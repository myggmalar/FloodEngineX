import sys
import numpy as np
import os

# Add the current directory to the path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import our module
from saint_venant_2d import SaintVenant2D

# Create a test DEM with a river channel (lower elevation in the middle)
dem_size = 20
dem_array = np.ones((dem_size, dem_size)) * 10.0  # Base elevation

# Create a river channel (lower elevation) from top to bottom
for i in range(dem_size):
    for j in range(dem_size):
        # Create a channel with varying elevation (higher at top, lower at bottom)
        if 8 <= j <= 12:
            dem_array[i, j] = 9.0 - (i / (dem_size - 1)) * 2.0

# Set up a geotransform (just for testing)
geotransform = (0, 10, 0, 0, 0, -10)  # 10m cell size

# Create the model
model = SaintVenant2D(dem_array, geotransform)

# Set initial water level just above the highest part of the river
initial_water_level = 9.1
model.set_initial_condition(water_level=initial_water_level)

# Add an inflow at the highest point
if model.h.max() > 0:
    print(f"Initial water in the system. Max depth: {model.h.max():.3f}m")
    
    # Find the highest elevation in the river network
    river_mask = model.h > 0.001
    if np.sum(river_mask) > 0:
        river_elevations = np.where(river_mask, dem_array, -np.inf)
        highest_idx = np.unravel_index(np.argmax(river_elevations), dem_array.shape)
        py, px = highest_idx
        print(f"Found highest point in river at ({px}, {py}) with elevation {dem_array[py, px]:.2f}m")
    
        # Run a few simulation steps
        print("\nRunning simulation:")
        for step in range(5):
            # Add water at the source
            model.h[py, px] = max(model.h[py, px], 0.5)  # Ensure minimum depth at source
            
            # Step the model
            dt = model.step()
            
            # Print some statistics
            print(f"Step {step+1}: Max depth={model.h.max():.3f}m, Time step={dt:.3f}s")
            
            # Check where water is flowing
            wet_cells = np.sum(model.h > 0.01)
            print(f"   Water present in {wet_cells} cells")
            
            # Check if water is flowing downstream (y-direction in our setup)
            if model.velocity_y.max() > 0:
                print(f"   Water is flowing downstream! Max v_y={model.velocity_y.max():.3f}m/s")
            
        print("\nTest passed! Water flows from highest point down through the river network.")
    else:
        print("No water in the river network. Test failed.")
else:
    print("No water initialized in the model. Test failed.")
