"""
Test script to validate the flow from highest elevation points in the river network
This test creates a simple synthetic terrain with dams and verifies water accumulation behavior
"""

import os
import sys
import numpy as np
import matplotlib.pyplot as plt
from osgeo import gdal
import time

# Add the current directory to the path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import the fixed Saint-Venant model
from saint_venant_2d import SaintVenant2D

# Create a synthetic test DEM with a river channel and dam
def create_test_dem_with_dam():
    """Create a synthetic DEM with a channel and dam for testing"""
    dem_size = 40
    dem = np.ones((dem_size, dem_size)) * 10.0  # Base elevation
    
    # Create a channel running from top to bottom
    channel_width = 4
    channel_center = dem_size // 2
    for i in range(dem_size):
        # Calculate channel depth (deeper as we go down)
        depth = 3.0 * (i / dem_size)
        
        # Channel with decreasing elevation from top to bottom
        for j in range(channel_center - channel_width, channel_center + channel_width):
            dem[i, j] = 9.0 - depth
    
    # Add a dam structure across the channel
    dam_row = dem_size // 4 * 3  # Place dam at 3/4 down the DEM
    dam_height = 1.5  # Dam height in meters
    
    for j in range(channel_center - channel_width - 1, channel_center + channel_width + 1):
        dem[dam_row, j] = 9.0 + dam_height
    
    # Create deeper pool behind dam
    for i in range(dam_row - 10, dam_row):
        for j in range(channel_center - channel_width, channel_center + channel_width):
            # Adjust the elevation behind the dam to create a deeper basin
            dem[i, j] = min(dem[i, j], 9.0 - 1.0)
    
    return dem

# Run the test
print("Starting Saint-Venant test with dam structure...")
dem_array = create_test_dem_with_dam()

# Set up a geotransform (just for testing)
geotransform = (0, 10, 0, 0, 0, -10)  # 10m cell size

# Create and initialize the model
model = SaintVenant2D(dem_array, geotransform)

# Set initial water level just above the highest part of the river channel
initial_water_level = 9.2  # Just above channel top
model.set_initial_condition(water_level=initial_water_level)

# Find the highest point in the wet cells (river)
wet_mask = model.h > 0.01
if np.sum(wet_mask) > 0:
    highest_elev = np.where(wet_mask, dem_array, -np.inf)
    highest_idx = np.unravel_index(np.argmax(highest_elev), dem_array.shape)
    py, px = highest_idx
    print(f"Identified highest point in river: ({px}, {py}) with elevation {dem_array[py, px]:.2f}m")
else:
    print("No wet cells identified. Check water level setup.")
    sys.exit(1)

# Visualization function
def visualize_results(dem, water_surface, step):
    """Create a visualization of the water surface and terrain"""
    fig, ax = plt.subplots(figsize=(10, 8))
    
    # Plot DEM as a grayscale background
    ax.imshow(dem, cmap='terrain', alpha=0.7)
    
    # Calculate water depth
    water_depth = np.maximum(water_surface - dem, 0)
    
    # Plot water with blue color where depth > 0
    water_mask = water_depth > 0.01
    water_plot = np.ma.masked_where(~water_mask, water_depth)
    
    # Use a blue colormap for water depth
    water_cmap = plt.cm.Blues
    im = ax.imshow(water_plot, cmap=water_cmap, vmin=0, vmax=max(0.1, np.max(water_depth)))
    
    # Add a colorbar for water depth
    cbar = plt.colorbar(im, ax=ax)
    cbar.set_label('Water Depth (m)')
    
    ax.set_title(f'Water Surface - Step {step}')
    plt.savefig(f'water_surface_step_{step:03d}.png')
    plt.close()

# Run several simulation steps
total_steps = 20
print(f"\nRunning {total_steps} simulation steps...")

# Add inflow at the highest point
for step in range(total_steps):
    # Add water at the highest point
    inflow_rate = 5.0  # m³/s
    cell_area = 100.0  # 10m x 10m
    depth_rate = inflow_rate / cell_area
    
    # Add water to the highest point
    model.h[py, px] += depth_rate * 1.0  # Add water equivalent to 1 second of flow
    
    # Ensure minimum source depth
    if model.h[py, px] < 0.5:
        model.h[py, px] = 0.5
    
    # Initialize flow in steepest downhill direction
    # Find direction of steepest descent
    max_slope = 0
    flow_dir_x, flow_dir_y = 0, 0
    
    for dy in [-1, 0, 1]:
        ny = py + dy
        if ny < 0 or ny >= model.shape[0]:
            continue
            
        for dx in [-1, 0, 1]:
            nx = px + dx
            if nx < 0 or nx >= model.shape[1]:
                continue
            if dx == 0 and dy == 0:
                continue
                
            # Calculate slope (positive means downhill)
            slope = dem_array[py, px] - dem_array[ny, nx]
            if slope > max_slope:
                max_slope = slope
                flow_dir_y, flow_dir_x = dy, dx
    
    # Set initial flow in steepest downhill direction
    if max_slope > 0:
        magnitude = 0.5  # Conservative velocity
        if flow_dir_x != 0:
            model.qx[py, px] = model.h[py, px] * magnitude * np.sign(flow_dir_x)
        if flow_dir_y != 0:
            model.qy[py, px] = model.h[py, px] * magnitude * np.sign(flow_dir_y)
    
    # Run a simulation step
    dt = model.calculate_timestep()
    actual_dt = model.step(dt)
    
    # Get water surface
    water_surface = model.get_water_surface()
    
    # Calculate max depth and stats
    water_depth = np.maximum(water_surface - dem_array, 0)
    max_depth = np.max(water_depth)
    
    # Count wet cells
    wet_cells = np.sum(water_depth > 0.01)
    
    print(f"Step {step+1}: dt={actual_dt:.2f}s, max depth={max_depth:.2f}m, wet cells={wet_cells}")
    
    # Visualize results every 5 steps
    if step % 5 == 0 or step == total_steps - 1:
        visualize_results(dem_array, water_surface, step)

print("\nTest completed successfully!")
print("Visualizations saved as PNG files.")

# Analyze water accumulation behind dam
dam_row = len(dem_array) // 4 * 3
channel_center = len(dem_array) // 2
channel_width = 4

# Calculate water depths before and after dam
water_depth = np.maximum(water_surface - dem_array, 0)
upstream_depths = water_depth[dam_row-5:dam_row, channel_center-channel_width:channel_center+channel_width]
downstream_depths = water_depth[dam_row+1:dam_row+6, channel_center-channel_width:channel_center+channel_width]

print(f"\nWater accumulation analysis:")
print(f"Average depth upstream of dam: {np.mean(upstream_depths):.2f}m")
print(f"Maximum depth upstream of dam: {np.max(upstream_depths):.2f}m")
print(f"Average depth downstream of dam: {np.mean(downstream_depths):.2f}m")
print(f"Maximum depth downstream of dam: {np.max(downstream_depths):.2f}m")

# Check if water accumulated behind dam correctly
if np.mean(upstream_depths) > np.mean(downstream_depths):
    print("SUCCESS: Water properly accumulated behind dam as expected")
else:
    print("WARNING: Water did not accumulate properly behind dam")
