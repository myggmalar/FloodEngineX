"""
Check indentation of all critical files
This script checks for indentation issues without importing the modules
"""
import os
import sys
import tokenize

def check_file_indentation(filename):
    """Check file for indentation issues without importing it"""
    print(f"\nChecking {filename}...")
    
    if not os.path.exists(filename):
        print(f"  ❌ File not found")
        return False
        
    try:
        # Read the file in binary mode for tokenize
        with open(filename, 'rb') as f:
            # Parse the file into tokens
            tokens = list(tokenize.tokenize(f.readline))
            
        # If we got here, the file tokenized correctly
        print(f"  ✅ No tokenization errors - indentation is correct")
        return True
    
    except tokenize.TokenError as e:
        line_no, message = e.args
        print(f"  ❌ Tokenization error at line {line_no}: {message}")
        
        # Show context around the error
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            start = max(0, line_no-5)
            end = min(len(lines), line_no+5)
            
            print("\nContext:")
            for i in range(start, end):
                prefix = "→ " if i == line_no-1 else "  "
                print(f"{prefix}{i+1}: {lines[i].rstrip()}")
        except Exception:
            print("  Could not show context")
            
        return False
    
    except IndentationError as e:
        print(f"  ❌ Indentation error at line {e.lineno}: {e.msg}")
        return False
    
    except Exception as e:
        print(f"  ❌ Error: {e}")
        return False

def main():
    """Check all critical files for indentation issues"""
    print("CHECKING INDENTATION")
    
    critical_files = [
        "floodengine_ui.py",
        "floodengine.py",
        "model_hydraulic.py",
        "flow_direction_flood_fixed.py",
        "__init__.py"
    ]
    
    results = []
    all_ok = True
    for filename in critical_files:
        result = check_file_indentation(filename)
        results.append((filename, result))
        if not result:
            all_ok = False
    
    print("\nSUMMARY:")
    for filename, result in results:
        status = "✓" if result else "✗"
        print(f"{status} {filename}")
    
    if all_ok:
        print("\nAll files OK - Plugin should load in QGIS")
        return 0
    else:
        print("\nSome files have issues - Fix and recheck")
        return 1

if __name__ == "__main__":
    sys.exit(main())
