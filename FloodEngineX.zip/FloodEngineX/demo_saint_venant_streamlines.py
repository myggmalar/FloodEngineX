#!/usr/bin/env python3
"""
Demonstration script for Enhanced Streamlines with Saint-Venant Velocity Files
==============================================================================

This script demonstrates how to use the enhanced streamlines functionality
with Saint-Venant velocity files for realistic 2D hydraulic modeling.

The script shows:
1. How to check for Saint-Venant velocity files
2. How to load and use them in streamlines generation
3. How to compare results with and without Saint-Venant data
"""

import os
import sys
import logging
from pathlib import Path

# Add the FloodEngineX directory to the Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("SaintVenantStreamlinesDemo")

def demonstrate_saint_venant_streamlines():
    """Demonstrate the enhanced streamlines with Saint-Venant velocity files."""
    
    logger.info("🌊 Enhanced Streamlines with Saint-Venant Velocity Files Demo")
    logger.info("=" * 60)
    
    # Import the enhanced streamlines functions
    try:
        from enhanced_streamlines import (
            load_saint_venant_velocity_files,
            create_enhanced_streamlines_auto_detect,
            create_enhanced_streamlines
        )
        logger.info("✅ Successfully imported enhanced streamlines functions")
    except ImportError as e:
        logger.error(f"❌ Failed to import enhanced streamlines: {e}")
        return False
    
    # Example usage scenarios
    logger.info("\n📋 Usage Scenarios:")
    logger.info("-" * 40)
    
    # Scenario 1: Auto-detection of Saint-Venant files
    logger.info("1️⃣  Auto-Detection Method (Recommended):")
    logger.info("   This method automatically detects Saint-Venant velocity files")
    logger.info("   and uses them if available, otherwise falls back to hydraulic approximation.")
    logger.info("")
    logger.info("   Usage example:")
    logger.info("   ```python")
    logger.info("   streamlines = create_enhanced_streamlines_auto_detect(")
    logger.info("       dem_path='path/to/dem.tif',")
    logger.info("       flood_layer=flood_polygon_layer,")
    logger.info("       output_folder='path/to/saint_venant_results',")
    logger.info("       flow_q=150.0")
    logger.info("   )")
    logger.info("   ```")
    
    # Scenario 2: Manual Saint-Venant method
    logger.info("\n2️⃣  Manual Saint-Venant Method:")
    logger.info("   This method explicitly uses Saint-Venant velocity files")
    logger.info("   and will generate an error if they're not found.")
    logger.info("")
    logger.info("   Usage example:")
    logger.info("   ```python")
    logger.info("   streamlines = create_enhanced_streamlines(")
    logger.info("       dem_path='path/to/dem.tif',")
    logger.info("       flood_layer=flood_polygon_layer,")
    logger.info("       output_folder='path/to/saint_venant_results',")
    logger.info("       method='saint_venant',")
    logger.info("       flow_q=150.0")
    logger.info("   )")
    logger.info("   ```")
    
    # Scenario 3: Hydraulic approximation method
    logger.info("\n3️⃣  Hydraulic Approximation Method:")
    logger.info("   This method uses traditional hydraulic approximations")
    logger.info("   based on water surface gradients and Manning's equation.")
    logger.info("")
    logger.info("   Usage example:")
    logger.info("   ```python")
    logger.info("   streamlines = create_enhanced_streamlines(")
    logger.info("       dem_path='path/to/dem.tif',")
    logger.info("       flood_layer=flood_polygon_layer,")
    logger.info("       method='hydraulic',")
    logger.info("       flow_q=150.0")
    logger.info("   )")
    logger.info("   ```")
    
    # Expected Saint-Venant file structure
    logger.info("\n📁 Expected Saint-Venant File Structure:")
    logger.info("-" * 40)
    logger.info("The Saint-Venant velocity files should be located in the output folder")
    logger.info("with the following naming conventions:")
    logger.info("")
    logger.info("Required files:")
    logger.info("  • velocity_x.tif    - X-component of velocity (m/s)")
    logger.info("  • velocity_y.tif    - Y-component of velocity (m/s)")
    logger.info("")
    logger.info("Optional files:")
    logger.info("  • velocity_magnitude.tif - Velocity magnitude (m/s)")
    logger.info("  • vx.tif, vy.tif, vmag.tif - Alternative naming")
    logger.info("")
    logger.info("All files should be in GeoTIFF format and have the same")
    logger.info("spatial extent and resolution as the DEM.")
    
    # Benefits of Saint-Venant method
    logger.info("\n🎯 Benefits of Using Saint-Venant Velocity Files:")
    logger.info("-" * 50)
    logger.info("✅ Physically realistic 2D hydraulic modeling")
    logger.info("✅ Proper momentum conservation")
    logger.info("✅ Accurate velocity magnitudes (typically 0.1-3.0 m/s)")
    logger.info("✅ Correct flow directions in complex geometries")
    logger.info("✅ Accounts for backwater effects and flow recirculation")
    logger.info("✅ No unrealistic high velocities (6+ m/s)")
    logger.info("✅ Better streamline patterns in rivers and floodplains")
    
    # Common issues and solutions
    logger.info("\n🔧 Common Issues and Solutions:")
    logger.info("-" * 35)
    logger.info("❌ 'No Saint-Venant velocity files found'")
    logger.info("   → Check file naming conventions")
    logger.info("   → Verify files are in GeoTIFF format")
    logger.info("   → Ensure files are in the specified output folder")
    logger.info("")
    logger.info("❌ 'Shape mismatch between DEM and velocity files'")
    logger.info("   → Ensure all files have the same spatial extent")
    logger.info("   → Check that pixel sizes match")
    logger.info("   → Verify coordinate reference systems are consistent")
    logger.info("")
    logger.info("❌ 'Unrealistic velocity values'")
    logger.info("   → Check Saint-Venant solver parameters")
    logger.info("   → Verify boundary conditions")
    logger.info("   → Ensure proper time step convergence")
    
    # Test current setup
    logger.info("\n🔍 Testing Current Setup:")
    logger.info("-" * 30)
    
    # Check for Saint-Venant files in common locations
    test_directories = [
        "C:/Plugin/VSCode/Alt3/FloodEngineX/results",
        "C:/Plugin/VSCode/Alt3/FloodEngineX/output",
        "C:/Plugin/VSCode/Alt3/FloodEngineX/saint_venant_results"
    ]
    
    found_files = False
    for test_dir in test_directories:
        if os.path.exists(test_dir):
            logger.info(f"📁 Checking: {test_dir}")
            
            # Check for Saint-Venant velocity files
            saint_venant_results = load_saint_venant_velocity_files(test_dir)
            if saint_venant_results is not None:
                logger.info(f"✅ Found Saint-Venant velocity files in {test_dir}")
                found_files = True
                break
            else:
                logger.info(f"❌ No Saint-Venant files found in {test_dir}")
    
    if not found_files:
        logger.info("⚠️  No Saint-Venant velocity files found in standard locations")
        logger.info("   To use Saint-Venant method, ensure velocity files are available")
        logger.info("   or use the hydraulic approximation method instead.")
    
    logger.info("\n🎉 Demo completed! You can now use enhanced streamlines with Saint-Venant velocity files.")
    logger.info("=" * 60)
    
    return True

def main():
    """Main function to run the demonstration."""
    try:
        demonstrate_saint_venant_streamlines()
    except Exception as e:
        logger.error(f"❌ Demo failed: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
