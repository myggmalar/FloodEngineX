"""
Emergency Diagnostic Script for Saint-Venant Velocity Issues
===========================================================

This script helps diagnose why the Saint-Venant solver is still producing
extreme velocities even after our fixes.
"""

import numpy as np
import os
import sys
from osgeo import gdal
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

def diagnose_velocity_files(output_folder):
    """
    Diagnose velocity files to understand the extreme values.
    """
    logger.info("🔍 Diagnosing Saint-Venant velocity files...")
    
    # Look for velocity files
    velocity_files = {}
    for file_name in os.listdir(output_folder):
        file_path = os.path.join(output_folder, file_name)
        
        if not os.path.isfile(file_path):
            continue
            
        if 'velocity' in file_name.lower() and file_name.lower().endswith(('.tif', '.tiff')):
            velocity_files[file_name] = file_path
            logger.info(f"Found velocity file: {file_name}")
    
    if not velocity_files:
        logger.error("No velocity files found!")
        return
    
    # Analyze each velocity file
    for file_name, file_path in velocity_files.items():
        logger.info(f"\n📊 Analyzing {file_name}:")
        
        try:
            # Load the file
            ds = gdal.Open(file_path)
            data = ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
            nodata = ds.GetRasterBand(1).GetNoDataValue()
            
            # Handle nodata
            if nodata is not None:
                data[data == nodata] = np.nan
            
            # Clean data
            data = np.nan_to_num(data, nan=0.0, posinf=0.0, neginf=0.0)
            
            # Calculate statistics
            non_zero_data = data[data != 0]
            
            logger.info(f"  📈 Statistics:")
            logger.info(f"    • Min value: {np.min(data):.3f}")
            logger.info(f"    • Max value: {np.max(data):.3f}")
            logger.info(f"    • Mean value: {np.mean(data):.3f}")
            logger.info(f"    • Median value: {np.median(data):.3f}")
            logger.info(f"    • Std deviation: {np.std(data):.3f}")
            
            if len(non_zero_data) > 0:
                logger.info(f"    • Non-zero cells: {len(non_zero_data)}")
                logger.info(f"    • Mean (non-zero): {np.mean(non_zero_data):.3f}")
                logger.info(f"    • Max (non-zero): {np.max(non_zero_data):.3f}")
            
            # Check for extreme values
            extreme_threshold = 10.0
            extreme_count = np.sum(np.abs(data) > extreme_threshold)
            if extreme_count > 0:
                logger.warning(f"  ⚠️  {extreme_count} cells with values > {extreme_threshold}")
                
                # Show distribution of extreme values
                extreme_values = data[np.abs(data) > extreme_threshold]
                logger.warning(f"    • Extreme values range: {np.min(extreme_values):.1f} to {np.max(extreme_values):.1f}")
            
            # Check for very extreme values
            very_extreme_threshold = 50.0
            very_extreme_count = np.sum(np.abs(data) > very_extreme_threshold)
            if very_extreme_count > 0:
                logger.error(f"  🚨 {very_extreme_count} cells with values > {very_extreme_threshold} (CRITICAL!)")
                
                # Show where these occur
                extreme_indices = np.where(np.abs(data) > very_extreme_threshold)
                logger.error(f"    • Extreme locations: {len(extreme_indices[0])} cells")
                for i in range(min(5, len(extreme_indices[0]))):  # Show first 5
                    row, col = extreme_indices[0][i], extreme_indices[1][i]
                    value = data[row, col]
                    logger.error(f"      Row {row}, Col {col}: {value:.1f}")
            
        except Exception as e:
            logger.error(f"Error analyzing {file_name}: {e}")

def diagnose_saint_venant_solver_state():
    """
    Check the state of the Saint-Venant solver configuration.
    """
    logger.info("\n🔧 Checking Saint-Venant solver configuration...")
    
    # Try to import and inspect the solver
    try:
        from saint_venant_2d import SaintVenant2D
        
        # Create a test instance
        test_dem = np.ones((10, 10)) * 5.0
        test_geotransform = (0, 10, 0, 0, 0, -10)
        
        solver = SaintVenant2D(test_dem, test_geotransform)
        
        logger.info(f"  • CFL factor: {getattr(solver, 'cfl', 'Not set')}")
        logger.info(f"  • Min depth: {solver.min_depth}")
        logger.info(f"  • Gravity: {solver.g}")
        logger.info(f"  • Epsilon: {solver.epsilon}")
        
        # Test timestep calculation
        solver.h[5, 5] = 1.0
        solver.u[5, 5] = 2.0
        solver.v[5, 5] = 1.0
        
        dt = solver.calculate_timestep()
        logger.info(f"  • Sample timestep: {dt:.4f} s")
        
        if dt > 1.0:
            logger.warning("  ⚠️  Timestep seems large - could cause instability")
        
    except Exception as e:
        logger.error(f"Error checking solver: {e}")

def apply_emergency_velocity_fix(output_folder):
    """
    Apply emergency velocity capping directly to velocity files.
    """
    logger.info("\n🚑 Applying emergency velocity fixes...")
    
    # Look for velocity files
    velocity_files = {}
    for file_name in os.listdir(output_folder):
        file_path = os.path.join(output_folder, file_name)
        
        if not os.path.isfile(file_path):
            continue
            
        if 'velocity' in file_name.lower() and file_name.lower().endswith(('.tif', '.tiff')):
            velocity_files[file_name] = file_path
    
    if not velocity_files:
        logger.error("No velocity files found to fix!")
        return
    
    # Apply fixes to each file
    for file_name, file_path in velocity_files.items():
        logger.info(f"  🔧 Fixing {file_name}...")
        
        try:
            # Load the file
            ds = gdal.Open(file_path, gdal.GA_Update)
            data = ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
            nodata = ds.GetRasterBand(1).GetNoDataValue()
            
            # Handle nodata
            if nodata is not None:
                data[data == nodata] = 0.0
            
            # Clean data
            data = np.nan_to_num(data, nan=0.0, posinf=0.0, neginf=0.0)
            
            # Record original stats
            original_max = np.max(np.abs(data))
            original_extreme_count = np.sum(np.abs(data) > 10.0)
            
            # Apply emergency caps
            # Cap 1: Emergency limit at 10 m/s
            emergency_cap = 10.0
            data = np.clip(data, -emergency_cap, emergency_cap)
            
            # Cap 2: Realistic limit at 5 m/s for most values
            realistic_cap = 5.0
            extreme_mask = np.abs(data) > realistic_cap
            if np.any(extreme_mask):
                data[extreme_mask] = np.sign(data[extreme_mask]) * realistic_cap
            
            # Write back to file
            ds.GetRasterBand(1).WriteArray(data)
            ds.FlushCache()
            
            # Report results
            new_max = np.max(np.abs(data))
            new_extreme_count = np.sum(np.abs(data) > 10.0)
            
            logger.info(f"    • Max value: {original_max:.1f} → {new_max:.1f}")
            logger.info(f"    • Extreme cells (>10): {original_extreme_count} → {new_extreme_count}")
            
            ds = None  # Close file
            
        except Exception as e:
            logger.error(f"Error fixing {file_name}: {e}")

def main():
    """
    Main diagnostic function.
    """
    logger.info("Saint-Venant Velocity Diagnostic Tool")
    logger.info("=" * 40)
    
    # Get output folder from user or use default
    if len(sys.argv) > 1:
        output_folder = sys.argv[1]
    else:
        output_folder = input("Enter path to output folder (or press Enter for current directory): ")
        if not output_folder:
            output_folder = "."
    
    if not os.path.exists(output_folder):
        logger.error(f"Output folder does not exist: {output_folder}")
        return
    
    logger.info(f"Analyzing folder: {output_folder}")
    
    # Run diagnostics
    diagnose_velocity_files(output_folder)
    diagnose_saint_venant_solver_state()
    
    # Ask if user wants to apply emergency fixes
    response = input("\nApply emergency velocity fixes? (y/n): ")
    if response.lower() in ['y', 'yes']:
        apply_emergency_velocity_fix(output_folder)
        logger.info("✅ Emergency fixes applied!")
        
        # Re-run diagnostics to show results
        logger.info("\n📊 Post-fix diagnostics:")
        diagnose_velocity_files(output_folder)
    
    logger.info("\nDiagnostic complete!")

if __name__ == "__main__":
    main()
