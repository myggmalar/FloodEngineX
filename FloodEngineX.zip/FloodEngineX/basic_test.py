"""
Basic verification of SaintVenant2D functionality
"""

import numpy as np
import sys

# Create a very simple test DEM
dem_size = 10
dem = np.ones((dem_size, dem_size)) * 10.0

# Create a simple slope from top to bottom
for i in range(dem_size):
    for j in range(dem_size):
        dem[i, j] = 10.0 - i * 0.1  # Simple slope down

# Print confirmation
print("Created test DEM")
print(f"DEM shape: {dem.shape}")
print(f"DEM elevation range: {np.min(dem):.1f} to {np.max(dem):.1f}")

try:
    # Import the model - try the fixed version first
    print("Importing SaintVenant2D...")
    from saint_venant_2d import SaintVenant2D
    
    # Setup basic geotransform
    geotransform = (0, 10, 0, 0, 0, -10)
    
    # Create model
    print("Creating model...")
    model = SaintVenant2D(dem, geotransform)
    
    # Set initial water with a simple depth
    print("Setting initial water...")
    water_level = 10.5  # Above the top of the DEM
    model.set_initial_condition(water_level=water_level)
    
    # Check if water was initialized
    if np.max(model.h) > 0:
        print(f"Water initialized. Max depth: {np.max(model.h):.2f}m")
    else:
        print("ERROR: No water was initialized")
        sys.exit(1)
    
    # Run a single step
    print("Running simulation step...")
    dt = model.calculate_timestep()
    print(f"Calculated timestep: {dt:.3f}s")
    
    actual_dt = model.step(dt)
    print(f"Step completed with dt={actual_dt:.3f}s")
    
    # Get water surface
    print("Getting final water surface...")
    water_surface = model.get_water_surface()
    
    # Print the final state
    water_depth = np.maximum(water_surface - dem, 0)
    print(f"Final maximum water depth: {np.max(water_depth):.2f}m")
    print(f"Final average water depth: {np.mean(water_depth):.2f}m")
    
    print("Test completed successfully!")
    
except Exception as e:
    print(f"Error occurred: {e}")
    import traceback
    traceback.print_exc()
