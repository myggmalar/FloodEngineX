#!/usr/bin/env python3
"""
Test script to verify flow point density and velocity distribution fixes
"""

import sys
import os
import numpy as np
import logging

# Add the FloodEngineX directory to the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from enhanced_flow_points import EnhancedFlowPoints

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

def test_flow_points_density():
    """Test that flow point density is reasonable and velocities are correctly distributed"""
    
    print("🔧 Testing Flow Point Density and Velocity Distribution")
    print("=" * 60)
    
    # Create a test DEM with a river channel
    rows, cols = 100, 100
    dem = np.zeros((rows, cols))
    
    # Create a river channel (deeper area) running diagonally
    for i in range(rows):
        for j in range(cols):
            # Distance from diagonal line
            dist_from_channel = abs(i - j) 
            
            if dist_from_channel <= 5:  # Main river channel
                dem[i, j] = 95.0 - (5 - dist_from_channel) * 0.5  # Deeper
            elif dist_from_channel <= 15:  # Secondary channels/floodplain
                dem[i, j] = 98.0 - (15 - dist_from_channel) * 0.1
            else:  # Higher ground
                dem[i, j] = 100.0 + 0.1 * (dist_from_channel - 15)
    
    # Create geotransform (10m pixel size)
    geotransform = (0.0, 10.0, 0.0, 0.0, 0.0, -10.0)
    
    # Create water level (flooding)
    water_level = 99.0
    water_depth = np.maximum(water_level - dem, 0)
    
    # Create flow points generator
    flow_points = EnhancedFlowPoints(dem, geotransform, water_depth=water_depth)
    
    # Calculate velocity field
    vx, vy, vmag = flow_points.calculate_velocity_field(method="hydraulic")
    
    print(f"\n📊 DEM and Water Statistics:")
    print(f"  • DEM range: {np.min(dem):.1f} - {np.max(dem):.1f} m")
    print(f"  • Water depth range: {np.min(water_depth):.2f} - {np.max(water_depth):.2f} m")
    print(f"  • Flooded cells: {np.sum(water_depth > 0.01)}")
    print(f"  • River channel cells (depth > 1.5m): {np.sum(water_depth > 1.5)}")
    print(f"  • Secondary channel cells (depth > 0.5m): {np.sum((water_depth > 0.5) & (water_depth <= 1.5))}")
    print(f"  • Floodplain cells (depth <= 0.5m): {np.sum((water_depth > 0.01) & (water_depth <= 0.5))}")
    
    print(f"\n🌊 Velocity Field Statistics:")
    print(f"  • Velocity range: {np.min(vmag):.3f} - {np.max(vmag):.3f} m/s")
    print(f"  • Mean velocity: {np.mean(vmag):.3f} m/s")
    
    # Check velocity distribution by depth
    main_channel_mask = water_depth > 1.5
    secondary_channel_mask = (water_depth > 0.5) & (water_depth <= 1.5)
    floodplain_mask = (water_depth > 0.01) & (water_depth <= 0.5)
    
    if np.sum(main_channel_mask) > 0:
        main_channel_vel = vmag[main_channel_mask]
        print(f"  • Main channel velocity: {np.mean(main_channel_vel):.3f} ± {np.std(main_channel_vel):.3f} m/s")
    
    if np.sum(secondary_channel_mask) > 0:
        secondary_channel_vel = vmag[secondary_channel_mask]
        print(f"  • Secondary channel velocity: {np.mean(secondary_channel_vel):.3f} ± {np.std(secondary_channel_vel):.3f} m/s")
    
    if np.sum(floodplain_mask) > 0:
        floodplain_vel = vmag[floodplain_mask]
        print(f"  • Floodplain velocity: {np.mean(floodplain_vel):.3f} ± {np.std(floodplain_vel):.3f} m/s")
    
    # Generate flow points
    flood_mask = water_depth > 0.01
    points = flow_points.generate_flow_points(flood_mask)
    
    print(f"\n📍 Flow Points Generation:")
    print(f"  • Total points generated: {len(points)}")
    print(f"  • Points per flooded cell: {len(points) / np.sum(flood_mask):.3f}")
    
    # Analyze point distribution by depth
    if len(points) > 0:
        point_depths = [p['depth'] for p in points]
        point_velocities = [p['velocity'] for p in points]
        
        main_channel_points = [p for p in points if p['depth'] > 1.5]
        secondary_channel_points = [p for p in points if 0.5 < p['depth'] <= 1.5]
        floodplain_points = [p for p in points if p['depth'] <= 0.5]
        
        print(f"  • Main channel points: {len(main_channel_points)}")
        print(f"  • Secondary channel points: {len(secondary_channel_points)}")
        print(f"  • Floodplain points: {len(floodplain_points)}")
        
        if len(main_channel_points) > 0:
            main_vel = np.mean([p['velocity'] for p in main_channel_points])
            print(f"  • Main channel point velocity: {main_vel:.3f} m/s")
        
        if len(secondary_channel_points) > 0:
            secondary_vel = np.mean([p['velocity'] for p in secondary_channel_points])
            print(f"  • Secondary channel point velocity: {secondary_vel:.3f} m/s")
        
        if len(floodplain_points) > 0:
            floodplain_vel = np.mean([p['velocity'] for p in floodplain_points])
            print(f"  • Floodplain point velocity: {floodplain_vel:.3f} m/s")
    
    print(f"\n✅ Test completed!")
    
    # Verify expectations
    success = True
    
    # Check point density is reasonable (not too dense)
    if len(points) > np.sum(flood_mask) * 0.5:  # More than 50% of cells have points
        print(f"⚠️  Warning: Point density may be too high ({len(points)} points for {np.sum(flood_mask)} flooded cells)")
        success = False
    else:
        print(f"✅ Point density is reasonable")
    
    # Check velocity distribution
    if len(main_channel_points) > 0 and len(floodplain_points) > 0:
        main_vel_avg = np.mean([p['velocity'] for p in main_channel_points])
        floodplain_vel_avg = np.mean([p['velocity'] for p in floodplain_points])
        
        if main_vel_avg > floodplain_vel_avg:
            print(f"✅ Main channel has higher velocity than floodplain ({main_vel_avg:.3f} vs {floodplain_vel_avg:.3f} m/s)")
        else:
            print(f"⚠️  Warning: Main channel velocity ({main_vel_avg:.3f}) should be higher than floodplain ({floodplain_vel_avg:.3f})")
            success = False
    
    return success

if __name__ == "__main__":
    success = test_flow_points_density()
    if success:
        print("\n🎉 All tests passed!")
        sys.exit(0)
    else:
        print("\n❌ Some tests failed!")
        sys.exit(1)
