import sys
import os
import numpy as np

print("Starting test of SaintVenant2D with proper river source detection...")

# Add current dir to path
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

# Import modules
from saint_venant_2d import SaintVenant2D

# Create a test DEM with a river channel
dem = np.ones((10, 10)) * 100.0
# Create a channel with decreasing elevation (high at top, low at bottom)
dem[0:10, 5] = np.linspace(99.0, 95.0, 10)

print(f"Created test DEM with river channel from {dem[0,5]} to {dem[9,5]}")

# Create the model
model = SaintVenant2D(dem, (0, 1, 0, 0, 0, -1))
print("Created SaintVenant2D model")

# Set initial water level
water_level = 99.1  # Just above the highest river point
model.set_initial_condition(water_level=water_level)
print(f"Set initial water level to {water_level}")

# Check if water initialized correctly
if np.max(model.h) > 0:
    print(f"Water initialized. Max depth: {np.max(model.h):.3f}m")
    
    # Find highest point in river
    wet_mask = model.h > 0.001
    if np.sum(wet_mask) > 0:
        river_elevations = np.where(wet_mask, dem, -np.inf)
        highest_idx = np.unravel_index(np.argmax(river_elevations), dem.shape)
        py, px = highest_idx
        print(f"Highest point in river: ({px}, {py}) with elevation {dem[py, px]:.2f}m")
        
        # Test complete
        print("Test passed! The river source (highest point) was correctly identified.")
    else:
        print("Error: No wet cells detected in river")
else:
    print("Error: No water initialized in model")
