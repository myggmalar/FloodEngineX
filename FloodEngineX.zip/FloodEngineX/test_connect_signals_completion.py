#!/usr/bin/env python3
"""
Test script to validate the completion of FloodEngine connect_signals implementation
"""

import sys
import os
import importlib.util
import inspect

def test_connect_signals_completion():
    """Test that connect_signals method and related methods are properly implemented"""
    
    print("=" * 60)
    print("FloodEngine connect_signals Implementation Validation")
    print("=" * 60)
    
    # Import the main UI module
    try:        # Add the project directory to path
        project_dir = os.path.dirname(os.path.abspath(__file__))
        sys.path.insert(0, project_dir)
        
        # Import floodengine_ui module
        spec = importlib.util.spec_from_file_location("floodengine_ui", 
            os.path.join(project_dir, "floodengine_ui.py"))
        floodengine_ui = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(floodengine_ui)
        
        print("✓ Successfully imported floodengine_ui module")
        
        # Check if FloodEngineDialog class exists
        if hasattr(floodengine_ui, 'FloodEngineDialog'):
            FloodEngineDialog = getattr(floodengine_ui, 'FloodEngineDialog')
            print("✓ FloodEngineDialog class found")
            
            # Check for required methods
            required_methods = [
                'connect_signals',
                'toggle_groundwater_controls', 
                'toggle_urban_controls',
                'toggle_advanced_engine',
                'toggle_advanced_stream_burning',
                'setup_advanced_tab'            ]
            
            missing_methods = []
            present_methods = []
            
            for method_name in required_methods:
                if hasattr(FloodEngineDialog, method_name):
                    method = getattr(FloodEngineDialog, method_name)
                    if callable(method):
                        present_methods.append(method_name)
                        print(f"✓ Method '{method_name}' found and callable")
                        
                        # Get method signature for connect_signals
                        if method_name == 'connect_signals':
                            sig = inspect.signature(method)
                            print(f"  - Signature: {method_name}{sig}")
                              # Check toggle methods have correct signature
                        elif method_name.startswith('toggle_'):
                            sig = inspect.signature(method)
                            params = list(sig.parameters.keys())
                            if len(params) >= 2 and 'enabled' in params:
                                print(f"  - Signature: {method_name}{sig} ✓")
                            else:
                                print(f"  - Warning: Unexpected signature {method_name}{sig}")
                                
                    else:
                        missing_methods.append(method_name)
                        print(f"✗ Method '{method_name}' found but not callable")
                else:
                    missing_methods.append(method_name)
                    print(f"✗ Method '{method_name}' not found")
            
            print(f"\nSummary:")
            print(f"Present methods: {len(present_methods)}/{len(required_methods)}")
            print(f"Missing methods: {len(missing_methods)}")
            
            if missing_methods:
                print(f"Missing: {', '.join(missing_methods)}")
                return False
            else:
                print("✓ All required methods are present!")
                
                # Additional validation - check if connect_signals has proper implementation
                connect_signals_method = getattr(FloodEngineDialog, 'connect_signals')
                source = inspect.getsource(connect_signals_method)
                
                # Check for key signal connections
                key_connections = [
                    'basic_dem_btn.clicked.connect',
                    'basic_bath_btn.clicked.connect',
                    'run_button.clicked.connect',
                    'adv_use_advanced_engine.toggled.connect',
                    'toggle_advanced_engine',                    'toggle_groundwater_controls',
                    'toggle_urban_controls'
                ]
                
                found_connections = []
                missing_connections = []
                
                for connection in key_connections:
                    if connection in source:
                        found_connections.append(connection)
                        print(f"✓ Signal connection '{connection}' found")
                    else:
                        missing_connections.append(connection)
                        print(f"✗ Signal connection '{connection}' missing")
                
                print(f"\nSignal Connections Summary:")
                print(f"Found: {len(found_connections)}/{len(key_connections)}")
                
                if missing_connections:
                    print(f"Missing connections: {', '.join(missing_connections)}")
                    return False
                else:
                    print("✓ All key signal connections are present!")
                    return True
                    
        else:
            print("✗ FloodEngineDialog class not found")
            return False
            
    except Exception as e:
        print(f"✗ Error importing module: {str(e)}")
        return False

def test_syntax_validation():
    """Test that the Python file has no syntax errors"""
    print("\n" + "=" * 40)
    print("Syntax Validation")
    print("=" * 40)
    
    try:
        import ast
        
        file_path = os.path.join(os.path.dirname(__file__), "floodengine_ui.py")
        
        with open(file_path, 'r', encoding='utf-8') as f:
            source_code = f.read()
        
        # Parse the AST to check for syntax errors
        ast.parse(source_code)
        print("✓ No syntax errors found in floodengine_ui.py")
        return True
        
    except SyntaxError as e:
        print(f"✗ Syntax error found: {e}")
        print(f"  Line {e.lineno}: {e.text.strip() if e.text else 'N/A'}")
        return False
    except Exception as e:
        print(f"✗ Error during syntax validation: {str(e)}")
        return False

def main():
    """Run all validation tests"""
    print("FloodEngine Development Completion Validation")
    print("Testing connect_signals implementation and related methods...\n")
    
    # Test syntax first
    syntax_ok = test_syntax_validation()
    
    # Test method implementation
    methods_ok = test_connect_signals_completion()
    
    print("\n" + "=" * 60)
    print("FINAL VALIDATION RESULTS")
    print("=" * 60)
    
    if syntax_ok and methods_ok:
        print("✓ SUCCESS: FloodEngine connect_signals implementation is COMPLETE!")
        print("✓ All required methods are present and properly implemented")
        print("✓ No syntax errors detected")
        print("\nThe FloodEngine UI should now have:")
        print("- Complete signal-slot connections")
        print("- Proper toggle methods for advanced features")
        print("- Working advanced tab with hydraulic engine controls")
        return True
    else:
        print("✗ VALIDATION FAILED:")
        if not syntax_ok:
            print("  - Syntax errors need to be fixed")
        if not methods_ok:
            print("  - Missing or incomplete method implementations")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
