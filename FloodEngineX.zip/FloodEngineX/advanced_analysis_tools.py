#!/usr/bin/env python3
"""
FloodEngine v4.0 - Advanced Analysis Tools
==========================================

Professional-grade analysis tools for FloodEngine providing:
- Flood risk assessment and hazard mapping
- Economic impact analysis and damage assessment
- Uncertainty quantification and sensitivity analysis
- Multi-scenario comparison and statistical analysis
- Return period analysis and frequency mapping
- Climate change impact assessment

Author: FloodEngine Development Team
Date: June 7, 2025
Version: 4.0
"""

import os
import sys
import json
import logging
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any, Union
from dataclasses import dataclass, field
from datetime import datetime
from scipy import stats
from scipy.interpolate import interp1d
from scipy.optimize import minimize
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@dataclass
class FloodHazardMetrics:
    """Data class for flood hazard metrics"""
    depth_max: np.ndarray
    velocity_max: np.ndarray
    duration: np.ndarray
    hazard_rating: np.ndarray
    return_period: float
    exceedance_probability: float

@dataclass
class EconomicDamageAssessment:
    """Data class for economic damage assessment"""
    direct_damages: Dict[str, float]
    indirect_damages: Dict[str, float]
    total_damage: float
    affected_population: int
    damage_per_capita: float
    recovery_time_days: int
    
@dataclass
class UncertaintyAnalysis:
    """Data class for uncertainty analysis results"""
    parameter_sensitivity: Dict[str, float]
    confidence_intervals: Dict[str, Tuple[float, float]]
    monte_carlo_results: np.ndarray
    uncertainty_sources: List[str]
    total_uncertainty: float

class FloodRiskAssessment:
    """
    Comprehensive flood risk assessment and hazard mapping
    """
    
    def __init__(self):
        """Initialize flood risk assessment module"""
        self.hazard_categories = {
            'low': {'depth': (0, 0.3), 'velocity': (0, 0.5), 'rating': 1},
            'moderate': {'depth': (0.3, 1.0), 'velocity': (0.5, 1.5), 'rating': 2},
            'significant': {'depth': (1.0, 2.0), 'velocity': (1.5, 2.5), 'rating': 3},
            'high': {'depth': (2.0, float('inf')), 'velocity': (2.5, float('inf')), 'rating': 4}
        }
        
        # Standard return periods for analysis
        self.return_periods = [2, 5, 10, 25, 50, 100, 200, 500, 1000]
        
        logger.info("Flood risk assessment module initialized")

    def assess_flood_hazard(self, 
                           depth_grid: np.ndarray,
                           velocity_grid: np.ndarray,
                           duration_grid: np.ndarray,
                           return_period: float) -> FloodHazardMetrics:
        """
        Assess flood hazard based on depth, velocity, and duration
        
        Args:
            depth_grid: Maximum flood depth (m)
            velocity_grid: Maximum velocity (m/s)
            duration_grid: Flood duration (hours)
            return_period: Return period (years)
            
        Returns:
            FloodHazardMetrics object with hazard assessment
        """
        logger.info(f"Assessing flood hazard for {return_period}-year return period")
        
        # Calculate hazard rating based on depth and velocity
        hazard_rating = self._calculate_hazard_rating(depth_grid, velocity_grid)
        
        # Adjust for duration (longer duration increases hazard)
        duration_factor = np.clip(duration_grid / 12.0, 1.0, 2.0)  # 12 hours baseline
        hazard_rating = hazard_rating * duration_factor
        
        # Calculate exceedance probability
        exceedance_probability = 1.0 / return_period
        
        metrics = FloodHazardMetrics(
            depth_max=depth_grid,
            velocity_max=velocity_grid,
            duration=duration_grid,
            hazard_rating=hazard_rating,
            return_period=return_period,
            exceedance_probability=exceedance_probability
        )
        
        logger.info("Flood hazard assessment completed")
        return metrics

    def _calculate_hazard_rating(self, depth: np.ndarray, velocity: np.ndarray) -> np.ndarray:
        """Calculate hazard rating based on depth and velocity"""
        hazard_rating = np.zeros_like(depth)
        
        for category, criteria in self.hazard_categories.items():
            # Depth criteria
            depth_mask = (depth >= criteria['depth'][0]) & (depth < criteria['depth'][1])
            
            # Velocity criteria (if both depth and velocity meet criteria)
            velocity_mask = (velocity >= criteria['velocity'][0]) & (velocity < criteria['velocity'][1])
            
            # Combined criteria (use maximum of depth or velocity rating)
            combined_mask = depth_mask | velocity_mask
            hazard_rating[combined_mask] = np.maximum(
                hazard_rating[combined_mask], 
                criteria['rating']
            )
        
        return hazard_rating

    def generate_hazard_maps(self,
                           simulation_results: Dict[float, Dict],
                           output_dir: str) -> Dict[float, str]:
        """
        Generate hazard maps for multiple return periods
        
        Args:
            simulation_results: Dictionary with return period as key and simulation results
            output_dir: Output directory for hazard maps
            
        Returns:
            Dictionary mapping return periods to hazard map file paths
        """
        logger.info("Generating flood hazard maps")
        
        os.makedirs(output_dir, exist_ok=True)
        hazard_map_files = {}
        
        for return_period, results in simulation_results.items():
            try:
                # Extract simulation data
                depth_grid = results.get('max_depth', np.zeros((100, 100)))
                velocity_grid = results.get('max_velocity', np.zeros((100, 100)))
                duration_grid = results.get('duration', np.ones((100, 100)) * 6)  # Default 6 hours
                
                # Assess hazard
                hazard_metrics = self.assess_flood_hazard(
                    depth_grid, velocity_grid, duration_grid, return_period
                )
                
                # Create hazard map
                map_file = os.path.join(output_dir, f"hazard_map_{int(return_period)}yr.png")
                self._create_hazard_map_plot(hazard_metrics, map_file)
                
                hazard_map_files[return_period] = map_file
                
            except Exception as e:
                logger.error(f"Failed to generate hazard map for {return_period}-year return period: {e}")
        
        logger.info(f"Generated {len(hazard_map_files)} hazard maps")
        return hazard_map_files

    def _create_hazard_map_plot(self, metrics: FloodHazardMetrics, output_file: str):
        """Create hazard map visualization"""
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 12))
        
        # Depth map
        im1 = ax1.imshow(metrics.depth_max, cmap='Blues', origin='lower')
        ax1.set_title(f'Maximum Depth (m) - {metrics.return_period}-year')
        plt.colorbar(im1, ax=ax1)
        
        # Velocity map
        im2 = ax2.imshow(metrics.velocity_max, cmap='Reds', origin='lower')
        ax2.set_title(f'Maximum Velocity (m/s) - {metrics.return_period}-year')
        plt.colorbar(im2, ax=ax2)
        
        # Duration map
        im3 = ax3.imshow(metrics.duration, cmap='Greens', origin='lower')
        ax3.set_title(f'Flood Duration (hours) - {metrics.return_period}-year')
        plt.colorbar(im3, ax=ax3)
        
        # Hazard rating map
        im4 = ax4.imshow(metrics.hazard_rating, cmap='YlOrRd', origin='lower', vmin=1, vmax=4)
        ax4.set_title(f'Hazard Rating - {metrics.return_period}-year')
        cbar = plt.colorbar(im4, ax=ax4, ticks=[1, 2, 3, 4])
        cbar.ax.set_yticklabels(['Low', 'Moderate', 'Significant', 'High'])
        
        plt.tight_layout()
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
        plt.close()

    def calculate_annual_exceedance_probability(self, 
                                              depth_grids: Dict[float, np.ndarray]) -> np.ndarray:
        """
        Calculate annual exceedance probability for each grid cell
        
        Args:
            depth_grids: Dictionary mapping return periods to depth grids
            
        Returns:
            Annual exceedance probability grid
        """
        logger.info("Calculating annual exceedance probability")
        
        if not depth_grids:
            raise ValueError("No depth grids provided")
        
        # Get grid shape from first available grid
        grid_shape = next(iter(depth_grids.values())).shape
        aep_grid = np.zeros(grid_shape)
        
        # For each cell, calculate AEP based on depth-frequency relationship
        for i in range(grid_shape[0]):
            for j in range(grid_shape[1]):
                depths = []
                return_periods = []
                
                for rp, grid in depth_grids.items():
                    if grid[i, j] > 0:  # Only consider cells with flooding
                        depths.append(grid[i, j])
                        return_periods.append(rp)
                
                if len(depths) >= 2:
                    # Interpolate to find 1% AEP (100-year) depth
                    try:
                        interp_func = interp1d(return_periods, depths, 
                                             kind='linear', fill_value='extrapolate')
                        depth_100yr = interp_func(100)
                        aep_grid[i, j] = 0.01 if depth_100yr > 0 else 0
                    except:
                        aep_grid[i, j] = 0
        
        return aep_grid

class EconomicImpactAnalysis:
    """
    Comprehensive economic impact analysis and damage assessment
    """
    
    def __init__(self):
        """Initialize economic impact analysis module"""
        # Standard damage curves (depth vs % damage)
        self.damage_curves = {
            'residential': {
                'single_family': [(0, 0), (0.3, 10), (1.0, 25), (2.0, 50), (3.0, 75), (4.0, 90)],
                'multi_family': [(0, 0), (0.5, 15), (1.5, 35), (2.5, 60), (3.5, 80), (4.5, 95)],
                'mobile_home': [(0, 0), (0.2, 20), (0.8, 50), (1.5, 80), (2.0, 100)]
            },
            'commercial': {
                'retail': [(0, 0), (0.5, 20), (1.0, 40), (2.0, 65), (3.0, 85), (4.0, 95)],
                'office': [(0, 0), (0.3, 15), (1.0, 35), (2.0, 60), (3.0, 80), (4.0, 90)],
                'warehouse': [(0, 0), (1.0, 10), (2.0, 30), (3.0, 50), (4.0, 70), (5.0, 85)]
            },
            'industrial': {
                'manufacturing': [(0, 0), (0.5, 25), (1.5, 50), (2.5, 75), (3.5, 90), (4.5, 95)],
                'heavy_industry': [(0, 0), (1.0, 20), (2.0, 45), (3.0, 70), (4.0, 85), (5.0, 95)]
            },
            'infrastructure': {
                'roads': [(0, 0), (0.3, 5), (1.0, 15), (2.0, 35), (3.0, 60), (4.0, 80)],
                'utilities': [(0, 0), (0.5, 30), (1.0, 60), (2.0, 85), (3.0, 95), (4.0, 100)]
            }
        }
        
        # Standard unit values ($/m² or $/unit)
        self.unit_values = {
            'residential': {
                'single_family': 1500,  # $/m²
                'multi_family': 1200,
                'mobile_home': 800
            },
            'commercial': {
                'retail': 2000,
                'office': 2500,
                'warehouse': 800
            },
            'industrial': {
                'manufacturing': 1800,
                'heavy_industry': 2200
            },
            'infrastructure': {
                'roads': 500,  # $/m²
                'utilities': 5000  # $/m
            }
        }
        
        # Economic multipliers for indirect effects
        self.economic_multipliers = {
            'business_interruption': 0.3,  # 30% of direct damage
            'emergency_response': 0.1,     # 10% of direct damage
            'cleanup_costs': 0.15,         # 15% of direct damage
            'economic_disruption': 0.2     # 20% of direct damage
        }
        
        logger.info("Economic impact analysis module initialized")

    def assess_economic_damage(self,
                              depth_grid: np.ndarray,
                              land_use_grid: np.ndarray,
                              building_values: np.ndarray,
                              population_grid: np.ndarray,
                              cell_size: float = 1.0) -> EconomicDamageAssessment:
        """
        Assess economic damage from flood depth and land use data
        
        Args:
            depth_grid: Flood depth grid (m)
            land_use_grid: Land use classification grid
            building_values: Building value grid ($/m²)
            population_grid: Population density grid (people/cell)
            cell_size: Cell size in meters
            
        Returns:
            EconomicDamageAssessment object
        """
        logger.info("Assessing economic damage from flood impacts")
        
        # Calculate direct damages
        direct_damages = self._calculate_direct_damages(
            depth_grid, land_use_grid, building_values, cell_size
        )
        
        # Calculate indirect damages
        total_direct = sum(direct_damages.values())
        indirect_damages = self._calculate_indirect_damages(total_direct)
        
        # Calculate affected population
        affected_population = int(np.sum(population_grid[depth_grid > 0]))
        
        # Total damage
        total_damage = total_direct + sum(indirect_damages.values())
        
        # Damage per capita
        damage_per_capita = total_damage / max(affected_population, 1)
        
        # Estimate recovery time (days)
        recovery_time = self._estimate_recovery_time(depth_grid)
        
        assessment = EconomicDamageAssessment(
            direct_damages=direct_damages,
            indirect_damages=indirect_damages,
            total_damage=total_damage,
            affected_population=affected_population,
            damage_per_capita=damage_per_capita,
            recovery_time_days=recovery_time
        )
        
        logger.info(f"Economic assessment completed: ${total_damage:,.0f} total damage")
        return assessment

    def _calculate_direct_damages(self,
                                 depth_grid: np.ndarray,
                                 land_use_grid: np.ndarray,
                                 building_values: np.ndarray,
                                 cell_size: float) -> Dict[str, float]:
        """Calculate direct structural damages"""
        direct_damages = {}
        cell_area = cell_size * cell_size
        
        # Land use codes (example mapping)
        land_use_mapping = {
            1: ('residential', 'single_family'),
            2: ('residential', 'multi_family'),
            3: ('commercial', 'retail'),
            4: ('commercial', 'office'),
            5: ('industrial', 'manufacturing'),
            6: ('infrastructure', 'roads')
        }
        
        for land_use_code, (category, subcategory) in land_use_mapping.items():
            # Find cells with this land use
            mask = (land_use_grid == land_use_code) & (depth_grid > 0)
            
            if np.any(mask):
                # Get damage curve
                damage_curve = self.damage_curves.get(category, {}).get(subcategory, [])
                
                if damage_curve:
                    # Calculate damage percentage for each cell
                    depths = depth_grid[mask]
                    damage_percentages = self._interpolate_damage_curve(depths, damage_curve)
                    
                    # Calculate monetary damage
                    cell_values = building_values[mask] * cell_area
                    cell_damages = cell_values * damage_percentages / 100.0
                    
                    total_damage = np.sum(cell_damages)
                    direct_damages[f"{category}_{subcategory}"] = total_damage
        
        return direct_damages

    def _interpolate_damage_curve(self, depths: np.ndarray, damage_curve: List[Tuple]) -> np.ndarray:
        """Interpolate damage percentage from depth-damage curve"""
        if not damage_curve:
            return np.zeros_like(depths)
        
        curve_depths = [point[0] for point in damage_curve]
        curve_damages = [point[1] for point in damage_curve]
        
        # Interpolate damage percentages
        damage_percentages = np.interp(depths, curve_depths, curve_damages)
        
        return np.clip(damage_percentages, 0, 100)

    def _calculate_indirect_damages(self, total_direct_damage: float) -> Dict[str, float]:
        """Calculate indirect economic damages"""
        indirect_damages = {}
        
        for damage_type, multiplier in self.economic_multipliers.items():
            indirect_damages[damage_type] = total_direct_damage * multiplier
        
        return indirect_damages

    def _estimate_recovery_time(self, depth_grid: np.ndarray) -> int:
        """Estimate recovery time in days based on flood severity"""
        max_depth = np.max(depth_grid)
        mean_depth = np.mean(depth_grid[depth_grid > 0])
        
        # Base recovery time calculation
        if max_depth < 0.5:
            base_days = 7
        elif max_depth < 1.0:
            base_days = 21
        elif max_depth < 2.0:
            base_days = 60
        else:
            base_days = 180
        
        # Adjust for average depth
        depth_factor = 1 + (mean_depth / 2.0)
        
        return int(base_days * depth_factor)

    def generate_damage_report(self,
                              assessment: EconomicDamageAssessment,
                              output_file: str) -> str:
        """Generate comprehensive damage assessment report"""
        logger.info("Generating economic damage report")
        
        report_html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>FloodEngine Economic Impact Assessment</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 40px; }}
                .header {{ background: #1976d2; color: white; padding: 20px; border-radius: 5px; }}
                .section {{ margin: 20px 0; padding: 15px; background: #f5f5f5; border-radius: 5px; }}
                .damage-table {{ width: 100%; border-collapse: collapse; margin: 15px 0; }}
                .damage-table th, .damage-table td {{ padding: 10px; border: 1px solid #ddd; text-align: right; }}
                .damage-table th {{ background: #e3f2fd; }}
                .total-row {{ font-weight: bold; background: #fff3e0; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>Economic Impact Assessment Report</h1>
                <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            </div>
            
            <div class="section">
                <h2>Executive Summary</h2>
                <p><strong>Total Economic Impact:</strong> ${assessment.total_damage:,.0f}</p>
                <p><strong>Affected Population:</strong> {assessment.affected_population:,} people</p>
                <p><strong>Damage per Capita:</strong> ${assessment.damage_per_capita:,.0f}</p>
                <p><strong>Estimated Recovery Time:</strong> {assessment.recovery_time_days} days</p>
            </div>
            
            <div class="section">
                <h2>Direct Damages</h2>
                <table class="damage-table">
                    <tr><th>Category</th><th>Damage ($)</th><th>Percentage</th></tr>
        """
        
        total_direct = sum(assessment.direct_damages.values())
        for category, damage in assessment.direct_damages.items():
            percentage = (damage / total_direct * 100) if total_direct > 0 else 0
            report_html += f"""
                    <tr>
                        <td>{category.replace('_', ' ').title()}</td>
                        <td>${damage:,.0f}</td>
                        <td>{percentage:.1f}%</td>
                    </tr>
            """
        
        report_html += f"""
                    <tr class="total-row">
                        <td>Total Direct Damages</td>
                        <td>${total_direct:,.0f}</td>
                        <td>100.0%</td>
                    </tr>
                </table>
            </div>
            
            <div class="section">
                <h2>Indirect Damages</h2>
                <table class="damage-table">
                    <tr><th>Category</th><th>Damage ($)</th></tr>
        """
        
        for category, damage in assessment.indirect_damages.items():
            report_html += f"""
                    <tr>
                        <td>{category.replace('_', ' ').title()}</td>
                        <td>${damage:,.0f}</td>
                    </tr>
            """
        
        total_indirect = sum(assessment.indirect_damages.values())
        report_html += f"""
                    <tr class="total-row">
                        <td>Total Indirect Damages</td>
                        <td>${total_indirect:,.0f}</td>
                    </tr>
                </table>
            </div>
        </body>
        </html>
        """
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(report_html)
        
        logger.info(f"Economic damage report saved: {output_file}")
        return output_file

class UncertaintyQuantification:
    """
    Advanced uncertainty quantification and sensitivity analysis
    """
    
    def __init__(self):
        """Initialize uncertainty quantification module"""
        # Default parameter uncertainty ranges (relative to nominal values)
        self.parameter_uncertainties = {
            'manning_n': {'distribution': 'normal', 'std_ratio': 0.2},
            'dem_elevation': {'distribution': 'normal', 'std_ratio': 0.05},
            'rainfall_intensity': {'distribution': 'lognormal', 'std_ratio': 0.3},
            'initial_conditions': {'distribution': 'uniform', 'range_ratio': 0.1},
            'boundary_conditions': {'distribution': 'normal', 'std_ratio': 0.15}
        }
        
        logger.info("Uncertainty quantification module initialized")

    def monte_carlo_analysis(self,
                           simulation_function: callable,
                           parameters: Dict[str, float],
                           n_samples: int = 1000,
                           output_metrics: List[str] = None) -> UncertaintyAnalysis:
        """
        Perform Monte Carlo uncertainty analysis
        
        Args:
            simulation_function: Function that runs flood simulation
            parameters: Nominal parameter values
            n_samples: Number of Monte Carlo samples
            output_metrics: List of output metrics to analyze
            
        Returns:
            UncertaintyAnalysis object with results
        """
        logger.info(f"Starting Monte Carlo analysis with {n_samples} samples")
        
        if output_metrics is None:
            output_metrics = ['max_depth', 'total_volume', 'peak_discharge']
        
        # Generate parameter samples
        parameter_samples = self._generate_parameter_samples(parameters, n_samples)
        
        # Run simulations
        results = []
        for i, sample_params in enumerate(parameter_samples):
            try:
                # Run simulation with sampled parameters
                result = simulation_function(sample_params)
                
                # Extract output metrics
                sample_result = {}
                for metric in output_metrics:
                    if metric in result:
                        if isinstance(result[metric], np.ndarray):
                            sample_result[metric] = np.mean(result[metric])
                        else:
                            sample_result[metric] = result[metric]
                    else:
                        sample_result[metric] = 0.0
                
                results.append(sample_result)
                
                if (i + 1) % 100 == 0:
                    logger.info(f"Completed {i + 1}/{n_samples} simulations")
                    
            except Exception as e:
                logger.warning(f"Simulation {i + 1} failed: {e}")
                # Use zero values for failed simulations
                sample_result = {metric: 0.0 for metric in output_metrics}
                results.append(sample_result)
        
        # Convert to numpy array for analysis
        results_array = np.array([[r[metric] for metric in output_metrics] for r in results])
        
        # Perform sensitivity analysis
        sensitivity = self._sensitivity_analysis(parameter_samples, results_array, output_metrics)
        
        # Calculate confidence intervals
        confidence_intervals = self._calculate_confidence_intervals(results_array, output_metrics)
        
        # Identify uncertainty sources
        uncertainty_sources = self._identify_uncertainty_sources(sensitivity)
        
        # Calculate total uncertainty
        total_uncertainty = self._calculate_total_uncertainty(results_array)
        
        analysis = UncertaintyAnalysis(
            parameter_sensitivity=sensitivity,
            confidence_intervals=confidence_intervals,
            monte_carlo_results=results_array,
            uncertainty_sources=uncertainty_sources,
            total_uncertainty=total_uncertainty
        )
        
        logger.info("Monte Carlo analysis completed")
        return analysis

    def _generate_parameter_samples(self,
                                   parameters: Dict[str, float],
                                   n_samples: int) -> List[Dict[str, float]]:
        """Generate parameter samples for Monte Carlo analysis"""
        samples = []
        
        for _ in range(n_samples):
            sample = {}
            
            for param_name, nominal_value in parameters.items():
                if param_name in self.parameter_uncertainties:
                    uncertainty = self.parameter_uncertainties[param_name]
                    
                    if uncertainty['distribution'] == 'normal':
                        std = nominal_value * uncertainty['std_ratio']
                        sample[param_name] = np.random.normal(nominal_value, std)
                        
                    elif uncertainty['distribution'] == 'lognormal':
                        std = nominal_value * uncertainty['std_ratio']
                        mu = np.log(nominal_value / np.sqrt(1 + (std/nominal_value)**2))
                        sigma = np.sqrt(np.log(1 + (std/nominal_value)**2))
                        sample[param_name] = np.random.lognormal(mu, sigma)
                        
                    elif uncertainty['distribution'] == 'uniform':
                        range_val = nominal_value * uncertainty['range_ratio']
                        sample[param_name] = np.random.uniform(
                            nominal_value - range_val,
                            nominal_value + range_val
                        )
                        
                    else:
                        sample[param_name] = nominal_value
                else:
                    sample[param_name] = nominal_value
            
            samples.append(sample)
        
        return samples

    def _sensitivity_analysis(self,
                            parameter_samples: List[Dict[str, float]],
                            results_array: np.ndarray,
                            output_metrics: List[str]) -> Dict[str, float]:
        """Perform sensitivity analysis using correlation coefficients"""
        sensitivity = {}
        
        # Convert parameter samples to array
        param_names = list(parameter_samples[0].keys())
        param_array = np.array([[sample[name] for name in param_names] for sample in parameter_samples])
        
        # Calculate correlation for each parameter-output combination
        for i, param_name in enumerate(param_names):
            param_values = param_array[:, i]
            
            # Calculate average sensitivity across all output metrics
            correlations = []
            for j, metric in enumerate(output_metrics):
                output_values = results_array[:, j]
                
                # Remove zero outputs for correlation calculation
                valid_mask = output_values > 0
                if np.sum(valid_mask) > 10:  # Need sufficient data
                    corr = np.corrcoef(param_values[valid_mask], output_values[valid_mask])[0, 1]
                    if not np.isnan(corr):
                        correlations.append(abs(corr))
            
            # Average absolute correlation as sensitivity measure
            if correlations:
                sensitivity[param_name] = np.mean(correlations)
            else:
                sensitivity[param_name] = 0.0
        
        return sensitivity

    def _calculate_confidence_intervals(self,
                                      results_array: np.ndarray,
                                      output_metrics: List[str],
                                      confidence_level: float = 0.95) -> Dict[str, Tuple[float, float]]:
        """Calculate confidence intervals for output metrics"""
        confidence_intervals = {}
        alpha = 1 - confidence_level
        
        for i, metric in enumerate(output_metrics):
            values = results_array[:, i]
            valid_values = values[values > 0]  # Remove zero values
            
            if len(valid_values) > 0:
                lower = np.percentile(valid_values, 100 * alpha / 2)
                upper = np.percentile(valid_values, 100 * (1 - alpha / 2))
                confidence_intervals[metric] = (lower, upper)
            else:
                confidence_intervals[metric] = (0.0, 0.0)
        
        return confidence_intervals

    def _identify_uncertainty_sources(self, sensitivity: Dict[str, float]) -> List[str]:
        """Identify major uncertainty sources"""
        # Sort by sensitivity (highest to lowest)
        sorted_params = sorted(sensitivity.items(), key=lambda x: x[1], reverse=True)
        
        # Consider parameters with sensitivity > 0.3 as major sources
        major_sources = [param for param, sens in sorted_params if sens > 0.3]
        
        return major_sources

    def _calculate_total_uncertainty(self, results_array: np.ndarray) -> float:
        """Calculate overall uncertainty measure"""
        # Use coefficient of variation as uncertainty measure
        mean_values = np.mean(results_array, axis=0)
        std_values = np.std(results_array, axis=0)
        
        # Average coefficient of variation across all metrics
        cv_values = []
        for i in range(len(mean_values)):
            if mean_values[i] > 0:
                cv = std_values[i] / mean_values[i]
                cv_values.append(cv)
        
        return np.mean(cv_values) if cv_values else 0.0

    def generate_uncertainty_report(self,
                                  analysis: UncertaintyAnalysis,
                                  output_file: str) -> str:
        """Generate uncertainty analysis report"""
        logger.info("Generating uncertainty analysis report")
        
        # Create visualizations
        self._create_uncertainty_plots(analysis, output_file.replace('.html', '_plots.png'))
        
        report_html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>FloodEngine Uncertainty Analysis Report</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 40px; }}
                .header {{ background: #7b1fa2; color: white; padding: 20px; border-radius: 5px; }}
                .section {{ margin: 20px 0; padding: 15px; background: #f5f5f5; border-radius: 5px; }}
                .results-table {{ width: 100%; border-collapse: collapse; margin: 15px 0; }}
                .results-table th, .results-table td {{ padding: 10px; border: 1px solid #ddd; }}
                .results-table th {{ background: #e1bee7; }}
                img {{ max-width: 100%; height: auto; margin: 15px 0; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>Uncertainty Analysis Report</h1>
                <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            </div>
            
            <div class="section">
                <h2>Summary</h2>
                <p><strong>Total Uncertainty:</strong> {analysis.total_uncertainty:.3f}</p>
                <p><strong>Major Uncertainty Sources:</strong> {', '.join(analysis.uncertainty_sources)}</p>
                <p><strong>Monte Carlo Samples:</strong> {len(analysis.monte_carlo_results)}</p>
            </div>
            
            <div class="section">
                <h2>Parameter Sensitivity</h2>
                <table class="results-table">
                    <tr><th>Parameter</th><th>Sensitivity</th><th>Importance</th></tr>
        """
        
        # Sort sensitivity by value
        sorted_sensitivity = sorted(analysis.parameter_sensitivity.items(), 
                                  key=lambda x: x[1], reverse=True)
        
        for param, sensitivity in sorted_sensitivity:
            importance = "High" if sensitivity > 0.5 else "Medium" if sensitivity > 0.3 else "Low"
            report_html += f"""
                    <tr>
                        <td>{param.replace('_', ' ').title()}</td>
                        <td>{sensitivity:.3f}</td>
                        <td>{importance}</td>
                    </tr>
            """
        
        report_html += f"""
                </table>
            </div>
            
            <div class="section">
                <h2>Confidence Intervals (95%)</h2>
                <table class="results-table">
                    <tr><th>Metric</th><th>Lower Bound</th><th>Upper Bound</th><th>Range</th></tr>
        """
        
        for metric, (lower, upper) in analysis.confidence_intervals.items():
            range_val = upper - lower
            report_html += f"""
                    <tr>
                        <td>{metric.replace('_', ' ').title()}</td>
                        <td>{lower:.3f}</td>
                        <td>{upper:.3f}</td>
                        <td>{range_val:.3f}</td>
                    </tr>
            """
        
        plot_file = output_file.replace('.html', '_plots.png')
        report_html += f"""
                </table>
            </div>
            
            <div class="section">
                <h2>Visualization</h2>
                <img src="{os.path.basename(plot_file)}" alt="Uncertainty Analysis Plots">
            </div>
        </body>
        </html>
        """
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(report_html)
        
        logger.info(f"Uncertainty analysis report saved: {output_file}")
        return output_file

    def _create_uncertainty_plots(self, analysis: UncertaintyAnalysis, output_file: str):
        """Create uncertainty analysis visualization plots"""
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 12))
        
        # Parameter sensitivity bar plot
        params = list(analysis.parameter_sensitivity.keys())
        sensitivities = list(analysis.parameter_sensitivity.values())
        
        ax1.barh(params, sensitivities, color='steelblue')
        ax1.set_xlabel('Sensitivity')
        ax1.set_title('Parameter Sensitivity Analysis')
        ax1.grid(True, alpha=0.3)
        
        # Monte Carlo results histogram (first metric)
        if analysis.monte_carlo_results.shape[1] > 0:
            values = analysis.monte_carlo_results[:, 0]
            values = values[values > 0]  # Remove zeros
            if len(values) > 0:
                ax2.hist(values, bins=30, alpha=0.7, color='green')
                ax2.set_xlabel('Value')
                ax2.set_ylabel('Frequency')
                ax2.set_title('Monte Carlo Results Distribution')
                ax2.grid(True, alpha=0.3)
        
        # Confidence intervals
        metrics = list(analysis.confidence_intervals.keys())
        lower_bounds = [ci[0] for ci in analysis.confidence_intervals.values()]
        upper_bounds = [ci[1] for ci in analysis.confidence_intervals.values()]
        ranges = [ub - lb for lb, ub in zip(lower_bounds, upper_bounds)]
        
        x_pos = np.arange(len(metrics))
        ax3.bar(x_pos, ranges, color='orange', alpha=0.7)
        ax3.set_xlabel('Metrics')
        ax3.set_ylabel('Confidence Interval Range')
        ax3.set_title('95% Confidence Interval Ranges')
        ax3.set_xticks(x_pos)
        ax3.set_xticklabels([m.replace('_', '\n') for m in metrics], rotation=45)
        ax3.grid(True, alpha=0.3)
        
        # Uncertainty sources pie chart
        if analysis.uncertainty_sources:
            source_sensitivities = [analysis.parameter_sensitivity.get(source, 0) 
                                  for source in analysis.uncertainty_sources]
            ax4.pie(source_sensitivities, labels=analysis.uncertainty_sources, autopct='%1.1f%%')
            ax4.set_title('Major Uncertainty Sources')
        else:
            ax4.text(0.5, 0.5, 'No major uncertainty\nsources identified', 
                    ha='center', va='center', transform=ax4.transAxes)
            ax4.set_title('Uncertainty Sources')
        
        plt.tight_layout()
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
        plt.close()

class MultiScenarioAnalysis:
    """
    Multi-scenario comparison and statistical analysis
    """
    
    def __init__(self):
        """Initialize multi-scenario analysis module"""
        self.scenarios = {}
        self.comparison_metrics = [
            'max_depth', 'mean_depth', 'flooded_area', 
            'peak_discharge', 'total_volume', 'economic_damage'
        ]
        logger.info("Multi-scenario analysis module initialized")

    def add_scenario(self, scenario_name: str, results: Dict[str, Any]):
        """Add scenario results for comparison"""
        self.scenarios[scenario_name] = results
        logger.info(f"Added scenario: {scenario_name}")

    def compare_scenarios(self) -> Dict[str, Any]:
        """Compare all scenarios and generate statistical analysis"""
        if len(self.scenarios) < 2:
            raise ValueError("At least 2 scenarios required for comparison")
        
        logger.info(f"Comparing {len(self.scenarios)} scenarios")
        
        comparison_results = {
            'scenario_summary': {},
            'statistical_comparison': {},
            'ranking': {},
            'correlation_analysis': {}
        }
        
        # Extract metrics for all scenarios
        scenario_metrics = {}
        for scenario_name, results in self.scenarios.items():
            metrics = {}
            for metric in self.comparison_metrics:
                if metric in results:
                    value = results[metric]
                    if isinstance(value, np.ndarray):
                        metrics[metric] = {
                            'mean': float(np.mean(value)),
                            'max': float(np.max(value)),
                            'min': float(np.min(value)),
                            'std': float(np.std(value))
                        }
                    else:
                        metrics[metric] = {'value': float(value)}
                else:
                    metrics[metric] = {'value': 0.0}
            
            scenario_metrics[scenario_name] = metrics
            comparison_results['scenario_summary'][scenario_name] = metrics
        
        # Statistical comparison
        comparison_results['statistical_comparison'] = self._statistical_comparison(scenario_metrics)
        
        # Ranking analysis
        comparison_results['ranking'] = self._rank_scenarios(scenario_metrics)
        
        # Correlation analysis
        comparison_results['correlation_analysis'] = self._correlation_analysis(scenario_metrics)
        
        return comparison_results

    def _statistical_comparison(self, scenario_metrics: Dict) -> Dict:
        """Perform statistical comparison between scenarios"""
        statistical_results = {}
        
        for metric in self.comparison_metrics:
            values = []
            scenario_names = []
            
            for scenario_name, metrics in scenario_metrics.items():
                if metric in metrics:
                    if 'mean' in metrics[metric]:
                        values.append(metrics[metric]['mean'])
                    else:
                        values.append(metrics[metric]['value'])
                    scenario_names.append(scenario_name)
            
            if len(values) > 1:
                statistical_results[metric] = {
                    'mean': np.mean(values),
                    'std': np.std(values),
                    'min': np.min(values),
                    'max': np.max(values),
                    'coefficient_of_variation': np.std(values) / np.mean(values) if np.mean(values) > 0 else 0,
                    'scenarios': dict(zip(scenario_names, values))
                }
        
        return statistical_results

    def _rank_scenarios(self, scenario_metrics: Dict) -> Dict:
        """Rank scenarios by different metrics"""
        rankings = {}
        
        for metric in self.comparison_metrics:
            scenario_values = []
            
            for scenario_name, metrics in scenario_metrics.items():
                if metric in metrics:
                    if 'mean' in metrics[metric]:
                        value = metrics[metric]['mean']
                    else:
                        value = metrics[metric]['value']
                    scenario_values.append((scenario_name, value))
            
            if scenario_values:
                # Sort by value (descending for most metrics)
                reverse_sort = metric not in ['economic_damage']  # Damage should be ascending
                scenario_values.sort(key=lambda x: x[1], reverse=reverse_sort)
                
                rankings[metric] = [
                    {'rank': i+1, 'scenario': name, 'value': value}
                    for i, (name, value) in enumerate(scenario_values)
                ]
        
        return rankings

    def _correlation_analysis(self, scenario_metrics: Dict) -> Dict:
        """Analyze correlations between different metrics"""
        # Create data matrix
        data_matrix = []
        metric_names = []
        
        for metric in self.comparison_metrics:
            values = []
            for scenario_name, metrics in scenario_metrics.items():
                if metric in metrics:
                    if 'mean' in metrics[metric]:
                        values.append(metrics[metric]['mean'])
                    else:
                        values.append(metrics[metric]['value'])
                else:
                    values.append(0.0)
            
            if any(v > 0 for v in values):  # Only include metrics with non-zero values
                data_matrix.append(values)
                metric_names.append(metric)
        
        if len(data_matrix) > 1:
            # Calculate correlation matrix
            correlation_matrix = np.corrcoef(data_matrix)
            
            # Convert to dictionary format
            correlations = {}
            for i, metric1 in enumerate(metric_names):
                correlations[metric1] = {}
                for j, metric2 in enumerate(metric_names):
                    correlations[metric1][metric2] = float(correlation_matrix[i, j])
            
            return {
                'correlation_matrix': correlations,
                'strong_correlations': self._find_strong_correlations(correlations)
            }
        
        return {}

    def _find_strong_correlations(self, correlations: Dict, threshold: float = 0.7) -> List[Dict]:
        """Find strong correlations between metrics"""
        strong_correlations = []
        
        metrics = list(correlations.keys())
        for i, metric1 in enumerate(metrics):
            for j, metric2 in enumerate(metrics[i+1:], i+1):
                corr_value = correlations[metric1][metric2]
                if abs(corr_value) > threshold:
                    strong_correlations.append({
                        'metric1': metric1,
                        'metric2': metric2,
                        'correlation': corr_value,
                        'strength': 'strong' if abs(corr_value) > 0.8 else 'moderate'
                    })
        
        return strong_correlations

def main():
    """Main function for testing advanced analysis tools"""
    print("FloodEngine v4.0 - Advanced Analysis Tools")
    print("=" * 60)
    
    # Create test data
    grid_size = (100, 100)
    depth_grid = np.random.rand(*grid_size) * 3.0
    velocity_grid = np.random.rand(*grid_size) * 2.0
    duration_grid = np.ones(grid_size) * 6.0
    
    # Test flood risk assessment
    print("\n1. Testing Flood Risk Assessment...")
    risk_assessment = FloodRiskAssessment()
    hazard_metrics = risk_assessment.assess_flood_hazard(
        depth_grid, velocity_grid, duration_grid, return_period=100
    )
    print(f"   Hazard assessment completed for 100-year return period")
    print(f"   Max hazard rating: {np.max(hazard_metrics.hazard_rating):.1f}")
    
    # Test economic impact analysis
    print("\n2. Testing Economic Impact Analysis...")
    economic_analysis = EconomicImpactAnalysis()
    
    # Create test land use and building value grids
    land_use_grid = np.random.randint(1, 7, grid_size)
    building_values = np.random.uniform(1000, 3000, grid_size)
    population_grid = np.random.randint(0, 100, grid_size)
    
    damage_assessment = economic_analysis.assess_economic_damage(
        depth_grid, land_use_grid, building_values, population_grid
    )
    print(f"   Economic assessment completed")
    print(f"   Total damage: ${damage_assessment.total_damage:,.0f}")
    print(f"   Affected population: {damage_assessment.affected_population}")
    
    # Test uncertainty quantification
    print("\n3. Testing Uncertainty Quantification...")
    uncertainty_analysis = UncertaintyQuantification()
    
    # Mock simulation function
    def mock_simulation(params):
        return {
            'max_depth': np.random.rand() * params.get('rainfall_intensity', 1.0),
            'total_volume': np.random.rand() * 1000,
            'peak_discharge': np.random.rand() * 100
        }
    
    # Small sample for testing
    test_params = {
        'manning_n': 0.03,
        'rainfall_intensity': 50.0,
        'dem_elevation': 100.0
    }
    
    uncertainty_results = uncertainty_analysis.monte_carlo_analysis(
        mock_simulation, test_params, n_samples=50
    )
    print(f"   Uncertainty analysis completed")
    print(f"   Total uncertainty: {uncertainty_results.total_uncertainty:.3f}")
    print(f"   Major sources: {uncertainty_results.uncertainty_sources}")
    
    # Test multi-scenario analysis
    print("\n4. Testing Multi-Scenario Analysis...")
    scenario_analysis = MultiScenarioAnalysis()
    
    # Add test scenarios
    scenario_analysis.add_scenario("Low Intensity", {
        'max_depth': np.random.rand(50, 50) * 1.0,
        'economic_damage': 500000,
        'flooded_area': 1000
    })
    
    scenario_analysis.add_scenario("High Intensity", {
        'max_depth': np.random.rand(50, 50) * 3.0,
        'economic_damage': 2000000,
        'flooded_area': 5000
    })
    
    comparison_results = scenario_analysis.compare_scenarios()
    print(f"   Scenario comparison completed")
    print(f"   Scenarios analyzed: {len(scenario_analysis.scenarios)}")
    
    print("\n✅ All advanced analysis tools tested successfully!")

if __name__ == "__main__":
    main()
