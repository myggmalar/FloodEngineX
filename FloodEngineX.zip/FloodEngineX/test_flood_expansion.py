#!/usr/bin/env python3
"""
Test script to verify improved flood expansion at different water levels
"""

import os
import sys
import numpy as np
from osgeo import gdal

# Add plugin directory to path
plugin_dir = r"c:\Plugin\VSCode\Alt2\FloodEngine_fixed_v8"
if plugin_dir not in sys.path:
    sys.path.insert(0, plugin_dir)

def test_flood_expansion():
    """Test that flood area increases significantly with higher water levels"""
    
    print("🧪 TESTING IMPROVED FLOOD EXPANSION")
    print("=" * 50)
    
    # Import the improved flood function
    try:
        from model_hydraulic import create_proper_flow_flood_mask
        print("✅ Successfully imported improved flood function")
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False
    
    # Create test DEM with channel and floodplains
    print("\n1. Creating test terrain with channel and floodplains...")
    
    width, height = 200, 200
    dem_array = np.zeros((height, width), dtype=np.float32)
    
    # Create realistic terrain with river channel and floodplains
    center_y = height // 2
    for y in range(height):
        for x in range(width):
            # Base terrain elevation
            base_elevation = 10.0
            
            # Distance from river center
            dist_from_river = abs(y - center_y)
            
            # Create main river channel (deep)
            if dist_from_river < 3:  # 6-pixel wide main channel
                channel_depth = 3.0 - dist_from_river * 0.5
                dem_array[y, x] = base_elevation - channel_depth
            
            # Create immediate floodplain (slightly elevated)
            elif dist_from_river < 15:  # 30-pixel wide floodplain
                floodplain_height = 0.5 + (dist_from_river - 3) * 0.1
                dem_array[y, x] = base_elevation + floodplain_height
            
            # Create higher terrain (hills)
            else:
                hill_height = 2.0 + (dist_from_river - 15) * 0.05
                dem_array[y, x] = base_elevation + hill_height
    
    # Add some random variation
    np.random.seed(42)
    dem_array += np.random.normal(0, 0.05, dem_array.shape)
    
    # Valid mask (all valid)
    valid_mask = np.ones_like(dem_array, dtype=bool)
    
    # Test different water levels
    test_levels = [8.5, 10.5, 12.0, 14.0, 16.0]  # From low to very high
    
    print(f"\n2. Testing flood expansion at different water levels...")
    print(f"   Terrain: Channel ~7-8m, Floodplain ~10-12m, Hills >12m")
    
    results = []
    
    for water_level in test_levels:
        print(f"\n   Testing water level: {water_level:.1f}m")
        
        flood_mask = create_proper_flow_flood_mask(dem_array, water_level, valid_mask, None)
        
        flooded_cells = np.sum(flood_mask)
        total_cells = width * height
        flood_percentage = (flooded_cells / total_cells) * 100
        
        if flooded_cells > 0:
            flooded_elevations = dem_array[flood_mask == 1]
            min_elev = np.min(flooded_elevations)
            max_elev = np.max(flooded_elevations)
            avg_elev = np.mean(flooded_elevations)
            elevation_range = max_elev - min_elev
            
            result = {
                'water_level': water_level,
                'flooded_cells': flooded_cells,
                'flood_percentage': flood_percentage,
                'min_elev': min_elev,
                'max_elev': max_elev,
                'avg_elev': avg_elev,
                'elevation_range': elevation_range
            }
            results.append(result)
            
            print(f"      Flooded: {flooded_cells} cells ({flood_percentage:.1f}%)")
            print(f"      Elevations: {min_elev:.2f}m to {max_elev:.2f}m (range: {elevation_range:.2f}m)")
        else:
            print(f"      No flooding occurred")
            results.append({
                'water_level': water_level,
                'flooded_cells': 0,
                'flood_percentage': 0
            })
    
    # Analyze expansion behavior
    print(f"\n3. ANALYZING FLOOD EXPANSION BEHAVIOR:")
    print(f"{'Water Level':<12} {'Cells':<8} {'Area %':<8} {'Elev Range':<12} {'Expected'}")
    print(f"-" * 60)
    
    expected_behaviors = [
        "Channel only",
        "Channel + banks", 
        "Into floodplain",
        "Full floodplain",
        "Beyond floodplain"
    ]
    
    expansion_success = True
    previous_cells = 0
    
    for i, result in enumerate(results):
        if result['flooded_cells'] > 0:
            elev_range = result.get('elevation_range', 0)
            print(f"{result['water_level']:<12.1f} {result['flooded_cells']:<8} "
                  f"{result['flood_percentage']:<8.1f} {elev_range:<12.2f} {expected_behaviors[i]}")
            
            # Check if flooding expanded appropriately
            if result['flooded_cells'] > previous_cells:
                print(f"    ✅ Expansion: +{result['flooded_cells'] - previous_cells} cells")
            elif i > 0:  # Should expand unless water level is too low
                print(f"    ⚠️ No expansion from previous level")
                if result['water_level'] > 10.0:  # Should definitely expand above base level
                    expansion_success = False
            
            previous_cells = result['flooded_cells']
        else:
            print(f"{result['water_level']:<12.1f} {'0':<8} {'0.0':<8} {'0.00':<12} {expected_behaviors[i]}")
    
    # Overall assessment
    print(f"\n4. FLOOD EXPANSION ASSESSMENT:")
    
    if len(results) >= 3 and results[-1]['flooded_cells'] > results[0]['flooded_cells'] * 2:
        print(f"✅ EXCELLENT: High water levels flood much larger areas")
        print(f"   {results[0]['flooded_cells']} → {results[-1]['flooded_cells']} cells")
        print(f"   {results[-1]['flooded_cells'] / results[0]['flooded_cells']:.1f}x expansion")
    elif expansion_success and results[-1]['flooded_cells'] > results[0]['flooded_cells']:
        print(f"✅ GOOD: Flood area increases with water level")
        print(f"   {results[0]['flooded_cells']} → {results[-1]['flooded_cells']} cells")
    else:
        print(f"❌ POOR: Limited expansion with higher water levels")
        print(f"   This suggests the algorithm is still too restrictive")
        return False
    
    # Check elevation range expansion
    high_water_result = results[-1]
    if high_water_result.get('elevation_range', 0) > 3.0:
        print(f"✅ GOOD VERTICAL EXPANSION: {high_water_result['elevation_range']:.2f}m elevation range flooded")
    elif high_water_result.get('elevation_range', 0) > 1.0:
        print(f"⚠️ MODERATE EXPANSION: {high_water_result['elevation_range']:.2f}m elevation range")
    else:
        print(f"❌ LIMITED EXPANSION: Only {high_water_result.get('elevation_range', 0):.2f}m range")
    
    print(f"\n🎉 FLOOD EXPANSION TEST COMPLETED!")
    return True

if __name__ == "__main__":
    success = test_flood_expansion()
    
    if success:
        print(f"\n✅ IMPROVED ALGORITHM IS WORKING!")
        print(f"   - Higher water levels now flood larger areas")
        print(f"   - Dynamic uphill flow allows floodplain access")
        print(f"   - Different timesteps should show different flood extents")
        print(f"\n💡 Test with your real DEM - you should see:")
        print(f"   - Small floods confined to channels")
        print(f"   - Large floods expanding to floodplains")
        print(f"   - Realistic progression with water level")
    else:
        print(f"\n⚠️ Algorithm may need further adjustment")
        print(f"   - Check if terrain has appropriate floodplains")
        print(f"   - Consider if water levels are realistic")
        print(f"   - May need to adjust uphill flow parameters")
