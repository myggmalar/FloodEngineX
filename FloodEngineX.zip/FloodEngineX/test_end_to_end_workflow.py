#!/usr/bin/env python3
"""
End-to-end test simulating the complete workflow:
UI checkbox -> Model run -> Animation file creation -> Animation launch
"""

import sys
import os
import tempfile
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_complete_workflow():
    """Test the complete workflow end-to-end."""
    print("🔄 Testing COMPLETE animation workflow...")
    
    # Step 1: Simulate UI checkbox check
    print("\n📋 Step 1: Simulating UI checkbox state...")
    create_animation = True  # This is what should be passed from UI
    print(f"🎬 Animation enabled from UI: {create_animation}")
    
    # Step 2: Simulate simulation results (what Saint-Venant produces)
    print("\n📊 Step 2: Simulating Saint-Venant simulation results...")
    temp_dir = tempfile.mkdtemp()
    output_folder = os.path.join(temp_dir, "test_simulation_output")
    os.makedirs(output_folder, exist_ok=True)
    
    # Create mock results (what Saint-Venant should produce)
    results = create_mock_simulation_results()
    print(f"✅ Mock simulation completed with {len(results['times'])} timesteps")
    
    # Step 3: Test animation file creation (what Saint-Venant should do if create_animation=True)
    print(f"\n🎬 Step 3: Testing animation file creation (create_animation={create_animation})...")
    
    if create_animation:
        try:
            from time_series_integration import integrate_time_series_animation
            
            animation_folder = os.path.join(output_folder, 'time_series_animation')
            print(f"📁 Creating animation files in: {animation_folder}")
            
            animation_result = integrate_time_series_animation(results, animation_folder)
            
            if animation_result['success']:
                print("✅ Animation files created successfully!")
                print(f"📁 Animation folder: {animation_folder}")
                
                # List files created
                if os.path.exists(animation_folder):
                    files = os.listdir(animation_folder)
                    print(f"📄 Files created: {files}")
                
                # Store animation folder path (what Saint-Venant should do)
                results['animation_folder'] = animation_folder
                
            else:
                print(f"❌ Animation file creation failed: {animation_result.get('error')}")
                return False
                
        except Exception as e:
            print(f"❌ Animation integration failed: {e}")
            return False
    else:
        print("ℹ️ Animation disabled - skipping file creation")
    
    # Step 4: Simulate UI animation launch (what UI should do after simulation)
    print(f"\n🚀 Step 4: Testing UI animation launch...")
    
    if create_animation:
        try:
            # This is the exact logic from floodengine_ui.launch_animation_controls
            from launch_animation import launch_animation_from_folder
            
            # Check for animation folder (UI logic)
            animation_folder_detected = None
            if os.path.exists(os.path.join(output_folder, 'time_series_animation')):
                animation_folder_detected = os.path.join(output_folder, 'time_series_animation')
                print(f"✅ UI detected animation folder: {animation_folder_detected}")
            elif os.path.exists(os.path.join(output_folder, 'rasters')):
                animation_folder_detected = output_folder
                print(f"✅ UI detected raster folder: {animation_folder_detected}")
            else:
                print("❌ UI could not detect animation data")
                return False
            
            # Launch animation (UI logic)
            print("🎬 UI launching animation...")
            result = launch_animation_from_folder(animation_folder_detected, standalone=True)
            
            if result:
                print("✅ UI ANIMATION LAUNCH SUCCEEDED!")
                print("🎮 Animation dialog should be visible!")
                return True
            else:
                print("❌ UI animation launch failed")
                return False
                
        except Exception as e:
            print(f"❌ UI animation launch error: {e}")
            import traceback
            traceback.print_exc()
            return False
    else:
        print("ℹ️ Animation disabled - UI skipping launch")
        return True
    
    return False

def create_mock_simulation_results():
    """Create mock simulation results similar to Saint-Venant output."""
    nx, ny = 15, 15
    times = [0.0, 5.0, 10.0, 15.0, 20.0]  # 5 timesteps
    
    results = {
        'times': times,
        'water_depths': [],
        'velocity_x': [],
        'velocity_y': [],
        'dem_array': np.random.rand(nx, ny) * 5 + 10,  # DEM from 10-15m
        'geotransform': (0, 10, 0, ny*10, 0, -10),  # 10m resolution
        'projection': 'GEOGCS["WGS 84",DATUM["WGS_1984",SPHEROID["WGS 84",6378137,298.257223563]]]'
    }
    
    # Create realistic flood progression
    center_x, center_y = nx//2, ny//2
    
    for i, t in enumerate(times):
        # Expanding flood pattern
        depth = np.zeros((nx, ny))
        vel_x = np.zeros((nx, ny))
        vel_y = np.zeros((nx, ny))
        
        radius = 2 + t * 0.1  # Expanding flood
        
        for x in range(nx):
            for y in range(ny):
                dist = np.sqrt((x - center_x)**2 + (y - center_y)**2)
                if dist <= radius:
                    # Water depth decreases with distance
                    depth[x, y] = max(0, 2.0 * np.exp(-dist/3))
                    # Simple radial velocity
                    if dist > 0.1:
                        vel_x[x, y] = 0.1 * (x - center_x) / dist
                        vel_y[x, y] = 0.1 * (y - center_y) / dist
        
        results['water_depths'].append(depth)
        results['velocity_x'].append(vel_x)
        results['velocity_y'].append(vel_y)
    
    return results

if __name__ == "__main__":
    try:
        success = test_complete_workflow()
        print(f"\n{'✅ COMPLETE WORKFLOW TEST PASSED' if success else '❌ COMPLETE WORKFLOW TEST FAILED'}")
        
        if success:
            print("\n🎉 EXCELLENT! The complete animation workflow is working!")
            print("🔍 If animation still doesn't appear after real simulation:")
            print("   1. Check console output for debug messages")
            print("   2. Verify checkbox is checked in Advanced mode") 
            print("   3. Check if animation files are actually created")
            print("   4. Verify output folder path is correct")
        else:
            print("\n❌ The workflow has issues that need to be fixed")
            
    except KeyboardInterrupt:
        print("\n⏹️ Test interrupted by user")
    except Exception as e:
        print(f"\n❌ Test failed with exception: {e}")
        import traceback
        traceback.print_exc()
