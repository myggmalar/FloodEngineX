import os
import numpy as np
from qgis.core import QgsProject, QgsVectorLayer
from PyQt5.QtGui import QColor
from osgeo import gdal, ogr, osr

def calculate_flood_area(
    iface,
    dem_path,
    water_levels=None,
    output_folder=None,
    flow_q=None,
    manning_n=None,
    bathymetry_path=None,
    bathymetry_columns=None,
    duration_hours=24,
    timestep_minutes=60,
    **kwargs
):
    """
    Calculate flood area using 2D Saint-Venant equations with dynamic simulation.
    """
    print(f"🌊 Starting FloodEngine simulation...")
    print(f"📍 DEM: {dem_path}")
    print(f"⏱️ Duration: {duration_hours} hours")
    print(f"🔄 Timestep: {timestep_minutes} minutes")
    print(f"💧 Flow rate: {flow_q} m³/s")
    print(f"🏔️ Manning's n: {manning_n}")
    
    # Create hillshade from DEM
    hillshade_path = os.path.join(output_folder, "dem_hillshade.tif")
    create_hillshade_gdal(dem_path, hillshade_path)
    
    # Calculate timesteps
    total_minutes = duration_hours * 60
    num_timesteps = int(total_minutes / timestep_minutes)
    
    print(f"📊 Calculated {num_timesteps} timesteps over {duration_hours} hours")
    
    # Run simulation
    sv_result = simulate_saint_venant_2d(
        dem_path=dem_path,
        flow_rate=flow_q,
        manning_n=manning_n,
        duration_hours=duration_hours,
        timestep_minutes=timestep_minutes,
        num_timesteps=num_timesteps,
        output_folder=output_folder,
        water_levels=water_levels
    )
    
    all_polygons = []
    for filename, timestep_num, simulation_time_hours, actual_water_level in sv_result:
        wet_array = load_raster_to_array_gdal(filename)
        threshold = kwargs.get('wet_threshold', 0.05)
        binary_mask = (wet_array > threshold)
        polygon_layer = polygonize_mask_gdal(binary_mask, filename, output_folder, timestep_num, actual_water_level)
        
        layer_name = f"Flood_T{timestep_num:03d}_{simulation_time_hours:.1f}h_{actual_water_level:.2f}m"
        polygon_layer.setName(layer_name)
        style_polygon_layer_blue_opacity(polygon_layer)
        QgsProject.instance().addMapLayer(polygon_layer)
        
        # Create streamlines
        vx_path = filename.replace('depth', 'velocity_x')
        vy_path = filename.replace('depth', 'velocity_y')
        mask_path = filename
        gpkg_path = os.path.join(output_folder, f"streamlines_T{timestep_num:03d}_{simulation_time_hours:.1f}h.gpkg")
        create_streamlines_from_velocity_gdal(vx_path, vy_path, mask_path, gpkg_path)
        layer = QgsVectorLayer(gpkg_path, f"Streamlines_T{timestep_num:03d}_{simulation_time_hours:.1f}h", "ogr")
        QgsProject.instance().addMapLayer(layer)
        all_polygons.append(polygon_layer)
        
    return all_polygons

def create_hillshade_gdal(dem_path, output_path, azimuth=315, altitude=45):
    """Create hillshade from DEM using GDAL."""
    print(f"Creating hillshade using GDAL...")
    
    try:
        options = gdal.DEMProcessingOptions(
            format='GTiff',
            creationOptions=['COMPRESS=LZW'],
            azimuth=azimuth,
            altitude=altitude
        )
        
        result = gdal.DEMProcessing(output_path, dem_path, 'hillshade', options=options)
        
        if result is not None and os.path.exists(output_path):
            print(f"✅ Hillshade saved: {output_path}")
        else:
            print(f"❌ Failed to create hillshade: {output_path}")
            
    except Exception as e:
        print(f"❌ Error creating hillshade: {str(e)}")

def load_raster_to_array_gdal(raster_path):
    """Load raster data to numpy array using GDAL."""
    dataset = gdal.Open(raster_path)
    if dataset is None:
        raise ValueError(f"Cannot open raster file: {raster_path}")
    
    band = dataset.GetRasterBand(1)
    array = band.ReadAsArray()
    dataset = None
    return array

def polygonize_mask_gdal(binary_mask, dem_path, output_folder, timestep, water_level):
    """Convert binary mask to polygon using GDAL."""
    from qgis.core import QgsVectorLayer
    
    # Get spatial reference from DEM
    dem_dataset = gdal.Open(dem_path)
    geotransform = dem_dataset.GetGeoTransform()
    projection = dem_dataset.GetProjection()
    
    # Create temporary raster for the mask
    rows, cols = binary_mask.shape
    temp_tif = os.path.join(output_folder, f"temp_mask_{timestep}.tif")
    
    driver = gdal.GetDriverByName('GTiff')
    mask_dataset = driver.Create(temp_tif, cols, rows, 1, gdal.GDT_Byte)
    mask_dataset.SetGeoTransform(geotransform)
    mask_dataset.SetProjection(projection)
    mask_band = mask_dataset.GetRasterBand(1)
    mask_band.WriteArray(binary_mask.astype(np.uint8))
    mask_dataset.FlushCache()
    mask_dataset = None
    dem_dataset = None
    
    # Convert raster to vector
    output_shp = os.path.join(output_folder, f"flood_polygons_{timestep:03d}_{water_level:.2f}m.shp")
    
    driver = ogr.GetDriverByName("ESRI Shapefile")
    if os.path.exists(output_shp):
        driver.DeleteDataSource(output_shp)
    
    datasource = driver.CreateDataSource(output_shp)
    
    srs = osr.SpatialReference()
    srs.ImportFromWkt(projection)
    
    layer = datasource.CreateLayer("flood", srs, ogr.wkbPolygon)
    field_defn = ogr.FieldDefn("WaterLevel", ogr.OFTReal)
    layer.CreateField(field_defn)
    
    # Polygonize
    mask_dataset = gdal.Open(temp_tif)
    mask_band = mask_dataset.GetRasterBand(1)
    gdal.Polygonize(mask_band, None, layer, 0, [], callback=None)
    
    # Add water level attribute
    layer.ResetReading()
    for feature in layer:
        feature.SetField("WaterLevel", water_level)
        layer.SetFeature(feature)
    
    # Clean up
    mask_dataset = None
    datasource = None
    
    try:
        os.remove(temp_tif)
    except:
        pass
    
    polygon_layer = QgsVectorLayer(output_shp, f"Flood_{timestep:03d}", "ogr")
    return polygon_layer

def create_streamlines_from_velocity_gdal(vx_path, vy_path, mask_path, output_gpkg, n_points=150, max_length=200, step=1.5):
    """Create streamlines from velocity fields using GDAL."""
    print(f"Creating streamlines from velocity fields...")
    
    try:
        # Load velocity and mask data
        vx_array = load_raster_to_array_gdal(vx_path)
        vy_array = load_raster_to_array_gdal(vy_path)
        mask_array = load_raster_to_array_gdal(mask_path)
        
        # Get geospatial info
        dataset = gdal.Open(vx_path)
        geotransform = dataset.GetGeoTransform()
        projection = dataset.GetProjection()
        dataset = None
        
        driver = ogr.GetDriverByName("GPKG")
        if os.path.exists(output_gpkg):
            driver.DeleteDataSource(output_gpkg)
        
        datasource = driver.CreateDataSource(output_gpkg)
        
        srs = osr.SpatialReference()
        srs.ImportFromWkt(projection)
        
        layer = datasource.CreateLayer("streamlines", srs, ogr.wkbLineString)
        layer.CreateField(ogr.FieldDefn("ID", ogr.OFTInteger))
        layer.CreateField(ogr.FieldDefn("Velocity", ogr.OFTReal))
        
        # Generate streamlines
        rows, cols = mask_array.shape
        valid_mask = (mask_array > 0.05) & (np.abs(vx_array) + np.abs(vy_array) > 0.01)
        
        if np.sum(valid_mask) == 0:
            print("No valid flow areas found for streamlines")
            datasource = None
            return
        
        # Sample starting points
        valid_indices = np.where(valid_mask)
        if len(valid_indices[0]) > n_points:
            indices = np.random.choice(len(valid_indices[0]), n_points, replace=False)
            start_rows = valid_indices[0][indices]
            start_cols = valid_indices[1][indices]
        else:
            start_rows = valid_indices[0]
            start_cols = valid_indices[1]
        
        streamline_id = 0
        for start_row, start_col in zip(start_rows, start_cols):
            points = []
            row, col = float(start_row), float(start_col)
            
            for _ in range(int(max_length / step)):
                if (row < 0 or row >= rows-1 or col < 0 or col >= cols-1 or
                    mask_array[int(row), int(col)] <= 0.05):
                    break
                
                # Convert pixel to geographic coordinates
                x = geotransform[0] + col * geotransform[1] + row * geotransform[2]
                y = geotransform[3] + col * geotransform[4] + row * geotransform[5]
                points.append((x, y))
                
                # Get velocity at current position
                vx = vx_array[int(row), int(col)]
                vy = vy_array[int(row), int(col)]
                
                if abs(vx) + abs(vy) < 0.01:
                    break
                
                # Move to next position
                pixel_size = abs(geotransform[1])
                row += vy * step / pixel_size
                col += vx * step / pixel_size
            
            # Create line feature if we have enough points
            if len(points) > 2:
                line_geom = ogr.Geometry(ogr.wkbLineString)
                for x, y in points:
                    line_geom.AddPoint(x, y)
                
                feature = ogr.Feature(layer.GetLayerDefn())
                feature.SetGeometry(line_geom)
                feature.SetField("ID", streamline_id)
                
                avg_velocity = np.sqrt(vx_array[int(start_row), int(start_col)]**2 + 
                                     vy_array[int(start_row), int(start_col)]**2)
                feature.SetField("Velocity", float(avg_velocity))
                
                layer.CreateFeature(feature)
                feature = None
                streamline_id += 1
        
        datasource = None
        print(f"Created {streamline_id} streamlines in {output_gpkg}")
        
    except Exception as e:
        print(f"Error creating streamlines: {str(e)}")
        # Create empty file to prevent errors
        driver = ogr.GetDriverByName("GPKG")
        if os.path.exists(output_gpkg):
            driver.DeleteDataSource(output_gpkg)
        datasource = driver.CreateDataSource(output_gpkg)
        layer = datasource.CreateLayer("streamlines", None, ogr.wkbLineString)
        datasource = None

def style_polygon_layer_blue_opacity(layer):
    """Style polygon layer with blue color and opacity."""
    symbol = layer.renderer().symbol()
    symbol.setColor(QColor(70, 140, 255, 120))
    symbol.setOpacity(0.47)
    layer.triggerRepaint()

def simulate_saint_venant_2d(
    dem_path,
    flow_rate,
    manning_n,
    duration_hours,
    timestep_minutes,
    num_timesteps,
    output_folder,
    water_levels=None,
    **kwargs
):
    """
    Enhanced 2D Saint-Venant simulation with realistic flooding.
    """
    print(f"🌊 Starting 2D Saint-Venant simulation...")
    print(f"📍 Terrain model: {dem_path}")
    
    # Load DEM with diagnostics
    dem_dataset = gdal.Open(dem_path)
    if dem_dataset is None:
        raise ValueError(f"Cannot open DEM file: {dem_path}")
    
    dem_band = dem_dataset.GetRasterBand(1)
    dem_data = dem_band.ReadAsArray()
    geotransform = dem_dataset.GetGeoTransform()
    projection = dem_dataset.GetProjection()
    height, width = dem_data.shape
    
    # DEM DIAGNOSTICS
    print(f"🔍 DEM DIAGNOSTICS:")
    print(f"   📐 DEM dimensions: {width} x {height} pixels")
    print(f"   📊 DEM data type: {dem_data.dtype}")
    print(f"   🎯 Raw DEM range: {np.nanmin(dem_data):.3f}m to {np.nanmax(dem_data):.3f}m")
    print(f"   ❌ NoData/NaN count: {np.sum(np.isnan(dem_data))} pixels")
    print(f"   🔢 Zero count: {np.sum(dem_data == 0)} pixels")
    
    # Handle NoData values
    nodata_value = dem_band.GetNoDataValue()
    if nodata_value is not None:
        print(f"   🚫 DEM NoData value: {nodata_value}")
        dem_data = np.where(dem_data == nodata_value, np.nan, dem_data)
    
    # Check valid elevation data
    valid_elevations = dem_data[~np.isnan(dem_data)]
    if len(valid_elevations) == 0:
        raise ValueError("DEM contains no valid elevation data")
    
    print(f"   📈 Valid elevation range: {np.min(valid_elevations):.2f}m to {np.max(valid_elevations):.2f}m")
    
    # Generate water levels if not provided
    if water_levels is None:
        max_water_level = 2.0
        if flow_rate:
            max_water_level += flow_rate / 100.0
        
        water_levels = list(np.linspace(0.5, max_water_level, num_timesteps))
        print(f"📊 Generated {len(water_levels)} water levels: {water_levels[0]:.2f}m to {water_levels[-1]:.2f}m")
    
    results = []
    
    # Process each timestep with REALISTIC FLOODING
    for i, water_level in enumerate(water_levels):
        timestep = i + 1
        print(f"📊 Processing timestep {timestep}: {water_level:.2f}m water level")
        
        # REALISTIC FLOODING: Start from lowest areas and spread
        flood_depth = np.zeros_like(dem_data, dtype=np.float32)
        
        # Find starting points (lowest 5% of DEM)
        dem_percentile_5 = np.percentile(valid_elevations, 5)
        initial_flood_elevation = min(water_level, dem_percentile_5 + 1.0)
        
        # Seed points for flooding
        seed_mask = (dem_data <= initial_flood_elevation) & (dem_data <= water_level - 0.5)
        
        if not np.any(seed_mask):
            min_elevation = np.nanmin(dem_data)
            seed_mask = dem_data <= (min_elevation + 0.5)
        
        print(f"   🌱 Flood seeds: {np.sum(seed_mask)} pixels at elevation ≤ {initial_flood_elevation:.1f}m")
        
        # Flood fill algorithm
        flood_mask = seed_mask.copy()
        
        # Simple neighbor-based flood spreading
        for iteration in range(10):  # Max 10 iterations
            old_flood_count = np.sum(flood_mask)
            
            # Create expanded flood area
            expanded = np.zeros_like(flood_mask, dtype=bool)
            
            # Check 4-connected neighbors
            for dy, dx in [(-1,0), (1,0), (0,-1), (0,1)]:
                # Create shifted version of flood mask
                if dy == -1:  # Up
                    shifted = np.pad(flood_mask[1:, :], ((0, 1), (0, 0)), mode='constant', constant_values=False)
                elif dy == 1:  # Down
                    shifted = np.pad(flood_mask[:-1, :], ((1, 0), (0, 0)), mode='constant', constant_values=False)
                elif dx == -1:  # Left
                    shifted = np.pad(flood_mask[:, 1:], ((0, 0), (0, 1)), mode='constant', constant_values=False)
                elif dx == 1:  # Right
                    shifted = np.pad(flood_mask[:, :-1], ((0, 0), (1, 0)), mode='constant', constant_values=False)
                
                # Allow spreading to adjacent areas that are:
                # 1. Not already flooded
                # 2. Below water level
                # 3. Not too much higher than current flood level
                if np.any(flood_mask):
                    avg_flood_elevation = np.nanmean(dem_data[flood_mask])
                    max_spread_elevation = min(water_level, avg_flood_elevation + 1.0)
                else:
                    max_spread_elevation = water_level
                
                spreadable = (
                    shifted & 
                    ~flood_mask & 
                    (dem_data <= max_spread_elevation) &
                    (dem_data <= water_level) &
                    ~np.isnan(dem_data)
                )
                expanded = expanded | spreadable
            
            flood_mask = flood_mask | expanded
            
            new_flood_count = np.sum(flood_mask)
            if new_flood_count == old_flood_count:
                break
            
            print(f"   📈 Iteration {iteration+1}: {new_flood_count} flooded pixels")
        
        # Calculate realistic flood depths
        potential_depth = np.maximum(0, water_level - dem_data)
        flood_depth = np.where(flood_mask, potential_depth, 0.0)
        
        # Apply depth limits and minimum threshold
        flood_depth = np.minimum(flood_depth, 20.0)  # Max 20m depth
        flood_depth[flood_depth < 0.05] = 0.0
        
        flooded_area_pct = np.sum(flood_depth > 0) / dem_data.size * 100
        print(f"   🌊 Realistic flooded area: {np.sum(flood_depth > 0)} pixels ({flooded_area_pct:.1f}% of DEM)")
        print(f"   💧 Max flood depth: {np.max(flood_depth):.1f}m")
        
        # Save depth raster
        depth_filename = os.path.join(output_folder, f"depth_{timestep:03d}.tif")
        driver = gdal.GetDriverByName('GTiff')
        depth_dataset = driver.Create(depth_filename, width, height, 1, gdal.GDT_Float32,
                                     options=['COMPRESS=LZW'])
        depth_dataset.SetGeoTransform(geotransform)
        depth_dataset.SetProjection(projection)
        depth_band = depth_dataset.GetRasterBand(1)
        depth_band.WriteArray(flood_depth)
        depth_dataset.FlushCache()
        depth_dataset = None
        
        # Create realistic velocity fields
        gradient_x = np.gradient(dem_data, axis=1, edge_order=2)
        gradient_y = np.gradient(dem_data, axis=0, edge_order=2)
        
        # Flow follows steepest descent
        flow_direction_x = -gradient_x
        flow_direction_y = -gradient_y
        
        # Normalize flow directions
        flow_magnitude = np.sqrt(flow_direction_x**2 + flow_direction_y**2)
        flow_magnitude[flow_magnitude == 0] = 1
        
        unit_flow_x = flow_direction_x / flow_magnitude
        unit_flow_y = flow_direction_y / flow_magnitude
        
        # Manning's equation for velocity
        if manning_n and manning_n > 0:
            hydraulic_radius = flood_depth
            slope = np.maximum(flow_magnitude, 0.001)
            
            velocity_magnitude = np.where(
                flood_depth > 0.05,
                (1.0 / manning_n) * np.power(hydraulic_radius, 2.0/3.0) * np.power(slope, 0.5),
                0
            )
            
            if flow_rate and flow_rate > 0:
                flow_scale = min(2.0, flow_rate / 50.0)
                velocity_magnitude *= flow_scale
        else:
            velocity_magnitude = np.where(
                flood_depth > 0, 
                0.5 * np.sqrt(flood_depth) * np.sqrt(flow_magnitude + 0.001), 
                0
            )
        
        # Apply flow direction
        velocity_x = velocity_magnitude * unit_flow_x
        velocity_y = velocity_magnitude * unit_flow_y
        
        # Save velocity rasters
        vx_filename = os.path.join(output_folder, f"velocity_x_{timestep:03d}.tif")
        vy_filename = os.path.join(output_folder, f"velocity_y_{timestep:03d}.tif")
        
        for vel_data, vel_filename in [(velocity_x, vx_filename), (velocity_y, vy_filename)]:
            driver = gdal.GetDriverByName('GTiff')
            vel_dataset = driver.Create(vel_filename, width, height, 1, gdal.GDT_Float32,
                                       options=['COMPRESS=LZW'])
            vel_dataset.SetGeoTransform(geotransform)
            vel_dataset.SetProjection(projection)
            vel_band = vel_dataset.GetRasterBand(1)
            vel_band.WriteArray(vel_data)
            vel_dataset.FlushCache()
            vel_dataset = None
        
        # Calculate simulation time
        simulation_time_hours = (timestep * timestep_minutes) / 60.0
        
        results.append((depth_filename, timestep, simulation_time_hours, water_level))
        print(f"✅ Saved: {depth_filename}")
    
    dem_dataset = None
    
    print(f"🎉 Enhanced simulation complete! Generated {len(results)} timesteps")
    return results
