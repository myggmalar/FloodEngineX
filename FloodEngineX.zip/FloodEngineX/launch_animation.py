#!/usr/bin/env python3
"""
FloodEngine Time Series Animation Launcher
==========================================
Enhanced launcher with comprehensive animation controls and dependency checking.
"""

import sys
import os
import logging
import argparse
from pathlib import Path

# CRITICAL: Global variable to prevent garbage collection
_PERSISTENT_DIALOG = None

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("FloodEngine.LaunchAnimation")

def check_dependencies():
    """Check if required dependencies are available."""
    missing_deps = []
    
    try:
        import numpy as np
        logger.info("✅ NumPy available")
    except ImportError:
        missing_deps.append("numpy")
    
    try:
        from PyQt5.QtWidgets import QApplication
        logger.info("✅ PyQt5 available")
    except ImportError:
        missing_deps.append("PyQt5")
    
    try:
        from osgeo import gdal
        logger.info("✅ GDAL available")
    except ImportError:
        logger.warning("⚠️ GDAL not available - limited raster functionality")
    
    try:
        from qgis.utils import iface
        if iface is not None:
            logger.info("✅ QGIS environment detected")
            return True, missing_deps
        else:
            logger.info("ℹ️ QGIS modules available but not in QGIS environment")
    except ImportError:
        logger.info("ℹ️ QGIS not available - will use standalone mode")
    
    if missing_deps:
        logger.error(f"❌ Missing required dependencies: {missing_deps}")
        return False, missing_deps
    
    return True, missing_deps

def launch_animation_from_folder(results_folder, standalone=False, parent=None):
    """
    Launch animation controls from existing results folder.
    
    Parameters:
        results_folder (str): Path to results folder
        standalone (bool): Force standalone mode
        parent (QWidget): Parent widget for the dialog (important for QGIS)
    """
    
    # Add FloodEngineX to path
    script_dir = Path(__file__).parent
    sys.path.insert(0, str(script_dir))
    
    # Check dependencies
    deps_ok, missing = check_dependencies()
    if not deps_ok:
        logger.error("❌ Cannot launch animation due to missing dependencies")
        logger.error(f"Please install: {missing}")
        return False
    
    # Determine animation folder
    if os.path.exists(os.path.join(results_folder, 'time_series_animation')):
        animation_folder = os.path.join(results_folder, 'time_series_animation')
    elif os.path.exists(os.path.join(results_folder, 'rasters')):
        animation_folder = results_folder
    else:
        logger.error(f"❌ No animation data found in: {results_folder}")
        return False
    
    # Check for QGIS environment and get parent window
    qgis_available = False
    qgis_main_window = None
    if not standalone:
        try:
            from qgis.core import QgsApplication
            from qgis.utils import iface
            qgis_available = (iface is not None)
            if qgis_available:
                logger.info("✅ QGIS environment detected")
                # Get QGIS main window as parent
                if hasattr(iface, 'mainWindow') and iface.mainWindow():
                    qgis_main_window = iface.mainWindow()
                    logger.info("✅ Found QGIS main window for parenting")
            else:
                logger.info("ℹ️ QGIS available but not in active environment")
        except ImportError:
            logger.info("ℹ️ QGIS not available - using standalone mode")
    
    try:
        if qgis_available and not standalone:
            # Launch in QGIS
            logger.info("🗺️ Attempting to launch in QGIS mode...")
            try:
                from map_canvas_time_series import launch_time_series_animation
                logger.info("✅ Successfully imported map_canvas_time_series")
                results_data = load_results_from_folder(animation_folder)
                logger.info("✅ Successfully loaded results data")
                result = launch_time_series_animation(results_data, animation_folder)
                logger.info(f"✅ QGIS animation launch result: {result}")
                return result
            except Exception as e:
                logger.error(f"❌ QGIS animation launch failed: {e}")
                logger.info("🔄 Falling back to standalone mode...")
                # Fall back to standalone mode
                standalone = True
        
        if standalone or not qgis_available:
            # Launch standalone
            logger.info("🖥️ Attempting to launch in standalone mode...")
            from time_series_animator import TimeSeriesAnimator
            from PyQt5.QtWidgets import QApplication
            
            # Create or get QApplication
            app = QApplication.instance()
            if app is None:
                app = QApplication(sys.argv)
                logger.info("📱 Created new QApplication")
            
            # Load results data
            results_data = load_results_from_folder(animation_folder)
            
            # Determine parent window - prefer passed parent, then QGIS main window
            effective_parent = parent or qgis_main_window
            if effective_parent:
                logger.info(f"✅ Using parent window: {type(effective_parent).__name__}")
            
            # Create animator with proper parent
            animator = TimeSeriesAnimator(results_data, animation_folder, parent=effective_parent)
            animator.setWindowTitle("FloodEngine - Time Series Animation")
            
            # Set window attributes to prevent garbage collection
            try:
                from PyQt5.QtCore import Qt
                animator.setAttribute(Qt.WA_DeleteOnClose, False)  # Don't auto-delete
            except:
                pass  # Ignore if attribute doesn't exist
            
            animator.show()
            animator.raise_()
            animator.activateWindow()
            
            # FORCE WINDOW TO FRONT (Windows-specific fix)
            try:
                from PyQt5.QtCore import Qt
                animator.setWindowState(Qt.WindowActive)
                animator.setWindowFlags(animator.windowFlags() | Qt.WindowStaysOnTopHint)
                animator.show()  # Show again after setting flags
                animator.setWindowFlags(animator.windowFlags() & ~Qt.WindowStaysOnTopHint)  # Remove stay-on-top
                animator.show()  # Final show
                logger.info("🔧 Applied Windows visibility fixes")
            except Exception as e:
                logger.warning(f"⚠️ Could not apply Windows fixes: {e}")
            
            logger.info("✅ Standalone animation dialog launched successfully!")
            
            # CRITICAL: Store in module global to prevent garbage collection
            global _PERSISTENT_DIALOG
            _PERSISTENT_DIALOG = animator
            print("✅ Stored dialog in global _PERSISTENT_DIALOG")
            
            # Store in multiple other locations for extra safety
            try:
                app._flood_animator = animator
            except:
                pass
            
            try:
                from dialog_manager import store_animation_dialog
                store_animation_dialog(animator)
            except:
                pass
            
            import __main__
            __main__._flood_animator = animator
            
            import sys as sys_module
            sys_module.modules['_current_flood_animator'] = animator
            
            print("✅ Stored dialog references in multiple locations")
            print("✅ Dialog should now persist and remain visible")
            
            # If this is the main application, start event loop
            if __name__ == "__main__":
                sys.exit(app.exec_())
            
            return animator
            
    except Exception as e:
        logger.error(f"❌ Failed to launch animation: {e}")
        logger.info("📖 Check ANIMATION_INSTRUCTIONS.md for manual setup")
        return False

def load_results_from_folder(animation_folder):
    """
    Try to reconstruct results data from animation folder.
    
    Parameters:
        animation_folder (str): Path to animation folder
        
    Returns:
        dict: Reconstructed results data
    """
    logger.info(f"🔍 Attempting to load results from: {animation_folder}")
    
    try:
        import numpy as np
        from osgeo import gdal
        import re
        
        results_data = {
            'times': [],
            'water_depths': [],
            'water_surfaces': [],
            'velocity_x': [],
            'velocity_y': []
        }
        
        raster_folder = os.path.join(animation_folder, 'rasters')
        if not os.path.exists(raster_folder):
            raster_folder = animation_folder
        
        # Find all depth rasters and extract timestamps
        depth_files = []
        for filename in os.listdir(raster_folder):
            if filename.startswith('flood_depth_t') and filename.endswith('.tif'):
                depth_files.append(filename)
        
        # Sort by timestep number
        depth_files.sort()
        
        for filename in depth_files:
            # Extract timestep and time from filename
            match = re.search(r't(\d+)_([0-9.]+)s\.tif', filename)
            if match:
                timestep = int(match.group(1))
                time_value = float(match.group(2))
                
                results_data['times'].append(time_value)
                
                # Load depth raster
                filepath = os.path.join(raster_folder, filename)
                ds = gdal.Open(filepath)
                if ds:
                    depth_array = ds.ReadAsArray()
                    results_data['water_depths'].append(depth_array)
                    
                    # Store geotransform and projection from first file
                    if len(results_data['water_depths']) == 1:
                        results_data['geotransform'] = ds.GetGeoTransform()
                        results_data['projection'] = ds.GetProjection()
                    
                    ds = None
        
        # Try to load DEM from water surface data
        if results_data['water_depths'] and os.path.exists(raster_folder):
            surface_filename = f"water_surface_t0000_{results_data['times'][0]:.1f}s.tif"
            surface_path = os.path.join(raster_folder, surface_filename)
            
            if os.path.exists(surface_path):
                ds = gdal.Open(surface_path)
                if ds:
                    surface_array = ds.ReadAsArray()
                    depth_array = results_data['water_depths'][0]
                    
                    # Calculate DEM as surface - depth
                    dem_array = surface_array - depth_array
                    results_data['dem_array'] = dem_array
                    ds = None
        
        logger.info(f"✅ Loaded {len(results_data['times'])} timesteps from folder")
        return results_data
        
    except Exception as e:
        logger.error(f"❌ Failed to load results from folder: {e}")
        
        # Return minimal valid structure
        return {
            'times': [0.0],
            'water_depths': [np.zeros((100, 100))],
            'geotransform': (0, 1, 0, 0, 0, -1),
            'projection': ''
        }

def create_sample_animation():
    """Create a sample animation for testing purposes."""
    logger.info("🧪 Creating sample animation data...")
    
    import numpy as np
    
    # Create sample data
    nx, ny = 50, 50
    x = np.linspace(0, 10, nx)
    y = np.linspace(0, 10, ny)
    X, Y = np.meshgrid(x, y)
    
    # Sample DEM (parabolic bowl)
    dem = 0.1 * ((X - 5)**2 + (Y - 5)**2)
    
    # Time series
    times = np.linspace(0, 100, 21)  # 21 timesteps over 100 seconds
    water_depths = []
    
    for i, t in enumerate(times):
        # Expanding flood pattern
        center_x, center_y = 5, 5
        radius = 1 + 3 * (t / 100)  # Expanding from 1 to 4
        
        distance = np.sqrt((X - center_x)**2 + (Y - center_y)**2)
        depth = np.maximum(0, 2.0 * np.exp(-0.5 * distance) - dem)
        depth = np.maximum(0, depth - radius * 0.1)  # Gradual recession
        
        water_depths.append(depth)
    
    results_data = {
        'times': times.tolist(),
        'water_depths': water_depths,
        'dem_array': dem,
        'geotransform': (0, 0.2, 0, 10, 0, -0.2),
        'projection': 'GEOGCS["WGS 84",DATUM["WGS_1984",SPHEROID["WGS 84",6378137,298.257223563]],PRIMEM["Greenwich",0],UNIT["degree",0.0174532925199433]]'
    }
    
    logger.info("✅ Sample animation data created")
    return results_data

def main():
    """Main function for command-line usage."""
    parser = argparse.ArgumentParser(description="Launch FloodEngine Time Series Animation")
    parser.add_argument('folder', nargs='?', default='test_time_series_output',
                       help='Animation folder path (default: test_time_series_output)')
    parser.add_argument('--sample', '-s', action='store_true', 
                       help='Create and show sample animation')
    parser.add_argument('--standalone', action='store_true', 
                       help='Force standalone mode (no QGIS)')
    parser.add_argument('--check-deps', action='store_true', 
                       help='Check dependencies and exit')
    
    args = parser.parse_args()
    
    # Check dependencies
    deps_ok, missing = check_dependencies()
    
    if args.check_deps:
        if deps_ok:
            print("✅ All dependencies are available")
            sys.exit(0)
        else:
            print(f"❌ Missing dependencies: {missing}")
            sys.exit(1)
    
    if not deps_ok:
        logger.error("❌ Cannot launch animation due to missing dependencies")
        logger.error(f"Please install: {missing}")
        return 1
    
    # Determine what to launch
    if args.sample:
        logger.info("🧪 Creating sample animation...")
        results_data = create_sample_animation()
        
        # Create temporary folder
        import tempfile
        temp_folder = tempfile.mkdtemp(prefix='floodengine_sample_')
        
        # Set up animation
        try:
            from time_series_integration import integrate_time_series_animation
            animation_result = integrate_time_series_animation(results_data, temp_folder)
            
            if animation_result['success']:
                launch_animation_from_folder(temp_folder, standalone=args.standalone)
            else:
                logger.error(f"Failed to set up sample animation: {animation_result.get('error')}")
                return 1
        except ImportError as e:
            logger.error(f"Cannot create sample animation: {e}")
            return 1
    else:
        # Launch from folder
        if not os.path.exists(args.folder):
            logger.error(f"❌ Folder does not exist: {args.folder}")
            return 1
        
        success = launch_animation_from_folder(args.folder, standalone=args.standalone)
        if not success:
            return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
