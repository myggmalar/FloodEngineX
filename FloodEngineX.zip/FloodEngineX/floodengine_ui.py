from PyQt5.QtWidgets import (
    QVBoxLayout, QHBoxLayout, QRadioButton, QLabel, QStackedWidget, 
    QWidget, QProgressBar, QPushButton, QGroupBox, QLineEdit, 
    QSlider, QComboBox, QCheckBox, QButtonGroup, QGridLayout, QDialog,
    QFileDialog, QScrollArea, QTableWidget, QTableWidgetItem, QTextEdit,
    QDialogButtonBox
)
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QIcon, QFont
import os

class BathymetryColumnDialog(QDialog):
    """Dialog for selecting X, Y, Z columns from CSV bathymetry data."""
    
    def __init__(self, csv_file_path, parent=None):
        super().__init__(parent)
        self.csv_file_path = csv_file_path
        self.selected_columns = {'x': None, 'y': None, 'z': None}
        self.setup_ui()
        self.load_csv_preview()
    
    def setup_ui(self):
        """Set up the column selection dialog UI."""
        self.setWindowTitle("Select Bathymetry Columns")
        self.setModal(True)
        self.resize(600, 400)
        
        layout = QVBoxLayout()
        self.setLayout(layout)
        
        # Instructions
        instructions = QLabel("Select the columns that contain X (longitude/easting), Y (latitude/northing), and Z (depth/elevation) coordinates:")
        instructions.setWordWrap(True)
        layout.addWidget(instructions)
        
        # Column selection section
        selection_layout = QHBoxLayout()
        
        # X column
        x_layout = QVBoxLayout()
        x_layout.addWidget(QLabel("<b>X Column (Longitude/Easting):</b>"))
        self.x_combo = QComboBox()
        x_layout.addWidget(self.x_combo)
        selection_layout.addLayout(x_layout)
        
        # Y column
        y_layout = QVBoxLayout()
        y_layout.addWidget(QLabel("<b>Y Column (Latitude/Northing):</b>"))
        self.y_combo = QComboBox()
        y_layout.addWidget(self.y_combo)
        selection_layout.addLayout(y_layout)
        
        # Z column
        z_layout = QVBoxLayout()
        z_layout.addWidget(QLabel("<b>Z Column (Depth/Elevation):</b>"))
        self.z_combo = QComboBox()
        z_layout.addWidget(self.z_combo)
        selection_layout.addLayout(z_layout)
        
        layout.addLayout(selection_layout)
        
        # Preview section
        layout.addWidget(QLabel("<b>Data Preview:</b>"))
        self.preview_table = QTableWidget()
        self.preview_table.setMaximumHeight(200)
        layout.addWidget(self.preview_table)
        
        # Buttons
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept_selection)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
    
    def load_csv_preview(self):
        """Load and display a preview of the CSV file."""
        try:
            import csv
            
            with open(self.csv_file_path, 'r', newline='', encoding='utf-8') as csvfile:
                # Try to detect delimiter
                sample = csvfile.read(1024)
                csvfile.seek(0)
                sniffer = csv.Sniffer()
                delimiter = sniffer.sniff(sample).delimiter
                
                reader = csv.reader(csvfile, delimiter=delimiter)
                rows = list(reader)
                
                if not rows:
                    return
                
                # Get headers (first row)
                headers = rows[0]
                
                # Populate combo boxes with column names
                for combo in [self.x_combo, self.y_combo, self.z_combo]:
                    combo.addItems(headers)
                
                # Try to auto-detect common column names
                self.auto_detect_columns(headers)
                
                # Set up preview table
                self.preview_table.setRowCount(min(10, len(rows)))  # Show max 10 rows
                self.preview_table.setColumnCount(len(headers))
                self.preview_table.setHorizontalHeaderLabels(headers)
                
                # Fill preview table with data
                for row_idx, row in enumerate(rows[:10]):
                    for col_idx, cell in enumerate(row):
                        if col_idx < len(headers):
                            item = QTableWidgetItem(str(cell))
                            self.preview_table.setItem(row_idx, col_idx, item)
                
                # Auto-resize columns
                self.preview_table.resizeColumnsToContents()
                
        except Exception as e:
            # If CSV loading fails, show error
            self.preview_table.setRowCount(1)
            self.preview_table.setColumnCount(1)
            self.preview_table.setHorizontalHeaderLabels(["Error"])
            error_item = QTableWidgetItem(f"Could not load CSV: {str(e)}")
            self.preview_table.setItem(0, 0, error_item)
    
    def auto_detect_columns(self, headers):
        """Try to automatically detect X, Y, Z columns based on common naming patterns."""
        headers_lower = [h.lower().strip() for h in headers]
        
        # Common patterns for X coordinate
        x_patterns = ['x', 'lon', 'longitude', 'easting', 'east', 'long']
        for i, header in enumerate(headers_lower):
            if any(pattern in header for pattern in x_patterns):
                self.x_combo.setCurrentIndex(i)
                break
        
        # Common patterns for Y coordinate
        y_patterns = ['y', 'lat', 'latitude', 'northing', 'north']
        for i, header in enumerate(headers_lower):
            if any(pattern in header for pattern in y_patterns):
                self.y_combo.setCurrentIndex(i)
                break
        
        # Common patterns for Z coordinate
        z_patterns = ['z', 'depth', 'elevation', 'elev', 'height', 'alt', 'altitude']
        for i, header in enumerate(headers_lower):
            if any(pattern in header for pattern in z_patterns):
                self.z_combo.setCurrentIndex(i)
                break
    
    def accept_selection(self):
        """Accept the column selection and store the results."""
        self.selected_columns = {
            'x': self.x_combo.currentText(),
            'y': self.y_combo.currentText(),
            'z': self.z_combo.currentText()
        }
        
        # Validate that different columns are selected
        columns = list(self.selected_columns.values())
        if len(set(columns)) != 3:
            # Show warning if same column is selected multiple times
            from PyQt5.QtWidgets import QMessageBox
            QMessageBox.warning(self, "Invalid Selection", 
                              "Please select different columns for X, Y, and Z coordinates.")
            return
        
        self.accept()
    
    def get_selected_columns(self):
        """Return the selected column names."""
        return self.selected_columns

class FloodEngineDialog(QDialog):
    """Main dialog for the FloodEngine QGIS plugin."""
    
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.setWindowTitle("FloodEngine")
        self.resize(800, 900)  # Increased size for better visibility
        self.iface = iface
        self.animation_window = None  # Store reference to animation window
        
        self.setup_ui()
        self.setup_connections()
    
    def setup_ui(self):
        """Set up the main user interface."""
        # Main dialog layout structure
        main_layout = QVBoxLayout()
        self.setLayout(main_layout)
        
        # Top section with mode selection
        mode_selection_layout = QHBoxLayout()
        self.basic_radio = QRadioButton("Basic Mode")
        self.advanced_radio = QRadioButton("Advanced Mode")
        self.basic_radio.setChecked(True)  # Default to Basic mode
        mode_selection_layout.addWidget(QLabel("<b>Model Mode:</b>"))
        mode_selection_layout.addWidget(self.basic_radio)
        mode_selection_layout.addWidget(self.advanced_radio)
        mode_selection_layout.addStretch()
        main_layout.addLayout(mode_selection_layout)
        
        # Stacked widget to switch between basic and advanced
        self.mode_stack = QStackedWidget()
        self.basic_page = QWidget()
        self.advanced_page = QWidget()
        
        # Set up the basic and advanced pages
        self.setup_basic_page()
        self.setup_advanced_page()
        
        self.mode_stack.addWidget(self.basic_page)
        self.mode_stack.addWidget(self.advanced_page)
        main_layout.addWidget(self.mode_stack)
        
        # Bottom section with run button and progress
        bottom_layout = QHBoxLayout()
        self.progress_bar = QProgressBar()
        self.run_button = QPushButton("Run Model")
        self.run_button.setMinimumHeight(40)
        bottom_layout.addWidget(self.progress_bar)
        bottom_layout.addWidget(self.run_button)
        main_layout.addLayout(bottom_layout)
    
    def setup_connections(self):
        """Set up signal-slot connections."""
        # Connect mode selection signals
        self.basic_radio.toggled.connect(self.toggle_mode)
        self.advanced_radio.toggled.connect(self.toggle_mode)
        
        # Connect run button
        self.run_button.clicked.connect(self.run_model)
        
        # Connect browse buttons
        self.connect_browse_buttons()
        
        # Connect sliders and other dynamic UI elements
        self.connect_dynamic_ui_elements()
        
        # Connect equation buttons
        self.connect_equation_buttons()
        
        # Connect timestep controls
        self.connect_timestep_controls()
        
        # Connect timestep controls
        self.connect_timestep_controls()
    
    def setup_basic_page(self):
        """Set up the UI for the Basic mode page."""
        # Create scroll area for basic page
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        
        # Create content widget
        content_widget = QWidget()
        layout = QVBoxLayout()
        content_widget.setLayout(layout)
        
        # Add the group boxes to the layout
        layout.addWidget(self.create_basic_data_inputs())
        layout.addWidget(self.create_basic_flood_parameters())
        layout.addWidget(self.create_basic_erosion_parameters())
        layout.addWidget(self.create_basic_output_options())
        
        layout.addStretch()  # Add stretch to push all widgets up
        
        # Set content widget to scroll area
        scroll_area.setWidget(content_widget)
        
        # Set scroll area as the page layout
        page_layout = QVBoxLayout()
        page_layout.addWidget(scroll_area)
        self.basic_page.setLayout(page_layout)
    
    def setup_advanced_page(self):
        """Set up the UI for the Advanced mode page."""
        # Create scroll area for advanced page
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        
        # Create content widget
        content_widget = QWidget()
        layout = QVBoxLayout()
        content_widget.setLayout(layout)
        
        # Add the group boxes to the layout
        layout.addWidget(self.create_advanced_hydraulic_model())
        layout.addWidget(self.create_advanced_stream_processing())
        layout.addWidget(self.create_advanced_erosion_section())
        layout.addWidget(self.create_advanced_groundwater_section())
        layout.addWidget(self.create_advanced_urban_section())
        layout.addWidget(self.create_advanced_time_series_section())
        
        layout.addStretch()  # Add stretch to push all widgets up
        
        # Set content widget to scroll area
        scroll_area.setWidget(content_widget)
        
        # Set scroll area as the page layout
        page_layout = QVBoxLayout()
        page_layout.addWidget(scroll_area)
        self.advanced_page.setLayout(page_layout)
    
    def create_section_header(self, title, tooltip=None, show_equation=False):
        """Creates a standardized section header with optional equation button"""
        header_layout = QHBoxLayout()
        
        # Create label with consistent styling
        label = QLabel(f"<b>{title}</b>")
        label.setStyleSheet("font-size: 11pt;")
        if tooltip:
            label.setToolTip(tooltip)
        header_layout.addWidget(label)
        
        header_layout.addStretch()
        
        # Add equation button if requested
        if show_equation:
            equation_btn = QPushButton()
            equation_btn.setIcon(QIcon(":/icons/equation.svg"))
            equation_btn.setToolTip(f"Show equations for {title}")
            equation_btn.setFixedSize(24, 24)
            equation_btn.setObjectName(f"equation_btn_{title.lower().replace(' ', '_')}")
            header_layout.addWidget(equation_btn)
        
        return header_layout
    
    def create_basic_data_inputs(self):
        """Creates the data inputs section for Basic mode"""
        group_box = QGroupBox("Data Inputs")
        layout = QVBoxLayout()
        
        # DEM file input
        dem_layout = QHBoxLayout()
        dem_layout.addWidget(QLabel("DEM File:"))
        self.basic_dem_path = QLineEdit()
        dem_layout.addWidget(self.basic_dem_path)
        self.basic_dem_btn = QPushButton("Browse...")
        dem_layout.addWidget(self.basic_dem_btn)
        layout.addLayout(dem_layout)
        
        # Bathymetry file input (optional)
        bathy_layout = QHBoxLayout()
        bathy_layout.addWidget(QLabel("Bathymetry (optional):"))
        self.basic_bathy_path = QLineEdit()
        bathy_layout.addWidget(self.basic_bathy_path)
        self.basic_bathy_btn = QPushButton("Browse...")
        bathy_layout.addWidget(self.basic_bathy_btn)
        layout.addLayout(bathy_layout)
        
        # Store bathymetry column information
        self.bathymetry_columns = {'x': None, 'y': None, 'z': None}
        
        # Soil data input (for erosion)
        soil_layout = QHBoxLayout()
        soil_layout.addWidget(QLabel("Soil Data (for erosion):"))
        self.basic_soil_path = QLineEdit()
        soil_layout.addWidget(self.basic_soil_path)
        self.basic_soil_btn = QPushButton("Browse...")
        soil_layout.addWidget(self.basic_soil_btn)
        layout.addLayout(soil_layout)
        
        group_box.setLayout(layout)
        return group_box
    
    def create_basic_flood_parameters(self):
        """Creates the flood parameters section for Basic mode"""
        group_box = QGroupBox("Flood Parameters")
        group_box.setToolTip("Configure the basic flood simulation parameters")
        layout = QVBoxLayout()
        
        # Grid layout for parameters with sliders
        params_layout = QGridLayout()
        
        # REMOVED: Water Level field - this was confusing for users
        # The flood simulation now automatically determines appropriate water levels
        
        # Flow Q row
        params_layout.addWidget(QLabel("Flow Rate (m³/s):"), 0, 0)
        self.basic_flow_q = QLineEdit()
        self.basic_flow_q.setText("100.0")
        self.basic_flow_q.setPlaceholderText("Flow rate")
        self.basic_flow_q.setMaximumWidth(80)
        self.basic_flow_q.setToolTip("Flow rate in cubic meters per second")
        params_layout.addWidget(self.basic_flow_q, 0, 1)
        
        # Flood Duration row
        params_layout.addWidget(QLabel("Flood Duration (hours):"), 1, 0)
        self.basic_duration = QLineEdit()
        self.basic_duration.setText("24")
        self.basic_duration.setMaximumWidth(80)
        self.basic_duration.setToolTip("Duration of flooding simulation")
        params_layout.addWidget(self.basic_duration, 1, 1)
        
        layout.addLayout(params_layout)
        
        # Add explanatory text
        explanation = QLabel("💡 The simulation automatically calculates realistic water levels based on your terrain and flow parameters. "
                           "No manual water level input needed!")
        explanation.setWordWrap(True)
        explanation.setStyleSheet("color: #666; font-style: italic; padding: 5px;")
        layout.addWidget(explanation)
        
        # Add visual diagram explaining the relationship between parameters
        diagram_layout = QHBoxLayout()
        diagram_label = QLabel()
        # Replace this with actual diagram image
        diagram_label.setText("[Diagram: Water Level vs Threshold visualization]")
        diagram_label.setStyleSheet("border: 1px solid #cccccc; padding: 5px; background-color: #f5f5f5;")
        diagram_label.setMinimumHeight(100)
        diagram_label.setAlignment(Qt.AlignCenter)
        diagram_layout.addWidget(diagram_label)
        layout.addLayout(diagram_layout)
        
        group_box.setLayout(layout)
        return group_box
    
    def create_basic_erosion_parameters(self):
        """Creates the erosion parameters section for Basic mode"""
        group_box = QGroupBox("Erosion Parameters")
        layout = QVBoxLayout()
        
        # Enable erosion checkbox
        self.basic_erosion_enable = QCheckBox("Calculate erosion risk")
        self.basic_erosion_enable.setChecked(True)
        layout.addWidget(self.basic_erosion_enable)
        
        # Soil type selection
        soil_layout = QHBoxLayout()
        soil_layout.addWidget(QLabel("Soil Type:"))
        self.basic_soil_type = QComboBox()
        soil_types = ["Select soil type...", "Sand", "Silt", "Clay", "Gravel", "Mixed", "Organic", "Rock"]
        self.basic_soil_type.addItems(soil_types)
        soil_layout.addWidget(self.basic_soil_type)
        layout.addLayout(soil_layout)
        
        # Erosion sensitivity
        sensitivity_layout = QHBoxLayout()
        sensitivity_layout.addWidget(QLabel("Erosion Sensitivity:"))
        self.basic_erosion_sensitivity = QComboBox()
        sensitivity_options = ["Low", "Medium", "High"]
        self.basic_erosion_sensitivity.addItems(sensitivity_options)
        self.basic_erosion_sensitivity.setCurrentIndex(1)  # Default to Medium
        sensitivity_layout.addWidget(self.basic_erosion_sensitivity)
        layout.addLayout(sensitivity_layout)
        
        # Note about more advanced options
        note_label = QLabel("Note: For more complex erosion models with custom parameters, use Advanced Mode")
        note_label.setStyleSheet("font-style: italic; color: #555555;")
        layout.addWidget(note_label)
        
        group_box.setLayout(layout)
        return group_box
    
    def create_basic_output_options(self):
        """Creates the output options section for Basic mode"""
        group_box = QGroupBox("Output Options")
        layout = QVBoxLayout()
        
        # Checkboxes for output options
        self.basic_output_flood_map = QCheckBox("Generate flood map")
        self.basic_output_flood_map.setChecked(True)
        layout.addWidget(self.basic_output_flood_map)
        
        self.basic_output_flood_stats = QCheckBox("Calculate inundation statistics")
        self.basic_output_flood_stats.setChecked(True)
        layout.addWidget(self.basic_output_flood_stats)
        
        self.basic_output_flow_arrows = QCheckBox("Show flow directions")
        layout.addWidget(self.basic_output_flow_arrows)
        
        # Output folder
        output_layout = QHBoxLayout()
        output_layout.addWidget(QLabel("Output Folder:"))
        self.basic_output_folder = QLineEdit()
        output_layout.addWidget(self.basic_output_folder)
        self.basic_output_folder_btn = QPushButton("Browse...")
        output_layout.addWidget(self.basic_output_folder_btn)
        layout.addLayout(output_layout)
        
        group_box.setLayout(layout)
        return group_box
    
    def create_advanced_hydraulic_model(self):
        """Creates the hydraulic model section for Advanced mode"""
        group_box = QGroupBox("Hydraulic Model")
        layout = QVBoxLayout()
        
        # Add header with equation button
        layout.addLayout(self.create_section_header("Hydraulic Model Configuration", 
                                               "Configure the hydraulic modeling approach",
                                               show_equation=True))
        
        # *** CRITICAL: DEM and Output Folder for 2D Models ***
        # DEM file input - REQUIRED for 2D models
        dem_layout = QHBoxLayout()
        dem_layout.addWidget(QLabel("DEM File:"))
        self.adv_dem_path = QLineEdit()
        self.adv_dem_path.setPlaceholderText("Select DEM file for terrain data...")
        dem_layout.addWidget(self.adv_dem_path)
        self.adv_dem_btn = QPushButton("Browse...")
        dem_layout.addWidget(self.adv_dem_btn)
        layout.addLayout(dem_layout)
        
        # Output folder - REQUIRED
        output_layout = QHBoxLayout()
        output_layout.addWidget(QLabel("Output Folder:"))
        self.adv_output_folder = QLineEdit()
        self.adv_output_folder.setPlaceholderText("Select output folder for results...")
        output_layout.addWidget(self.adv_output_folder)
        self.adv_output_btn = QPushButton("Browse...")
        output_layout.addWidget(self.adv_output_btn)
        layout.addLayout(output_layout)
        
        # Bathymetry file input - OPTIONAL
        bathy_layout = QHBoxLayout()
        bathy_layout.addWidget(QLabel("Bathymetry (optional):"))
        self.adv_bathy_path = QLineEdit()
        self.adv_bathy_path.setPlaceholderText("Optional bathymetry data...")
        bathy_layout.addWidget(self.adv_bathy_path)
        self.adv_bathy_btn = QPushButton("Browse...")
        bathy_layout.addWidget(self.adv_bathy_btn)
        layout.addLayout(bathy_layout)
        
        # Model type selection
        model_layout = QHBoxLayout()
        model_layout.addWidget(QLabel("Model Type:"))
        self.adv_model_type = QComboBox()
        model_types = ["1D Simplified", "2D Shallow Water", "2D SWE with Momentum"]
        self.adv_model_type.addItems(model_types)
        model_layout.addWidget(self.adv_model_type)
        layout.addLayout(model_layout)
        
        # Model state options
        state_layout = QHBoxLayout()
        self.adv_steady_state = QRadioButton("Steady State")
        self.adv_dynamic = QRadioButton("Dynamic")
        self.adv_steady_state.setChecked(True)
        state_group = QButtonGroup()
        state_group.addButton(self.adv_steady_state)
        state_group.addButton(self.adv_dynamic)
        state_layout.addWidget(QLabel("Simulation Type:"))
        state_layout.addWidget(self.adv_steady_state)
        state_layout.addWidget(self.adv_dynamic)
        state_layout.addStretch()
        layout.addLayout(state_layout)
        
        # Numerical method
        num_layout = QHBoxLayout()
        num_layout.addWidget(QLabel("Numerical Method:"))
        self.adv_numerical_method = QComboBox()
        num_methods = ["Finite Difference", "Finite Volume"]
        self.adv_numerical_method.addItems(num_methods)
        num_layout.addWidget(self.adv_numerical_method)
        layout.addLayout(num_layout)
        
        # Water levels and flow parameters for 2D models
        flow_layout = QGridLayout()
        
        # REMOVED: Water Levels field - this was confusing and not needed
        # The water levels are now automatically calculated from the DEM and flow parameters
        
        flow_layout.addWidget(QLabel("Flow Rate (m³/s):"), 0, 0)
        self.adv_flow_q = QLineEdit("500.0")
        self.adv_flow_q.setToolTip("Flow rate in cubic meters per second - determines flood intensity")
        flow_layout.addWidget(self.adv_flow_q, 0, 1)
        
        flow_layout.addWidget(QLabel("Manning's n:"), 1, 0)
        self.adv_manning_n = QLineEdit("0.03")
        self.adv_manning_n.setToolTip("Surface roughness coefficient (0.02-0.08 typical)")
        flow_layout.addWidget(self.adv_manning_n, 1, 1)
        
        layout.addLayout(flow_layout)
        
        # Add explanatory text
        explanation = QLabel("💡 Water levels are automatically calculated from the terrain (DEM) and flow parameters. "
                           "The simulation creates realistic flood progression over time.")
        explanation.setWordWrap(True)
        explanation.setStyleSheet("color: #666; font-style: italic; padding: 5px;")
        layout.addWidget(explanation)
        
        # Grid resolution
        grid_layout = QGridLayout()
        grid_layout.addWidget(QLabel("Grid Resolution:"), 0, 0)
        self.adv_grid_res = QLineEdit("5")
        self.adv_grid_res.setMaximumWidth(80)
        grid_layout.addWidget(self.adv_grid_res, 0, 1)
        grid_layout.addWidget(QLabel("meters"), 0, 2)
        layout.addLayout(grid_layout)
        
        # Advanced options
        self.adv_adaptive_mesh = QCheckBox("Use adaptive mesh refinement")
        self.adv_momentum = QCheckBox("Apply momentum conservation")
        self.adv_momentum.setToolTip("Increases accuracy but more computationally intensive")
        layout.addWidget(self.adv_adaptive_mesh)
        layout.addWidget(self.adv_momentum)
        
        group_box.setLayout(layout)
        return group_box
    
    def create_advanced_stream_processing(self):
        """Creates the stream and terrain processing section for Advanced mode"""
        group_box = QGroupBox("Stream & Terrain Processing")
        layout = QVBoxLayout()
        
        # Add header with equation button
        layout.addLayout(self.create_section_header("Stream & Terrain Processing", 
                                              "Configure stream burning and terrain modifications",
                                              show_equation=True))
        
        # Enable stream burning
        self.adv_enable_stream_burning = QCheckBox("Enable advanced stream burning")
        layout.addWidget(self.adv_enable_stream_burning)
        
        # Stream options container (enabled only when stream burning is checked)
        stream_container = QWidget()
        stream_layout = QVBoxLayout()
        stream_container.setLayout(stream_layout)
        stream_container.setEnabled(False)
        layout.addWidget(stream_container)
        
        # Stream file input
        stream_file_layout = QHBoxLayout()
        stream_file_layout.addWidget(QLabel("Stream file:"))
        self.adv_stream_file = QLineEdit()
        stream_file_layout.addWidget(self.adv_stream_file)
        self.adv_stream_file_btn = QPushButton("Browse...")
        stream_file_layout.addWidget(self.adv_stream_file_btn)
        stream_layout.addLayout(stream_file_layout)
        
        # Burn depth
        burn_layout = QHBoxLayout()
        burn_layout.addWidget(QLabel("Burn depth:"))
        self.adv_burn_depth = QLineEdit("5")
        self.adv_burn_depth.setMaximumWidth(80)
        burn_layout.addWidget(self.adv_burn_depth)
        burn_layout.addWidget(QLabel("meters"))
        stream_layout.addLayout(burn_layout)
        
        # Advanced stream options
        self.adv_consider_soil = QCheckBox("Consider soil erodibility")
        stream_layout.addWidget(self.adv_consider_soil)
        
        self.adv_bottom_undulations = QCheckBox("Generate bottom undulations")
        self.adv_bottom_undulations.setToolTip("Creates natural pool-riffle sequences in the stream")
        stream_layout.addWidget(self.adv_bottom_undulations)
        
        group_box.setLayout(layout)
        return group_box
    
    def create_advanced_erosion_section(self):
        """Creates the erosion and sediment section for Advanced mode"""
        group_box = QGroupBox("Erosion & Sediment")
        layout = QVBoxLayout()
        
        # Add header with equation button
        layout.addLayout(self.create_section_header("Erosion & Sediment Transport", 
                                              "Configure advanced erosion and sediment models",
                                              show_equation=True))
        
        # Erosion model selection
        model_layout = QHBoxLayout()
        model_layout.addWidget(QLabel("Erosion Model:"))
        self.adv_erosion_model = QComboBox()
        erosion_models = ["Basic (Slope-based)", "Meyer-Peter Müller", "van Rijn", "USLE"]
        self.adv_erosion_model.addItems(erosion_models)
        self.adv_erosion_model.setCurrentIndex(1)  # Default to MPM
        model_layout.addWidget(self.adv_erosion_model)
        layout.addLayout(model_layout)
        
        # Soil data input
        soil_layout = QHBoxLayout()
        soil_layout.addWidget(QLabel("Soil Data:"))
        self.adv_soil_data = QLineEdit()
        soil_layout.addWidget(self.adv_soil_data)
        self.adv_soil_data_btn = QPushButton("Browse...")
        soil_layout.addWidget(self.adv_soil_data_btn)
        layout.addLayout(soil_layout)
        
        # Enable sediment transport
        self.adv_enable_sediment = QCheckBox("Enable sediment transport")
        layout.addWidget(self.adv_enable_sediment)
        
        # Sediment options container
        sediment_container = QWidget()
        sediment_layout = QVBoxLayout()
        sediment_container.setLayout(sediment_layout)
        sediment_container.setEnabled(False)
        layout.addWidget(sediment_container)
        
        # Sediment parameters
        grain_layout = QHBoxLayout()
        grain_layout.addWidget(QLabel("D50 Grain Size:"))
        self.adv_grain_size = QLineEdit("1.0")
        self.adv_grain_size.setMaximumWidth(80)
        grain_layout.addWidget(self.adv_grain_size)
        grain_layout.addWidget(QLabel("mm"))
        sediment_layout.addLayout(grain_layout)
        
        density_layout = QHBoxLayout()
        density_layout.addWidget(QLabel("Sediment Density:"))
        self.adv_sediment_density = QLineEdit("2650")
        self.adv_sediment_density.setMaximumWidth(80)
        density_layout.addWidget(self.adv_sediment_density)
        density_layout.addWidget(QLabel("kg/m³"))
        sediment_layout.addLayout(density_layout)
        
        # Transport options
        transport_layout = QHBoxLayout()
        transport_layout.addWidget(QLabel("Transport Mode:"))
        self.adv_transport_mode = QComboBox()
        transport_modes = ["Bedload only", "Suspended only", "Bedload + Suspended"]
        self.adv_transport_mode.addItems(transport_modes)
        self.adv_transport_mode.setCurrentIndex(2)  # Default to both
        transport_layout.addWidget(self.adv_transport_mode)
        sediment_layout.addLayout(transport_layout)
        
        group_box.setLayout(layout)
        return group_box
    
    def create_advanced_groundwater_section(self):
        """Creates the groundwater section for Advanced mode"""
        group_box = QGroupBox("Groundwater")
        layout = QVBoxLayout()
        
        # Add header with equation button
        layout.addLayout(self.create_section_header("Groundwater Modeling", 
                                              "Configure groundwater and surface water interaction",
                                              show_equation=True))
        
        # Enable groundwater modeling
        self.adv_enable_groundwater = QCheckBox("Enable groundwater modeling")
        layout.addWidget(self.adv_enable_groundwater)
        
        # Groundwater options container
        gw_container = QWidget()
        gw_layout = QVBoxLayout()
        gw_container.setLayout(gw_layout)
        gw_container.setEnabled(False)
        layout.addWidget(gw_container)
        
        # Aquifer type
        aquifer_layout = QHBoxLayout()
        aquifer_layout.addWidget(QLabel("Aquifer Type:"))
        self.adv_aquifer_type = QComboBox()
        aquifer_types = ["Unconfined", "Confined", "Leaky confined"]
        self.adv_aquifer_type.addItems(aquifer_types)
        aquifer_layout.addWidget(self.adv_aquifer_type)
        gw_layout.addLayout(aquifer_layout)
        
        # Hydraulic conductivity
        k_layout = QHBoxLayout()
        k_layout.addWidget(QLabel("Hydraulic Conductivity:"))
        self.adv_hydraulic_k = QLineEdit("1.0")
        self.adv_hydraulic_k.setMaximumWidth(80)
        k_layout.addWidget(self.adv_hydraulic_k)
        k_layout.addWidget(QLabel("m/day"))
        gw_layout.addLayout(k_layout)
        
        # Storage coefficient
        storage_layout = QHBoxLayout()
        storage_layout.addWidget(QLabel("Storage Coefficient:"))
        self.adv_storage_coef = QLineEdit("0.1")
        self.adv_storage_coef.setMaximumWidth(80)
        storage_layout.addWidget(self.adv_storage_coef)
        gw_layout.addLayout(storage_layout)
        
        # Exchange rate
        exchange_layout = QHBoxLayout()
        exchange_layout.addWidget(QLabel("SW-GW Exchange Rate:"))
        self.adv_exchange_rate = QLineEdit("0.01")
        self.adv_exchange_rate.setMaximumWidth(80)
        exchange_layout.addWidget(self.adv_exchange_rate)
        exchange_layout.addWidget(QLabel("m/day"))
        gw_layout.addLayout(exchange_layout)
        
        # Initial groundwater level
        gw_level_layout = QHBoxLayout()
        gw_level_layout.addWidget(QLabel("Initial Groundwater Level:"))
        self.adv_init_gw_level = QComboBox()
        gw_level_options = ["Auto (based on DEM)", "Relative to surface", "Absolute elevation"]
        self.adv_init_gw_level.addItems(gw_level_options)
        gw_level_layout.addWidget(self.adv_init_gw_level)
        gw_layout.addLayout(gw_level_layout)
        
        group_box.setLayout(layout)
        return group_box
    
    def create_advanced_urban_section(self):
        """Creates the urban features section for Advanced mode"""
        group_box = QGroupBox("Urban Features")
        layout = QVBoxLayout()
        
        # Add header with equation button
        layout.addLayout(self.create_section_header("Urban Flood Modeling", 
                                              "Configure urban infrastructure and drainage",
                                              show_equation=True))
        
        # Enable urban modeling
        self.adv_enable_urban = QCheckBox("Enable urban flood modeling")
        layout.addWidget(self.adv_enable_urban)
        
        # Urban options container
        urban_container = QWidget()
        urban_layout = QVBoxLayout()
        urban_container.setLayout(urban_layout)
        urban_container.setEnabled(False)
        layout.addWidget(urban_container)
        
        # Buildings file
        buildings_layout = QHBoxLayout()
        buildings_layout.addWidget(QLabel("Buildings:"))
        self.adv_buildings_file = QLineEdit()
        buildings_layout.addWidget(self.adv_buildings_file)
        self.adv_buildings_btn = QPushButton("Browse...")
        buildings_layout.addWidget(self.adv_buildings_btn)
        urban_layout.addLayout(buildings_layout)
        
        # Drainage file
        drainage_layout = QHBoxLayout()
        drainage_layout.addWidget(QLabel("Drainage Network:"))
        self.adv_drainage_file = QLineEdit()
        drainage_layout.addWidget(self.adv_drainage_file)
        self.adv_drainage_btn = QPushButton("Browse...")
        drainage_layout.addWidget(self.adv_drainage_btn)
        urban_layout.addLayout(drainage_layout)
        
        # Urban options
        self.adv_include_culverts = QCheckBox("Include culverts and bridges")
        urban_layout.addWidget(self.adv_include_culverts)
        
        self.adv_urban_runoff = QCheckBox("Model urban surface runoff")
        urban_layout.addWidget(self.adv_urban_runoff)
        
        # Drainage capacity
        drainage_cap_layout = QHBoxLayout()
        drainage_cap_layout.addWidget(QLabel("Drainage Capacity:"))
        self.adv_drainage_capacity = QLineEdit("50")
        self.adv_drainage_capacity.setMaximumWidth(80)
        drainage_cap_layout.addWidget(self.adv_drainage_capacity)
        drainage_cap_layout.addWidget(QLabel("mm/hour"))
        urban_layout.addLayout(drainage_cap_layout)
        
        group_box.setLayout(layout)
        return group_box
    
    def create_advanced_time_series_section(self):
        """Creates the time series section for Advanced mode"""
        group_box = QGroupBox("Time Series")
        layout = QVBoxLayout()
        
        # Add header with equation button
        layout.addLayout(self.create_section_header("Time Series Simulation", 
                                              "Configure temporal simulation settings",
                                              show_equation=False))
        
        # Enable time series
        self.adv_enable_time_series = QCheckBox("Run time-series simulation")
        layout.addWidget(self.adv_enable_time_series)
        
        # Time series options container
        self.timeseries_container = QWidget()
        timeseries_layout = QVBoxLayout()
        self.timeseries_container.setLayout(timeseries_layout)
        self.timeseries_container.setEnabled(False)
        layout.addWidget(self.timeseries_container)
        
        # Modern timestep controls
        duration_layout = QHBoxLayout()
        duration_layout.addWidget(QLabel("Simulation Duration:"))
        self.adv_simulation_duration = QLineEdit("24")
        self.adv_simulation_duration.setMaximumWidth(80)
        duration_layout.addWidget(self.adv_simulation_duration)
        duration_layout.addWidget(QLabel("hours"))
        timeseries_layout.addLayout(duration_layout)
        
        # Number of output timesteps
        timesteps_layout = QHBoxLayout()
        timesteps_layout.addWidget(QLabel("Number of Output Timesteps:"))
        self.adv_output_timesteps = QLineEdit("10")
        self.adv_output_timesteps.setMaximumWidth(80)
        timesteps_layout.addWidget(self.adv_output_timesteps)
        timesteps_layout.addWidget(QLabel("outputs"))
        timeseries_layout.addLayout(timesteps_layout)
        
        # Output interval display (auto-calculated)
        self.adv_output_interval_label = QLabel("Output interval: 2.4 hours")
        self.adv_output_interval_label.setStyleSheet("color: #666; font-style: italic; padding: 5px;")
        timeseries_layout.addWidget(self.adv_output_interval_label)
        
        # Output options
        self.adv_create_animation = QCheckBox("🎬 Create time series animation")
        self.adv_create_animation.setChecked(True)  # Check by default
        self.adv_create_animation.setToolTip("Create animated controls for viewing flood progression over time")
        self.adv_create_animation.setStyleSheet("font-weight: bold; color: #0066cc;")
        timeseries_layout.addWidget(self.adv_create_animation)
        
        self.adv_export_timeseries = QCheckBox("Export time series data")
        timeseries_layout.addWidget(self.adv_export_timeseries)
        
        # Hydrograph input
        hydrograph_layout = QVBoxLayout()
        hydrograph_header = QHBoxLayout()
        hydrograph_header.addWidget(QLabel("Input Hydrograph:"))
        self.adv_use_hydrograph = QCheckBox("Use input hydrograph")
        hydrograph_header.addWidget(self.adv_use_hydrograph)
        hydrograph_layout.addLayout(hydrograph_header)
        
        hydrograph_file_layout = QHBoxLayout()
        self.adv_hydrograph_file = QLineEdit()
        self.adv_hydrograph_file.setEnabled(False)
        hydrograph_file_layout.addWidget(self.adv_hydrograph_file)
        self.adv_hydrograph_btn = QPushButton("Browse...")
        self.adv_hydrograph_btn.setEnabled(False)
        hydrograph_file_layout.addWidget(self.adv_hydrograph_btn)
        hydrograph_layout.addLayout(hydrograph_file_layout)
        timeseries_layout.addLayout(hydrograph_layout)
        
        group_box.setLayout(layout)
        return group_box
    
    def toggle_mode(self):
        """Switch between basic and advanced modes."""
        if self.basic_radio.isChecked():
            self.mode_stack.setCurrentIndex(0)
        else:
            self.mode_stack.setCurrentIndex(1)
    
    def connect_browse_buttons(self):
        """Connect all browse button signals."""
        # Basic mode browse buttons
        if hasattr(self, 'basic_dem_btn'):
            self.basic_dem_btn.clicked.connect(lambda: self.browse_file(self.basic_dem_path, "DEM file (*.tif *.tiff)"))
        if hasattr(self, 'basic_bathy_btn'):
            self.basic_bathy_btn.clicked.connect(self.browse_bathymetry_file)
        if hasattr(self, 'basic_soil_btn'):
            self.basic_soil_btn.clicked.connect(lambda: self.browse_file(self.basic_soil_path, "Soil file (*.shp *.gpkg)"))
        if hasattr(self, 'basic_output_folder_btn'):
            self.basic_output_folder_btn.clicked.connect(lambda: self.browse_folder(self.basic_output_folder))
        
        # Advanced mode browse buttons - CRITICAL for 2D models
        if hasattr(self, 'adv_dem_btn'):
            self.adv_dem_btn.clicked.connect(lambda: self.browse_file(self.adv_dem_path, "DEM file (*.tif *.tiff)"))
        if hasattr(self, 'adv_output_btn'):
            self.adv_output_btn.clicked.connect(lambda: self.browse_folder(self.adv_output_folder))
        if hasattr(self, 'adv_bathy_btn'):
            self.adv_bathy_btn.clicked.connect(self.browse_advanced_bathymetry_file)
    
    def connect_dynamic_ui_elements(self):
        """Connect sliders and other dynamic UI elements."""
        # Connect any sliders or dynamic elements if they exist
        pass
    
    def connect_equation_buttons(self):
        """Connect equation display buttons."""
        # Connect any equation buttons if they exist
        pass
    
    def connect_timestep_controls(self):
        """Connect timestep controls for real-time interval updates."""
        try:
            if hasattr(self, 'adv_simulation_duration'):
                self.adv_simulation_duration.textChanged.connect(self.update_output_interval)
            if hasattr(self, 'adv_output_timesteps'):
                self.adv_output_timesteps.textChanged.connect(self.update_output_interval)
            
            # Connect time series checkbox to enable/disable controls
            if hasattr(self, 'adv_enable_time_series') and hasattr(self, 'timeseries_container'):
                self.adv_enable_time_series.toggled.connect(self.toggle_time_series_controls)
        except Exception as e:
            print(f"Error connecting timestep controls: {e}")
    
    def toggle_time_series_controls(self, checked):
        """Enable/disable time series controls based on checkbox state."""
        if hasattr(self, 'timeseries_container'):
            self.timeseries_container.setEnabled(checked)
    
    def update_output_interval(self):
        """Update the output interval label when duration or timesteps change."""
        try:
            if hasattr(self, 'adv_simulation_duration') and hasattr(self, 'adv_output_timesteps'):
                duration = float(self.adv_simulation_duration.text())
                timesteps = int(self.adv_output_timesteps.text())
                
                if duration > 0 and timesteps > 0:
                    interval = duration / timesteps
                    if hasattr(self, 'adv_output_interval_label'):
                        if interval >= 1.0:
                            self.adv_output_interval_label.setText(f"Output interval: {interval:.1f} hours")
                        else:
                            minutes = interval * 60
                            self.adv_output_interval_label.setText(f"Output interval: {minutes:.1f} minutes")
        except (ValueError, ZeroDivisionError):
            if hasattr(self, 'adv_output_interval_label'):
                self.adv_output_interval_label.setText("Output interval: Check values")
        except Exception as e:
            print(f"Error updating output interval: {e}")
    
    def browse_file(self, line_edit, file_filter):
        """Open file dialog and set the selected file path."""
        file_path, _ = QFileDialog.getOpenFileName(self, "Select File", "", file_filter)
        if file_path:
            line_edit.setText(file_path)
    
    def browse_folder(self, line_edit):
        """Open folder dialog and set the selected folder path."""
        folder_path = QFileDialog.getExistingDirectory(self, "Select Output Folder")
        if folder_path:
            line_edit.setText(folder_path)
    
    def browse_bathymetry_file(self):
        """Open file dialog for bathymetry file and handle column selection for CSV files."""
        file_path, _ = QFileDialog.getOpenFileName(
            self, 
            "Select Bathymetry File", 
            "", 
            "All Bathymetry Files (*.csv *.txt *.shp *.gpkg);;CSV Files (*.csv *.txt);;Shapefiles (*.shp);;GeoPackage (*.gpkg)"
        )
        
        if file_path:
            self.basic_bathy_path.setText(file_path)
            
            # If it's a CSV file, open column selection dialog
            if file_path.lower().endswith(('.csv', '.txt')):
                try:
                    dialog = BathymetryColumnDialog(file_path, self)
                    if dialog.exec_() == QDialog.Accepted:
                        self.bathymetry_columns = dialog.get_selected_columns()
                        # Update the UI to show that columns have been configured
                        self.basic_bathy_path.setToolTip(
                            f"CSV file with columns: X={self.bathymetry_columns['x']}, "
                            f"Y={self.bathymetry_columns['y']}, Z={self.bathymetry_columns['z']}"
                        )
                    else:
                        # User cancelled column selection, clear the file path
                        self.basic_bathy_path.setText("")
                except Exception as e:
                    self.show_message(f"Error reading CSV file: {str(e)}")
                    self.basic_bathy_path.setText("")
            else:
                # For non-CSV files (shapefiles, geopackages), clear column info
                self.bathymetry_columns = {'x': None, 'y': None, 'z': None}
                self.basic_bathy_path.setToolTip("Shapefile or GeoPackage bathymetry data")
    
    def browse_advanced_bathymetry_file(self):
        """Open file dialog for advanced bathymetry file and handle column selection for CSV files."""
        file_path, _ = QFileDialog.getOpenFileName(
            self, 
            "Select Bathymetry File", 
            "", 
            "All Bathymetry Files (*.csv *.txt *.shp *.gpkg);;CSV Files (*.csv *.txt);;Shapefiles (*.shp);;GeoPackage (*.gpkg)"
        )
        
        if file_path:
            self.adv_bathy_path.setText(file_path)
            
            # Handle CSV column selection
            if file_path.lower().endswith(('.csv', '.txt')):
                dialog = BathymetryColumnDialog(file_path, self)
                if dialog.exec_() == QDialog.Accepted:
                    self.adv_bathymetry_columns = dialog.selected_columns
                    self.adv_bathy_path.setToolTip(f"CSV bathymetry data\nX: {self.adv_bathymetry_columns['x']}\nY: {self.adv_bathymetry_columns['y']}\nZ: {self.adv_bathymetry_columns['z']}")
                else:
                    # User cancelled column selection, clear the path
                    self.adv_bathy_path.setText("")
            else:
                # For non-CSV files (shapefiles, geopackages), clear column info
                self.adv_bathymetry_columns = {'x': None, 'y': None, 'z': None}
                self.adv_bathy_path.setToolTip("Shapefile or GeoPackage bathymetry data")

    def run_model(self):
        """Run the flood model with the current parameters."""
        try:
            # Import the model function
            from .model_hydraulic import calculate_flood_area
            
            # Initialize default timestep parameters
            simulation_duration_hours = 24.0
            output_timesteps = 10
            
            # Get parameters from UI based on current mode
            if self.basic_radio.isChecked():
                # Basic mode parameters - access UI elements directly
                dem_path = self.basic_dem_path.text().strip()
                output_folder = self.basic_output_folder.text().strip()
                
                # Debug print to verify DEM path
                print(f"DEBUG: DEM path from UI: '{dem_path}'")
                print(f"DEBUG: Output folder from UI: '{output_folder}'")
                
                # Get bathymetry information
                bathymetry_path, bathymetry_columns = self.get_bathymetry_info()
                
                # Get flow Q from UI
                flow_q_text = self.basic_flow_q.text().strip()
                try:
                    flow_q = float(flow_q_text) if flow_q_text else 100.0
                except ValueError:
                    flow_q = 100.0
                
                # Get duration from UI
                duration_text = self.basic_duration.text().strip()
                try:
                    duration_hours = float(duration_text) if duration_text else 24.0
                except ValueError:
                    duration_hours = 24.0
                
                # Water levels are automatically calculated - no user input needed
                water_levels = None  # Will be auto-generated in the model
                
                manning_n = 0.03  # Default Manning's n
                
            else:
                # Advanced mode parameters - NOW PROPERLY IMPLEMENTED
                dem_path = self.adv_dem_path.text().strip()
                output_folder = self.adv_output_folder.text().strip()
                
                # Get bathymetry information for advanced mode
                bathymetry_path = self.adv_bathy_path.text().strip() if self.adv_bathy_path.text().strip() else None
                bathymetry_columns = getattr(self, 'adv_bathymetry_columns', {'x': None, 'y': None, 'z': None})
                
                # Water levels are automatically calculated - no user input needed
                water_levels = None  # Will be auto-generated in the model
                
                # Get flow Q from advanced UI
                try:
                    flow_q = float(self.adv_flow_q.text().strip()) if self.adv_flow_q.text().strip() else 500.0
                except ValueError:
                    flow_q = 500.0
                
                # Get Manning's n from advanced UI
                try:
                    manning_n = float(self.adv_manning_n.text().strip()) if self.adv_manning_n.text().strip() else 0.03
                except ValueError:
                    manning_n = 0.03
                
                # Get modern timestep parameters
                try:
                    simulation_duration_hours = float(self.adv_simulation_duration.text()) if hasattr(self, 'adv_simulation_duration') and self.adv_simulation_duration.text() else 24.0
                    output_timesteps = int(self.adv_output_timesteps.text()) if hasattr(self, 'adv_output_timesteps') and self.adv_output_timesteps.text() else 10
                except (ValueError, AttributeError):
                    simulation_duration_hours = 24.0
                    output_timesteps = 10
                
                print(f"🕒 Using modern timestep system: {simulation_duration_hours} hours, {output_timesteps} outputs")
            
            # Validate inputs with better error messages
            print(f"🔍 VALIDATION: DEM path = '{dem_path}'")
            print(f"🔍 VALIDATION: Output folder = '{output_folder}'")
            print(f"🔍 VALIDATION: Basic mode selected = {self.basic_radio.isChecked()}")
            
            if not dem_path:
                error_msg = f"Error: Please select a DEM file. Current path is empty. Mode: {'Basic' if self.basic_radio.isChecked() else 'Advanced'}"
                self.show_message(error_msg)
                print(f"❌ ERROR: DEM path validation failed. Value: '{dem_path}'")
                return
                
            if not os.path.exists(dem_path):
                self.show_message(f"Error: DEM file does not exist: {dem_path}")
                print(f"ERROR: DEM file not found at: '{dem_path}'")
                return
                
            if not output_folder:
                self.show_message("Error: Please select an output folder.")
                print(f"ERROR: Output folder validation failed. Value: '{output_folder}'")
                return
            
            # Update progress
            self.progress_bar.setValue(10)
            self.progress_bar.setFormat("Starting simulation...")
            
            # Check if animation should be created
            if self.basic_radio.isChecked():
                # Basic mode - animation is optional, default to False
                create_animation = False
                print("🔍 DEBUG: Basic mode selected - animation disabled")
            else:
                # Advanced mode - check the animation checkbox
                checkbox = getattr(self, 'adv_create_animation', None)
                create_animation = bool(checkbox and checkbox.isChecked())
                print(f"🔍 DEBUG: Advanced mode - checkbox exists: {checkbox is not None}")
                if checkbox:
                    print(f"🔍 DEBUG: Checkbox checked: {checkbox.isChecked()}")
                else:
                    print("🔍 DEBUG: Checkbox not found!")
            
            print(f"🎬 Animation enabled: {create_animation}")
            print(f"🔍 DEBUG: Output folder: {output_folder}")
            
            # Run the model
            if self.basic_radio.isChecked():
                # Basic mode - simple run
                calculate_flood_area(
                    self.iface,
                    dem_path,
                    water_levels,
                    output_folder,
                    flow_q=flow_q,
                    manning_n=manning_n,
                    bathymetry_path=bathymetry_path,
                    bathymetry_columns=bathymetry_columns,
                    create_animation=create_animation
                )
            else:
                # Advanced mode - with timestep parameters
                calculate_flood_area(
                    self.iface,
                    dem_path,
                    water_levels,
                    output_folder,
                    flow_q=flow_q,
                    manning_n=manning_n,
                    bathymetry_path=bathymetry_path,
                    bathymetry_columns=bathymetry_columns,
                    simulation_duration_hours=simulation_duration_hours,
                    output_timesteps=output_timesteps,
                    create_animation=create_animation
                )
            
            # Complete
            self.progress_bar.setValue(100)
            self.progress_bar.setFormat("Complete!")
            self.show_message("Model run completed successfully!")
            
            # CRITICAL FIX: Launch animation if requested
            print(f"🔍 DEBUG: Model complete. Animation enabled: {create_animation}")
            if create_animation:
                try:
                    print("🎬 Launching animation controls...")
                    print(f"🔍 DEBUG: About to call launch_animation_controls with: {output_folder}")
                    
                    # Force check if animation data was actually created
                    animation_folder = os.path.join(output_folder, 'time_series_animation')
                    raster_folder = os.path.join(output_folder, 'rasters')
                    
                    print(f"🔍 DEBUG: Checking for animation folder: {animation_folder}")
                    print(f"🔍 DEBUG: Animation folder exists: {os.path.exists(animation_folder)}")
                    print(f"🔍 DEBUG: Checking for raster folder: {raster_folder}")
                    print(f"🔍 DEBUG: Raster folder exists: {os.path.exists(raster_folder)}")
                    
                    if os.path.exists(animation_folder) or os.path.exists(raster_folder):
                        print("✅ Animation data found - proceeding with launch")
                        self.launch_animation_controls(output_folder)
                        print("🔍 DEBUG: launch_animation_controls completed")
                    else:
                        print("❌ No animation data found - simulation may not have created animation files")
                        self.show_message("No animation data was created. Check that the simulation completed successfully.")
                        
                except Exception as e:
                    print(f"❌ Animation launch failed: {e}")
                    import traceback
                    traceback.print_exc()
                    self.show_message(f"Animation setup failed: {e}")
            else:
                print("🔍 DEBUG: Animation not enabled - skipping launch")
            
        except Exception as e:
            self.show_message(f"Error running model: {str(e)}")
            self.progress_bar.setValue(0)
            self.progress_bar.setFormat("Error")
    
    def show_message(self, message):
        """Show a message to the user."""
        if self.iface:
            self.iface.messageBar().pushMessage("FloodEngine", message)
        else:
            print(f"FloodEngine: {message}")
    
    def get_bathymetry_info(self):
        """Get bathymetry file path and column information."""
        bathy_path = self.basic_bathy_path.text().strip()
        if not bathy_path:
            return None, None
        
        # Return both file path and column mapping (for CSV files)
        columns = getattr(self, 'bathymetry_columns', {'x': None, 'y': None, 'z': None})
        return bathy_path, columns
    
    def launch_animation_controls(self, output_folder):
        """Launch animation controls after simulation completion."""
        print(f"🎬 Attempting to launch animation from: {output_folder}")
        
        try:
            # Check if animation window already exists and is visible
            if self.animation_window is not None and self.animation_window.isVisible():
                print("✅ Animation window already exists - bringing to front")
                self.animation_window.raise_()
                self.animation_window.activateWindow()
                self.show_message("Animation controls are already available!")
                return
            
            # Use the safe launcher that handles QGIS module reload issues
            from qgis_module_reload_helper import launch_animation_safe
            
            # Get the parent window for proper dialog management
            parent_window = None
            try:
                # Try to get QGIS main window first
                from qgis.utils import iface
                if iface and hasattr(iface, 'mainWindow') and iface.mainWindow():
                    parent_window = iface.mainWindow()
                    print("✅ Using QGIS main window as parent")
                else:
                    # Fall back to this widget's parent
                    parent_window = self.parent() if hasattr(self, 'parent') else None
                    print(f"✅ Using widget parent: {type(parent_window).__name__ if parent_window else 'None'}")
            except ImportError:
                # Not in QGIS, use this widget's parent
                parent_window = self.parent() if hasattr(self, 'parent') else None
                print(f"✅ Using widget parent (no QGIS): {type(parent_window).__name__ if parent_window else 'None'}")
            
            # Launch using the safe method
            result = launch_animation_safe(output_folder, parent_window)
            
            if result:
                print("✅ Animation controls launched successfully!")
                
                # Store the animation window reference for proper management
                self.animation_window = result
                print("✅ Stored animation window reference")
                
                # Store persistent reference in the UI to prevent garbage collection
                self._animation_dialog = result
                print("✅ Stored persistent reference to animation dialog")
                
                # Also store in dialog manager for extra persistence
                try:
                    from dialog_manager import store_animation_dialog
                    store_animation_dialog(result)
                    print("✅ Stored in dialog manager")
                except Exception as e:
                    print(f"⚠️ Could not store in dialog manager: {e}")
                
                self.show_message("Animation controls are now available!")
            else:
                print("❌ Animation launch failed")
                self.show_message("Animation launch failed - check console for details")
                
        except ImportError as e:
            print(f"❌ Cannot import animation launcher: {e}")
            self.show_message("Animation module not available")
        except Exception as e:
            print(f"❌ Unexpected animation error: {e}")
            import traceback
            traceback.print_exc()
            self.show_message(f"Animation error: {e}")
    
    def closeEvent(self, event):
        """Handle cleanup when the main dialog is closed."""
        # Clean up animation window if it exists
        if self.animation_window is not None:
            try:
                if self.animation_window.isVisible():
                    self.animation_window.close()
                self.animation_window = None
                print("✅ Animation window cleaned up")
            except Exception as e:
                print(f"⚠️ Error cleaning up animation window: {e}")
        
        # Call parent closeEvent
        super().closeEvent(event)
