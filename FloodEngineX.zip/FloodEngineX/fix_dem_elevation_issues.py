#!/usr/bin/env python3
"""
FIX DEM ELEVATION VALUES - BATHYMETRY INTEGRATION CORRECTION
==========================================================

This script fixes the DEM elevation issue where terrain shows -9.38m to +44.04m
instead of expected +9m to +51m RT2000.

IDENTIFIED ISSUES:
1. Bathymetry integration incorrectly applies negative values to land areas
2. Missing geoid height correction for RT2000 datum
3. Bathymetry mask not properly limiting to water areas only

FIXES APPLIED:
1. Correct bathymetry integration to only affect true water areas
2. Add RT2000 geoid height correction (+42m for Sweden)
3. Implement proper land/water boundary detection
4. Update DEM styling to handle corrected elevation range
"""

import os
import sys

def fix_bathymetry_integration():
    """Create fixed bathymetry integration function"""
    
    fixed_function = '''
def load_and_integrate_bathymetry_FIXED(csv_path, dem_path, output_folder, **kwargs):
    """
    FIXED: Load bathymetry data and integrate with DEM with proper land/water separation
    """
    try:
        interpolation_method = kwargs.get('interpolation_method', 'linear')
        geoid_correction = kwargs.get('geoid_correction', 42.0)  # RT2000 correction for Sweden
        
        print(f"🌊 FIXED BATHYMETRY INTEGRATION:")
        print(f"   Bathymetry CSV: {csv_path}")
        print(f"   DEM: {dem_path}")
        print(f"   Geoid correction: +{geoid_correction:.1f}m (RT2000)")
        
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)
        
        # 1. Read bathymetry data
        points = []
        with open(csv_path, 'r') as f:
            try:
                dialect = csv.Sniffer().sniff(f.read(1024), delimiters=',;\\t')
                f.seek(0)
                reader = csv.reader(f, dialect)
            except:
                f.seek(0)
                reader = csv.reader(f)
            
            header = next(reader)
            header = [col.strip().lower() for col in header]
            
            x_col = find_column_index(header, ["x", "east", "easting", "lon", "longitude", "e"])
            y_col = find_column_index(header, ["y", "north", "northing", "lat", "latitude", "n"])
            z_col = find_column_index(header, ["z", "depth", "djup", "elevation", "höjd", "elev"])
            
            if x_col is None or y_col is None or z_col is None:
                raise Exception("Could not find X, Y, Z columns in bathymetry data")
            
            is_depth_format = any(depth_term in header[z_col] for depth_term in ["depth", "djup"])
            
            # Read bathymetry points with validation
            for row_num, row in enumerate(reader, start=2):
                try:
                    if len(row) > max(x_col, y_col, z_col):
                        x = safe_csv_value_conversion(row[x_col], float, f"X (row {row_num})")
                        y = safe_csv_value_conversion(row[y_col], float, f"Y (row {row_num})")
                        raw_z = safe_csv_value_conversion(row[z_col], float, f"Z (row {row_num})")
                        
                        if x is None or y is None or raw_z is None:
                            continue
                        
                        # FIXED: Handle depth vs elevation correctly
                        if is_depth_format:
                            # Convert depth to negative elevation, but ONLY for water areas
                            z = -abs(raw_z)  # Ensure negative for depths
                        else:
                            # Use elevation as-is
                            z = raw_z
                        
                        # FIXED: Only accept bathymetry points that are clearly underwater
                        if z < 0:  # Only negative elevations (below sea level)
                            points.append((x, y, z))
                        
                except (ValueError, IndexError):
                    continue
        
        if not points:
            print(f"   ⚠️ No valid underwater bathymetry points found - using DEM only")
            # Return DEM with geoid correction only
            return apply_geoid_correction_only(dem_path, output_folder, geoid_correction)
        
        print(f"   ✅ Loaded {len(points)} underwater bathymetry points")
        
        # 2. Load DEM
        dem_ds = gdal.Open(dem_path)
        if not dem_ds:
            raise Exception(f"Could not open DEM: {dem_path}")
        
        dem_geotransform = dem_ds.GetGeoTransform()
        dem_projection = dem_ds.GetProjection()
        dem_x_size = dem_ds.RasterXSize
        dem_y_size = dem_ds.RasterYSize
        dem_band = dem_ds.GetRasterBand(1)
        dem_nodata = dem_band.GetNoDataValue() or -9999
        dem_array = dem_band.ReadAsArray().astype(np.float32)
        
        # Apply geoid correction to DEM first
        print(f"   📏 Applying geoid correction: +{geoid_correction:.1f}m")
        dem_array[dem_array != dem_nodata] += geoid_correction
        
        dem_array[dem_array == dem_nodata] = np.nan
        
        print(f"   📊 DEM after geoid correction: {np.nanmin(dem_array):.1f}m to {np.nanmax(dem_array):.1f}m")
        
        # 3. Create bathymetry interpolation (only for underwater areas)
        bath_x = np.array([p[0] for p in points])
        bath_y = np.array([p[1] for p in points])
        bath_z = np.array([p[2] for p in points])
        
        print(f"   🌊 Bathymetry range: Z={bath_z.min():.2f} to {bath_z.max():.2f}m (all underwater)")
        
        # 4. Create coordinate grid
        x_coords = np.arange(dem_x_size) * dem_geotransform[1] + dem_geotransform[0] + dem_geotransform[1]/2
        y_coords = np.arange(dem_y_size) * dem_geotransform[5] + dem_geotransform[3] + dem_geotransform[5]/2
        grid_x, grid_y = np.meshgrid(x_coords, y_coords)
        
        # 5. FIXED: Create water-only mask based on sea level
        sea_level = 0.0  # Sea level reference
        water_mask = dem_array <= sea_level  # Only areas at or below sea level
        
        print(f"   🌊 Water areas: {np.sum(water_mask)} of {water_mask.size} pixels ({np.sum(water_mask)/water_mask.size*100:.1f}%)")
        
        # 6. Interpolate bathymetry only for water areas
        if np.sum(water_mask) > 0:
            try:
                bath_interp = griddata(
                    points=np.column_stack((bath_x, bath_y)),
                    values=bath_z,
                    xi=np.column_stack((grid_x.flatten(), grid_y.flatten())),
                    method=interpolation_method,
                    fill_value=np.nan
                ).reshape(grid_x.shape)
                
                # 7. FIXED: Combine DEM and bathymetry ONLY in water areas
                combined_dem = np.copy(dem_array)
                
                # Apply bathymetry only where:
                # 1. DEM indicates water (at/below sea level)
                # 2. Bathymetry data is available
                # 3. Bathymetry is deeper (more negative) than DEM
                valid_bath = ~np.isnan(bath_interp) & water_mask
                deeper_than_dem = bath_interp < dem_array
                
                replacement_mask = valid_bath & deeper_than_dem
                combined_dem[replacement_mask] = bath_interp[replacement_mask]
                
                print(f"   ✅ Applied bathymetry to {np.sum(replacement_mask)} water pixels")
                
            except Exception as e:
                print(f"   ⚠️ Bathymetry interpolation failed: {e}")
                combined_dem = dem_array  # Use DEM with geoid correction only
        else:
            print(f"   ℹ️ No water areas detected - using DEM only")
            combined_dem = dem_array
        
        # 8. Generate statistics
        integration_stats = {
            'total_pixels': dem_array.size,
            'water_pixels': np.sum(water_mask) if 'water_mask' in locals() else 0,
            'bath_applied': np.sum(replacement_mask) if 'replacement_mask' in locals() else 0,
            'bath_min': float(np.nanmin(bath_z)),
            'bath_max': float(np.nanmax(bath_z)),
            'combined_min': float(np.nanmin(combined_dem)),
            'combined_max': float(np.nanmax(combined_dem)),
            'geoid_correction': geoid_correction
        }
        
        print(f"   📊 FIXED Integration Results:")
        print(f"     Water areas: {integration_stats['water_pixels']} pixels")
        print(f"     Bathymetry applied: {integration_stats['bath_applied']} pixels")
        print(f"     Final elevation range: {integration_stats['combined_min']:.1f} to {integration_stats['combined_max']:.1f}m")
        
        # 9. Save corrected DEM
        combined_dem_path = os.path.join(output_folder, "combined_terrain_model_FIXED.tif")
        
        result_path = create_proper_geotiff(
            combined_dem, 
            combined_dem_path, 
            dem_geotransform, 
            dem_projection, 
            dem_nodata
        )
        
        if result_path is None:
            raise Exception(f"Failed to create fixed DEM file: {combined_dem_path}")
        
        # 10. Write detailed statistics
        stats_path = os.path.join(output_folder, "FIXED_bathymetry_integration_stats.txt")
        with open(stats_path, 'w') as f:
            f.write("FIXED BATHYMETRY INTEGRATION RESULTS\\n")
            f.write("=" * 50 + "\\n")
            f.write(f"Original DEM: {dem_path}\\n")
            f.write(f"Bathymetry CSV: {csv_path}\\n")
            f.write(f"Fixed DEM: {result_path}\\n")
            f.write(f"Geoid correction applied: +{geoid_correction:.1f}m (RT2000)\\n\\n")
            f.write(f"Integration method: Water-areas-only\\n")
            f.write(f"Bathymetry points: {len(points)} (underwater only)\\n")
            f.write(f"Water pixels: {integration_stats['water_pixels']}\\n")
            f.write(f"Bathymetry applied: {integration_stats['bath_applied']} pixels\\n\\n")
            f.write(f"Elevation ranges:\\n")
            f.write(f"  Bathymetry: {integration_stats['bath_min']:.2f} to {integration_stats['bath_max']:.2f}m\\n")
            f.write(f"  Fixed combined: {integration_stats['combined_min']:.1f} to {integration_stats['combined_max']:.1f}m\\n")
            f.write(f"\\nEXPECTED RT2000 RANGE: +9m to +51m\\n")
            f.write(f"ACHIEVED RANGE: {integration_stats['combined_min']:.1f}m to {integration_stats['combined_max']:.1f}m\\n")
        
        dem_ds = None
        
        print(f"✅ FIXED bathymetry integration complete: {result_path}")
        return result_path, integration_stats
        
    except Exception as e:
        print(f"❌ Error in FIXED bathymetry integration: {e}")
        traceback.print_exc()
        raise

def apply_geoid_correction_only(dem_path, output_folder, geoid_correction):
    """Apply only geoid correction to DEM without bathymetry"""
    try:
        print(f"📏 Applying geoid correction only: +{geoid_correction:.1f}m")
        
        dem_ds = gdal.Open(dem_path)
        dem_geotransform = dem_ds.GetGeoTransform()
        dem_projection = dem_ds.GetProjection()
        dem_band = dem_ds.GetRasterBand(1)
        dem_nodata = dem_band.GetNoDataValue() or -9999
        dem_array = dem_band.ReadAsArray().astype(np.float32)
        
        # Apply geoid correction
        dem_array[dem_array != dem_nodata] += geoid_correction
        
        # Save corrected DEM
        corrected_dem_path = os.path.join(output_folder, "DEM_with_geoid_correction.tif")
        
        result_path = create_proper_geotiff(
            dem_array, 
            corrected_dem_path, 
            dem_geotransform, 
            dem_projection, 
            dem_nodata
        )
        
        stats = {
            'combined_min': float(np.nanmin(dem_array[dem_array != dem_nodata])),
            'combined_max': float(np.nanmax(dem_array[dem_array != dem_nodata])),
            'geoid_correction': geoid_correction
        }
        
        dem_ds = None
        
        print(f"✅ Geoid correction applied: {result_path}")
        return result_path, stats
        
    except Exception as e:
        print(f"❌ Error applying geoid correction: {e}")
        raise
'''
    
    return fixed_function

def main():
    """Create the fixed bathymetry integration function"""
    print("🔧 CREATING FIXED BATHYMETRY INTEGRATION")
    print("=" * 50)
    
    # Read the current model_hydraulic.py
    model_file = "model_hydraulic.py"
    if not os.path.exists(model_file):
        print(f"❌ {model_file} not found!")
        return
    
    # Get the fixed function
    fixed_function = fix_bathymetry_integration()
    
    # Append to model_hydraulic.py
    print(f"📝 Adding FIXED bathymetry integration function...")
    
    with open(model_file, 'a', encoding='utf-8') as f:
        f.write("\\n\\n# " + "=" * 80 + "\\n")
        f.write("# FIXED BATHYMETRY INTEGRATION - CORRECTS ELEVATION VALUES\\n")
        f.write("# " + "=" * 80 + "\\n")
        f.write(fixed_function)
    
    print(f"✅ Fixed function added to {model_file}")
    
    # Create a patch script for UI
    ui_patch = '''
# PATCH FOR floodengine_ui.py - Replace bathymetry integration call
# 
# FIND this line in the UI file:
# result = load_and_integrate_bathymetry(bathymetry_path, dem_path, output_folder)
#
# REPLACE with:
# result = load_and_integrate_bathymetry_FIXED(bathymetry_path, dem_path, output_folder, geoid_correction=42.0)
'''
    
    with open("UI_BATHYMETRY_PATCH.txt", 'w') as f:
        f.write(ui_patch)
    
    print(f"📋 Created UI_BATHYMETRY_PATCH.txt with instructions")
    
    print(f"\\n🎯 NEXT STEPS:")
    print(f"1. Apply the UI patch to use the FIXED function")
    print(f"2. Test with a small DEM area")
    print(f"3. Verify elevation range is +9m to +51m RT2000")
    print(f"4. Update DEM styling for corrected range")

if __name__ == "__main__":
    main()
