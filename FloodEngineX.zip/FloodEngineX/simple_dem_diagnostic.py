#!/usr/bin/env python3
"""
SIMPLIFIED DEM ELEVATION DIAGNOSTIC
===================================

Identifies why DEM shows -9.38m to +44.04m instead of expected +9m to +51m RT2000
"""

import os
import sys

def investigate_elevation_issues():
    """Investigate DEM elevation value problems"""
    print("🔧 DEM ELEVATION ISSUES DIAGNOSTIC")
    print("=" * 60)
    
    print("\n📊 PROBLEM SUMMARY:")
    print("Expected elevation range (RT2000): +9m to +51m above sea level")
    print("Actual elevation range (Current):  -9.38m to +44.04m")
    print("File: combined_terrain_model.tif")
    
    print("\n📈 VALUE ANALYSIS:")
    expected_min = 9.0
    expected_max = 51.0
    actual_min = -9.38
    actual_max = 44.04
    
    min_diff = actual_min - expected_min  # -18.38m
    max_diff = actual_max - expected_max  # -6.96m
    
    print(f"Minimum elevation error: {min_diff:.2f}m (too low)")
    print(f"Maximum elevation error: {max_diff:.2f}m (too low)")
    print(f"Expected range: {expected_max - expected_min:.0f}m")
    print(f"Actual range: {actual_max - actual_min:.2f}m")
    
    print("\n🔍 MOST LIKELY CAUSES:")
    print("1. 🌊 BATHYMETRY INTEGRATION ERROR")
    print("   - Negative depth values incorrectly applied to land elevation")
    print("   - Should only apply to water areas, not entire DEM")
    
    print("\n2. 📏 VERTICAL DATUM MISMATCH")
    print("   - RT2000 vs WGS84 ellipsoid height difference ~40-45m")
    print("   - Missing geoid height correction")
    
    print("\n3. 🔄 COORDINATE SYSTEM TRANSFORMATION")
    print("   - Incorrect height datum transformation")
    print("   - Wrong vertical coordinate reference system")
    
    print("\n4. 📊 DATA PROCESSING ERROR")
    print("   - NoData values (-9999) incorrectly processed")
    print("   - Wrong offset or scaling applied")
    
    print("\n🎯 SPECIFIC ISSUES TO CHECK:")
    
    # Check for files indicating problem source
    output_dirs = [
        r"C:\Plugin\VSCode\output",
        r"C:\Users\david\OneDrive\Dokument\GIS\FloodEngine\VSCode\output"
    ]
    
    print("\n📁 CHECKING OUTPUT DIRECTORIES:")
    for output_dir in output_dirs:
        if os.path.exists(output_dir):
            print(f"✅ Found: {output_dir}")
            
            # Look for timestep folders
            try:
                subdirs = [d for d in os.listdir(output_dir) if os.path.isdir(os.path.join(output_dir, d))]
                timestep_dirs = [d for d in subdirs if 'timestep' in d.lower()]
                
                if timestep_dirs:
                    print(f"   📂 Timestep directories: {len(timestep_dirs)}")
                    latest_dir = max(timestep_dirs)
                    print(f"   📅 Latest: {latest_dir}")
                    
                    # Check for combined DEM
                    latest_path = os.path.join(output_dir, latest_dir)
                    files = os.listdir(latest_path)
                    
                    dem_files = [f for f in files if 'combined' in f.lower() and f.endswith('.tif')]
                    bathymetry_files = [f for f in files if 'bath' in f.lower()]
                    
                    print(f"   🗻 DEM files: {dem_files}")
                    print(f"   🌊 Bathymetry files: {bathymetry_files}")
                    
            except Exception as e:
                print(f"   ❌ Error reading directory: {e}")
        else:
            print(f"❌ Not found: {output_dir}")

def check_model_hydraulic_bathymetry_integration():
    """Check bathymetry integration code for issues"""
    print("\n🔍 CHECKING BATHYMETRY INTEGRATION CODE:")
    
    model_file = "model_hydraulic.py"
    if os.path.exists(model_file):
        try:
            with open(model_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Look for bathymetry integration functions
            bath_functions = []
            lines = content.split('\n')
            
            for i, line in enumerate(lines):
                if 'def ' in line and ('bath' in line.lower() or 'integrate' in line.lower()):
                    bath_functions.append((i+1, line.strip()))
            
            print(f"📋 Found {len(bath_functions)} bathymetry-related functions:")
            for line_num, func_line in bath_functions:
                print(f"   Line {line_num}: {func_line}")
            
            # Check for negative value handling
            negative_handling = []
            for i, line in enumerate(lines):
                if any(keyword in line.lower() for keyword in ['negative', '-', 'below', 'depth']):
                    if any(context in line.lower() for context in ['elevation', 'height', 'dem', 'bathymetry']):
                        negative_handling.append((i+1, line.strip()))
            
            print(f"\n⚠️  Lines potentially handling negative values: {len(negative_handling)}")
            for line_num, line_content in negative_handling[:5]:  # Show first 5
                print(f"   Line {line_num}: {line_content}")
                
        except Exception as e:
            print(f"❌ Error reading model file: {e}")
    else:
        print(f"❌ model_hydraulic.py not found")

def suggest_fixes():
    """Suggest specific fixes for elevation issues"""
    print("\n🔧 RECOMMENDED FIXES:")
    print("=" * 30)
    
    print("1. 🌊 FIX BATHYMETRY INTEGRATION:")
    print("   - Ensure bathymetry only affects water areas")
    print("   - Don't apply negative depths to land elevation")
    print("   - Use proper mask for water vs land areas")
    
    print("\n2. 📏 ADD GEOID HEIGHT CORRECTION:")
    print("   - For Sweden/RT2000: add ~40-45m correction")
    print("   - Convert from ellipsoid height to orthometric height")
    print("   - Use SWEN17_RH2000.gtx geoid model if available")
    
    print("\n3. 🎯 VALIDATE SOURCE DATA:")
    print("   - Check original DEM elevation range")
    print("   - Ensure bathymetry CSV has correct sign convention")
    print("   - Verify coordinate system is EPSG:3006 (SWEREF99 TM)")
    
    print("\n4. 🔧 UPDATE DEM STYLING:")
    print("   - Fix color scheme to handle actual elevation range")
    print("   - Use proper sea level reference (0m)")
    print("   - Apply terrain colors for positive elevations")
    
    print("\n5. 💾 CREATE CORRECTED DEM:")
    print("   - Add offset to bring elevations to RT2000 levels")
    print("   - Possible offset: +18.38m to fix minimum")
    print("   - Verify with known elevation benchmarks")

def main():
    """Main function"""
    investigate_elevation_issues()
    check_model_hydraulic_bathymetry_integration()
    suggest_fixes()
    
    print(f"\n✅ NEXT STEPS:")
    print("1. Check bathymetry integration function")
    print("2. Add geoid height correction")
    print("3. Validate source DEM data")
    print("4. Test with corrected elevation offset")

if __name__ == "__main__":
    main()
