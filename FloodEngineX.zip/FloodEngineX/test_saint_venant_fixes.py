"""
Test script to validate the Saint-Venant solver fixes.
Tests the critical components that were causing unrealistic velocities.
"""

import numpy as np
import sys
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

def test_timestep_calculation():
    """Test the improved timestep calculation."""
    logger.info("Testing timestep calculation...")
    
    # Mock the necessary parts of SaintVenant2D for testing
    class MockSaintVenant:
        def __init__(self):
            self.dx = 10.0
            self.dy = 10.0
            self.g = 9.81
            self.epsilon = 1e-6
            self.min_depth = 0.001
            self.h = np.ones((50, 50)) * 1.0
            self.u = np.zeros((50, 50))
            self.v = np.zeros((50, 50))
        
        def calculate_timestep(self):
            """Conservative timestep calculation."""
            max_depth = np.nanmax(self.h)
            if max_depth < self.min_depth:
                return 0.1
                
            wet_mask = self.h > self.min_depth
            if not np.any(wet_mask):
                return 0.1
            
            max_u = np.nanmax(np.abs(self.u[wet_mask]))
            max_v = np.nanmax(np.abs(self.v[wet_mask]))
            max_wave_speed = np.sqrt(self.g * max_depth)
            
            cfl_factor = 0.25  # Conservative
            
            dt_x = cfl_factor * self.dx / (max_u + max_wave_speed + self.epsilon)
            dt_y = cfl_factor * self.dy / (max_v + max_wave_speed + self.epsilon)
            
            dt = min(dt_x, dt_y)
            
            max_dt = 0.5
            min_dt = 0.001
            
            if max_depth > 0.5 or max_u > 1.0 or max_v > 1.0:
                max_dt = 0.2
            
            max_velocity = max(max_u, max_v)
            if max_velocity > 2.0:
                max_dt = 0.05
            
            return max(min_dt, min(dt, max_dt))
    
    # Create test model
    model = MockSaintVenant()
    
    # Test 1: Low velocity case
    model.u[25, 25] = 0.5  # 0.5 m/s
    model.v[25, 25] = 0.5  # 0.5 m/s
    dt_low = model.calculate_timestep()
    logger.info(f"Low velocity timestep: {dt_low:.4f} s")
    
    # Test 2: High velocity case
    model.u[25, 25] = 3.0  # 3.0 m/s
    model.v[25, 25] = 2.0  # 2.0 m/s
    dt_high = model.calculate_timestep()
    logger.info(f"High velocity timestep: {dt_high:.4f} s")
    
    # Test 3: Very high velocity case
    model.u[25, 25] = 5.0  # 5.0 m/s
    model.v[25, 25] = 4.0  # 4.0 m/s
    dt_very_high = model.calculate_timestep()
    logger.info(f"Very high velocity timestep: {dt_very_high:.4f} s")
    
    # Assertions
    assert dt_high < dt_low, "High velocity should result in smaller timestep"
    assert dt_very_high <= dt_high, "Very high velocity should result in equal or smaller timestep"
    assert dt_low <= 0.5, "Timestep should be reasonably small"
    assert dt_very_high <= 0.05, "Very high velocity should give very small timestep"
    
    logger.info("✅ Timestep calculation test passed!")
    return True

def test_velocity_limiting():
    """Test velocity limiting functionality."""
    logger.info("Testing velocity limiting...")
    
    class MockSaintVenant:
        def __init__(self):
            self.g = 9.81
            self.min_depth = 0.001
            self.h = np.ones((10, 10)) * 2.0
            self.u = np.zeros((10, 10))
            self.v = np.zeros((10, 10))
            self.qx = np.zeros((10, 10))
            self.qy = np.zeros((10, 10))
        
        def apply_velocity_limiting(self):
            """Apply realistic velocity limits."""
            mask = self.h > self.min_depth
            
            # Calculate velocities
            self.u[mask] = self.qx[mask] / self.h[mask]
            self.v[mask] = self.qy[mask] / self.h[mask]
            
            # Realistic velocity limits
            max_vel = 3.0  # Maximum realistic velocity
            extreme_vel = 5.0  # Absolute maximum
            
            # Apply graduated velocity limiting
            vel_magnitude = np.sqrt(self.u**2 + self.v**2)
            
            # First level: soft limiting at 3 m/s
            over_limit = vel_magnitude > max_vel
            if np.any(over_limit):
                scale_factor = max_vel / vel_magnitude[over_limit]
                self.u[over_limit] *= scale_factor
                self.v[over_limit] *= scale_factor
                self.qx[over_limit] = self.u[over_limit] * self.h[over_limit]
                self.qy[over_limit] = self.v[over_limit] * self.h[over_limit]
            
            # Second level: hard limiting at 5 m/s
            vel_magnitude = np.sqrt(self.u**2 + self.v**2)
            extreme_over_limit = vel_magnitude > extreme_vel
            if np.any(extreme_over_limit):
                scale_factor = extreme_vel / vel_magnitude[extreme_over_limit]
                self.u[extreme_over_limit] *= scale_factor
                self.v[extreme_over_limit] *= scale_factor
                self.qx[extreme_over_limit] = self.u[extreme_over_limit] * self.h[extreme_over_limit]
                self.qy[extreme_over_limit] = self.v[extreme_over_limit] * self.h[extreme_over_limit]
            
            # Froude number limiting
            froude_limit = 1.5
            if np.any(mask):
                froude_numbers = vel_magnitude[mask] / np.sqrt(self.g * self.h[mask])
                over_froude = froude_numbers > froude_limit
                
                if np.any(over_froude):
                    mask_indices = np.where(mask)
                    froude_over_indices = (mask_indices[0][over_froude], mask_indices[1][over_froude])
                    
                    scale_factor = froude_limit / froude_numbers[over_froude]
                    self.u[froude_over_indices] *= scale_factor
                    self.v[froude_over_indices] *= scale_factor
                    self.qx[froude_over_indices] = self.u[froude_over_indices] * self.h[froude_over_indices]
                    self.qy[froude_over_indices] = self.v[froude_over_indices] * self.h[froude_over_indices]
            
            return np.sqrt(self.u**2 + self.v**2)
    
    # Create test model
    model = MockSaintVenant()
    
    # Test 1: Extreme unrealistic velocity
    model.qx[5, 5] = 20.0  # Would give 10 m/s velocity
    model.qy[5, 5] = 20.0  # Would give 10 m/s velocity
    
    vel_magnitude = model.apply_velocity_limiting()
    final_vel = vel_magnitude[5, 5]
    
    logger.info(f"Original velocity would be: {np.sqrt(20**2 + 20**2)/2:.2f} m/s")
    logger.info(f"Limited velocity: {final_vel:.2f} m/s")
    
    # Test 2: Moderately high velocity
    model.qx[3, 3] = 8.0   # Would give 4 m/s velocity
    model.qy[3, 3] = 6.0   # Would give 3 m/s velocity
    
    vel_magnitude = model.apply_velocity_limiting()
    moderate_vel = vel_magnitude[3, 3]
    
    logger.info(f"Moderate velocity limited to: {moderate_vel:.2f} m/s")
    
    # Assertions
    assert final_vel <= 5.0, f"Velocity should be limited to 5 m/s, got {final_vel:.2f}"
    assert moderate_vel <= 3.0, f"Moderate velocity should be limited to 3 m/s, got {moderate_vel:.2f}"
    assert final_vel > 0, "Velocity should be positive"
    
    logger.info("✅ Velocity limiting test passed!")
    return True

def test_cfl_compliance():
    """Test that the CFL condition is properly enforced."""
    logger.info("Testing CFL compliance...")
    
    # Test parameters
    dx = 5.0  # 5m cell size
    dy = 5.0  # 5m cell size
    g = 9.81
    
    # Test scenarios
    scenarios = [
        {"depth": 0.5, "velocity": 1.0, "name": "Shallow slow flow"},
        {"depth": 2.0, "velocity": 2.0, "name": "Deep moderate flow"},
        {"depth": 1.0, "velocity": 4.0, "name": "Fast flow"},
    ]
    
    for scenario in scenarios:
        h = scenario["depth"]
        v = scenario["velocity"]
        name = scenario["name"]
        
        # Calculate wave speed
        c = np.sqrt(g * h)
        
        # CFL condition: dt <= CFL * dx / (v + c)
        cfl_factor = 0.25
        dt_max_cfl = cfl_factor * dx / (v + c)
        
        # Our conservative limits
        max_dt = 0.5
        if h > 0.5 or v > 1.0:
            max_dt = 0.2
        if v > 2.0:
            max_dt = 0.05
        
        dt_actual = min(dt_max_cfl, max_dt)
        
        logger.info(f"{name}: h={h}m, v={v}m/s, c={c:.2f}m/s, dt={dt_actual:.4f}s")
        
        # Check CFL compliance
        cfl_number = dt_actual * (v + c) / dx
        assert cfl_number <= 0.25, f"CFL number {cfl_number:.3f} exceeds limit for {name}"
    
    logger.info("✅ CFL compliance test passed!")
    return True

def test_froude_number_calculation():
    """Test Froude number calculation and limiting."""
    logger.info("Testing Froude number calculation...")
    
    g = 9.81
    
    # Test cases
    test_cases = [
        {"depth": 1.0, "velocity": 2.0, "expected_froude": 2.0/np.sqrt(g)},
        {"depth": 0.5, "velocity": 1.0, "expected_froude": 1.0/np.sqrt(g*0.5)},
        {"depth": 2.0, "velocity": 3.0, "expected_froude": 3.0/np.sqrt(g*2.0)},
    ]
    
    for case in test_cases:
        h = case["depth"]
        v = case["velocity"]
        expected_fr = case["expected_froude"]
        
        # Calculate Froude number
        calculated_fr = v / np.sqrt(g * h)
        
        logger.info(f"Depth: {h}m, Velocity: {v}m/s, Froude: {calculated_fr:.2f}")
        
        # Check calculation
        assert abs(calculated_fr - expected_fr) < 0.01, f"Froude calculation error"
        
        # Check if limiting would be applied
        if calculated_fr > 1.5:
            limited_velocity = 1.5 * np.sqrt(g * h)
            logger.info(f"  Would limit velocity to: {limited_velocity:.2f} m/s")
            assert limited_velocity < v, "Limited velocity should be less than original"
    
    logger.info("✅ Froude number test passed!")
    return True

def run_all_tests():
    """Run all validation tests."""
    logger.info("Running Saint-Venant solver validation tests...")
    logger.info("=" * 50)
    
    tests = [
        test_timestep_calculation,
        test_velocity_limiting,
        test_cfl_compliance,
        test_froude_number_calculation,
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            if test():
                passed += 1
            else:
                failed += 1
        except Exception as e:
            logger.error(f"Test {test.__name__} failed with error: {e}")
            failed += 1
    
    logger.info("=" * 50)
    logger.info(f"Test Results: {passed} passed, {failed} failed")
    
    if failed == 0:
        logger.info("🎉 All tests passed! The Saint-Venant solver fixes are working correctly.")
        return True
    else:
        logger.error("❌ Some tests failed. Please check the implementation.")
        return False

if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
