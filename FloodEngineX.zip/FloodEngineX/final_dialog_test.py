#!/usr/bin/env python3
"""
FINAL ANIMATION DIALOG TEST
===========================
"""

import sys
import os
sys.path.insert(0, '.')

def final_dialog_test():
    """Final test - just launch the dialog and see if it appears."""
    print("🎯 FINAL ANIMATION DIALOG TEST")
    print("=" * 40)
    
    try:
        from launch_animation import launch_animation_from_folder
        
        output_folder = 'C:/Plugin/VSCode/output'
        
        print("🚀 Launching animation dialog...")
        result = launch_animation_from_folder(output_folder, standalone=True)
        
        if result:
            print("✅ DIALOG LAUNCHED!")
            print("👀 Check if you can see an animation window!")
            print("📝 The dialog should be visible even if Python shows it as 'deleted'")
            
            # Keep the script running for a bit
            import time
            print("⏱️ Keeping script alive for 10 seconds...")
            for i in range(10):
                print(f"   {10-i} seconds remaining...")
                time.sleep(1)
            
            print("✅ Test completed - dialog should be persistent now")
            return True
        else:
            print("❌ Dialog launch failed")
            return False
            
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

if __name__ == "__main__":
    success = final_dialog_test()
    if success:
        print("\n🎉 CHECK YOUR SCREEN FOR THE ANIMATION DIALOG!")
    else:
        print("\n❌ Dialog test failed")
