# -*- coding: utf-8 -*-
"""
FloodEngine v4.0 - Precipitation Input Module
==============================================

This module provides comprehensive precipitation input capabilities for FloodEngine's
flood modeling system. Supports multiple precipitation sources, formats, and 
rainfall-runoff modeling for realistic flood simulation scenarios.

Features:
- Multiple precipitation input formats (CSV, NetCDF, GRIB, JSON)
- Spatial interpolation for irregular precipitation data
- Temporal interpolation for varying time steps
- Rainfall-runoff coefficient modeling
- Real-time weather data integration
- Precipitation scenario generation
- Storm pattern analysis and design storms

Author: FloodEngine Development Team
Date: June 7, 2025
Version: 4.0
"""

import numpy as np
import os
import sys
import json
import csv
import time
from datetime import datetime, timedelta
from typing import Optional, Tuple, Dict, Any, List, Union
import logging
from scipy.interpolate import griddata, interp1d
from scipy.ndimage import gaussian_filter

# Attempt to import optional dependencies
try:
    import netCDF4 as nc
    NETCDF_AVAILABLE = True
except ImportError:
    NETCDF_AVAILABLE = False
    nc = None

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False
    requests = None

class PrecipitationData:
    """
    Container class for precipitation data with spatial and temporal components.
    """
    
    def __init__(self, name: str, description: str = ""):
        """
        Initialize precipitation data container.
        
        Args:
            name: Name identifier for the precipitation dataset
            description: Optional description of the dataset
        """
        self.name = name
        self.description = description
        self.spatial_data = {}  # Spatial precipitation fields
        self.temporal_data = {}  # Time series data
        self.metadata = {
            'created': datetime.now().isoformat(),
            'units': 'mm/hr',
            'coordinate_system': 'SWEREF99 TM',
            'interpolation_method': 'linear'
        }
        self.logger = logging.getLogger(__name__)
    
    def add_spatial_field(self, timestamp: datetime, precipitation_grid: np.ndarray, 
                         x_coords: np.ndarray, y_coords: np.ndarray):
        """
        Add spatial precipitation field for specific timestamp.
        
        Args:
            timestamp: Time of precipitation measurement
            precipitation_grid: 2D array of precipitation values (mm/hr)
            x_coords: X coordinates of grid points
            y_coords: Y coordinates of grid points
        """
        time_key = timestamp.isoformat()
        self.spatial_data[time_key] = {
            'precipitation': precipitation_grid,
            'x_coords': x_coords,
            'y_coords': y_coords,
            'timestamp': timestamp
        }
        
    def add_point_data(self, station_id: str, x: float, y: float, 
                      time_series: List[Tuple[datetime, float]]):
        """
        Add point precipitation data from weather station.
        
        Args:
            station_id: Unique identifier for weather station
            x: X coordinate of station
            y: Y coordinate of station
            time_series: List of (timestamp, precipitation_rate) tuples
        """
        self.temporal_data[station_id] = {
            'x': x,
            'y': y,
            'time_series': time_series,
            'total_records': len(time_series)
        }

class PrecipitationProcessor:
    """
    Main processor for handling precipitation input and conversion to flood model forcing.
    """
    
    def __init__(self, dem_extent: Tuple[float, float, float, float],
                 dem_resolution: Tuple[float, float]):
        """
        Initialize precipitation processor for specific DEM domain.
        
        Args:
            dem_extent: (xmin, ymin, xmax, ymax) in DEM coordinate system
            dem_resolution: (dx, dy) DEM grid spacing
        """
        self.dem_extent = dem_extent
        self.dem_resolution = dem_resolution
        self.dem_grid_x, self.dem_grid_y = self._create_dem_grid()
        
        # Runoff coefficients for different land uses
        self.runoff_coefficients = {
            'urban_dense': 0.85,
            'urban_medium': 0.70,
            'urban_low': 0.50,
            'agricultural': 0.30,
            'forest': 0.15,
            'grassland': 0.25,
            'water': 1.00,
            'impervious': 0.95,
            'default': 0.40
        }
        
        self.logger = logging.getLogger(__name__)
        
    def _create_dem_grid(self) -> Tuple[np.ndarray, np.ndarray]:
        """Create coordinate grids matching DEM extent and resolution."""
        xmin, ymin, xmax, ymax = self.dem_extent
        dx, dy = self.dem_resolution
        
        # Create coordinate arrays
        x = np.arange(xmin, xmax + dx, dx)
        y = np.arange(ymin, ymax + dy, dy)
        
        # Create meshgrid
        X, Y = np.meshgrid(x, y)
        
        return X, Y
    
    def load_precipitation_csv(self, csv_file: str, format_type: str = "point") -> PrecipitationData:
        """
        Load precipitation data from CSV file.
        
        Args:
            csv_file: Path to CSV file
            format_type: "point" for station data, "grid" for gridded data
            
        Returns:
            PrecipitationData object with loaded data
        """
        precip_data = PrecipitationData(os.path.basename(csv_file))
        
        try:
            with open(csv_file, 'r', newline='', encoding='utf-8') as file:
                reader = csv.DictReader(file)
                
                if format_type == "point":
                    self._load_point_csv(reader, precip_data)
                elif format_type == "grid":
                    self._load_grid_csv(reader, precip_data)
                else:
                    raise ValueError(f"Unknown format_type: {format_type}")
                    
        except Exception as e:
            self.logger.error(f"Error loading CSV file {csv_file}: {e}")
            raise
            
        return precip_data
    
    def _load_point_csv(self, reader, precip_data):
        """Load point precipitation data from CSV reader."""
        # Expected format: station_id, x, y, timestamp, precipitation_mm_hr
        stations = {}
        
        for row in reader:
            station_id = row['station_id']
            x = float(row['x'])
            y = float(row['y'])
            timestamp = datetime.fromisoformat(row['timestamp'])
            precip_rate = float(row['precipitation_mm_hr'])
            
            if station_id not in stations:
                stations[station_id] = {'x': x, 'y': y, 'data': []}
            
            stations[station_id]['data'].append((timestamp, precip_rate))
        
        # Add to precipitation data object
        for station_id, station_info in stations.items():
            precip_data.add_point_data(station_id, station_info['x'], station_info['y'], 
                                     station_info['data'])
    
    def _load_grid_csv(self, reader, precip_data):
        """Load gridded precipitation data from CSV reader."""
        # Expected format: timestamp, x, y, precipitation_mm_hr
        time_grids = {}
        
        for row in reader:
            timestamp = datetime.fromisoformat(row['timestamp'])
            x = float(row['x'])
            y = float(row['y'])
            precip_rate = float(row['precipitation_mm_hr'])
            
            time_key = timestamp.isoformat()
            if time_key not in time_grids:
                time_grids[time_key] = {'x': [], 'y': [], 'precip': [], 'timestamp': timestamp}
            
            time_grids[time_key]['x'].append(x)
            time_grids[time_key]['y'].append(y)
            time_grids[time_key]['precip'].append(precip_rate)
        
        # Convert to regular grids and add to precipitation data
        for time_key, grid_data in time_grids.items():
            x_coords = np.array(grid_data['x'])
            y_coords = np.array(grid_data['y'])
            precip_values = np.array(grid_data['precip'])
            
            # Interpolate to regular grid (assuming regular spacing)
            xi = np.unique(x_coords)
            yi = np.unique(y_coords)
            X, Y = np.meshgrid(xi, yi)
            
            # Interpolate precipitation values
            precip_grid = griddata((x_coords, y_coords), precip_values, 
                                 (X, Y), method='linear', fill_value=0.0)
            
            precip_data.add_spatial_field(grid_data['timestamp'], precip_grid, xi, yi)
    
    def load_precipitation_netcdf(self, netcdf_file: str) -> PrecipitationData:
        """
        Load precipitation data from NetCDF file.
        
        Args:
            netcdf_file: Path to NetCDF file
            
        Returns:
            PrecipitationData object with loaded data
        """
        if not NETCDF_AVAILABLE:
            raise ImportError("NetCDF4 library not available. Install with: pip install netCDF4")
        
        precip_data = PrecipitationData(os.path.basename(netcdf_file))
        
        try:
            with nc.Dataset(netcdf_file, 'r') as dataset:
                # Extract coordinate variables
                if 'x' in dataset.variables and 'y' in dataset.variables:
                    x_coords = dataset.variables['x'][:]
                    y_coords = dataset.variables['y'][:]
                elif 'longitude' in dataset.variables and 'latitude' in dataset.variables:
                    # Need coordinate transformation for lat/lon data
                    self.logger.warning("Lat/Lon coordinates detected. Consider coordinate transformation.")
                    x_coords = dataset.variables['longitude'][:]
                    y_coords = dataset.variables['latitude'][:]
                else:
                    raise ValueError("Cannot find coordinate variables in NetCDF file")
                
                # Extract time variable
                if 'time' in dataset.variables:
                    time_var = dataset.variables['time']
                    times = nc.num2date(time_var[:], time_var.units)
                else:
                    raise ValueError("Cannot find time variable in NetCDF file")
                
                # Extract precipitation variable
                precip_var_names = ['precipitation', 'precip', 'rainfall', 'rain', 'pr']
                precip_var = None
                for name in precip_var_names:
                    if name in dataset.variables:
                        precip_var = dataset.variables[name]
                        break
                
                if precip_var is None:
                    raise ValueError("Cannot find precipitation variable in NetCDF file")
                
                # Load data for each time step
                for i, timestamp in enumerate(times):
                    if isinstance(timestamp, (list, tuple, np.ndarray)):
                        timestamp = timestamp[0]
                    
                    precip_grid = precip_var[i, :, :]
                    
                    # Handle missing values
                    if hasattr(precip_var, '_FillValue'):
                        precip_grid = np.where(precip_grid == precip_var._FillValue, 0.0, precip_grid)
                    
                    # Convert units if necessary (assume mm/hr or mm/day)
                    if hasattr(precip_var, 'units'):
                        if 'mm/day' in precip_var.units or 'mm d-1' in precip_var.units:
                            precip_grid = precip_grid / 24.0  # Convert to mm/hr
                    
                    precip_data.add_spatial_field(timestamp, precip_grid, x_coords, y_coords)
                    
        except Exception as e:
            self.logger.error(f"Error loading NetCDF file {netcdf_file}: {e}")
            raise
            
        return precip_data
    
    def create_design_storm(self, storm_type: str, duration_hours: float, 
                          total_rainfall_mm: float, time_step_minutes: int = 10) -> PrecipitationData:
        """
        Create design storm precipitation patterns.
        
        Args:
            storm_type: "uniform", "triangular", "scs_type2", "chicago"
            duration_hours: Total storm duration
            total_rainfall_mm: Total rainfall amount
            time_step_minutes: Time step for precipitation data
            
        Returns:
            PrecipitationData object with design storm
        """
        precip_data = PrecipitationData(f"design_storm_{storm_type}")
        precip_data.description = f"{storm_type.replace('_', ' ').title()} design storm"
        
        # Create time series
        num_steps = int((duration_hours * 60) / time_step_minutes)
        start_time = datetime.now().replace(minute=0, second=0, microsecond=0)
        
        # Generate precipitation pattern
        if storm_type == "uniform":
            precip_rates = self._uniform_storm(num_steps, total_rainfall_mm, time_step_minutes)
        elif storm_type == "triangular":
            precip_rates = self._triangular_storm(num_steps, total_rainfall_mm, time_step_minutes)
        elif storm_type == "scs_type2":
            precip_rates = self._scs_type2_storm(num_steps, total_rainfall_mm, time_step_minutes)
        elif storm_type == "chicago":
            precip_rates = self._chicago_storm(num_steps, total_rainfall_mm, time_step_minutes)
        else:
            raise ValueError(f"Unknown storm type: {storm_type}")
        
        # Create spatial uniform field (can be modified for spatial patterns)
        nx, ny = len(self.dem_grid_x[0]), len(self.dem_grid_x)
        uniform_field = np.ones((ny, nx))
        
        # Add precipitation fields for each time step
        for i, precip_rate in enumerate(precip_rates):
            timestamp = start_time + timedelta(minutes=i * time_step_minutes)
            precip_field = uniform_field * precip_rate
            
            precip_data.add_spatial_field(timestamp, precip_field, 
                                        self.dem_grid_x[0], self.dem_grid_y[:, 0])
        
        return precip_data
    
    def _uniform_storm(self, num_steps: int, total_mm: float, time_step_min: int) -> np.ndarray:
        """Generate uniform precipitation pattern."""
        rate_mm_hr = total_mm / (num_steps * time_step_min / 60.0)
        return np.full(num_steps, rate_mm_hr)
    
    def _triangular_storm(self, num_steps: int, total_mm: float, time_step_min: int) -> np.ndarray:
        """Generate triangular precipitation pattern with peak at center."""
        # Create triangular distribution
        peak_index = num_steps // 2
        rates = np.zeros(num_steps)
        
        # Rising limb
        for i in range(peak_index):
            rates[i] = (i + 1) / peak_index
        
        # Falling limb
        for i in range(peak_index, num_steps):
            rates[i] = (num_steps - i) / (num_steps - peak_index)
        
        # Scale to total rainfall
        total_volume = np.sum(rates) * time_step_min / 60.0
        scale_factor = total_mm / total_volume
        
        return rates * scale_factor
    
    def _scs_type2_storm(self, num_steps: int, total_mm: float, time_step_min: int) -> np.ndarray:
        """Generate SCS Type II storm distribution."""
        # SCS Type II 24-hour distribution (simplified to any duration)
        duration_hours = (num_steps * time_step_min) / 60.0
        
        # Characteristic curve for SCS Type II
        time_fractions = np.linspace(0, 1, num_steps)
        
        # SCS Type II cumulative distribution approximation
        cumulative = np.zeros(num_steps)
        for i, t in enumerate(time_fractions):
            if t <= 0.5:
                cumulative[i] = 2.0 * t * t
            else:
                cumulative[i] = 1.0 - 2.0 * (1.0 - t) * (1.0 - t)
        
        # Convert to incremental rates
        incremental = np.diff(np.concatenate([[0], cumulative]))
        rates = incremental * total_mm / (time_step_min / 60.0)
        
        return rates
    
    def _chicago_storm(self, num_steps: int, total_mm: float, time_step_min: int) -> np.ndarray:
        """Generate Chicago storm distribution."""
        # Chicago storm has peak at 1/3 of duration
        peak_index = num_steps // 3
        rates = np.zeros(num_steps)
        
        # Intensity equation parameters (simplified)
        a, b, c = 25.0, 0.8, 10.0  # Typical IDF parameters
        
        for i in range(num_steps):
            t_hours = (i + 1) * time_step_min / 60.0
            
            # Before peak
            if i <= peak_index:
                t_before = (peak_index + 1 - i) * time_step_min / 60.0
                rates[i] = a / ((t_before + c) ** b)
            else:
                # After peak
                t_after = (i - peak_index) * time_step_min / 60.0
                rates[i] = a / ((t_after + c) ** b)
        
        # Scale to total rainfall
        total_volume = np.sum(rates) * time_step_min / 60.0
        scale_factor = total_mm / max(total_volume, 1e-6)
        
        return rates * scale_factor
    
    def interpolate_to_dem_grid(self, precip_data: PrecipitationData, 
                               timestamp: datetime, method: str = "linear") -> np.ndarray:
        """
        Interpolate precipitation data to DEM grid for specific timestamp.
        
        Args:
            precip_data: PrecipitationData object
            timestamp: Target timestamp for interpolation
            method: Interpolation method ("linear", "cubic", "nearest")
            
        Returns:
            2D array of precipitation values on DEM grid
        """
        # Find closest available timestamps
        available_times = []
        for time_key in precip_data.spatial_data.keys():
            available_times.append(datetime.fromisoformat(time_key))
        
        if not available_times:
            # Try point data interpolation
            return self._interpolate_point_data_to_grid(precip_data, timestamp, method)
        
        available_times.sort()
        
        # Find surrounding timestamps for temporal interpolation
        if timestamp <= available_times[0]:
            # Use first available time
            target_time = available_times[0]
            time_key = target_time.isoformat()
            spatial_data = precip_data.spatial_data[time_key]
            
            return self._spatial_interpolation(spatial_data, method)
            
        elif timestamp >= available_times[-1]:
            # Use last available time
            target_time = available_times[-1]
            time_key = target_time.isoformat()
            spatial_data = precip_data.spatial_data[time_key]
            
            return self._spatial_interpolation(spatial_data, method)
            
        else:
            # Temporal interpolation between two time steps
            before_time = None
            after_time = None
            
            for i, time_point in enumerate(available_times[:-1]):
                if time_point <= timestamp <= available_times[i+1]:
                    before_time = time_point
                    after_time = available_times[i+1]
                    break
            
            # Interpolate spatially for both time points
            before_key = before_time.isoformat()
            after_key = after_time.isoformat()
            
            before_grid = self._spatial_interpolation(precip_data.spatial_data[before_key], method)
            after_grid = self._spatial_interpolation(precip_data.spatial_data[after_key], method)
            
            # Temporal interpolation
            total_seconds = (after_time - before_time).total_seconds()
            elapsed_seconds = (timestamp - before_time).total_seconds()
            weight = elapsed_seconds / total_seconds
            
            return (1 - weight) * before_grid + weight * after_grid
    
    def _spatial_interpolation(self, spatial_data: Dict, method: str) -> np.ndarray:
        """Perform spatial interpolation to DEM grid."""
        source_grid = spatial_data['precipitation']
        source_x = spatial_data['x_coords']
        source_y = spatial_data['y_coords']
        
        # Create source coordinate meshgrid
        if len(source_x.shape) == 1 and len(source_y.shape) == 1:
            source_X, source_Y = np.meshgrid(source_x, source_y)
        else:
            source_X, source_Y = source_x, source_y
        
        # Flatten source data
        source_points = np.column_stack((source_X.ravel(), source_Y.ravel()))
        source_values = source_grid.ravel()
        
        # Remove NaN values
        valid_mask = ~np.isnan(source_values)
        source_points = source_points[valid_mask]
        source_values = source_values[valid_mask]
        
        # Interpolate to DEM grid
        target_points = np.column_stack((self.dem_grid_x.ravel(), self.dem_grid_y.ravel()))
        
        try:
            interpolated_values = griddata(source_points, source_values, target_points, 
                                         method=method, fill_value=0.0)
            return interpolated_values.reshape(self.dem_grid_x.shape)
        except Exception as e:
            self.logger.warning(f"Spatial interpolation failed: {e}. Using nearest neighbor.")
            interpolated_values = griddata(source_points, source_values, target_points, 
                                         method='nearest', fill_value=0.0)
            return interpolated_values.reshape(self.dem_grid_x.shape)
    
    def _interpolate_point_data_to_grid(self, precip_data: PrecipitationData, 
                                      timestamp: datetime, method: str) -> np.ndarray:
        """Interpolate point precipitation data to DEM grid."""
        if not precip_data.temporal_data:
            self.logger.warning("No temporal data available for interpolation")
            return np.zeros(self.dem_grid_x.shape)
        
        # Extract precipitation values at target timestamp
        station_points = []
        station_values = []
        
        for station_id, station_data in precip_data.temporal_data.items():
            x, y = station_data['x'], station_data['y']
            time_series = station_data['time_series']
            
            # Find value at target timestamp (or interpolate)
            times = [t for t, v in time_series]
            values = [v for t, v in time_series]
            
            if times:
                # Temporal interpolation for this station
                if len(times) == 1:
                    precip_value = values[0]
                else:
                    time_seconds = [(t - times[0]).total_seconds() for t in times]
                    target_seconds = (timestamp - times[0]).total_seconds()
                    
                    interp_func = interp1d(time_seconds, values, kind='linear', 
                                         bounds_error=False, fill_value=0.0)
                    precip_value = float(interp_func(target_seconds))
                
                station_points.append([x, y])
                station_values.append(precip_value)
        
        if not station_points:
            return np.zeros(self.dem_grid_x.shape)
        
        # Spatial interpolation
        station_points = np.array(station_points)
        station_values = np.array(station_values)
        target_points = np.column_stack((self.dem_grid_x.ravel(), self.dem_grid_y.ravel()))
        
        try:
            interpolated_values = griddata(station_points, station_values, target_points, 
                                         method=method, fill_value=0.0)
            interpolated_grid = interpolated_values.reshape(self.dem_grid_x.shape)
            
            # Apply smoothing for better spatial continuity
            return gaussian_filter(interpolated_grid, sigma=1.0)
            
        except Exception as e:
            self.logger.error(f"Point data interpolation failed: {e}")
            return np.zeros(self.dem_grid_x.shape)
    
    def apply_runoff_coefficients(self, precipitation_grid: np.ndarray, 
                                 land_use_grid: Optional[np.ndarray] = None, 
                                 default_coefficient: float = 0.4) -> np.ndarray:
        """
        Apply runoff coefficients to convert precipitation to effective rainfall.
        
        Args:
            precipitation_grid: Precipitation rates (mm/hr)
            land_use_grid: Land use classification grid (optional)
            default_coefficient: Default runoff coefficient
            
        Returns:
            Effective rainfall grid (mm/hr)
        """
        if land_use_grid is None:
            # Use default coefficient for entire domain
            return precipitation_grid * default_coefficient
        
        # Apply land use specific coefficients
        effective_rainfall = np.zeros_like(precipitation_grid)
        
        # Define land use mappings (adjust based on your land use classification)
        land_use_mapping = {
            1: 'urban_dense',
            2: 'urban_medium', 
            3: 'urban_low',
            4: 'agricultural',
            5: 'forest',
            6: 'grassland',
            7: 'water',
            8: 'impervious'
        }
        
        for land_use_code, land_use_type in land_use_mapping.items():
            mask = (land_use_grid == land_use_code)
            coefficient = self.runoff_coefficients.get(land_use_type, default_coefficient)
            effective_rainfall[mask] = precipitation_grid[mask] * coefficient
        
        # Handle unclassified areas
        unclassified_mask = ~np.isin(land_use_grid, list(land_use_mapping.keys()))
        effective_rainfall[unclassified_mask] = precipitation_grid[unclassified_mask] * default_coefficient
        
        return effective_rainfall
    
    def generate_precipitation_report(self, precip_data: PrecipitationData) -> Dict[str, Any]:
        """Generate comprehensive report of precipitation data."""
        report = {
            'name': precip_data.name,
            'description': precip_data.description,
            'metadata': precip_data.metadata,
            'spatial_data_count': len(precip_data.spatial_data),
            'temporal_data_count': len(precip_data.temporal_data),
            'statistics': {}
        }
        
        # Analyze spatial data
        if precip_data.spatial_data:
            all_precip_values = []
            time_coverage = []
            
            for time_key, spatial_data in precip_data.spatial_data.items():
                precip_grid = spatial_data['precipitation']
                valid_values = precip_grid[~np.isnan(precip_grid)]
                all_precip_values.extend(valid_values.tolist())
                time_coverage.append(datetime.fromisoformat(time_key))
            
            if all_precip_values:
                report['statistics']['spatial'] = {
                    'min_precipitation': float(np.min(all_precip_values)),
                    'max_precipitation': float(np.max(all_precip_values)),
                    'mean_precipitation': float(np.mean(all_precip_values)),
                    'total_precipitation': float(np.sum(all_precip_values)),
                    'time_range': {
                        'start': min(time_coverage).isoformat(),
                        'end': max(time_coverage).isoformat(),
                        'duration_hours': (max(time_coverage) - min(time_coverage)).total_seconds() / 3600
                    }
                }
        
        # Analyze temporal data
        if precip_data.temporal_data:
            station_stats = {}
            for station_id, station_data in precip_data.temporal_data.items():
                time_series = station_data['time_series']
                values = [v for t, v in time_series]
                times = [t for t, v in time_series]
                
                if values:
                    station_stats[station_id] = {
                        'location': {'x': station_data['x'], 'y': station_data['y']},
                        'records': len(values),
                        'min_precipitation': float(np.min(values)),
                        'max_precipitation': float(np.max(values)),
                        'mean_precipitation': float(np.mean(values)),
                        'total_precipitation': float(np.sum(values)),
                        'time_range': {
                            'start': min(times).isoformat(),
                            'end': max(times).isoformat()
                        }
                    }
            
            report['statistics']['temporal'] = station_stats
        
        return report

# Factory function for easy integration
def create_precipitation_processor(dem_extent: Tuple[float, float, float, float],
                                 dem_resolution: Tuple[float, float]) -> PrecipitationProcessor:
    """
    Factory function to create precipitation processor.
    
    Args:
        dem_extent: (xmin, ymin, xmax, ymax) in DEM coordinate system
        dem_resolution: (dx, dy) DEM grid spacing
        
    Returns:
        Configured PrecipitationProcessor instance
    """
    return PrecipitationProcessor(dem_extent, dem_resolution)

# Example usage and testing
if __name__ == "__main__":
    print("FloodEngine Precipitation Input Test")
    print("===================================")
    
    # Test setup
    dem_extent = (500000, 6500000, 502000, 6502000)  # 2km x 2km in SWEREF99 TM
    dem_resolution = (10.0, 10.0)  # 10m resolution
    
    # Create processor
    processor = create_precipitation_processor(dem_extent, dem_resolution)
    
    # Test design storm creation
    print("\nCreating design storms...")
    
    storm_types = ["uniform", "triangular", "scs_type2", "chicago"]
    for storm_type in storm_types:
        design_storm = processor.create_design_storm(
            storm_type=storm_type,
            duration_hours=6.0,
            total_rainfall_mm=50.0,
            time_step_minutes=15
        )
        
        print(f"{storm_type.title()} storm created with {len(design_storm.spatial_data)} time steps")
        
        # Generate report
        report = processor.generate_precipitation_report(design_storm)
        if 'spatial' in report['statistics']:
            stats = report['statistics']['spatial']
            print(f"  Max intensity: {stats['max_precipitation']:.2f} mm/hr")
            print(f"  Duration: {stats['time_range']['duration_hours']:.1f} hours")
    
    # Test grid interpolation
    print(f"\nTesting grid interpolation...")
    test_storm = processor.create_design_storm("triangular", 3.0, 25.0, 10)
    
    # Get precipitation at specific time
    target_time = datetime.now() + timedelta(hours=1)
    precip_grid = processor.interpolate_to_dem_grid(test_storm, target_time)
    
    print(f"Interpolated grid shape: {precip_grid.shape}")
    print(f"Grid statistics: min={np.min(precip_grid):.2f}, max={np.max(precip_grid):.2f} mm/hr")
    
    print("\nPrecipitation module test completed successfully!")
