#!/usr/bin/env python3
"""
FIX: Timestep and Hillshade Issues
==================================

This script fixes two critical issues:
1. Only the last timestep gets added to the project (others are just saved to output folder)
2. Multiple hillshades are created instead of just one

FIXES APPLIED:
- Modify timestep simulation to add ALL timestep layers to project in a layer group
- Modify hillshade creation to only create ONE hillshade per simulation
- Ensure layers are properly organized and visible
"""

import os
import sys

def fix_timestep_layer_visibility():
    """Fix the timestep simulation to add all layers to project"""
    
    model_file = "model_hydraulic.py"
    if not os.path.exists(model_file):
        print(f"❌ Model file not found: {model_file}")
        return False
    
    with open(model_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Fix 1: Change the timestep simulation to keep track of all layers
    if "# Remove layer from map to avoid clutter during batch processing" in content:
        print("✅ Found layer removal code - will modify to collect layers instead")
        
        # Replace the layer removal with layer collection
        old_code = """                    # Store result
                    timestep_results.append(step_path)
                    
                    # Remove layer from map to avoid clutter during batch processing
                    QgsProject.instance().removeMapLayer(flood_layer)"""
        
        new_code = """                    # Store result
                    timestep_results.append(step_path)
                    
                    # Keep track of layers for adding to project later
                    if 'timestep_layers' not in locals():
                        timestep_layers = []
                    timestep_layers.append(flood_layer)
                    
                    # Remove from map during processing to avoid clutter, but keep reference
                    QgsProject.instance().removeMapLayer(flood_layer)"""
        
        content = content.replace(old_code, new_code)
        print("✅ Modified layer collection logic")
    
    # Fix 2: Add all timestep layers to project in a group at the end
    if "# Load final timestep for visualization" in content:
        print("✅ Found final timestep loading - will modify to load all layers")
        
        old_final_code = """        # Load final timestep for visualization
        if timestep_results:
            final_layer = QgsVectorLayer(timestep_results[-1], f"Final Flood (t={time_steps[-1]})", "ogr")
            if final_layer.isValid():
                QgsProject.instance().addMapLayer(final_layer)
                print(f"   📊 Final timestep layer added to project")"""
        
        new_final_code = """        # Load ALL timestep layers and organize in a group
        from qgis.core import QgsLayerTreeGroup
        
        timestep_layers_final = []
        
        if timestep_results:
            # Create a layer group for timesteps
            root = QgsProject.instance().layerTreeRoot()
            timestep_group = root.insertGroup(0, f"Flood Timesteps ({len(timestep_results)} steps)")
            
            print(f"📊 Adding {len(timestep_results)} timestep layers to project...")
            
            # Load and add each timestep layer
            for i, result_path in enumerate(timestep_results):
                timestep_num = time_steps[i] if i < len(time_steps) else i+1
                layer_name = f"Timestep {timestep_num:02d} ({water_levels[i]:.1f}m)" if i < len(water_levels) else f"Timestep {timestep_num:02d}"
                
                timestep_layer = QgsVectorLayer(result_path, layer_name, "ogr")
                if timestep_layer.isValid():
                    # Style the layer with transparency and blue color
                    from qgis.core import QgsFillSymbol, QgsSingleSymbolRenderer
                    symbol = QgsFillSymbol.createSimple({
                        'color': f'0,100,255,{max(50, 150-i*10)}',  # Blue with decreasing opacity
                        'outline_color': '0,50,200,255',
                        'outline_width': '0.2'
                    })
                    renderer = QgsSingleSymbolRenderer(symbol)
                    timestep_layer.setRenderer(renderer)
                    
                    # Add to project and group
                    QgsProject.instance().addMapLayer(timestep_layer, False)  # Don't add to root
                    timestep_group.addLayer(timestep_layer)
                    timestep_layers_final.append(timestep_layer)
                    
                    print(f"   ✅ Added: {layer_name}")
            
            # Set the final layer as the currently visible one
            if timestep_layers_final:
                final_layer = timestep_layers_final[-1]
                print(f"   📊 Final timestep layer: {final_layer.name()}")
            else:
                final_layer = None
        else:
            final_layer = None
            timestep_layers_final = []"""
        
        content = content.replace(old_final_code, new_final_code)
        print("✅ Modified final layer loading to include all timesteps")
    
    # Fix 3: Update the return value to include all layers
    if "return time_folder" in content and "Enhanced timestep simulation complete" in content:
        old_return = """        print(f"✅ Enhanced timestep simulation complete:")
        print(f"   📁 Results folder: {time_folder}")
        print(f"   🕐 Timesteps processed: {len(timestep_results)}")
        print(f"   ✅ Successful floods: {successful_timesteps}")
        
        return time_folder"""
        
        new_return = """        print(f"✅ Enhanced timestep simulation complete:")
        print(f"   📁 Results folder: {time_folder}")
        print(f"   🕐 Timesteps processed: {len(timestep_results)}")
        print(f"   ✅ Successful floods: {successful_timesteps}")
        print(f"   📊 Layers added to project: {len(timestep_layers_final)}")
        
        # Return comprehensive results
        return {
            'time_folder': time_folder,
            'timestep_results': timestep_results,
            'timestep_layers': timestep_layers_final,
            'final_layer': final_layer,
            'successful_timesteps': successful_timesteps,
            'total_timesteps': len(time_steps)
        }"""
        
        content = content.replace(old_return, new_return)
        print("✅ Enhanced return value to include all layer information")
    
    # Write the fixed content back
    with open(model_file, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print("✅ Timestep layer visibility fixes applied")
    return True

def fix_hillshade_duplication():
    """Fix the hillshade creation to avoid multiple hillshades"""
    
    model_file = "model_hydraulic.py"
    if not os.path.exists(model_file):
        print(f"❌ Model file not found: {model_file}")
        return False
    
    with open(model_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Fix 1: Modify timestep simulation to only create ONE hillshade
    if "# CRITICAL: Use Saint-Venant model for each timestep" in content:
        print("✅ Found timestep simulation - will modify hillshade creation")
        
        # Add hillshade creation before the loop
        timestep_loop_start = content.find("# Simulate each timestep")
        if timestep_loop_start != -1:
            # Insert hillshade creation before the loop
            insert_point = content.find("# Simulate each timestep")
            
            hillshade_creation_code = """        
        # Create ONE hillshade for the entire simulation (before processing timesteps)
        print("🏔️ Creating single hillshade for timestep simulation...")
        try:
            hillshade_layer = create_combined_hillshade(
                dem_path,
                time_folder,
                bathymetry_integrated=bathymetry is not None,
                stream_burned=kwargs.get('stream_path') is not None
            )
            if hillshade_layer and hillshade_layer.isValid():
                QgsProject.instance().addMapLayer(hillshade_layer)
                print("   ✅ Single hillshade created for all timesteps")
            else:
                print("   ⚠️ Hillshade creation failed, continuing without hillshade")
        except Exception as e:
            print(f"   ⚠️ Hillshade creation error: {e}")
        
        """
            
            content = content[:insert_point] + hillshade_creation_code + content[insert_point:]
            print("✅ Added single hillshade creation before timestep loop")
    
    # Fix 2: Modify calculate_flood_area to skip hillshade creation during timestep simulation
    if "hillshade_layer = create_combined_hillshade(" in content:
        print("✅ Found hillshade creation in calculate_flood_area - will add conditional logic")
        
        old_hillshade_code = """        # CRITICAL FIX 4: Create combined DEM/Bathymetry/Streamburn hillshade
        print(f"🏔️ Creating combined terrain hillshade...")
        try:
            hillshade_layer = create_combined_hillshade(
                working_dem_path,
                output_folder,
                bathymetry_integrated=bathymetry is not None,
                stream_burned=stream_path is not None
            )
            if hillshade_layer and hillshade_layer.isValid():
                QgsProject.instance().addMapLayer(hillshade_layer)
                print(f"✅ Combined hillshade created successfully")
        except Exception as e:
            print(f"⚠️ Hillshade creation failed: {e}")"""
        
        new_hillshade_code = """        # CRITICAL FIX 4: Create combined DEM/Bathymetry/Streamburn hillshade
        # Skip hillshade creation if this is part of a timestep simulation (to avoid duplicates)
        skip_hillshade = kwargs.get('skip_hillshade', False)
        
        if not skip_hillshade:
            print(f"🏔️ Creating combined terrain hillshade...")
            try:
                hillshade_layer = create_combined_hillshade(
                    working_dem_path,
                    output_folder,
                    bathymetry_integrated=bathymetry is not None,
                    stream_burned=stream_path is not None
                )
                if hillshade_layer and hillshade_layer.isValid():
                    QgsProject.instance().addMapLayer(hillshade_layer)
                    print(f"✅ Combined hillshade created successfully")
            except Exception as e:
                print(f"⚠️ Hillshade creation failed: {e}")
        else:
            print(f"⏩ Skipping hillshade creation (timestep simulation mode)")"""
        
        content = content.replace(old_hillshade_code, new_hillshade_code)
        print("✅ Added conditional hillshade creation logic")
    
    # Fix 3: Modify timestep simulation to pass skip_hillshade flag
    if "local_kwargs['use_saint_venant'] = True" in content:
        print("✅ Found timestep kwargs setup - will add skip_hillshade flag")
        
        old_kwargs_code = """                # CRITICAL: Use Saint-Venant model for each timestep
                local_kwargs['time_steps'] = 5  # Use 5 internal Saint-Venant steps per timestep
                local_kwargs['use_saint_venant'] = True"""
        
        new_kwargs_code = """                # CRITICAL: Use Saint-Venant model for each timestep
                local_kwargs['time_steps'] = 5  # Use 5 internal Saint-Venant steps per timestep
                local_kwargs['use_saint_venant'] = True
                local_kwargs['skip_hillshade'] = True  # Skip individual hillshades in timestep mode"""
        
        content = content.replace(old_kwargs_code, new_kwargs_code)
        print("✅ Added skip_hillshade flag to timestep simulations")
    
    # Write the fixed content back
    with open(model_file, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print("✅ Hillshade duplication fixes applied")
    return True

def fix_ui_handling():
    """Fix the UI to properly handle the new timestep return format"""
    
    ui_file = "floodengine_ui.py"
    if not os.path.exists(ui_file):
        print(f"❌ UI file not found: {ui_file}")
        return False
    
    with open(ui_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check if already fixed
    if "timestep_layers = simulation_result.get('timestep_layers'" in content:
        print("✅ UI already has enhanced result handling")
        return True
    
    # Fix the UI result handling
    if "if isinstance(simulation_result, dict):" in content:
        print("✅ Found UI result handling - enhancing it")
        
        old_handling = """                    if isinstance(simulation_result, dict):
                        time_folder_result = simulation_result.get('time_folder')
                        timestep_layers = simulation_result.get('timestep_layers', [])
                        final_flood_layer = simulation_result.get('final_layer')
                        print(f"✅ Timestep simulation created {len(timestep_layers)} layers")"""
        
        new_handling = """                    if isinstance(simulation_result, dict):
                        time_folder_result = simulation_result.get('time_folder')
                        timestep_layers = simulation_result.get('timestep_layers', [])
                        timestep_results = simulation_result.get('timestep_results', [])
                        final_flood_layer = simulation_result.get('final_layer')
                        successful_count = simulation_result.get('successful_timesteps', 0)
                        total_count = simulation_result.get('total_timesteps', 0)
                        print(f"✅ Timestep simulation created {len(timestep_layers)} layers ({successful_count}/{total_count} successful)")
                        
                        # Show success message
                        if timestep_layers:
                            self.iface.messageBar().pushSuccess(
                                "FloodEngine", 
                                f"Timestep simulation complete: {len(timestep_layers)} flood layers created"
                            )"""
        
        content = content.replace(old_handling, new_handling)
        print("✅ Enhanced UI result handling")
    
    # Write the fixed content back
    with open(ui_file, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print("✅ UI handling fixes applied")
    return True

def test_fixes():
    """Test that all fixes were applied correctly"""
    
    print("\n🧪 TESTING FIXES...")
    
    # Test model file
    model_file = "model_hydraulic.py"
    if os.path.exists(model_file):
        with open(model_file, 'r', encoding='utf-8') as f:
            model_content = f.read()
        
        tests = [
            ("Timestep layer collection", "timestep_layers.append(flood_layer)" in model_content),
            ("Layer group creation", "timestep_group = root.insertGroup" in model_content),
            ("Enhanced return value", "'timestep_layers': timestep_layers_final" in model_content),
            ("Single hillshade creation", "Creating single hillshade for timestep simulation" in model_content),
            ("Skip hillshade flag", "skip_hillshade = kwargs.get('skip_hillshade'" in model_content),
            ("Conditional hillshade", "if not skip_hillshade:" in model_content)
        ]
        
        print("Model file tests:")
        for test_name, result in tests:
            status = "✅" if result else "❌"
            print(f"  {status} {test_name}")
    
    # Test UI file
    ui_file = "floodengine_ui.py"
    if os.path.exists(ui_file):
        with open(ui_file, 'r', encoding='utf-8') as f:
            ui_content = f.read()
        
        ui_tests = [
            ("Enhanced result handling", "timestep_results = simulation_result.get" in ui_content),
            ("Success message", "Timestep simulation complete:" in ui_content)
        ]
        
        print("UI file tests:")
        for test_name, result in ui_tests:
            status = "✅" if result else "❌"
            print(f"  {status} {test_name}")

if __name__ == "__main__":
    print("FIXING TIMESTEP AND HILLSHADE ISSUES")
    print("=" * 50)
    
    success = True
    
    print("\n1. FIXING TIMESTEP LAYER VISIBILITY...")
    if fix_timestep_layer_visibility():
        print("✅ Timestep layer visibility fixed")
    else:
        print("❌ Failed to fix timestep layer visibility")
        success = False
    
    print("\n2. FIXING HILLSHADE DUPLICATION...")
    if fix_hillshade_duplication():
        print("✅ Hillshade duplication fixed")
    else:
        print("❌ Failed to fix hillshade duplication")
        success = False
    
    print("\n3. FIXING UI HANDLING...")
    if fix_ui_handling():
        print("✅ UI handling fixed")
    else:
        print("❌ Failed to fix UI handling")
        success = False
    
    print("\n4. TESTING FIXES...")
    test_fixes()
    
    if success:
        print("\n🎉 ALL FIXES APPLIED SUCCESSFULLY!")
        print("\nEXPECTED BEHAVIOR AFTER FIXES:")
        print("=" * 40)
        print("✅ ALL timestep layers will be added to project in a 'Flood Timesteps' group")
        print("✅ Each layer will be styled with decreasing opacity (newest = most opaque)")
        print("✅ Only ONE hillshade will be created per simulation")
        print("✅ Hillshade will be created BEFORE timestep processing begins")
        print("✅ Files will still be saved to output folder for each timestep")
        print("✅ UI will show success message with layer count")
        print("\nLAYER ORGANIZATION:")
        print("📁 Flood Timesteps (X steps)")
        print("  ├── Timestep 01 (60.0m)")
        print("  ├── Timestep 02 (60.5m)")
        print("  ├── Timestep 03 (61.0m)")
        print("  └── ...")
        print("🏔️ Combined Terrain Hillshade")
    else:
        print("\n❌ SOME FIXES FAILED")
        print("Please check the error messages above and try again.")
