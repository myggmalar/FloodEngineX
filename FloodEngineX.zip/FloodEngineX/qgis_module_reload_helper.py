#!/usr/bin/env python3
"""
QGIS Module Reload Helper
=========================
Forces proper module reload in QGIS to avoid caching issues.
"""

import sys
import os
import importlib

def force_qgis_module_reload():
    """Force reload of FloodEngine modules in QGIS."""
    print("🔄 FORCING QGIS MODULE RELOAD...")
    
    # List of modules to reload
    modules_to_reload = [
        'launch_animation',
        'time_series_animator',
        'time_series_integration',
        'dialog_manager'
    ]
    
    reloaded_count = 0
    
    for module_name in modules_to_reload:
        try:
            if module_name in sys.modules:
                print(f"🔄 Reloading {module_name}...")
                importlib.reload(sys.modules[module_name])
                reloaded_count += 1
                print(f"✅ Successfully reloaded {module_name}")
            else:
                print(f"ℹ️ {module_name} not in sys.modules, skipping")
        except Exception as e:
            print(f"❌ Failed to reload {module_name}: {e}")
    
    print(f"✅ Successfully reloaded {reloaded_count} modules")
    return reloaded_count

def get_launch_animation_function():
    """Get the launch_animation_from_folder function with proper reload."""
    try:
        # Force reload first
        force_qgis_module_reload()
        
        # Import the function
        from launch_animation import launch_animation_from_folder
        
        # Verify signature
        import inspect
        sig = inspect.signature(launch_animation_from_folder)
        print(f"✅ Function signature verified: {sig}")
        
        return launch_animation_from_folder
    except Exception as e:
        print(f"❌ Error getting launch function: {e}")
        return None

def launch_animation_safe(output_folder, parent_window=None):
    """
    Safely launch animation with proper module reload and error handling.
    
    Args:
        output_folder: Path to the simulation output folder
        parent_window: Parent widget for the dialog (optional)
    
    Returns:
        bool: True if successful, False otherwise
    """
    print(f"🎬 SAFE ANIMATION LAUNCH: {output_folder}")
    
    try:
        # Get the launch function with proper reload
        launch_function = get_launch_animation_function()
        if not launch_function:
            print("❌ Could not get launch function")
            return False
        
        # Check for animation data
        animation_folder = None
        if os.path.exists(os.path.join(output_folder, 'time_series_animation')):
            animation_folder = os.path.join(output_folder, 'time_series_animation')
            print(f"📁 Found time_series_animation folder: {animation_folder}")
        elif os.path.exists(os.path.join(output_folder, 'rasters')):
            animation_folder = output_folder
            print(f"📁 Found rasters in output folder: {animation_folder}")
        
        if not animation_folder:
            print("❌ No animation data found")
            return False
        
        # Try to launch with parent first, then without
        print("🚀 Attempting to launch animation dialog...")
        
        try:
            # First try with parent
            if parent_window:
                result = launch_function(animation_folder, standalone=True, parent=parent_window)
                print("✅ Launched with parent window")
            else:
                result = launch_function(animation_folder, standalone=True, parent=None)
                print("✅ Launched without parent window")
            
            if result:
                print("✅ Animation dialog launched successfully!")
                return result
            else:
                print("❌ Animation launch returned False")
                return False
                
        except TypeError as e:
            if "unexpected keyword argument 'parent'" in str(e):
                print("⚠️ Function doesn't accept parent argument, trying without...")
                # Fallback: call without parent argument
                result = launch_function(animation_folder, standalone=True)
                print("✅ Launched without parent argument")
                return result
            else:
                raise e
        
    except Exception as e:
        print(f"❌ Animation launch error: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("QGIS Module Reload Helper Test")
    print("=" * 50)
    
    # Test the reload functionality
    force_qgis_module_reload()
    
    # Test getting the function
    func = get_launch_animation_function()
    if func:
        print("✅ Function retrieved successfully")
    else:
        print("❌ Could not retrieve function")
