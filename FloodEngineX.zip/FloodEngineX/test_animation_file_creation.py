#!/usr/bin/env python3
"""
Test if the time_series_integration actually creates the animation files.
This simulates what Saint-Venant should be doing.
"""

import sys
import os
import tempfile
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_animation_file_creation():
    """Test if animation files are actually created."""
    print("🎬 Testing animation file creation...")
    
    # Create mock results data (similar to what Saint-Venant produces)
    print("📊 Creating mock simulation results...")
    
    # Create sample data
    nx, ny = 20, 20
    times = [0.0, 10.0, 20.0, 30.0]  # 4 timesteps
    
    results_data = {
        'times': times,
        'water_depths': [],
        'velocity_x': [],
        'velocity_y': [],
        'dem_array': np.random.rand(nx, ny) * 10,  # Random DEM
        'geotransform': (0, 1, 0, ny, 0, -1),
        'projection': 'GEOGCS["WGS 84",DATUM["WGS_1984",SPHEROID["WGS 84",6378137,298.257223563]]]'
    }
    
    # Create sample time series data
    for i, t in enumerate(times):
        # Random water depths that change over time
        depth = np.random.rand(nx, ny) * (i + 1) * 0.5
        vel_x = np.random.rand(nx, ny) * 0.2
        vel_y = np.random.rand(nx, ny) * 0.2
        
        results_data['water_depths'].append(depth)
        results_data['velocity_x'].append(vel_x)
        results_data['velocity_y'].append(vel_y)
    
    print(f"✅ Created mock data with {len(times)} timesteps")
    
    # Create temporary output folder
    temp_dir = tempfile.mkdtemp()
    animation_folder = os.path.join(temp_dir, 'time_series_animation')
    
    try:
        print(f"📁 Animation folder: {animation_folder}")
        
        # Test the time_series_integration
        from time_series_integration import integrate_time_series_animation
        print("✅ Successfully imported integrate_time_series_animation")
        
        # Run the integration
        print("🔄 Running time series integration...")
        animation_result = integrate_time_series_animation(results_data, animation_folder)
        
        print(f"📋 Integration result: {animation_result}")
        
        if animation_result['success']:
            print("✅ Animation integration SUCCEEDED!")
            
            # Check what files were created
            if os.path.exists(animation_folder):
                print(f"📁 Animation folder exists: {animation_folder}")
                
                # List all files
                for root, dirs, files in os.walk(animation_folder):
                    for file in files:
                        full_path = os.path.join(root, file)
                        print(f"  📄 {os.path.relpath(full_path, animation_folder)}")
                
                # Now test launching the animation
                print("\n🎬 Testing animation launch...")
                from launch_animation import launch_animation_from_folder
                
                result = launch_animation_from_folder(animation_folder, standalone=True)
                
                if result:
                    print("✅ Animation launch SUCCEEDED!")
                    return True
                else:
                    print("❌ Animation launch FAILED")
                    return False
            else:
                print("❌ Animation folder was not created")
                return False
        else:
            print(f"❌ Animation integration FAILED: {animation_result.get('error', 'Unknown error')}")
            return False
            
    except Exception as e:
        print(f"❌ Test failed with exception: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    finally:
        # Clean up
        try:
            import shutil
            shutil.rmtree(temp_dir)
            print(f"\n🧹 Cleaned up: {temp_dir}")
        except:
            pass

if __name__ == "__main__":
    success = test_animation_file_creation()
    print(f"\n{'✅ ANIMATION FILE CREATION TEST PASSED' if success else '❌ ANIMATION FILE CREATION TEST FAILED'}")
    
    if success:
        print("\n🎉 Great! The animation system is working!")
        print("🔍 The issue might be:")
        print("   1. Animation files not being created during real simulation")
        print("   2. Animation checkbox not being checked") 
        print("   3. Wrong path being passed to animation launcher")
    else:
        print("\n🔍 The animation system has issues. Check:")
        print("   1. time_series_integration.py functionality")
        print("   2. File permissions")
        print("   3. Missing dependencies")
