"""
FloodEngine Plugin Load Test

This script tests if the FloodEngine plugin can be loaded successfully
by simulating the QGIS plugin loading process.
"""

import os
import sys
import unittest.mock as mock

def setup_mock_environment():
    """Set up mock QGIS environment for testing."""
    
    # Mock QGIS modules that the plugin depends on
    mock_modules = {
        'osgeo': mock.MagicMock(),
        'osgeo.gdal': mock.MagicMock(), 
        'osgeo.ogr': mock.MagicMock(),
        'osgeo.osr': mock.MagicMock(),
        'qgis': mock.MagicMock(),
        'qgis.core': mock.MagicMock(),
        'qgis.gui': mock.MagicMock(),
        'qgis.utils': mock.MagicMock(),
        'qgis.PyQt': mock.MagicMock(),
        'qgis.PyQt.QtCore': mock.MagicMock(),
        'qgis.PyQt.QtGui': mock.MagicMock(),
        'qgis.PyQt.QtWidgets': mock.MagicMock(),
        'processing': mock.MagicMock(),
        'pandas': mock.MagicMock(),
    }
    
    # Patch all modules at once
    return mock.patch.dict('sys.modules', mock_modules)

def test_load_bathymetry_import():
    """Test the specific import that was failing."""
    print("1. Testing load_bathymetry import...")
    
    try:
        from model_hydraulic import load_bathymetry
        print("   ✓ load_bathymetry imported successfully")
        
        if callable(load_bathymetry):
            print("   ✓ load_bathymetry is callable")
            return True
        else:
            print("   ✗ load_bathymetry is not callable")
            return False
            
    except Exception as e:
        print(f"   ✗ Import failed: {e}")
        return False

def test_ui_dialog_import():
    """Test importing the main UI dialog."""
    print("2. Testing FloodEngineDialog import...")
    
    try:
        from floodengine_ui import FloodEngineDialog
        print("   ✓ FloodEngineDialog imported successfully")
        return True
    except Exception as e:
        print(f"   ✗ FloodEngineDialog import failed: {e}")
        return False

def test_plugin_init():
    """Test the plugin initialization through __init__.py."""
    print("3. Testing plugin initialization...")
    
    try:
        # Simulate the classFactory call from QGIS
        import importlib.util
        
        # Load the __init__.py module
        init_path = os.path.join(os.getcwd(), '__init__.py')
        spec = importlib.util.spec_from_file_location("floodengine_init", init_path)
        init_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(init_module)
        
        # Test the classFactory function
        mock_iface = mock.MagicMock()
        plugin_instance = init_module.classFactory(mock_iface)
        
        print("   ✓ classFactory executed successfully")
        print(f"   ✓ Plugin instance created: {type(plugin_instance).__name__}")
        return True
        
    except Exception as e:
        print(f"   ✗ Plugin initialization failed: {e}")
        return False

def main():
    """Run all tests."""
    print("=" * 60)
    print("FLOODENGINE PLUGIN LOAD TEST")
    print("=" * 60)
    print(f"Testing in directory: {os.getcwd()}")
    print()
    
    # Set up mock environment
    with setup_mock_environment():
        
        # Run tests
        test1 = test_load_bathymetry_import()
        print()
        
        test2 = test_ui_dialog_import() 
        print()
        
        test3 = test_plugin_init()
        print()
        
        # Summary
        print("=" * 60)
        if all([test1, test2, test3]):
            print("🎉 ALL TESTS PASSED!")
            print("The FloodEngine plugin should load successfully in QGIS.")
            print()
            print("✓ load_bathymetry function is available")
            print("✓ FloodEngineDialog can be imported")
            print("✓ Plugin can be initialized through classFactory")
        else:
            print("❌ SOME TESTS FAILED!")
            print("There may still be issues preventing the plugin from loading.")
            print()
            print(f"✓ load_bathymetry import: {'PASS' if test1 else 'FAIL'}")
            print(f"✓ FloodEngineDialog import: {'PASS' if test2 else 'FAIL'}")
            print(f"✓ Plugin initialization: {'PASS' if test3 else 'FAIL'}")
        
        print("=" * 60)

if __name__ == "__main__":
    main()
