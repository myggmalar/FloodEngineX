#!/usr/bin/env python3
"""
FloodEngine v4.0 - Simple Integration Validation
===============================================

Simple validation script to test newly implemented modules.
"""

import os
import sys
import traceback

def test_module_import(module_name, file_path):
    """Test if a module can be imported."""
    print(f"\nTesting {module_name}...")
    print(f"File exists: {os.path.exists(file_path)}")
    
    try:
        # Add current directory to path
        if os.path.dirname(file_path) not in sys.path:
            sys.path.insert(0, os.path.dirname(file_path))
        
        # Try to import
        import importlib.util
        spec = importlib.util.spec_from_file_location(module_name, file_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        
        print(f"✓ {module_name} imported successfully")
        return True, module
        
    except Exception as e:
        print(f"✗ {module_name} import failed: {e}")
        print(f"Traceback: {traceback.format_exc()}")
        return False, None

def test_qa_framework():
    """Test Quality Assurance Framework."""
    success, module = test_module_import("quality_assurance_framework", 
                                       "quality_assurance_framework.py")
    if success:
        try:
            # Test class instantiation
            qa_framework = module.QualityAssuranceFramework("./test_output")
            print(f"✓ QualityAssuranceFramework instantiated")
            
            # Test basic method
            if hasattr(qa_framework, 'initialize_test_environment'):
                qa_framework.initialize_test_environment()
                print(f"✓ Test environment initialized")
            
            return True
        except Exception as e:
            print(f"✗ QA Framework test failed: {e}")
            return False
    return False

def test_analysis_tools():
    """Test Advanced Analysis Tools."""
    success, module = test_module_import("advanced_analysis_tools", 
                                       "advanced_analysis_tools.py")
    if success:
        try:
            # Test class instantiation
            risk_assessor = module.FloodRiskAssessment()
            economic_analyzer = module.EconomicImpactAnalysis()
            uncertainty_analyzer = module.UncertaintyQuantification()
            
            print(f"✓ Analysis tools instantiated")
            
            # Test a simple method
            import numpy as np
            test_depths = np.array([[1.0, 2.0], [0.5, 1.5]])
            test_velocities = np.array([[0.5, 1.0], [0.3, 0.8]])
            
            risk_map = risk_assessor.calculate_flood_hazard(test_depths, test_velocities)
            print(f"✓ Risk assessment calculation successful")
            
            return True
        except Exception as e:
            print(f"✗ Analysis tools test failed: {e}")
            return False
    return False

def test_gpu_acceleration():
    """Test GPU Acceleration."""
    success, module = test_module_import("gpu_acceleration", "gpu_acceleration.py")
    if success:
        try:
            gpu_manager = module.GPUAccelerationManager()
            gpu_available = gpu_manager.is_gpu_available()
            print(f"✓ GPU manager created, GPU available: {gpu_available}")
            return True
        except Exception as e:
            print(f"✗ GPU acceleration test failed: {e}")
            return False
    return False

def test_precipitation_input():
    """Test Precipitation Input."""
    success, module = test_module_import("precipitation_input", "precipitation_input.py")
    if success:
        try:
            precip_processor = module.PrecipitationProcessor()
            storm_generator = module.DesignStormGenerator()
            print(f"✓ Precipitation modules created")
            
            # Test storm generation
            storm = storm_generator.generate_design_storm("constant", 2, 10, 10)
            if storm:
                print(f"✓ Design storm generated: {storm.get('type', 'Unknown')}")
            
            return True
        except Exception as e:
            print(f"✗ Precipitation input test failed: {e}")
            return False
    return False

def test_performance_optimization():
    """Test Performance Optimization."""
    success, module = test_module_import("performance_optimization", "performance_optimization.py")
    if success:
        try:
            optimizer = module.PerformanceOptimizer()
            print(f"✓ Performance optimizer created")
            return True
        except Exception as e:
            print(f"✗ Performance optimization test failed: {e}")
            return False
    return False

def main():
    """Main validation function."""
    print("FloodEngine v4.0 - Simple Integration Validation")
    print("=" * 50)
    
    # Test core modules
    tests = [
        ("Quality Assurance Framework", test_qa_framework),
        ("Advanced Analysis Tools", test_analysis_tools),
        ("GPU Acceleration", test_gpu_acceleration),
        ("Precipitation Input", test_precipitation_input),
        ("Performance Optimization", test_performance_optimization)
    ]
    
    results = {}
    
    for test_name, test_func in tests:
        print(f"\n{'-' * 30}")
        print(f"Testing: {test_name}")
        print(f"{'-' * 30}")
        
        try:
            results[test_name] = test_func()
        except Exception as e:
            print(f"✗ Test {test_name} crashed: {e}")
            results[test_name] = False
    
    # Summary
    print(f"\n{'=' * 50}")
    print("VALIDATION SUMMARY")
    print(f"{'=' * 50}")
    
    passed = sum(1 for success in results.values() if success)
    total = len(results)
    
    for test_name, success in results.items():
        status = "PASS" if success else "FAIL"
        print(f"{test_name:<30} {status}")
    
    print(f"\nTotal: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All validation tests passed!")
        return 0
    else:
        print("⚠️  Some validation tests failed.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
