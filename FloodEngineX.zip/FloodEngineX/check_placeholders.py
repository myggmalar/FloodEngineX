#!/usr/bin/env python3
"""
Simple test to check for placeholder code in the FloodEngine UI.
This focuses on finding actual placeholder implementations, not placeholder text.
"""

import os
import re

def check_for_real_placeholders():
    """Check for actual placeholder code (not just placeholder text)."""
    
    ui_file_path = os.path.join(os.path.dirname(__file__), 'floodengine_ui.py')
    
    with open(ui_file_path, 'r', encoding='utf-8') as f:
        content = f.read()
        lines = content.split('\n')
    
    # These are real placeholder patterns that indicate incomplete implementation
    real_placeholder_patterns = [
        r'not yet implemented',
        r'not implemented',
        r'placeholder.*logic',
        r'TODO:',
        r'FIXME:',
        r'^\s*pass\s*$',  # Standalone pass statements
        r'pass\s*#.*placeholder',
        r'placeholder.*implementation'
    ]
    
    # These are acceptable placeholder texts (UI element placeholders)
    acceptable_patterns = [
        r'setPlaceholderText\(',
        r'placeholder.*text',
        r'Optional:',
        r'Valfritt'
    ]
    
    found_real_placeholders = []
    
    for i, line in enumerate(lines, 1):
        line_lower = line.lower()
        
        # Check if line contains real placeholder patterns
        for pattern in real_placeholder_patterns:
            if re.search(pattern, line_lower):
                # Make sure it's not an acceptable placeholder
                is_acceptable = False
                for acceptable in acceptable_patterns:
                    if re.search(acceptable, line_lower):
                        is_acceptable = True
                        break
                
                if not is_acceptable:
                    found_real_placeholders.append((i, line.strip()))
    
    return found_real_placeholders

def check_method_completeness():
    """Check that all methods have proper implementations."""
    
    ui_file_path = os.path.join(os.path.dirname(__file__), 'floodengine_ui.py')
    
    with open(ui_file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Find all method definitions
    method_pattern = r'def\s+(\w+)\s*\([^)]*\):'
    methods = re.findall(method_pattern, content)
    
    incomplete_methods = []
    
    # Check each method for proper implementation
    method_sections = re.split(r'\n\s*def\s+', content)
    
    for i, section in enumerate(method_sections[1:], 1):  # Skip first section before any method
        lines = section.split('\n')
        method_name = re.match(r'(\w+)', lines[0])
        if method_name:
            method_name = method_name.group(1)
            
            # Check if method only contains docstring and pass/placeholder
            non_empty_lines = [line.strip() for line in lines[1:] if line.strip() and not line.strip().startswith('"""') and not line.strip().startswith("'''")]
            
            if len(non_empty_lines) <= 2 and any('pass' in line or 'not implemented' in line.lower() for line in non_empty_lines):
                incomplete_methods.append(method_name)
    
    return incomplete_methods

def main():
    print("FloodEngine UI Placeholder Check")
    print("=" * 40)
    
    # Check for real placeholder code
    real_placeholders = check_for_real_placeholders()
    
    if real_placeholders:
        print("✗ Found real placeholder code:")
        for line_num, line in real_placeholders:
            print(f"  Line {line_num}: {line}")
    else:
        print("✓ No real placeholder code found")
    
    # Check for incomplete methods
    incomplete_methods = check_method_completeness()
    
    if incomplete_methods:
        print("✗ Found incomplete methods:")
        for method in incomplete_methods:
            print(f"  - {method}")
    else:
        print("✓ All methods appear to be properly implemented")
    
    print("\n" + "=" * 40)
    
    if not real_placeholders and not incomplete_methods:
        print("🎉 SUCCESS: No placeholders found! The UI is fully functional.")
        return True
    else:
        print("❌ ISSUES FOUND: Please review the items listed above.")
        return False

if __name__ == "__main__":
    success = main()
    exit(0 if success else 1)
