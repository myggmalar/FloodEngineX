#!/usr/bin/env python3
"""
Focused Test: Verify adaptive threshold fixes in intermediate timestep simulation
===============================================================================
This test verifies that our adaptive threshold and bathtub fallback fixes
resolve the critical issue where intermediate timestep layers were empty.
"""

import sys
import os
import numpy as np
import time
from pathlib import Path

# Add the plugin directory to path
plugin_dir = Path(__file__).parent
sys.path.insert(0, str(plugin_dir))

def test_adaptive_threshold_function():
    """Test the adaptive threshold function directly"""
    print("🧪 TESTING: Adaptive Threshold Function")
    print("=" * 60)
    
    try:
        from model_hydraulic import create_proper_flow_flood_mask
        print("✅ Successfully imported create_proper_flow_flood_mask")
        
        # Create test DEM with realistic intermediate flooding scenarios
        rows, cols = 60, 60
        dem = np.zeros((rows, cols), dtype=np.float32)
        
        # Create a river valley scenario
        for i in range(rows):
            for j in range(cols):
                # Base elevation declining towards center
                dist_to_center = abs(i - rows//2) + abs(j - cols//2)
                valley_depth = max(0, 10 - dist_to_center * 0.3)
                base_elevation = 45 - valley_depth
                
                # Add some noise
                noise = np.random.normal(0, 0.3)
                dem[i, j] = base_elevation + noise
        
        # Ensure proper range
        dem = np.clip(dem, 35, 50)
        valid_mask = np.ones_like(dem, dtype=bool)
        
        print(f"📊 Test DEM: {dem.shape}, elevation range {dem.min():.2f}m to {dem.max():.2f}m")
        
        # Test critical intermediate water levels that were problematic
        test_levels = [
            36.5,  # Very low - should trigger adaptive thresholds
            38.0,  # Low-intermediate
            40.0,  # Mid-level
            42.0,  # Higher intermediate
            44.0,  # High level
        ]
        
        results = {}
        
        for water_level in test_levels:
            print(f"\n🌊 Testing water level: {water_level:.1f}m")
            
            start_time = time.time()
            try:
                flood_mask = create_proper_flow_flood_mask(dem, valid_mask, water_level)
                flooded_cells = np.sum(flood_mask)
                elapsed_time = time.time() - start_time
                
                if flooded_cells > 0:
                    flood_percentage = (flooded_cells / np.sum(valid_mask)) * 100
                    print(f"   ✅ SUCCESS: {flooded_cells} cells flooded ({flood_percentage:.1f}%) in {elapsed_time:.3f}s")
                    results[water_level] = {
                        'success': True,
                        'flooded_cells': flooded_cells,
                        'percentage': flood_percentage,
                        'time': elapsed_time
                    }
                else:
                    print(f"   ❌ FAILED: No flooding at {water_level:.1f}m")
                    results[water_level] = {
                        'success': False,
                        'flooded_cells': 0,
                        'percentage': 0,
                        'time': elapsed_time
                    }
                    
            except Exception as e:
                elapsed_time = time.time() - start_time
                print(f"   💥 ERROR: {str(e)}")
                results[water_level] = {
                    'success': False,
                    'error': str(e),
                    'time': elapsed_time
                }
        
        # Analyze results
        print("\n" + "=" * 60)
        print("📊 TEST RESULTS SUMMARY")
        print("=" * 60)
        
        successful_levels = [wl for wl, result in results.items() if result.get('success', False)]
        failed_levels = [wl for wl, result in results.items() if not result.get('success', False)]
        
        print(f"✅ Successful water levels: {len(successful_levels)}/{len(test_levels)}")
        print(f"❌ Failed water levels: {len(failed_levels)}")
        
        if failed_levels:
            print(f"🚨 Failed levels: {failed_levels}")
        
        # Check intermediate level performance specifically
        intermediate_levels = [wl for wl in test_levels[1:-1]]  # Skip first and last
        intermediate_successes = [wl for wl in intermediate_levels if results[wl].get('success', False)]
        
        print(f"\n🎯 INTERMEDIATE LEVELS FOCUS:")
        print(f"   Tested intermediate levels: {intermediate_levels}")
        print(f"   Successful intermediate levels: {intermediate_successes}")
        print(f"   Intermediate success rate: {len(intermediate_successes)}/{len(intermediate_levels)}")
        
        # Performance analysis
        if successful_levels:
            successful_results = [results[wl] for wl in successful_levels]
            avg_time = sum(r['time'] for r in successful_results) / len(successful_results)
            max_time = max(r['time'] for r in successful_results)
            print(f"\n⚡ Performance: Avg {avg_time:.3f}s, Max {max_time:.3f}s per calculation")
        
        # Overall assessment
        print("\n" + "=" * 60)
        if len(failed_levels) == 0:
            print("🎉 ALL TESTS PASSED!")
            print("✅ Adaptive threshold fixes are working perfectly.")
            print("✅ All intermediate water levels produce flooding results.")
        elif len(failed_levels) <= 1:
            print("⚠️ MOSTLY SUCCESSFUL!")
            print("✅ Adaptive threshold fixes are mostly working.")
            print("✅ Critical intermediate timestep issue appears resolved.")
        else:
            print("❌ SIGNIFICANT ISSUES REMAIN!")
            print("🔧 Multiple water levels still failing - may need additional fixes.")
        
        print("=" * 60)
        
        return len(failed_levels) <= 1
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False
    except Exception as e:
        print(f"💥 Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_water_level_progression():
    """Test that we can generate proper water level progressions"""
    print("\n🌊 TESTING: Water Level Progression Generation")
    print("=" * 60)
    
    try:
        from model_hydraulic import generate_variable_water_levels_IMPROVED
        print("✅ Successfully imported generate_variable_water_levels_IMPROVED")
        
        # Test different scenarios
        scenarios = [
            {
                'name': 'Small simulation (5 steps)',
                'initial_level': 40.0,
                'time_steps': 5,
                'flow_q': 100,
                'method': 'accumulation'
            },
            {
                'name': 'Medium simulation (10 steps)',
                'initial_level': 42.0,
                'time_steps': 10,
                'flow_q': 150,
                'method': 'accumulation'
            },
            {
                'name': 'Linear method test',
                'initial_level': 38.0,
                'time_steps': 8,
                'flow_q': None,
                'method': 'linear'
            }
        ]
        
        all_passed = True
        
        for scenario in scenarios:
            print(f"\n📋 Testing: {scenario['name']}")
            print(f"   Initial: {scenario['initial_level']}m, Steps: {scenario['time_steps']}")
            
            try:
                water_levels = generate_variable_water_levels_IMPROVED(
                    initial_level=scenario['initial_level'],
                    time_steps=scenario['time_steps'],
                    flow_q=scenario['flow_q'],
                    method=scenario['method']
                )
                
                if water_levels and len(water_levels) == scenario['time_steps']:
                    min_level = min(water_levels)
                    max_level = max(water_levels)
                    variation = max_level - min_level
                    
                    print(f"   ✅ Generated {len(water_levels)} levels")
                    print(f"   📊 Range: {min_level:.2f}m to {max_level:.2f}m (Δ={variation:.2f}m)")
                    
                    # Check for adequate variation
                    if variation >= 0.2:  # At least 20cm variation
                        print(f"   ✅ Good variation: {variation:.2f}m")
                    else:
                        print(f"   ⚠️ Low variation: {variation:.2f}m")
                        all_passed = False
                        
                    # Check for monotonic progression (should generally increase)
                    increasing = all(water_levels[i] <= water_levels[i+1] for i in range(len(water_levels)-1))
                    if increasing:
                        print(f"   ✅ Monotonic progression")
                    else:
                        print(f"   ⚠️ Non-monotonic progression")
                    
                else:
                    print(f"   ❌ FAILED: Expected {scenario['time_steps']} levels, got {len(water_levels) if water_levels else 0}")
                    all_passed = False
                    
            except Exception as e:
                print(f"   💥 ERROR: {str(e)}")
                all_passed = False
        
        print("\n" + "-" * 60)
        if all_passed:
            print("🎉 WATER LEVEL PROGRESSION TEST PASSED!")
        else:
            print("❌ WATER LEVEL PROGRESSION TEST FAILED!")
        print("-" * 60)
        
        return all_passed
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False
    except Exception as e:
        print(f"💥 Unexpected error: {e}")
        return False

def test_key_fixes_validation():
    """Validate that our key fixes are properly implemented"""
    print("\n🔧 TESTING: Key Fixes Validation")
    print("=" * 60)
    
    fixes_found = 0
    total_fixes = 3
    
    try:
        # Test 1: Check for adaptive percentile thresholds
        print("🔍 Checking for adaptive percentile threshold implementation...")
        with open('model_hydraulic.py', 'r', encoding='utf-8') as f:
            content = f.read()
            
        if 'percentile_thresholds = [80, 70, 60, 50]' in content:
            print("   ✅ Adaptive percentile thresholds found")
            fixes_found += 1
        else:
            print("   ❌ Adaptive percentile thresholds NOT found")
        
        # Test 2: Check for bathtub fallback mechanism
        if 'bathtub_mask = valid_mask & (dem_array < water_level)' in content:
            print("   ✅ Bathtub fallback mechanism found")
            fixes_found += 1
        else:
            print("   ❌ Bathtub fallback mechanism NOT found")
        
        # Test 3: Check for enhanced water level generation
        if 'base_accumulation = 0.5' in content:
            print("   ✅ Enhanced water level generation found")
            fixes_found += 1
        else:
            print("   ❌ Enhanced water level generation NOT found")
        
        print(f"\n📊 Fixes validation: {fixes_found}/{total_fixes} key fixes implemented")
        
        if fixes_found == total_fixes:
            print("✅ All critical fixes are properly implemented!")
            return True
        else:
            print("⚠️ Some fixes may be missing or modified!")
            return False
            
    except Exception as e:
        print(f"💥 Error validating fixes: {e}")
        return False

if __name__ == "__main__":
    print("🚀 Starting Focused Adaptive Threshold Test")
    print("=" * 80)
    
    # Run the tests
    test1_passed = test_adaptive_threshold_function()
    test2_passed = test_water_level_progression()
    test3_passed = test_key_fixes_validation()
    
    # Final summary
    print("\n" + "🏁" * 20)
    print("FINAL TEST SUMMARY")
    print("🏁" * 20)
    
    tests_passed = sum([test1_passed, test2_passed, test3_passed])
    total_tests = 3
    
    print(f"📊 Tests passed: {tests_passed}/{total_tests}")
    print(f"🧪 Adaptive threshold test: {'✅ PASS' if test1_passed else '❌ FAIL'}")
    print(f"🌊 Water level progression: {'✅ PASS' if test2_passed else '❌ FAIL'}")
    print(f"🔧 Fixes validation: {'✅ PASS' if test3_passed else '❌ FAIL'}")
    
    if tests_passed == total_tests:
        print("\n🎉 ALL TESTS PASSED!")
        print("✅ Adaptive threshold fixes are working correctly!")
        print("✅ Intermediate timestep layers should now be populated!")
        print("✅ The critical timestep simulation issue is RESOLVED!")
    elif tests_passed >= 2:
        print("\n⚠️ MOSTLY SUCCESSFUL!")
        print("✅ Core adaptive threshold functionality is working!")
        print("✅ Intermediate timestep issue should be largely resolved!")
    else:
        print("\n❌ SIGNIFICANT ISSUES REMAIN!")
        print("🔧 The adaptive threshold fixes may need additional work!")
    
    print("🏁" * 20)
