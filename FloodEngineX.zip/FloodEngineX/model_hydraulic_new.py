import os
from qgis.core import QgsProject, QgsVectorLayer
from PyQt5.QtGui import QColor

def calculate_flood_area(
    iface,
    dem_path,
    water_levels,
    output_folder,
    flow_q=None,
    manning_n=None,
    **kwargs
):
    sv_result = simulate_saint_venant_2d(
        dem_path=dem_path,
        initial_water_level=water_levels[0] if isinstance(water_levels, list) else water_levels,
        output_folder=output_folder,
        inflow_rate=flow_q,
        manning_n=manning_n,
        time_steps=len(water_levels),
        water_levels=water_levels,
    )
    all_polygons = []
    for filename, tid, nivå in sv_result:
        wet_array = load_raster_to_array(filename)
        threshold = kwargs.get('wet_threshold', 0.05)
        binary_mask = (wet_array > threshold)
        polygon_layer = polygonize_mask(binary_mask, dem_path, output_folder, tid, nivå)
        layer_name = f"Flood_{tid:03d}_{nivå:.2f}m"
        polygon_layer.setName(layer_name)
        style_polygon_layer_blue_opacity(polygon_layer)
        QgsProject.instance().addMapLayer(polygon_layer)
        # Streamlines per timestep
        vx_path = filename.replace('depth', 'velocity_x')
        vy_path = filename.replace('depth', 'velocity_y')
        mask_path = filename
        gpkg_path = os.path.join(output_folder, f"streamlines_{tid:03d}.gpkg")
        create_streamlines_from_velocity(
            vx_path, vy_path, mask_path, gpkg_path, n_points=150, max_length=200, step=1.5
        )
        layer = QgsVectorLayer(gpkg_path, f"Streamlines_{tid:03d}", "ogr")
        QgsProject.instance().addMapLayer(layer)
        all_polygons.append(polygon_layer)
    return all_polygons

def load_raster_to_array(raster_path):
    import rasterio
    with rasterio.open(raster_path) as src:
        return src.read(1)

def polygonize_mask(mask, dem_path, output_folder, tid, nivå):
    import numpy as np
    import rasterio
    from rasterio.features import shapes
    import fiona
    from shapely.geometry import shape, mapping
    temp_tif = os.path.join(output_folder, f"temp_{tid:03d}.tif")
    with rasterio.open(dem_path) as src:
        meta = src.meta.copy()
        meta.update(dtype=rasterio.uint8, count=1)
        with rasterio.open(temp_tif, "w", **meta) as dst:
            dst.write(mask.astype(rasterio.uint8), 1)
    results = (
        {'geometry': shape(geom), 'properties': {'value': value}}
        for geom, value in shapes(mask.astype(np.uint8), mask=mask.astype(np.uint8), transform=meta['transform'])
        if value == 1
    )
    schema = {'geometry': 'Polygon', 'properties': {'value': 'int'}}
    gpkg_path = os.path.join(output_folder, f"Flood_{tid:03d}_{nivå:.2f}m.gpkg")
    with fiona.open(gpkg_path, 'w', driver='GPKG', crs=src.crs, schema=schema) as c:
        for feat in results:
            c.write({'geometry': mapping(feat['geometry']), 'properties': {'value': 1}})
    return QgsVectorLayer(gpkg_path, f"Flood_{tid:03d}_{nivå:.2f}m", "ogr")

def style_polygon_layer_blue_opacity(layer):
    symbol = layer.renderer().symbol()
    symbol.setColor(QColor(70, 140, 255, 120))
    symbol.setOpacity(0.47)
    layer.triggerRepaint()

def create_streamlines_from_velocity(
    vx_path, vy_path, mask_path, output_gpkg,
    n_points=200, max_length=300, step=1.0, crs=None
):
    import numpy as np
    import rasterio
    from shapely.geometry import LineString, mapping
    import fiona
    with rasterio.open(vx_path) as src_vx, \
         rasterio.open(vy_path) as src_vy, \
         rasterio.open(mask_path) as src_mask:
        vx = src_vx.read(1)
        vy = src_vy.read(1)
        mask = src_mask.read(1) > 0
        transform = src_vx.transform
        if crs is None:
            crs = src_vx.crs
    y_idx, x_idx = np.where(mask)
    if len(x_idx) > n_points:
        idx = np.random.choice(len(x_idx), n_points, replace=False)
        x_idx, y_idx = x_idx[idx], y_idx[idx]
    lines = []
    for x0, y0 in zip(x_idx, y_idx):
        pts = []
        x, y = float(x0), float(y0)
        for _ in range(max_length):
            col, row = int(round(x)), int(round(y))
            if (0 <= row < mask.shape[0]) and (0 <= col < mask.shape[1]) and mask[row, col]:
                pts.append(rasterio.transform.xy(transform, row, col))
                vx_val = vx[row, col]
                vy_val = vy[row, col]
                norm = np.hypot(vx_val, vy_val)
                if norm < 1e-6:
                    break
                x += (vx_val / norm) * step
                y += (vy_val / norm) * step
            else:
                break
        if len(pts) > 1:
            lines.append(LineString(pts))
    schema = {'geometry': 'LineString', 'properties': {}}
    with fiona.open(output_gpkg, 'w', driver='GPKG', crs=crs, schema=schema) as c:
        for line in lines:
            c.write({'geometry': mapping(line), 'properties': {}})
    return output_gpkg

def simulate_saint_venant_2d(
    dem_path,
    initial_water_level,
    output_folder,
    inflow_rate,
    manning_n,
    time_steps,
    water_levels,
    **kwargs
):
    # Din SV-kärna här! Byt ut/komplettera!
    raise NotImplementedError("Replace with your own SV kernel integration.")
