# FloodEngine QGIS Plugin

## Overview

FloodEngine is an advanced QGIS plugin for flood modeling and erosion analysis. It provides tools for creating flood maps, analyzing erosion risk, visualizing flow patterns, and performing hydraulic calculations based on flow rates (Q).

This implementation follows the design outlined in the implementation plan, providing both basic and advanced functionality with a clear, user-friendly interface.

## Files Structure

The plugin consists of the following key files:

```
FloodEngine/
├── __init__.py               # Plugin initialization
├── floodengine.py            # Main plugin class
├── floodengine_ui.py         # User interface dialog
├── floodengine_equations.py  # Equation display system
├── model_hydraulic.py        # Core hydraulic calculations
├── advanced_hydraulics.py    # Advanced hydraulic models (SWE)
├── icon.png                  # Plugin icon
└── metadata.txt              # Plugin metadata
```

## Implementation Steps

### 1. Create the Basic Plugin Structure

1. Create a folder named `FloodEngine` for your plugin
2. Copy the provided files into this structure
3. Make sure `__init__.py` contains the `classFactory` function

### 2. User Interface Implementation

The UI is implemented in `floodengine_ui.py` and features:

- Two modes: Basic and Advanced
- A stacked widget to switch between modes
- Comprehensive input sections for all required parameters
- Interactive elements like sliders and checkboxes
- Equation display buttons with LaTeX support

Key features include:
- Consistent section headers with equation buttons
- Collapsible sections for advanced options
- Dynamic enabling/disabling of options based on selections

### 3. Core Hydraulic Functionality

The core hydraulic calculations are implemented in `model_hydraulic.py`:

- Flood area calculation based on DEM and water level
- Stream burning for incorporating stream networks
- Erosion risk assessment
- Flow vector generation
- Streamlines calculation

### 4. Q-based Hydraulics

Q-based hydraulic calculations are implemented:

- Water level calculation from flow rate (Q)
- Erosion risk assessment based on flow conditions
- Flow pattern visualization
- Report generation

### 5. Equation Display System

The equation display system in `floodengine_equations.py` provides:

- LaTeX rendering of mathematical equations
- Categorized tabs for different types of equations
- Descriptive text explaining each equation
- A polished, professional appearance

## Installation Instructions

1. Create a ZIP file of the `FloodEngine` folder
2. Open QGIS
3. Go to Plugins > Manage and Install Plugins
4. Select "Install from ZIP" tab
5. Choose your ZIP file and click "Install"

## Troubleshooting

If you encounter issues:

1. Check that all dependencies are installed (GDAL, NumPy)
2. Verify file permissions
3. Look for error messages in the QGIS Python Console
4. Check the log file in your home directory: `FloodEngine_plugin_log.txt`

### Common Issues

- **UI doesn't appear**: Check that `floodengine.py` correctly creates and shows the dialog
- **Missing icons**: Verify that icon paths are correct and fallbacks are provided
- **Calculation errors**: Ensure input validation is properly implemented

## Development Notes

### UI Extension

The UI is designed to be extensible. To add new functionality:

1. Create a new section in the appropriate tab
2. Add corresponding methods in the `floodengine.py` file
3. Implement the computational logic in `model_hydraulic.py` or a specialized module

### Equations

To add new equations to the equation display system:

1. Create a new method in `EquationDisplay` class
2. Add appropriate LaTeX equations and descriptions
3. Connect to the corresponding equation button

## Roadmap

Future enhancements planned for FloodEngine:

1. Full implementation of 2D Shallow Water Equations
2. Advanced sediment transport modeling
3. Coupled groundwater-surface water interaction
4. Urban flood modeling with infrastructure elements
5. API integration for automated data retrieval
