print("FloodEngine Import Validation")
print("=" * 30)

# Check if load_bathymetry function exists in model_hydraulic.py
print("Checking model_hydraulic.py for load_bathymetry function...")

try:
    with open('model_hydraulic.py', 'r') as f:
        content = f.read()
        if 'def load_bathymetry(' in content:
            print("✓ load_bathymetry function found in model_hydraulic.py")
        else:
            print("✗ load_bathymetry function NOT found in model_hydraulic.py")
except Exception as e:
    print(f"✗ Error reading model_hydraulic.py: {e}")

# Check if the import statement is correct in floodengine_ui.py  
print("\nChecking floodengine_ui.py import statement...")

try:
    with open('floodengine_ui.py', 'r') as f:
        content = f.read()
        if 'load_bathymetry,' in content and 'from .model_hydraulic import' in content:
            print("✓ load_bathymetry is imported in floodengine_ui.py")
        else:
            print("✗ load_bathymetry import NOT found in floodengine_ui.py")
except Exception as e:
    print(f"✗ Error reading floodengine_ui.py: {e}")

# Check __init__.py structure
print("\nChecking __init__.py...")

try:
    with open('__init__.py', 'r') as f:
        content = f.read()
        if 'classFactory' in content and 'FloodEngine' in content:
            print("✓ __init__.py has correct structure")
        else:
            print("✗ __init__.py structure issue")
except Exception as e:
    print(f"✗ Error reading __init__.py: {e}")

print("\n" + "=" * 30)
print("Validation complete!")
print("If all checks passed, the import error should be fixed.")
