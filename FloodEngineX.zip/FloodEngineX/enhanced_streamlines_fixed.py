"""
Enhanced Streamline Generation for FloodEngine - CRITICAL VELOCITY FIXES
------------------------------------------------------------------------
This version addresses the root causes of extreme velocities that persist 
despite multiple capping layers.

CRITICAL FIXES APPLIED:
1. No adjustment methods applied to Saint-Venant results (they already have proper physics)
2. Simplified and bulletproof final velocity capping
3. More aggressive Saint-Venant validation and rejection
4. Fixed streamline seeding to focus on actual river channels
5. Removed complex logic that could bypass velocity caps
"""

import os
import time
import math
import numpy as np
import random
from osgeo import gdal
import logging
from scipy.ndimage import gaussian_filter
from qgis.core import (
    QgsVectorLayer, QgsField, QgsFeature, QgsGeometry, QgsPointXY,
    QgsWkbTypes, QgsVectorFileWriter, QgsPoint, QgsCoordinateReferenceSystem,
    QgsFields
)
from PyQt5.QtCore import QVariant

logger = logging.getLogger("FloodEngine.EnhancedStreamlines")

class EnhancedStreamlines:
    """Advanced streamline generation with FIXED hydraulics"""
    
    def __init__(self, dem_array, geotransform, water_depth=None, water_level=None):
        """Initialize streamline generator with critical fixes."""
        self.dem = dem_array
        self.geotransform = geotransform
        self.shape = dem_array.shape
        
        # Calculate cell size from geotransform
        self.dx = abs(geotransform[1])
        self.dy = abs(geotransform[5])
        
        # Set water depth
        if water_depth is not None:
            self.water_depth = water_depth
        elif water_level is not None:
            if isinstance(water_level, (int, float)):
                self.water_depth = np.maximum(water_level - dem_array, 0)
            else:
                self.water_depth = np.maximum(water_level - dem_array, 0)
        else:
            self.water_depth = np.zeros_like(dem_array)
        
        # Initialize velocity fields
        self.velocity_x = np.zeros(self.shape)
        self.velocity_y = np.zeros(self.shape)
        self.velocity_mag = np.zeros(self.shape)
        
        # FIXED parameters - much more conservative
        self.min_velocity = 0.01  # m/s
        self.min_depth = 0.01     # m
        self.max_steps = 1000     # maximum steps per streamline
        self.smoothing = 1.5      # smoothing parameter
        
        # CRITICAL: Removed curvature and bottleneck factors - these cause the extreme velocities!
        # These adjustment methods should NOT be applied to Saint-Venant results
        
    def calculate_velocity_field(self, manning_n=0.035, method="hydraulic", 
                                saint_venant_results=None):
        """
        Calculate velocity field with CRITICAL FIXES to prevent extreme velocities.
        
        MAJOR CHANGES:
        1. More aggressive Saint-Venant validation and rejection
        2. No adjustment methods applied to Saint-Venant results
        3. Simplified, bulletproof final capping
        4. Fail-fast approach when velocities are unrealistic
        """
        logger.info(f"🔧 FIXED: Calculating velocity field using {method} method")
        
        # CRITICAL FIX 1: Much more aggressive Saint-Venant validation
        if saint_venant_results is not None:
            logger.warning("🛡️  CRITICAL: Applying aggressive Saint-Venant validation")
            
            # Get velocity statistics
            if 'velocity_magnitude' not in saint_venant_results:
                saint_venant_results['velocity_magnitude'] = np.sqrt(
                    saint_venant_results.get('velocity_x', np.zeros((1,1)))**2 + 
                    saint_venant_results.get('velocity_y', np.zeros((1,1)))**2
                )
            
            max_vel = np.max(saint_venant_results['velocity_magnitude'])
            mean_vel = np.mean(saint_venant_results['velocity_magnitude'])
            cells_over_5 = np.sum(saint_venant_results['velocity_magnitude'] > 5.0)
            cells_over_10 = np.sum(saint_venant_results['velocity_magnitude'] > 10.0)
            
            logger.warning(f"Saint-Venant validation: max={max_vel:.1f}, mean={mean_vel:.1f}, >5m/s={cells_over_5}, >10m/s={cells_over_10}")
            
            # MUCH MORE AGGRESSIVE rejection criteria
            should_reject = False
            rejection_reasons = []
            
            if max_vel > 8.0:
                should_reject = True
                rejection_reasons.append(f"max velocity {max_vel:.1f} m/s > 8.0 m/s")
            
            if mean_vel > 2.0:
                should_reject = True
                rejection_reasons.append(f"mean velocity {mean_vel:.1f} m/s > 2.0 m/s")
            
            if cells_over_5 > 100:
                should_reject = True
                rejection_reasons.append(f"{cells_over_5} cells > 5 m/s (too many)")
            
            if cells_over_10 > 0:
                should_reject = True
                rejection_reasons.append(f"{cells_over_10} cells > 10 m/s (any is too many)")
                
            if should_reject:
                logger.error("🚨 REJECTING Saint-Venant results - unrealistic velocities detected:")
                for reason in rejection_reasons:
                    logger.error(f"   ❌ {reason}")
                logger.error("🔄 FORCING fallback to hydraulic approximation")
                saint_venant_results = None
                method = "hydraulic"
            else:
                logger.info("✅ Saint-Venant results passed aggressive validation")
        
        # CRITICAL FIX 2: Use Saint-Venant results WITHOUT any adjustments
        if saint_venant_results is not None and method == "saint_venant":
            logger.info("🎯 Using Saint-Venant velocity field (NO ADJUSTMENTS - they have proper physics)")
            
            # Apply emergency capping ONCE, cleanly
            ABSOLUTE_CAP = 5.0  # Conservative cap for Saint-Venant
            
            # Simple, clean capping
            saint_venant_results['velocity_x'] = np.clip(
                saint_venant_results['velocity_x'], -ABSOLUTE_CAP, ABSOLUTE_CAP
            )
            saint_venant_results['velocity_y'] = np.clip(
                saint_venant_results['velocity_y'], -ABSOLUTE_CAP, ABSOLUTE_CAP
            )
            saint_venant_results['velocity_magnitude'] = np.clip(
                saint_venant_results['velocity_magnitude'], 0.0, ABSOLUTE_CAP
            )
            
            # Ensure shape compatibility
            if (saint_venant_results['velocity_x'].shape != self.shape or
                saint_venant_results['velocity_y'].shape != self.shape):
                logger.warning(f"Resizing Saint-Venant velocity fields from {saint_venant_results['velocity_x'].shape} to {self.shape}")
                from scipy.ndimage import zoom
                y_scale = self.shape[0] / saint_venant_results['velocity_x'].shape[0]
                x_scale = self.shape[1] / saint_venant_results['velocity_x'].shape[1]
                
                self.velocity_x = zoom(saint_venant_results['velocity_x'], (y_scale, x_scale), order=1)
                self.velocity_y = zoom(saint_venant_results['velocity_y'], (y_scale, x_scale), order=1)
                self.velocity_mag = zoom(saint_venant_results['velocity_magnitude'], (y_scale, x_scale), order=1)
            else:
                # Direct assignment
                self.velocity_x = saint_venant_results['velocity_x'].copy()
                self.velocity_y = saint_venant_results['velocity_y'].copy()
                self.velocity_mag = saint_venant_results['velocity_magnitude'].copy()
            
            # Apply water depth mask
            water_mask = self.water_depth > self.min_depth
            self.velocity_x = np.where(water_mask, self.velocity_x, 0.0)
            self.velocity_y = np.where(water_mask, self.velocity_y, 0.0)
            self.velocity_mag = np.where(water_mask, self.velocity_mag, 0.0)
            
            # CRITICAL: NO adjustment methods applied to Saint-Venant results!
            # Saint-Venant already accounts for 2D physics, curves, bottlenecks, etc.
            
            # Simple final validation
            final_max = np.max(self.velocity_mag)
            if final_max > ABSOLUTE_CAP:
                logger.error(f"🚨 CRITICAL: Final Saint-Venant velocity {final_max:.1f} m/s > {ABSOLUTE_CAP} m/s")
                logger.error("🔄 Something is wrong - forcing hydraulic fallback")
                method = "hydraulic"
                saint_venant_results = None
            else:
                logger.info(f"✅ Saint-Venant final check: max velocity = {final_max:.3f} m/s")
                return self.velocity_x, self.velocity_y, self.velocity_mag
        
        # CRITICAL FIX 3: Improved hydraulic approximation with better capping
        logger.info("🔧 Using improved hydraulic approximation method")
        
        # Initialize arrays
        self.velocity_x = np.zeros(self.shape)
        self.velocity_y = np.zeros(self.shape)
        self.velocity_mag = np.zeros(self.shape)
        
        # Create water surface with smoothing
        self.water_level = self.dem + self.water_depth
        water_surface = np.pad(self.water_level, pad_width=2, mode='edge')
        water_surface = gaussian_filter(water_surface, sigma=self.smoothing)
        
        # Valid flow mask
        valid_mask = self.water_depth > self.min_depth
        
        if np.sum(valid_mask) == 0:
            logger.warning("No cells with sufficient water depth for velocity calculation!")
            return self.velocity_x, self.velocity_y, self.velocity_mag
        
        # Process valid cells
        valid_indices = np.argwhere(valid_mask)
        
        # Ensure manning_n is array-like
        if isinstance(manning_n, (int, float)):
            manning_array = np.full(self.shape, manning_n)
        else:
            manning_array = manning_n
        
        # IMPROVED hydraulic calculation with better flow accumulation
        logger.info("🔧 IMPROVED: Using 2D hydraulic modeling with conservative parameters")
        
        # Calculate flow accumulation
        flow_accumulation = self._calculate_flow_accumulation(valid_mask)
        
        # Calculate bed slope
        padded_dem = np.pad(self.dem, pad_width=2, mode='edge')
        
        # Calculate water surface slope
        water_surface_slope_x = np.zeros(self.shape)
        water_surface_slope_y = np.zeros(self.shape)
        
        for i, j in valid_indices:
            ws_dh_dx = (water_surface[i+2, j+3] - water_surface[i+2, j+1]) / (2 * self.dx)
            ws_dh_dy = (water_surface[i+3, j+2] - water_surface[i+1, j+2]) / (2 * self.dy)
            
            water_surface_slope_x[i, j] = ws_dh_dx
            water_surface_slope_y[i, j] = ws_dh_dy
        
        # Calculate velocities for each valid cell
        for i, j in valid_indices:
            depth = self.water_depth[i, j]
            
            # Calculate bed slope
            bed_dh_dx = (padded_dem[i+2, j+3] - padded_dem[i+2, j+1]) / (2 * self.dx)
            bed_dh_dy = (padded_dem[i+3, j+2] - padded_dem[i+1, j+2]) / (2 * self.dy)
            bed_slope_mag = np.sqrt(bed_dh_dx**2 + bed_dh_dy**2)
            
            # Apply minimum slope for channels
            if depth > 1.5:
                min_slope = 0.0005  # REDUCED from 0.001 for more conservative velocities
                if bed_slope_mag < min_slope:
                    bed_slope_mag = min_slope
            elif depth > 0.5:
                min_slope = 0.0003  # REDUCED
                if bed_slope_mag < min_slope:
                    bed_slope_mag = min_slope
            
            # Get water surface slope
            ws_slope_x = water_surface_slope_x[i, j]
            ws_slope_y = water_surface_slope_y[i, j]
            ws_slope_mag = np.sqrt(ws_slope_x**2 + ws_slope_y**2)
            
            # Get flow accumulation
            flow_acc = flow_accumulation[i, j]
            
            # Calculate upstream discharge (CONSERVATIVE)
            upstream_discharge = self._calculate_upstream_discharge(flow_acc, depth)
            
            # CONSERVATIVE velocity calculation
            if depth > 1.5:  # Main channel
                n_effective = manning_array[i, j] * 1.0  # Normal roughness
                channel_factor = 1.0  # REDUCED from 1.2 - no artificial enhancement
            elif depth > 0.5:  # Secondary channels
                n_effective = manning_array[i, j] * 1.1
                channel_factor = 0.9  # REDUCED from 1.1
            else:  # Floodplain
                n_effective = manning_array[i, j] * 1.2
                channel_factor = 0.8
            
            # Manning velocity with CONSERVATIVE cap
            if bed_slope_mag > 1e-6:
                hydraulic_radius = depth
                manning_vel = (1.0 / n_effective) * (hydraulic_radius ** (2/3)) * (bed_slope_mag ** 0.5)
                
                # CRITICAL: Conservative Manning velocity cap
                manning_vel = min(manning_vel, 2.0)  # REDUCED from 3.0
                
                # Flow direction from bed slope
                bed_dir_x = -bed_dh_dx / bed_slope_mag
                bed_dir_y = -bed_dh_dy / bed_slope_mag
            else:
                manning_vel = 0.0
                bed_dir_x = 0.0
                bed_dir_y = -1.0
            
            # Pressure velocity (CONSERVATIVE)
            if ws_slope_mag > 1e-6:
                pressure_vel = upstream_discharge / (depth * 1.0)
                pressure_vel = min(pressure_vel, 1.5)  # REDUCED from 2.0
                
                ws_dir_x = -ws_slope_x / ws_slope_mag
                ws_dir_y = -ws_slope_y / ws_slope_mag
            else:
                pressure_vel = 0.0
                ws_dir_x = 0.0
                ws_dir_y = -1.0
            
            # Combine velocities (CONSERVATIVE)
            if bed_slope_mag > 1e-4:
                vel_magnitude = manning_vel * channel_factor + 0.2 * pressure_vel  # REDUCED from 0.3
                direction_x = bed_dir_x
                direction_y = bed_dir_y
            else:
                vel_magnitude = 0.2 * manning_vel + pressure_vel * channel_factor  # REDUCED from 0.3
                direction_x = ws_dir_x
                direction_y = ws_dir_y
            
            # Apply minimum velocity (CONSERVATIVE)
            min_vel = min(0.03 + 0.01 * np.log10(max(float(flow_acc), 1)), 0.3)  # REDUCED from 0.5
            vel_magnitude = max(vel_magnitude, min_vel)
            
            # Flow concentration bonus (VERY CONSERVATIVE)
            if depth > 1.5:  # Main channel
                flow_bonus = 0.2 + 0.05 * np.log10(max(float(flow_acc), 1))  # REDUCED
                flow_bonus = min(flow_bonus, 0.4)  # REDUCED from 0.8
                vel_magnitude += flow_bonus
            elif depth > 0.5:  # Secondary channel
                flow_bonus = 0.1 + 0.02 * np.log10(max(float(flow_acc), 1))  # REDUCED
                flow_bonus = min(flow_bonus, 0.2)  # REDUCED from 0.4
                vel_magnitude += flow_bonus
            
            # CRITICAL: Conservative final velocity cap
            vel_magnitude = min(vel_magnitude, 3.0)  # REDUCED from 4.0
            
            # Store velocity components
            self.velocity_x[i, j] = vel_magnitude * direction_x
            self.velocity_y[i, j] = vel_magnitude * direction_y
            self.velocity_mag[i, j] = vel_magnitude
        
        # CRITICAL FIX 4: Apply adjustment methods ONLY to hydraulic approximation
        # (Never to Saint-Venant results which already have proper physics)
        if method == "hydraulic":
            logger.info("🔧 Applying CONSERVATIVE adjustments to hydraulic approximation")
            self._apply_conservative_adjustments()
        
        # CRITICAL FIX 5: Simple, bulletproof final velocity capping
        self._apply_bulletproof_final_capping()
        
        # Log final statistics
        final_max = np.max(self.velocity_mag)
        final_mean = np.mean(self.velocity_mag[self.velocity_mag > 0])
        cells_with_flow = np.sum(self.velocity_mag > 0.01)
        
        logger.info(f"🎯 FINAL velocity field statistics ({method} method):")
        logger.info(f"  • Max velocity: {final_max:.3f} m/s")
        logger.info(f"  • Mean velocity: {final_mean:.3f} m/s")
        logger.info(f"  • Cells with flow: {cells_with_flow}")
        
        # CRITICAL: Final validation - if still too high, something is fundamentally wrong
        if final_max > 5.0:
            logger.error(f"🚨 CRITICAL FAILURE: Final velocity {final_max:.1f} m/s is still too high!")
            logger.error("🚨 This indicates a fundamental calculation error - setting all velocities to safe defaults")
            self.velocity_x.fill(0.0)
            self.velocity_y.fill(0.0)
            self.velocity_mag.fill(0.0)
            
            # Create basic downhill flow as fallback
            self._create_basic_downhill_flow()
        
        return self.velocity_x, self.velocity_y, self.velocity_mag
    
    def _apply_conservative_adjustments(self):
        """Apply very conservative adjustments only to hydraulic approximation."""
        logger.info("🔧 Applying conservative curvature and bottleneck adjustments")
        
        # Very conservative adjustment factors
        max_curvature_boost = 1.02  # Only 2% increase maximum
        max_bottleneck_boost = 1.05  # Only 5% increase maximum
        
        # Calculate curvature with conservative adjustment
        padded_dem = np.pad(self.dem, pad_width=1, mode='edge')
        rows, cols = self.shape
        
        for i in range(rows):
            for j in range(cols):
                if self.water_depth[i, j] <= self.min_depth:
                    continue
                
                # Calculate curvature
                d2z_dx2 = (padded_dem[i+1, j+2] - 2*padded_dem[i+1, j+1] + padded_dem[i+1, j]) / (self.dx**2)
                d2z_dy2 = (padded_dem[i+2, j+1] - 2*padded_dem[i+1, j+1] + padded_dem[i, j+1]) / (self.dy**2)
                
                curvature = abs(d2z_dx2 + d2z_dy2)
                
                # Normalize and apply very conservative boost
                if curvature > 0:
                    norm_curvature = min(curvature / 0.01, 1.0)  # Normalize to max 0.01
                    curvature_factor = 1.0 + (max_curvature_boost - 1.0) * norm_curvature
                    
                    # Apply conservative curvature adjustment
                    self.velocity_mag[i, j] *= curvature_factor
                
                # Calculate bottleneck factor (depth gradient)
                if i > 0 and i < rows-1 and j > 0 and j < cols-1:
                    depth_grad_x = (self.water_depth[i, j+1] - self.water_depth[i, j-1]) / (2 * self.dx)
                    depth_grad_y = (self.water_depth[i+1, j] - self.water_depth[i-1, j]) / (2 * self.dy)
                    bottleneck_factor_raw = np.sqrt(depth_grad_x**2 + depth_grad_y**2)
                    
                    if bottleneck_factor_raw > 0:
                        norm_bottleneck = min(bottleneck_factor_raw / 0.1, 1.0)  # Normalize
                        bottleneck_factor = 1.0 + (max_bottleneck_boost - 1.0) * norm_bottleneck
                        
                        # Apply conservative bottleneck adjustment
                        self.velocity_mag[i, j] *= bottleneck_factor
        
        # Update velocity components
        valid_mask = (self.velocity_mag > 0) & (np.sqrt(self.velocity_x**2 + self.velocity_y**2) > 0)
        
        if np.any(valid_mask):
            old_magnitude = np.sqrt(self.velocity_x[valid_mask]**2 + self.velocity_y[valid_mask]**2)
            ratio = self.velocity_mag[valid_mask] / old_magnitude
            self.velocity_x[valid_mask] *= ratio
            self.velocity_y[valid_mask] *= ratio
    
    def _apply_bulletproof_final_capping(self):
        """Apply simple, bulletproof final velocity capping that cannot fail."""
        logger.info("🛡️  Applying bulletproof final velocity capping")
        
        # Simple, aggressive capping
        FINAL_ABSOLUTE_CAP = 4.0  # No velocity can exceed this under any circumstances
        
        # Cap velocity magnitude
        self.velocity_mag = np.clip(self.velocity_mag, 0.0, FINAL_ABSOLUTE_CAP)
        
        # Cap velocity components
        self.velocity_x = np.clip(self.velocity_x, -FINAL_ABSOLUTE_CAP, FINAL_ABSOLUTE_CAP)
        self.velocity_y = np.clip(self.velocity_y, -FINAL_ABSOLUTE_CAP, FINAL_ABSOLUTE_CAP)
        
        # Ensure magnitude is consistent with components
        calculated_magnitude = np.sqrt(self.velocity_x**2 + self.velocity_y**2)
        self.velocity_mag = np.minimum(self.velocity_mag, calculated_magnitude)
        self.velocity_mag = np.clip(self.velocity_mag, 0.0, FINAL_ABSOLUTE_CAP)
        
        # Apply water mask
        water_mask = self.water_depth > self.min_depth
        self.velocity_x = np.where(water_mask, self.velocity_x, 0.0)
        self.velocity_y = np.where(water_mask, self.velocity_y, 0.0)
        self.velocity_mag = np.where(water_mask, self.velocity_mag, 0.0)
        
        # Clean up any remaining NaN or infinite values
        self.velocity_x = np.nan_to_num(self.velocity_x, nan=0.0, posinf=0.0, neginf=0.0)
        self.velocity_y = np.nan_to_num(self.velocity_y, nan=0.0, posinf=0.0, neginf=0.0)
        self.velocity_mag = np.nan_to_num(self.velocity_mag, nan=0.0, posinf=0.0, neginf=0.0)
        
        final_max = np.max(self.velocity_mag)
        logger.info(f"🛡️  Final capping complete: max velocity = {final_max:.3f} m/s")
    
    def _create_basic_downhill_flow(self):
        """Create basic downhill flow as emergency fallback."""
        logger.warning("🚨 Creating basic downhill flow as emergency fallback")
        
        # Calculate simple downhill flow
        rows, cols = self.shape
        for i in range(1, rows-1):
            for j in range(1, cols-1):
                if self.water_depth[i, j] > self.min_depth:
                    # Find steepest downhill direction
                    min_elev = self.dem[i, j]
                    best_di, best_dj = 0, 0
                    
                    for di in [-1, 0, 1]:
                        for dj in [-1, 0, 1]:
                            if di == 0 and dj == 0:
                                continue
                            ni, nj = i + di, j + dj
                            if 0 <= ni < rows and 0 <= nj < cols:
                                if self.dem[ni, nj] < min_elev:
                                    min_elev = self.dem[ni, nj]
                                    best_di, best_dj = di, dj
                    
                    # Set basic velocity in steepest direction
                    if best_di != 0 or best_dj != 0:
                        distance = np.sqrt(best_di**2 + best_dj**2)
                        basic_velocity = 0.5  # Conservative 0.5 m/s
                        
                        self.velocity_x[i, j] = basic_velocity * best_dj / distance
                        self.velocity_y[i, j] = basic_velocity * best_di / distance
                        self.velocity_mag[i, j] = basic_velocity
    
    def generate_streamlines(self, flood_mask=None, seed_points=None, num_seeds=200):
        """Generate streamlines with FIXED seeding to focus on river channels."""
        logger.info("🔧 FIXED: Generating enhanced streamlines with improved seeding")
        
        # Create flood mask if not provided
        if flood_mask is None:
            flood_mask = self.water_depth > self.min_depth
        
        # CRITICAL FIX: Improved seed point generation focusing on river channels
        if seed_points is None:
            seed_points = self._generate_improved_seed_points(flood_mask, num_seeds)
            
        logger.info(f"Using {len(seed_points)} seed points for streamlines")
        
        # Generate streamlines from each seed point
        streamlines = []
        for seed in seed_points:
            # Convert to pixel coordinates
            px = int((seed.x() - self.geotransform[0]) / self.geotransform[1])
            py = int((seed.y() - self.geotransform[3]) / self.geotransform[5])
            
            # Skip if outside raster or not in flood area
            if (px < 0 or px >= self.shape[1] or 
                py < 0 or py >= self.shape[0] or
                not flood_mask[py, px]):
                continue
                
            # Generate streamline
            points = self._trace_streamline_rk4(seed, flood_mask)
            
            # Add streamline if it has enough points
            if len(points) >= 3:
                streamlines.append(points)
        
        logger.info(f"Generated {len(streamlines)} streamlines")
        return streamlines
    
    def _generate_improved_seed_points(self, flood_mask, num_seeds):
        """Generate improved seed points focusing on actual river channels."""
        seed_points = []
        
        # CRITICAL FIX: Focus on river channels (deep water) first
        logger.info("🎯 FIXED: Generating seed points with river channel focus")
        
        # Method 1: Deep water areas (main river channels) - 60% of seeds
        deep_water_mask = (self.water_depth > 1.0) & flood_mask
        deep_water_indices = np.argwhere(deep_water_mask)
        
        if len(deep_water_indices) > 0:
            num_deep_seeds = min(int(num_seeds * 0.6), len(deep_water_indices))
            selected_indices = deep_water_indices[
                np.random.choice(len(deep_water_indices), num_deep_seeds, replace=False)
            ]
            
            for i, j in selected_indices:
                x = self.geotransform[0] + j * self.geotransform[1]
                y = self.geotransform[3] + i * self.geotransform[5]
                seed_points.append(QgsPointXY(x, y))
            
            logger.info(f"Added {num_deep_seeds} seeds in deep water (main channels)")
        
        # Method 2: Areas with MODERATE velocity (0.1-2.0 m/s) - 30% of seeds
        moderate_velocity_mask = ((self.velocity_mag > 0.1) & (self.velocity_mag < 2.0) & 
                                 flood_mask & (self.water_depth > 0.3))
        moderate_vel_indices = np.argwhere(moderate_velocity_mask)
        
        if len(moderate_vel_indices) > 0:
            remaining_seeds = num_seeds - len(seed_points)
            num_moderate_seeds = min(int(num_seeds * 0.3), len(moderate_vel_indices), remaining_seeds)
            
            if num_moderate_seeds > 0:
                selected_indices = moderate_vel_indices[
                    np.random.choice(len(moderate_vel_indices), num_moderate_seeds, replace=False)
                ]
                
                for i, j in selected_indices:
                    x = self.geotransform[0] + j * self.geotransform[1]
                    y = self.geotransform[3] + i * self.geotransform[5]
                    seed_points.append(QgsPointXY(x, y))
                
                logger.info(f"Added {num_moderate_seeds} seeds in moderate velocity areas")
        
        # Method 3: Regular grid in remaining flooded areas - 10% of seeds
        remaining_seeds = num_seeds - len(seed_points)
        if remaining_seeds > 0:
            all_flood_indices = np.argwhere(flood_mask)
            
            if len(all_flood_indices) > 0:
                num_random_seeds = min(remaining_seeds, len(all_flood_indices))
                selected_indices = all_flood_indices[
                    np.random.choice(len(all_flood_indices), num_random_seeds, replace=False)
                ]
                
                for i, j in selected_indices:
                    x = self.geotransform[0] + j * self.geotransform[1]
                    y = self.geotransform[3] + i * self.geotransform[5]
                    seed_points.append(QgsPointXY(x, y))
                
                logger.info(f"Added {num_random_seeds} seeds in remaining flooded areas")
        
        logger.info(f"Total seed points generated: {len(seed_points)}")
        return seed_points
    
    def _trace_streamline_rk4(self, start_point, flood_mask):
        """Trace streamline using RK4 integration with improved stability."""
        points = []
        points.append(QgsPoint(start_point.x(), start_point.y()))
        
        current_point = start_point
        
        # Conservative parameters
        base_step = min(self.dx, self.dy) * 0.3  # REDUCED from 0.5 for stability
        max_iterations = self.max_steps
        
        for iteration in range(max_iterations):
            # Convert to pixel coordinates
            px = int((current_point.x() - self.geotransform[0]) / self.geotransform[1])
            py = int((current_point.y() - self.geotransform[3]) / self.geotransform[5])
            
            # Check bounds and flood area
            if (px < 2 or px >= self.shape[1] - 2 or 
                py < 2 or py >= self.shape[0] - 2 or
                not flood_mask[py, px]):
                break
                
            # Check velocity
            local_velocity_mag = self.velocity_mag[py, px]
            if local_velocity_mag < self.min_velocity:
                break
                
            # Adaptive step size
            dt = base_step / max(local_velocity_mag, 0.1)
            dt = min(dt, 1.0)  # REDUCED from 2.0 for stability
            
            # Get velocity
            vx = self.velocity_x[py, px]
            vy = self.velocity_y[py, px]
            
            # Simple RK4 integration
            # Step 1
            k1x = vx
            k1y = vy
            
            # Step 2
            mid_x1 = current_point.x() + 0.5 * dt * k1x
            mid_y1 = current_point.y() + 0.5 * dt * k1y
            
            mid_px = int((mid_x1 - self.geotransform[0]) / self.geotransform[1])
            mid_py = int((mid_y1 - self.geotransform[3]) / self.geotransform[5])
            
            if (mid_px < 0 or mid_px >= self.shape[1] or 
                mid_py < 0 or mid_py >= self.shape[0] or
                not flood_mask[mid_py, mid_px]):
                break
                
            k2x = self.velocity_x[mid_py, mid_px]
            k2y = self.velocity_y[mid_py, mid_px]
            
            # Calculate new point
            next_x = current_point.x() + dt * k2x
            next_y = current_point.y() + dt * k2y
            
            # Check minimum distance
            min_distance = 0.3 * self.dx  # REDUCED from 0.5
            if len(points) > 0:
                last_point = points[-1]
                dist = math.sqrt((next_x - last_point.x())**2 + (next_y - last_point.y())**2)
                if dist < min_distance:
                    current_point = QgsPointXY(next_x, next_y)
                    continue
            
            # Add point
            points.append(QgsPoint(next_x, next_y))
            current_point = QgsPointXY(next_x, next_y)
        
        return points
    
    def save_streamlines_shapefile(self, streamlines, output_path, crs="EPSG:3006"):
        """Save streamlines to shapefile."""
        logger.info(f"Saving {len(streamlines)} streamlines to {output_path}")
        
        # Create fields
        fields = QgsFields()
        fields.append(QgsField("id", QVariant.Int))
        fields.append(QgsField("length", QVariant.Double))
        fields.append(QgsField("speed", QVariant.Double))
        
        # Create writer
        writer = QgsVectorFileWriter(
            output_path,
            "UTF-8",
            fields,
            QgsWkbTypes.LineString,
            QgsCoordinateReferenceSystem(crs),
            "ESRI Shapefile"
        )
        
        if writer.hasError() != QgsVectorFileWriter.NoError:
            logger.error(f"Error creating shapefile: {writer.errorMessage()}")
            return None
        
        # Write features
        for i, points in enumerate(streamlines):
            if len(points) >= 2:
                feature = QgsFeature(fields)
                feature.setGeometry(QgsGeometry.fromPolyline(points))
                
                # Calculate length
                length = 0
                for j in range(1, len(points)):
                    dx = points[j].x() - points[j-1].x()
                    dy = points[j].y() - points[j-1].y()
                    length += math.sqrt(dx*dx + dy*dy)
                
                # Calculate average speed
                speeds = []
                for point in points:
                    px = int((point.x() - self.geotransform[0]) / self.geotransform[1])
                    py = int((point.y() - self.geotransform[3]) / self.geotransform[5])
                    
                    if (0 <= px < self.shape[1] and 0 <= py < self.shape[0]):
                        speeds.append(self.velocity_mag[py, px])
                
                avg_speed = np.mean(speeds) if speeds else 0.0
                
                # Set attributes
                feature.setAttribute("id", i)
                feature.setAttribute("length", length)
                feature.setAttribute("speed", avg_speed)
                
                writer.addFeature(feature)
        
        del writer
        return output_path
    
    def _calculate_flow_accumulation(self, valid_mask):
        """Calculate flow accumulation for hydraulic modeling."""
        logger.info("Calculating flow accumulation")
        
        flow_acc = np.ones(self.shape, dtype=np.float32)
        valid_indices = np.argwhere(valid_mask)
        
        if len(valid_indices) == 0:
            return flow_acc
        
        # Sort cells by elevation
        cell_elevations = [(self.dem[i, j], i, j) for i, j in valid_indices]
        cell_elevations.sort(key=lambda x: x[0], reverse=True)
        
        # Route flow downhill
        for elevation, i, j in cell_elevations:
            current_acc = flow_acc[i, j]
            
            # Find steepest downhill neighbor
            max_slope = 0.0
            flow_i, flow_j = i, j
            
            for di in [-1, 0, 1]:
                for dj in [-1, 0, 1]:
                    if di == 0 and dj == 0:
                        continue
                    
                    ni, nj = i + di, j + dj
                    
                    if (0 <= ni < self.shape[0] and 0 <= nj < self.shape[1] and 
                        valid_mask[ni, nj]):
                        
                        distance = np.sqrt((di * self.dx)**2 + (dj * self.dy)**2)
                        slope = (self.dem[i, j] - self.dem[ni, nj]) / distance
                        
                        if slope > max_slope:
                            max_slope = slope
                            flow_i, flow_j = ni, nj
            
            # Route flow
            if flow_i != i or flow_j != j:
                flow_acc[flow_i, flow_j] += current_acc
        
        # Light smoothing
        flow_acc = gaussian_filter(flow_acc, sigma=0.8)
        
        return flow_acc
    
    def _calculate_upstream_discharge(self, flow_accumulation, depth):
        """Calculate upstream discharge based on flow accumulation."""
        # CONSERVATIVE discharge calculation
        base_discharge = 0.0005 * flow_accumulation  # REDUCED from 0.001
        
        # Depth adjustment
        if depth > 2.0:
            depth_factor = 1.2  # REDUCED from 1.5
        elif depth > 1.0:
            depth_factor = 1.1  # REDUCED from 1.2
        elif depth > 0.5:
            depth_factor = 1.0
        else:
            depth_factor = 0.9  # REDUCED from 0.8
        
        discharge = base_discharge * depth_factor
        
        # CONSERVATIVE limits
        discharge = min(discharge, 1.0)  # REDUCED from 2.0
        discharge = max(discharge, 0.001)
        
        return discharge


# Main function for creating enhanced streamlines
def create_enhanced_streamlines(dem_path, flood_layer, output_folder=None, flow_q=None, 
                             bathymetry=None, method="hydraulic"):
    """Create enhanced streamlines with CRITICAL FIXES applied."""
    logger = logging.getLogger("FloodEngine.EnhancedStreamlines")
    logger.setLevel(logging.INFO)
    
    if output_folder is None:
        output_folder = os.path.dirname(dem_path)
    os.makedirs(output_folder, exist_ok=True)
    
    output_path = os.path.join(output_folder, "enhanced_streamlines.shp")
    
    # Check for Saint-Venant files
    logger.info("🔍 Checking for Saint-Venant velocity files...")
    saint_venant_results = load_saint_venant_velocity_files(output_folder)
    
    if saint_venant_results is not None:
        max_vel = np.max(saint_venant_results.get('velocity_magnitude', 0))
        mean_vel = np.mean(saint_venant_results.get('velocity_magnitude', 0))
        
        logger.info(f"📊 Saint-Venant validation: max={max_vel:.1f}, mean={mean_vel:.1f}")
        
        # More aggressive validation
        if max_vel > 6.0 or mean_vel > 1.5:
            logger.error(f"❌ Saint-Venant velocities rejected (max: {max_vel:.1f}, mean: {mean_vel:.1f})")
            saint_venant_results = None
            method = "hydraulic"
        else:
            logger.info(f"✅ Saint-Venant velocities accepted")
            method = "saint_venant"
    else:
        logger.info("⚠️  No Saint-Venant files found - using hydraulic approximation")
        method = "hydraulic"
    
    logger.info(f"🎯 FINAL METHOD: {method}")
    
    # Load DEM
    try:
        dem_ds = gdal.Open(dem_path)
        dem_array = dem_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
        geotransform = dem_ds.GetGeoTransform()
        projection = dem_ds.GetProjection()
        nodata = dem_ds.GetRasterBand(1).GetNoDataValue()
        
        if nodata is None:
            nodata = -9999
        dem_array[dem_array == nodata] = np.nan
    except Exception as e:
        logger.error(f"Error loading DEM: {str(e)}")
        raise
    
    # Extract water level from flood layer
    try:
        water_levels = []
        flood_geom = None
        
        for feature in flood_layer.getFeatures():
            if 'water_lvl' in feature.fields().names():
                water_levels.append(float(feature['water_lvl']))
            
            if flood_geom is None:
                flood_geom = feature.geometry()
            else:
                flood_geom = flood_geom.combine(feature.geometry())
        
        if not water_levels:
            raise Exception("Flood layer missing 'water_lvl' attribute")
        
        water_level = np.mean(water_levels)
        logger.info(f"Using water level: {water_level:.2f}m")
        
        # Create flood mask
        flood_mask = np.zeros(dem_array.shape, dtype=bool)
        bounds = flood_geom.boundingBox()
        
        for y in range(dem_array.shape[0]):
            for x in range(dem_array.shape[1]):
                world_x = geotransform[0] + x * geotransform[1]
                world_y = geotransform[3] + y * geotransform[5]
                
                if (bounds.xMinimum() <= world_x <= bounds.xMaximum() and 
                    bounds.yMinimum() <= world_y <= bounds.yMaximum()):
                    if flood_geom.contains(QgsPointXY(world_x, world_y)):
                        flood_mask[y, x] = True
        
        logger.info(f"Flood area covers {np.sum(flood_mask)} cells")
    except Exception as e:
        logger.error(f"Error extracting water level: {str(e)}")
        raise
        
    # Calculate water depth
    water_depth = np.zeros_like(dem_array)
    water_depth[flood_mask] = water_level - dem_array[flood_mask]
    water_depth[water_depth < 0.01] = 0.0
    
    logger.info(f"Maximum water depth: {np.nanmax(water_depth):.2f}m")
    
    # Initialize streamline generator
    streamline_generator = EnhancedStreamlines(dem_array, geotransform, water_depth=water_depth)
    
    # Calculate velocity field with CRITICAL FIXES
    logger.info("🔧 FIXED: Calculating velocity field with critical fixes")
    
    manning_n = 0.035
    if flow_q is not None:
        logger.info(f"Using flow rate Q = {flow_q} m³/s")
        if flow_q > 100:
            manning_n = 0.03
        elif flow_q < 10:
            manning_n = 0.04
    
    # Apply the FIXED velocity calculation
    velocity_x, velocity_y, velocity_mag = streamline_generator.calculate_velocity_field(
        manning_n=manning_n, method=method, saint_venant_results=saint_venant_results
    )
    
    logger.info(f"✅ FIXED velocity field: max = {np.nanmax(velocity_mag):.2f} m/s")
    
    # Generate streamlines
    logger.info("🔧 FIXED: Generating streamlines with improved seeding")
    streamlines = streamline_generator.generate_streamlines(flood_mask=flood_mask)
    
    # Save streamlines
    if streamlines:
        logger.info(f"Saving {len(streamlines)} streamlines")
        output_file = streamline_generator.save_streamlines_shapefile(streamlines, output_path)
        
        if output_file:
            from qgis.core import QgsVectorLayer
            streamline_layer = QgsVectorLayer(output_path, "Enhanced Streamlines", "ogr")
            
            if streamline_layer.isValid():
                logger.info("✅ FIXED streamlines created successfully")
                return streamline_layer
            else:
                logger.error(f"Could not load created layer: {output_path}")
                raise Exception("Could not load streamline layer")
    else:
        logger.warning("No streamlines were generated")
        return None


def load_saint_venant_velocity_files(output_folder):
    """Load Saint-Venant velocity files with aggressive validation."""
    logger = logging.getLogger("FloodEngine.EnhancedStreamlines")
    
    velocity_files = {
        'velocity_x': None,
        'velocity_y': None,
        'velocity_magnitude': None
    }
    
    # Search for velocity files
    for file_name in os.listdir(output_folder):
        file_path = os.path.join(output_folder, file_name)
        
        if not os.path.isfile(file_path):
            continue
            
        if any(pattern in file_name.lower() for pattern in ['velocity_x', 'vx']):
            if file_name.lower().endswith(('.tif', '.tiff')):
                velocity_files['velocity_x'] = file_path
        elif any(pattern in file_name.lower() for pattern in ['velocity_y', 'vy']):
            if file_name.lower().endswith(('.tif', '.tiff')):
                velocity_files['velocity_y'] = file_path
        elif any(pattern in file_name.lower() for pattern in ['velocity_magnitude', 'vmag']):
            if file_name.lower().endswith(('.tif', '.tiff')):
                velocity_files['velocity_magnitude'] = file_path
    
    # Load if we have components
    if velocity_files['velocity_x'] and velocity_files['velocity_y']:
        try:
            saint_venant_results = {}
            
            # Load components
            vx_ds = gdal.Open(velocity_files['velocity_x'])
            saint_venant_results['velocity_x'] = vx_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
            vx_nodata = vx_ds.GetRasterBand(1).GetNoDataValue()
            
            vy_ds = gdal.Open(velocity_files['velocity_y'])
            saint_venant_results['velocity_y'] = vy_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
            vy_nodata = vy_ds.GetRasterBand(1).GetNoDataValue()
            
            # Handle nodata
            if vx_nodata is not None:
                saint_venant_results['velocity_x'][saint_venant_results['velocity_x'] == vx_nodata] = 0.0
            if vy_nodata is not None:
                saint_venant_results['velocity_y'][saint_venant_results['velocity_y'] == vy_nodata] = 0.0
            
            # Calculate magnitude
            if velocity_files['velocity_magnitude']:
                vmag_ds = gdal.Open(velocity_files['velocity_magnitude'])
                saint_venant_results['velocity_magnitude'] = vmag_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
                vmag_nodata = vmag_ds.GetRasterBand(1).GetNoDataValue()
                if vmag_nodata is not None:
                    saint_venant_results['velocity_magnitude'][saint_venant_results['velocity_magnitude'] == vmag_nodata] = 0.0
            else:
                saint_venant_results['velocity_magnitude'] = np.sqrt(
                    saint_venant_results['velocity_x']**2 + saint_venant_results['velocity_y']**2
                )
            
            # Clean up
            saint_venant_results['velocity_x'] = np.nan_to_num(saint_venant_results['velocity_x'], nan=0.0, posinf=0.0, neginf=0.0)
            saint_venant_results['velocity_y'] = np.nan_to_num(saint_venant_results['velocity_y'], nan=0.0, posinf=0.0, neginf=0.0)
            saint_venant_results['velocity_magnitude'] = np.nan_to_num(saint_venant_results['velocity_magnitude'], nan=0.0, posinf=0.0, neginf=0.0)
            
            return saint_venant_results
            
        except Exception as e:
            logger.error(f"Error loading Saint-Venant files: {str(e)}")
            return None
    else:
        return None


def create_enhanced_streamlines_auto_detect(dem_path, flood_layer, output_folder=None, 
                                           flow_q=None, bathymetry=None, 
                                           prefer_saint_venant=True):
    """Create enhanced streamlines with automatic method detection."""
    logger = logging.getLogger("FloodEngine.EnhancedStreamlines")
    
    if output_folder is None:
        output_folder = os.path.dirname(dem_path)
    
    # Check for Saint-Venant files
    saint_venant_results = load_saint_venant_velocity_files(output_folder)
    
    if saint_venant_results is not None and prefer_saint_venant:
        logger.info("🎯 Auto-detected Saint-Venant velocity files - using saint_venant method")
        method = "saint_venant"
    else:
        logger.info("🎯 Auto-detected no suitable Saint-Venant files - using hydraulic method")
        method = "hydraulic"
    
    return create_enhanced_streamlines(
        dem_path=dem_path,
        flood_layer=flood_layer,
        output_folder=output_folder,
        flow_q=flow_q,
        bathymetry=bathymetry,
        method=method
    )
