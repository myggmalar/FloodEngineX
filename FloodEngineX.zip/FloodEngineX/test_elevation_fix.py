#!/usr/bin/env python3
"""
Test script to validate the DEM elevation fix
Tests the corrected bathymetry integration and verifies proper RT2000 elevation range
"""

import os
import sys
import numpy as np
from osgeo import gdal
from pathlib import Path

# Add the current directory to Python path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from model_hydraulic import load_and_integrate_bathymetry_FIXED, apply_geoid_correction_only
    MODEL_AVAILABLE = True
except ImportError as e:
    print(f"Warning: Could not import model functions: {e}")
    MODEL_AVAILABLE = False

def test_dem_elevation_range(dem_path, description="DEM"):
    """Test and display elevation statistics for a DEM file using GDAL"""
    print(f"\n=== {description} Elevation Statistics ===")
    
    try:
        # Open with GDAL
        dataset = gdal.Open(dem_path, gdal.GA_ReadOnly)
        if dataset is None:
            print(f"ERROR: Could not open {dem_path}")
            return None
            
        band = dataset.GetRasterBand(1)
        data = band.ReadAsArray()
        
        if data is None:
            print("ERROR: Could not read raster data")
            return None
            
        # Handle nodata values
        nodata = band.GetNoDataValue()
        if nodata is not None:
            data = np.ma.masked_equal(data, nodata)
        else:
            # Mask common nodata values
            data = np.ma.masked_invalid(data)
            data = np.ma.masked_equal(data, -9999)
            data = np.ma.masked_equal(data, -32768)
        
        if data.mask.all() if hasattr(data, 'mask') else False:
            print("ERROR: All data is masked/nodata")
            dataset = None
            return None
            
        # Calculate statistics
        if hasattr(data, 'mask'):
            valid_data = data.compressed()
        else:
            valid_data = data.flatten()
            
        stats = {
            'min': float(np.min(valid_data)),
            'max': float(np.max(valid_data)),
            'mean': float(np.mean(valid_data)),
            'std': float(np.std(valid_data)),
            'count': len(valid_data)
        }
        
        print(f"File: {dem_path}")
        print(f"Elevation range: {stats['min']:.2f}m to {stats['max']:.2f}m")
        print(f"Mean elevation: {stats['mean']:.2f}m")
        print(f"Standard deviation: {stats['std']:.2f}m")
        print(f"Valid pixels: {stats['count']:,}")
        
        # Check if range matches expected RT2000 values for Sweden
        expected_min = 9.0  # Expected minimum for Swedish RT2000
        expected_max = 51.0  # Expected maximum for Swedish RT2000
        
        if stats['min'] >= expected_min and stats['max'] <= expected_max:
            print("✅ PASS: Elevation range matches expected RT2000 values")
        else:
            print("❌ FAIL: Elevation range does not match expected RT2000 values")
            print(f"   Expected range: {expected_min}m to {expected_max}m")
            
        dataset = None  # Close dataset
        return stats
        
    except Exception as e:
        print(f"ERROR reading {dem_path}: {e}")
        return None

def test_bathymetry_integration():
    """Test the fixed bathymetry integration function"""
    print("\n" + "="*60)
    print("TESTING FIXED BATHYMETRY INTEGRATION")
    print("="*60)
    
    if not MODEL_AVAILABLE:
        print("Model functions not available, skipping integration test")
        return
    
    # Look for test data files
    test_dir = Path(".")
    dem_files = list(test_dir.glob("*.tif")) + list(test_dir.glob("**/dem*.tif"))
    bathymetry_files = list(test_dir.glob("*.csv")) + list(test_dir.glob("**/bathymetry*.csv"))
    
    print(f"Found {len(dem_files)} DEM files and {len(bathymetry_files)} bathymetry files")
    
    if not dem_files:
        print("No DEM files found for testing")
        return
        
    # Test with the first available DEM
    test_dem = str(dem_files[0])
    print(f"Using DEM: {test_dem}")
    
    # Test original DEM first
    original_stats = test_dem_elevation_range(test_dem, "Original DEM")
    
    if original_stats is None:
        print("Cannot read original DEM, skipping test")
        return
    
    # Create output directory
    output_dir = Path("test_output")
    output_dir.mkdir(exist_ok=True)
    
    try:
        if bathymetry_files:
            # Test with bathymetry integration
            bathymetry_file = str(bathymetry_files[0])
            print(f"\nTesting with bathymetry file: {bathymetry_file}")
            
            result_path, bath_stats = load_and_integrate_bathymetry_FIXED(
                csv_path=bathymetry_file,
                dem_path=test_dem,
                output_folder=str(output_dir),
                geoid_correction=42.0  # RT2000 correction for Sweden
            )
            
            if result_path and os.path.exists(result_path):
                corrected_stats = test_dem_elevation_range(result_path, "Corrected DEM (with bathymetry)")
                
                if corrected_stats and original_stats:
                    print(f"\n=== COMPARISON ===")
                    print(f"Original range:  {original_stats['min']:.2f}m to {original_stats['max']:.2f}m")
                    print(f"Corrected range: {corrected_stats['min']:.2f}m to {corrected_stats['max']:.2f}m")
                    print(f"Change in min:   {corrected_stats['min'] - original_stats['min']:.2f}m")
                    print(f"Change in max:   {corrected_stats['max'] - original_stats['max']:.2f}m")
                    
                    if bath_stats:
                        print(f"\nBathymetry integration stats:")
                        for key, value in bath_stats.items():
                            print(f"  {key}: {value}")
            else:
                print("Failed to create corrected DEM with bathymetry")
                
        else:
            # Test with geoid correction only (no bathymetry)
            print("\nNo bathymetry files found, testing geoid correction only")
            
            result_path = apply_geoid_correction_only(
                dem_path=test_dem,
                output_folder=str(output_dir),
                geoid_correction=42.0
            )
            
            if result_path and os.path.exists(result_path):
                corrected_stats = test_dem_elevation_range(result_path, "Corrected DEM (geoid only)")
                
                if corrected_stats and original_stats:
                    print(f"\n=== COMPARISON (Geoid Correction Only) ===")
                    print(f"Original range:  {original_stats['min']:.2f}m to {original_stats['max']:.2f}m")
                    print(f"Corrected range: {corrected_stats['min']:.2f}m to {corrected_stats['max']:.2f}m")
                    print(f"Change in min:   {corrected_stats['min'] - original_stats['min']:.2f}m")
                    print(f"Change in max:   {corrected_stats['max'] - original_stats['max']:.2f}m")
                    
                    # The change should be approximately +42m due to RT2000 geoid correction
                    expected_change = 42.0
                    actual_change = corrected_stats['mean'] - original_stats['mean']
                    print(f"Mean elevation change: {actual_change:.2f}m (expected: ~{expected_change:.2f}m)")
                    
                    if abs(actual_change - expected_change) < 1.0:
                        print("✅ PASS: Geoid correction applied correctly")
                    else:
                        print("❌ FAIL: Geoid correction not applied correctly")
            else:
                print("Failed to create corrected DEM with geoid correction")
                
    except Exception as e:
        print(f"ERROR during bathymetry integration test: {e}")
        import traceback
        traceback.print_exc()

def test_file_analysis():
    """Analyze available files in the workspace"""
    print("\n" + "="*60)
    print("WORKSPACE FILE ANALYSIS")
    print("="*60)
    
    current_dir = Path(".")
    
    # Look for DEM files
    dem_extensions = ['.tif', '.tiff', '.asc', '.img']
    dem_files = []
    for ext in dem_extensions:
        dem_files.extend(list(current_dir.glob(f"**/*{ext}")))
    
    print(f"\nFound {len(dem_files)} potential DEM files:")
    for dem_file in dem_files[:10]:  # Show first 10
        size_mb = dem_file.stat().st_size / (1024*1024)
        print(f"  {dem_file} ({size_mb:.1f} MB)")
    
    # Look for bathymetry files
    bath_files = list(current_dir.glob("**/*.csv"))
    print(f"\nFound {len(bath_files)} CSV files (potential bathymetry):")
    for bath_file in bath_files[:10]:  # Show first 10
        size_kb = bath_file.stat().st_size / 1024
        print(f"  {bath_file} ({size_kb:.1f} KB)")
    
    # Look for output/test directories
    output_dirs = [d for d in current_dir.iterdir() if d.is_dir() and 'output' in d.name.lower()]
    print(f"\nFound {len(output_dirs)} output directories:")
    for output_dir in output_dirs:
        print(f"  {output_dir}")

if __name__ == "__main__":
    print("DEM Elevation Fix Test Suite")
    print("="*60)
    
    # Run tests
    test_file_analysis()
    test_bathymetry_integration()
    
    print("\n" + "="*60)
    print("TEST COMPLETE")
    print("="*60)
