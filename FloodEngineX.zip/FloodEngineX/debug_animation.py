#!/usr/bin/env python3
"""
Quick Animation Test and Debugger
=================================
This script will help diagnose why animation controls aren't showing up.
"""

import sys
import os
from pathlib import Path

# Add FloodEngineX to path
script_dir = Path(__file__).parent
sys.path.insert(0, str(script_dir))

def test_minimal_animation():
    """Test the most basic animation setup."""
    print("🔍 Testing minimal animation setup...")
    
    # Test 1: Check PyQt5
    try:
        from PyQt5.QtWidgets import QApplication, QDialog, QVBoxLayout, QLabel, QPushButton
        from PyQt5.QtCore import Qt
        print("✅ PyQt5 import successful")
        
        # Create minimal test dialog
        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)
            print("✅ QApplication created")
        
        # Create simple test dialog
        dialog = QDialog()
        layout = QVBoxLayout()
        
        label = QLabel("🌊 FloodEngine Animation Test")
        label.setAlignment(Qt.AlignCenter)
        layout.addWidget(label)
        
        button = QPushButton("Test Button")
        layout.addWidget(button)
        
        dialog.setLayout(layout)
        dialog.setWindowTitle("Animation Test")
        dialog.resize(400, 200)
        dialog.show()
        
        print("✅ Test dialog created and shown")
        print("📋 If you can see a dialog window, PyQt5 is working correctly")
        
        # Keep dialog open briefly
        from PyQt5.QtCore import QTimer
        timer = QTimer()
        timer.singleShot(3000, app.quit)  # Close after 3 seconds
        
        return app.exec_()
        
    except ImportError as e:
        print(f"❌ PyQt5 import failed: {e}")
        print("💡 Try installing PyQt5: pip install PyQt5")
        return False
    except Exception as e:
        print(f"❌ PyQt5 test failed: {e}")
        return False

def test_animation_data_loading():
    """Test if we can load animation data."""
    print("\n🔍 Testing animation data loading...")
    
    # Look for existing simulation results
    test_folders = [
        "test_time_series_output",
        "simulation_output", 
        "flood_results",
        "output"
    ]
    
    found_data = False
    for folder in test_folders:
        if os.path.exists(folder):
            print(f"📁 Found folder: {folder}")
            
            # Check for animation data
            animation_folder = os.path.join(folder, 'time_series_animation')
            raster_folder = os.path.join(folder, 'rasters')
            
            if os.path.exists(animation_folder):
                print(f"  ✅ Animation folder found: {animation_folder}")
                found_data = True
            elif os.path.exists(raster_folder):
                print(f"  ✅ Raster folder found: {raster_folder}")
                found_data = True
            else:
                print(f"  ⚠️ No animation data in {folder}")
    
    if not found_data:
        print("❌ No animation data found in current directory")
        print("💡 Run a FloodEngine simulation first to generate animation data")
    
    return found_data

def test_direct_animator():
    """Test the TimeSeriesAnimator directly with minimal data."""
    print("\n🔍 Testing TimeSeriesAnimator directly...")
    
    try:
        from PyQt5.QtWidgets import QApplication
        import numpy as np
        
        # Create QApplication
        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)
        
        # Create minimal test data
        print("📊 Creating minimal test data...")
        
        times = [0.0, 30.0, 60.0, 90.0, 120.0]
        water_depths = []
        
        # Simple test data - expanding circle
        for i, t in enumerate(times):
            # 20x20 grid
            x = np.linspace(0, 100, 20)
            y = np.linspace(0, 100, 20)
            X, Y = np.meshgrid(x, y)
            
            # Expanding flood
            center_x, center_y = 50, 50
            radius = 10 + i * 5
            
            distance = np.sqrt((X - center_x)**2 + (Y - center_y)**2)
            depth = np.maximum(0, 2.0 * np.exp(-distance / radius))
            
            water_depths.append(depth)
        
        # Create DEM
        dem = np.zeros((20, 20))
        
        # Package results
        results_data = {
            'times': times,
            'water_depths': water_depths,
            'dem_array': dem,
            'geotransform': (0, 5, 0, 100, 0, -5),
            'projection': 'EPSG:4326'
        }
        
        print("✅ Test data created")
        
        # Try to import and create animator
        from time_series_animator import TimeSeriesAnimator
        
        import tempfile
        temp_dir = tempfile.mkdtemp(prefix='animation_test_')
        print(f"📁 Using temp directory: {temp_dir}")
        
        # Create animator
        animator = TimeSeriesAnimator(results_data, temp_dir)
        animator.setWindowTitle("FloodEngine Animation Test")
        animator.resize(800, 600)
        animator.show()
        animator.raise_()
        animator.activateWindow()
        
        print("✅ TimeSeriesAnimator created and shown")
        print("🎮 Animation controls should now be visible!")
        print("   - Play/Pause buttons")
        print("   - Timeline slider")
        print("   - Speed controls")
        
        # Keep reference
        app._test_animator = animator
        
        return app.exec_()
        
    except ImportError as e:
        print(f"❌ Import failed: {e}")
        return False
    except Exception as e:
        print(f"❌ Animator test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    print("🌊 FloodEngine Animation Diagnostics")
    print("=" * 40)
    
    # Test 1: Basic PyQt5
    print("\n1️⃣ Testing PyQt5...")
    pyqt_ok = test_minimal_animation()
    
    if not pyqt_ok:
        print("❌ Cannot proceed - PyQt5 issues detected")
        return 1
    
    # Test 2: Check for existing data
    print("\n2️⃣ Checking for animation data...")
    data_found = test_animation_data_loading()
    
    # Test 3: Direct animator test
    print("\n3️⃣ Testing animation controls directly...")
    animator_ok = test_direct_animator()
    
    print("\n📊 Diagnostic Summary:")
    print(f"  PyQt5: {'✅ OK' if pyqt_ok else '❌ FAIL'}")
    print(f"  Data: {'✅ FOUND' if data_found else '⚠️ NONE'}")
    print(f"  Animator: {'✅ OK' if animator_ok else '❌ FAIL'}")
    
    if not animator_ok:
        print("\n🔧 Troubleshooting Steps:")
        print("1. Check PyQt5 installation: pip install PyQt5")
        print("2. Try running in a fresh Python environment")
        print("3. Check for conflicting Qt installations")
        print("4. Run: python -c 'from PyQt5.QtWidgets import QApplication; app=QApplication([]); print(\"PyQt5 OK\")'")
    
    return 0 if animator_ok else 1

if __name__ == "__main__":
    sys.exit(main())
