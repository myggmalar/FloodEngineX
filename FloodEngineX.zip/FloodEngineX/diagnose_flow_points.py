#!/usr/bin/env python3
"""
Diagnostic script to troubleshoot why no flow points are being created.
"""

import sys
import os
import numpy as np

# Add the FloodEngineX directory to the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def diagnose_flow_points_issue():
    """Diagnose why no flow points are being created."""
    
    print("🔍 Diagnosing Flow Points Issue...")
    
    # Check 1: Verify files exist
    print("\n📁 File Check:")
    files_to_check = [
        'enhanced_flow_points.py',
        'model_hydraulic.py'
    ]
    
    for file in files_to_check:
        if os.path.exists(file):
            print(f"✅ {file} exists")
        else:
            print(f"❌ {file} missing")
            return False
    
    # Check 2: Look for recent simulation output
    print("\n📊 Recent Simulation Output Check:")
    try:
        # Look for output folders
        output_folders = [d for d in os.listdir('.') if d.startswith('FloodEngine_') and os.path.isdir(d)]
        if output_folders:
            latest_folder = sorted(output_folders)[-1]
            print(f"✅ Found output folder: {latest_folder}")
            
            # Check for Saint-Venant velocity files
            velocity_files = [f for f in os.listdir(latest_folder) if 'velocity' in f and f.endswith('.tif')]
            depth_files = [f for f in os.listdir(latest_folder) if f.startswith('depth_T') and f.endswith('.tif')]
            
            print(f"📈 Velocity files found: {len(velocity_files)}")
            print(f"🌊 Depth files found: {len(depth_files)}")
            
            if velocity_files:
                print("✅ Saint-Venant velocity data available")
                for vf in velocity_files[:3]:  # Show first 3
                    print(f"   - {vf}")
            else:
                print("⚠️ No Saint-Venant velocity files found")
                
            if depth_files:
                print("✅ Depth files available for flood polygons")
                for df in depth_files[:3]:  # Show first 3
                    print(f"   - {df}")
            else:
                print("⚠️ No depth files found")
                
        else:
            print("⚠️ No recent simulation output folders found")
            
    except Exception as e:
        print(f"❌ Error checking output: {e}")
    
    # Check 3: Verify integration in model_hydraulic.py
    print("\n🔗 Integration Check:")
    try:
        with open('model_hydraulic.py', 'r', encoding='utf-8') as f:
            content = f.read()
        
        if 'create_enhanced_flow_points' in content:
            print("✅ Flow points function imported")
        else:
            print("❌ Flow points function not imported")
            return False
            
        if 'FlowPoints_T' in content:
            print("✅ Flow points generation code present")
        else:
            print("❌ Flow points generation code missing")
            return False
            
        # Check if old streamline code was properly replaced
        if 'create_streamlines_from_velocity_gdal' in content:
            print("⚠️ Old streamline code still present - may be interfering")
        else:
            print("✅ Old streamline code removed")
            
    except Exception as e:
        print(f"❌ Error checking integration: {e}")
        return False
    
    # Check 4: Test the flow points module
    print("\n🧪 Module Test:")
    try:
        from enhanced_flow_points import EnhancedFlowPoints, create_enhanced_flow_points
        print("✅ Flow points module imports successfully")
        
        # Test basic functionality
        test_dem = np.random.rand(10, 10) * 100
        test_geotransform = (0, 1, 0, 0, 0, -1)
        test_water_depth = np.random.rand(10, 10) * 2
        
        flow_gen = EnhancedFlowPoints(test_dem, test_geotransform, water_depth=test_water_depth)
        print("✅ Flow points class initializes correctly")
        
    except Exception as e:
        print(f"❌ Error testing module: {e}")
        return False
    
    # Check 5: Common issues
    print("\n🔍 Common Issues Check:")
    
    # Issue 1: Empty flood mask
    print("1. Check for empty flood mask in flow points generation")
    
    # Issue 2: Very low velocities
    print("2. Check if all velocities are below minimum threshold")
    
    # Issue 3: Missing water_lvl attribute
    print("3. Check if flood polygons have 'water_lvl' attribute")
    
    # Issue 4: Coordinate system issues
    print("4. Check coordinate system compatibility")
    
    print("\n💡 Potential Solutions:")
    print("1. Ensure flood simulation has completed successfully")
    print("2. Check that flood polygons have proper water_lvl attribute")
    print("3. Verify Saint-Venant velocity files are being generated")
    print("4. Check minimum velocity threshold in flow points code")
    print("5. Ensure proper coordinate system transformation")
    
    return True

def create_test_flow_points():
    """Create a simple test to verify flow points work with dummy data."""
    
    print("\n🧪 Creating Test Flow Points...")
    
    try:
        import numpy as np
        from enhanced_flow_points import EnhancedFlowPoints
        
        # Create test data
        rows, cols = 50, 50
        test_dem = np.random.rand(rows, cols) * 100 + 100  # DEM between 100-200m
        test_geotransform = (0, 10, 0, 0, 0, -10)  # 10m resolution
        
        # Create a simple flood scenario
        test_water_depth = np.zeros((rows, cols))
        # Add water in center area with some depth variation
        test_water_depth[20:30, 20:30] = np.random.rand(10, 10) * 3 + 0.5  # 0.5-3.5m depth
        
        # Create flow generator
        flow_gen = EnhancedFlowPoints(test_dem, test_geotransform, water_depth=test_water_depth)
        
        # Calculate velocity field
        velocity_x, velocity_y, velocity_mag = flow_gen.calculate_velocity_field(method="hydraulic")
        
        print(f"✅ Velocity field calculated")
        print(f"   Max velocity: {np.nanmax(velocity_mag):.3f} m/s")
        print(f"   Cells with water: {np.sum(test_water_depth > 0.01)}")
        print(f"   Cells with velocity > 0.01: {np.sum(velocity_mag > 0.01)}")
        
        # Create flood mask
        flood_mask = test_water_depth > 0.01
        
        # Generate flow points
        flow_points = flow_gen.generate_flow_points(flood_mask=flood_mask)
        
        print(f"✅ Flow points generated: {len(flow_points)}")
        
        if len(flow_points) > 0:
            velocities = [p['velocity'] for p in flow_points]
            print(f"   Velocity range: {min(velocities):.3f} - {max(velocities):.3f} m/s")
            print("✅ Test successful - flow points system is working")
            return True
        else:
            print("❌ No flow points generated in test")
            return False
            
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("🌊 FLOW POINTS DIAGNOSTIC TOOL")
    print("=" * 50)
    
    # Run diagnostics
    diagnosis_success = diagnose_flow_points_issue()
    
    # Run test
    test_success = create_test_flow_points()
    
    print("\n" + "=" * 50)
    if diagnosis_success and test_success:
        print("✅ DIAGNOSIS COMPLETE - System appears to be working")
        print("\nNext steps:")
        print("1. Run a new flood simulation")
        print("2. Check that the flood polygon layers have 'water_lvl' attribute")
        print("3. Verify that Saint-Venant velocity files are being created")
        print("4. Look for 'FlowPoints_T###_XXXh' layers in QGIS after simulation")
    else:
        print("❌ ISSUES DETECTED - Flow points system needs attention")
        print("\nPlease check the specific error messages above.")
