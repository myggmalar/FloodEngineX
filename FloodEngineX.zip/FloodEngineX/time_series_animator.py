"""
Time Series Animation for FloodEngine Results
--------------------------------------------
Provides automatic timestep animation and interactive depth/elevation viewing
with RH2000 coordinate system support.
"""

import os
import time
import numpy as np
from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton, QSlider, QLabel,
    QSpinBox, QCheckBox, QProgressBar, QGroupBox, QGridLayout,
    QComboBox, QDoubleSpinBox, QTextEdit, QSplitter, QFrame,
    QWidget, QScrollArea
)
from PyQt5.QtCore import QTimer, Qt, pyqtSignal, QThread, pyqtSlot
from PyQt5.QtGui import QFont, QColor, QPalette, QPixmap, QPainter
from PyQt5.QtCore import QVariant
import logging

logger = logging.getLogger("FloodEngine.TimeSeriesAnimator")

# Try to import QGIS components - graceful fallback if not available
try:
    from qgis.core import (
        QgsProject, QgsRasterLayer, QgsVectorLayer, QgsCoordinateReferenceSystem,
        QgsCoordinateTransform, QgsPointXY, QgsGeometry, QgsFeature, QgsFields,
        QgsField, QgsWkbTypes, QgsVectorFileWriter, QgsRasterDataProvider,
        QgsMapLayerStyleManager, QgsSymbol, QgsSingleSymbolRenderer,
        QgsGraduatedSymbolRenderer, QgsClassificationMethod
    )
    from qgis.gui import QgsMapCanvas, QgsMapToolEmitPoint
    from qgis.utils import iface
    QGIS_AVAILABLE = True
    logger.info("✅ QGIS components available - full functionality enabled")
except ImportError:
    QGIS_AVAILABLE = False
    logger.info("⚠️ QGIS not available - running in standalone mode")
    # Define dummy classes to avoid import errors
    class QgsMapCanvas: pass
    class QgsMapToolEmitPoint: pass
    iface = None

class TimeSeriesAnimator(QDialog):
    """Main animation dialog for time series flood data."""
    
    # Signals
    animation_started = pyqtSignal()
    animation_stopped = pyqtSignal()
    timestep_changed = pyqtSignal(int)
    
    def __init__(self, results_data, output_folder, parent=None):
        """
        Initialize the time series animator.
        
        Parameters:
            results_data (dict): Saint-Venant simulation results
            output_folder (str): Path to output folder with time series data
            parent: Parent widget
        """
        super().__init__(parent)
        
        self.results_data = results_data
        self.output_folder = output_folder
        self.current_timestep = 0
        self.is_playing = False
        self.animation_speed = 500  # milliseconds per frame
        
        # Animation timer
        self.timer = QTimer()
        self.timer.timeout.connect(self.next_timestep)
        
        # Map interaction (QGIS mode vs standalone mode)
        if QGIS_AVAILABLE and iface is not None:
            self.map_canvas = iface.mapCanvas()
            self.qgis_mode = True
            logger.info("🗺️ QGIS mode - full map integration available")
        else:
            self.map_canvas = None
            self.qgis_mode = False
            logger.info("🖥️ Standalone mode - simplified interface")
            
        self.click_tool = None
        
        # Time series data
        self.time_series_layers = []
        self.timestamps = results_data.get('times', [])
        self.water_depths = results_data.get('water_depths', [])
        self.water_surfaces = []
        
        # Calculate water surface elevations
        if 'water_depths' in results_data and len(self.water_depths) > 0:
            dem_data = results_data.get('dem_array')
            if dem_data is not None:
                for depth_array in self.water_depths:
                    surface = dem_data + depth_array
                    self.water_surfaces.append(surface)
        
        # Coordinate system (RH2000 - EPSG:3006)
        if QGIS_AVAILABLE:
            try:
                self.rh2000_crs = QgsCoordinateReferenceSystem("EPSG:3006")
                if self.qgis_mode:
                    self.map_crs = self.map_canvas.mapSettings().destinationCrs()
                    self.coord_transform = QgsCoordinateTransform(
                        self.map_crs, self.rh2000_crs, QgsProject.instance()
                    )
                else:
                    self.map_crs = None
                    self.coord_transform = None
            except Exception as e:
                logger.warning(f"⚠️ Could not set up coordinate transforms: {e}")
                self.rh2000_crs = None
                self.map_crs = None
                self.coord_transform = None
        else:
            self.rh2000_crs = None
            self.map_crs = None
            self.coord_transform = None
        
        self.setup_ui()
        if self.qgis_mode:
            self.setup_map_interaction()
        self.load_time_series_data()
        
        logger.info(f"Time Series Animator initialized with {len(self.timestamps)} timesteps")
    
    def setup_ui(self):
        """Set up the user interface."""
        self.setWindowTitle("FloodEngine - Time Series Animation")
        self.setGeometry(100, 100, 600, 500)
        
        # Main layout
        main_layout = QVBoxLayout()
        
        # Create splitter for resizable panels
        splitter = QSplitter(Qt.Vertical)
        
        # Animation Controls Panel
        controls_frame = QFrame()
        controls_frame.setFrameStyle(QFrame.StyledPanel)
        controls_layout = QVBoxLayout(controls_frame)
        
        # Title
        title_label = QLabel("🌊 FloodEngine Time Series Animation")
        title_font = QFont()
        title_font.setPointSize(14)
        title_font.setBold(True)
        title_label.setFont(title_font)
        title_label.setAlignment(Qt.AlignCenter)
        controls_layout.addWidget(title_label)
        
        # Timestep info
        info_layout = QHBoxLayout()
        self.timestep_label = QLabel(f"Timestep: 0 / {len(self.timestamps)}")
        self.time_label = QLabel("Time: 0.0 s")
        info_layout.addWidget(self.timestep_label)
        info_layout.addStretch()
        info_layout.addWidget(self.time_label)
        controls_layout.addLayout(info_layout)
        
        # Timeline slider
        self.timeline_slider = QSlider(Qt.Horizontal)
        self.timeline_slider.setMinimum(0)
        self.timeline_slider.setMaximum(max(0, len(self.timestamps) - 1))
        self.timeline_slider.setValue(0)
        self.timeline_slider.valueChanged.connect(self.on_slider_changed)
        controls_layout.addWidget(self.timeline_slider)
        
        # Playback controls
        playback_layout = QHBoxLayout()
        
        self.play_button = QPushButton("▶️ Play")
        self.play_button.clicked.connect(self.toggle_animation)
        
        self.stop_button = QPushButton("⏹️ Stop")
        self.stop_button.clicked.connect(self.stop_animation)
        
        self.step_back_button = QPushButton("⏮️ Step Back")
        self.step_back_button.clicked.connect(self.previous_timestep)
        
        self.step_forward_button = QPushButton("⏭️ Step Forward")
        self.step_forward_button.clicked.connect(self.next_timestep)
        
        playback_layout.addWidget(self.step_back_button)
        playback_layout.addWidget(self.play_button)
        playback_layout.addWidget(self.stop_button)
        playback_layout.addWidget(self.step_forward_button)
        controls_layout.addLayout(playback_layout)
        
        # Animation settings
        settings_group = QGroupBox("Animation Settings")
        settings_layout = QGridLayout(settings_group)
        
        # Speed control
        settings_layout.addWidget(QLabel("Speed (fps):"), 0, 0)
        self.speed_spinbox = QDoubleSpinBox()
        self.speed_spinbox.setRange(0.1, 10.0)
        self.speed_spinbox.setValue(2.0)
        self.speed_spinbox.setSingleStep(0.1)
        self.speed_spinbox.valueChanged.connect(self.update_animation_speed)
        settings_layout.addWidget(self.speed_spinbox, 0, 1)
        
        # Loop option
        self.loop_checkbox = QCheckBox("Loop Animation")
        self.loop_checkbox.setChecked(True)
        settings_layout.addWidget(self.loop_checkbox, 0, 2)
        
        # Auto-hide layers
        self.auto_hide_checkbox = QCheckBox("Auto-hide Other Timesteps")
        self.auto_hide_checkbox.setChecked(True)
        settings_layout.addWidget(self.auto_hide_checkbox, 1, 0, 1, 2)
        
        # Export animation
        self.export_button = QPushButton("📹 Export Animation")
        self.export_button.clicked.connect(self.export_animation)
        settings_layout.addWidget(self.export_button, 1, 2)
        
        controls_layout.addWidget(settings_group)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        controls_layout.addWidget(self.progress_bar)
        
        splitter.addWidget(controls_frame)
        
        # Interactive Info Panel
        info_frame = QFrame()
        info_frame.setFrameStyle(QFrame.StyledPanel)
        info_layout_panel = QVBoxLayout(info_frame)
        
        info_title = QLabel("🎯 Interactive Point Information")
        info_title.setFont(title_font)
        info_layout_panel.addWidget(info_title)
        
        # Click instruction
        click_label = QLabel("Click on the map to view depth and elevation at that location.")
        click_label.setWordWrap(True)
        info_layout_panel.addWidget(click_label)
        
        # Coordinate display
        coord_group = QGroupBox("Point Coordinates")
        coord_layout = QGridLayout(coord_group)
        
        coord_layout.addWidget(QLabel("Map X:"), 0, 0)
        self.map_x_label = QLabel("---")
        coord_layout.addWidget(self.map_x_label, 0, 1)
        
        coord_layout.addWidget(QLabel("Map Y:"), 1, 0)
        self.map_y_label = QLabel("---")
        coord_layout.addWidget(self.map_y_label, 1, 1)
        
        coord_layout.addWidget(QLabel("RH2000 X:"), 0, 2)
        self.rh2000_x_label = QLabel("---")
        coord_layout.addWidget(self.rh2000_x_label, 0, 3)
        
        coord_layout.addWidget(QLabel("RH2000 Y:"), 1, 2)
        self.rh2000_y_label = QLabel("---")
        coord_layout.addWidget(self.rh2000_y_label, 1, 3)
        
        info_layout_panel.addWidget(coord_group)
        
        # Data display
        data_group = QGroupBox("Current Timestep Data")
        data_layout = QGridLayout(data_group)
        
        data_layout.addWidget(QLabel("Water Depth:"), 0, 0)
        self.depth_label = QLabel("--- m")
        data_layout.addWidget(self.depth_label, 0, 1)
        
        data_layout.addWidget(QLabel("Surface Elevation (RH2000):"), 1, 0)
        self.elevation_label = QLabel("--- m")
        data_layout.addWidget(self.elevation_label, 1, 1)
        
        data_layout.addWidget(QLabel("DEM Elevation:"), 0, 2)
        self.dem_elevation_label = QLabel("--- m")
        data_layout.addWidget(self.dem_elevation_label, 0, 3)
        
        data_layout.addWidget(QLabel("Velocity:"), 1, 2)
        self.velocity_label = QLabel("--- m/s")
        data_layout.addWidget(self.velocity_label, 1, 3)
        
        info_layout_panel.addWidget(data_group)
        
        # Time series display
        self.time_series_text = QTextEdit()
        self.time_series_text.setMaximumHeight(150)
        self.time_series_text.setPlainText("Click on a point to see time series data...")
        info_layout_panel.addWidget(QLabel("📊 Time Series at Point:"))
        info_layout_panel.addWidget(self.time_series_text)
        
        splitter.addWidget(info_frame)
        
        # Set splitter proportions (60% controls, 40% info)
        splitter.setSizes([350, 250])
        
        main_layout.addWidget(splitter)
        self.setLayout(main_layout)
    
    def setup_map_interaction(self):
        """Set up map click tool for interactive point information."""
        if not self.qgis_mode or self.map_canvas is None:
            logger.info("⚠️ Map interaction not available in standalone mode")
            return
            
        try:
            self.click_tool = QgsMapToolEmitPoint(self.map_canvas)
            self.click_tool.canvasClicked.connect(self.on_map_clicked)
            
            # Enable the click tool
            self.map_canvas.setMapTool(self.click_tool)
            logger.info("🎯 Map click interaction enabled")
        except Exception as e:
            logger.warning(f"⚠️ Could not set up map interaction: {e}")
    
    def load_time_series_data(self):
        """Load time series raster data if available."""
        logger.info("Loading time series data...")
        
        # Look for time series raster files
        if os.path.exists(self.output_folder):
            for i, timestamp in enumerate(self.timestamps):
                # Look for depth rasters
                depth_file = os.path.join(self.output_folder, f"depth_t{i:04d}.tif")
                if os.path.exists(depth_file):
                    layer_name = f"Flood Depth T{i:04d} ({timestamp:.1f}s)"
                    depth_layer = QgsRasterLayer(depth_file, layer_name)
                    if depth_layer.isValid():
                        self.time_series_layers.append({
                            'type': 'depth',
                            'timestep': i,
                            'timestamp': timestamp,
                            'layer': depth_layer,
                            'file_path': depth_file
                        })
                
                # Look for surface elevation rasters
                surface_file = os.path.join(self.output_folder, f"surface_t{i:04d}.tif")
                if os.path.exists(surface_file):
                    layer_name = f"Water Surface T{i:04d} ({timestamp:.1f}s)"
                    surface_layer = QgsRasterLayer(surface_file, layer_name)
                    if surface_layer.isValid():
                        self.time_series_layers.append({
                            'type': 'surface',
                            'timestep': i,
                            'timestamp': timestamp,
                            'layer': surface_layer,
                            'file_path': surface_file
                        })
        
        logger.info(f"Loaded {len(self.time_series_layers)} time series layers")
        
        # Add layers to project if not already added
        self.add_layers_to_project()
    
    def add_layers_to_project(self):
        """Add time series layers to QGIS project (QGIS mode only)."""
        if not self.qgis_mode or not QGIS_AVAILABLE:
            logger.debug("⚠️ Layer addition not available in standalone mode")
            return
            
        try:
            project = QgsProject.instance()
            
            for layer_info in self.time_series_layers:
                layer = layer_info['layer']
                if not project.mapLayer(layer.id()):
                    project.addMapLayer(layer, False)  # Don't add to legend yet
                    
                    # Hide all layers except the first timestep
                    if layer_info['timestep'] != 0:
                        layer.setCustomProperty('overview', False)
            
            # Show only the first timestep initially
            self.update_visible_layers()
            
        except Exception as e:
            logger.error(f"❌ Error adding layers to project: {e}")
    
    def update_visible_layers(self):
        """Update which layers are visible based on current timestep (QGIS mode only)."""
        if not self.qgis_mode or not QGIS_AVAILABLE:
            return
            
        try:
            if not self.auto_hide_checkbox.isChecked():
                return
            
            for layer_info in self.time_series_layers:
                layer = layer_info['layer']
                should_be_visible = (layer_info['timestep'] == self.current_timestep)
                
                # Update layer visibility in legend
                root = QgsProject.instance().layerTreeRoot()
                layer_node = root.findLayer(layer.id())
                if layer_node:
                    layer_node.setItemVisibilityChecked(should_be_visible)
                    
        except Exception as e:
            logger.debug(f"Could not update layer visibility: {e}")
    
    def toggle_animation(self):
        """Toggle animation play/pause."""
        if self.is_playing:
            self.pause_animation()
        else:
            self.start_animation()
    
    def start_animation(self):
        """Start the animation."""
        if not self.timestamps:
            logger.warning("No timesteps available for animation")
            return
        
        self.is_playing = True
        self.play_button.setText("⏸️ Pause")
        self.timer.start(self.animation_speed)
        self.animation_started.emit()
        logger.info("Animation started")
    
    def pause_animation(self):
        """Pause the animation."""
        self.is_playing = False
        self.play_button.setText("▶️ Play")
        self.timer.stop()
        logger.info("Animation paused")
    
    def stop_animation(self):
        """Stop the animation and reset to first timestep."""
        self.pause_animation()
        self.current_timestep = 0
        self.timeline_slider.setValue(0)
        self.update_display()
        self.animation_stopped.emit()
        logger.info("Animation stopped")
    
    def next_timestep(self):
        """Advance to next timestep."""
        if not self.timestamps:
            return
        
        if self.current_timestep < len(self.timestamps) - 1:
            self.current_timestep += 1
        elif self.loop_checkbox.isChecked():
            self.current_timestep = 0
        else:
            self.pause_animation()
            return
        
        self.timeline_slider.setValue(self.current_timestep)
        self.update_display()
    
    def previous_timestep(self):
        """Go back to previous timestep."""
        if not self.timestamps:
            return
        
        if self.current_timestep > 0:
            self.current_timestep -= 1
        elif self.loop_checkbox.isChecked():
            self.current_timestep = len(self.timestamps) - 1
        
        self.timeline_slider.setValue(self.current_timestep)
        self.update_display()
    
    def on_slider_changed(self, value):
        """Handle timeline slider changes."""
        if value != self.current_timestep:
            self.current_timestep = value
            self.update_display()
    
    def update_display(self):
        """Update all display elements for current timestep."""
        if not self.timestamps:
            return
        
        # Update labels
        current_time = self.timestamps[self.current_timestep] if self.current_timestep < len(self.timestamps) else 0
        self.timestep_label.setText(f"Timestep: {self.current_timestep + 1} / {len(self.timestamps)}")
        self.time_label.setText(f"Time: {current_time:.1f} s")
        
        # Update visible layers
        self.update_visible_layers()
        
        # Refresh map canvas (QGIS mode only)
        if self.qgis_mode and self.map_canvas:
            self.map_canvas.refresh()
        
        # Emit signal
        self.timestep_changed.emit(self.current_timestep)
    
    def update_animation_speed(self, fps):
        """Update animation speed from FPS value."""
        self.animation_speed = int(1000 / fps)  # Convert FPS to milliseconds
        if self.is_playing:
            self.timer.stop()
            self.timer.start(self.animation_speed)
    
    def on_map_clicked(self, point, button):
        """Handle map clicks for point information."""
        if not self.qgis_mode:
            return
            
        try:
            # Get point in map coordinates
            map_point = point
            
            # Transform to RH2000 (if coordinate transform available)
            if self.coord_transform:
                rh2000_point = self.coord_transform.transform(map_point)
            else:
                rh2000_point = map_point
            
            # Update coordinate display
            self.map_x_label.setText(f"{map_point.x():.2f}")
            self.map_y_label.setText(f"{map_point.y():.2f}")
            self.rh2000_x_label.setText(f"{rh2000_point.x():.2f}")
            self.rh2000_y_label.setText(f"{rh2000_point.y():.2f}")
            
            # Sample data at this point
            self.sample_data_at_point(map_point)
            
        except Exception as e:
            logger.error(f"Error handling map click: {e}")
    
    def sample_data_at_point(self, point):
        """Sample flood data at the clicked point."""
        try:
            # Sample current timestep data
            current_depth = self.sample_raster_at_point(point, 'depth', self.current_timestep)
            current_surface = self.sample_raster_at_point(point, 'surface', self.current_timestep)
            
            # Update current data display
            if current_depth is not None and current_depth != -9999:
                self.depth_label.setText(f"{current_depth:.3f} m")
            else:
                self.depth_label.setText("No Data")
            
            if current_surface is not None and current_surface != -9999:
                self.elevation_label.setText(f"{current_surface:.3f} m")
                
                # Calculate DEM elevation (surface - depth)
                if current_depth is not None and current_depth != -9999:
                    dem_elev = current_surface - current_depth
                    self.dem_elevation_label.setText(f"{dem_elev:.3f} m")
                else:
                    self.dem_elevation_label.setText("No Data")
            else:
                self.elevation_label.setText("No Data")
                self.dem_elevation_label.setText("No Data")
            
            # TODO: Add velocity sampling if velocity rasters are available
            self.velocity_label.setText("--- m/s")
            
            # Generate time series for this point
            self.generate_time_series(point)
            
        except Exception as e:
            logger.error(f"Error sampling data at point: {e}")
    
    def sample_raster_at_point(self, point, data_type, timestep):
        """Sample a specific raster at a point."""
        try:
            if QGIS_AVAILABLE and self.qgis_mode:
                # QGIS mode - use QGIS sampling
                target_layer = None
                for layer_info in self.time_series_layers:
                    if layer_info['type'] == data_type and layer_info['timestep'] == timestep:
                        target_layer = layer_info['layer']
                        break
                
                if target_layer is None:
                    return None
                
                # Sample the raster
                provider = target_layer.dataProvider()
                sample_result = provider.sample(point, 1)  # Band 1
                
                if sample_result[0]:  # If sampling was successful
                    return sample_result[1]
                else:
                    return None
            else:
                # Standalone mode - use GDAL sampling
                return self._sample_raster_gdal(point, data_type, timestep)
                
        except Exception as e:
            logger.error(f"Error sampling raster: {e}")
            return None
    
    def _sample_raster_gdal(self, point, data_type, timestep):
        """Sample raster using GDAL in standalone mode."""
        try:
            from osgeo import gdal
            import numpy as np
            
            # Find the raster file
            raster_folder = os.path.join(self.output_folder, 'rasters')
            if not os.path.exists(raster_folder):
                raster_folder = self.output_folder
            
            # Build filename pattern
            if data_type == 'depth':
                pattern = f"flood_depth_t{timestep:04d}_*.tif"
            elif data_type == 'surface':
                pattern = f"water_surface_t{timestep:04d}_*.tif"
            elif data_type == 'velocity':
                pattern = f"flood_velocity_t{timestep:04d}_*.tif"
            else:
                return None
            
            # Find matching file
            import glob
            matching_files = glob.glob(os.path.join(raster_folder, pattern))
            if not matching_files:
                return None
            
            raster_file = matching_files[0]
            
            # Open raster
            ds = gdal.Open(raster_file)
            if not ds:
                return None
            
            # Get geotransform
            gt = ds.GetGeoTransform()
            
            # Convert point coordinates to pixel coordinates
            px = int((point.x() - gt[0]) / gt[1])
            py = int((point.y() - gt[3]) / gt[5])
            
            # Check bounds
            if px < 0 or py < 0 or px >= ds.RasterXSize or py >= ds.RasterYSize:
                ds = None
                return None
            
            # Read pixel value
            band = ds.GetRasterBand(1)
            value = band.ReadAsArray(px, py, 1, 1)[0, 0]
            
            ds = None
            
            # Check for nodata
            if value == -9999 or np.isnan(value):
                return None
            
            return float(value)
            
        except Exception as e:
            logger.error(f"Error in GDAL sampling: {e}")
            return None

    def generate_time_series(self, point):
        """Generate time series data for the clicked point."""
        try:
            depth_series = []
            surface_series = []
            
            for i, timestamp in enumerate(self.timestamps):
                depth = self.sample_raster_at_point(point, 'depth', i)
                surface = self.sample_raster_at_point(point, 'surface', i)
                
                depth_series.append((timestamp, depth))
                surface_series.append((timestamp, surface))
            
            # Format time series text
            text_lines = ["Time Series Data at Selected Point:", ""]
            text_lines.append("Time (s) | Depth (m) | Surface Elev (m)")
            text_lines.append("-" * 40)
            
            for i, (timestamp, depth) in enumerate(depth_series):
                surface = surface_series[i][1]
                
                depth_str = f"{depth:.3f}" if depth is not None and depth != -9999 else "No Data"
                surface_str = f"{surface:.3f}" if surface is not None and surface != -9999 else "No Data"
                
                line = f"{timestamp:8.1f} | {depth_str:>8s} | {surface_str:>12s}"
                text_lines.append(line)
            
            self.time_series_text.setPlainText("\n".join(text_lines))
            
        except Exception as e:
            logger.error(f"Error generating time series: {e}")
    
    def export_animation(self):
        """Export animation frames or video."""
        # This would be implemented to export the animation
        # Could save individual frames or create a video file
        logger.info("Export animation functionality would be implemented here")
        
        # Placeholder implementation
        from PyQt5.QtWidgets import QMessageBox
        QMessageBox.information(
            self, 
            "Export Animation",
            "Animation export functionality will be implemented in a future version.\n\n"
            "You can manually capture frames using QGIS's map composer or "
            "screenshot tools while the animation is playing."
        )
    
    def closeEvent(self, event):
        """Handle dialog close event."""
        self.pause_animation()
        
        # Reset map tool (QGIS mode only)
        if self.qgis_mode and self.map_canvas and self.click_tool:
            try:
                if hasattr(self.map_canvas, 'mapTool') and self.map_canvas.mapTool() == self.click_tool:
                    self.map_canvas.unsetMapTool(self.click_tool)
            except:
                pass  # Ignore errors during cleanup
        
        event.accept()


def create_time_series_rasters(results_data, output_folder, geotransform, projection):
    """
    Create individual raster files for each timestep from simulation results.
    
    Parameters:
        results_data (dict): Saint-Venant simulation results
        output_folder (str): Output directory
        geotransform (tuple): GDAL geotransform
        projection (str): Projection string
    """
    logger.info("Creating time series raster files...")
    
    os.makedirs(output_folder, exist_ok=True)
    
    water_depths = results_data.get('water_depths', [])
    times = results_data.get('times', [])
    dem_array = results_data.get('dem_array')
    
    for i, (depth_array, timestamp) in enumerate(zip(water_depths, times)):
        # Save depth raster
        depth_file = os.path.join(output_folder, f"depth_t{i:04d}.tif")
        _save_raster_file(depth_array, depth_file, geotransform, projection)
        
        # Save water surface raster if DEM is available
        if dem_array is not None:
            surface_array = dem_array + depth_array
            surface_file = os.path.join(output_folder, f"surface_t{i:04d}.tif")
            _save_raster_file(surface_array, surface_file, geotransform, projection)
        
        logger.info(f"Created rasters for timestep {i+1}/{len(water_depths)} (t={timestamp:.1f}s)")


def _save_raster_file(data_array, output_path, geotransform, projection, nodata=-9999):
    """Save a numpy array as a GeoTIFF raster file."""
    from osgeo import gdal
    
    try:
        # Handle NaN values
        data_array = np.where(np.isnan(data_array), nodata, data_array)
        
        # Create output dataset
        driver = gdal.GetDriverByName('GTiff')
        rows, cols = data_array.shape
        
        dataset = driver.Create(output_path, cols, rows, 1, gdal.GDT_Float32,
                              ['COMPRESS=LZW', 'TILED=YES'])
        
        if dataset is None:
            raise Exception(f"Could not create output file: {output_path}")
        
        # Set geospatial information
        dataset.SetGeoTransform(geotransform)
        dataset.SetProjection(projection)
        
        # Write data
        band = dataset.GetRasterBand(1)
        band.WriteArray(data_array)
        band.SetNoDataValue(nodata)
        band.ComputeStatistics(0)
        
        # Clean up
        band = None
        dataset = None
        
    except Exception as e:
        logger.error(f"Error saving raster {output_path}: {e}")
        raise


def show_time_series_animator(results_data, output_folder):
    """
    Show the time series animator dialog.
    
    Parameters:
        results_data (dict): Saint-Venant simulation results
        output_folder (str): Path to output folder
        
    Returns:
        TimeSeriesAnimator: The animator dialog instance
    """
    animator = TimeSeriesAnimator(results_data, output_folder)
    animator.show()
    return animator
