#!/usr/bin/env python3
"""
Test the velocity fix by comparing old vs new slope calculations.
"""
import numpy as np

def test_slope_calculation():
    """Test the difference between old buggy and new fixed slope calculations."""
    
    print("🧪 Testing slope calculation fix...")
    
    # Create synthetic DEM data
    dem_data = np.array([
        [100, 98, 95, 90, 85],
        [102, 100, 97, 92, 87],
        [104, 102, 99, 94, 89],
        [106, 104, 101, 96, 91],
        [108, 106, 103, 98, 93]
    ], dtype=float)
    
    # Synthetic geotransform (10m pixel size)
    geotransform = (0, 10, 0, 0, 0, -10)
    dx = abs(geotransform[1])  # 10m
    dy = abs(geotransform[5])  # 10m
    
    # OLD BUGGY METHOD
    gradient_x_old = np.gradient(dem_data, axis=1, edge_order=2)
    gradient_y_old = np.gradient(dem_data, axis=0, edge_order=2)
    slope_old = np.sqrt(gradient_x_old**2 + gradient_y_old**2)
    
    # NEW FIXED METHOD
    gradient_x_new = np.gradient(dem_data, axis=1, edge_order=2)
    gradient_y_new = np.gradient(dem_data, axis=0, edge_order=2)
    slope_x_new = gradient_x_new / dx
    slope_y_new = gradient_y_new / dy
    slope_new = np.sqrt(slope_x_new**2 + slope_y_new**2)
    slope_new = np.clip(slope_new, 0.0001, 0.3)
    
    print(f"📊 DEM elevation range: {np.min(dem_data):.1f} to {np.max(dem_data):.1f} m")
    print(f"📐 Pixel size: {dx}m x {dy}m")
    print()
    print(f"❌ OLD BUGGY slope range: {np.min(slope_old):.3f} to {np.max(slope_old):.3f}")
    print(f"✅ NEW FIXED slope range: {np.min(slope_new):.3f} to {np.max(slope_new):.3f}")
    print()
    
    # Test Manning velocity calculation
    manning_n = 0.03
    flood_depth = 2.0  # 2m depth
    
    # OLD BUGGY Manning velocity
    velocity_old = (1.0 / manning_n) * (flood_depth ** (2/3)) * (np.max(slope_old) ** 0.5)
    
    # NEW FIXED Manning velocity
    velocity_new = (1.0 / manning_n) * (flood_depth ** (2/3)) * (np.max(slope_new) ** 0.5)
    
    print(f"🌊 Manning velocity calculation (depth = {flood_depth}m, n = {manning_n}):")
    print(f"❌ OLD BUGGY: {velocity_old:.1f} m/s")
    print(f"✅ NEW FIXED: {velocity_new:.1f} m/s")
    print(f"📉 Velocity reduction factor: {velocity_old/velocity_new:.1f}x")
    print()
    
    # Show why the old method was wrong
    print("🔍 Why the old method was wrong:")
    print(f"   • np.gradient() returns elevation change per PIXEL")
    print(f"   • Example: 5m elevation drop over 1 pixel = 5.0 gradient")
    print(f"   • But 1 pixel = {dx}m, so actual slope = 5.0/{dx} = {5.0/dx:.3f}")
    print(f"   • OLD method used 5.0 as slope → extreme velocities")
    print(f"   • NEW method uses {5.0/dx:.3f} as slope → realistic velocities")
    
    return velocity_old, velocity_new

if __name__ == "__main__":
    test_slope_calculation()
