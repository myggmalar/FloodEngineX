"""
FloodEngine v4.0 - Batch Processing Framework
============================================

Multi-scenario batch processing for flood modeling automation.
Supports parameter sweeps, multiple datasets, and automated report generation.

Author: FloodEngine Development Team
Date: June 7, 2025
"""

import os
import json
import time
import traceback
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple
import tempfile
import shutil

class BatchJob:
    """Represents a single batch processing job."""
    
    def __init__(self, job_id: str, dem_path: str, parameters: Dict[str, Any]):
        """Initialize a batch job.
        
        Args:
            job_id (str): Unique identifier for the job
            dem_path (str): Path to DEM file
            parameters (dict): FloodEngine parameters
        """
        self.job_id = job_id
        self.dem_path = dem_path
        self.parameters = parameters
        self.status = "pending"
        self.start_time = None
        self.end_time = None
        self.output_files = []
        self.error_message = None
        self.execution_time = None
    
    def to_dict(self):
        """Convert job to dictionary for serialization."""
        return {
            'job_id': self.job_id,
            'dem_path': self.dem_path,
            'parameters': self.parameters,
            'status': self.status,
            'start_time': self.start_time,
            'end_time': self.end_time,
            'output_files': self.output_files,
            'error_message': self.error_message,
            'execution_time': self.execution_time
        }

class BatchConfiguration:
    """Configuration for batch processing scenarios."""
    
    def __init__(self, name: str, description: str = ""):
    self.manning_n = 0.035  # default Manning’s n
        """Initialize batch configuration.
        
        Args:
            name (str): Configuration name
            description (str): Configuration description
        """
        self.name = name
        self.description = description
        self.jobs = []
        self.output_directory = None
        self.created_date = datetime.now().isoformat()
    
    def add_parameter_sweep(self, dem_path: str, parameter_name: str, 
                           values: List[Any], base_parameters: Dict[str, Any]):
        """Add jobs for parameter sweep analysis.
        
        Args:
            dem_path (str): Path to DEM file
            parameter_name (str): Parameter to sweep
            values (list): List of parameter values to test
            base_parameters (dict): Base parameters for all jobs
        """
        for i, value in enumerate(values):
            parameters = base_parameters.copy()
            parameters[parameter_name] = value
            
            job_id = f"{self.name}_sweep_{parameter_name}_{i:03d}"
            job = BatchJob(job_id, dem_path, parameters)
            self.jobs.append(job)
    
    def add_multi_dem_analysis(self, dem_paths: List[str], parameters: Dict[str, Any]):
        """Add jobs for multiple DEM analysis with same parameters.
        
        Args:
            dem_paths (list): List of DEM file paths
            parameters (dict): Common parameters for all DEMs
        """
        for i, dem_path in enumerate(dem_paths):
            dem_name = os.path.splitext(os.path.basename(dem_path))[0]
            job_id = f"{self.name}_multi_dem_{dem_name}"
            job = BatchJob(job_id, dem_path, parameters)
            self.jobs.append(job)
    
    def add_scenario_matrix(self, dem_paths: List[str], parameter_sets: List[Dict[str, Any]]):
        """Add jobs for full scenario matrix (all DEMs x all parameter sets).
        
        Args:
            dem_paths (list): List of DEM file paths
            parameter_sets (list): List of parameter dictionaries
        """
        for i, dem_path in enumerate(dem_paths):
            dem_name = os.path.splitext(os.path.basename(dem_path))[0]
            for j, parameters in enumerate(parameter_sets):
                job_id = f"{self.name}_matrix_{dem_name}_{j:03d}"
                job = BatchJob(job_id, dem_path, parameters)
                self.jobs.append(job)
    
    def save_configuration(self, filepath: str):
        """Save configuration to JSON file.
        
        Args:
            filepath (str): Path to save configuration
        """
        config_data = {
            'name': self.name,
            'description': self.description,
            'created_date': self.created_date,
            'total_jobs': len(self.jobs),
            'jobs': [job.to_dict() for job in self.jobs]
        }
        
        with open(filepath, 'w') as f:
            json.dump(config_data, f, indent=2)
    
    @classmethod
    def load_configuration(cls, filepath: str):
        """Load configuration from JSON file.
        
        Args:
            filepath (str): Path to configuration file
            
        Returns:
            BatchConfiguration: Loaded configuration
        """
        with open(filepath, 'r') as f:
            config_data = json.load(f)
        
        config = cls(config_data['name'], config_data.get('description', ''))
        config.created_date = config_data.get('created_date', '')
        
        for job_data in config_data['jobs']:
            job = BatchJob(job_data['job_id'], job_data['dem_path'], job_data['parameters'])
            job.status = job_data.get('status', 'pending')
            job.start_time = job_data.get('start_time')
            job.end_time = job_data.get('end_time')
            job.output_files = job_data.get('output_files', [])
            job.error_message = job_data.get('error_message')
            job.execution_time = job_data.get('execution_time')
            config.jobs.append(job)
        
        return config

class BatchProgressCallback:
    """Callback interface for batch processing progress."""
    
    def on_batch_started(self, total_jobs: int):
        """Called when batch processing starts."""
        pass
    
    def on_job_started(self, job: BatchJob, current_job: int, total_jobs: int):
        """Called when a job starts."""
        pass
    
    def on_job_completed(self, job: BatchJob, current_job: int, total_jobs: int):
        """Called when a job completes."""
        pass
    
    def on_job_failed(self, job: BatchJob, current_job: int, total_jobs: int, error: str):
        """Called when a job fails."""
        pass
    
    def on_batch_completed(self, completed_jobs: int, failed_jobs: int, total_time: float):
        """Called when batch processing completes."""
        pass

class ConsoleProgressCallback(BatchProgressCallback):
    """Console-based progress callback."""
    
    def on_batch_started(self, total_jobs: int):
        print(f"Starting batch processing: {total_jobs} jobs")
        print("=" * 50)
    
    def on_job_started(self, job: BatchJob, current_job: int, total_jobs: int):
        print(f"[{current_job}/{total_jobs}] Starting: {job.job_id}")
    
    def on_job_completed(self, job: BatchJob, current_job: int, total_jobs: int):
        print(f"[{current_job}/{total_jobs}] Completed: {job.job_id} ({job.execution_time:.1f}s)")
    
    def on_job_failed(self, job: BatchJob, current_job: int, total_jobs: int, error: str):
        print(f"[{current_job}/{total_jobs}] FAILED: {job.job_id} - {error}")
    
    def on_batch_completed(self, completed_jobs: int, failed_jobs: int, total_time: float):
        print("=" * 50)
        print(f"Batch processing completed:")
        print(f"  Successful jobs: {completed_jobs}")
        print(f"  Failed jobs: {failed_jobs}")
        print(f"  Total time: {total_time:.1f} seconds")

class BatchProcessor:
    """Main batch processing engine."""
    
    def __init__(self, hydraulic_model, output_directory: str):
    self.manning_n = 0.035  # default Manning’s n
        """Initialize batch processor.
        
        Args:
            hydraulic_model: FloodEngine hydraulic model instance
            output_directory (str): Base output directory for all jobs
        """
        self.hydraulic_model = hydraulic_model
        self.output_directory = output_directory
        self.progress_callback = ConsoleProgressCallback()
        self.continue_on_error = True
        
        # Ensure output directory exists
        os.makedirs(output_directory, exist_ok=True)
    
    def set_progress_callback(self, callback: BatchProgressCallback):
        """Set custom progress callback.
        
        Args:
            callback (BatchProgressCallback): Progress callback instance
        """
        self.progress_callback = callback
    
    def process_configuration(self, config: BatchConfiguration) -> Tuple[int, int]:
        """Process a batch configuration.
        
        Args:
            config (BatchConfiguration): Batch configuration to process
            
        Returns:
            tuple: (completed_jobs, failed_jobs)
        """
        batch_start_time = time.time()
        completed_jobs = 0
        failed_jobs = 0
        
        # Create batch-specific output directory
        batch_output_dir = os.path.join(self.output_directory, f"batch_{config.name}_{int(time.time())}")
        os.makedirs(batch_output_dir, exist_ok=True)
        config.output_directory = batch_output_dir
        
        self.progress_callback.on_batch_started(len(config.jobs))
        
        for i, job in enumerate(config.jobs, 1):
            try:
                self.progress_callback.on_job_started(job, i, len(config.jobs))
                
                # Process single job
                success = self._process_job(job, batch_output_dir)
                
                if success:
                    completed_jobs += 1
                    self.progress_callback.on_job_completed(job, i, len(config.jobs))
                else:
                    failed_jobs += 1
                    self.progress_callback.on_job_failed(job, i, len(config.jobs), 
                                                       job.error_message or "Unknown error")
                    
                    if not self.continue_on_error:
                        break
                        
            except Exception as e:
                failed_jobs += 1
                job.status = "failed"
                job.error_message = str(e)
                self.progress_callback.on_job_failed(job, i, len(config.jobs), str(e))
                
                if not self.continue_on_error:
                    break
        
        # Save final configuration with results
        config_path = os.path.join(batch_output_dir, "batch_configuration.json")
        config.save_configuration(config_path)
        
        # Generate summary report
        self._generate_batch_report(config, batch_output_dir, completed_jobs, failed_jobs)
        
        total_time = time.time() - batch_start_time
        self.progress_callback.on_batch_completed(completed_jobs, failed_jobs, total_time)
        
        return completed_jobs, failed_jobs
    
    def _process_job(self, job: BatchJob, output_directory: str) -> bool:
        """Process a single batch job.
        
        Args:
            job (BatchJob): Job to process
            output_directory (str): Output directory for job results
            
        Returns:
            bool: True if successful, False otherwise
        """
        job.start_time = datetime.now().isoformat()
        job.status = "running"
        start_time = time.time()
        
        try:
            # Create job-specific output directory
            job_output_dir = os.path.join(output_directory, job.job_id)
            os.makedirs(job_output_dir, exist_ok=True)
            
            # Prepare parameters with output directory
            parameters = job.parameters.copy()
            parameters['output_directory'] = job_output_dir
            
            # Execute hydraulic model
            # Note: This assumes the hydraulic model has a batch-compatible interface
            if hasattr(self.hydraulic_model, 'run_batch_simulation'):
                results = self.hydraulic_model.run_batch_simulation(job.dem_path, parameters)
            else:
                # Fallback to standard interface
                results = self.hydraulic_model.run_simulation(job.dem_path, **parameters)
            
            # Collect output files
            if os.path.exists(job_output_dir):
                job.output_files = [os.path.join(job_output_dir, f) 
                                  for f in os.listdir(job_output_dir)
                                  if f.endswith(('.tif', '.csv', '.txt'))]
            
            job.status = "completed"
            job.end_time = datetime.now().isoformat()
            job.execution_time = time.time() - start_time
            
            return True
            
        except Exception as e:
            job.status = "failed"
            job.error_message = str(e)
            job.end_time = datetime.now().isoformat()
            job.execution_time = time.time() - start_time
            
            return False
    
    def _generate_batch_report(self, config: BatchConfiguration, output_directory: str,
                             completed_jobs: int, failed_jobs: int):
        """Generate comprehensive batch processing report.
        
        Args:
            config (BatchConfiguration): Batch configuration
            output_directory (str): Output directory
            completed_jobs (int): Number of completed jobs
            failed_jobs (int): Number of failed jobs
        """
        report_path = os.path.join(output_directory, "batch_report.md")
        
        with open(report_path, 'w') as f:
            f.write(f"# FloodEngine Batch Processing Report\n\n")
            f.write(f"**Configuration**: {config.name}\n")
            f.write(f"**Description**: {config.description}\n")
            f.write(f"**Generated**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            f.write(f"## Summary\n\n")
            f.write(f"- **Total Jobs**: {len(config.jobs)}\n")
            f.write(f"- **Completed**: {completed_jobs}\n")
            f.write(f"- **Failed**: {failed_jobs}\n")
            f.write(f"- **Success Rate**: {completed_jobs/len(config.jobs)*100:.1f}%\n\n")
            
            f.write(f"## Job Details\n\n")
            for job in config.jobs:
                f.write(f"### {job.job_id}\n")
                f.write(f"- **Status**: {job.status}\n")
                f.write(f"- **DEM**: {os.path.basename(job.dem_path)}\n")
                f.write(f"- **Execution Time**: {job.execution_time:.1f}s\n")
                
                if job.error_message:
                    f.write(f"- **Error**: {job.error_message}\n")
                
                if job.output_files:
                    f.write(f"- **Output Files**: {len(job.output_files)}\n")
                    for output_file in job.output_files:
                        f.write(f"  - {os.path.basename(output_file)}\n")
                
                f.write(f"\n")
            
            f.write(f"## Parameters Used\n\n")
            if config.jobs:
                # Show parameters from first job as example
                example_params = config.jobs[0].parameters
                for key, value in example_params.items():
                    f.write(f"- **{key}**: {value}\n")

def create_water_level_sweep_config(name: str, dem_path: str, 
                                  water_levels: List[float],
                                  base_parameters: Dict[str, Any] = None) -> BatchConfiguration:
    """Create a configuration for water level parameter sweep.
    
    Args:
        name (str): Configuration name
        dem_path (str): Path to DEM file
        water_levels (list): List of water levels to test
        base_parameters (dict): Base parameters
        
    Returns:
        BatchConfiguration: Created configuration
    """
    if base_parameters is None:
        base_parameters = {
            'model_type': 'saint_venant_2d',
            'time_step': 0.1,
            'total_time': 3600,
            'manning_n': 0.035,
            'output_interval': 300
        }
    
    config = BatchConfiguration(name, f"Water level sweep: {water_levels}")
    config.add_parameter_sweep(dem_path, 'dam_height', water_levels, base_parameters)
    
    return config

def create_multi_scenario_config(name: str, dem_paths: List[str],
                                scenario_parameters: List[Dict[str, Any]]) -> BatchConfiguration:
    """Create a configuration for multi-scenario analysis.
    
    Args:
        name (str): Configuration name
        dem_paths (list): List of DEM file paths
        scenario_parameters (list): List of scenario parameter sets
        
    Returns:
        BatchConfiguration: Created configuration
    """
    config = BatchConfiguration(name, f"Multi-scenario analysis: {len(scenario_parameters)} scenarios")
    config.add_scenario_matrix(dem_paths, scenario_parameters)
    
    return config