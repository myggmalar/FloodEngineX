#!/usr/bin/env python3
"""
Simple FloodEngine Validation Test
Check implementation without requiring imports
"""

import os
import re

def validate_connect_signals_implementation():
    """Validate that connect_signals is properly implemented"""
    print("🔍 Validating connect_signals Implementation")
    print("=" * 50)
    
    ui_file = "floodengine_ui.py"
    if not os.path.exists(ui_file):
        print(f"❌ UI file not found: {ui_file}")
        return False
    
    with open(ui_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check for connect_signals method
    if "def connect_signals(self):" not in content:
        print("❌ connect_signals method not found")
        return False
    
    print("✅ connect_signals method found")
    
    # Check for key signal connections that were previously missing
    required_connections = [
        "adv_hydrograph_btn.clicked.connect",
        "adv_buildings_btn.clicked.connect", 
        "adv_soil_btn.clicked.connect",
        "adv_enable_groundwater.toggled.connect",
        "adv_enable_urban.toggled.connect",
        "run_button.clicked.connect",
        "night_mode_toggle.toggled.connect"
    ]
    
    missing_connections = []
    found_connections = []
    
    for connection in required_connections:
        if connection in content:
            found_connections.append(connection)
            print(f"✅ {connection}")
        else:
            missing_connections.append(connection)
            print(f"❌ {connection}")
    
    print(f"\nConnections: {len(found_connections)}/{len(required_connections)} found")
    
    return len(missing_connections) == 0

def validate_toggle_methods():
    """Validate that toggle methods are properly implemented"""
    print("\n🔄 Validating Toggle Methods")
    print("=" * 50)
    
    ui_file = "floodengine_ui.py"
    with open(ui_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check for toggle methods
    required_methods = [
        "def toggle_groundwater_controls(self, enabled):",
        "def toggle_urban_controls(self, enabled):",
        "def toggle_advanced_engine(self, enabled):",
        "def toggle_advanced_stream_burning(self, enabled):"
    ]
    
    missing_methods = []
    found_methods = []
    
    for method in required_methods:
        if method in content:
            found_methods.append(method)
            print(f"✅ {method}")
        else:
            missing_methods.append(method)
            print(f"❌ {method}")
    
    print(f"\nMethods: {len(found_methods)}/{len(required_methods)} found")
    
    return len(missing_methods) == 0

def validate_ui_elements():
    """Validate that UI elements are properly created"""
    print("\n🎯 Validating UI Elements Creation")
    print("=" * 50)
    
    ui_file = "floodengine_ui.py"
    with open(ui_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check for UI elements that were previously missing
    required_elements = [
        "self.adv_hydrograph",
        "self.adv_hydrograph_path", 
        "self.adv_hydrograph_btn",
        "self.adv_buildings_path",
        "self.adv_buildings_btn",
        "self.adv_enable_groundwater",
        "self.adv_hydraulic_conductivity",
        "self.adv_storage_coefficient",
        "self.adv_enable_urban",
        "self.adv_drainage_capacity",
        "self.adv_include_sewers",
        "self.adv_include_culverts",
        "self.adv_length",
        "self.adv_width",
        "self.adv_shape",
        "self.adv_side_slope",
        "self.adv_manning",
        "self.adv_draw_threshold"
    ]
    
    missing_elements = []
    found_elements = []
    
    for element in required_elements:
        # Look for element assignment (creation)
        if f"{element} =" in content:
            found_elements.append(element)
            print(f"✅ {element}")
        else:
            missing_elements.append(element)
            print(f"❌ {element}")
    
    print(f"\nElements: {len(found_elements)}/{len(required_elements)} found")
    
    return len(missing_elements) == 0

def validate_syntax():
    """Validate Python syntax"""
    print("\n📝 Validating Python Syntax")
    print("=" * 50)
    
    import py_compile
    
    try:
        py_compile.compile("floodengine_ui.py", doraise=True)
        print("✅ Python syntax is valid")
        return True
    except py_compile.PyCompileError as e:
        print(f"❌ Syntax error: {e}")
        return False

def main():
    """Run all validations"""
    print("🚀 FloodEngine Simple Validation Test")
    print("=" * 70)
    
    tests = [
        ("Syntax Validation", validate_syntax),
        ("connect_signals Implementation", validate_connect_signals_implementation),
        ("Toggle Methods", validate_toggle_methods),
        ("UI Elements Creation", validate_ui_elements)
    ]
    
    results = []
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"❌ {test_name} failed: {e}")
            results.append((test_name, False))
    
    # Summary
    print("\n" + "=" * 70)
    print("📊 VALIDATION SUMMARY")
    print("=" * 70)
    
    passed = 0
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} {test_name}")
        if result:
            passed += 1
    
    print(f"\nResult: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 VALIDATION SUCCESSFUL!")
        print("✅ FloodEngine implementation is complete")
        print("✅ All connect_signals issues resolved")
        print("✅ Ready for QGIS plugin testing")
        return True
    else:
        print(f"\n❌ VALIDATION INCOMPLETE: {total - passed} tests failed")
        return False

if __name__ == "__main__":
    success = main()
    exit(0 if success else 1)
