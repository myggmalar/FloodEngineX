#!/usr/bin/env python3
"""
Plugin structure validation - checks files without importing dependencies
"""

import os

def validate_plugin_structure():
    """Validate that all required plugin files are present"""
    
    print("=" * 60)
    print("QGIS PLUGIN STRUCTURE VALIDATION")
    print("=" * 60)
    
    # Required files for QGIS plugin
    required_files = [
        '__init__.py',
        'floodengine.py',
        'floodengine_ui.py',
        'model_hydraulic.py',
        'metadata.txt'
    ]
    
    print("\n1. CHECKING REQUIRED FILES:")
    print("-" * 40)
    
    missing_files = []
    for file_name in required_files:
        if os.path.exists(file_name):
            file_size = os.path.getsize(file_name)
            print(f"✓ {file_name} ({file_size:,} bytes)")
        else:
            print(f"✗ {file_name} - MISSING")
            missing_files.append(file_name)
    
    # Check imports in key files
    print("\n2. CHECKING IMPORT STRUCTURE:")
    print("-" * 40)
    
    # Check __init__.py
    if os.path.exists('__init__.py'):
        with open('__init__.py', 'r', encoding='utf-8') as f:
            init_content = f.read()
        if 'from .floodengine import FloodEngine' in init_content:
            print("✓ __init__.py has correct relative import")
        else:
            print("✗ __init__.py missing correct import")
    
    # Check floodengine.py
    if os.path.exists('floodengine.py'):
        with open('floodengine.py', 'r', encoding='utf-8') as f:
            main_content = f.read()
        if 'from .floodengine_ui import FloodEngineDialog' in main_content:
            print("✓ floodengine.py has correct relative import")
        else:
            print("✗ floodengine.py missing correct import")
    
    # Check floodengine_ui.py
    if os.path.exists('floodengine_ui.py'):
        with open('floodengine_ui.py', 'r', encoding='utf-8') as f:
            ui_content = f.read()
        if 'from .model_hydraulic import' in ui_content:
            print("✓ floodengine_ui.py has correct relative imports")
        else:
            print("✗ floodengine_ui.py missing correct relative imports")
    
    print("\n3. VALIDATION RESULT:")
    print("-" * 40)
    
    if not missing_files:
        print("✓ SUCCESS: All required files present with correct import structure")
        print("\nThe plugin should now load correctly in QGIS!")
        print("\nTo deploy:")
        print("1. Copy this entire folder to QGIS plugins directory")
        print("2. Restart QGIS")
        print("3. Enable the plugin in Plugin Manager")
        return True
    else:
        print(f"✗ FAILED: Missing files: {', '.join(missing_files)}")
        return False

if __name__ == "__main__":
    validate_plugin_structure()
