#!/usr/bin/env python3
"""Direct test of animation launch after creating fake output folder."""

import sys
import os
import tempfile
import shutil

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def create_fake_output_folder():
    """Create a fake output folder with animation data."""
    temp_dir = tempfile.mkdtemp(prefix='floodengine_test_')
    output_folder = os.path.join(temp_dir, "test_model_output")
    
    # Create the main output folder
    os.makedirs(output_folder, exist_ok=True)
    
    # Create animation subfolder
    animation_folder = os.path.join(output_folder, 'time_series_animation')
    os.makedirs(animation_folder, exist_ok=True)
    
    # Create some fake animation files
    with open(os.path.join(animation_folder, 'animation_data.txt'), 'w') as f:
        f.write("Fake animation data for testing")
    
    # Create rasters folder too
    rasters_folder = os.path.join(animation_folder, 'rasters')
    os.makedirs(rasters_folder, exist_ok=True)
    
    with open(os.path.join(rasters_folder, 'test_raster.txt'), 'w') as f:
        f.write("Fake raster data")
    
    print(f"✅ Created fake output folder: {output_folder}")
    print(f"📁 Animation folder: {animation_folder}")
    print(f"📁 Rasters folder: {rasters_folder}")
    
    return temp_dir, output_folder

def test_launch_from_ui():
    """Test launching animation from UI perspective."""
    print("🔍 Testing animation launch from UI perspective...")
    
    try:
        # Create fake output
        temp_dir, output_folder = create_fake_output_folder()
        
        # Import UI module
        from floodengine_ui import FloodEngineDialog
        
        # Create a fake UI instance
        class FakeUI:
            def __init__(self):
                self.iface = None
                
            def show_message(self, msg):
                print(f"📢 UI Message: {msg}")
                
            def launch_animation_controls(self, output_folder):
                """Copy of the actual method from FloodEngineDialog."""
                print(f"🎬 Attempting to launch animation from: {output_folder}")
                
                try:
                    # Import the launch function
                    from launch_animation import launch_animation_from_folder
                    
                    # Check for animation folder
                    animation_folder = None
                    if os.path.exists(os.path.join(output_folder, 'time_series_animation')):
                        animation_folder = os.path.join(output_folder, 'time_series_animation')
                        print(f"📁 Found time_series_animation folder: {animation_folder}")
                    elif os.path.exists(os.path.join(output_folder, 'rasters')):
                        animation_folder = output_folder
                        print(f"📁 Found rasters in output folder: {animation_folder}")
                    
                    if animation_folder:
                        print(f"📁 Animation data confirmed in: {animation_folder}")
                        
                        # List contents for debugging
                        try:
                            contents = os.listdir(animation_folder)
                            print(f"📄 Folder contents: {contents}")
                        except Exception as e:
                            print(f"⚠️ Could not list folder contents: {e}")
                        
                        # FORCE STANDALONE MODE FOR DEBUGGING
                        print("🖥️ Forcing standalone mode for debugging...")
                        try:
                            result = launch_animation_from_folder(animation_folder, standalone=True)
                            
                            if result:
                                print("✅ Animation controls launched successfully!")
                                self.show_message("Animation controls are now available!")
                                return True
                            else:
                                print("❌ Animation launch returned False")
                                self.show_message("Animation launch failed - check console for details")
                                return False
                                
                        except Exception as e:
                            print(f"❌ Animation launch error: {e}")
                            import traceback
                            traceback.print_exc()
                            self.show_message(f"Animation error: {e}")
                            return False
                    else:
                        print("❌ No animation data found in output folder")
                        print(f"🔍 Checked paths:")
                        print(f"  - {os.path.join(output_folder, 'time_series_animation')}")
                        print(f"  - {os.path.join(output_folder, 'rasters')}")
                        self.show_message("No animation data found - check that 'Create animation' was selected")
                        return False
                        
                except ImportError as e:
                    print(f"❌ Cannot import animation launcher: {e}")
                    self.show_message("Animation module not available")
                    return False
                except Exception as e:
                    print(f"❌ Unexpected animation error: {e}")
                    import traceback
                    traceback.print_exc()
                    self.show_message(f"Animation error: {e}")
                    return False
        
        # Test the launch
        fake_ui = FakeUI()
        result = fake_ui.launch_animation_controls(output_folder)
        
        print(f"\n{'✅ Animation launch test PASSED' if result else '❌ Animation launch test FAILED'}")
        
        return result
        
    except Exception as e:
        print(f"❌ Test failed with exception: {e}")
        import traceback
        traceback.print_exc()
        return False
        
    finally:
        # Clean up
        try:
            if 'temp_dir' in locals():
                shutil.rmtree(temp_dir)
                print(f"🧹 Cleaned up temp directory")
        except:
            pass

if __name__ == "__main__":
    success = test_launch_from_ui()
    sys.exit(0 if success else 1)
