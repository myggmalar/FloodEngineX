"""
Verify QGIS Plugin Compatibility
This script checks if the FloodEngine plugin is compatible with QGIS
"""
import os
import sys
import py_compile

def verify_plugin_structure():
    """Verify plugin directory structure"""
    required_files = [
        "__init__.py",
        "floodengine.py",
        "floodengine_ui.py",
        "model_hydraulic.py"
    ]
    
    for filename in required_files:
        if not os.path.exists(filename):
            print(f"❌ Required file missing: {filename}")
            return False
    
    print("✅ All required files present")
    return True

def verify_init_file():
    """Verify __init__.py contains classFactory function"""
    try:
        with open("__init__.py", "r", encoding="utf-8") as f:
            content = f.read()
            
        if "def classFactory" not in content:
            print("❌ __init__.py is missing classFactory function")
            return False
        
        print("✅ __init__.py contains classFactory function")
        return True
    except Exception as e:
        print(f"❌ Error reading __init__.py: {e}")
        return False

def compile_key_files():
    """Compile key Python files to check syntax"""
    files_to_check = [
        "__init__.py",
        "floodengine.py",
        "floodengine_ui.py",
        "model_hydraulic.py",
        "flow_direction_flood_fixed.py"
    ]
    
    all_ok = True
    for filename in files_to_check:
        if not os.path.exists(filename):
            continue
            
        try:
            py_compile.compile(filename, doraise=True)
            print(f"✅ {filename} compiled successfully")
        except py_compile.PyCompileError as e:
            print(f"❌ {filename} has syntax errors: {e}")
            all_ok = False
        except Exception as e:
            print(f"❌ Error compiling {filename}: {e}")
            all_ok = False
    
    return all_ok

def main():
    """Main function"""
    print("QGIS Plugin Compatibility Check")
    print("===============================")
    
    # Check current directory
    print(f"Current directory: {os.getcwd()}")
    print()
    
    # Verify structure
    structure_ok = verify_plugin_structure()
    if not structure_ok:
        print("\n❌ Plugin structure verification failed")
        return 1
    
    # Verify init file
    init_ok = verify_init_file()
    if not init_ok:
        print("\n❌ __init__.py verification failed")
        return 1
    
    # Compile files
    print("\nVerifying syntax of key files...")
    compile_ok = compile_key_files()
    if not compile_ok:
        print("\n❌ Syntax verification failed")
        return 1
    
    print("\n✅ QGIS Plugin compatibility check PASSED!")
    print("The plugin should load correctly in QGIS")
    return 0

if __name__ == "__main__":
    sys.exit(main())
