#!/usr/bin/env python3
"""
Standalone Flood Diagnostic - No Dependencies
Analyzes the 80th percentile threshold issue in flood mask generation
"""

import numpy as np
from collections import deque

def simulate_flood_with_percentile(dem_array, water_level, percentile):
    """Simulate flood with specific percentile threshold for starting points"""
    
    # Create a simple DEM for testing
    valid_mask = ~np.isnan(dem_array)
    
    # Find floodable areas
    floodable_mask = valid_mask & (dem_array < water_level)
    
    if not np.any(floodable_mask):
        return 0  # No flooding possible
    
    # Get starting threshold based on percentile
    floodable_elevations = dem_array[floodable_mask]
    starting_threshold = np.percentile(floodable_elevations, percentile)
    
    # Find starting points
    start_candidates = np.where(floodable_mask & (dem_array >= starting_threshold))
    start_points = list(zip(start_candidates[0], start_candidates[1]))
    
    if not start_points:
        return 0  # No start points available
    
    # Initialize flood tracking
    flooded = np.zeros_like(dem_array, dtype=bool)
    queue = deque()
    
    # Add starting points to queue
    for row, col in start_points:
        flooded[row, col] = True
        queue.append((row, col))
    
    # 8-directional neighbors
    directions = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]
    
    # Propagate flood downhill
    iteration = 0
    max_iterations = 10000
    
    while queue and iteration < max_iterations:
        current_row, current_col = queue.popleft()
        current_elevation = dem_array[current_row, current_col]
        iteration += 1
        
        # Check all neighbors
        for dr, dc in directions:
            new_row, new_col = current_row + dr, current_col + dc
            
            # Boundary checks
            if (new_row < 0 or new_row >= dem_array.shape[0] or 
                new_col < 0 or new_col >= dem_array.shape[1]):
                continue
            
            # Skip if already processed
            if flooded[new_row, new_col] or not valid_mask[new_row, new_col]:
                continue
            
            neighbor_elevation = dem_array[new_row, new_col]
            
            # Water flows downhill
            if (neighbor_elevation <= current_elevation and 
                neighbor_elevation < water_level):
                
                flooded[new_row, new_col] = True
                queue.append((new_row, new_col))
    
    return np.sum(flooded)

def run_diagnostic():
    """Run the flood diagnostic"""
    print("FLOOD MASK DIAGNOSTIC - STANDALONE VERSION")
    print("=" * 50)
    
    # Create synthetic DEM with realistic terrain
    size = 100
    dem_array = np.ones((size, size), dtype=np.float32) * 45.0  # Base elevation 45m
    
    # Add a river valley through the middle
    center = size // 2
    for i in range(size):
        for j in range(size):
            # Create a valley that goes from NE to SW
            valley_distance = abs((i + j) - size)  # Distance from diagonal
            if valley_distance < 20:  # Within valley
                # Deeper toward the center of valley
                depth = (20 - valley_distance) * 0.3
                dem_array[i, j] = 45.0 - depth
            
            # Add some random noise for realism
            dem_array[i, j] += (np.random.random() - 0.5) * 2.0
    
    # Test with different water levels that represent intermediate timesteps
    water_levels = [40.0, 42.0, 44.0, 46.0, 48.0]  # Range from low to high flooding
    
    print(f"Synthetic DEM created: {dem_array.shape}")
    print(f"Elevation range: {np.min(dem_array):.1f}m to {np.max(dem_array):.1f}m")
    print("")
    
    print("TESTING DIFFERENT PERCENTILE THRESHOLDS:")
    print("Water Level | Bathtub | 50th% | 60th% | 70th% | 80th% | 90th%")
    print("-" * 65)
    
    for water_level in water_levels:
        # Bathtub model (reference)
        valid_mask = ~np.isnan(dem_array)
        bathtub_flooded = np.sum(valid_mask & (dem_array < water_level))
        
        # Test different percentiles
        results = []
        for percentile in [50, 60, 70, 80, 90]:
            flooded_count = simulate_flood_with_percentile(dem_array, water_level, percentile)
            results.append(flooded_count)
        
        print(f"{water_level:8.1f}m | {bathtub_flooded:6,} | {results[0]:5,} | {results[1]:5,} | {results[2]:5,} | {results[3]:5,} | {results[4]:5,}")
        
        # Identify problems
        if results[3] == 0 and bathtub_flooded > 0:  # 80th percentile gives zero flooding
            print(f"    ❌ PROBLEM: 80th percentile produces ZERO flooding!")
            print(f"       Better thresholds: 50th={results[0]:,}, 60th={results[1]:,}, 70th={results[2]:,}")
    
    print("")
    print("RECOMMENDATIONS:")
    print("1. 🔧 LOWER PERCENTILE THRESHOLD from 80th to 60th-70th")
    print("2. ⚡ ADD ADAPTIVE THRESHOLD: try 80th, then 70th, then 60th if no start points")
    print("3. 🔄 ADD FALLBACK to bathtub model when flow algorithm produces zero results")
    print("4. 🎯 USE HYBRID APPROACH: flow-based for high water levels, bathtub for low levels")

if __name__ == "__main__":
    run_diagnostic()
