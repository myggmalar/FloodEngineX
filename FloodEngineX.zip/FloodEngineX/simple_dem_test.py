#!/usr/bin/env python3
"""
Simple DEM Elevation Test
Tests basic functionality and file discovery
"""

import os
import sys
from pathlib import Path

def test_basic_functionality():
    """Test basic Python functionality"""
    print("="*60)
    print("BASIC FUNCTIONALITY TEST")
    print("="*60)
    
    try:
        import numpy as np
        print("✅ NumPy available")
        
        # Test numpy basic functionality
        test_array = np.array([1, 2, 3, 4, 5])
        print(f"   NumPy test: {test_array.mean():.1f}")
        
    except ImportError:
        print("❌ NumPy not available")
        return False
    
    try:
        from osgeo import gdal
        print("✅ GDAL available")
        
        # Test GDAL version
        print(f"   GDAL version: {gdal.VersionInfo()}")
        
    except ImportError:
        print("❌ GDAL not available")
        return False
    
    return True

def find_files():
    """Find relevant files in the workspace"""
    print("\n" + "="*60)
    print("FILE DISCOVERY")
    print("="*60)
    
    current_dir = Path(".")
    
    # Look for DEM files
    print("\n--- DEM Files ---")
    dem_extensions = ['.tif', '.tiff', '.asc', '.img']
    dem_files = []
    
    for ext in dem_extensions:
        files = list(current_dir.glob(f"*{ext}"))
        files.extend(list(current_dir.glob(f"**/*{ext}")))
        dem_files.extend(files)
    
    if dem_files:
        print(f"Found {len(dem_files)} DEM files:")
        for dem_file in dem_files[:5]:  # Show first 5
            try:
                size_mb = dem_file.stat().st_size / (1024*1024)
                print(f"  {dem_file.name} ({size_mb:.1f} MB)")
            except:
                print(f"  {dem_file.name} (size unknown)")
    else:
        print("No DEM files found")
    
    # Look for bathymetry files
    print("\n--- CSV Files (potential bathymetry) ---")
    csv_files = list(current_dir.glob("*.csv"))
    csv_files.extend(list(current_dir.glob("**/*.csv")))
    
    if csv_files:
        print(f"Found {len(csv_files)} CSV files:")
        for csv_file in csv_files[:5]:  # Show first 5
            try:
                size_kb = csv_file.stat().st_size / 1024
                print(f"  {csv_file.name} ({size_kb:.1f} KB)")
            except:
                print(f"  {csv_file.name} (size unknown)")
    else:
        print("No CSV files found")
    
    # Look for Python files
    print("\n--- Python Files ---")
    py_files = list(current_dir.glob("*.py"))
    print(f"Found {len(py_files)} Python files:")
    for py_file in py_files:
        print(f"  {py_file.name}")
    
    return dem_files, csv_files

def test_model_import():
    """Test if we can import the model functions"""
    print("\n" + "="*60)
    print("MODEL IMPORT TEST")
    print("="*60)
    
    try:
        # Add current directory to path
        sys.path.insert(0, str(Path(".").absolute()))
        
        from model_hydraulic import load_and_integrate_bathymetry_FIXED, apply_geoid_correction_only
        print("✅ Model functions imported successfully")
        
        # Test function signatures
        try:
            help_text = str(load_and_integrate_bathymetry_FIXED.__doc__)
            if help_text and "RT2000" in help_text:
                print("✅ Function contains RT2000 documentation")
            else:
                print("ℹ️  Function imported but no RT2000 docs found")
        except:
            print("ℹ️  Function imported but cannot check documentation")
            
        return True
        
    except ImportError as e:
        print(f"❌ Could not import model functions: {e}")
        return False
    except Exception as e:
        print(f"❌ Error testing model import: {e}")
        return False

def test_file_reading():
    """Test if we can read a DEM file if available"""
    print("\n" + "="*60)
    print("FILE READING TEST")
    print("="*60)
    
    dem_files, _ = find_files()
    
    if not dem_files:
        print("No DEM files to test")
        return
    
    test_file = dem_files[0]
    print(f"Testing file: {test_file}")
    
    try:
        from osgeo import gdal
        
        # Try to open with GDAL
        dataset = gdal.Open(str(test_file), gdal.GA_ReadOnly)
        
        if dataset is None:
            print(f"❌ Could not open {test_file}")
            return
        
        print("✅ File opened successfully")
        
        # Get basic info
        width = dataset.RasterXSize
        height = dataset.RasterYSize
        bands = dataset.RasterCount
        
        print(f"   Dimensions: {width} x {height}")
        print(f"   Bands: {bands}")
        
        # Get georeference info
        geotransform = dataset.GetGeoTransform()
        if geotransform:
            print(f"   Pixel size: {geotransform[1]:.2f} x {geotransform[5]:.2f}")
        
        # Try to read a small sample
        band = dataset.GetRasterBand(1)
        sample_data = band.ReadAsArray(0, 0, min(100, width), min(100, height))
        
        if sample_data is not None:
            print("✅ Sample data read successfully")
            
            # Get basic stats from sample
            import numpy as np
            valid_data = sample_data[sample_data != band.GetNoDataValue()] if band.GetNoDataValue() is not None else sample_data
            
            if len(valid_data) > 0:
                print(f"   Sample elevation range: {valid_data.min():.2f} to {valid_data.max():.2f}")
                print(f"   Sample mean: {valid_data.mean():.2f}")
                
                # Check if values look like the problematic range
                if valid_data.min() < 0 and valid_data.max() < 50:
                    print("⚠️  ALERT: Negative elevations detected - this may be the issue!")
                elif valid_data.min() > 0 and valid_data.max() > 40:
                    print("✅ Elevation values look reasonable for RT2000")
                else:
                    print("ℹ️  Elevation values unclear - need full analysis")
            else:
                print("   No valid elevation data in sample")
        else:
            print("❌ Could not read sample data")
        
        dataset = None  # Close dataset
        
    except Exception as e:
        print(f"❌ Error reading file: {e}")

if __name__ == "__main__":
    print("DEM Elevation Fix - Simple Test Suite")
    
    # Run tests
    if test_basic_functionality():
        find_files()
        test_model_import()
        test_file_reading()
    else:
        print("\nBasic functionality test failed - cannot proceed")
    
    print("\n" + "="*60)
    print("TEST COMPLETE")
    print("="*60)
