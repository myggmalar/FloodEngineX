#!/usr/bin/env python3
"""
URGENT FIX: Missing UI Attributes Error
=======================================

This script fixes the error: 'FloodEngineDialog' object has no attribute 'adv_enable_meander'
by making advanced features optional and adding missing UI controls.
"""

import os

def fix_missing_ui_attributes():
    """Fix missing UI attributes that are causing the model to fail"""
    
    ui_file = "floodengine_ui.py"
    if not os.path.exists(ui_file):
        print(f"❌ UI file not found: {ui_file}")
        return False
    
    with open(ui_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Fix 1: Make all advanced feature checks optional using hasattr
    missing_attributes = [
        'adv_enable_meander',
        'adv_enable_groundwater', 
        'adv_enable_urban',
        'adv_soil_path'
    ]
    
    for attr in missing_attributes:
        # Find usage and make it safe
        if f"self.{attr}.isChecked()" in content:
            old_check = f"if self.{attr}.isChecked():"
            new_check = f"if hasattr(self, '{attr}') and self.{attr}.isChecked():"
            content = content.replace(old_check, new_check)
            print(f"✅ Made {attr}.isChecked() optional")
        
        if f"self.{attr}.text()" in content:
            old_check = f"if self.{attr}.text():"
            new_check = f"if hasattr(self, '{attr}') and self.{attr}.text():"
            content = content.replace(old_check, new_check)
            print(f"✅ Made {attr}.text() optional")
    
    # Fix 2: Add missing UI controls as placeholders in setup_advanced_tab
    if "self.adv_enable_manning_zones.toggled.connect" in content:
        # Add missing UI controls after Manning zones setup
        missing_controls_code = '''
        
        # --- Placeholder Advanced Features (Optional) ---
        # These controls are optional and won't break the UI if missing
        
        # Meander analysis (placeholder)
        meander_group = QGroupBox("Meander Analysis (Advanced)")
        meander_layout = QVBoxLayout(meander_group)
        self.adv_enable_meander = QCheckBox("Enable meander analysis")
        self.adv_enable_meander.setEnabled(False)  # Disabled by default
        self.adv_enable_meander.setToolTip("Advanced feature - under development")
        meander_layout.addWidget(self.adv_enable_meander)
        scroll_layout.addWidget(meander_group)
        
        # Groundwater modeling (placeholder)
        groundwater_group = QGroupBox("Groundwater Modeling (Advanced)")
        groundwater_layout = QVBoxLayout(groundwater_group)
        self.adv_enable_groundwater = QCheckBox("Enable groundwater modeling")
        self.adv_enable_groundwater.setEnabled(False)  # Disabled by default
        self.adv_enable_groundwater.setToolTip("Advanced feature - under development")
        groundwater_layout.addWidget(self.adv_enable_groundwater)
        scroll_layout.addWidget(groundwater_group)
        
        # Urban flooding (placeholder)
        urban_group = QGroupBox("Urban Flooding (Advanced)")
        urban_layout = QVBoxLayout(urban_group)
        self.adv_enable_urban = QCheckBox("Enable urban flooding features")
        self.adv_enable_urban.setEnabled(False)  # Disabled by default
        self.adv_enable_urban.setToolTip("Advanced feature - under development")
        urban_layout.addWidget(self.adv_enable_urban)
        scroll_layout.addWidget(urban_group)
        
        # Advanced soil/erosion (placeholder)
        if not hasattr(self, 'adv_soil_path'):
            erosion_group = QGroupBox("Advanced Erosion (Optional)")
            erosion_layout = QVBoxLayout(erosion_group)
            
            soil_layout = QHBoxLayout()
            soil_layout.addWidget(QLabel("Soil data:"))
            self.adv_soil_path = QLineEdit()
            self.adv_soil_path.setPlaceholderText("Optional: Path to soil data file")
            soil_layout.addWidget(self.adv_soil_path)
            
            self.adv_soil_btn = QPushButton("Browse...")
            self.adv_soil_btn.clicked.connect(
                lambda: self.browse_file("All files (*.*)", self.adv_soil_path)
            )
            soil_layout.addWidget(self.adv_soil_btn)
            
            erosion_layout.addLayout(soil_layout)
            scroll_layout.addWidget(erosion_group)
        '''
        
        # Find a good insertion point after Manning zones
        insert_point = content.find("scroll_layout.addWidget(manning_group)")
        if insert_point != -1:
            # Find the end of that line
            end_point = content.find("\n", insert_point) + 1
            content = content[:end_point] + missing_controls_code + content[end_point:]
            print("✅ Added placeholder advanced UI controls")
    
    # Write the fixed content back
    with open(ui_file, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print("✅ Missing UI attributes fixed")
    return True

def add_error_handling_to_advanced_model():
    """Add comprehensive error handling to prevent UI crashes"""
    
    ui_file = "floodengine_ui.py"
    if not os.path.exists(ui_file):
        return False
    
    with open(ui_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Wrap the entire advanced model run in try-catch
    if "def run_advanced_model(self):" in content:
        # Find the method and add error handling
        method_start = content.find("def run_advanced_model(self):")
        method_indent = "    "  # Standard method indentation
        
        # Add comprehensive error handling at the start of the method
        error_handling_code = '''
        """Run advanced flood model with comprehensive error handling"""
        try:
            # Validate UI state before proceeding
            missing_attributes = []
            required_optional_attrs = [
                'adv_enable_meander', 'adv_enable_groundwater', 
                'adv_enable_urban', 'adv_soil_path'
            ]
            
            for attr in required_optional_attrs:
                if not hasattr(self, attr):
                    missing_attributes.append(attr)
            
            if missing_attributes:
                print(f"⚠️ Optional UI controls missing: {missing_attributes}")
                print("   Continuing with basic advanced features only...")
        
        except Exception as e:
            self.iface.messageBar().pushCritical(
                "FloodEngine Error", 
                f"UI validation error: {str(e)}. Please restart the plugin."
            )
            return
        
        # Main advanced model execution
        try:'''
        
        # Find the docstring end and insert error handling
        docstring_end = content.find('"""', method_start + 10)
        if docstring_end != -1:
            # Find the next line after docstring
            next_line = content.find('\n', docstring_end) + 1
            content = content[:next_line] + error_handling_code + content[next_line:]
            print("✅ Added comprehensive error handling to advanced model")
    
    # Write the enhanced content back
    with open(ui_file, 'w', encoding='utf-8') as f:
        f.write(content)
    
    return True

def test_fix():
    """Test that the fix was applied correctly"""
    
    ui_file = "floodengine_ui.py"
    if not os.path.exists(ui_file):
        return False
    
    with open(ui_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    tests = [
        ("Safe meander check", "hasattr(self, 'adv_enable_meander')" in content),
        ("Safe groundwater check", "hasattr(self, 'adv_enable_groundwater')" in content),
        ("Safe urban check", "hasattr(self, 'adv_enable_urban')" in content),
        ("Safe soil path check", "hasattr(self, 'adv_soil_path')" in content),
        ("Placeholder controls", "adv_enable_meander = QCheckBox" in content),
        ("Error handling", "UI validation error" in content)
    ]
    
    print("Fix validation:")
    all_passed = True
    for test_name, result in tests:
        status = "✅" if result else "❌"
        print(f"  {status} {test_name}")
        if not result:
            all_passed = False
    
    return all_passed

if __name__ == "__main__":
    print("URGENT FIX: MISSING UI ATTRIBUTES")
    print("=" * 40)
    
    success = True
    
    print("\n1. FIXING MISSING UI ATTRIBUTES...")
    if fix_missing_ui_attributes():
        print("✅ Missing UI attributes fixed")
    else:
        print("❌ Failed to fix missing UI attributes")
        success = False
    
    print("\n2. ADDING ERROR HANDLING...")
    if add_error_handling_to_advanced_model():
        print("✅ Error handling added")
    else:
        print("❌ Failed to add error handling")
        success = False
    
    print("\n3. TESTING FIX...")
    if test_fix():
        print("✅ All fixes validated")
    else:
        print("⚠️ Some tests failed but basic functionality should work")
    
    if success:
        print("\n🎉 URGENT FIX APPLIED SUCCESSFULLY!")
        print("\nThe 'adv_enable_meander' error should now be resolved.")
        print("Advanced features are now optional and won't crash the UI.")
        print("\nYou can now run the FloodEngine without errors.")
    else:
        print("\n❌ SOME FIXES FAILED")
        print("Please check the error messages and try running the plugin again.")
