"""
Integration module for Time Series Animation with FloodEngine
------------------------------------------------------------
Connects the Saint-Venant solver results with time series animation
and interactive visualization capabilities.
"""

import os
import logging
from pathlib import Path

logger = logging.getLogger("FloodEngine.TimeSeriesIntegration")

def integrate_time_series_animation(results_data, output_folder):
    """
    Main integration function to set up time series animation.
    
    Parameters:
        results_data (dict): Saint-Venant simulation results containing:
            - times: list of timestamps
            - water_depths: list of depth arrays for each timestep
            - velocity_x: list of x-velocity arrays
            - velocity_y: list of y-velocity arrays
            - dem_array: DEM elevation data
            - geotransform: GDAL geotransform tuple
        output_folder (str): Path to output folder
        
    Returns:
        dict: Animation setup results
    """
    logger.info("🎬 Integrating time series animation with FloodEngine results...")
    
    try:
        # Validate input data
        if not validate_results_data(results_data):
            raise ValueError("Invalid results data for time series animation")
        
        # Create output directory structure
        setup_output_structure(output_folder)
        
        # Create time series raster files
        raster_files = create_animation_rasters(results_data, output_folder)
        
        # Set up QGIS integration (if available)
        animation_info = setup_qgis_integration(results_data, output_folder)
        
        # Create usage instructions
        create_usage_instructions(output_folder, results_data)
        
        # Create animation summary
        summary = create_animation_summary(results_data, output_folder)
        
        logger.info("✅ Time series animation integration completed successfully!")
        
        return {
            'success': True,
            'output_folder': output_folder,
            'num_timesteps': len(results_data.get('times', [])),
            'animation_info': animation_info,
            'instructions_file': os.path.join(output_folder, 'ANIMATION_INSTRUCTIONS.md'),
            'raster_files': raster_files,
            'summary': summary
        }
        
    except Exception as e:
        logger.error(f"❌ Failed to integrate time series animation: {e}")
        return {
            'success': False,
            'error': str(e)
        }

def validate_results_data(results_data):
    """Validate that results data contains required components."""
    required_keys = ['times', 'water_depths']
    
    for key in required_keys:
        if key not in results_data:
            logger.error(f"Missing required key: {key}")
            return False
    
    times = results_data['times']
    depths = results_data['water_depths']
    
    if len(times) != len(depths):
        logger.error(f"Mismatch in number of timesteps: {len(times)} times vs {len(depths)} depth arrays")
        return False
    
    if len(times) < 2:
        logger.warning("Less than 2 timesteps available - animation will be limited")
    
    logger.info(f"✅ Results data validation passed: {len(times)} timesteps")
    return True

def setup_output_structure(output_folder):
    """Create organized output directory structure."""
    Path(output_folder).mkdir(parents=True, exist_ok=True)
    
    # Create subdirectories
    subdirs = ['rasters', 'animations', 'exports']
    for subdir in subdirs:
        Path(output_folder, subdir).mkdir(exist_ok=True)
    
    logger.info(f"📁 Output structure created in: {output_folder}")

def create_animation_rasters(results_data, output_folder):
    """Create individual raster files for each timestep."""
    logger.info("🗺️ Creating time series raster files...")
    
    raster_folder = os.path.join(output_folder, 'rasters')
    times = results_data['times']
    water_depths = results_data['water_depths']
    dem_array = results_data.get('dem_array')
    geotransform = results_data.get('geotransform')
    projection = results_data.get('projection', '')  # Get projection from results
    
    # Get velocity data if available
    velocity_x = results_data.get('velocity_x', [])
    velocity_y = results_data.get('velocity_y', [])
    
    created_files = []
    
    logger.info(f"Creating rasters for {len(times)} timesteps...")
    logger.info(f"Time range: {times[0]:.1f}s to {times[-1]:.1f}s")
    
    for i, (timestamp, depth_array) in enumerate(zip(times, water_depths)):
        # Create depth raster
        depth_filename = f"flood_depth_t{i:04d}_{timestamp:.1f}s.tif"
        depth_path = os.path.join(raster_folder, depth_filename)
        
        if _save_array_to_raster(depth_array, depth_path, geotransform, projection):
            created_files.append(depth_path)
            logger.debug(f"Created depth raster: {depth_filename}")
        
        # Create water surface raster (DEM + depth)
        if dem_array is not None:
            surface_array = dem_array + depth_array
            surface_filename = f"water_surface_t{i:04d}_{timestamp:.1f}s.tif"
            surface_path = os.path.join(raster_folder, surface_filename)
            
            if _save_array_to_raster(surface_array, surface_path, geotransform, projection):
                created_files.append(surface_path)
                logger.debug(f"Created surface raster: {surface_filename}")
        
        # Create velocity magnitude raster if velocity components are available
        if i < len(velocity_x) and i < len(velocity_y):
            import numpy as np
            velocity_mag = np.sqrt(velocity_x[i]**2 + velocity_y[i]**2)
            
            velocity_filename = f"flood_velocity_t{i:04d}_{timestamp:.1f}s.tif"
            velocity_path = os.path.join(raster_folder, velocity_filename)
            
            if _save_array_to_raster(velocity_mag, velocity_path, geotransform, projection):
                created_files.append(velocity_path)
                logger.debug(f"Created velocity raster: {velocity_filename}")
    
    logger.info(f"✅ Created {len(created_files)} time series raster files")
    return created_files

def _save_array_to_raster(data_array, output_path, geotransform, projection=None, nodata=-9999):
    """Save numpy array as GeoTIFF raster file."""
    try:
        from osgeo import gdal
        import numpy as np
        
        # Handle NaN values
        data_array = np.where(np.isnan(data_array), nodata, data_array)
        
        # Create output dataset
        driver = gdal.GetDriverByName('GTiff')
        rows, cols = data_array.shape
        
        dataset = driver.Create(output_path, cols, rows, 1, gdal.GDT_Float32,
                              ['COMPRESS=LZW', 'TILED=YES'])
        
        if dataset is None:
            logger.error(f"Could not create output file: {output_path}")
            return False
        
        # Set geospatial information
        if geotransform:
            dataset.SetGeoTransform(geotransform)
        
        # Set projection - use provided projection or reasonable default
        if projection:
            dataset.SetProjection(projection)
        else:
            # Default to WGS84 Geographic
            srs_wkt = '''GEOGCS["WGS 84",DATUM["WGS_1984",SPHEROID["WGS 84",6378137,298.257223563]],PRIMEM["Greenwich",0],UNIT["degree",0.0174532925199433]]'''
            dataset.SetProjection(srs_wkt)
        
        # Write data
        band = dataset.GetRasterBand(1)
        band.WriteArray(data_array)
        band.SetNoDataValue(nodata)
        band.ComputeStatistics(0)
        
        # Clean up
        band = None
        dataset = None
        
        return True
        
    except ImportError:
        logger.warning("GDAL not available - cannot create raster files")
        return False
    except Exception as e:
        logger.error(f"Error saving raster {output_path}: {e}")
        return False

def setup_qgis_integration(results_data, output_folder):
    """Set up QGIS integration if available."""
    try:
        # Try to import QGIS modules
        from qgis.utils import iface
        from map_canvas_time_series import setup_time_series_animation
        
        # Set up the animation system
        controller, dock, control_panel = setup_time_series_animation(results_data, output_folder)
        
        logger.info("✅ QGIS integration set up successfully")
        
        return {
            'qgis_available': True,
            'controller': controller,
            'dock_widget': dock,
            'control_panel': control_panel
        }
        
    except ImportError:
        logger.info("ℹ️ QGIS not available - creating standalone instructions")
        return {
            'qgis_available': False,
            'message': 'QGIS integration not available in current environment'
        }
    except Exception as e:
        logger.warning(f"QGIS integration failed: {e}")
        return {
            'qgis_available': False,
            'error': str(e)
        }

def create_usage_instructions(output_folder, results_data):
    """Create detailed usage instructions for the time series animation."""
    instructions_file = os.path.join(output_folder, 'ANIMATION_INSTRUCTIONS.md')
    
    times = results_data['times']
    num_timesteps = len(times)
    total_time = max(times) if times else 0
    
    instructions = f"""# FloodEngine Time Series Animation Instructions

## Overview
This folder contains time series animation data for your flood simulation with {num_timesteps} timesteps covering {total_time:.1f} seconds.

## Files Created

### Raster Files (`rasters/` folder)
- `flood_depth_tXXXX_YYYs.tif` - Water depth at each timestep
- `water_surface_tXXXX_YYYs.tif` - Water surface elevation (DEM + depth)
- `flood_velocity_tXXXX_YYYs.tif` - Flow velocity magnitude (if available)

Where XXXX is the timestep number (0000-{num_timesteps-1:04d}) and YYY is the time in seconds.

## Using the Animation in QGIS

### Method 1: Automatic Setup (Recommended)
If you're running this from within QGIS with the FloodEngine plugin:

1. **Time Series Panel**: Look for the "FloodEngine Time Series" dock panel on the right side
2. **Play Controls**: Use the ▶️ Play button to start animation
3. **Speed Control**: Adjust animation speed (0.1-10 fps)
4. **Timeline**: Drag the slider to jump to specific timesteps
5. **Point Sampling**: Enable "📍 Point Sampling" and click on the map to see data

### Method 2: Manual Setup
If the automatic setup didn't work:

1. **Load Rasters**: 
   - Go to Layer → Add Layer → Add Raster Layer
   - Navigate to the `rasters/` folder
   - Select all the raster files (Ctrl+A or Cmd+A)
   - Click Open

2. **Organize Layers**:
   - Group layers by type (depth, surface, velocity)
   - Initially hide all layers except the first timestep (t0000)

3. **Create Animation**:
   - Install the "Temporal Controller" plugin if not available
   - Or manually toggle layer visibility to create animation

### Interactive Features

#### Point Information with RH2000 Coordinates
When point sampling is enabled:

- **Click anywhere on the map** to see:
  - Map coordinates (current projection)
  - RH2000 coordinates (EPSG:3006)
  - Water depth at that point
  - Water surface elevation in RH2000
  - DEM elevation
  - Flow velocity (if available)
  - Complete time series for that location

#### Time Series Display
- View how depth and velocity change over time at any point
- See maximum values during the entire simulation
- Export time series data for further analysis

## Animation Controls

### Playback
- **▶️ Play/⏸️ Pause**: Start/stop animation
- **⏹️ Stop**: Stop and return to first timestep
- **Timeline Slider**: Manually navigate through timesteps

### Settings
- **Speed Control**: 0.1 to 10 frames per second
- **Loop Animation**: Automatically restart when reaching the end
- **Auto-hide Layers**: Only show current timestep layers

## Data Values

### Water Depth
- Units: meters
- Range: 0.01m (minimum displayed) to maximum flood depth
- Color scheme: White (no water) → Blue (deep water)

### Water Surface Elevation
- Units: meters above RH2000 datum (EPSG:3006)
- Calculated as: DEM elevation + Water depth
- Useful for understanding flood levels relative to Swedish elevation system

### Flow Velocity
- Units: meters per second
- Color scheme: Transparent (low) → Red (high velocity)
- Maximum values capped at realistic flood velocities (≤ 5 m/s)

## Timestep Information

| Timestep | Time (s) | Description |
|----------|----------|-------------|"""

    # Add timestep table
    for i, timestamp in enumerate(times[:10]):  # Show first 10 timesteps
        instructions += f"\n| {i+1:4d} | {timestamp:8.1f} | Timestep {i+1} |"
    
    if len(times) > 10:
        instructions += f"\n| ...  | ...      | ... ({len(times)-10} more timesteps) |"

    instructions += f"""

## Technical Details

### Coordinate Systems
- **Input Data**: Based on your DEM coordinate system
- **RH2000**: Swedish national elevation system (EPSG:3006)
- **Automatic Transform**: Coordinates are automatically converted for display

### File Formats
- **Rasters**: GeoTIFF format with LZW compression
- **Projection**: WGS84 Geographic (or original DEM projection)
- **NoData Value**: -9999

### Performance Tips
1. **Large Datasets**: Consider reducing animation speed for smoother playback
2. **Memory Usage**: Close unused timestep layers to free memory
3. **Export**: Use QGIS's "Export Map" to create animation frames

## Troubleshooting

### Animation Not Working
1. Check that all raster files loaded successfully
2. Verify layer visibility settings
3. Try manual layer toggling first

### Point Sampling Issues
1. Ensure "Point Sampling" is enabled
2. Click directly on flooded areas
3. Check that coordinate systems are properly set

### Performance Issues
1. Reduce animation speed
2. Close other applications
3. Consider processing smaller area or fewer timesteps

## Advanced Usage

### Export Animation Frames
1. Set up desired map extent and styling
2. Use QGIS's "Export Map" feature
3. Create frame for each timestep
4. Combine frames into video using external software

### Time Series Analysis
1. Enable point sampling
2. Click on points of interest
3. Copy time series data from info panel
4. Import into spreadsheet or analysis software

### Custom Styling
1. Right-click on layers → Properties
2. Modify color ramps and value ranges
3. Save styles for consistent appearance

## Getting Help

For issues or questions:
1. Check FloodEngine documentation
2. Verify QGIS plugin installation
3. Contact support with specific error messages

---
*Generated by FloodEngine v1.0 - Time Series Animation System*
*Data covers {total_time:.1f} seconds with {num_timesteps} timesteps*
"""

    with open(instructions_file, 'w', encoding='utf-8') as f:
        f.write(instructions)
    
    logger.info(f"📖 Created animation instructions: {instructions_file}")

def create_animation_summary(results_data, output_folder):
    """Create a summary of the animation setup."""
    summary = {
        'timesteps': len(results_data.get('times', [])),
        'total_time': max(results_data.get('times', [0])),
        'has_velocity': len(results_data.get('velocity_x', [])) > 0,
        'has_dem': results_data.get('dem_array') is not None,
        'output_folder': output_folder,
        'raster_files': len([f for f in os.listdir(os.path.join(output_folder, 'rasters')) if f.endswith('.tif')]) if os.path.exists(os.path.join(output_folder, 'rasters')) else 0
    }
    
    logger.info("📊 Animation Summary:")
    logger.info(f"  • Timesteps: {summary['timesteps']}")
    logger.info(f"  • Total Time: {summary['total_time']:.1f} seconds")
    logger.info(f"  • Velocity Data: {'Yes' if summary['has_velocity'] else 'No'}")
    logger.info(f"  • DEM Data: {'Yes' if summary['has_dem'] else 'No'}")
    logger.info(f"  • Raster Files: {summary['raster_files']}")
    
    return summary

# Integration with Saint-Venant solver
def enhance_saint_venant_with_animation(simulate_function):
    """
    Decorator to enhance Saint-Venant simulation with automatic animation setup.
    
    Usage:
        @enhance_saint_venant_with_animation
        def simulate_saint_venant_2d(...):
            # existing simulation code
            return results
    """
    def wrapper(*args, **kwargs):
        # Run original simulation
        results = simulate_function(*args, **kwargs)
        
        # Extract output folder from arguments
        output_folder = None
        if len(args) >= 3:
            output_folder = args[2]  # Assuming 3rd argument is output_folder
        elif 'output_folder' in kwargs:
            output_folder = kwargs['output_folder']
        
        if output_folder and results:
            # Set up animation automatically
            animation_folder = os.path.join(output_folder, 'time_series_animation')
            integration_result = integrate_time_series_animation(results, animation_folder)
            
            # Add animation info to results
            results['animation_setup'] = integration_result
        
        return results
    
    return wrapper
