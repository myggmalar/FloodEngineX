"""
Quick test script for QGIS Python Console
==========================================

Run this in the QGIS Python Console to test the FloodEngine fix:

1. Open QGIS
2. Go to Plugins > Python Console  
3. Copy and paste this code
4. Run it to test the gdal.Open() fix

This will simulate the bathymetry integration workflow that was causing the error.
"""

def test_floodengine_gdal_fix():
    """Test the FloodEngine gdal.Open() path fix"""
    
    print("🧪 Testing FloodEngine gdal.Open() fix...")
    
    try:
        # Test import
        import sys
        import os
        
        # Add plugin path
        plugin_path = r"c:\Users\david\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\FloodEngine_fixed_v8"
        if plugin_path not in sys.path:
            sys.path.insert(0, plugin_path)
        
        # Import the fixed module
        from model_hydraulic import load_and_integrate_bathymetry, create_proper_geotiff
        
        print("✅ Successfully imported fixed model_hydraulic module")
        
        # Test that the functions exist and have the right signatures
        if hasattr(load_and_integrate_bathymetry, '__call__'):
            print("✅ load_and_integrate_bathymetry function available")
        
        if hasattr(create_proper_geotiff, '__call__'):
            print("✅ create_proper_geotiff function available")
        
        # Check if the function returns paths instead of boolean
        import inspect
        source = inspect.getsource(create_proper_geotiff)
        
        if "return output_path" in source:
            print("✅ create_proper_geotiff returns file paths (FIXED)")
        else:
            print("❌ create_proper_geotiff still returns boolean")
        
        if "isinstance(data, np.ndarray)" in source:
            print("✅ Enhanced input validation implemented")
        
        if "FlushCache()" in source:
            print("✅ Proper data flushing implemented")
        
        print("\n🎉 FloodEngine fix verification complete!")
        print("The gdal.Open() path error should now be resolved.")
        
        return True
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        print("Make sure the FloodEngine plugin is properly installed")
        return False
        
    except Exception as e:
        print(f"❌ Test error: {e}")
        return False

def test_bathymetry_workflow_simulation():
    """Simulate the bathymetry workflow that was causing the None path issue"""
    
    print("\n🔄 Simulating bathymetry workflow...")
    
    try:
        # Simulate the problematic workflow
        original_dem_path = "c:/test/original_dem.tif"
        
        # Simulate bathymetry_result scenarios that were causing None paths
        test_scenarios = [
            {"combined_dem": None, "status": "success"},
            {"status": "success"},  # Missing combined_dem key
            {"combined_dem": "", "status": "success"},
            {"combined_dem": "c:/nonexistent/file.tif", "status": "success"}
        ]
        
        for i, bathymetry_result in enumerate(test_scenarios, 1):
            print(f"\nScenario {i}: {bathymetry_result}")
            
            # This is the FIXED logic
            new_dem_path = bathymetry_result.get('combined_dem', original_dem_path)
            
            if new_dem_path and os.path.exists(new_dem_path):
                working_dem_path = new_dem_path
                print(f"  ✅ Would use combined DEM: {working_dem_path}")
            else:
                working_dem_path = original_dem_path
                print(f"  ✅ Using original DEM: {working_dem_path}")
            
            # Critical check - this should NEVER be None now
            if working_dem_path is None:
                print(f"  ❌ CRITICAL: working_dem_path is None!")
                return False
            else:
                print(f"  ✅ working_dem_path is safe: {type(working_dem_path)}")
        
        print("\n✅ All scenarios handled safely - no None paths!")
        return True
        
    except Exception as e:
        print(f"❌ Simulation error: {e}")
        return False

def run_complete_test():
    """Run the complete FloodEngine fix test"""
    
    print("=" * 80)
    print("FLOODENGINE GDAL.OPEN() FIX TEST")
    print("=" * 80)
    
    test1 = test_floodengine_gdal_fix()
    test2 = test_bathymetry_workflow_simulation()
    
    print("\n" + "=" * 80)
    print("TEST SUMMARY")
    print("=" * 80)
    
    if test1 and test2:
        print("🎉 ALL TESTS PASSED!")
        print("✅ The FloodEngine gdal.Open() error should be fixed")
        print("✅ Ready to test real flood calculations")
    else:
        print("❌ Some tests failed - check the implementation")
    
    print("=" * 80)

# Run the test
run_complete_test()
