#!/usr/bin/env python3
"""
Test Animation Dialog - Shows immediately
========================================
"""

import sys
import os
import numpy as np
from pathlib import Path

# Add FloodEngineX to path
sys.path.insert(0, str(Path(__file__).parent))

def test_animation_dialog():
    """Test animation dialog with synthetic data."""
    print("🧪 Testing animation dialog...")
    
    try:
        # Import Qt
        from PyQt5.QtWidgets import QApplication
        from time_series_animator import TimeSeriesAnimator
        
        # Create synthetic test data
        print("📊 Creating test data...")
        test_data = create_test_data()
        
        # Create QApplication
        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)
        
        # Create animation dialog
        print("🎬 Launching animation dialog...")
        animator = TimeSeriesAnimator(test_data, "test_output")
        animator.setWindowTitle("FloodEngine Animation Test")
        animator.show()
        animator.raise_()
        animator.activateWindow()
        
        print("✅ Dialog should be visible now!")
        print("🎮 Test the controls:")
        print("   • Click Play to start animation")
        print("   • Drag timeline slider")
        print("   • Try step forward/backward")
        
        # Run application
        sys.exit(app.exec_())
        
    except ImportError:
        print("❌ PyQt5 not available")
        print("💡 Install with: pip install PyQt5")
        
    except Exception as e:
        print(f"❌ Test failed: {e}")

def create_test_data():
    """Create minimal test data for animation."""
    # Simple test data
    size = 20
    timesteps = 10
    
    times = [i * 5.0 for i in range(timesteps)]
    depths = []
    
    for t in range(timesteps):
        depth = np.zeros((size, size))
        # Create expanding flood
        center = size // 2
        radius = min(t + 1, size // 2)
        
        for i in range(size):
            for j in range(size):
                dist = ((i - center)**2 + (j - center)**2)**0.5
                if dist <= radius:
                    depth[i, j] = max(0, 1.0 - dist/radius)
        
        depths.append(depth)
    
    return {
        'times': times,
        'water_depths': depths,
        'velocity_x': [np.zeros((size, size)) for _ in range(timesteps)],
        'velocity_y': [np.zeros((size, size)) for _ in range(timesteps)],
        'dem_array': np.random.random((size, size)) * 10,
        'geotransform': (0, 1, 0, size, 0, -1)
    }

if __name__ == "__main__":
    test_animation_dialog()
