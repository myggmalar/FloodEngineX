#!/usr/bin/env python3
"""
FloodEngine v4.0 - Current Deployment Verification
==================================================

Verifies that the plugin is ready for immediate deployment and use.
Run this before distributing to end users.
"""

import os
import sys
import zipfile
from pathlib import Path
import json

def verify_production_package():
    """Verify the production package is complete and valid"""
    print("📦 Verifying Production Package...")
    print("-" * 40)
    
    current_dir = Path(__file__).parent
    package_path = current_dir / "FloodEngine_v4.0_Production.zip"
    
    if not package_path.exists():
        print("❌ Production package not found!")
        return False
    
    # Check package size
    size_mb = package_path.stat().st_size / (1024 * 1024)
    print(f"✅ Package exists: {size_mb:.1f} MB")
    
    # Verify package contents
    try:
        with zipfile.ZipFile(package_path, 'r') as zip_file:
            files = zip_file.namelist()
            
            essential_files = [
                '__init__.py',
                'floodengine.py',
                'floodengine_ui.py',
                'metadata.txt',
                'icon.png',
                'model_hydraulic.py',
                'saint_venant_2d_fixed.py',
                'enhanced_streamlines.py'
            ]
            
            missing_files = []
            for file in essential_files:
                if not any(f.endswith(file) for f in files):
                    missing_files.append(file)
                else:
                    print(f"  ✅ {file}")
            
            if missing_files:
                print(f"❌ Missing files in package: {missing_files}")
                return False
            
            print(f"✅ Package contains {len(files)} files")
            return True
            
    except Exception as e:
        print(f"❌ Error reading package: {e}")
        return False

def verify_metadata():
    """Verify plugin metadata is correct"""
    print("\n📋 Verifying Plugin Metadata...")
    print("-" * 40)
    
    metadata_path = Path(__file__).parent / "metadata.txt"
    
    if not metadata_path.exists():
        print("❌ metadata.txt not found!")
        return False
    
    try:
        with open(metadata_path, 'r', encoding='utf-8') as f:
            content = f.read()
            
        # Check essential metadata fields
        required_fields = [
            'name=FloodEngine',
            'version=4.0',
            'qgisMinimumVersion=3.0',
            'description=',
            'author=',
            'email='
        ]
        
        for field in required_fields:
            if field in content:
                print(f"  ✅ {field.split('=')[0]}")
            else:
                print(f"  ❌ Missing: {field}")
                return False
        
        return True
        
    except Exception as e:
        print(f"❌ Error reading metadata: {e}")
        return False

def verify_core_functionality():
    """Test basic functionality without QGIS dependencies"""
    print("\n🔧 Verifying Core Functionality...")
    print("-" * 40)
    
    current_dir = Path(__file__).parent
    sys.path.insert(0, str(current_dir))
    
    try:
        # Test core imports (without QGIS dependencies)
        print("  Testing module imports...")
        
        # Test model_hydraulic
        import model_hydraulic
        if hasattr(model_hydraulic, 'safe_csv_value_conversion'):
            print("  ✅ CSV safety functions available")
        else:
            print("  ❌ CSV safety functions missing")
            return False
        
        # Test Saint-Venant solver
        import saint_venant_2d_fixed
        if hasattr(saint_venant_2d_fixed, 'SaintVenant2D'):
            print("  ✅ Saint-Venant 2D solver available")
        else:
            print("  ❌ Saint-Venant 2D solver missing")
            return False
        
        # Test enhanced streamlines
        import enhanced_streamlines
        print("  ✅ Enhanced streamlines module available")
        
        print("  ✅ All core modules functional")
        return True
        
    except ImportError as e:
        print(f"  ❌ Import error: {e}")
        return False
    except Exception as e:
        print(f"  ❌ Functionality test error: {e}")
        return False

def verify_documentation():
    """Verify documentation files are present"""
    print("\n📚 Verifying Documentation...")
    print("-" * 40)
    
    current_dir = Path(__file__).parent
    
    doc_files = [
        ('USER_GUIDE.md', 'User Guide'),
        ('DEPLOYMENT_GUIDE.md', 'Deployment Guide'),
        ('PRODUCTION_VALIDATION_REPORT.md', 'Validation Report'),
        ('CONTINUATION_STATUS_JUNE_2025.md', 'Current Status')
    ]
    
    all_present = True
    for filename, description in doc_files:
        file_path = current_dir / filename
        if file_path.exists():
            size_kb = file_path.stat().st_size / 1024
            print(f"  ✅ {description}: {size_kb:.1f} KB")
        else:
            print(f"  ❌ Missing: {description}")
            all_present = False
    
    return all_present

def create_deployment_checklist():
    """Create a deployment checklist for end users"""
    checklist_content = """# FloodEngine v4.0 - Deployment Checklist
===============================================

## Pre-Deployment Verification ✅

- [ ] Production package exists and is complete
- [ ] All essential files are included
- [ ] Metadata is correct and up-to-date
- [ ] Core functionality tests pass
- [ ] Documentation is available and current

## Installation Instructions

### For End Users:
1. Extract FloodEngine_v4.0_Production.zip
2. Copy extracted folder to QGIS plugins directory
3. Restart QGIS
4. Enable plugin in Plugin Manager
5. Access via Plugins > FloodEngine menu

### System Requirements:
- QGIS 3.0 or later
- Python 3.7+
- 4GB+ RAM (8GB+ recommended)
- Available disk space for output files

## Quick Test Procedure

### After Installation:
1. Open QGIS
2. Look for FloodEngine in Plugins menu
3. Open FloodEngine dialog
4. Verify "2D Shallow Water" model is available
5. Check that file browsers work for DEM selection

### First Simulation:
1. Use small test DEM (< 1MB)
2. Set simple parameters:
   - Water level: 10.0m
   - Time steps: 10
   - Simulation time: 300s
3. Run simulation
4. Verify output layers are created

## Troubleshooting

### Plugin Won't Load:
- Check QGIS version compatibility
- Verify folder is in correct plugins directory
- Restart QGIS after installation

### Simulation Errors:
- Verify DEM file is accessible
- Check coordinate system is projected (not geographic)
- Ensure output directory is writable

## Support Resources

- User Guide: USER_GUIDE.md
- Deployment Guide: DEPLOYMENT_GUIDE.md
- Technical Documentation: Available in plugin folder

---
Generated: June 7, 2025
Status: Ready for Production Deployment
"""
    
    checklist_path = Path(__file__).parent / "DEPLOYMENT_CHECKLIST.md"
    with open(checklist_path, 'w', encoding='utf-8') as f:
        f.write(checklist_content)
    
    print(f"\n📋 Deployment checklist created: {checklist_path}")

def main():
    """Main verification function"""
    print("FloodEngine v4.0 - Deployment Verification")
    print("=" * 60)
    print("Date: June 7, 2025")
    print("=" * 60)
    
    # Run all verification tests
    tests = [
        ("Production Package", verify_production_package),
        ("Plugin Metadata", verify_metadata),
        ("Core Functionality", verify_core_functionality),
        ("Documentation", verify_documentation)
    ]
    
    results = []
    for test_name, test_func in tests:
        result = test_func()
        results.append((test_name, result))
    
    # Create deployment checklist
    create_deployment_checklist()
    
    # Summary
    print("\n" + "=" * 60)
    print("DEPLOYMENT VERIFICATION SUMMARY")
    print("=" * 60)
    
    passed = 0
    total = len(results)
    
    for test_name, result in results:
        status = "PASS" if result else "FAIL"
        print(f"  {test_name}: {status}")
        if result:
            passed += 1
    
    print(f"\nResults: {passed}/{total} verifications passed")
    
    if passed == total:
        print("\n🎉 DEPLOYMENT VERIFICATION SUCCESSFUL")
        print("   ✅ Plugin is ready for production deployment")
        print("   ✅ All systems validated and functional")
        print("   ✅ Documentation complete and current")
        print("\n📦 Ready to distribute FloodEngine_v4.0_Production.zip")
        return True
    else:
        print(f"\n⚠️  DEPLOYMENT VERIFICATION INCOMPLETE")
        print(f"   {total-passed} verification(s) failed")
        print("   Plugin needs attention before deployment")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
