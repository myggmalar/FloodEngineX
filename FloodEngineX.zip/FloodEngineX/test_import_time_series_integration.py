#!/usr/bin/env python3
"""Test import of time_series_integration module to find the exact error."""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_time_series_integration_import():
    """Test if we can import the time_series_integration module."""
    print("🔍 Testing time_series_integration import...")
    
    try:
        print("📦 Attempting import...")
        from time_series_integration import integrate_time_series_animation
        print("✅ Import successful!")
        print(f"📋 Function: {integrate_time_series_animation}")
        return True
        
    except ImportError as e:
        print(f"❌ ImportError: {e}")
        return False
    except Exception as e:
        print(f"❌ Other error: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_time_series_integration_import()
    print(f"\n{'✅ IMPORT TEST PASSED' if success else '❌ IMPORT TEST FAILED'}")
    
    if not success:
        print("\n🔍 Troubleshooting:")
        print("1. Check if file exists")
        print("2. Check for syntax errors in time_series_integration.py")
        print("3. Check for missing dependencies")
        
        # Try to check if file exists
        import os
        file_path = os.path.join(os.path.dirname(__file__), "time_series_integration.py")
        print(f"📁 File exists: {os.path.exists(file_path)}")
        if os.path.exists(file_path):
            print(f"📊 File size: {os.path.getsize(file_path)} bytes")
