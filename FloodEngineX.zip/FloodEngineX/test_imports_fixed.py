"""
Test if all modules can be imported without indentation errors
"""
import sys
print("Starting import tests...")
print(f"Python version: {sys.version}")
print(f"Current directory: {__file__}")

try:
    print("Testing floodengine_ui...")
    import floodengine_ui
    print("✅ floodengine_ui imported successfully")
except IndentationError as e:
    print(f"❌ IndentationError in floodengine_ui: {e}")
    print(f"  Line {e.lineno}, {e.msg}")
except ImportError as e:
    print(f"❌ ImportError in floodengine_ui: {e}")
except Exception as e:
    print(f"❌ Error importing floodengine_ui: {e}")

try:
    print("\nTesting floodengine...")
    import floodengine
    print("✅ floodengine imported successfully")
except IndentationError as e:
    print(f"❌ IndentationError in floodengine: {e}")
    print(f"  Line {e.lineno}, {e.msg}")
except ImportError as e:
    print(f"❌ ImportError in floodengine: {e}")
except Exception as e:
    print(f"❌ Error importing floodengine: {e}")

try:
    print("\nTesting model_hydraulic...")
    import model_hydraulic
    print("✅ model_hydraulic imported successfully")
except IndentationError as e:
    print(f"❌ IndentationError in model_hydraulic: {e}")
    print(f"  Line {e.lineno}, {e.msg}")
except ImportError as e:
    print(f"❌ ImportError in model_hydraulic: {e}")
except Exception as e:
    print(f"❌ Error importing model_hydraulic: {e}")

try:
    print("\nTesting flow_direction_flood_fixed...")
    import flow_direction_flood_fixed
    print("✅ flow_direction_flood_fixed imported successfully")
except IndentationError as e:
    print(f"❌ IndentationError in flow_direction_flood_fixed: {e}")
    print(f"  Line {e.lineno}, {e.msg}")
except ImportError as e:
    print(f"❌ ImportError in flow_direction_flood_fixed: {e}")
except Exception as e:
    print(f"❌ Error importing flow_direction_flood_fixed: {e}")

print("\nImport tests complete!")
