#!/usr/bin/env python3
"""
FloodEngine Core Functionality Validation Test
==============================================

This script tests the core hydraulic modeling functions to ensure
they work properly after the critical fixes.

Usage:
    python core_functionality_test.py

Requirements:
    - NumPy
    - GDAL (optional, will use mock if not available)
    - Matplotlib (optional)
"""

import os
import sys
import numpy as np
import warnings
warnings.filterwarnings('ignore')

def create_mock_gdal():
    """Create mock GDAL classes for testing without GDAL installation"""
    class MockDataset:
        def __init__(self, array, geotransform=None, projection=None):
            self.array = array
            self._geotransform = geotransform or (0, 1, 0, 0, 0, -1)
            self._projection = projection or ""
            self._band = MockBand(array)
            
        def GetGeoTransform(self):
            return self._geotransform
            
        def GetProjection(self):
            return self._projection
            
        def GetRasterBand(self, band_num):
            return self._band
            
        @property
        def RasterXSize(self):
            return self.array.shape[1]
            
        @property
        def RasterYSize(self):
            return self.array.shape[0]
    
    class MockBand:
        def __init__(self, array):
            self.array = array
            
        def ReadAsArray(self):
            return self.array.copy()
            
        def GetNoDataValue(self):
            return -9999
            
        def WriteArray(self, data):
            pass
            
        def SetNoDataValue(self, value):
            pass
    
    class MockDriver:
        def Create(self, path, xsize, ysize, bands, datatype):
            return MockDataset(np.zeros((ysize, xsize)))
            
        def CreateDataSource(self, path):
            return MockDataSource()
    
    class MockDataSource:
        def CreateLayer(self, name, srs=None, geom_type=None):
            return MockLayer()
    
    class MockLayer:
        def GetLayerDefn(self):
            return MockLayerDefn()
            
        def CreateFeature(self, feature):
            pass
            
        def ResetReading(self):
            pass
            
        def __iter__(self):
            return iter([])
    
    class MockLayerDefn:
        pass
    
    class MockGDAL:
        GDT_Float32 = 6
        
        @staticmethod
        def Open(path):
            # Create a simple DEM for testing
            size = 100
            x, y = np.meshgrid(np.arange(size), np.arange(size))
            # Create a simple terrain with a valley in the middle
            dem = 100 + 10 * np.sin(x/10) + 5 * np.sin(y/15) - (x-50)**2/1000 - (y-50)**2/1000
            return MockDataset(dem.astype(np.float32))
        
        @staticmethod
        def GetDriverByName(name):
            return MockDriver()
        
        @staticmethod
        def DEMProcessing(output_path, input_path, processing_type):
            # Mock slope calculation
            return 0
    
    class MockOGR:
        wkbPoint = 1
        wkbPolygon = 3
        
        @staticmethod
        def GetDriverByName(name):
            return MockDriver()
    
    class MockOSR:
        class SpatialReference:
            def ImportFromWkt(self, wkt):
                pass
                
            def ExportToWkt(self):
                return ""
    
    return MockGDAL(), MockOGR(), MockOSR()

def test_imports():
    """Test if we can import the core module"""
    print("🧪 Testing imports...")
    
    try:
        # Try importing GDAL
        from osgeo import gdal, ogr, osr
        print("   ✅ GDAL available")
        gdal_available = True
    except ImportError:
        print("   ⚠️ GDAL not available, using mock")
        gdal, ogr, osr = create_mock_gdal()
        gdal_available = False
        
        # Inject mock GDAL into sys.modules to simulate availability
        import sys
        class MockOSGEO:
            gdal = gdal
            ogr = ogr
            osr = osr
        sys.modules['osgeo'] = MockOSGEO()
        sys.modules['osgeo.gdal'] = gdal
        sys.modules['osgeo.ogr'] = ogr
        sys.modules['osgeo.osr'] = osr
    
    try:
        # Import the core module
        import model_hydraulic
        print("   ✅ Core hydraulic module imported successfully")
        return True, model_hydraulic, gdal_available
    except Exception as e:
        print(f"   ❌ Failed to import core module: {e}")
        return False, None, gdal_available

def test_basic_functions(model_hydraulic, gdal_available):
    """Test basic function availability"""
    print("\\n🧪 Testing basic function availability...")
    
    required_functions = [
        'calculate_water_level_from_flow',
        'calculate_deposition',
        'calculate_velocity', 
        'create_streamlines',
        'burn_bathymetry_into_dem',
        'flow_direction_d8',
        'flood_modeling_highest_points'
    ]
    
    missing_functions = []
    for func_name in required_functions:
        if hasattr(model_hydraulic, func_name):
            print(f"   ✅ {func_name} available")
        else:
            print(f"   ❌ {func_name} missing")
            missing_functions.append(func_name)
    
    if missing_functions:
        print(f"   ⚠️ Missing functions: {missing_functions}")
        return False
    else:
        print("   ✅ All required functions available")
        return True

def test_water_level_calculation(model_hydraulic):
    """Test water level calculation from flow"""
    print("\\n🧪 Testing water level calculation...")
    
    try:
        # Create a simple test DEM file path
        test_dem_path = "test_dem.tif"
        
        # Test with different flow rates
        flow_rates = [10, 50, 100, 500]
        
        for flow_q in flow_rates:
            try:
                water_level = model_hydraulic.calculate_water_level_from_flow(
                    flow_q=flow_q,
                    dem_path=test_dem_path,
                    manning_n=0.035
                )
                
                if isinstance(water_level, (int, float)) and water_level > 0:
                    print(f"   ✅ Q={flow_q} m³/s → Water level={water_level:.2f}m")
                else:
                    print(f"   ⚠️ Q={flow_q} m³/s → Invalid water level: {water_level}")
                    
            except Exception as e:
                print(f"   ❌ Q={flow_q} m³/s → Error: {e}")
                
        return True
        
    except Exception as e:
        print(f"   ❌ Water level calculation failed: {e}")
        return False

def test_flow_direction(model_hydraulic):
    """Test flow direction calculation"""
    print("\\n🧪 Testing flow direction calculation...")
    
    try:
        # Create test DEM data
        size = 50
        x, y = np.meshgrid(np.arange(size), np.arange(size))
        # Simple slope from top-left to bottom-right
        test_dem = 100 - 0.5*x - 0.3*y + np.random.normal(0, 0.1, (size, size))
        
        flow_dir = model_hydraulic.flow_direction_d8(test_dem)
        
        if isinstance(flow_dir, np.ndarray) and flow_dir.shape == test_dem.shape:
            unique_values = np.unique(flow_dir[flow_dir > 0])
            print(f"   ✅ Flow direction calculated, unique values: {unique_values}")
            return True
        else:
            print(f"   ❌ Invalid flow direction result: {type(flow_dir)}")
            return False
            
    except Exception as e:
        print(f"   ❌ Flow direction calculation failed: {e}")
        return False

def test_flood_modeling(model_hydraulic):
    """Test basic flood modeling"""
    print("\\n🧪 Testing flood modeling...")
    
    try:
        # Create test DEM
        size = 30
        x, y = np.meshgrid(np.arange(size), np.arange(size))
        # Create a valley with higher edges
        test_dem = 50 + 0.5*(x-15)**2/15 + 0.3*(y-15)**2/15
        
        # Mock QGIS interface
        class MockIface:
            pass
        
        # Test flood modeling
        mock_iface = MockIface()
        test_dem_path = "test_dem.tif"
        
        flood_result = model_hydraulic.flood_modeling_highest_points(
            mock_iface, 
            test_dem_path, 
            water_level=55.0,  # 5m above valley floor
            output_folder="test_output"
        )
        
        print(f"   ✅ Flood modeling completed: {type(flood_result)}")
        return True
        
    except Exception as e:
        print(f"   ❌ Flood modeling failed: {e}")
        return False

def create_test_summary():
    """Create a test summary report"""
    print("\\n" + "="*60)
    print("📋 FLOODENGINE CORE FUNCTIONALITY TEST SUMMARY")
    print("="*60)
    
    # Run all tests
    test_results = {}
    
    # Test 1: Imports
    import_success, model_hydraulic, gdal_available = test_imports()
    test_results['imports'] = import_success
    
    if not import_success:
        print("\\n❌ Cannot proceed with tests - import failed")
        return False
    
    # Test 2: Function availability
    functions_success = test_basic_functions(model_hydraulic, gdal_available)
    test_results['functions'] = functions_success
    
    # Test 3: Water level calculation
    if functions_success:
        water_level_success = test_water_level_calculation(model_hydraulic)
        test_results['water_level'] = water_level_success
        
        # Test 4: Flow direction
        flow_dir_success = test_flow_direction(model_hydraulic)
        test_results['flow_direction'] = flow_dir_success
        
        # Test 5: Flood modeling
        flood_success = test_flood_modeling(model_hydraulic)
        test_results['flood_modeling'] = flood_success
    else:
        test_results['water_level'] = False
        test_results['flow_direction'] = False
        test_results['flood_modeling'] = False
    
    # Summary
    print("\\n" + "="*60)
    print("📊 TEST RESULTS SUMMARY:")
    print("="*60)
    
    passed = 0
    total = len(test_results)
    
    for test_name, result in test_results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"   {test_name.upper():<20} {status}")
        if result:
            passed += 1
    
    print(f"\\n🎯 Overall Score: {passed}/{total} tests passed ({(passed/total)*100:.1f}%)")
    
    if passed == total:
        print("🎉 ALL TESTS PASSED! Core functionality is working properly.")
    elif passed >= total * 0.7:
        print("⚠️ MOSTLY WORKING - Minor issues detected, but core functionality is operational.")
    else:
        print("❌ SIGNIFICANT ISSUES - Core functionality needs attention.")
    
    return passed == total

if __name__ == "__main__":
    print("🚀 FloodEngine Core Functionality Validation")
    print("=" * 50)
    print("Testing core hydraulic modeling functions...")
    
    try:
        success = create_test_summary()
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"\\n💥 Test suite failed with error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
