#!/usr/bin/env python3
"""
Test velocity calculation logic to ensure main channels have higher velocities.
"""

import numpy as np
import matplotlib.pyplot as plt
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("VelocityTest")

def test_velocity_logic():
    """Test the velocity calculation logic"""
    
    # Create a simple test DEM with a river channel
    # Higher values = higher elevation, lower values = river channel
    dem = np.array([
        [100, 100, 100, 100, 100],  # Ridge
        [100,  99,  98,  99, 100],  # Gentle slope down to river
        [100,  98,  95,  98, 100],  # River channel (deepest)
        [100,  99,  98,  99, 100],  # Gentle slope up from river
        [100, 100, 100, 100, 100]   # Ridge
    ], dtype=np.float32)
    
    # Water level at 100.5m everywhere (shallow flooding scenario)
    water_level = 100.5
    
    # Calculate water depth
    water_depth = np.maximum(water_level - dem, 0.0)
    
    print("DEM (elevation):")
    print(dem)
    print("\nWater depth:")
    print(water_depth)
    print(f"\nMax water depth: {np.max(water_depth):.2f}m")
    print(f"Min water depth: {np.min(water_depth[water_depth > 0]):.2f}m")
    
    # Test the velocity calculation logic
    manning_n = 0.035
    dx = dy = 10.0  # 10m grid cells
    
    # Calculate bed slope (DEM gradient)
    padded_dem = np.pad(dem, pad_width=1, mode='edge')
    
    velocities = np.zeros_like(dem)
    
    for i in range(dem.shape[0]):
        for j in range(dem.shape[1]):
            if water_depth[i, j] <= 0.01:  # Skip dry areas
                continue
                
            depth = water_depth[i, j]
            
            # Calculate BED SLOPE using DEM
            dh_dx = (padded_dem[i+1, j+2] - padded_dem[i+1, j]) / (2 * dx)
            dh_dy = (padded_dem[i+2, j+1] - padded_dem[i, j+1]) / (2 * dy)
            
            # Calculate slope magnitude
            slope_mag = np.sqrt(dh_dx**2 + dh_dy**2)
            
            # Enhanced velocity calculation for different flow regimes
            if depth > 1.5:  # Main river channel (deep water)
                n_effective = manning_n * 0.8  # Smoother flow in channels
                base_velocity = 0.2  # More realistic base velocity for channels
                regime = "Main Channel"
                
            elif depth > 0.5:  # Secondary channels
                n_effective = manning_n * 0.9
                base_velocity = 0.1
                regime = "Secondary Channel"
                
            else:  # Floodplain/shallow areas
                n_effective = manning_n * 1.1  # Slightly rougher flow on floodplains
                base_velocity = 0.05
                regime = "Floodplain"
            
            # Apply Manning's equation with enhancements
            if slope_mag > 1e-6:
                hydraulic_radius = depth
                manning_vel = (1.0 / n_effective) * (hydraulic_radius ** (2/3)) * (slope_mag ** 0.5)
                
                # Cap Manning's velocity to realistic values and add base velocity
                manning_vel = min(manning_vel, 5.0)  # Cap at 5 m/s for realism
                vel_mag = manning_vel + base_velocity
                
                # Final cap on total velocity
                vel_mag = min(vel_mag, 6.0)  # Maximum realistic flood velocity
                
            else:
                # For areas with minimal slope, use depth-based velocity
                # Deeper areas should still have higher velocities due to channel effects
                if depth > 1.5:  # Main channel with low slope
                    vel_mag = base_velocity + 0.3 * min(depth / 3.0, 1.0)
                    vel_mag = min(vel_mag, 2.0)  # Cap channel velocities
                else:
                    vel_mag = base_velocity + 0.05 * min(depth / 2.0, 1.0)
                    vel_mag = min(vel_mag, 1.0)  # Cap low-slope velocities
                
            velocities[i, j] = vel_mag
            
            print(f"Cell ({i},{j}): depth={depth:.2f}m, slope={slope_mag:.4f}, vel={vel_mag:.2f}m/s ({regime})")
    
    print("\nVelocity field:")
    print(velocities)
    
    # Check if main channel has higher velocities
    main_channel_mask = water_depth > 1.5
    secondary_channel_mask = (water_depth > 0.5) & (water_depth <= 1.5)
    floodplain_mask = (water_depth > 0.01) & (water_depth <= 0.5)
    
    if np.any(main_channel_mask):
        main_channel_vel = np.mean(velocities[main_channel_mask])
        print(f"\nMain channel average velocity: {main_channel_vel:.2f} m/s")
        
    if np.any(secondary_channel_mask):
        secondary_vel = np.mean(velocities[secondary_channel_mask])
        print(f"Secondary channel average velocity: {secondary_vel:.2f} m/s")
        
    if np.any(floodplain_mask):
        floodplain_vel = np.mean(velocities[floodplain_mask])
        print(f"Floodplain average velocity: {floodplain_vel:.2f} m/s")
    
    # Create visualization
    try:
        fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(15, 5))
        
        # Plot 1: DEM
        im1 = ax1.imshow(dem, cmap='terrain', origin='upper')
        ax1.set_title('DEM (Elevation)')
        ax1.set_xlabel('X')
        ax1.set_ylabel('Y')
        plt.colorbar(im1, ax=ax1, label='Elevation (m)')
        
        # Plot 2: Water Depth
        im2 = ax2.imshow(water_depth, cmap='Blues', origin='upper')
        ax2.set_title('Water Depth')
        ax2.set_xlabel('X')
        ax2.set_ylabel('Y')
        plt.colorbar(im2, ax=ax2, label='Depth (m)')
        
        # Plot 3: Velocity
        im3 = ax3.imshow(velocities, cmap='plasma', origin='upper')
        ax3.set_title('Velocity Magnitude')
        ax3.set_xlabel('X')
        ax3.set_ylabel('Y')
        plt.colorbar(im3, ax=ax3, label='Velocity (m/s)')
        
        plt.tight_layout()
        plt.savefig('velocity_test_results.png', dpi=150, bbox_inches='tight')
        print(f"\nVisualization saved as 'velocity_test_results.png'")
        
    except ImportError:
        print("Matplotlib not available for visualization")
    
    # Verify the logic
    print("\n" + "="*50)
    print("VELOCITY LOGIC VERIFICATION")
    print("="*50)
    
    # Find the deepest point (main channel)
    max_depth_idx = np.unravel_index(np.argmax(water_depth), water_depth.shape)
    max_depth = water_depth[max_depth_idx]
    max_depth_vel = velocities[max_depth_idx]
    
    # Find a floodplain point
    floodplain_points = np.where((water_depth > 0.01) & (water_depth < 1.0))
    if len(floodplain_points[0]) > 0:
        fp_idx = (floodplain_points[0][0], floodplain_points[1][0])
        fp_depth = water_depth[fp_idx]
        fp_vel = velocities[fp_idx]
        
        print(f"Main channel: depth={max_depth:.2f}m, velocity={max_depth_vel:.2f}m/s")
        print(f"Floodplain: depth={fp_depth:.2f}m, velocity={fp_vel:.2f}m/s")
        
        if max_depth_vel > fp_vel:
            print("✅ CORRECT: Main channel has higher velocity than floodplain")
        else:
            print("❌ INCORRECT: Main channel has lower velocity than floodplain")
    else:
        print("No floodplain points found for comparison")

if __name__ == "__main__":
    test_velocity_logic()
