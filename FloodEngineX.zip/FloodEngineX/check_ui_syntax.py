"""
Syntax check for floodengine_ui.py only
"""
import os
import sys

# Get full path to the file
file_path = os.path.join(os.path.dirname(__file__), "floodengine_ui.py")

print(f"Checking syntax for: {file_path}")
print(f"File exists: {os.path.exists(file_path)}")

# Try to compile the file
import py_compile
try:
    py_compile.compile(file_path, doraise=True)
    print("✅ Compilation successful")
except py_compile.PyCompileError as e:
    print(f"❌ Compilation error: {str(e)}")
    sys.exit(1)

# Try to import the module
print("Trying to import the module...")
try:
    import floodengine_ui
    print("✅ Module imported successfully")
except ImportError as e:
    print(f"❌ Import error: {str(e)}")
    sys.exit(1)
except IndentationError as e:
    line_no = e.lineno
    print(f"❌ Indentation error on line {line_no}: {str(e)}")
    
    # Print context around the error
    with open(file_path, 'r') as f:
        lines = f.readlines()
    
    print("\nContext:")
    start = max(0, line_no - 5)
    end = min(len(lines), line_no + 5)
    
    for i in range(start, end):
        prefix = "→ " if i == line_no - 1 else "  "
        print(f"{prefix}{i+1}: {lines[i].rstrip()}")
    
    sys.exit(1)

print("✅ All checks passed!")
