# IMMEDIATE FIX for Saint-Venant Velocity Issues
# ==============================================

## The Problem
Your Saint-Venant solver is producing velocities of 400+ m/s because of **fundamental numerical stability issues**. This is **NOT** a problem with the streamlines code - it's a problem with the solver itself.

## Root Causes Found

### 1. ❌ **CRITICAL: Fixed Time Step Violating CFL Condition**
```python
# In saint_venant_2d.py line ~768
dt = total_time / time_steps  # FIXED TIME STEP - CAUSES INSTABILITY!

# In simulation loop:
actual_dt = model.step(dt)    # Calculates adaptive dt but IGNORES IT!
```

**Why this causes 400+ m/s velocities:**
- CFL condition requires: `dt < CFL * dx / (velocity + wave_speed)`
- Fixed time step ignores this → numerical instability → velocity explosion

### 2. ❌ **Unrealistic Velocity Limits**
```python
# In saint_venant_2d.py line ~572
max_vel = 8.0  # Still too high for floods!
```

### 3. ❌ **Poor CFL Implementation**
```python
# Line ~213 - Complex adaptive CFL that makes things worse
self.cfl = min(0.45, 0.45 * (1.0 - 0.5 * max_depth / (max_depth + 0.1)))
```

## Immediate Fixes

### FIX 1: Replace Fixed Time Step (CRITICAL)
```python
# CURRENT CODE (BAD):
def simulate_saint_venant_2d(...):
    dt = total_time / time_steps  # FIXED TIME STEP
    for step in range(time_steps):
        actual_dt = model.step(dt)  # Ignores adaptive dt!

# FIXED CODE:
def simulate_saint_venant_2d(...):
    current_time = 0.0
    step = 0
    max_steps = 10000  # Safety limit
    
    while current_time < total_time and step < max_steps:
        dt_adaptive = model.calculate_timestep()  # RESPECT CFL!
        actual_dt = model.step(dt_adaptive)       # USE adaptive dt
        current_time += actual_dt
        step += 1
        
        # Safety check
        max_vel = np.max(model.velocity_mag)
        if max_vel > 5.0:  # Early stop if unstable
            logger.error(f"Instability detected: {max_vel:.1f} m/s")
            break
```

### FIX 2: Conservative CFL Condition
```python
# In SaintVenant2D.calculate_timestep():
# CURRENT CODE (BAD):
self.cfl = min(0.45, complex_formula)

# FIXED CODE:
self.cfl = 0.2  # Simple, conservative CFL for flood flows
```

### FIX 3: Realistic Velocity Limits
```python
# In SaintVenant2D._update_velocities():
# CURRENT CODE (BAD):
max_vel = 8.0

# FIXED CODE:
max_vel = 3.0  # Realistic for flood flows

# Better: Use Froude number limiting
froude_limit = 1.5  # Subcritical flow
velocity_mag = np.sqrt(u**2 + v**2)
froude = velocity_mag / np.sqrt(9.81 * depth)
over_froude = froude > froude_limit
# Scale down velocities that exceed Froude limit
```

### FIX 4: Add Instability Monitoring
```python
# In simulation loop:
max_velocity = np.max(model.velocity_mag)
if max_velocity > 10.0:  # Emergency stop
    logger.error(f"SIMULATION UNSTABLE: {max_velocity:.1f} m/s")
    logger.error("Check time step, CFL condition, or initial conditions")
    break
```

## Why This Happens in 2D Shallow Water Solvers

This is a **common problem** in 2D shallow water codes. Even commercial software like:
- **HEC-RAS 2D** - Has similar issues without proper time step control
- **MIKE 21** - Requires careful CFL settings
- **TELEMAC-2D** - Can become unstable with wrong parameters

The Saint-Venant equations are **hyperbolic PDEs** that are inherently prone to numerical instability if not discretized properly.

## Comparison with Well-Known Software

### What Commercial Software Does Right:
1. **Adaptive time stepping** - Always respect CFL
2. **Conservative CFL** - Usually 0.1-0.3, not 0.45+
3. **Froude number limiting** - Keep flow subcritical
4. **Wet/dry front handling** - Special treatment for flood fronts
5. **Slope limiting** - Prevent spurious oscillations

### Your Current Solver Issues:
1. ❌ **Fixed time step** - Ignores CFL completely
2. ❌ **Too aggressive CFL** - 0.45 is too high for floods
3. ❌ **No Froude limiting** - Allows supercritical flow everywhere
4. ❌ **Poor wet/dry handling** - Can cause mass conservation issues
5. ❌ **No monitoring** - Instabilities grow unchecked

## Recommended Action Plan

### Phase 1: Emergency Fixes (Can do now)
1. Fix the time stepping in `simulate_saint_venant_2d()` 
2. Lower CFL to 0.2 in `calculate_timestep()`
3. Lower velocity limits to 3.0 m/s
4. Add instability monitoring

### Phase 2: Proper Solver Implementation
1. Implement proper Riemann solver (Roe, HLL, or HLLC)
2. Add MUSCL reconstruction for 2nd order accuracy
3. Implement proper wet/dry front tracking
4. Add slope limiting to prevent oscillations

### Phase 3: Validation
1. Test against analytical solutions (dam break, etc.)
2. Compare with commercial software on same test case
3. Ensure mass conservation to machine precision
4. Verify realistic velocity ranges

## Trust Issues with 2D Solvers

You're right to be concerned about trusting the solver. A properly implemented 2D Saint-Venant solver should:

✅ **Never exceed physically realistic velocities** (< 5 m/s for floods)
✅ **Conserve mass exactly** (within numerical precision)
✅ **Respect CFL condition** (adaptive time stepping)
✅ **Handle wet/dry fronts** (no spurious oscillations)
✅ **Match analytical solutions** (for simple test cases)

Your current solver **fails all of these tests**, which is why the velocities are unrealistic.

The problem is **definitely solvable** - it just needs proper numerical methods implementation, similar to how commercial codes work.
