import os
import sys
import numpy as np
import traceback

output_file = "test_output.txt"
with open(output_file, "w") as f:
    try:
        f.write("Adding current directory to path...\n")
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        
        f.write("Importing SaintVenant2D...\n")
        from saint_venant_2d import SaintVenant2D
        
        f.write("Creating test DEM...\n")
        dem = np.ones((20, 20)) * 100.0
        # Create a river channel
        dem[5:15, 10] = np.linspace(99, 95, 10)
        
        f.write("Creating SaintVenant2D model...\n")
        model = SaintVenant2D(dem, (0, 1, 0, 0, 0, -1))
        
        f.write("Setting initial water level...\n")
        model.set_initial_condition(water_level=99.1)
        
        f.write(f"Model initialized. Max water depth: {np.max(model.h):.3f}m\n")
        
        f.write("Running simulation step...\n")
        dt = model.step()
        
        f.write(f"Simulation step complete. dt={dt:.3f}s, max velocity={np.max(model.velocity_mag):.3f}m/s\n")
        
        f.write("TEST COMPLETED SUCCESSFULLY!\n")
    except Exception as e:
        f.write(f"ERROR: {str(e)}\n")
        traceback.print_exc(file=f)
