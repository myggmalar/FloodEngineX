#!/usr/bin/env python3
"""
Simple test to check FloodEngine class structure without imports
"""

import ast
import os

def check_class_structure():
    """Check if FloodEngineDialog class has required methods"""
    
    print("=" * 60)
    print("FloodEngine Class Structure Validation")
    print("=" * 60)
    
    file_path = os.path.join(os.path.dirname(__file__), "floodengine_ui.py")
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            source_code = f.read()
        
        # Parse the AST
        tree = ast.parse(source_code)
        
        # Find FloodEngineDialog class
        flood_engine_class = None
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef) and node.name == 'FloodEngineDialog':
                flood_engine_class = node
                break
        
        if not flood_engine_class:
            print("✗ FloodEngineDialog class not found")
            return False
        
        print("✓ FloodEngineDialog class found")
        
        # Check for required methods
        required_methods = [
            'connect_signals',
            'toggle_groundwater_controls', 
            'toggle_urban_controls',
            'toggle_advanced_engine',
            'toggle_advanced_stream_burning',
            'browse_file'
        ]
        
        found_methods = []
        class_methods = []
        
        # Get all methods in the class
        for node in flood_engine_class.body:
            if isinstance(node, ast.FunctionDef):
                class_methods.append(node.name)
        
        print(f"\nTotal methods found in class: {len(class_methods)}")
        
        # Check for required methods
        for method_name in required_methods:
            if method_name in class_methods:
                found_methods.append(method_name)
                print(f"✓ Method '{method_name}' found")
            else:
                print(f"✗ Method '{method_name}' not found")
        
        print(f"\nSummary:")
        print(f"Required methods found: {len(found_methods)}/{len(required_methods)}")
        
        if len(found_methods) == len(required_methods):
            print("✓ All required methods are present!")
            return True
        else:
            missing = set(required_methods) - set(found_methods)
            print(f"Missing methods: {', '.join(missing)}")
            return False
            
    except Exception as e:
        print(f"✗ Error analyzing file: {str(e)}")
        return False

def check_syntax():
    """Check file syntax"""
    print("\n" + "=" * 40)
    print("Syntax Validation")
    print("=" * 40)
    
    file_path = os.path.join(os.path.dirname(__file__), "floodengine_ui.py")
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            source_code = f.read()
        
        # Parse the AST to check for syntax errors
        ast.parse(source_code)
        print("✓ No syntax errors found in floodengine_ui.py")
        return True
        
    except SyntaxError as e:
        print(f"✗ Syntax error found: {e}")
        print(f"  Line {e.lineno}: {e.text.strip() if e.text else 'N/A'}")
        return False
    except Exception as e:
        print(f"✗ Error checking syntax: {str(e)}")
        return False

if __name__ == "__main__":
    syntax_ok = check_syntax()
    structure_ok = check_class_structure()
    
    print("\n" + "=" * 60)
    print("FINAL VALIDATION RESULTS")
    print("=" * 60)
    
    if syntax_ok and structure_ok:
        print("✓ SUCCESS: FloodEngine plugin is ready for QGIS!")
        print("  - No syntax errors")
        print("  - All required methods present")
        print("  - Class structure is correct")
    else:
        print("✗ ISSUES FOUND:")
        if not syntax_ok:
            print("  - Syntax errors need to be fixed")
        if not structure_ok:
            print("  - Missing required methods")
