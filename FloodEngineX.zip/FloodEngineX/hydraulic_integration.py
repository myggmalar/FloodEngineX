"""
FloodEngine Integration Module for Saint-Venant 2D Model
------------------------------------------------------
This module provides integration functions for the advanced hydraulic models.
"""

import os
import logging
import time
from qgis.core import QgsMessageLog

# Configure logging
logger = logging.getLogger("FloodEngine.Integration")

def run_saint_venant_simulation(iface, dem_path, water_level, flow_q, output_folder, time_steps=10, 
                           bounding_box=None, resolution_factor=1):
    """
    Run a full 2D Saint-Venant simulation for flood modeling.
    
    Parameters:
        iface: QGIS interface
        dem_path: Path to DEM file
        water_level: Initial water level
        flow_q: Flow rate in m³/s
        output_folder: Output folder for results
        time_steps: Number of time steps to simulate
        bounding_box: (xmin, ymin, xmax, ymax) to limit calculation area
        resolution_factor: Factor to reduce resolution (1=original, 2=half resolution, etc.)
        
    Returns:
        dict: Simulation results with paths to output files
    """
    try:
        # Import modules dynamically to avoid hard dependencies
        from saint_venant_2d_fixed import simulate_saint_venant_2d
        
        logger.info(f"Starting 2D Saint-Venant simulation with {time_steps} steps")
        
        # Display a message to the user
        iface.messageBar().pushInfo("FloodEngine", 
                                 f"Running full 2D Saint-Venant simulation with {time_steps} steps")          # Run the simulation
        time_start = time.time()
        
        # Add information about optimization parameters
        optimization_info = ""
        if bounding_box:
            optimization_info += f" with bounding box ({bounding_box[0]:.0f},{bounding_box[1]:.0f}) to ({bounding_box[2]:.0f},{bounding_box[3]:.0f})"
        if resolution_factor > 1:
            optimization_info += f" at 1/{resolution_factor} resolution"
            
        iface.messageBar().pushInfo("FloodEngine", 
                                  f"Running optimized Saint-Venant simulation{optimization_info}")                                    # Inform user that water will flow from the highest point of the river
        if flow_q:
            iface.messageBar().pushInfo("FloodEngine", 
                                 f"Water will flow from the highest elevation point of the river network at {flow_q} m³/s")
            iface.messageBar().pushInfo("FloodEngine", 
                                 f"The improved model identifies the natural flow direction from high to low terrain")
            iface.messageBar().pushInfo("FloodEngine", 
                                 f"Water will properly accumulate behind dams until potential overflow")
        water_files, velocity_files = simulate_saint_venant_2d(
            dem_path=dem_path,
            initial_water_level=water_level,
            output_folder=output_folder,
            time_steps=time_steps,
            inflow_rate=flow_q,
            bounding_box=bounding_box,
            resolution_factor=resolution_factor
        )
        time_elapsed = time.time() - time_start
        
        logger.info(f"2D simulation completed in {time_elapsed:.1f} seconds")
        
        # Notify user of completion
        iface.messageBar().pushSuccess("FloodEngine", 
                                     f"2D Saint-Venant simulation completed in {time_elapsed:.1f} seconds")
        
        return {
            "water_files": water_files,
            "velocity_files": velocity_files,
            "final_water": water_files[-1],
            "final_velocity": velocity_files[-1]
        }
        
    except ImportError as e:
        logger.error(f"Failed to import Saint-Venant module: {str(e)}")
        iface.messageBar().pushWarning("FloodEngine", 
                                     "Advanced 2D hydraulic model not available. Using simplified model.")
        return None
    except Exception as e:
        logger.error(f"Error in Saint-Venant simulation: {str(e)}")
        iface.messageBar().pushCritical("FloodEngine", 
                                      f"Error in 2D simulation: {str(e)}")
        return None

def fix_flow_directions(iface, dem_path, water_surface_path, output_folder):
    """
    Fix flow direction to ensure correct downhill flow.
    
    Parameters:
        iface: QGIS interface
        dem_path: Path to DEM file
        water_surface_path: Path to water surface file
        output_folder: Output folder for results
        
    Returns:
        dict: Paths to corrected velocity files
    """
    try:
        # Import enhanced flow direction module
        from flow_direction_fix_v2 import analyze_flow_patterns
        
        logger.info(f"Fixing flow directions for {os.path.basename(water_surface_path)}")
        
        # Display a message to the user
        iface.messageBar().pushInfo("FloodEngine", "Correcting flow directions to ensure downhill flow in waterways")
        
        # Get bounding box from stored settings
        bounding_box = None
        # Try to access the bounding_box from the QGIS interface
        if hasattr(iface, 'mainWindow'):
            # Get plugin instance if possible
            plugin_instance = None
            for obj in iface.mainWindow().findChildren(object):
                if hasattr(obj, 'bounding_box') and hasattr(obj, 'dlg'):
                    plugin_instance = obj
                    break
                    
            if plugin_instance:
                bounding_box = getattr(plugin_instance, 'bounding_box', None)
                if bounding_box:
                    logger.info(f"Using bounding box from settings: {bounding_box}")
                    iface.messageBar().pushInfo("FloodEngine", 
                                           f"Respecting calculation area boundaries for flow direction")
        
        # Run the enhanced flow correction with bounding box
        vx_path, vy_path, vmag_path = analyze_flow_patterns(
            dem_path=dem_path,
            water_surface_path=water_surface_path,
            output_folder=output_folder,
            bounding_box=bounding_box
        )
        
        logger.info("Flow direction correction complete")
        
        return {
            "velocity_x": vx_path,
            "velocity_y": vy_path,
            "velocity_magnitude": vmag_path
        }
        
    except ImportError as e:
        logger.error(f"Failed to import flow direction module: {str(e)}")
        iface.messageBar().pushWarning("FloodEngine", 
                                     "Flow direction correction not available. Using original flow directions.")
        return None
    except Exception as e:
        logger.error(f"Error in flow direction correction: {str(e)}")
        iface.messageBar().pushCritical("FloodEngine", 
                                      f"Error in flow direction correction: {str(e)}")
        return None

def generate_improved_streamlines(iface, dem_path, flood_layer, output_folder, flow_q=None):
    """
    Generate improved streamlines with better hydraulic behavior.
    
    Parameters:
        iface: QGIS interface
        dem_path: Path to DEM file
        flood_layer: QGIS flood polygon layer
        output_folder: Output folder for results
        flow_q: Flow rate in m³/s
        
    Returns:
        QgsVectorLayer: Streamline layer
    """
    try:
        # Import modules dynamically
        from enhanced_streamlines import create_enhanced_streamlines
        
        logger.info("Generating improved streamlines with enhanced hydraulic behavior")
        
        # Display a message to the user
        iface.messageBar().pushInfo("FloodEngine", 
                                 "Generating enhanced streamlines with acceleration in curves and bottlenecks")
        
        # Generate streamlines
        streamline_layer = create_enhanced_streamlines(
            dem_path=dem_path,
            flood_layer=flood_layer,
            output_folder=output_folder,
            flow_q=flow_q,
            method="hydraulic"
        )
        
        if streamline_layer and streamline_layer.isValid():
            logger.info(f"Generated {streamline_layer.featureCount()} enhanced streamlines")
            iface.messageBar().pushSuccess("FloodEngine", 
                                        f"Created {streamline_layer.featureCount()} enhanced streamlines")
            return streamline_layer
        else:
            logger.warning("No valid streamlines were created")
            iface.messageBar().pushWarning("FloodEngine", 
                                        "No valid streamlines were created. Check input data.")
            return None
        
    except ImportError as e:
        logger.error(f"Failed to import enhanced streamlines module: {str(e)}")
        iface.messageBar().pushWarning("FloodEngine", 
                                     "Enhanced streamline generation not available. Using standard streamlines.")
        return None
    except Exception as e:
        logger.error(f"Error in streamline generation: {str(e)}")
        iface.messageBar().pushCritical("FloodEngine", 
                                      f"Error in streamline generation: {str(e)}")
        return None
