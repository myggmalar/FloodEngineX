# 🕐 TIMESTEP TIMESTAMPS & 🌍 ADVANCED MANNING ZONES

## 🎯 New Features Overview

### ✅ **Timestep Timestamps**
Timestep layers now display meaningful timestamps and elevation changes in their names, making it easy to track flood progression over time.

**Example Layer Names:**
- `Timestep 01 (T+0m, +0.000m)` - Initial timestep
- `Timestep 02 (T+1h, +0.500m)` - After 1 hour, water level increased by 0.5m
- `Timestep 03 (T+2h, +1.150m)` - After 2 hours, water level increased by 1.15m
- `Timestep 04 (T+3h30m, +2.458m)` - After 3.5 hours, water level increased by 2.458m

### ✅ **Advanced Manning Coefficient Zones**
Comprehensive Manning coefficient management with polygon-based zones for realistic hydraulic modeling of different land use types.

## 🔧 Technical Implementation

### **Timestamp Calculation**

The system now calculates timestamps based on configurable timestep duration:

```python
def calculate_timestep_timestamp(timestep_number, timestep_duration_minutes=60):
    """Calculate timestamp for a given timestep"""
    total_minutes = (timestep_number - 1) * timestep_duration_minutes
    
    if total_minutes == 0:
        return "T+0m"
    
    hours = total_minutes // 60
    minutes = total_minutes % 60
    
    if hours == 0:
        return f"T+{minutes}m"
    elif minutes == 0:
        return f"T+{hours}h"
    else:
        return f"T+{hours}h{minutes}m"
```

### **Elevation Change Formatting**

Shows precise elevation changes from the initial water level:

```python
def format_elevation_change(current_elevation, base_elevation):
    """Format elevation change with proper sign"""
    change = current_elevation - base_elevation
    if change >= 0:
        return f"+{change:.3f}m"
    else:
        return f"{change:.3f}m"
```

## 🌍 Manning Zones Management

### **Manning Zone Structure**

Each Manning zone contains:
- **Name**: Descriptive name (e.g., "Natural Channel", "Forest Area")
- **Manning's n**: Coefficient value (0.001 - 1.0)
- **Description**: Detailed description
- **Geometry**: Polygon boundary (optional)

### **Default Manning Values**

The system includes preset values for common land types:

| Land Type | Manning's n | Description |
|-----------|-------------|-------------|
| Natural channels (clean) | 0.025-0.035 | Clean, straight channels |
| Natural channels (rough) | 0.035-0.050 | Channels with vegetation/rocks |
| Floodplains (pasture) | 0.025-0.035 | Grassy floodplains |
| Floodplains (forest) | 0.050-0.100 | Forested floodplains |
| Urban areas | 0.013-0.020 | Developed/paved areas |
| Agricultural land | 0.020-0.030 | Cultivated fields |

### **Manning Zones Dialog Features**

1. **Zone Management**:
   - Add/Edit/Delete zones
   - Preset value buttons
   - Geometry drawing (planned)

2. **File Operations**:
   - Save zones to JSON
   - Load zones from JSON
   - Export as shapefile

3. **Default Coefficient**:
   - Set default Manning's n for unmapped areas
   - Typically 0.035 for natural channels

## 🎮 User Interface Enhancements

### **Advanced Tab - New Controls**

#### **Manning Coefficient Zones Section**
```
┌─ Advanced Manning Coefficient Zones ─────────────────────┐
│ ☐ Use advanced Manning zones                            │
│                                                          │
│ [Manage Manning Zones...] [Manning zones file] [Browse] │
│                                                          │
│ Timestep duration: [60] minutes                         │
└──────────────────────────────────────────────────────────┘
```

#### **Timestep Duration Control**
- Range: 1-1440 minutes (1 minute to 24 hours)
- Default: 60 minutes
- Affects timestamp display in layer names

### **Manning Zones Management Dialog**

```
┌─ Manning Coefficient Zones ──────────────────────────────┐
│                                                          │
│ Default Manning's n: [0.0350] (Used for unmapped areas) │
│                                                          │
│ ┌─ Manning Zones ────────────────────────────────────────┐
│ │ Zone Name     │ Manning's n │ Description │ Geometry  │
│ │ Natural Ch... │ 0.0300      │ Clean ch... │ Defined   │
│ │ Forest Area   │ 0.0750      │ Forest...   │ Not def.  │
│ │ Urban Zone    │ 0.0160      │ Urban...    │ Defined   │
│ └─────────────────────────────────────────────────────────┘
│                                                          │
│ [Add Zone] [Edit Zone] [Delete Zone] [Draw Zone on Map] │
│                                                          │
│ ┌─ Presets ──────────────────────────────────────────────┐
│ │ [Add Natural Channel Zone] [Add Forest Zone]          │
│ │ [Add Urban Zone]                                       │
│ └─────────────────────────────────────────────────────────┘
│                                                          │
│ [Save Zones] [Load Zones] [Export as Shapefile]        │
│                                                          │
│ [OK] [Cancel]                                           │
└──────────────────────────────────────────────────────────┘
```

## 📋 Usage Workflow

### **Setting Up Timestep Simulation with Timestamps**

1. **Open FloodEngine Advanced Mode**
2. **Configure Timestep Duration**:
   - Set desired timestep duration (e.g., 30 minutes, 1 hour, 2 hours)
3. **Run Timestep Simulation**
4. **View Results**:
   - Layers appear with timestamps: `Timestep 05 (T+2h, +1.750m)`
   - Easy to see flood progression over time

### **Setting Up Manning Zones**

1. **Enable Advanced Manning Zones**:
   ```
   ☑ Use advanced Manning zones
   ```

2. **Open Manning Zones Dialog**:
   - Click "Manage Manning Zones..."

3. **Configure Default Manning's n**:
   - Set default value (typically 0.035)

4. **Add Manning Zones**:
   - Click "Add Zone" or use preset buttons
   - Define zone properties:
     - Name: "Main Channel"
     - Manning's n: 0.030
     - Description: "Natural channel, clean"

5. **Draw Zone Geometry** (Future):
   - Click "Draw Zone on Map"
   - Draw polygon on QGIS map

6. **Save Configuration**:
   - Click "Save Zones"
   - Choose file location
   - Configuration saved as JSON

7. **Export for External Use**:
   - Click "Export as Shapefile"
   - Creates shapefile with Manning zones

### **Running Simulation with Manning Zones**

1. **Load Manning Zones**:
   - Enable advanced Manning zones
   - Load zones file or configure new zones

2. **Set Timestep Duration**:
   - Choose appropriate duration (30-120 minutes typical)

3. **Run Advanced Simulation**:
   - System applies different Manning coefficients based on location
   - More realistic flow modeling

4. **Review Results**:
   - Timestep layers show progression with timestamps
   - Manning zones affect flow behavior in different areas

## 📁 File Formats

### **Manning Zones JSON Format**
```json
{
  "default_manning": 0.035,
  "zones": [
    {
      "name": "Natural Channel",
      "manning_n": 0.030,
      "description": "Clean natural channel",
      "geometry_wkt": "POLYGON((x1 y1, x2 y2, ...))"
    },
    {
      "name": "Forest Area",
      "manning_n": 0.075,
      "description": "Forested floodplain",
      "geometry_wkt": "POLYGON((x1 y1, x2 y2, ...))"
    }
  ]
}
```

### **Manning Zones Shapefile**
Exported shapefile contains:
- **name** (String): Zone name
- **manning_n** (Double): Manning coefficient
- **description** (String): Zone description
- **Geometry**: Polygon boundaries

## 🎯 Expected Output Examples

### **Layer Names with Timestamps**
```
📁 Flood Timesteps (10 steps)
├── 🌊 Timestep 01 (T+0m, +0.000m)      [Initial state]
├── 🌊 Timestep 02 (T+30m, +0.250m)     [After 30 minutes]
├── 🌊 Timestep 03 (T+1h, +0.500m)      [After 1 hour]
├── 🌊 Timestep 04 (T+1h30m, +0.875m)   [After 1.5 hours]
├── 🌊 Timestep 05 (T+2h, +1.350m)      [After 2 hours]
├── 🌊 Timestep 06 (T+2h30m, +1.920m)   [After 2.5 hours]
├── 🌊 Timestep 07 (T+3h, +2.580m)      [After 3 hours]
├── 🌊 Timestep 08 (T+3h30m, +3.320m)   [After 3.5 hours]
├── 🌊 Timestep 09 (T+4h, +4.150m)      [After 4 hours]
└── 🌊 Timestep 10 (T+4h30m, +5.070m)   [After 4.5 hours]
```

### **Console Output with Manning Zones**
```
🕐 Starting IMPROVED timestep simulation with 10 steps
🌍 Applying Manning coefficient zones from: /path/to/manning_zones.json
   Loaded 5 Manning zones
🏔️ Creating single hillshade for timestep simulation...
   ✅ Single hillshade created for all timesteps

⏱️ Processing timestep 1 (1/10): Water level 60.00m
   Applied Manning zones to 1,245 cells
   ✅ Timestep 1: 156 flood features created

⏱️ Processing timestep 2 (2/10): Water level 60.25m
   Applied Manning zones to 1,387 cells
   ✅ Timestep 2: 203 flood features created

...

📊 Adding 10 timestep layers to project...
   ✅ Added: Timestep 01 (T+0m, +0.000m)
   ✅ Added: Timestep 02 (T+30m, +0.250m)
   ✅ Added: Timestep 03 (T+1h, +0.500m)
   ...

✅ Enhanced timestep simulation complete:
   📁 Results folder: /path/to/timestep_simulation_20241217_143522
   🕐 Timesteps processed: 10
   ✅ Successful floods: 10
   📊 Layers added to project: 10
   🌍 Manning zones applied: 5 zones, 12,456 cells affected
```

## 🚀 Benefits

### **Timestamp Benefits**
1. **✅ Clear Time Progression**: Immediately see flood development over time
2. **✅ Precise Timing**: Know exactly when each flood stage occurs
3. **✅ Elevation Tracking**: See cumulative water level changes
4. **✅ Animation Ready**: Perfect for creating flood animations

### **Manning Zones Benefits**
1. **✅ Realistic Modeling**: Different land types have appropriate friction coefficients
2. **✅ Spatial Accuracy**: Urban areas vs forests vs channels modeled differently
3. **✅ Reusable Configurations**: Save and load Manning zone setups
4. **✅ Standard Values**: Built-in presets for common land types
5. **✅ External Integration**: Export zones for use in other hydraulic models

## 🧪 Testing the Features

### **Test Timestamp Display**
1. Set timestep duration to 30 minutes
2. Run 6-timestep simulation
3. Verify layer names show: T+0m, T+30m, T+1h, T+1h30m, T+2h, T+2h30m

### **Test Manning Zones**
1. Create zones: Channel (0.030), Forest (0.075), Urban (0.016)
2. Save and reload configuration
3. Export as shapefile
4. Run simulation and verify different flow behavior in zones

---

## 🎉 **FEATURES READY FOR USE!**

The FloodEngine plugin now provides:
- ✅ **Meaningful timestamps** in layer names for easy temporal tracking
- ✅ **Advanced Manning zones** for realistic hydraulic modeling
- ✅ **Comprehensive zone management** with save/load functionality
- ✅ **Preset Manning values** for common land types
- ✅ **Configurable timestep duration** for flexible modeling
- ✅ **Export capabilities** for external tool integration

Perfect for creating professional flood simulations with proper temporal tracking and spatial hydraulic accuracy!
