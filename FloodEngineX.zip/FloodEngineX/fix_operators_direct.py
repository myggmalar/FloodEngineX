import os
import re

# Print startup message with visible separator
print("="*80)
print("DIRECT SWEDISH LOGICAL OPERATORS REPLACEMENT SCRIPT")
print("="*80)

# Get the absolute path to model_hydraulic.py
script_dir = os.path.dirname(os.path.abspath(__file__))
file_path = os.path.join(script_dir, "model_hydraulic.py")

print(f"Target file: {file_path}")

# Read the file content
with open(file_path, 'r', encoding='utf-8') as file:
    content = file.read()
    
# Print initial statistics
original_eller_count = content.count("eller")
original_och_count = content.count("och")
print(f"Original file contains: {original_eller_count} instances of 'eller' and {original_och_count} instances of 'och'")

# Replace Swedish logical operators with English equivalents
# Replace incorrect comparison operator too
modified_content = content.replace("eller", "or").replace("och", "and").replace(">==", ">=")

# Verify replacements
final_eller_count = modified_content.count("eller")
final_och_count = modified_content.count("och")
print(f"After replacement: {final_eller_count} instances of 'eller' and {final_och_count} instances of 'och'")

# Write the modified content back to the file
with open(file_path, 'w', encoding='utf-8') as file:
    file.write(modified_content)

print("File successfully updated!")
print("="*80)