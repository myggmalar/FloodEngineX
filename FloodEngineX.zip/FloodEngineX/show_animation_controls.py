#!/usr/bin/env python3
"""
Launch FloodEngine Animation Controls
====================================
This script shows you exactly how to access and use the animation controls.
"""

import os
import sys
from pathlib import Path

# Add FloodEngineX to path
sys.path.insert(0, str(Path(__file__).parent))

def launch_animation_controls_demo():
    """Show how to launch the animation controls in different ways."""
    
    print("🎬 FLOODENGINE ANIMATION CONTROLS - LAUNCH GUIDE")
    print("=" * 60)
    
    print("\n1. 🚀 AUTOMATIC LAUNCH (When running simulation)")
    print("   The animation controls launch automatically when you run:")
    print("   ```python")
    print("   from saint_venant_2d import simulate_saint_venant_2d")
    print("   ")
    print("   results = simulate_saint_venant_2d(")
    print("       dem_path='your_dem.tif',")
    print("       water_level=105.0,")
    print("       output_folder='output/',")
    print("       total_time=3600")
    print("   )")
    print("   # Animation controls appear automatically in QGIS!")
    print("   ```")
    
    print("\n2. 🎮 MANUAL LAUNCH (For existing results)")
    print("   If you have existing simulation results:")
    print("   ```python")
    print("   from time_series_animator import TimeSeriesAnimator")
    print("   from PyQt5.QtWidgets import QApplication")
    print("   ")
    print("   # Load your results data")
    print("   results = load_your_simulation_results()")
    print("   ")
    print("   # Launch animation dialog")
    print("   app = QApplication([])")
    print("   animator = TimeSeriesAnimator(results, 'output_folder')")
    print("   animator.show()")
    print("   app.exec_()")
    print("   ```")
    
    print("\n3. 🗺️ QGIS DOCK WIDGET")
    print("   For direct map canvas integration:")
    print("   ```python")
    print("   from map_canvas_time_series import MapCanvasTimeSeriesController")
    print("   from map_canvas_time_series import TimeSeriesDockWidget")
    print("   ")
    print("   # Create controller")
    print("   controller = MapCanvasTimeSeriesController(results, 'output_folder')")
    print("   ")
    print("   # Create dock widget")
    print("   dock = TimeSeriesDockWidget(controller)")
    print("   iface.addDockWidget(Qt.RightDockWidgetArea, dock)")
    print("   ```")
    
    print("\n4. 📁 FINDING ANIMATION FILES")
    print("   After running a simulation, look for:")
    print("   • output_folder/time_series_animation/")
    print("   • ANIMATION_INSTRUCTIONS.md (detailed guide)")
    print("   • rasters/ folder (individual timestep files)")
    
    print("\n5. 🎯 CONTROL FEATURES")
    print("   The animation controls include:")
    print("   • ▶️ Play/Pause buttons")
    print("   • ⏭️ Step forward/backward")
    print("   • 🎚️ Timeline slider")
    print("   • ⚡ Speed control (0.1-10 fps)")
    print("   • 🔄 Loop mode")
    print("   • 📍 Interactive point sampling")
    print("   • 📊 Real-time data display")
    print("   • 📹 Export animation")

def create_simple_launcher():
    """Create a simple launcher script for the animation controls."""
    
    launcher_code = '''#!/usr/bin/env python3
"""
Simple Animation Controls Launcher
==================================
"""

import sys
import os
from pathlib import Path

def launch_animation_from_folder(results_folder):
    """Launch animation controls from existing results folder."""
    
    # Check for QGIS environment
    try:
        from qgis.core import QgsApplication
        from qgis.utils import iface
        qgis_available = True
        print("✅ QGIS environment detected")
    except ImportError:
        qgis_available = False
        print("⚠️ QGIS not available - using standalone mode")
    
    # Add FloodEngineX to path
    script_dir = Path(__file__).parent
    sys.path.insert(0, str(script_dir))
    
    try:
        if qgis_available:
            # Launch in QGIS
            from map_canvas_time_series import launch_time_series_animation
            launch_time_series_animation(results_folder)
        else:
            # Launch standalone
            from time_series_animator import launch_standalone_animator
            launch_standalone_animator(results_folder)
            
    except Exception as e:
        print(f"❌ Failed to launch animation: {e}")
        print("📖 Check ANIMATION_INSTRUCTIONS.md for manual setup")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        results_folder = sys.argv[1]
    else:
        # Default to test output
        results_folder = "test_time_series_output"
    
    print(f"🚀 Launching animation for: {results_folder}")
    launch_animation_from_folder(results_folder)
'''
    
    with open("launch_animation.py", "w", encoding='utf-8') as f:
        f.write(launcher_code)
    
    print("\n✅ Created 'launch_animation.py' - A simple launcher script!")
    print("   Usage: python launch_animation.py [results_folder]")

def check_existing_animations():
    """Check for existing animation files."""
    
    print("\n📁 CHECKING FOR EXISTING ANIMATION FILES...")
    
    # Check common locations
    locations_to_check = [
        "test_time_series_output",
        "demo_flood_animation",
        "output",
        "time_series_animation"
    ]
    
    found_animations = []
    
    for location in locations_to_check:
        if os.path.exists(location):
            # Check for animation files
            rasters_dir = os.path.join(location, "rasters")
            instructions_file = os.path.join(location, "ANIMATION_INSTRUCTIONS.md")
            
            if os.path.exists(rasters_dir) or os.path.exists(instructions_file):
                found_animations.append(location)
                print(f"✅ Found animation files in: {location}")
                
                # List contents
                if os.path.exists(rasters_dir):
                    raster_files = [f for f in os.listdir(rasters_dir) if f.endswith('.tif')]
                    print(f"   📊 {len(raster_files)} raster files")
                
                if os.path.exists(instructions_file):
                    print(f"   📖 Instructions: {instructions_file}")
    
    if not found_animations:
        print("❌ No animation files found")
        print("   Run a simulation first to generate animation data")
    
    return found_animations

if __name__ == "__main__":
    launch_animation_controls_demo()
    create_simple_launcher()
    found = check_existing_animations()
    
    if found:
        print(f"\n🎉 Ready to launch animations from {len(found)} locations!")
        print("   Use: python launch_animation.py [folder_name]")
    else:
        print("\n💡 TIP: Run 'python test_time_series_animation.py' first to generate test data")
