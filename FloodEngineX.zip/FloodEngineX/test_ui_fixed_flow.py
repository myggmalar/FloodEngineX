"""
Test script to verify that the UI options for fixed flow direction work correctly.
This simulates user interaction with the new checkboxes.

Run this script in QGIS Python console to verify the implementation.
"""
from qgis.core import QgsApplication
from qgis.utils import iface
from PyQt5.QtWidgets import QApplication
import sys
import os

# Add the plugin path to sys.path if needed
plugin_path = os.path.join(QgsApplication.qgisSettingsDirPath(), 'python', 'plugins', 'floodengine')
if plugin_path not in sys.path:
    sys.path.append(plugin_path)

# Import the FloodEngine dialog
try:
    from floodengine_ui import FloodEngineDialog
    print("✅ Successfully imported FloodEngineDialog")
except ImportError as e:
    print(f"❌ Error importing FloodEngineDialog: {e}")
    sys.exit(1)

def test_ui_fixed_flow_options():
    """Test that the UI options for fixed flow direction work correctly."""
    # Create a new dialog
    dialog = FloodEngineDialog(iface)
    
    # Check that the fixed flow checkboxes exist
    if not hasattr(dialog, 'use_fixed_flow'):
        print("❌ ERROR: use_fixed_flow checkbox not found in UI")
        return False
    
    if not hasattr(dialog, 'use_fixed_flow_wl'):
        print("❌ ERROR: use_fixed_flow_wl checkbox not found in UI")
        return False
    
    # Test toggling the checkboxes
    print(f"Initial Q mode fixed flow state: {dialog.use_fixed_flow.isChecked()}")
    print(f"Initial WL mode fixed flow state: {dialog.use_fixed_flow_wl.isChecked()}")
    
    # Toggle the checkboxes
    dialog.use_fixed_flow.setChecked(False)
    dialog.use_fixed_flow_wl.setChecked(False)
    
    print(f"After toggle Q mode fixed flow state: {dialog.use_fixed_flow.isChecked()}")
    print(f"After toggle WL mode fixed flow state: {dialog.use_fixed_flow_wl.isChecked()}")
    
    # Reset to default state
    dialog.use_fixed_flow.setChecked(True)
    dialog.use_fixed_flow_wl.setChecked(True)
    
    print("✅ UI test completed successfully")
    return True

# Run the test when script is executed directly
if __name__ == "__main__":
    test_ui_fixed_flow_options()
    print("Test completed")
