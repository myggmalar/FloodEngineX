#!/usr/bin/env python3
"""
Test script to verify the new timestep controls are properly implemented
and the old controls have been removed.
"""

import os
import sys

def test_ui_timestep_modernization():
    """Test that the UI has been properly modernized with new timestep controls."""
    
    print("🔧 Testing FloodEngine UI Timestep Modernization...")
    print("=" * 60)
    
    ui_file = "floodengine_ui.py"
    if not os.path.exists(ui_file):
        print(f"❌ UI file not found: {ui_file}")
        return False
    
    with open(ui_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check that OLD timestep controls have been REMOVED
    old_controls_removed = [
        ('self.adv_timestep = QLineEdit("60")', 'Old timestep seconds control'),
        ('self.adv_output_timestep = QLineEdit("60")', 'Old output timestep minutes control'),
        ('"Timestep:"', 'Old timestep label'),
        ('"Output Timestep:"', 'Old output timestep label'),
        ('QLabel("seconds")', 'Old seconds label'),
        ('QLabel("minutes")', 'Old minutes label (in timestep context)')
    ]
    
    print("🗑️  Checking OLD controls have been REMOVED:")
    old_found = []
    old_removed = []
    
    for old_control, description in old_controls_removed:
        if old_control in content:
            old_found.append(description)
            print(f"   ❌ Still found: {description}")
        else:
            old_removed.append(description)
            print(f"   ✅ Removed: {description}")
    
    # Check that NEW timestep controls have been ADDED
    new_controls_added = [
        ('self.adv_simulation_duration = QLineEdit("24")', 'New simulation duration control'),
        ('self.adv_output_timesteps = QLineEdit("10")', 'New output timesteps control'),
        ('self.adv_output_interval_label', 'New output interval display'),
        ('"Simulation Duration:"', 'New simulation duration label'),
        ('"Number of Output Timesteps:"', 'New output timesteps label'),
        ('def update_output_interval', 'Update interval function'),
        ('def connect_timestep_controls', 'Connect timestep controls function'),
        ('simulation_duration_hours=simulation_duration_hours', 'Timestep parameter passing')
    ]
    
    print(f"\n🆕 Checking NEW controls have been ADDED:")
    new_found = []
    new_missing = []
    
    for new_control, description in new_controls_added:
        if new_control in content:
            new_found.append(description)
            print(f"   ✅ Added: {description}")
        else:
            new_missing.append(description)
            print(f"   ❌ Missing: {description}")
    
    # Check for calculation logic
    print(f"\n🧮 Checking CALCULATION LOGIC:")
    calculation_checks = [
        ('interval = duration / timesteps', 'Interval calculation'),
        ('Output interval:', 'Interval display'),
        ('hours" if interval >= 1.0', 'Hours display logic'),
        ('minutes = interval * 60', 'Minutes conversion')
    ]
    
    calculation_working = []
    for calc_check, description in calculation_checks:
        if calc_check in content:
            calculation_working.append(description)
            print(f"   ✅ Working: {description}")
        else:
            print(f"   ❌ Missing: {description}")
    
    # Summary
    print(f"\n📊 SUMMARY:")
    print(f"   Old controls removed: {len(old_removed)}/{len(old_controls_removed)}")
    print(f"   New controls added: {len(new_found)}/{len(new_controls_added)}")
    print(f"   Calculation logic: {len(calculation_working)}/{len(calculation_checks)}")
    
    success = (len(old_found) == 0 and 
               len(new_missing) == 0 and 
               len(calculation_working) == len(calculation_checks))
    
    if success:
        print(f"\n🎉 SUCCESS: UI has been fully modernized!")
        print(f"   ✅ All old timestep controls removed")
        print(f"   ✅ All new timestep controls added") 
        print(f"   ✅ Calculation logic working")
        print(f"\n🎯 USER EXPERIENCE:")
        print(f"   👤 User will now see:")
        print(f"      - 'Simulation Duration: 24 hours' (clear total time)")
        print(f"      - 'Number of Output Timesteps: 10 outputs' (clear output count)")
        print(f"      - 'Output interval: 2.4 hours' (auto-calculated)")
        print(f"   📝 No more confusion about seconds vs minutes!")
        print(f"   🎛️ Full control over both duration AND output frequency")
    else:
        print(f"\n⚠️ ISSUES FOUND:")
        if old_found:
            print(f"   🗑️ Old controls still present: {len(old_found)}")
        if new_missing:
            print(f"   🆕 New controls missing: {len(new_missing)}")
        if len(calculation_working) < len(calculation_checks):
            print(f"   🧮 Calculation logic incomplete")
    
    return success

if __name__ == "__main__":
    success = test_ui_timestep_modernization()
    
    if success:
        print(f"\n🚀 READY FOR TESTING!")
        print(f"   The user should now see proper timestep controls")
        print(f"   that allow setting timespan in HOURS and number of TIMESTEPS.")
    else:
        print(f"\n🔧 NEEDS MORE WORK")
        print(f"   Some issues remain with the timestep modernization.")
    
    sys.exit(0 if success else 1)
