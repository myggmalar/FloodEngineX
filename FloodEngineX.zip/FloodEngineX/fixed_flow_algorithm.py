# force_fixed_flow_solution.py
# This module provides a corrected directional flood algorithm

import numpy as np
from collections import deque

def create_directional_flood_mask(dem_array, water_level):
    """
    Create flood mask using proper HIGH-TO-LOW flow direction.
    Water starts from highest floodable points and flows downhill.
    
    Args:
        dem_array: DEM elevation array (numpy array)
        water_level: Target water level (float)
    
    Returns:
        flood_mask: Boolean array where True = flooded
    """
    print(f"🔧 FIXED ALGORITHM: Creating directional flood from HIGH ({np.nanmax(dem_array):.1f}m) to LOW ({np.nanmin(dem_array):.1f}m)")
    
    # Initialize
    valid_mask = ~np.isnan(dem_array)
    floodable_mask = valid_mask & (dem_array < water_level)
    flooded = np.zeros_like(dem_array, dtype=bool)
    
    if not np.any(floodable_mask):
        print("❌ No floodable areas found")
        return flooded
    
    # CRITICAL FIX: Start from HIGHEST floodable elevations
    floodable_elevations = dem_array[floodable_mask]
    elevation_threshold = np.percentile(floodable_elevations, 85)  # Top 15% of floodable areas
    
    # Find starting points (high elevation areas that can be flooded)
    start_mask = floodable_mask & (dem_array >= elevation_threshold)
    start_rows, start_cols = np.where(start_mask)
    
    if len(start_rows) == 0:
        # Fallback: use highest single points
        max_floodable_elev = np.max(floodable_elevations)
        start_mask = floodable_mask & (dem_array >= max_floodable_elev - 0.5)
        start_rows, start_cols = np.where(start_mask)
    
    print(f"✅ Starting flood from {len(start_rows)} high points at elevation ≥ {elevation_threshold:.2f}m")
    
    # Initialize flood propagation queue
    queue = deque()
    
    # Add all starting points
    for i in range(len(start_rows)):
        row, col = start_rows[i], start_cols[i]
        flooded[row, col] = True
        queue.append((row, col, dem_array[row, col]))  # Include elevation for proper flow
    
    # 8-directional flow (including diagonals)
    directions = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]
    
    # Flow from high to low with strict elevation control
    processed = 0
    max_iterations = 50000  # Prevent infinite loops
    
    while queue and processed < max_iterations:
        current_row, current_col, current_elevation = queue.popleft()
        processed += 1
        
        # Check all 8 neighbors
        for dr, dc in directions:
            new_row, new_col = current_row + dr, current_col + dc
            
            # Boundary check
            if (new_row < 0 or new_row >= dem_array.shape[0] or 
                new_col < 0 or new_col >= dem_array.shape[1]):
                continue
            
            # Skip if already flooded or invalid
            if flooded[new_row, new_col] or not valid_mask[new_row, new_col]:
                continue
            
            neighbor_elevation = dem_array[new_row, new_col]
            
            # CRITICAL: Water flows DOWNHILL - neighbor must be lower AND floodable
            if (neighbor_elevation <= current_elevation and  # Downhill or level
                neighbor_elevation < water_level):           # Below water level
                
                flooded[new_row, new_col] = True
                queue.append((new_row, new_col, neighbor_elevation))
    
    total_flooded = np.sum(flooded)
    print(f"✅ FIXED FLOW complete: {total_flooded} cells flooded, {processed} iterations")
    
    return flooded


def validate_flow_direction(dem_array, flood_mask, water_level):
    """
    Validate that flood follows proper downhill flow patterns
    """
    if not np.any(flood_mask):
        return False, "No flooded areas to validate"
    
    # Check that flooded areas are below water level
    flooded_elevations = dem_array[flood_mask]
    invalid_count = np.sum(flooded_elevations >= water_level)
    
    if invalid_count > 0:
        return False, f"{invalid_count} flooded cells are above water level"
    
    # Check flow connectivity (flooded areas should be connected downhill)
    # This is a simplified check - in practice you'd do full connectivity analysis
    elevation_range = np.max(flooded_elevations) - np.min(flooded_elevations)
    
    return True, f"Flow validation passed. Elevation range: {elevation_range:.2f}m"
