import os
import numpy as np
from qgis.core import QgsProject, QgsVectorLayer
from PyQt5.QtGui import QColor
from osgeo import gdal, ogr, osr

def calculate_flood_area(
    iface,
    dem_path,
    water_levels=None,
    output_folder=None,
    flow_q=None,
    manning_n=None,
    bathymetry_path=None,
    bathymetry_columns=None,
    duration_hours=24,
    timestep_minutes=60,
    **kwargs
):
    """
    Calculate flood area using 2D Saint-Venant equations with dynamic simulation.
    
    Args:
        iface: QGIS interface
        dem_path: Path to DEM file
        water_levels: List of water levels (if None, will be computed dynamically)
        output_folder: Output directory
        flow_q: Flow rate (m³/s)
        manning_n: Manning's roughness coefficient
        bathymetry_path: Path to bathymetry data
        bathymetry_columns: Column mapping for bathymetry CSV
        duration_hours: Simulation duration in hours
        timestep_minutes: Output timestep in minutes
        **kwargs: Additional parameters
    
    Returns:
        List of polygon layers created
    """
    print(f"🌊 Starting FloodEngine simulation...")
    print(f"📍 DEM: {dem_path}")
    print(f"⏱️ Duration: {duration_hours} hours")
    print(f"🔄 Timestep: {timestep_minutes} minutes")
    print(f"💧 Flow rate: {flow_q} m³/s")
    print(f"🏔️ Manning's n: {manning_n}")
    
    # Create merged terrain model from DEM + bathymetry if available
    terrain_path = dem_path
    hillshade_path = None
    
    if bathymetry_path and bathymetry_columns:
        print(f"Creating merged terrain model from DEM + bathymetry...")
        print(f"Bathymetry file: {bathymetry_path}")
        print(f"Columns: X={bathymetry_columns.get('x')}, Y={bathymetry_columns.get('y')}, Z={bathymetry_columns.get('z')}")
        
        # Create merged terrain model with TIN interpolation
        terrain_path, hillshade_path = create_merged_terrain_model(
            dem_path, bathymetry_path, bathymetry_columns, output_folder
        )
        print(f"Using merged terrain model: {terrain_path}")
        print(f"Hillshade created: {hillshade_path}")
    else:
        print("No bathymetry data provided, using DEM only")
        # Still create hillshade from DEM using GDAL
        hillshade_path = os.path.join(output_folder, "dem_hillshade.tif")
        create_hillshade_gdal(dem_path, hillshade_path)
    
    # Calculate timesteps from duration and timestep interval
    total_minutes = duration_hours * 60
    num_timesteps = int(total_minutes / timestep_minutes)
    
    print(f"📊 Calculated {num_timesteps} timesteps over {duration_hours} hours")
    
    # Run 2D Saint-Venant simulation with dynamic water levels
    sv_result = simulate_saint_venant_2d(
        dem_path=terrain_path,
        flow_rate=flow_q,
        manning_n=manning_n,
        duration_hours=duration_hours,
        timestep_minutes=timestep_minutes,
        num_timesteps=num_timesteps,
        output_folder=output_folder,
        bathymetry_path=bathymetry_path,
        bathymetry_columns=bathymetry_columns,
        hillshade_path=hillshade_path,
        water_levels=water_levels,  # Pass for fallback if needed
    )
    
    all_polygons = []
    for filename, timestep_num, simulation_time_hours, actual_water_level in sv_result:
        wet_array = load_raster_to_array_gdal(filename)
        threshold = kwargs.get('wet_threshold', 0.05)
        binary_mask = (wet_array > threshold)
        polygon_layer = polygonize_mask_gdal(binary_mask, filename, output_folder, timestep_num, actual_water_level)
        
        # Create descriptive layer name with both time and water level
        layer_name = f"Flood_T{timestep_num:03d}_{simulation_time_hours:.1f}h_{actual_water_level:.2f}m"
        polygon_layer.setName(layer_name)
        style_polygon_layer_blue_opacity(polygon_layer)
        QgsProject.instance().addMapLayer(polygon_layer)
        
        # Generate streamlines per timestep
        vx_path = filename.replace('depth', 'velocity_x')
        vy_path = filename.replace('depth', 'velocity_y')
        mask_path = filename
        gpkg_path = os.path.join(output_folder, f"streamlines_T{timestep_num:03d}_{simulation_time_hours:.1f}h.gpkg")
        create_streamlines_from_velocity_gdal(
            vx_path, vy_path, mask_path, gpkg_path, n_points=150, max_length=200, step=1.5
        )
        layer = QgsVectorLayer(gpkg_path, f"Streamlines_T{timestep_num:03d}_{simulation_time_hours:.1f}h", "ogr")
        QgsProject.instance().addMapLayer(layer)
        all_polygons.append(polygon_layer)
        
    return all_polygons

def create_hillshade_gdal(dem_path, output_path, azimuth=315, altitude=45):
    """Create hillshade from DEM using GDAL."""
    print(f"Creating hillshade using GDAL...")
    
    try:
        # Check if input DEM exists
        if not os.path.exists(dem_path):
            print(f"❌ DEM file not found: {dem_path}")
            return
        
        # Use gdaldem hillshade command
        from osgeo import gdal
        
        # Configure hillshade options
        options = gdal.DEMProcessingOptions(
            format='GTiff',
            creationOptions=['COMPRESS=LZW'],
            azimuth=azimuth,
            altitude=altitude
        )
        
        # Generate hillshade
        result = gdal.DEMProcessing(output_path, dem_path, 'hillshade', options=options)
        
        if result is not None and os.path.exists(output_path):
            print(f"✅ Hillshade saved: {output_path}")
        else:
            print(f"❌ Failed to create hillshade: {output_path}")
            
    except Exception as e:
        print(f"❌ Error creating hillshade: {str(e)}")
        print(f"   Input: {dem_path}")
        print(f"   Output: {output_path}")
        # Create a dummy hillshade file to prevent errors
        try:
            import shutil
            shutil.copy(dem_path, output_path)
            print(f"📋 Created copy of DEM as fallback hillshade")
        except:
            pass
):
    """
    Calculate flood area using 2D Saint-Venant equations with dynamic simulation.
    
    Args:
        iface: QGIS interface
        dem_path: Path to DEM file
        water_levels: List of water levels (if None, will be computed dynamically)
        output_folder: Output directory
        flow_q: Flow rate (m³/s)
        manning_n: Manning's roughness coefficient
        bathymetry_path: Path to bathymetry data
        bathymetry_columns: Column mapping for bathymetry CSV
        duration_hours: Simulation duration in hours
        timestep_minutes: Output timestep in minutes
        **kwargs: Additional parameters
    
    Returns:
        List of polygon layers created
    """
    print(f"🌊 Starting FloodEngine simulation...")
    print(f"📍 DEM: {dem_path}")
    print(f"⏱️ Duration: {duration_hours} hours")
    print(f"🔄 Timestep: {timestep_minutes} minutes")
    print(f"💧 Flow rate: {flow_q} m³/s")
    print(f"🏔️ Manning's n: {manning_n}")
    
    # Create merged terrain model from DEM + bathymetry if available
    terrain_path = dem_path
    hillshade_path = None
    
    if bathymetry_path and bathymetry_columns:
        print(f"Creating merged terrain model from DEM + bathymetry...")
        print(f"Bathymetry file: {bathymetry_path}")
        print(f"Columns: X={bathymetry_columns.get('x')}, Y={bathymetry_columns.get('y')}, Z={bathymetry_columns.get('z')}")
        
        # Create merged terrain model with TIN interpolation
        terrain_path, hillshade_path = create_merged_terrain_model(
            dem_path, bathymetry_path, bathymetry_columns, output_folder
        )
        print(f"Using merged terrain model: {terrain_path}")
        print(f"Hillshade created: {hillshade_path}")
    else:
        print("No bathymetry data provided, using DEM only")
        # Still create hillshade from DEM using GDAL
        hillshade_path = os.path.join(output_folder, "dem_hillshade.tif")
        create_hillshade_gdal(dem_path, hillshade_path)
    
    # Calculate timesteps from duration and timestep interval
    total_minutes = duration_hours * 60
    num_timesteps = int(total_minutes / timestep_minutes)
    
    print(f"📊 Calculated {num_timesteps} timesteps over {duration_hours} hours")
    
    # Run 2D Saint-Venant simulation with dynamic water levels
    sv_result = simulate_saint_venant_2d(
        dem_path=terrain_path,
        flow_rate=flow_q,
        manning_n=manning_n,
        duration_hours=duration_hours,
        timestep_minutes=timestep_minutes,
        num_timesteps=num_timesteps,
        output_folder=output_folder,
        bathymetry_path=bathymetry_path,
        bathymetry_columns=bathymetry_columns,
        hillshade_path=hillshade_path,
        water_levels=water_levels,  # Pass for fallback if needed
    )
    
    all_polygons = []
    for filename, timestep_num, simulation_time_hours, actual_water_level in sv_result:
        wet_array = load_raster_to_array_gdal(filename)
        threshold = kwargs.get('wet_threshold', 0.05)
        binary_mask = (wet_array > threshold)
        polygon_layer = polygonize_mask_gdal(binary_mask, filename, output_folder, timestep_num, actual_water_level)
        
        # Create descriptive layer name with both time and water level
        layer_name = f"Flood_T{timestep_num:03d}_{simulation_time_hours:.1f}h_{actual_water_level:.2f}m"
        polygon_layer.setName(layer_name)
        style_polygon_layer_blue_opacity(polygon_layer)
        QgsProject.instance().addMapLayer(polygon_layer)
        
        # Generate streamlines per timestep
        vx_path = filename.replace('depth', 'velocity_x')
        vy_path = filename.replace('depth', 'velocity_y')
        mask_path = filename
        gpkg_path = os.path.join(output_folder, f"streamlines_T{timestep_num:03d}_{simulation_time_hours:.1f}h.gpkg")
        create_streamlines_from_velocity_gdal(
            vx_path, vy_path, mask_path, gpkg_path, n_points=150, max_length=200, step=1.5
        )
        layer = QgsVectorLayer(gpkg_path, f"Streamlines_T{timestep_num:03d}_{simulation_time_hours:.1f}h", "ogr")
        QgsProject.instance().addMapLayer(layer)
        all_polygons.append(polygon_layer)
        
    return all_polygons

def create_merged_terrain_model(dem_path, bathymetry_path, bathymetry_columns, output_folder):
    """
    Create a merged terrain model from DEM + bathymetry using TIN interpolation.
    Uses GDAL for all raster operations.
    Returns the path to the merged terrain raster and hillshade.
    """
    import numpy as np
    from scipy.spatial import Delaunay
    from scipy.interpolate import griddata
    import pandas as pd
    
    print("Creating merged terrain model from DEM + bathymetry using GDAL...")
    
    # Load DEM using GDAL
    dem_dataset = gdal.Open(dem_path)
    if dem_dataset is None:
        raise ValueError(f"Cannot open DEM file: {dem_path}")
    
    dem_band = dem_dataset.GetRasterBand(1)
    dem_data = dem_band.ReadAsArray()
    geotransform = dem_dataset.GetGeoTransform()
    projection = dem_dataset.GetProjection()
    
    rows, cols = dem_data.shape
    
    # Generate coordinates efficiently using numpy broadcasting
    col_indices, row_indices = np.meshgrid(np.arange(cols), np.arange(rows))
    x_coords = geotransform[0] + col_indices * geotransform[1] + row_indices * geotransform[2]
    y_coords = geotransform[3] + col_indices * geotransform[4] + row_indices * geotransform[5]
    
    # Load bathymetry data
    if bathymetry_path.lower().endswith('.csv'):
        bathy_df = pd.read_csv(bathymetry_path)
        x_col = bathymetry_columns['x']
        y_col = bathymetry_columns['y']
        z_col = bathymetry_columns['z']
        
        bathy_x = bathy_df[x_col].values
        bathy_y = bathy_df[y_col].values
        bathy_z = bathy_df[z_col].values
    else:
        # Handle shapefile/geopackage bathymetry
        from osgeo import ogr
        driver = ogr.GetDriverByName("ESRI Shapefile" if bathymetry_path.endswith('.shp') else "GPKG")
        datasource = driver.Open(bathymetry_path)
        layer = datasource.GetLayer(0)
        
        bathy_x, bathy_y, bathy_z = [], [], []
        for feature in layer:
            geom = feature.GetGeometryRef()
            if geom.GetGeometryName() == 'POINT':
                x = geom.GetX()
                y = geom.GetY()
                # Assume elevation is in first field or 'elevation'/'z' field
                z = feature.GetField(0)  # Simplified - you may need to adjust field selection
                bathy_x.append(x)
                bathy_y.append(y)
                bathy_z.append(z)
        
        bathy_x = np.array(bathy_x)
        bathy_y = np.array(bathy_y)
        bathy_z = np.array(bathy_z)
    
    print(f"Loaded {len(bathy_x)} bathymetry points")
    
    # ✅ PRECISION-PRESERVING OPTIMIZATION:
    # Instead of combining ALL DEM pixels with bathymetry, use adaptive sampling
    # - Full precision in areas near bathymetry points
    # - Reduced sampling in areas far from water bodies
    # - Maintains accuracy where it matters most
    
    # Create spatial bounds for bathymetry influence
    if len(bathy_x) > 0:
        bathy_bounds = {
            'min_x': np.min(bathy_x),
            'max_x': np.max(bathy_x),
            'min_y': np.min(bathy_y),
            'max_y': np.max(bathy_y)
        }
        
        # Buffer around bathymetry points for high-precision interpolation
        pixel_size = abs(geotransform[1])
        buffer_distance = pixel_size * 10  # 10-pixel buffer for precision
        
        bathy_bounds['min_x'] -= buffer_distance
        bathy_bounds['max_x'] += buffer_distance
        bathy_bounds['min_y'] -= buffer_distance
        bathy_bounds['max_y'] += buffer_distance
        
        # Create mask for high-precision area (near bathymetry)
        precision_mask = (
            (x_coords >= bathy_bounds['min_x']) & 
            (x_coords <= bathy_bounds['max_x']) &
            (y_coords >= bathy_bounds['min_y']) & 
            (y_coords <= bathy_bounds['max_y'])
        )
        
        # Adaptive sampling: full resolution near bathymetry, coarser elsewhere
        high_precision_x = x_coords[precision_mask]
        high_precision_y = y_coords[precision_mask]
        high_precision_z = dem_data[precision_mask]
        
        # Coarser sampling for areas far from bathymetry (every 4th pixel)
        coarse_mask = ~precision_mask
        coarse_indices = np.where(coarse_mask)
        if len(coarse_indices[0]) > 0:
            # Subsample coarse areas to reduce computation while preserving overall shape
            step = 4  # Every 4th pixel
            coarse_subset = slice(None, None, step)
            coarse_x = x_coords[coarse_indices[0][coarse_subset], coarse_indices[1][coarse_subset]]
            coarse_y = y_coords[coarse_indices[0][coarse_subset], coarse_indices[1][coarse_subset]]
            coarse_z = dem_data[coarse_indices[0][coarse_subset], coarse_indices[1][coarse_subset]]
            
            # Combine high-precision and coarse-sampled points
            all_x = np.concatenate([high_precision_x.flatten(), coarse_x.flatten(), bathy_x])
            all_y = np.concatenate([high_precision_y.flatten(), coarse_y.flatten(), bathy_y])
            all_z = np.concatenate([high_precision_z.flatten(), coarse_z.flatten(), bathy_z])
        else:
            # All area is high-precision (small DEM)
            all_x = np.concatenate([high_precision_x.flatten(), bathy_x])
            all_y = np.concatenate([high_precision_y.flatten(), bathy_y])
            all_z = np.concatenate([high_precision_z.flatten(), bathy_z])
            
        print(f"💡 Adaptive sampling: {len(high_precision_x.flatten())} high-precision + {len(bathy_x)} bathymetry points")
        
    else:
        # No bathymetry data - use coarser DEM sampling for performance
        step = 2  # Every 2nd pixel when no bathymetry
        all_x = x_coords[::step, ::step].flatten()
        all_y = y_coords[::step, ::step].flatten()
        all_z = dem_data[::step, ::step].flatten()
    
    # Remove invalid values
    valid_mask = ~(np.isnan(all_x) | np.isnan(all_y) | np.isnan(all_z))
    all_x = all_x[valid_mask]
    all_y = all_y[valid_mask]
    all_z = all_z[valid_mask]
    
    print(f"Total points for interpolation: {len(all_x)}")
    
    # Create grid for interpolation
    grid_x, grid_y = np.meshgrid(
        np.linspace(x_coords.min(), x_coords.max(), cols),
        np.linspace(y_coords.min(), y_coords.max(), rows)
    )
    
    # Perform interpolation
    print("Performing TIN interpolation...")
    interpolated_z = griddata(
        (all_x, all_y), all_z, (grid_x, grid_y), 
        method='linear', fill_value=np.nan
    )
    
    # Fill NaN values with original DEM
    nan_mask = np.isnan(interpolated_z)
    interpolated_z[nan_mask] = dem_data[nan_mask]
    
    # Save merged terrain model
    merged_path = os.path.join(output_folder, "merged_terrain.tif")
    driver = gdal.GetDriverByName('GTiff')
    merged_dataset = driver.Create(merged_path, cols, rows, 1, gdal.GDT_Float32,
                                   options=['COMPRESS=LZW'])
    merged_dataset.SetGeoTransform(geotransform)
    merged_dataset.SetProjection(projection)
    merged_band = merged_dataset.GetRasterBand(1)
    merged_band.WriteArray(interpolated_z)
    merged_band.SetNoDataValue(np.nan)
    merged_dataset.FlushCache()
    
    # Create hillshade from merged terrain
    hillshade_path = os.path.join(output_folder, "merged_hillshade.tif")
    create_hillshade_gdal(merged_path, hillshade_path)
    
    # Close datasets
    dem_dataset = None
    merged_dataset = None
    
    print(f"Merged terrain model saved: {merged_path}")
    print(f"Hillshade saved: {hillshade_path}")
    
    return merged_path, hillshade_path

def load_bathymetry_points(bathymetry_path, bathymetry_columns):
    """Load bathymetry points from CSV or shapefile."""
    if not bathymetry_path or not bathymetry_columns:
        return None
        
    try:
        if bathymetry_path.lower().endswith(('.csv', '.txt')):
            # Load CSV bathymetry
            import pandas as pd
            df = pd.read_csv(bathymetry_path)
            
            x_col = bathymetry_columns.get('x')
            y_col = bathymetry_columns.get('y')
            z_col = bathymetry_columns.get('z')
            
            if x_col in df.columns and y_col in df.columns and z_col in df.columns:
                # Remove rows with NaN values
                df_clean = df[[x_col, y_col, z_col]].dropna()
                points = df_clean[[x_col, y_col, z_col]].values
                return points.astype(float)
            else:
                print(f"Error: Required columns not found in CSV: {x_col}, {y_col}, {z_col}")
                return None
                
        elif bathymetry_path.lower().endswith(('.shp', '.gpkg')):
            # Load shapefile/geopackage bathymetry
            import geopandas as gpd
            gdf = gpd.read_file(bathymetry_path)
            
            # Extract coordinates and elevation
            coords = []
            for idx, row in gdf.iterrows():
                geom = row.geometry
                if geom.geom_type == 'Point':
                    # Assume Z value is in a column (first numeric column found)
                    z_value = None
                    for col in gdf.columns:
                        if gdf[col].dtype in ['float64', 'int64'] and col != 'geometry':
                            z_value = row[col]
                            break
                    
                    if z_value is not None:
                        coords.append([geom.x, geom.y, z_value])
            
            if coords:
                return np.array(coords)
            else:
                print("No valid point geometries with elevation found in bathymetry file")
                return None
                
    except Exception as e:
        print(f"Error loading bathymetry data: {str(e)}")
        return None

def merge_dem_bathymetry_tin(dem_data, dem_x, dem_y, bathymetry_points):
    """Merge DEM and bathymetry using TIN interpolation."""
    from scipy.interpolate import griddata
    
    # Create mask for water areas (assume negative DEM values or areas where bathymetry exists)
    bathy_x = bathymetry_points[:, 0]
    bathy_y = bathymetry_points[:, 1] 
    bathy_z = bathymetry_points[:, 2]
    
    # Interpolate bathymetry to DEM grid using TIN (linear interpolation)
    print("Interpolating bathymetry using TIN...")
    
    # Flatten DEM coordinates for interpolation
    grid_points = np.column_stack((dem_x.ravel(), dem_y.ravel()))
    
    # Interpolate bathymetry values to grid
    try:
        interpolated_bathy = griddata(
            (bathy_x, bathy_y), bathy_z, 
            grid_points, 
            method='linear',
            fill_value=np.nan
        ).reshape(dem_data.shape)
        
        # Create merged terrain
        merged_terrain = dem_data.copy()
        
        # Where bathymetry is available and below DEM, use bathymetry
        valid_bathy_mask = ~np.isnan(interpolated_bathy)
        below_surface_mask = interpolated_bathy < dem_data
        
        # Use bathymetry where it's valid and below the DEM surface
        use_bathy_mask = valid_bathy_mask & below_surface_mask
        merged_terrain[use_bathy_mask] = interpolated_bathy[use_bathy_mask]
        
        print(f"Merged bathymetry into {np.sum(use_bathy_mask)} DEM cells")
        return merged_terrain
        
    except Exception as e:
        print(f"Error in TIN interpolation: {str(e)}")
        return dem_data

def create_hillshade_gdal(dem_path, output_path, azimuth=315, altitude=45):
    """Create hillshade from DEM using GDAL."""
    print(f"Creating hillshade using GDAL...")
    
    # Use gdaldem hillshade command
    from osgeo import gdal
    
    # Configure hillshade options
    options = gdal.DEMProcessingOptions(
        format='GTiff',
        creationOptions=['COMPRESS=LZW'],
        azimuth=azimuth,
        altitude=altitude
    )
    
    # Generate hillshade
    gdal.DEMProcessing(output_path, dem_path, 'hillshade', options=options)
    print(f"Hillshade saved: {output_path}")

def load_raster_to_array_gdal(raster_path):
    """Load raster data to numpy array using GDAL."""
    dataset = gdal.Open(raster_path)
    if dataset is None:
        raise ValueError(f"Cannot open raster file: {raster_path}")
    
    band = dataset.GetRasterBand(1)
    array = band.ReadAsArray()
    dataset = None
    return array

def polygonize_mask_gdal(binary_mask, dem_path, output_folder, timestep, water_level):
    """Convert binary mask to polygon using GDAL."""
    from qgis.core import QgsVectorLayer, QgsDataSourceUri
    import tempfile
    
    # Get spatial reference from DEM
    dem_dataset = gdal.Open(dem_path)
    geotransform = dem_dataset.GetGeoTransform()
    projection = dem_dataset.GetProjection()
    
    # Create temporary raster for the mask
    rows, cols = binary_mask.shape
    temp_tif = os.path.join(output_folder, f"temp_mask_{timestep}.tif")
    
    driver = gdal.GetDriverByName('GTiff')
    mask_dataset = driver.Create(temp_tif, cols, rows, 1, gdal.GDT_Byte)
    mask_dataset.SetGeoTransform(geotransform)
    mask_dataset.SetProjection(projection)
    mask_band = mask_dataset.GetRasterBand(1)
    mask_band.WriteArray(binary_mask.astype(np.uint8))
    mask_dataset.FlushCache()
    mask_dataset = None
    dem_dataset = None
    
    # Convert raster to vector using gdal_polygonize
    output_shp = os.path.join(output_folder, f"flood_polygons_{timestep:03d}_{water_level:.2f}m.shp")
    
    # Create output shapefile
    from osgeo import ogr, osr
    
    driver = ogr.GetDriverByName("ESRI Shapefile")
    if os.path.exists(output_shp):
        driver.DeleteDataSource(output_shp)
    
    datasource = driver.CreateDataSource(output_shp)
    
    # Create spatial reference
    srs = osr.SpatialReference()
    srs.ImportFromWkt(projection)
    
    layer = datasource.CreateLayer("flood", srs, ogr.wkbPolygon)
    
    # Add field for water level
    field_defn = ogr.FieldDefn("WaterLevel", ogr.OFTReal)
    layer.CreateField(field_defn)
    
    # Polygonize
    mask_dataset = gdal.Open(temp_tif)
    mask_band = mask_dataset.GetRasterBand(1)
    
    gdal.Polygonize(mask_band, None, layer, 0, [], callback=None)
    
    # Add water level attribute to all features
    layer.ResetReading()
    for feature in layer:
        feature.SetField("WaterLevel", water_level)
        layer.SetFeature(feature)
    
    # Clean up
    mask_dataset = None
    datasource = None
    
    # Remove temporary raster
    try:
        os.remove(temp_tif)
    except:
        pass
    
    # Create QGIS layer
    polygon_layer = QgsVectorLayer(output_shp, f"Flood_{timestep:03d}", "ogr")
    return polygon_layer

def create_streamlines_from_velocity_gdal(vx_path, vy_path, mask_path, output_gpkg, n_points=150, max_length=200, step=1.5):
    """Create streamlines from velocity fields using GDAL for raster I/O."""
    print(f"Creating streamlines from velocity fields...")
    
    try:
        # Load velocity and mask data using GDAL
        vx_array = load_raster_to_array_gdal(vx_path)
        vy_array = load_raster_to_array_gdal(vy_path)
        mask_array = load_raster_to_array_gdal(mask_path)
        
        # Get geospatial info
        dataset = gdal.Open(vx_path)
        geotransform = dataset.GetGeoTransform()
        projection = dataset.GetProjection()
        dataset = None
        
        # Create streamlines (simplified implementation)
        from osgeo import ogr, osr
        
        driver = ogr.GetDriverByName("GPKG")
        if os.path.exists(output_gpkg):
            driver.DeleteDataSource(output_gpkg)
        
        datasource = driver.CreateDataSource(output_gpkg)
        
        # Create spatial reference
        srs = osr.SpatialReference()
        srs.ImportFromWkt(projection)
        
        layer = datasource.CreateLayer("streamlines", srs, ogr.wkbLineString)
        
        # Add fields
        layer.CreateField(ogr.FieldDefn("ID", ogr.OFTInteger))
        layer.CreateField(ogr.FieldDefn("Velocity", ogr.OFTReal))
        
        # Generate streamlines (basic implementation)
        rows, cols = mask_array.shape
        valid_mask = (mask_array > 0.05) & (np.abs(vx_array) + np.abs(vy_array) > 0.01)
        
        if np.sum(valid_mask) == 0:
            print("No valid flow areas found for streamlines")
            datasource = None
            return
        
        # Sample starting points
        valid_indices = np.where(valid_mask)
        if len(valid_indices[0]) > n_points:
            # Subsample if too many points
            indices = np.random.choice(len(valid_indices[0]), n_points, replace=False)
            start_rows = valid_indices[0][indices]
            start_cols = valid_indices[1][indices]
        else:
            start_rows = valid_indices[0]
            start_cols = valid_indices[1]
        
        streamline_id = 0
        for start_row, start_col in zip(start_rows, start_cols):
            # Trace streamline
            points = []
            row, col = float(start_row), float(start_col)
            
            for _ in range(int(max_length / step)):
                if (row < 0 or row >= rows-1 or col < 0 or col >= cols-1 or
                    mask_array[int(row), int(col)] <= 0.05):
                    break
                
                # Convert pixel to geographic coordinates
                x = geotransform[0] + col * geotransform[1] + row * geotransform[2]
                y = geotransform[3] + col * geotransform[4] + row * geotransform[5]
                points.append((x, y))
                
                # Get velocity at current position
                vx = vx_array[int(row), int(col)]
                vy = vy_array[int(row), int(col)]
                
                if abs(vx) + abs(vy) < 0.01:
                    break
                
                # Move to next position
                pixel_size = abs(geotransform[1])
                row += vy * step / pixel_size
                col += vx * step / pixel_size
            
            # Create line feature if we have enough points
            if len(points) > 2:
                line_geom = ogr.Geometry(ogr.wkbLineString)
                for x, y in points:
                    line_geom.AddPoint(x, y)
                
                feature = ogr.Feature(layer.GetLayerDefn())
                feature.SetGeometry(line_geom)
                feature.SetField("ID", streamline_id)
                
                # Calculate average velocity
                avg_velocity = np.sqrt(vx_array[int(start_row), int(start_col)]**2 + 
                                     vy_array[int(start_row), int(start_col)]**2)
                feature.SetField("Velocity", float(avg_velocity))
                
                layer.CreateFeature(feature)
                feature = None
                streamline_id += 1
        
        datasource = None
        print(f"Created {streamline_id} streamlines in {output_gpkg}")
        
    except Exception as e:
        print(f"Error creating streamlines: {str(e)}")
        # Create empty file to prevent errors
        driver = ogr.GetDriverByName("GPKG")
        if os.path.exists(output_gpkg):
            driver.DeleteDataSource(output_gpkg)
        datasource = driver.CreateDataSource(output_gpkg)
        layer = datasource.CreateLayer("streamlines", None, ogr.wkbLineString)
        datasource = None

def style_polygon_layer_blue_opacity(layer):
    symbol = layer.renderer().symbol()
    symbol.setColor(QColor(70, 140, 255, 120))
    symbol.setOpacity(0.47)
    layer.triggerRepaint()

def simulate_saint_venant_2d(
    dem_path,
    flow_rate,
    manning_n,
    duration_hours,
    timestep_minutes,
    num_timesteps,
    output_folder,
    bathymetry_path=None,
    bathymetry_columns=None,
    hillshade_path=None,
    water_levels=None,
    **kwargs
):
    """
    2D Saint-Venant solver with automatic terrain model integration.
    
    Args:
        dem_path: Path to DEM or merged terrain model
        flow_rate: Flow rate in m³/s
        manning_n: Manning's roughness coefficient
        duration_hours: Simulation duration in hours
        timestep_minutes: Output timestep interval in minutes
        num_timesteps: Number of output timesteps
        output_folder: Output directory path
        bathymetry_path: Path to bathymetry data (CSV/shapefile)
        bathymetry_columns: Column mapping for bathymetry data
        hillshade_path: Path to hillshade raster for visualization
        water_levels: Optional list of water levels (if None, will be generated)
    
    Returns:
        List of (filename, timestep_number, simulation_time_hours, water_level) tuples
    """
    
    print(f"🌊 Starting 2D Saint-Venant simulation...")
    print(f"📍 Terrain model: {dem_path}")
    print(f"💧 Water levels: {water_levels}")
    print(f"🌊 Flow rate: {flow_rate} m³/s")
    print(f"🏔️ Manning's n: {manning_n}")
    if hillshade_path:
        print(f"🏔️ Hillshade available: {hillshade_path}")
    if bathymetry_path:
        print(f"🌊 Bathymetry integration: {bathymetry_path}")
    
    # Generate water levels if not provided
    if water_levels is None:
        # Create dynamic water levels based on duration and flow rate
        max_water_level = 2.0  # Base level
        if flow_rate:
            max_water_level += flow_rate / 100.0  # Scale with flow rate
        
        water_levels = list(np.linspace(0.5, max_water_level, num_timesteps))
        print(f"📊 Generated {len(water_levels)} dynamic water levels: {water_levels[0]:.2f}m to {water_levels[-1]:.2f}m")
    
    # TEMPORARY IMPLEMENTATION - Create mock flood simulation results
    # This allows testing the terrain integration and visualization pipeline
    
    print("⚠️  Using TEMPORARY mock implementation for testing")
    print("🔧 Replace this with your actual Saint-Venant 2D solver")
    print("🎯 ENHANCED with precision-preserving optimizations")
    
    # Load the DEM to get dimensions and geospatial info using GDAL
    dem_dataset = gdal.Open(dem_path)
    if dem_dataset is None:
        raise ValueError(f"Cannot open DEM file: {dem_path}")
    
    dem_band = dem_dataset.GetRasterBand(1)
    dem_data = dem_band.ReadAsArray()
    geotransform = dem_dataset.GetGeoTransform()
    projection = dem_dataset.GetProjection()
    height, width = dem_data.shape
    
    # 🔍 DIAGNOSTIC: Check DEM data integrity
    print(f"🔍 DEM DIAGNOSTICS:")
    print(f"   📐 DEM dimensions: {width} x {height} pixels")
    print(f"   📊 DEM data type: {dem_data.dtype}")
    print(f"   🎯 Raw DEM range: {np.nanmin(dem_data):.3f}m to {np.nanmax(dem_data):.3f}m")
    print(f"   ❌ NoData/NaN count: {np.sum(np.isnan(dem_data))} pixels")
    print(f"   🔢 Zero count: {np.sum(dem_data == 0)} pixels")
    print(f"   📏 Pixel size: {abs(geotransform[1]):.6f} units")
    
    # Check for NoData value issues
    nodata_value = dem_band.GetNoDataValue()
    if nodata_value is not None:
        print(f"   🚫 DEM NoData value: {nodata_value}")
        # Replace NoData values with NaN
        dem_data = np.where(dem_data == nodata_value, np.nan, dem_data)
        print(f"   ✅ Replaced {np.sum(dem_data == nodata_value)} NoData values with NaN")
    
    # Check elevation statistics after cleaning
    valid_elevations = dem_data[~np.isnan(dem_data)]
    if len(valid_elevations) > 0:
        print(f"   📈 Valid elevation stats:")
        print(f"      Min: {np.min(valid_elevations):.2f}m")
        print(f"      Max: {np.max(valid_elevations):.2f}m") 
        print(f"      Mean: {np.mean(valid_elevations):.2f}m")
        print(f"      Median: {np.median(valid_elevations):.2f}m")
        print(f"      25th percentile: {np.percentile(valid_elevations, 25):.2f}m")
        print(f"      75th percentile: {np.percentile(valid_elevations, 75):.2f}m")
    else:
        print(f"   ❌ ERROR: No valid elevation data found!")
        raise ValueError("DEM contains no valid elevation data")
    
    # Check coordinate system
    print(f"   🗺️ Projection: {projection[:100]}..." if len(projection) > 100 else projection)
    
    # ✅ PRECISION ENHANCEMENT 1: Identify critical flood zones
    # Pre-compute areas most likely to flood for enhanced precision
    pixel_size = abs(geotransform[1])
    dem_min = np.nanmin(dem_data)
    dem_max = np.nanmax(dem_data)
    max_water_level = max(water_levels) if water_levels else 3.0
    
    # Critical zone: areas within reasonable flooding range
    critical_elevation = dem_min + (max_water_level * 1.5)  # 50% buffer
    critical_zone_mask = dem_data <= critical_elevation
    
    print(f"📊 DEM range: {dem_min:.1f}m to {dem_max:.1f}m")
    print(f"🎯 Critical flood zone: {np.sum(critical_zone_mask)} pixels ({np.sum(critical_zone_mask)/dem_data.size*100:.1f}%)")
    
    # ✅ PRECISION ENHANCEMENT 2: Adaptive time stepping
    # Use smaller timesteps for rapid changes, larger for steady states
    def adaptive_water_level_progression(base_levels, flow_rate):
        """Create more precise water level progression with flow physics."""
        if flow_rate is None or flow_rate <= 0:
            return base_levels
            
        # Apply flow-based ramping curve for more realistic progression
        time_points = np.linspace(0, 1, len(base_levels))
        
        # Exponential rise with flow rate influence (more realistic than linear)
        flow_factor = min(flow_rate / 50.0, 2.0)  # Scale factor
        rise_curve = 1 - np.exp(-3 * time_points * flow_factor)
        
        # Apply curve to water level range
        min_level, max_level = min(base_levels), max(base_levels)
        enhanced_levels = min_level + (max_level - min_level) * rise_curve
        
        return enhanced_levels.tolist()
    
    # Enhance water levels with physics-based progression
    if flow_rate and flow_rate > 0:
        water_levels = adaptive_water_level_progression(water_levels, flow_rate)
        print(f"🌊 Enhanced water level progression with flow physics")
    
    results = []
    
    # Create mock flood simulation for each water level with enhanced precision
    for i, water_level in enumerate(water_levels):
        timestep = i + 1
        print(f"📊 Processing timestep {timestep}: {water_level:.2f}m water level")
        
        # ✅ REALISTIC FLOODING ALGORITHM - Flood fill from low points
        # Water doesn't magically appear everywhere - it flows from sources!
        
        # Create base flood depth
        flood_depth = np.zeros_like(dem_data, dtype=np.float32)
        
        # Step 1: Find realistic starting points for flooding (lowest areas)
        # Start flooding from the lowest 5% of the DEM (natural water collection points)
        dem_percentile_5 = np.percentile(dem_data[~np.isnan(dem_data)], 5)
        
        # Only start flooding from areas that are:
        # 1. In the lowest areas of the DEM
        # 2. Actually below the water level
        initial_flood_elevation = min(water_level, dem_percentile_5 + 1.0)  # Don't flood too high initially
        
        # Find seed points (lowest areas that can be flooded)
        seed_mask = (dem_data <= initial_flood_elevation) & (dem_data <= water_level - 0.5)
        
        if not np.any(seed_mask):
            # If no realistic seed points, use the very lowest points
            min_elevation = np.nanmin(dem_data)
            seed_mask = dem_data <= (min_elevation + 0.5)
        
        print(f"   🌱 Flood seeds: {np.sum(seed_mask)} pixels at elevation ≤ {initial_flood_elevation:.1f}m")
        
        # Step 2: Flood fill algorithm - water spreads from seeds following topography
        flood_mask = seed_mask.copy()
        
        # Iterative flood fill - water spreads to connected lower areas
        max_iterations = 10  # Prevent infinite loops
        for iteration in range(max_iterations):
            old_flood_count = np.sum(flood_mask)
            
            # Create a dilated (expanded) version of current flood
            from scipy import ndimage
            try:
                # Expand flood by 1 pixel in all directions
                expanded_flood = ndimage.binary_dilation(flood_mask, structure=np.ones((3,3)))
                
                # Water can only spread to areas that are:
                # 1. Not already flooded
                # 2. Below the water level 
                # 3. Not significantly higher than already flooded areas (max 1m step up)
                
                # Calculate average elevation of currently flooded areas
                if np.any(flood_mask):
                    avg_flood_elevation = np.mean(dem_data[flood_mask])
                    max_spread_elevation = min(water_level, avg_flood_elevation + 1.0)
                else:
                    max_spread_elevation = water_level
                
                # Allow spreading to new areas
                spreadable = (
                    ~flood_mask &  # Not already flooded
                    expanded_flood &  # Adjacent to current flood
                    (dem_data <= max_spread_elevation) &  # Not too high
                    (dem_data <= water_level)  # Below water level
                )
                
                flood_mask = flood_mask | spreadable
                
                new_flood_count = np.sum(flood_mask)
                
                # Stop if no new areas flooded
                if new_flood_count == old_flood_count:
                    break
                    
                print(f"   📈 Iteration {iteration+1}: {new_flood_count} flooded pixels")
                
            except ImportError:
                # Fallback without scipy - simple neighbor expansion
                # This is less sophisticated but still works
                expanded = np.zeros_like(flood_mask, dtype=bool)
                
                # Check 4-connected neighbors (up, down, left, right)
                for dy, dx in [(-1,0), (1,0), (0,-1), (0,1)]:
                    shifted = np.roll(np.roll(flood_mask, dy, axis=0), dx, axis=1)
                    # Only spread to areas below water level and not too high
                    spreadable = (
                        shifted & 
                        ~flood_mask & 
                        (dem_data <= water_level) &
                        (dem_data <= np.nanmean(dem_data[flood_mask]) + 1.0)
                    )
                    expanded = expanded | spreadable
                
                flood_mask = flood_mask | expanded
                
                if np.sum(expanded) == 0:
                    break
        
        # Step 3: Calculate realistic flood depths
        # Only in areas that were actually reached by flood fill
        potential_depth = np.maximum(0, water_level - dem_data)
        flood_depth = np.where(flood_mask, potential_depth, 0.0)
        
        # Apply reasonable depth limits
        flood_depth = np.minimum(flood_depth, 20.0)  # Max 20m depth
        
        # Remove very shallow floods (less than 5cm)
        flood_depth[flood_depth < 0.05] = 0.0
        
        flooded_area_pct = np.sum(flood_depth > 0) / dem_data.size * 100
        print(f"   🌊 Realistic flooded area: {np.sum(flood_depth > 0)} pixels ({flooded_area_pct:.1f}% of DEM)")
        print(f"   💧 Max flood depth: {np.max(flood_depth):.1f}m, avg: {np.mean(flood_depth[flood_depth > 0]):.1f}m")
        gradient_x = np.gradient(dem_data, axis=1)
        gradient_y = np.gradient(dem_data, axis=0)
        slope_magnitude = np.sqrt(gradient_x**2 + gradient_y**2)
        
        # Slope-dependent depth variations (steeper slopes drain better)
        slope_factor = np.clip(1.0 - slope_magnitude * 0.1, 0.8, 1.0)
        flood_depth *= slope_factor
        
        # Apply minimum depth threshold
        flood_depth[flood_depth < 0.05] = 0
        
        # Save depth raster using GDAL
        depth_filename = os.path.join(output_folder, f"depth_{timestep:03d}.tif")
        driver = gdal.GetDriverByName('GTiff')
        depth_dataset = driver.Create(depth_filename, width, height, 1, gdal.GDT_Float32,
                                     options=['COMPRESS=LZW'])
        depth_dataset.SetGeoTransform(geotransform)
        depth_dataset.SetProjection(projection)
        depth_band = depth_dataset.GetRasterBand(1)
        depth_band.WriteArray(flood_depth)
        depth_dataset.FlushCache()
        depth_dataset = None
        
        # ✅ PRECISION ENHANCEMENT 5: Enhanced velocity field generation
        # Instead of simple radial flow, use topography-driven flow direction
        
        # Calculate topographic gradients for realistic flow direction
        gradient_x = np.gradient(dem_data, axis=1, edge_order=2)
        gradient_y = np.gradient(dem_data, axis=0, edge_order=2)
        
        # Flow direction follows steepest descent (opposite to gradient)
        flow_direction_x = -gradient_x
        flow_direction_y = -gradient_y
        
        # Normalize flow directions
        flow_magnitude = np.sqrt(flow_direction_x**2 + flow_direction_y**2)
        flow_magnitude[flow_magnitude == 0] = 1  # Avoid division by zero
        
        unit_flow_x = flow_direction_x / flow_magnitude
        unit_flow_y = flow_direction_y / flow_magnitude
        
        # ✅ Enhanced velocity calculation based on Manning's equation
        # v = (1/n) * R^(2/3) * S^(1/2), where R ≈ depth, S = slope
        if manning_n and manning_n > 0:
            # Hydraulic radius approximation: R ≈ depth for wide shallow flow
            hydraulic_radius = flood_depth
            
            # Slope magnitude (already calculated)
            slope = np.maximum(flow_magnitude, 0.001)  # Minimum slope to avoid zero
            
            # Manning's velocity calculation
            velocity_magnitude = np.where(
                flood_depth > 0.05,
                (1.0 / manning_n) * np.power(hydraulic_radius, 2.0/3.0) * np.power(slope, 0.5),
                0
            )
            
            # Scale by flow rate influence
            if flow_rate and flow_rate > 0:
                flow_scale = min(2.0, flow_rate / 50.0)  # More realistic scaling
                velocity_magnitude *= flow_scale
                
        else:
            # Fallback: simple velocity based on depth and slope
            velocity_magnitude = np.where(
                flood_depth > 0, 
                0.5 * np.sqrt(flood_depth) * np.sqrt(flow_magnitude + 0.001), 
                0
            )
        
        # Apply flow direction to velocity magnitude
        velocity_x = velocity_magnitude * unit_flow_x
        velocity_y = velocity_magnitude * unit_flow_y
        
        # ✅ PRECISION ENHANCEMENT 6: Velocity smoothing for numerical stability
        # Apply light smoothing to prevent unrealistic velocity spikes
        try:
            from scipy import ndimage
            # Light Gaussian smoothing (sigma=0.5) for stability
            velocity_x = ndimage.gaussian_filter(velocity_x, sigma=0.5)
            velocity_y = ndimage.gaussian_filter(velocity_y, sigma=0.5)
        except ImportError:
            pass  # Skip smoothing if scipy not available
        
        # Save velocity rasters using GDAL
        vx_filename = os.path.join(output_folder, f"velocity_x_{timestep:03d}.tif")
        vy_filename = os.path.join(output_folder, f"velocity_y_{timestep:03d}.tif")
        
        for vel_data, vel_filename in [(velocity_x, vx_filename), (velocity_y, vy_filename)]:
            driver = gdal.GetDriverByName('GTiff')
            vel_dataset = driver.Create(vel_filename, width, height, 1, gdal.GDT_Float32,
                                       options=['COMPRESS=LZW'])
            vel_dataset.SetGeoTransform(geotransform)
            vel_dataset.SetProjection(projection)
            vel_band = vel_dataset.GetRasterBand(1)
            vel_band.WriteArray(vel_data)
            vel_dataset.FlushCache()
            vel_dataset = None
        
        # Calculate simulation time in hours for this timestep
        simulation_time_hours = (timestep * timestep_minutes) / 60.0
        
        results.append((depth_filename, timestep, simulation_time_hours, water_level))
        print(f"✅ Saved: {depth_filename}")
    
    # Close the DEM dataset
    dem_dataset = None
    
    print(f"🎉 Mock simulation complete! Generated {len(results)} timesteps")
    print("🔧 NEXT STEP: Replace this mock implementation with your actual Saint-Venant solver")
    
    return results
