#!/usr/bin/env python3
"""
Comprehensive FloodEngine v4.0 Visualization Test Suite
======================================================

Tests all visualization features with proper error handling and dependency management.
"""

import os
import sys
import numpy as np
import traceback
import tempfile
from pathlib import Path

def print_header(title):
    """Print a formatted header."""
    print("\n" + "=" * 60)
    print(f" {title}")
    print("=" * 60)

def print_section(title):
    """Print a formatted section header."""
    print(f"\n🔬 {title}")
    print("-" * 40)

def check_dependency(module_name, description=""):
    """Check if a dependency is available."""
    try:
        __import__(module_name)
        print(f"✅ {module_name}: Available {description}")
        return True
    except ImportError:
        print(f"❌ {module_name}: Missing {description}")
        return False
    except Exception as e:
        print(f"⚠️ {module_name}: Error - {e}")
        return False

def main():
    """Main test function."""
    print_header("FloodEngine v4.0 - Advanced Visualization Test Suite")
    
    # Set working directory
    working_dir = Path("c:/Plugin/VSCode/FloodEngine_fixed_v8")
    os.chdir(str(working_dir))
    print(f"📁 Working directory: {os.getcwd()}")
    
    # Phase 1: Dependency Check
    print_section("Phase 1: Dependency Validation")
    
    # Core dependencies
    core_deps = {
        'numpy': 'Numerical computing',
        'matplotlib': '2D plotting and basic animation'
    }
    
    core_available = True
    for dep, desc in core_deps.items():
        if not check_dependency(dep, desc):
            core_available = False
    
    if not core_available:
        print("❌ Core dependencies missing - cannot continue")
        return False
    
    # Optional visualization dependencies
    viz_deps = {
        'vtk': '3D visualization engine',
        'plotly': 'Interactive plotting',
        'dash': 'Web-based interfaces',
        'imageio': 'Animation export',
        'pillow': 'Image processing',
        'moderngl': 'GPU acceleration (optional)',
        'openvr': 'VR/AR support (optional)'
    }
    
    available_features = []
    for dep, desc in viz_deps.items():
        if check_dependency(dep, desc):
            available_features.append(dep)
    
    print(f"\n📊 Available visualization features: {len(available_features)}/{len(viz_deps)}")
    
    # Phase 2: Module Import Test
    print_section("Phase 2: FloodEngine Visualization Module Import")
    
    try:
        print("🔍 Importing advanced_visualization_features module...")
        import advanced_visualization_features as viz_module
        print("✅ Successfully imported visualization module")
        
        # Test individual class imports
        classes_to_test = [
            'FloodEngineVisualizationManager',
            'VisualizationConfig',
            'FloodVisualization3D',
            'FloodAnimationGenerator',
            'InteractiveFloodAnalysis'
        ]
        
        for class_name in classes_to_test:
            try:
                getattr(viz_module, class_name)
                print(f"✅ {class_name}: Available")
            except AttributeError:
                print(f"❌ {class_name}: Not found in module")
    
    except Exception as e:
        print(f"❌ Failed to import visualization module: {e}")
        traceback.print_exc()
        return False
    
    # Phase 3: Visualization Manager Test
    print_section("Phase 3: Visualization Manager Initialization")
    
    try:
        # Create output directory
        output_dir = Path("test_viz_output")
        output_dir.mkdir(exist_ok=True)
        
        # Initialize visualization manager
        from advanced_visualization_features import FloodEngineVisualizationManager
        viz_manager = FloodEngineVisualizationManager(str(output_dir))
        print("✅ Visualization manager initialized successfully")
        
        # Check capabilities
        print("\n📋 Available capabilities:")
        capability_count = 0
        total_capabilities = len(viz_manager.capabilities)
        
        for capability, available in viz_manager.capabilities.items():
            status = "✅" if available else "❌"
            print(f"  {status} {capability}")
            if available:
                capability_count += 1
        
        print(f"\n📈 Capabilities available: {capability_count}/{total_capabilities}")
        
    except Exception as e:
        print(f"❌ Failed to initialize visualization manager: {e}")
        traceback.print_exc()
        return False
    
    # Phase 4: Component Creation Test
    print_section("Phase 4: Visualization Component Creation")
    
    components_tested = 0
    components_successful = 0
    
    # Test 3D Visualization
    if viz_manager.capabilities.get('3d_visualization', False):
        try:
            viz_3d = viz_manager.create_3d_visualization()
            print("✅ 3D visualization component created")
            components_successful += 1
        except Exception as e:
            print(f"❌ 3D visualization failed: {e}")
        components_tested += 1
    else:
        print("⚠️ 3D visualization not available (VTK missing)")
    
    # Test Animation Generator
    if viz_manager.capabilities.get('animation_generation', False):
        try:
            anim_gen = viz_manager.create_animation_generator()
            print("✅ Animation generator created")
            components_successful += 1
        except Exception as e:
            print(f"❌ Animation generator failed: {e}")
        components_tested += 1
    else:
        print("⚠️ Animation generation not available")
    
    # Test Interactive Analysis
    if viz_manager.capabilities.get('interactive_analysis', False):
        try:
            interactive = viz_manager.create_interactive_analysis()
            print("✅ Interactive analysis component created")
            components_successful += 1
        except Exception as e:
            print(f"❌ Interactive analysis failed: {e}")
        components_tested += 1
    else:
        print("⚠️ Interactive analysis not available")
    
    print(f"\n📊 Components successful: {components_successful}/{components_tested}")
    
    # Phase 5: Sample Data Test
    print_section("Phase 5: Sample Data Processing")
    
    try:
        # Create sample flood data
        x = np.linspace(0, 100, 50)
        y = np.linspace(0, 100, 50)
        X, Y = np.meshgrid(x, y)
        
        # Sample elevation data (simple terrain)
        Z = 10 + 0.1 * X + 0.05 * Y + 2 * np.sin(0.1 * X) * np.cos(0.1 * Y)
        
        # Sample water depth data
        water_depth = np.maximum(0, 5 - 0.05 * np.sqrt((X - 50)**2 + (Y - 50)**2))
        
        print("✅ Sample data created successfully")
        
        # Test basic visualization if matplotlib is available
        try:
            import matplotlib.pyplot as plt
            
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
            
            # Plot elevation
            im1 = ax1.contourf(X, Y, Z, levels=20, cmap='terrain')
            ax1.set_title('Terrain Elevation')
            ax1.set_xlabel('X (m)')
            ax1.set_ylabel('Y (m)')
            plt.colorbar(im1, ax=ax1, label='Elevation (m)')
            
            # Plot water depth
            im2 = ax2.contourf(X, Y, water_depth, levels=20, cmap='Blues')
            ax2.set_title('Water Depth')
            ax2.set_xlabel('X (m)')
            ax2.set_ylabel('Y (m)')
            plt.colorbar(im2, ax=ax2, label='Depth (m)')
            
            # Save the plot
            output_file = output_dir / "sample_visualization.png"
            plt.savefig(str(output_file), dpi=150, bbox_inches='tight')
            plt.close()
            
            print(f"✅ Sample visualization saved to: {output_file}")
            
        except Exception as e:
            print(f"⚠️ Basic visualization test failed: {e}")
    
    except Exception as e:
        print(f"❌ Sample data processing failed: {e}")
        traceback.print_exc()
    
    # Phase 6: Integration Check
    print_section("Phase 6: FloodEngine Integration Check")
    
    try:
        # Test integration with core FloodEngine modules
        floodengine_modules = [
            'saint_venant_2d',
            'model_hydraulic',
            'advanced_analysis_tools'
        ]
        
        integration_available = 0
        for module in floodengine_modules:
            try:
                __import__(module)
                print(f"✅ {module}: Available for integration")
                integration_available += 1
            except ImportError:
                print(f"⚠️ {module}: Not available")
        
        print(f"📊 Integration modules available: {integration_available}/{len(floodengine_modules)}")
        
    except Exception as e:
        print(f"❌ Integration check failed: {e}")
    
    # Final Summary
    print_header("Test Summary")
    
    print(f"✅ Core dependencies: Available")
    print(f"📊 Visualization features: {len(available_features)}/{len(viz_deps)} available")
    print(f"🎯 Components tested: {components_successful}/{components_tested} successful")
    print(f"🔗 Integration ready: {integration_available}/{len(floodengine_modules)} modules")
    
    success_rate = (components_successful / max(components_tested, 1)) * 100
    print(f"\n🎉 Overall success rate: {success_rate:.1f}%")
    
    if success_rate >= 50:
        print("🚀 FloodEngine v4.0 visualization system is ready for use!")
        return True
    else:
        print("⚠️ Some issues detected - manual intervention may be required")
        return False

if __name__ == "__main__":
    try:
        success = main()
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"\n💥 Critical error in test suite: {e}")
        traceback.print_exc()
        sys.exit(1)
