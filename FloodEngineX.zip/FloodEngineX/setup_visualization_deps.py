#!/usr/bin/env python3
"""
FloodEngine v4.0 - Dependency Installation and Validation Script
================================================================

This script installs required dependencies for advanced visualization features
and validates the installation.
"""

import subprocess
import sys
import importlib
import os

def run_command(cmd):
    """Run a command and return success status."""
    try:
        print(f"🔧 Running: {cmd}")
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=300)
        if result.returncode == 0:
            print("✅ Command successful")
            if result.stdout:
                print(result.stdout)
            return True
        else:
            print(f"❌ Command failed with return code {result.returncode}")
            if result.stderr:
                print(f"Error: {result.stderr}")
            return False
    except subprocess.TimeoutExpired:
        print("⏰ Command timed out")
        return False
    except Exception as e:
        print(f"❌ Exception running command: {e}")
        return False

def check_dependency(module_name, description=""):
    """Check if a dependency is available."""
    try:
        importlib.import_module(module_name)
        print(f"✅ {module_name}: Available {description}")
        return True
    except ImportError:
        print(f"❌ {module_name}: Missing {description}")
        return False

print("=" * 70)
print("FloodEngine v4.0 - Advanced Visualization Setup")
print("=" * 70)

# Check Python version
print(f"\n🐍 Python version: {sys.version}")
print(f"📁 Python executable: {sys.executable}")

# Update pip first
print("\n🔄 Updating pip...")
run_command(f"{sys.executable} -m pip install --upgrade pip")

# Core dependencies that should already be available
print("\n🔍 Checking core dependencies...")
core_deps = {
    'numpy': 'Numerical computing',
    'matplotlib': '2D plotting',
    'scipy': 'Scientific computing (if available)'
}

for dep, desc in core_deps.items():
    check_dependency(dep, desc)

# Install visualization dependencies
print("\n🎨 Installing visualization dependencies...")
viz_deps = [
    'vtk',           # 3D visualization
    'plotly',        # Interactive plots
    'dash',          # Web interfaces
    'kaleido',       # Static image export for plotly
    'dash-bootstrap-components',  # Enhanced UI components
]

for dep in viz_deps:
    print(f"\n📦 Installing {dep}...")
    success = run_command(f"{sys.executable} -m pip install {dep}")
    if success:
        check_dependency(dep)

# Optional advanced dependencies
print("\n🚀 Installing optional advanced dependencies...")
optional_deps = [
    'moderngl',      # GPU acceleration
    'pillow',        # Image processing
    'imageio',       # Animation export
    'imageio-ffmpeg' # Video export
]

for dep in optional_deps:
    print(f"\n📦 Installing {dep}...")
    run_command(f"{sys.executable} -m pip install {dep}")
    check_dependency(dep)

# Final validation
print("\n" + "=" * 70)
print("🔍 FINAL VALIDATION")
print("=" * 70)

print("\n📊 Checking all dependencies:")
all_deps = {
    'numpy': 'Core numerical computing',
    'matplotlib': 'Core plotting',
    'vtk': '3D visualization engine',
    'plotly': 'Interactive plotting',
    'dash': 'Web-based interfaces',
    'kaleido': 'Static image export',
    'moderngl': 'GPU acceleration (optional)',
    'pillow': 'Image processing (optional)',
    'imageio': 'Animation export (optional)'
}

available_count = 0
total_count = len(all_deps)

for dep, desc in all_deps.items():
    if check_dependency(dep, desc):
        available_count += 1

print(f"\n📈 Dependencies available: {available_count}/{total_count}")

# Test FloodEngine visualization module
print("\n🔬 Testing FloodEngine visualization module...")
try:
    # Change to the FloodEngine directory
    os.chdir(r"c:\Plugin\VSCode\FloodEngine_fixed_v8")
    import advanced_visualization_features
    print("✅ Advanced visualization module imported successfully!")
    
    # Test visualization manager
    from advanced_visualization_features import FloodEngineVisualizationManager
    viz_manager = FloodEngineVisualizationManager("test_output")
    print("✅ Visualization manager created successfully!")
    
    print("\n📊 Available visualization capabilities:")
    for capability, available in viz_manager.capabilities.items():
        status = "✅" if available else "⚠️"
        print(f"  {status} {capability}")
        
except Exception as e:
    print(f"❌ Error testing visualization module: {e}")
    import traceback
    traceback.print_exc()

print("\n🎉 Setup and validation complete!")
print("=" * 70)
