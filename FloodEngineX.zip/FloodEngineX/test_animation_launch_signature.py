#!/usr/bin/env python3
"""
Quick test to verify animation dialog launch works properly
"""

import sys
import os
from pathlib import Path

# Add current directory to path
script_dir = Path(__file__).parent
sys.path.insert(0, str(script_dir))

def test_animation_launch():
    """Test launching animation dialog with parent parameter."""
    
    print("🧪 Testing animation dialog launch...")
    
    try:
        # Import the function
        from launch_animation import launch_animation_from_folder
        import inspect
        
        # Show function signature
        sig = inspect.signature(launch_animation_from_folder)
        print(f"✅ Function signature: {sig}")
        
        # Test with a mock folder (that doesn't exist, should fail gracefully)
        test_folder = "test_animation_folder"
        
        print(f"🧪 Testing call with parent=None...")
        result = launch_animation_from_folder(test_folder, standalone=True, parent=None)
        print(f"✅ Function call succeeded, returned: {result}")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True

if __name__ == "__main__":
    success = test_animation_launch()
    if success:
        print("✅ Test completed successfully")
    else:
        print("❌ Test failed")
