"""
Simple test script to verify the fix for water flowing from highest elevation points
"""

import os
import sys
import numpy as np
import traceback

try:
    print("Starting dam flow test...")
    
    # Import from fixed model
    from saint_venant_2d import SaintVenant2D
    print("Successfully imported SaintVenant2D")
    
    # Create a simple DEM with a channel and dam
    dem_size = 20
    dem = np.ones((dem_size, dem_size)) * 10.0  # Base elevation
    
    # Create a channel with decreasing elevation from top to bottom
    for i in range(dem_size):
        # Create a channel in the middle (columns 8-12)
        dem[i, 8:12] = 9.0 - (i / dem_size) * 2.0
    
    # Add a dam across the channel at row 15
    dam_row = 15
    for j in range(7, 13):  # Make dam slightly wider than channel
        dem[dam_row, j] = 9.5  # Dam is 0.5m higher than channel start
    
    print("Created test DEM with channel and dam")
    
    # Setup model with the DEM
    geotransform = (0, 10, 0, 0, 0, -10)  # 10m cell size
    print("Creating SaintVenant2D model...")
    model = SaintVenant2D(dem, geotransform)
    print("Model created successfully")
    
    # Set initial water level just above the highest point of the channel
    initial_water_level = 9.2
    print(f"Setting initial water level to {initial_water_level}m")
    model.set_initial_condition(water_level=initial_water_level)
    print("Initial conditions set")
    
    # Verify water is initialized correctly
    if np.max(model.h) > 0:
        print(f"Water initialized. Max depth: {np.max(model.h):.2f}m")
        wet_cells = np.sum(model.h > 0.01)
        print(f"Initial wet cells: {wet_cells}")
    else:
        print("ERROR: No water was initialized")
        sys.exit(1)
    
    # Find highest point in river (wet cells)
    wet_mask = model.h > 0.01
    if np.sum(wet_mask) > 0:
        river_elevations = np.where(wet_mask, dem, -np.inf)
        highest_idx = np.unravel_index(np.argmax(river_elevations), dem.shape)
        py, px = highest_idx
        print(f"Highest point in river: ({px}, {py}) with elevation {dem[py, px]:.2f}m")
    
        # Run simulation steps
        print("\nRunning simulation steps...")
        total_steps = 10
        
        for step in range(total_steps):
            print(f"Starting step {step+1}...")
            
            # Add water at highest point (simulate inflow)
            model.h[py, px] += 0.1  # Add 10cm of water per step
            
            # Set initial flow direction downhill
            # Find steepest downhill direction
            max_slope = 0
            flow_dir_x, flow_dir_y = 0, 0
            
            for dy in [-1, 0, 1]:
                ny = py + dy
                if ny < 0 or ny >= model.shape[0]:
                    continue
                    
                for dx in [-1, 0, 1]:
                    nx = px + dx
                    if nx < 0 or nx >= model.shape[1]:
                        continue
                    if dx == 0 and dy == 0:
                        continue
                        
                    # Calculate slope (positive = downhill)
                    slope = dem[py, px] - dem[ny, nx]
                    if slope > max_slope:
                        max_slope = slope
                        flow_dir_y, flow_dir_x = dy, dx
            
            # Set velocity in steepest downhill direction
            if max_slope > 0:
                magnitude = 0.5  # Conservative velocity
                if flow_dir_x != 0:
                    model.qx[py, px] = model.h[py, px] * magnitude * np.sign(flow_dir_x)
                if flow_dir_y != 0:
                    model.qy[py, px] = model.h[py, px] * magnitude * np.sign(flow_dir_y)
            
            # Run a simulation step
            print(f"Calculating timestep...")
            dt = model.calculate_timestep()
            print(f"Running model step with dt={dt:.3f}...")
            actual_dt = model.step(dt)
            
            # Calculate water depths and locations
            water_surface = model.get_water_surface()
            water_depth = np.maximum(water_surface - dem, 0)
            
            # Check depths before and after dam
            upstream_depths = water_depth[dam_row-2:dam_row, 8:12]
            downstream_depths = water_depth[dam_row+1:dam_row+3, 8:12]
            
            print(f"Step {step+1}: dt={actual_dt:.2f}s, "
                  f"Max depth={np.max(water_depth):.2f}m, "
                  f"Upstream avg={np.mean(upstream_depths):.2f}m, "
                  f"Downstream avg={np.mean(downstream_depths):.2f}m")
    
    # Final analysis
    print("\nFinal water distribution:")
    water_surface = model.get_water_surface()
    water_depth = np.maximum(water_surface - dem, 0)
    
    # Check upstream vs downstream depths
    upstream_avg = np.mean(water_depth[dam_row-5:dam_row, 8:12])
    downstream_avg = np.mean(water_depth[dam_row+1:dam_row+5, 8:12])
    
    print(f"Final upstream average depth: {upstream_avg:.2f}m")
    print(f"Final downstream average depth: {downstream_avg:.2f}m")
    
    # Check if water accumulated properly behind dam
    if upstream_avg > downstream_avg:
        print("SUCCESS: Water properly accumulated behind dam")
    else:
        print("FAILURE: Water did not accumulate properly behind dam")
    
    print("Test completed")

except Exception as e:
    print(f"Error occurred: {e}")
    traceback.print_exc()
