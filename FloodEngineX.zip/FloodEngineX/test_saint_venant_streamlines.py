#!/usr/bin/env python3
"""
Test script to verify Saint-Venant velocity files can be loaded and used in streamlines.
This script tests the enhanced streamlines functionality with Saint-Venant velocity files.
"""

import os
import sys
import numpy as np
import logging
from pathlib import Path

# Add the FloodEngineX directory to the Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import the enhanced streamlines module
from enhanced_streamlines import load_saint_venant_velocity_files, EnhancedStreamlines

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("TestSaintVenantStreamlines")

def test_saint_venant_velocity_loading():
    """Test loading Saint-Venant velocity files from different output folders."""
    
    # Test directories where Saint-Venant results might be stored
    test_directories = [
        "C:/Plugin/VSCode/Alt3/FloodEngineX/results",
        "C:/Plugin/VSCode/Alt3/FloodEngineX/output",
        "C:/Plugin/VSCode/Alt3/FloodEngineX/saint_venant_results",
        "C:/Plugin/VSCode/Alt3/FloodEngineX",
        "C:/Plugin/VSCode/Alt3/FloodEngineX/test_data"
    ]
    
    logger.info("🧪 Testing Saint-Venant velocity file loading...")
    
    for test_dir in test_directories:
        if os.path.exists(test_dir):
            logger.info(f"📁 Checking directory: {test_dir}")
            
            # List all files in the directory
            files = [f for f in os.listdir(test_dir) if f.lower().endswith(('.tif', '.tiff'))]
            if files:
                logger.info(f"   Found {len(files)} TIFF files:")
                for file in files:
                    logger.info(f"     • {file}")
            else:
                logger.info("   No TIFF files found")
            
            # Try to load Saint-Venant velocity files from this directory
            saint_venant_results = load_saint_venant_velocity_files(test_dir)
            
            if saint_venant_results is not None:
                logger.info(f"✅ Successfully loaded Saint-Venant velocity files from {test_dir}")
                
                # Report statistics
                vx_shape = saint_venant_results['velocity_x'].shape
                vy_shape = saint_venant_results['velocity_y'].shape
                max_vel = np.max(saint_venant_results['velocity_magnitude'])
                mean_vel = np.mean(saint_venant_results['velocity_magnitude'][saint_venant_results['velocity_magnitude'] > 0])
                
                logger.info(f"   • Velocity X shape: {vx_shape}")
                logger.info(f"   • Velocity Y shape: {vy_shape}")
                logger.info(f"   • Maximum velocity: {max_vel:.3f} m/s")
                logger.info(f"   • Mean velocity: {mean_vel:.3f} m/s")
                
                return test_dir, saint_venant_results
            else:
                logger.info(f"❌ No Saint-Venant velocity files found in {test_dir}")
        else:
            logger.info(f"📁 Directory does not exist: {test_dir}")
    
    logger.warning("⚠️  No Saint-Venant velocity files found in any test directory")
    return None, None

def create_test_velocity_files(output_dir):
    """Create synthetic Saint-Venant velocity files for testing."""
    
    logger.info(f"🔧 Creating synthetic Saint-Venant velocity files in {output_dir}")
    
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Create synthetic velocity data (100x100 grid)
    rows, cols = 100, 100
    
    # Create a synthetic flow pattern (flow from northwest to southeast)
    y_indices, x_indices = np.meshgrid(np.arange(rows), np.arange(cols), indexing='ij')
    
    # Create velocity components for a diagonal flow pattern
    velocity_x = 0.5 + 0.3 * np.sin(x_indices * 0.1) * np.cos(y_indices * 0.1)
    velocity_y = 0.3 + 0.2 * np.cos(x_indices * 0.1) * np.sin(y_indices * 0.1)
    
    # Calculate velocity magnitude
    velocity_magnitude = np.sqrt(velocity_x**2 + velocity_y**2)
    
    # Create realistic velocity ranges (0.1 - 2.0 m/s)
    velocity_x = np.clip(velocity_x, -2.0, 2.0)
    velocity_y = np.clip(velocity_y, -2.0, 2.0)
    velocity_magnitude = np.clip(velocity_magnitude, 0.1, 2.0)
    
    # Create geotransform (arbitrary coordinates)
    geotransform = (100000, 10, 0, 200000, 0, -10)
    
    # Save as TIFF files using GDAL
    from osgeo import gdal
    
    # Create velocity_x file
    vx_path = os.path.join(output_dir, "velocity_x.tif")
    driver = gdal.GetDriverByName('GTiff')
    vx_ds = driver.Create(vx_path, cols, rows, 1, gdal.GDT_Float32)
    vx_ds.SetGeoTransform(geotransform)
    vx_ds.GetRasterBand(1).WriteArray(velocity_x)
    vx_ds.GetRasterBand(1).SetNoDataValue(-9999)
    vx_ds = None
    
    # Create velocity_y file
    vy_path = os.path.join(output_dir, "velocity_y.tif")
    vy_ds = driver.Create(vy_path, cols, rows, 1, gdal.GDT_Float32)
    vy_ds.SetGeoTransform(geotransform)
    vy_ds.GetRasterBand(1).WriteArray(velocity_y)
    vy_ds.GetRasterBand(1).SetNoDataValue(-9999)
    vy_ds = None
    
    # Create velocity_magnitude file
    vmag_path = os.path.join(output_dir, "velocity_magnitude.tif")
    vmag_ds = driver.Create(vmag_path, cols, rows, 1, gdal.GDT_Float32)
    vmag_ds.SetGeoTransform(geotransform)
    vmag_ds.GetRasterBand(1).WriteArray(velocity_magnitude)
    vmag_ds.GetRasterBand(1).SetNoDataValue(-9999)
    vmag_ds = None
    
    logger.info(f"✅ Created synthetic velocity files:")
    logger.info(f"   • {vx_path}")
    logger.info(f"   • {vy_path}")
    logger.info(f"   • {vmag_path}")
    
    return output_dir

def test_streamlines_with_saint_venant():
    """Test the streamlines generation with Saint-Venant velocity files."""
    
    logger.info("🧪 Testing streamlines generation with Saint-Venant velocity files...")
    
    # First, try to find existing Saint-Venant files
    test_dir, saint_venant_results = test_saint_venant_velocity_loading()
    
    if saint_venant_results is None:
        # Create synthetic test data
        test_dir = create_test_velocity_files("C:/Plugin/VSCode/Alt3/FloodEngineX/test_saint_venant")
        saint_venant_results = load_saint_venant_velocity_files(test_dir)
    
    if saint_venant_results is not None:
        logger.info("✅ Testing streamlines with Saint-Venant velocity data...")
        
        # Create a synthetic DEM that matches the velocity field shape
        dem_shape = saint_venant_results['velocity_x'].shape
        dem_array = np.random.rand(*dem_shape) * 10 + 100  # Elevation 100-110m
        
        # Create a synthetic geotransform
        geotransform = (100000, 10, 0, 200000, 0, -10)
        
        # Create water depth array
        water_depth = np.ones(dem_shape) * 1.5  # 1.5m water depth everywhere
        
        # Initialize streamlines generator
        streamlines_generator = EnhancedStreamlines(dem_array, geotransform, water_depth=water_depth)
        
        # Test velocity field calculation with Saint-Venant method
        logger.info("🔧 Testing velocity field calculation with Saint-Venant method...")
        
        velocity_x, velocity_y, velocity_mag = streamlines_generator.calculate_velocity_field(
            manning_n=0.035, 
            method="saint_venant", 
            saint_venant_results=saint_venant_results
        )
        
        # Verify results
        logger.info(f"✅ Velocity field calculation completed:")
        logger.info(f"   • Velocity X range: {np.min(velocity_x):.3f} to {np.max(velocity_x):.3f} m/s")
        logger.info(f"   • Velocity Y range: {np.min(velocity_y):.3f} to {np.max(velocity_y):.3f} m/s")
        logger.info(f"   • Velocity magnitude range: {np.min(velocity_mag):.3f} to {np.max(velocity_mag):.3f} m/s")
        logger.info(f"   • Cells with velocity > 0.1 m/s: {np.sum(velocity_mag > 0.1)}")
        
        # Test streamlines generation
        logger.info("🔧 Testing streamlines generation...")
        
        # Create flood mask (assume all cells are flooded)
        flood_mask = water_depth > 0.01
        
        # Generate streamlines
        streamlines = streamlines_generator.generate_streamlines(
            flood_mask=flood_mask,
            num_seeds=50  # Smaller number for testing
        )
        
        logger.info(f"✅ Generated {len(streamlines)} streamlines")
        
        # Check streamline quality
        total_points = sum(len(streamline) for streamline in streamlines)
        avg_points_per_streamline = total_points / len(streamlines) if streamlines else 0
        
        logger.info(f"   • Total points: {total_points}")
        logger.info(f"   • Average points per streamline: {avg_points_per_streamline:.1f}")
        
        return True
    else:
        logger.error("❌ Could not load or create Saint-Venant velocity files for testing")
        return False

def main():
    """Main test function."""
    logger.info("🚀 Starting Saint-Venant streamlines test...")
    
    try:
        # Test 1: Saint-Venant velocity file loading
        success1 = test_saint_venant_velocity_loading()[1] is not None
        
        # Test 2: Streamlines generation with Saint-Venant
        success2 = test_streamlines_with_saint_venant()
        
        # Summary
        logger.info("\n" + "="*50)
        logger.info("TEST SUMMARY")
        logger.info("="*50)
        logger.info(f"✅ Saint-Venant file loading: {'PASS' if success1 else 'FAIL'}")
        logger.info(f"✅ Streamlines generation: {'PASS' if success2 else 'FAIL'}")
        logger.info("="*50)
        
        if success1 and success2:
            logger.info("🎉 All tests passed! Saint-Venant streamlines are working correctly.")
        else:
            logger.warning("⚠️  Some tests failed. Check the logs above for details.")
            
    except Exception as e:
        logger.error(f"❌ Test failed with error: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
