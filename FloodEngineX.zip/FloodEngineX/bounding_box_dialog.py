"""
FloodEngine Bounding Box Selection Tool
---------------------------------------
This module provides a dialog for selecting a bounding box on the map.
"""

from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QPushButton, 
                                QLabel, QLineEdit, QComboBox, QCheckBox, QGroupBox)
from qgis.PyQt.QtCore import Qt
from qgis.core import QgsRectangle, QgsProject, QgsMapLayerProxyModel
from qgis.gui import QgsMapCanvas, QgsMapToolExtent, QgsMapLayerComboBox

class BoundingBoxDialog(QDialog):
    """Dialog for selecting a bounding box on the map"""
    
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.setWindowTitle("Select Calculation Area")
        self.setMinimumWidth(500)
        self.setMinimumHeight(300)
        
        # Set up layout
        self.layout = QVBoxLayout()
        
        # Instructions
        self.instruction_label = QLabel("Select area for hydraulic calculation to reduce computation time.")
        self.layout.addWidget(self.instruction_label)
        
        # Bounding box group
        self.bbox_group = QGroupBox("Bounding Box")
        self.bbox_layout = QVBoxLayout()
        
        # Coordinate inputs
        coords_layout = QHBoxLayout()
        self.xmin_label = QLabel("X min:")
        self.xmin_input = QLineEdit()
        self.ymin_label = QLabel("Y min:")
        self.ymin_input = QLineEdit()
        self.xmax_label = QLabel("X max:")
        self.xmax_input = QLineEdit()
        self.ymax_label = QLabel("Y max:")
        self.ymax_input = QLineEdit()
        
        coords_layout.addWidget(self.xmin_label)
        coords_layout.addWidget(self.xmin_input)
        coords_layout.addWidget(self.ymin_label)
        coords_layout.addWidget(self.ymin_input)
        coords_layout.addWidget(self.xmax_label)
        coords_layout.addWidget(self.xmax_input)
        coords_layout.addWidget(self.ymax_label)
        coords_layout.addWidget(self.ymax_input)
        
        self.bbox_layout.addLayout(coords_layout)
        
        # Buttons for setting bounding box
        bbox_buttons_layout = QHBoxLayout()
        self.use_canvas_extent_btn = QPushButton("Use Current Map Extent")
        self.draw_on_map_btn = QPushButton("Draw Extent on Map")
        self.use_dem_extent_btn = QPushButton("Use DEM Extent")
        
        bbox_buttons_layout.addWidget(self.use_canvas_extent_btn)
        bbox_buttons_layout.addWidget(self.draw_on_map_btn)
        bbox_buttons_layout.addWidget(self.use_dem_extent_btn)
        
        self.bbox_layout.addLayout(bbox_buttons_layout)
        
        # Set up the map tool
        self.map_tool = QgsMapToolExtent(self.canvas)
        
        # Layer selection for DEM
        layer_layout = QHBoxLayout()
        self.layer_label = QLabel("DEM Layer:")
        self.layer_combo = QgsMapLayerComboBox()
        self.layer_combo.setFilters(QgsMapLayerProxyModel.RasterLayer)
        
        layer_layout.addWidget(self.layer_label)
        layer_layout.addWidget(self.layer_combo)
        
        self.bbox_layout.addLayout(layer_layout)
        
        self.bbox_group.setLayout(self.bbox_layout)
        self.layout.addWidget(self.bbox_group)
        
        # Resolution group
        self.resolution_group = QGroupBox("Resolution")
        self.resolution_layout = QVBoxLayout()
        
        resolution_option_layout = QHBoxLayout()
        self.resolution_label = QLabel("Resolution:")
        self.resolution_combo = QComboBox()
        self.resolution_combo.addItems([
            "Original resolution", 
            "Half resolution (4x faster)", 
            "Quarter resolution (16x faster)",
            "Eighth resolution (64x faster)",
            "Sixteenth resolution (256x faster)"
        ])
        
        resolution_option_layout.addWidget(self.resolution_label)
        resolution_option_layout.addWidget(self.resolution_combo)
        
        self.resolution_layout.addLayout(resolution_option_layout)
        self.resolution_warning = QLabel("Warning: Lower resolution may reduce accuracy")
        self.resolution_warning.setStyleSheet("color: orange;")
        self.resolution_layout.addWidget(self.resolution_warning)
        
        self.resolution_group.setLayout(self.resolution_layout)
        self.layout.addWidget(self.resolution_group)
        
        # Dialog buttons
        button_layout = QHBoxLayout()
        self.ok_button = QPushButton("OK")
        self.cancel_button = QPushButton("Cancel")
        
        button_layout.addWidget(self.ok_button)
        button_layout.addWidget(self.cancel_button)
        
        self.layout.addLayout(button_layout)
        
        self.setLayout(self.layout)
        
        # Connect signals
        self.use_canvas_extent_btn.clicked.connect(self.use_canvas_extent)
        self.draw_on_map_btn.clicked.connect(self.draw_on_map)
        self.use_dem_extent_btn.clicked.connect(self.use_dem_extent)
        self.map_tool.extentChanged.connect(self.extent_drawn)
        self.ok_button.clicked.connect(self.accept)
        self.cancel_button.clicked.connect(self.reject)
        
        # Initialize with canvas extent
        self.use_canvas_extent()
    
    def use_canvas_extent(self):
        """Use the current map canvas extent"""
        extent = self.canvas.extent()
        self.set_extent_in_form(extent)
    
    def draw_on_map(self):
        """Activate the map tool to draw the extent"""
        self.canvas.setMapTool(self.map_tool)
        self.hide()  # Hide the dialog while drawing
    
    def use_dem_extent(self):
        """Use the extent of the selected DEM layer"""
        current_layer = self.layer_combo.currentLayer()
        if current_layer:
            extent = current_layer.extent()
            self.set_extent_in_form(extent)
    
    def extent_drawn(self, extent):
        """Handle the extent drawn on the map"""
        self.set_extent_in_form(extent)
        self.canvas.setMapTool(self.canvas.mapTool())  # Reset map tool
        self.show()  # Show the dialog again
    
    def set_extent_in_form(self, extent):
        """Set the extent values in the form inputs"""
        self.xmin_input.setText(str(int(extent.xMinimum())))
        self.ymin_input.setText(str(int(extent.yMinimum())))
        self.xmax_input.setText(str(int(extent.xMaximum())))
        self.ymax_input.setText(str(int(extent.yMaximum())))
    
    def get_bounding_box(self):
        """Get the bounding box from the form"""
        try:
            xmin = float(self.xmin_input.text())
            ymin = float(self.ymin_input.text())
            xmax = float(self.xmax_input.text())
            ymax = float(self.ymax_input.text())
            return (xmin, ymin, xmax, ymax)
        except ValueError:
            return None
    
    def get_resolution_factor(self):
        """Get the resolution factor from the combo box"""
        index = self.resolution_combo.currentIndex()
        factors = [1, 2, 4, 8, 16]
        return factors[index] if 0 <= index < len(factors) else 1


def show_bounding_box_dialog(iface):
    """Show the bounding box dialog and return the selected values"""
    dialog = BoundingBoxDialog(iface)
    result = dialog.exec_()
    
    if result == QDialog.Accepted:
        return {
            "bounding_box": dialog.get_bounding_box(),
            "resolution_factor": dialog.get_resolution_factor()
        }
    return None
