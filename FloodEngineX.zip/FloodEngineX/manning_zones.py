"""
Manning Zones Management for FloodEngine
========================================

This module provides advanced Manning coefficient management with polygon zones.
"""

import os
import json
from qgis.core import (QgsVectorLayer, QgsProject, QgsFeature, QgsGeometry, QgsPointXY,
                      QgsField, QgsFields, QgsWkbTypes, QgsVectorFileWriter, 
                      QgsCoordinateReferenceSystem)
from qgis.PyQt.QtCore import QVariant
from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QTableWidget, 
                            QTableWidgetItem, QPushButton, QLabel, QLineEdit, 
                            QDoubleSpinBox, QFileDialog, QMessageBox, QComboBox,
                            QGroupBox, QCheckBox)

class ManningZone:
    """Represents a Manning coefficient zone"""
    
    def __init__(self, name, manning_n, geometry=None, description=""):
        self.name = name
        self.manning_n = manning_n
        self.geometry = geometry  # QgsGeometry polygon
        self.description = description
    
    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            'name': self.name,
            'manning_n': self.manning_n,
            'description': self.description,
            'geometry_wkt': self.geometry.asWkt() if self.geometry else None
        }
    
    @classmethod
    def from_dict(cls, data):
        """Create from dictionary"""
        zone = cls(data['name'], data['manning_n'], description=data.get('description', ''))
        if data.get('geometry_wkt'):
            zone.geometry = QgsGeometry.fromWkt(data['geometry_wkt'])
        return zone

class ManningZonesManager:
    """Manages Manning coefficient zones"""
    
    def __init__(self):
        self.zones = []
        self.default_manning = 0.035
        
    def add_zone(self, zone):
        """Add a Manning zone"""
        self.zones.append(zone)
    
    def remove_zone(self, zone_name):
        """Remove a Manning zone by name"""
        self.zones = [z for z in self.zones if z.name != zone_name]
    
    def get_zone(self, zone_name):
        """Get a zone by name"""
        for zone in self.zones:
            if zone.name == zone_name:
                return zone
        return None
    
    def get_manning_at_point(self, point):
        """
        Get Manning coefficient at a specific point
        
        Args:
            point: QgsPointXY
        
        Returns:
            float: Manning coefficient
        """
        point_geom = QgsGeometry.fromPointXY(point)
        
        for zone in self.zones:
            if zone.geometry and zone.geometry.contains(point_geom):
                return zone.manning_n
        
        return self.default_manning
    
    def save_to_file(self, filepath):
        """Save zones to JSON file"""
        data = {
            'default_manning': self.default_manning,
            'zones': [zone.to_dict() for zone in self.zones]
        }
        
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
    
    def load_from_file(self, filepath):
        """Load zones from JSON file"""
        if not os.path.exists(filepath):
            return False
        
        try:
            with open(filepath, 'r') as f:
                data = json.load(f)
            
            self.default_manning = data.get('default_manning', 0.035)
            self.zones = [ManningZone.from_dict(zone_data) for zone_data in data.get('zones', [])]
            return True
        except Exception as e:
            print(f"Error loading Manning zones: {e}")
            return False
    
    def create_zones_layer(self, output_path):
        """Create a shapefile layer from the zones"""
        fields = QgsFields()
        fields.append(QgsField("name", QVariant.String))
        fields.append(QgsField("manning_n", QVariant.Double))
        fields.append(QgsField("description", QVariant.String))
        
        crs = QgsCoordinateReferenceSystem("EPSG:3006")  # SWEREF99 TM
        
        writer = QgsVectorFileWriter(output_path, "UTF-8", fields, QgsWkbTypes.Polygon, crs, "ESRI Shapefile")
        
        if writer.hasError() != QgsVectorFileWriter.NoError:
            return None
        
        for zone in self.zones:
            if zone.geometry:
                feature = QgsFeature()
                feature.setGeometry(zone.geometry)
                feature.setAttributes([zone.name, zone.manning_n, zone.description])
                writer.addFeature(feature)
        
        del writer
        
        return QgsVectorLayer(output_path, "Manning Zones", "ogr")

class ManningZonesDialog(QDialog):
    """Dialog for managing Manning coefficient zones"""
    
    def __init__(self, parent=None, iface=None):
        super().__init__(parent)
        self.iface = iface
        self.manager = ManningZonesManager()
        self.setup_ui()
        self.load_default_zones()
    
    def setup_ui(self):
        """Set up the UI"""
        self.setWindowTitle("Manning Coefficient Zones")
        self.setModal(True)
        self.resize(800, 600)
        
        layout = QVBoxLayout(self)
        
        # Default Manning coefficient
        default_group = QGroupBox("Default Manning Coefficient")
        default_layout = QHBoxLayout(default_group)
        
        default_layout.addWidget(QLabel("Default Manning's n:"))
        self.default_manning_spin = QDoubleSpinBox()
        self.default_manning_spin.setRange(0.001, 1.0)
        self.default_manning_spin.setDecimals(4)
        self.default_manning_spin.setValue(0.035)
        self.default_manning_spin.setSingleStep(0.001)
        default_layout.addWidget(self.default_manning_spin)
        
        default_layout.addWidget(QLabel("(Used for areas not covered by zones)"))
        default_layout.addStretch()
        
        layout.addWidget(default_group)
        
        # Zones table
        zones_group = QGroupBox("Manning Zones")
        zones_layout = QVBoxLayout(zones_group)
        
        self.zones_table = QTableWidget()
        self.zones_table.setColumnCount(4)
        self.zones_table.setHorizontalHeaderLabels(["Zone Name", "Manning's n", "Description", "Geometry"])
        zones_layout.addWidget(self.zones_table)
        
        # Zone management buttons
        zone_buttons_layout = QHBoxLayout()
        
        self.add_zone_btn = QPushButton("Add Zone")
        self.add_zone_btn.clicked.connect(self.add_zone)
        zone_buttons_layout.addWidget(self.add_zone_btn)
        
        self.edit_zone_btn = QPushButton("Edit Zone")
        self.edit_zone_btn.clicked.connect(self.edit_zone)
        zone_buttons_layout.addWidget(self.edit_zone_btn)
        
        self.delete_zone_btn = QPushButton("Delete Zone")
        self.delete_zone_btn.clicked.connect(self.delete_zone)
        zone_buttons_layout.addWidget(self.delete_zone_btn)
        
        self.draw_zone_btn = QPushButton("Draw Zone on Map")
        self.draw_zone_btn.clicked.connect(self.draw_zone)
        zone_buttons_layout.addWidget(self.draw_zone_btn)
        
        zone_buttons_layout.addStretch()
        zones_layout.addLayout(zone_buttons_layout)
        
        layout.addWidget(zones_group)
        
        # Presets
        presets_group = QGroupBox("Manning Coefficient Presets")
        presets_layout = QVBoxLayout(presets_group)
        
        presets_info = QLabel(
            "Common Manning's n values:\n"
            "• Natural channels (clean): 0.025-0.035\n"
            "• Natural channels (rough): 0.035-0.050\n"
            "• Floodplains (pasture): 0.025-0.035\n"
            "• Floodplains (forest): 0.050-0.100\n"
            "• Urban areas: 0.013-0.020\n"
            "• Agricultural land: 0.020-0.030"
        )
        presets_layout.addWidget(presets_info)
        
        presets_buttons_layout = QHBoxLayout()
        
        self.add_channel_preset = QPushButton("Add Natural Channel Zone")
        self.add_channel_preset.clicked.connect(lambda: self.add_preset_zone("Natural Channel", 0.030))
        presets_buttons_layout.addWidget(self.add_channel_preset)
        
        self.add_forest_preset = QPushButton("Add Forest Zone")
        self.add_forest_preset.clicked.connect(lambda: self.add_preset_zone("Forest", 0.075))
        presets_buttons_layout.addWidget(self.add_forest_preset)
        
        self.add_urban_preset = QPushButton("Add Urban Zone")
        self.add_urban_preset.clicked.connect(lambda: self.add_preset_zone("Urban", 0.016))
        presets_buttons_layout.addWidget(self.add_urban_preset)
        
        presets_layout.addLayout(presets_buttons_layout)
        layout.addWidget(presets_group)
        
        # File operations
        file_group = QGroupBox("File Operations")
        file_layout = QHBoxLayout(file_group)
        
        self.save_zones_btn = QPushButton("Save Zones")
        self.save_zones_btn.clicked.connect(self.save_zones)
        file_layout.addWidget(self.save_zones_btn)
        
        self.load_zones_btn = QPushButton("Load Zones")
        self.load_zones_btn.clicked.connect(self.load_zones)
        file_layout.addWidget(self.load_zones_btn)
        
        self.export_shapefile_btn = QPushButton("Export as Shapefile")
        self.export_shapefile_btn.clicked.connect(self.export_shapefile)
        file_layout.addWidget(self.export_shapefile_btn)
        
        file_layout.addStretch()
        layout.addWidget(file_group)
        
        # Dialog buttons
        dialog_buttons_layout = QHBoxLayout()
        
        self.ok_btn = QPushButton("OK")
        self.ok_btn.clicked.connect(self.accept)
        dialog_buttons_layout.addWidget(self.ok_btn)
        
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self.reject)
        dialog_buttons_layout.addWidget(self.cancel_btn)
        
        dialog_buttons_layout.addStretch()
        layout.addLayout(dialog_buttons_layout)
    
    def load_default_zones(self):
        """Load default Manning zones"""
        # Add some default zones
        default_zones = [
            ManningZone("Default Channel", 0.030, description="Natural channel, clean"),
            ManningZone("Rough Channel", 0.045, description="Natural channel, rough with vegetation"),
            ManningZone("Floodplain", 0.035, description="Grassy floodplain"),
            ManningZone("Forest", 0.075, description="Forested area"),
            ManningZone("Urban", 0.016, description="Urban/developed area")
        ]
        
        for zone in default_zones:
            self.manager.add_zone(zone)
        
        self.update_zones_table()
    
    def update_zones_table(self):
        """Update the zones table"""
        self.zones_table.setRowCount(len(self.manager.zones))
        
        for i, zone in enumerate(self.manager.zones):
            self.zones_table.setItem(i, 0, QTableWidgetItem(zone.name))
            self.zones_table.setItem(i, 1, QTableWidgetItem(f"{zone.manning_n:.4f}"))
            self.zones_table.setItem(i, 2, QTableWidgetItem(zone.description))
            
            geometry_status = "Defined" if zone.geometry else "Not defined"
            self.zones_table.setItem(i, 3, QTableWidgetItem(geometry_status))
    
    def add_zone(self):
        """Add a new zone"""
        dialog = ZoneEditDialog(self)
        if dialog.exec_():
            zone_data = dialog.get_zone_data()
            zone = ManningZone(zone_data['name'], zone_data['manning_n'], description=zone_data['description'])
            self.manager.add_zone(zone)
            self.update_zones_table()
    
    def edit_zone(self):
        """Edit selected zone"""
        current_row = self.zones_table.currentRow()
        if current_row >= 0:
            zone = self.manager.zones[current_row]
            dialog = ZoneEditDialog(self, zone)
            if dialog.exec_():
                zone_data = dialog.get_zone_data()
                zone.name = zone_data['name']
                zone.manning_n = zone_data['manning_n']
                zone.description = zone_data['description']
                self.update_zones_table()
    
    def delete_zone(self):
        """Delete selected zone"""
        current_row = self.zones_table.currentRow()
        if current_row >= 0:
            zone_name = self.manager.zones[current_row].name
            reply = QMessageBox.question(self, "Delete Zone", f"Delete zone '{zone_name}'?")
            if reply == QMessageBox.Yes:
                self.manager.remove_zone(zone_name)
                self.update_zones_table()
    
    def draw_zone(self):
        """Draw zone geometry on map"""
        current_row = self.zones_table.currentRow()
        if current_row >= 0:
            zone = self.manager.zones[current_row]
            # TODO: Implement map drawing tool
            QMessageBox.information(self, "Draw Zone", f"Map drawing for zone '{zone.name}' will be implemented.")
    
    def add_preset_zone(self, name, manning_n):
        """Add a preset zone"""
        zone = ManningZone(name, manning_n, description=f"Preset zone: {name}")
        self.manager.add_zone(zone)
        self.update_zones_table()
    
    def save_zones(self):
        """Save zones to file"""
        filename, _ = QFileDialog.getSaveFileName(self, "Save Manning Zones", "", "JSON files (*.json)")
        if filename:
            self.manager.default_manning = self.default_manning_spin.value()
            self.manager.save_to_file(filename)
            QMessageBox.information(self, "Save Zones", "Manning zones saved successfully.")
    
    def load_zones(self):
        """Load zones from file"""
        filename, _ = QFileDialog.getOpenFileName(self, "Load Manning Zones", "", "JSON files (*.json)")
        if filename:
            if self.manager.load_from_file(filename):
                self.default_manning_spin.setValue(self.manager.default_manning)
                self.update_zones_table()
                QMessageBox.information(self, "Load Zones", "Manning zones loaded successfully.")
            else:
                QMessageBox.warning(self, "Load Zones", "Failed to load Manning zones.")
    
    def export_shapefile(self):
        """Export zones as shapefile"""
        filename, _ = QFileDialog.getSaveFileName(self, "Export Manning Zones", "", "Shapefiles (*.shp)")
        if filename:
            layer = self.manager.create_zones_layer(filename)
            if layer:
                if self.iface:
                    QgsProject.instance().addMapLayer(layer)
                QMessageBox.information(self, "Export Shapefile", "Manning zones exported successfully.")
            else:
                QMessageBox.warning(self, "Export Shapefile", "Failed to export Manning zones.")
    
    def get_manager(self):
        """Get the Manning zones manager"""
        self.manager.default_manning = self.default_manning_spin.value()
        return self.manager

class ZoneEditDialog(QDialog):
    """Dialog for editing a Manning zone"""
    
    def __init__(self, parent=None, zone=None):
        super().__init__(parent)
        self.zone = zone
        self.setup_ui()
        if zone:
            self.load_zone_data()
    
    def setup_ui(self):
        """Set up the UI"""
        self.setWindowTitle("Edit Manning Zone" if self.zone else "Add Manning Zone")
        self.setModal(True)
        
        layout = QVBoxLayout(self)
        
        # Zone name
        name_layout = QHBoxLayout()
        name_layout.addWidget(QLabel("Zone Name:"))
        self.name_edit = QLineEdit()
        name_layout.addWidget(self.name_edit)
        layout.addLayout(name_layout)
        
        # Manning coefficient
        manning_layout = QHBoxLayout()
        manning_layout.addWidget(QLabel("Manning's n:"))
        self.manning_spin = QDoubleSpinBox()
        self.manning_spin.setRange(0.001, 1.0)
        self.manning_spin.setDecimals(4)
        self.manning_spin.setValue(0.035)
        self.manning_spin.setSingleStep(0.001)
        manning_layout.addWidget(self.manning_spin)
        layout.addLayout(manning_layout)
        
        # Description
        desc_layout = QHBoxLayout()
        desc_layout.addWidget(QLabel("Description:"))
        self.description_edit = QLineEdit()
        desc_layout.addWidget(self.description_edit)
        layout.addLayout(desc_layout)
        
        # Buttons
        buttons_layout = QHBoxLayout()
        
        self.ok_btn = QPushButton("OK")
        self.ok_btn.clicked.connect(self.accept)
        buttons_layout.addWidget(self.ok_btn)
        
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self.reject)
        buttons_layout.addWidget(self.cancel_btn)
        
        layout.addLayout(buttons_layout)
    
    def load_zone_data(self):
        """Load zone data into the form"""
        if self.zone:
            self.name_edit.setText(self.zone.name)
            self.manning_spin.setValue(self.zone.manning_n)
            self.description_edit.setText(self.zone.description)
    
    def get_zone_data(self):
        """Get zone data from the form"""
        return {
            'name': self.name_edit.text(),
            'manning_n': self.manning_spin.value(),
            'description': self.description_edit.text()
        }
