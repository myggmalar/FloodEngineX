#!/usr/bin/env python3
"""
CRITICAL TEST: Timestep Simulation Intermediate Layers
=====================================================
This test verifies that the adaptive threshold fixes resolve the issue where
intermediate timestep layers were empty despite proper water level variation.

Test focuses on:
1. Multiple timestep water levels (not just min/max)
2. Verifying each timestep produces flood results
3. Checking intermediate water levels specifically
4. Performance impact of adaptive thresholds
"""

import sys
import os
import numpy as np
import time
from pathlib import Path

# Add the plugin directory to path
plugin_dir = Path(__file__).parent
sys.path.insert(0, str(plugin_dir))

# Import the fixed functions
from model_hydraulic import create_proper_flow_flood_mask

def create_test_dem_with_valley():
    """Create a synthetic DEM with a valley structure ideal for testing intermediate levels"""
    rows, cols = 100, 100
    dem = np.zeros((rows, cols), dtype=np.float32)
    
    # Create a valley that runs diagonally with varying depths
    for i in range(rows):
        for j in range(cols):
            # Base elevation (slope from 50m to 40m)
            base_elevation = 50 - (i + j) * 0.05
            
            # Add valley (lower area in middle)
            center_distance = abs(i - rows//2) + abs(j - cols//2)
            valley_depth = max(0, 8 - center_distance * 0.1)
            
            # Add some random variation
            noise = np.random.normal(0, 0.5)
            
            dem[i, j] = base_elevation - valley_depth + noise
    
    # Ensure reasonable elevation range (35-50m)
    dem = np.clip(dem, 35, 50)
    
    return dem

def run_timestep_simulation_test():
    """Test timestep simulation with intermediate water levels"""
    print("=" * 80)
    print("🧪 TESTING: Timestep Simulation Intermediate Layers")
    print("=" * 80)
    
    # Create test DEM
    dem_array = create_test_dem_with_valley()
    valid_mask = np.ones_like(dem_array, dtype=bool)
    
    print(f"📊 Test DEM shape: {dem_array.shape}")
    print(f"📊 Elevation range: {dem_array.min():.2f}m to {dem_array.max():.2f}m")
    
    # Define water level range for timestep simulation
    min_water_level = dem_array.min() + 1  # Start 1m above minimum
    max_water_level = dem_array.max() - 1  # End 1m below maximum
    num_timesteps = 10
    
    water_levels = np.linspace(min_water_level, max_water_level, num_timesteps)
    
    print(f"🌊 Testing {num_timesteps} timesteps from {min_water_level:.2f}m to {max_water_level:.2f}m")
    print("-" * 80)
    
    results = []
    failed_timesteps = []
    total_time = 0
    
    for i, water_level in enumerate(water_levels):
        print(f"\n🔄 TIMESTEP {i+1}/{num_timesteps}: Water Level = {water_level:.2f}m")
        
        start_time = time.time()
        
        # Test the fixed flood calculation
        try:
            flood_mask = create_proper_flow_flood_mask(dem_array, valid_mask, water_level)
            flooded_cells = np.sum(flood_mask)
            
            elapsed_time = time.time() - start_time
            total_time += elapsed_time
            
            # Check if this timestep produced results
            if flooded_cells > 0:
                flood_percentage = (flooded_cells / np.sum(valid_mask)) * 100
                print(f"✅ SUCCESS: {flooded_cells} cells flooded ({flood_percentage:.1f}%) in {elapsed_time:.3f}s")
                results.append({
                    'timestep': i+1,
                    'water_level': water_level,
                    'flooded_cells': flooded_cells,
                    'flood_percentage': flood_percentage,
                    'time': elapsed_time,
                    'success': True
                })
            else:
                print(f"❌ FAILED: No flooding detected at water level {water_level:.2f}m")
                failed_timesteps.append(i+1)
                results.append({
                    'timestep': i+1,
                    'water_level': water_level,
                    'flooded_cells': 0,
                    'flood_percentage': 0,
                    'time': elapsed_time,
                    'success': False
                })
                
        except Exception as e:
            elapsed_time = time.time() - start_time
            total_time += elapsed_time
            print(f"💥 ERROR in timestep {i+1}: {str(e)}")
            failed_timesteps.append(i+1)
            results.append({
                'timestep': i+1,
                'water_level': water_level,
                'flooded_cells': 0,
                'flood_percentage': 0,
                'time': elapsed_time,
                'success': False,
                'error': str(e)
            })
    
    # Analyze results
    print("\n" + "=" * 80)
    print("📊 TIMESTEP SIMULATION RESULTS")
    print("=" * 80)
    
    successful_timesteps = [r for r in results if r['success']]
    print(f"✅ Successful timesteps: {len(successful_timesteps)}/{num_timesteps}")
    print(f"❌ Failed timesteps: {len(failed_timesteps)}")
    print(f"⏱️ Total simulation time: {total_time:.3f}s (avg: {total_time/num_timesteps:.3f}s per timestep)")
    
    if failed_timesteps:
        print(f"🚨 FAILED TIMESTEPS: {failed_timesteps}")
        
    # Show progression of flooding
    if successful_timesteps:
        print("\n📈 FLOODING PROGRESSION:")
        print("Timestep | Water Level | Flooded Cells | Percentage | Time")
        print("-" * 65)
        for r in successful_timesteps:
            print(f"    {r['timestep']:2d}   |   {r['water_level']:7.2f}m |   {r['flooded_cells']:8d} |   {r['flood_percentage']:6.1f}% | {r['time']:.3f}s")
    
    # Test intermediate levels specifically
    intermediate_results = [r for r in results[2:-2] if r['success']]  # Skip first 2 and last 2
    print(f"\n🎯 INTERMEDIATE LEVELS TEST: {len(intermediate_results)}/{len(results)-4} intermediate timesteps successful")
    
    # Performance analysis
    if successful_timesteps:
        avg_time = sum(r['time'] for r in successful_timesteps) / len(successful_timesteps)
        max_time = max(r['time'] for r in successful_timesteps)
        print(f"⚡ Performance: Avg {avg_time:.3f}s, Max {max_time:.3f}s per timestep")
    
    # Overall test result
    print("\n" + "=" * 80)
    if len(failed_timesteps) == 0:
        print("🎉 TEST PASSED: All timesteps produced flooding results!")
        print("✅ The adaptive threshold fixes successfully resolved intermediate layer issues.")
    elif len(failed_timesteps) <= 2:
        print("⚠️ TEST MOSTLY PASSED: Only minor issues in edge cases.")
        print("✅ Intermediate timestep issue appears to be resolved.")
    else:
        print("❌ TEST FAILED: Multiple timesteps still producing empty results.")
        print("🔧 Additional fixes may be needed.")
    
    print("=" * 80)
    
    return results, failed_timesteps

def test_specific_intermediate_levels():
    """Test specific intermediate water levels that were problematic"""
    print("\n" + "=" * 80)
    print("🔍 TESTING: Specific Problematic Intermediate Levels")
    print("=" * 80)
    
    # Create test DEM
    dem_array = create_test_dem_with_valley()
    valid_mask = np.ones_like(dem_array, dtype=bool)
    
    # Test specific intermediate levels that commonly failed
    min_elev = dem_array.min()
    max_elev = dem_array.max()
    elev_range = max_elev - min_elev
    
    # These are the typical problematic intermediate levels
    test_levels = [
        min_elev + 0.25 * elev_range,  # 25% of range
        min_elev + 0.4 * elev_range,   # 40% of range  
        min_elev + 0.6 * elev_range,   # 60% of range
        min_elev + 0.75 * elev_range,  # 75% of range
    ]
    
    print(f"🎯 Testing intermediate levels at 25%, 40%, 60%, and 75% of elevation range")
    
    all_passed = True
    for i, water_level in enumerate(test_levels):
        percentage = (i + 1) * 25 if i < 3 else 75
        print(f"\n🌊 Testing {percentage}% level: {water_level:.2f}m")
        
        try:
            flood_mask = create_proper_flow_flood_mask(dem_array, valid_mask, water_level)
            flooded_cells = np.sum(flood_mask)
            
            if flooded_cells > 0:
                flood_percentage = (flooded_cells / np.sum(valid_mask)) * 100
                print(f"✅ SUCCESS: {flooded_cells} cells flooded ({flood_percentage:.1f}%)")
            else:
                print(f"❌ FAILED: No flooding at {percentage}% level")
                all_passed = False
                
        except Exception as e:
            print(f"💥 ERROR: {str(e)}")
            all_passed = False
    
    print("\n" + "-" * 80)
    if all_passed:
        print("🎉 INTERMEDIATE LEVELS TEST PASSED!")
    else:
        print("❌ INTERMEDIATE LEVELS TEST FAILED!")
    print("-" * 80)
    
    return all_passed

if __name__ == "__main__":
    print("🚀 Starting Timestep Simulation Tests...")
    
    # Run main timestep simulation test
    results, failed_timesteps = run_timestep_simulation_test()
    
    # Run specific intermediate level test
    intermediate_test_passed = test_specific_intermediate_levels()
    
    # Final summary
    print("\n" + "🏁 FINAL TEST SUMMARY" + "🏁")
    print("=" * 80)
    print(f"📊 Timestep simulation: {len(results) - len(failed_timesteps)}/{len(results)} successful")
    print(f"🎯 Intermediate levels: {'PASSED' if intermediate_test_passed else 'FAILED'}")
    
    overall_success = len(failed_timesteps) <= 1 and intermediate_test_passed
    
    if overall_success:
        print("🎉 OVERALL SUCCESS: Adaptive threshold fixes are working!")
        print("✅ Intermediate timestep layers should now be populated correctly.")
    else:
        print("⚠️ ISSUES REMAIN: Some timesteps still failing.")
        print("🔧 May need additional debugging or fixes.")
    
    print("=" * 80)
