"""
Fix indentation in floodengine_ui.py
This script normalizes indentation by ensuring all spaces are consistent
"""
import os
import re
import sys

def normalize_indentation(filename):
    """Normalize indentation in a Python file"""
    print(f"Normalizing indentation in {filename}...")
    
    # Check if file exists
    if not os.path.exists(filename):
        print(f"Error: File {filename} not found")
        return None
        
    print(f"Reading file...")
    
    try:
        # Read file content
        with open(filename, "r", encoding="utf-8") as f:
            content = f.read()
        print("File read successfully with UTF-8 encoding")
    except UnicodeDecodeError:
        print("UTF-8 decoding failed, trying Latin-1...")
        # Try alternative encoding
        try:
            with open(filename, "r", encoding="latin-1") as f:
                content = f.read()
            print("File read successfully with Latin-1 encoding")
        except Exception as e:
            print(f"Error reading file: {e}")
            return None
    
    # Split into lines
    lines = content.split("\n")
    
    # Process each line
    normalized_lines = []
    for i, line in enumerate(lines):
        # Skip empty lines
        if not line.strip():
            normalized_lines.append(line)
            continue
        
        # Count leading spaces
        leading_spaces = len(line) - len(line.lstrip(' '))
        
        # Normalize to 4 spaces per indentation level
        indent_level = leading_spaces // 4
        normalized_indent = ' ' * (4 * indent_level)
        
        # Create normalized line
        normalized_line = normalized_indent + line.lstrip(' ')
        normalized_lines.append(normalized_line)
      # Write back to file
    output_filename = filename + ".normalized"
    print(f"Writing normalized content to {output_filename}...")
    
    try:
        with open(output_filename, "w", encoding="utf-8") as f:
            f.write("\n".join(normalized_lines))
        print(f"Normalized version saved successfully")
        return output_filename
    except Exception as e:
        print(f"Error writing file: {e}")
        return None

def main():
    # Check command line arguments
    if len(sys.argv) > 1:
        filename = sys.argv[1]
    else:
        filename = "floodengine_ui.py"
    
    # Ensure file exists
    if not os.path.exists(filename):
        print(f"Error: File {filename} not found")
        return 1
    
    # Normalize indentation
    normalized_file = normalize_indentation(filename)
    
    # Provide instructions
    print(f"\nNormalization complete.")
    print(f"To use the normalized file:")
    print(f"1. Review {normalized_file} to ensure it's correct")
    print(f"2. Replace the original file: copy {normalized_file} {filename}")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
