#!/usr/bin/env python3
"""
DEM ELEVATION ISSUES DIAGNOSTIC SCRIPT
=====================================

This script investigates why the DEM shows incorrect elevation values
(-9.38m to +44.04m) instead of expected RT2000 heights (+9m to +51m).

ISSUES TO INVESTIGATE:
1. Raw DEM file values vs processed values
2. Bathymetry integration effects  
3. Coordinate system/datum transformations
4. NoData value handling
5. Unit conversion problems
"""

import os
import sys
import numpy as np
from osgeo import gdal, osr
import traceback

def analyze_dem_file(dem_path):
    """Analyze a DEM file to understand elevation value issues"""
    try:
        print(f"\n🔍 ANALYZING DEM FILE: {os.path.basename(dem_path)}")
        print("=" * 60)
        
        # Open DEM
        ds = gdal.Open(dem_path)
        if not ds:
            print(f"❌ Could not open: {dem_path}")
            return None
            
        # Basic info
        print(f"📁 File: {dem_path}")
        print(f"📏 Size: {ds.RasterXSize} x {ds.RasterYSize}")
        print(f"🔢 Bands: {ds.RasterCount}")
        print(f"📊 Data Type: {gdal.GetDataTypeName(ds.GetRasterBand(1).DataType)}")
        
        # Geospatial info
        geotransform = ds.GetGeoTransform()
        projection = ds.GetProjection()
        
        print(f"🌍 Projection: {projection[:100]}...")
        print(f"📍 Origin: ({geotransform[0]:.1f}, {geotransform[3]:.1f})")
        print(f"📐 Pixel Size: {geotransform[1]:.3f} x {geotransform[5]:.3f}")
        
        # Get elevation data
        band = ds.GetRasterBand(1)
        nodata = band.GetNoDataValue()
        data = band.ReadAsArray().astype(np.float32)
        
        print(f"🚫 NoData Value: {nodata}")
        
        # Filter out NoData values
        if nodata is not None:
            valid_data = data[data != nodata]
        else:
            valid_data = data[~np.isnan(data)]
            
        print(f"✅ Valid Pixels: {len(valid_data):,} of {data.size:,} ({(len(valid_data)/data.size)*100:.1f}%)")
        
        if len(valid_data) > 0:
            print(f"\n📊 ELEVATION STATISTICS:")
            print(f"   Minimum: {np.min(valid_data):.3f}m")
            print(f"   Maximum: {np.max(valid_data):.3f}m") 
            print(f"   Mean: {np.mean(valid_data):.3f}m")
            print(f"   Median: {np.median(valid_data):.3f}m")
            print(f"   Std Dev: {np.std(valid_data):.3f}m")
            print(f"   Range: {np.max(valid_data) - np.min(valid_data):.3f}m")
            
            # Check for problematic values
            negative_count = np.sum(valid_data < 0)
            very_low_count = np.sum(valid_data < -5)
            very_high_count = np.sum(valid_data > 100)
            
            print(f"\n⚠️  POTENTIAL ISSUES:")
            print(f"   Negative values: {negative_count:,} pixels ({(negative_count/len(valid_data))*100:.1f}%)")
            print(f"   Very low (<-5m): {very_low_count:,} pixels ({(very_low_count/len(valid_data))*100:.1f}%)")
            print(f"   Very high (>100m): {very_high_count:,} pixels ({(very_high_count/len(valid_data))*100:.1f}%)")
            
            # Elevation distribution
            print(f"\n📈 ELEVATION DISTRIBUTION:")
            ranges = [
                (-999, -10, "Deep negative"),
                (-10, -1, "Shallow negative"), 
                (-1, 0, "Near sea level (negative)"),
                (0, 10, "Low elevation (0-10m)"),
                (10, 30, "Medium elevation (10-30m)"),
                (30, 60, "High elevation (30-60m)"),
                (60, 999, "Very high (>60m)")
            ]
            
            for min_val, max_val, label in ranges:
                count = np.sum((valid_data >= min_val) & (valid_data < max_val))
                if count > 0:
                    print(f"   {label}: {count:,} pixels ({(count/len(valid_data))*100:.1f}%)")
        
        # Check coordinate system details
        print(f"\n🗺️  COORDINATE SYSTEM ANALYSIS:")
        srs = osr.SpatialReference()
        srs.ImportFromWkt(projection)
        
        print(f"   Authority: {srs.GetAuthorityName(None)} : {srs.GetAuthorityCode(None)}")
        print(f"   Units: {srs.GetLinearUnitsName()}")
        
        # Check if this is SWEREF99 TM (EPSG:3006)
        if srs.GetAuthorityCode(None) == "3006":
            print(f"   ✅ Correct SWEREF99 TM projection")
        else:
            print(f"   ⚠️  Not SWEREF99 TM - this could cause elevation issues")
            
        return {
            'min_elevation': np.min(valid_data) if len(valid_data) > 0 else None,
            'max_elevation': np.max(valid_data) if len(valid_data) > 0 else None,
            'mean_elevation': np.mean(valid_data) if len(valid_data) > 0 else None,
            'negative_pixels': negative_count if len(valid_data) > 0 else 0,
            'projection_code': srs.GetAuthorityCode(None),
            'nodata_value': nodata,
            'valid_pixel_ratio': len(valid_data)/data.size if data.size > 0 else 0
        }
        
    except Exception as e:
        print(f"❌ Error analyzing DEM: {e}")
        traceback.print_exc()
        return None
    finally:
        if 'ds' in locals():
            ds = None

def find_dem_files():
    """Find DEM-related files in the workspace"""
    search_paths = [
        r"C:\Plugin\VSCode\output",
        r"C:\Plugin\VSCode\FloodEngine_fixed_v8",
        r"C:\Users\david\OneDrive\Dokument\GIS\FloodEngine\VSCode\output"
    ]
    
    dem_files = []
    
    for search_path in search_paths:
        if os.path.exists(search_path):
            print(f"🔍 Searching: {search_path}")
            
            for root, dirs, files in os.walk(search_path):
                for file in files:
                    if file.lower().endswith(('.tif', '.tiff', '.img', '.asc')):
                        full_path = os.path.join(root, file)
                        dem_files.append(full_path)
                        print(f"   Found: {full_path}")
    
    return dem_files

def compare_with_expected_values():
    """Compare current values with expected RT2000 values"""
    print(f"\n📋 EXPECTED vs ACTUAL VALUES COMPARISON")
    print("=" * 50)
    print(f"Expected (RT2000): +9m to +51m above sea level")
    print(f"Actual (Current):  -9.38m to +44.04m")
    print(f"")
    print(f"ANALYSIS:")
    print(f"• Minimum difference: -9.38 - 9 = -18.38m too low")
    print(f"• Maximum difference: 44.04 - 51 = -6.96m too low") 
    print(f"• Range expected: 51 - 9 = 42m")
    print(f"• Range actual: 44.04 - (-9.38) = 53.42m")
    print(f"")
    print(f"POSSIBLE CAUSES:")
    print(f"1. Wrong vertical datum (RT2000 vs WGS84 ellipsoid height)")
    print(f"2. Bathymetry incorrectly integrated with negative values")
    print(f"3. Unit conversion error (feet to meters?)")
    print(f"4. Geoid height correction not applied properly")
    print(f"5. DEM processing algorithm error")

def check_bathymetry_integration():
    """Check if bathymetry files are causing negative elevation values"""
    print(f"\n🌊 BATHYMETRY INTEGRATION CHECK")
    print("=" * 40)
    
    # Look for bathymetry files
    bathymetry_files = []
    search_paths = [
        r"C:\Plugin\VSCode\output",
        r"C:\Plugin\VSCode\FloodEngine_fixed_v8"
    ]
    
    for search_path in search_paths:
        if os.path.exists(search_path):
            for root, dirs, files in os.walk(search_path):
                for file in files:
                    if any(keyword in file.lower() for keyword in ['bath', 'depth', 'sea', 'water']):
                        if file.lower().endswith(('.csv', '.txt', '.shp', '.tif')):
                            bathymetry_files.append(os.path.join(root, file))
    
    if bathymetry_files:
        print(f"📁 Found {len(bathymetry_files)} potential bathymetry files:")
        for file in bathymetry_files:
            print(f"   {file}")
    else:
        print(f"❌ No bathymetry files found")
        print(f"   This suggests negative values are NOT from bathymetry integration")

def main():
    """Main diagnostic function"""
    print("🔧 DEM ELEVATION ISSUES DIAGNOSTIC")
    print("=" * 60)
    print(f"Target: Investigate why DEM shows -9.38m to +44.04m instead of +9m to +51m RT2000")
    
    try:
        # 1. Find and analyze DEM files
        dem_files = find_dem_files()
        
        if not dem_files:
            print(f"❌ No DEM files found!")
            return
            
        print(f"\n📊 Found {len(dem_files)} DEM files to analyze:")
        
        results = []
        for dem_file in dem_files:
            result = analyze_dem_file(dem_file)
            if result:
                results.append((dem_file, result))
        
        # 2. Compare with expected values
        compare_with_expected_values()
        
        # 3. Check bathymetry integration
        check_bathymetry_integration()
        
        # 4. Summary and recommendations
        print(f"\n🎯 DIAGNOSTIC SUMMARY")
        print("=" * 30)
        
        if results:
            problematic_files = []
            for file_path, result in results:
                if result['min_elevation'] and result['min_elevation'] < 0:
                    problematic_files.append(file_path)
            
            if problematic_files:
                print(f"⚠️  Files with negative elevations: {len(problematic_files)}")
                for file_path in problematic_files:
                    print(f"   {os.path.basename(file_path)}")
                
                print(f"\n🔧 RECOMMENDED FIXES:")
                print(f"1. Check if bathymetry data is incorrectly integrated")
                print(f"2. Verify coordinate system is RT2000 (EPSG:3006)")
                print(f"3. Apply geoid height correction (+40-45m for Sweden)")
                print(f"4. Validate source DEM data quality")
                print(f"5. Check for unit conversion errors")
                
        print(f"\n✅ Diagnostic complete!")
        
    except Exception as e:
        print(f"❌ Error in diagnostic: {e}")
        traceback.print_exc()

if __name__ == "__main__":
    main()
