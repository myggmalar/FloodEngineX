"""
Simplified test for FloodEngine water flow simulation without dependencies
"""

import numpy as np
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class SimpleSaintVenant2D:
    """Simplified implementation of the 2D Saint-Venant equations"""
    
    def __init__(self, dem_array, dx=1.0, dy=1.0, manning_n=0.035):
        """Initialize the simplified model"""
        self.dem = dem_array
        self.dx = dx
        self.dy = dy
        self.shape = dem_array.shape
        self.h = np.zeros(self.shape)  # Water depth
        self.qx = np.zeros(self.shape)  # Unit discharge in x-direction
        self.qy = np.zeros(self.shape)  # Unit discharge in y-direction
        self.u = np.zeros(self.shape)   # Velocity in x-direction
        self.v = np.zeros(self.shape)   # Velocity in y-direction
        
        # Model parameters
        self.g = 9.81  # Gravity (m/s²)
        self.min_depth = 0.01  # Minimum depth for calculations (m)
        self.epsilon = 1e-6  # Small value to prevent division by zero
        self.cfl = 0.4  # Courant-Friedrichs-Lewy condition
        
        # Manning's n coefficient
        if isinstance(manning_n, (int, float)):
            self.manning = np.full(self.shape, manning_n)
        else:
            self.manning = manning_n
    
    def set_initial_condition(self, initial_depth=0.1):
        """Set initial water depth at highest points"""
        # Reset arrays
        self.h.fill(0.0)
        self.qx.fill(0.0)
        self.qy.fill(0.0)
        self.u.fill(0.0)
        self.v.fill(0.0)
        
        # Identify river network
        river_mask = self._identify_river_network()
        print(f"Identified {np.sum(river_mask)} river cells")
        
        # Find highest points in river network
        source_points = self._find_source_points(river_mask)
        print(f"Identified {len(source_points)} source points at high elevations")
        
        # Set initial water at source points
        for i, j in source_points:
            self.h[i, j] = initial_depth * 2  # Higher depth at source points
            print(f"Source at ({i},{j}): elev={self.dem[i,j]:.2f}m, depth={self.h[i,j]:.3f}m")
        
        # Add water to river network
        for i in range(self.shape[0]):
            for j in range(self.shape[1]):
                if river_mask[i, j] and self.h[i, j] == 0:
                    self.h[i, j] = initial_depth
        
        # Calculate initial velocities based on terrain gradient
        self._calculate_initial_velocities()
    
    def _identify_river_network(self):
        """Identify potential river cells based on local minima"""
        rows, cols = self.shape
        river_mask = np.zeros(self.shape, dtype=bool)
        
        for i in range(1, rows-1):
            for j in range(1, cols-1):
                # Check if cell is lower than surrounding cells
                current_elev = self.dem[i, j]
                neighbors = [
                    self.dem[i-1, j], self.dem[i+1, j],
                    self.dem[i, j-1], self.dem[i, j+1]
                ]
                # If cell is lower than most neighbors, mark as river
                lower_count = sum(1 for n_elev in neighbors if current_elev < n_elev)
                if lower_count >= 2:
                    river_mask[i, j] = True
        
        return river_mask
    
    def _find_source_points(self, river_mask):
        """Find source points at high elevations in river network"""
        source_points = []
        
        # Get river cells
        river_elevations = self.dem[river_mask]
        high_threshold = np.percentile(river_elevations, 90)  # Use top 10% of elevations
        
        # Find high points in river network
        for i in range(self.shape[0]):
            for j in range(self.shape[1]):
                if river_mask[i, j] and self.dem[i, j] >= high_threshold:
                    source_points.append((i, j))
        
        return source_points
    
    def _calculate_initial_velocities(self):
        """Calculate initial velocities based on terrain gradient"""
        # Create padded DEM for gradient calculation
        dem_pad = np.pad(self.dem, 1, mode='edge')
        
        for i in range(1, self.shape[0]+1):
            for j in range(1, self.shape[1]+1):
                if self.h[i-1, j-1] > self.min_depth:
                    # Calculate terrain gradient using neighboring cells
                    dx = (dem_pad[i, j+1] - dem_pad[i, j-1]) / (2 * self.dx)
                    dy = (dem_pad[i+1, j] - dem_pad[i-1, j]) / (2 * self.dy)
                    
                    # Initialize flow downhill (negative gradient)
                    if dx*dx + dy*dy > 1e-6:
                        grad_mag = np.sqrt(dx*dx + dy*dy)
                        self.u[i-1, j-1] = -dx/grad_mag * 0.2  # Scale velocity to 0.2 m/s
                        self.v[i-1, j-1] = -dy/grad_mag * 0.2
                    
                    # Update discharges
                    self.qx[i-1, j-1] = self.h[i-1, j-1] * self.u[i-1, j-1]
                    self.qy[i-1, j-1] = self.h[i-1, j-1] * self.v[i-1, j-1]
    
    def calculate_timestep(self):
        """Calculate stable time step based on CFL condition"""
        max_depth = np.max(self.h)
        if max_depth < self.min_depth:
            return 0.5  # Default timestep if no water
        
        max_u = np.max(np.abs(self.u))
        max_v = np.max(np.abs(self.v))
        max_c = np.sqrt(self.g * max_depth)  # Wave celerity
        
        # CFL condition
        dt_x = self.cfl * self.dx / (max_u + max_c + self.epsilon)
        dt_y = self.cfl * self.dy / (max_v + max_c + self.epsilon)
        
        return min(dt_x, dt_y, 1.0)  # Cap at 1.0 second
    
    def _update_fluxes(self, dt):
        """Update water depths and discharges based on flux calculations"""
        # Create padded arrays for flux calculation
        h_pad = np.pad(self.h, 1, mode='edge')
        qx_pad = np.pad(self.qx, 1, mode='edge')
        qy_pad = np.pad(self.qy, 1, mode='edge')
        dem_pad = np.pad(self.dem, 1, mode='edge')
        
        # Parameters for dam detection
        dam_threshold = 0.5  # Height difference to consider as dam (m)
        
        # Update cells
        for i in range(1, self.shape[0]+1):
            for j in range(1, self.shape[1]+1):
                if h_pad[i, j] < self.min_depth:
                    continue
                  # Water surface elevations
                wsC = dem_pad[i, j] + h_pad[i, j]     # Center
                wsN = dem_pad[i-1, j] + h_pad[i-1, j]  # North
                wsS = dem_pad[i+1, j] + h_pad[i+1, j]  # South
                wsW = dem_pad[i, j-1] + h_pad[i, j-1]  # West
                wsE = dem_pad[i, j+1] + h_pad[i, j+1]  # East
                
                # Check for dams/barriers
                dam_north = dem_pad[i-1, j] - dem_pad[i, j] > dam_threshold
                dam_south = dem_pad[i+1, j] - dem_pad[i, j] > dam_threshold
                dam_west = dem_pad[i, j-1] - dem_pad[i, j] > dam_threshold
                dam_east = dem_pad[i, j+1] - dem_pad[i, j] > dam_threshold
                
                # Handle dams - block flow unless water can overtop
                if dam_north and wsE < dem_pad[i-1, j]:
                    wsN = dem_pad[i-1, j]  # Block flow if water can't overtop
                if dam_south and wsE < dem_pad[i+1, j]:
                    wsS = dem_pad[i+1, j]
                if dam_west and wsE < dem_pad[i, j-1]:
                    wsW = dem_pad[i, j-1]
                if dam_east and wsE < dem_pad[i, j+1]:
                    wsE = dem_pad[i, j+1]
                
                # Calculate water surface gradients
                dws_dx = (wsE - wsW) / (2 * self.dx)
                dws_dy = (wsS - wsN) / (2 * self.dy)
                
                # Get velocities
                u = qx_pad[i, j] / max(h_pad[i, j], self.min_depth)
                v = qy_pad[i, j] / max(h_pad[i, j], self.min_depth)
                
                # Calculate friction terms (Manning's equation)
                vel_mag = np.sqrt(u**2 + v**2)
                if vel_mag > self.epsilon:
                    n = self.manning[i-1, j-1]
                    sf_x = n**2 * u * vel_mag / h_pad[i, j]**(4/3)
                    sf_y = n**2 * v * vel_mag / h_pad[i, j]**(4/3)
                else:
                    sf_x, sf_y = 0, 0
                
                # Source terms (gravity and friction)
                source_x = -self.g * h_pad[i, j] * dws_dx - self.g * h_pad[i, j] * sf_x
                source_y = -self.g * h_pad[i, j] * dws_dy - self.g * h_pad[i, j] * sf_y
                
                # Calculate fluxes for mass conservation
                flux_h_x = (qx_pad[i, j+1] - qx_pad[i, j-1]) / (2 * self.dx)
                flux_h_y = (qy_pad[i+1, j] - qy_pad[i-1, j]) / (2 * self.dy)
                
                # Update conserved variables
                self.h[i-1, j-1] -= dt * (flux_h_x + flux_h_y)
                self.qx[i-1, j-1] += dt * source_x
                self.qy[i-1, j-1] += dt * source_y
                
                # Ensure non-negative water depth
                self.h[i-1, j-1] = max(0, self.h[i-1, j-1])
                
                # Final dam blocking - prevent flow through unsubmerged dams
                for di, dj, vel in [(1, 0, self.qy), (-1, 0, self.qy), (0, 1, self.qx), (0, -1, self.qx)]:
                    ni, nj = i-1+di, j-1+dj
                    if 0 <= ni < self.shape[0] and 0 <= nj < self.shape[1]:
                        if (self.dem[ni, nj] - self.dem[i-1, j-1] > dam_threshold and 
                            self.dem[i-1, j-1] + self.h[i-1, j-1] < self.dem[ni, nj]):
                            if di == 1:  # South
                                self.qy[i-1, j-1] = min(0, self.qy[i-1, j-1])  # Allow only northward flow
                            elif di == -1:  # North
                                self.qy[i-1, j-1] = max(0, self.qy[i-1, j-1])  # Allow only southward flow
                            elif dj == 1:  # East
                                self.qx[i-1, j-1] = min(0, self.qx[i-1, j-1])  # Allow only westward flow
                            elif dj == -1:  # West
                                self.qx[i-1, j-1] = max(0, self.qx[i-1, j-1])  # Allow only eastward flow
    
    def _update_velocities(self):
        """Update velocities from discharges"""
        for i in range(self.shape[0]):
            for j in range(self.shape[1]):
                if self.h[i, j] > self.min_depth:
                    self.u[i, j] = self.qx[i, j] / self.h[i, j]
                    self.v[i, j] = self.qy[i, j] / self.h[i, j]
                else:
                    self.u[i, j] = 0
                    self.v[i, j] = 0
    
    def step(self, dt=None):
        """Advance simulation one time step"""
        if dt is None:
            dt = self.calculate_timestep()
        
        # Store current state
        h_old = self.h.copy()
        qx_old = self.qx.copy()
        qy_old = self.qy.copy()
        
        # First step
        self._update_fluxes(dt)
        self._update_velocities()
        
        # Second step (improved accuracy)
        h_int = self.h.copy()
        qx_int = self.qx.copy()
        qy_int = self.qy.copy()
        
        # Reset to original values for second step
        self.h = h_old
        self.qx = qx_old
        self.qy = qy_old
        
        # Second step
        self._update_fluxes(dt)
        self._update_velocities()
        
        # Average the results for better accuracy
        self.h = 0.5 * (h_old + h_int)
        self.qx = 0.5 * (qx_old + qx_int)
        self.qy = 0.5 * (qy_old + qy_int)
        
        return dt
    
    def get_water_surface(self):
        """Get water surface elevation"""
        return self.dem + self.h

def create_test_dem():
    """Create a test DEM with river channel and dam"""
    print("\nCreating test DEM...")
    size = 30
    dem = np.ones((size, size)) * 100.0  # Base elevation
    
    # Create a river channel with slope
    channel_width = 3
    channel_center = size // 2
    
    print("Adding river channel...")
    for i in range(size):
        # Elevation decreases from top to bottom
        channel_elevation = 98.0 - (i / size) * 4.0
        for j in range(channel_center - channel_width, channel_center + channel_width + 1):
            dem[i, j] = channel_elevation
    
    # Add a dam
    dam_row = size * 3 // 4  # Dam at 3/4 down the channel
    dam_height = 2.0
    print(f"Adding dam at row {dam_row} with height {dam_height}m...")
    
    for j in range(channel_center - channel_width - 1, channel_center + channel_width + 2):
        dem[dam_row, j] = dem[dam_row, j] + dam_height
    
    # Create basin behind dam
    print("Creating basin behind dam...")
    basin_depth = 1.0
    for i in range(dam_row - 5, dam_row):
        for j in range(channel_center - channel_width, channel_center + channel_width + 1):
            # Deepen area behind dam
            dem[i, j] = min(dem[i, j], dem[dam_row, j] - basin_depth)
    
    # Print DEM statistics
    print(f"\nDEM Statistics:")
    print(f"Size: {dem.shape}")
    print(f"Elevation range: {np.min(dem):.2f} - {np.max(dem):.2f} m")
    print(f"Channel center: column {channel_center}")
    print(f"Dam location: row {dam_row}")
    
    return dem, dam_row, channel_center

def main():
    """Run simplified flow simulation test"""
    print("=== Simplified FloodEngine Flow Simulation Test ===")
    
    # Create test DEM
    dem, dam_row, channel_center = create_test_dem()
    channel_width = 3  # Same as in create_test_dem
    
    # Initialize model
    print("\nInitializing Saint-Venant 2D model...")
    model = SimpleSaintVenant2D(dem)
    
    # Set initial conditions
    print("\nSetting initial conditions with enhanced source detection...")
    model.set_initial_condition(initial_depth=0.2)
    
    # Run simulation for several steps
    print("\nRunning flow simulation...")
    num_steps = 20
    
    for step in range(num_steps):
        dt = model.step()
        max_depth = np.max(model.h)
        wet_cells = np.sum(model.h > 0.01)
        max_vel = np.max(np.sqrt(model.u**2 + model.v**2))
        
        print(f"Step {step+1}: dt={dt:.3f}s, max_depth={max_depth:.3f}m, "
              f"wet_cells={wet_cells}, max_vel={max_vel:.3f}m/s")
    
    # Check water at high points
    print("\nChecking water flow from high points...")
    river_mask = model._identify_river_network()
    high_elevation = np.percentile(model.dem[river_mask], 75)
    high_points_with_water = np.logical_and(
        model.dem > high_elevation,
        model.h > 0.01
    )
    
    if np.sum(high_points_with_water) > 0:
        print(f"✓ PASS: {np.sum(high_points_with_water)} high elevation points have water")
    else:
        print("✗ FAIL: No water at high elevation points")
    
    # Check dam function
    print("\nChecking dam functionality...")
    water_before_dam = np.mean(model.h[dam_row-3:dam_row-1, channel_center-channel_width:channel_center+channel_width+1])
    water_after_dam = np.mean(model.h[dam_row+1:dam_row+3, channel_center-channel_width:channel_center+channel_width+1])
    
    print(f"Water depth before dam: {water_before_dam:.3f}m")
    print(f"Water depth after dam: {water_after_dam:.3f}m")
    
    if water_before_dam > water_after_dam:
        print("✓ PASS: Dam is functioning correctly (water building up behind dam)")
    else:
        print("✗ FAIL: Dam is not blocking water flow properly")
    
    print("\n=== Test Complete ===")

if __name__ == "__main__":
    main()
