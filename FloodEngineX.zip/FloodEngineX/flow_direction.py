"""
Flow Direction Utilities for FloodEngine
---------------------------------------
Ensures that water flows correctly downhill and prevents backward flow.
"""

import numpy as np
from osgeo import gdal
import logging
from scipy.ndimage import gaussian_filter
import os

logger = logging.getLogger("FloodEngine.FlowDirection")

def ensure_correct_flow_directions(dem_array, water_depth, velocity_x, velocity_y):
    """
    Ensure that water flows correctly downhill by checking and adjusting velocity vectors.
    This is a critical fix for cases where mathematical approximations might cause incorrect flow.
    
    Parameters:
        dem_array (numpy.ndarray): Digital Elevation Model array
        water_depth (numpy.ndarray): Water depth array
        velocity_x (numpy.ndarray): X component of velocity
        velocity_y (numpy.ndarray): Y component of velocity
        
    Returns:
        tuple: Corrected velocity arrays (velocity_x, velocity_y)
    """
    rows, cols = dem_array.shape
    min_depth = 0.05  # Only consider cells with at least 5cm of water
    
    # Create water surface elevation array
    water_surface = dem_array + water_depth
    
    # Smooth the water surface slightly to reduce noise
    valid_mask = water_depth > min_depth
    smoothed_surface = np.copy(water_surface)
    if np.sum(valid_mask) > 0:  # Only smooth if we have water
        smoothed_surface[valid_mask] = gaussian_filter(
            water_surface[valid_mask], sigma=1.0)
    
    # Pad the surface for gradient calculation
    padded = np.pad(smoothed_surface, 1, mode='edge')
    
    # Calculate surface gradient (water flows from high to low)
    for i in range(1, rows-1):
        for j in range(1, cols-1):
            if water_depth[i, j] <= min_depth:
                continue
                  # Calculate gradient of water surface using central difference
            dx = (padded[i+1, j+2] - padded[i+1, j]) / 2.0
            dy = (padded[i+2, j+1] - padded[i, j+1]) / 2.0
            
            # Special case handling for dam structures
            # Check surrounding cells for significant elevation changes that may indicate a dam
            neighbor_elevations = [
                padded[i, j+1],    # left
                padded[i+2, j+1],  # right
                padded[i+1, j],    # up
                padded[i+1, j+2]   # down
            ]
            center_elev = padded[i+1, j+1]
            elevation_diff = [abs(ne - center_elev) for ne in neighbor_elevations]
            max_diff = max(elevation_diff)
            
            # If we detect a significant elevation change (potential dam structure)
            is_dam_structure = max_diff > 1.0  # More than 1 meter drop indicates potential dam
            
            # For dam structures, force water to flow from higher to lower elevation
            if is_dam_structure:
                # Find the direction with the greatest downward slope
                directions = [(0, -1), (0, 1), (-1, 0), (1, 0)]  # Left, right, up, down
                slopes = []
                
                for di, (dy_dir, dx_dir) in enumerate(directions):
                    ni, nj = i + dy_dir + 1, j + dx_dir + 1  # +1 because padded
                    slope = center_elev - padded[ni, nj]
                    slopes.append(slope)
                
                # Find the steepest downslope direction
                max_slope_idx = np.argmax(slopes)
                if slopes[max_slope_idx] > 0:  # If there's a downslope
                    dy_flow, dx_flow = directions[max_slope_idx]
                    # Force flow in this direction
                    v_mag = np.sqrt(velocity_x[i, j]**2 + velocity_y[i, j]**2)
                    v_mag = max(v_mag, 0.5)  # Ensure minimum flow velocity
                    velocity_x[i, j] = v_mag * dx_flow
                    velocity_y[i, j] = v_mag * dy_flow
            
            # Standard handling for non-dam situations
            # Check if velocity direction is consistent with surface gradient
            # If water is flowing uphill, reverse the direction
            elif (dx * velocity_x[i, j] > 0) or (dy * velocity_y[i, j] > 0):
                # Velocity direction is wrong (water flowing uphill)
                # Correct the flow direction to follow the gradient
                grad_mag = np.sqrt(dx*dx + dy*dy)
                if grad_mag > 1e-6:
                    # Set velocity to flow downhill following the surface gradient
                    v_mag = np.sqrt(velocity_x[i, j]**2 + velocity_y[i, j]**2)
                    v_mag = max(v_mag, 0.2)  # Ensure minimum flow velocity
                    velocity_x[i, j] = -v_mag * (dx / grad_mag)
                    velocity_y[i, j] = -v_mag * (dy / grad_mag)
    
    logger.info("Applied flow direction corrections to ensure downhill flow")
    return velocity_x, velocity_y

def calculate_flow_direction(dem_array, resolution=1.0):
    """
    Calculate flow direction based on D8 algorithm.
    
    Parameters:
        dem_array (numpy.ndarray): Digital Elevation Model
        resolution (float): Cell size
        
    Returns:
        numpy.ndarray: Flow direction array (D8 encoding)
    """
    rows, cols = dem_array.shape
    flow_dir = np.zeros((rows, cols), dtype=np.uint8)
    
    # D8 flow direction encoding
    # 32 64 128
    # 16  0   1
    #  8  4   2
    
    for i in range(1, rows-1):
        for j in range(1, cols-1):
            if np.isnan(dem_array[i, j]):
                continue
                
            # Get elevation of central cell
            center_elev = dem_array[i, j]
            
            # Get elevation of 8 neighboring cells
            neighbors = [
                dem_array[i-1, j+1],  # NE (128)
                dem_array[i, j+1],    # E (1)
                dem_array[i+1, j+1],  # SE (2)
                dem_array[i+1, j],    # S (4)
                dem_array[i+1, j-1],  # SW (8)
                dem_array[i, j-1],    # W (16)
                dem_array[i-1, j-1],  # NW (32)
                dem_array[i-1, j]     # N (64)
            ]
            
            # Direction values
            dir_values = [128, 1, 2, 4, 8, 16, 32, 64]
            
            # Calculate elevation differences
            diffs = [center_elev - n if not np.isnan(n) else -np.inf for n in neighbors]
            
            # Find steepest descent
            max_diff_idx = np.argmax(diffs)
            
            # If steepest descent is positive, assign flow direction
            if diffs[max_diff_idx] > 0:
                flow_dir[i, j] = dir_values[max_diff_idx]
            else:
                # Handle pits/sinks
                flow_dir[i, j] = 0
    
    return flow_dir

def enforce_downhill_flow(velocity_x, velocity_y, dem_array, water_depth, min_depth=0.01):
    """
    Enforce downhill flow direction by adjusting velocity vectors to follow terrain gradient.
    
    Parameters:
        velocity_x (numpy.ndarray): X-component of velocity
        velocity_y (numpy.ndarray): Y-component of velocity
        dem_array (numpy.ndarray): Digital Elevation Model
        water_depth (numpy.ndarray): Water depth
        min_depth (float): Minimum depth for flow calculation
        
    Returns:
        tuple: Corrected velocity components (velocity_x, velocity_y)
    """
    rows, cols = dem_array.shape
    corrected_vx = velocity_x.copy()
    corrected_vy = velocity_y.copy()
    
    # Create padded DEM for gradient calculation
    dem_padded = np.pad(dem_array, 1, mode='edge')
    
    # Calculate gradient of terrain
    grad_x = np.zeros_like(dem_array)
    grad_y = np.zeros_like(dem_array)
    
    for i in range(rows):
        for j in range(cols):
            if water_depth[i, j] > min_depth:
                # Calculate terrain gradient using central difference
                grad_x[i, j] = (dem_padded[i+1, j+2] - dem_padded[i+1, j]) / 2
                grad_y[i, j] = (dem_padded[i+2, j+1] - dem_padded[i, j+1]) / 2
    
    # Normalize gradient vectors
    grad_mag = np.sqrt(grad_x**2 + grad_y**2)
    valid_mask = (grad_mag > 0) & (water_depth > min_depth)
    
    if np.any(valid_mask):
        grad_x[valid_mask] = grad_x[valid_mask] / grad_mag[valid_mask]
        grad_y[valid_mask] = grad_y[valid_mask] / grad_mag[valid_mask]
        
        # Calculate flow velocity magnitude
        velocity_mag = np.sqrt(velocity_x**2 + velocity_y**2)
        
        # Adjust flow direction to follow terrain gradient (downhill)
        # Dot product between velocity and negative gradient
        dot_product = -1 * (velocity_x * grad_x + velocity_y * grad_y)
        
        # Where dot product is negative, flow is going uphill, so correct it
        uphill_mask = (dot_product < 0) & valid_mask
        
        if np.any(uphill_mask):
            # Correct direction: use negative gradient direction
            corrected_vx[uphill_mask] = -grad_x[uphill_mask] * velocity_mag[uphill_mask]
            corrected_vy[uphill_mask] = -grad_y[uphill_mask] * velocity_mag[uphill_mask]
            
            logger.info(f"Corrected {np.sum(uphill_mask)} cells with uphill flow")
    
    return corrected_vx, corrected_vy

def smooth_flow_field(velocity_x, velocity_y, sigma=1.0):
    """
    Apply smoothing to flow velocity field to reduce noise.
    
    Parameters:
        velocity_x (numpy.ndarray): X-component of velocity
        velocity_y (numpy.ndarray): Y-component of velocity
        sigma (float): Gaussian smoothing parameter
        
    Returns:
        tuple: Smoothed velocity components
    """
    # Save original magnitude
    orig_magnitude = np.sqrt(velocity_x**2 + velocity_y**2)
    
    # Apply gaussian smoothing to each component
    smoothed_vx = gaussian_filter(velocity_x, sigma)
    smoothed_vy = gaussian_filter(velocity_y, sigma)
    
    # Calculate new magnitude
    new_magnitude = np.sqrt(smoothed_vx**2 + smoothed_vy**2)
    
    # Scale to maintain original magnitude where new magnitude is significant
    valid_mask = new_magnitude > 0.001
    if np.any(valid_mask):
        scale = np.ones_like(velocity_x)
        scale[valid_mask] = orig_magnitude[valid_mask] / new_magnitude[valid_mask]
        
        final_vx = smoothed_vx * scale
        final_vy = smoothed_vy * scale
    else:
        final_vx = smoothed_vx
        final_vy = smoothed_vy
    
    return final_vx, final_vy

def detect_channelized_flow(dem_array, water_depth, threshold_depth=0.5):
    """
    Detect areas of channelized flow based on water depth.
    
    Parameters:
        dem_array (numpy.ndarray): Digital Elevation Model
        water_depth (numpy.ndarray): Water depth
        threshold_depth (float): Threshold depth for channel detection
        
    Returns:
        numpy.ndarray: Boolean mask of channelized flow areas
    """
    # Smooth the water depth to reduce noise
    smoothed_depth = gaussian_filter(water_depth, sigma=1.5)
    
    # Apply threshold to identify deeper water (channels)
    channels = smoothed_depth > threshold_depth
    
    return channels

def analyze_flow_patterns(dem_path, water_surface_path, output_folder=None):
    """
    Analyze flow patterns from DEM and water surface to correct flow direction.
    
    Parameters:
        dem_path (str): Path to DEM file
        water_surface_path (str): Path to water surface elevation file
        output_folder (str): Output folder for results
        
    Returns:
        tuple: Paths to corrected velocity rasters
    """
    if output_folder is None:
        output_folder = os.path.dirname(dem_path)
    
    # Read DEM
    dem_ds = gdal.Open(dem_path)
    dem_array = dem_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
    geotransform = dem_ds.GetGeoTransform()
    projection = dem_ds.GetProjection()
    nodata = dem_ds.GetRasterBand(1).GetNoDataValue()
    dem_array[dem_array == nodata] = np.nan
    
    # Read water surface
    water_ds = gdal.Open(water_surface_path)
    water_surface = water_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
    water_nodata = water_ds.GetRasterBand(1).GetNoDataValue()
    water_surface[water_surface == water_nodata] = np.nan
    
    # Calculate water depth
    water_depth = np.maximum(water_surface - dem_array, 0)
    
    # Calculate gradient of water surface
    dx = abs(geotransform[1])
    dy = abs(geotransform[5])
    
    # Use central differences with padding
    pad_surface = np.pad(water_surface, pad_width=1, mode='edge')
    grad_x = np.zeros_like(water_surface)
    grad_y = np.zeros_like(water_surface)
    
    # Valid areas for calculation
    valid_mask = water_depth > 0.01
    
    rows, cols = water_surface.shape
    for i in range(rows):
        for j in range(cols):
            if valid_mask[i, j]:
                grad_x[i, j] = (pad_surface[i+1, j+2] - pad_surface[i+1, j]) / (2 * dx)
                grad_y[i, j] = (pad_surface[i+2, j+1] - pad_surface[i, j+1]) / (2 * dy)
    
    # Calculate velocity based on gradient and Manning's equation
    manning_n = 0.035  # Default Manning's roughness
    hydraulic_radius = water_depth.copy()  # Simplified for 2D
    
    slope_mag = np.sqrt(grad_x**2 + grad_y**2)
    velocity_mag = np.zeros_like(water_depth)
    
    # Manning's equation: v = (1/n) * R^(2/3) * S^(1/2)
    valid_mask = (slope_mag > 0) & (hydraulic_radius > 0.01)
    if np.any(valid_mask):
        velocity_mag[valid_mask] = (1.0 / manning_n) * \
                                  (hydraulic_radius[valid_mask] ** (2/3)) * \
                                  (slope_mag[valid_mask] ** 0.5)
    
    # Calculate velocity components
    velocity_x = np.zeros_like(water_depth)
    velocity_y = np.zeros_like(water_depth)
    
    # Velocity is in the direction of negative gradient
    valid_mask = slope_mag > 0
    if np.any(valid_mask):
        velocity_x[valid_mask] = -velocity_mag[valid_mask] * (grad_x[valid_mask] / slope_mag[valid_mask])
        velocity_y[valid_mask] = -velocity_mag[valid_mask] * (grad_y[valid_mask] / slope_mag[valid_mask])
    
    # Apply terrain-based correction
    corrected_vx, corrected_vy = enforce_downhill_flow(velocity_x, velocity_y, dem_array, water_depth)
    
    # Apply smoothing
    final_vx, final_vy = smooth_flow_field(corrected_vx, corrected_vy, sigma=1.5)
    
    # Calculate final magnitude
    final_magnitude = np.sqrt(final_vx**2 + final_vy**2)
    
    # Save outputs
    vx_path = os.path.join(output_folder, "velocity_x_corrected.tif")
    vy_path = os.path.join(output_folder, "velocity_y_corrected.tif")
    vmag_path = os.path.join(output_folder, "velocity_mag_corrected.tif")
    
    # Save velocity x-component
    driver = gdal.GetDriverByName("GTiff")
    out_ds = driver.Create(vx_path, cols, rows, 1, gdal.GDT_Float32)
    out_ds.SetGeoTransform(geotransform)
    out_ds.SetProjection(projection)
    out_band = out_ds.GetRasterBand(1)
    out_band.SetNoDataValue(-9999)
    out_band.WriteArray(np.where(np.isnan(final_vx), -9999, final_vx))
    out_ds.FlushCache()
    
    # Save velocity y-component
    out_ds = driver.Create(vy_path, cols, rows, 1, gdal.GDT_Float32)
    out_ds.SetGeoTransform(geotransform)
    out_ds.SetProjection(projection)
    out_band = out_ds.GetRasterBand(1)
    out_band.SetNoDataValue(-9999)
    out_band.WriteArray(np.where(np.isnan(final_vy), -9999, final_vy))
    out_ds.FlushCache()
    
    # Save velocity magnitude
    out_ds = driver.Create(vmag_path, cols, rows, 1, gdal.GDT_Float32)
    out_ds.SetGeoTransform(geotransform)
    out_ds.SetProjection(projection)
    out_band = out_ds.GetRasterBand(1)
    out_band.SetNoDataValue(-9999)
    out_band.WriteArray(np.where(np.isnan(final_magnitude), -9999, final_magnitude))
    out_ds.FlushCache()
    
    return vx_path, vy_path, vmag_path
