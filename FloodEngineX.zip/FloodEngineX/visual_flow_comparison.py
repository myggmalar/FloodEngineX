"""
Visual comparison test for fixed vs original flow direction algorithms
Uses both UI options and direct API calls to verify functionality
"""
import os
import sys
import numpy as np
from qgis.core import QgsProject, QgsRasterLayer
from qgis.utils import iface

# Import FloodEngine modules
try:
    from model_hydraulic import calculate_flood_area
    from flow_direction_flood import calculate_flood_area_with_flow_direction
    from flow_direction_flood_fixed import calculate_flood_area_with_flow_direction_FIXED
except ImportError as e:
    print(f"Error importing FloodEngine modules: {e}")
    print("Make sure you're running this script in QGIS Python console")
    sys.exit(1)

def setup_test_environment():
    """
    Set up test environment with sample DEM
    """
    # Get the current QGIS project
    project = QgsProject.instance()
    
    # Find a DEM layer in the current project
    dem_layer = None
    for layer_id, layer in project.mapLayers().items():
        if isinstance(layer, QgsRasterLayer) and "dem" in layer.name().lower():
            dem_layer = layer
            break
    
    if not dem_layer:
        print("❌ No DEM layer found in project. Please load a DEM before running this test.")
        return None
    
    print(f"✅ Using DEM layer: {dem_layer.name()}")
    return dem_layer.source()

def generate_comparison_images(dem_path, water_level=10.0, flow_q=50.0):
    """
    Generate comparison images between original and fixed flow direction algorithms
    """
    if not dem_path:
        return False
    
    print("Generating comparison images...")
    
    # Create output folders
    base_folder = os.path.dirname(dem_path)
    comparison_folder = os.path.join(base_folder, "flow_direction_comparison")
    os.makedirs(comparison_folder, exist_ok=True)
    
    # Water level mode comparison
    print("\n=== TESTING WATER LEVEL MODE ===")
    print("1. Testing original algorithm (no fixed flow)")
    original_wl = calculate_flood_area(
        iface, dem_path, water_level,
        output_folder=comparison_folder,
        flow_q=None,
        use_fixed_flow=False
    )
    
    print("2. Testing fixed algorithm (with fixed flow)")
    fixed_wl = calculate_flood_area(
        iface, dem_path, water_level,
        output_folder=comparison_folder,
        flow_q=None,
        use_fixed_flow=True
    )
    
    # Flow Q mode comparison
    print("\n=== TESTING FLOW Q MODE ===")
    print("1. Testing original algorithm (no fixed flow)")
    original_q = calculate_flood_area(
        iface, dem_path, None,
        output_folder=comparison_folder,
        flow_q=flow_q,
        use_fixed_flow=False
    )
    
    print("2. Testing fixed algorithm (with fixed flow)")
    fixed_q = calculate_flood_area(
        iface, dem_path, None,
        output_folder=comparison_folder,
        flow_q=flow_q,
        use_fixed_flow=True
    )
    
    print("\n=== COMPARISON COMPLETE ===")
    print(f"Results saved in: {comparison_folder}")
    print("You should visually verify the differences:")
    print("- Original flow: Water fills from low points like a bathtub")
    print("- Fixed flow: Water flows from high points and follows terrain downhill")
    
    return True

def run_visual_comparison():
    """
    Run the visual comparison test
    """
    print("Starting flow direction comparison test...")
    dem_path = setup_test_environment()
    
    if dem_path:
        result = generate_comparison_images(dem_path)
        if result:
            print("✅ Test completed successfully")
        else:
            print("❌ Test failed to generate comparison images")
    else:
        print("❌ Could not set up test environment")

if __name__ == "__main__":
    run_visual_comparison()
