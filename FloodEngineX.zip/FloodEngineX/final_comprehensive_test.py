#!/usr/bin/env python3
"""
Final Comprehensive Test for FloodEngine Animation Dialog Fix
=============================================================
This test verifies that all components work together:
1. QGIS module reload helper
2. Safe animation launcher
3. Updated UI method
4. Animation dialog persistence
"""

import sys
import os
import tempfile

# Add the FloodEngineX directory to path
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

def test_qgis_module_reload():
    """Test the QGIS module reload helper."""
    print("=" * 60)
    print("TESTING QGIS MODULE RELOAD HELPER")
    print("=" * 60)
    
    try:
        from qgis_module_reload_helper import force_qgis_module_reload, get_launch_animation_function
        
        # Test module reload
        print("🔄 Testing module reload...")
        count = force_qgis_module_reload()
        print(f"✅ Module reload completed (reloaded {count} modules)")
        
        # Test function retrieval
        print("🔍 Testing function retrieval...")
        func = get_launch_animation_function()
        if func:
            print("✅ Function retrieved successfully")
            
            # Check signature
            import inspect
            sig = inspect.signature(func)
            print(f"✅ Function signature: {sig}")
            return True
        else:
            print("❌ Could not retrieve function")
            return False
            
    except Exception as e:
        print(f"❌ Error in QGIS module reload test: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_safe_animation_launcher():
    """Test the safe animation launcher."""
    print("\n" + "=" * 60)
    print("TESTING SAFE ANIMATION LAUNCHER")
    print("=" * 60)
    
    try:
        from qgis_module_reload_helper import launch_animation_safe
        
        # Create a temporary test folder with some animation data
        test_folder = tempfile.mkdtemp(prefix="floodengine_test_")
        print(f"📁 Created test folder: {test_folder}")
        
        # Create a fake animation subfolder
        anim_folder = os.path.join(test_folder, "time_series_animation")
        os.makedirs(anim_folder, exist_ok=True)
        
        # Create some fake animation files that the launcher expects
        fake_files = [
            "flood_depth_t0000.tif",
            "flood_depth_t0001.tif", 
            "flood_depth_t0002.tif",
            "flood_velocity_t0000.tif",
            "flood_velocity_t0001.tif",
            "flood_velocity_t0002.tif",
            "ANIMATION_INSTRUCTIONS.md"
        ]
        
        for fake_file in fake_files:
            file_path = os.path.join(anim_folder, fake_file)
            with open(file_path, 'w') as f:
                if fake_file.endswith('.md'):
                    f.write("# Fake Animation Instructions\nThis is a test file.")
                else:
                    f.write("fake raster data")
        
        print(f"📁 Created {len(fake_files)} fake animation files")
        
        # Also create a rasters subfolder
        rasters_folder = os.path.join(anim_folder, "rasters")
        os.makedirs(rasters_folder, exist_ok=True)
        
        # Test the safe launcher
        print("🚀 Testing safe animation launcher...")
        try:
            result = launch_animation_safe(test_folder, parent_window=None)
            if result:
                print("✅ Safe launcher succeeded (dialog created)")
                
                # Clean up test data
                import shutil
                shutil.rmtree(test_folder)
                print("🧹 Cleaned up test folder")
                
                return True
            else:
                print("⚠️ Safe launcher returned False (no animation data or other issue)")
                return False
                
        except Exception as e:
            print(f"❌ Safe launcher error: {e}")
            import traceback
            traceback.print_exc()
            return False
            
    except Exception as e:
        print(f"❌ Error in safe launcher test: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_ui_integration():
    """Test that the UI can import and use the safe launcher."""
    print("\n" + "=" * 60)
    print("TESTING UI INTEGRATION")
    print("=" * 60)
    
    try:
        # Read the UI file and check for the safe launcher import
        ui_file = os.path.join(current_dir, "floodengine_ui.py")
        with open(ui_file, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        if "from qgis_module_reload_helper import launch_animation_safe" in content:
            print("✅ UI file contains safe launcher import")
        else:
            print("❌ UI file missing safe launcher import")
            return False
        
        if "launch_animation_safe(output_folder, parent_window)" in content:
            print("✅ UI file uses safe launcher correctly")
        else:
            print("❌ UI file not using safe launcher")
            return False
        
        # Test importing the updated UI components (without actually creating a Qt application)
        print("🔍 Testing UI module imports...")
        
        # This is a basic import test - we can't fully test the Qt components without QGIS
        try:
            # Just verify the imports would work
            exec("from qgis_module_reload_helper import launch_animation_safe")
            print("✅ Safe launcher can be imported from UI context")
            return True
        except Exception as e:
            print(f"❌ Import error: {e}")
            return False
            
    except Exception as e:
        print(f"❌ Error in UI integration test: {e}")
        return False

def test_dialog_persistence():
    """Test dialog persistence mechanisms."""
    print("\n" + "=" * 60)
    print("TESTING DIALOG PERSISTENCE")
    print("=" * 60)
    
    try:
        # Test dialog manager
        try:
            from dialog_manager import store_animation_dialog, get_active_dialogs
            print("✅ Dialog manager imports successfully")
            
            # Test storing a fake dialog (just a simple object)
            fake_dialog = type('FakeDialog', (), {'show': lambda: None})()
            store_animation_dialog(fake_dialog)
            print("✅ Dialog storage works")
            
            retrieved = get_active_dialogs()
            if retrieved and retrieved[-1] is fake_dialog:
                print("✅ Dialog retrieval works")
                return True
            else:
                print("⚠️ Dialog retrieval returned different object")
                return False
                
        except ImportError:
            print("⚠️ Dialog manager not available")
            return False
            
    except Exception as e:
        print(f"❌ Error in dialog persistence test: {e}")
        return False

def main():
    """Run all tests."""
    print("FloodEngine Animation Dialog Fix - Comprehensive Test")
    print("=" * 60)
    
    tests = [
        ("QGIS Module Reload", test_qgis_module_reload),
        ("Safe Animation Launcher", test_safe_animation_launcher),
        ("UI Integration", test_ui_integration),
        ("Dialog Persistence", test_dialog_persistence),
    ]
    
    results = []
    for test_name, test_func in tests:
        print(f"\n🧪 Running {test_name} test...")
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"❌ Test {test_name} failed with exception: {e}")
            results.append((test_name, False))
    
    # Summary
    print("\n" + "=" * 60)
    print("TEST RESULTS SUMMARY")
    print("=" * 60)
    
    passed = 0
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{test_name:25} {status}")
        if result:
            passed += 1
    
    print("-" * 60)
    print(f"TOTAL: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 ALL TESTS PASSED!")
        print("The animation dialog fix is ready for use in QGIS.")
        print("\n📋 NEXT STEPS:")
        print("1. Restart QGIS or reload the FloodEngine plugin")
        print("2. Run a simulation with 'Create animation' checked")
        print("3. The animation dialog should appear and remain visible")
    else:
        print(f"\n⚠️ {total - passed} test(s) failed. Please review the errors above.")
    
    return passed == total

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
