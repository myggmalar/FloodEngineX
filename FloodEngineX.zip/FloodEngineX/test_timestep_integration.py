#!/usr/bin/env python3
"""
Test script for timestep saving coordination in FloodEngine
Tests the integration between Saint-Venant simulations and the hydraulic model
"""

import os
import sys
import numpy as np
import tempfile
import shutil
from unittest.mock import MagicMock

def test_timestep_coordination():
    """Test the timestep saving functionality integration"""
    print("🧪 Testing timestep saving coordination...")
    
    # Create mock QGIS interface
    mock_iface = MagicMock()
    mock_messagebar = MagicMock()
    mock_iface.messageBar.return_value = mock_messagebar
    
    # Create temporary directories for testing
    test_dir = tempfile.mkdtemp(prefix="floodengine_test_")
    dem_path = os.path.join(test_dir, "test_dem.tif")
    output_dir = os.path.join(test_dir, "output")
    os.makedirs(output_dir, exist_ok=True)
    
    try:
        # Create a simple test DEM
        create_test_dem(dem_path)
        
        print(f"📁 Test directory: {test_dir}")
        print(f"🗺️  Test DEM: {dem_path}")
        
        # Test 1: Verify Saint-Venant import path is working
        print("\n1️⃣ Testing Saint-Venant import...")
        try:
            from saint_venant_2d_fixed import simulate_saint_venant_2d
            print("✅ Saint-Venant fixed module imported successfully")
        except ImportError as e:
            print(f"❌ Saint-Venant import failed: {e}")
            return False
        
        # Test 2: Test hydraulic integration import
        print("\n2️⃣ Testing hydraulic integration import...")
        try:
            from hydraulic_integration_fixed import run_saint_venant_simulation
            print("✅ Hydraulic integration module imported successfully")
        except ImportError as e:
            print(f"❌ Hydraulic integration import failed: {e}")
            return False
        
        # Test 3: Test simulate_over_time function exists in model_hydraulic
        print("\n3️⃣ Testing model_hydraulic function availability...")
        try:
            from model_hydraulic import simulate_over_time
            print("✅ simulate_over_time function available")
        except ImportError as e:
            print(f"❌ simulate_over_time import failed: {e}")
            return False
        
        # Test 4: Test small Saint-Venant simulation
        print("\n4️⃣ Testing Saint-Venant simulation...")
        try:
            water_files, velocity_files = simulate_saint_venant_2d(
                dem_path=dem_path,
                initial_water_level=10.0,  # 10m water level
                output_folder=output_dir,
                time_steps=3,  # Small test
                time_step_seconds=1.0,
                inflow_rate=10.0,  # 10 m³/s
                bounding_box=None,
                resolution_factor=2  # Half resolution for speed
            )
            
            print(f"✅ Saint-Venant simulation completed")
            print(f"   Water files: {len(water_files)}")
            print(f"   Velocity files: {len(velocity_files)}")
            
            # Verify files exist
            missing_files = []
            for wf in water_files[:2]:  # Check first 2 files
                if not os.path.exists(wf):
                    missing_files.append(wf)
            
            if missing_files:
                print(f"❌ Missing output files: {missing_files}")
                return False
            else:
                print("✅ Output files created successfully")
                
        except Exception as e:
            print(f"❌ Saint-Venant simulation failed: {e}")
            return False
        
        # Test 5: Test hydraulic integration coordination
        print("\n5️⃣ Testing hydraulic integration coordination...")
        try:
            result = run_saint_venant_simulation(
                iface=mock_iface,
                dem_path=dem_path,
                water_level=10.0,
                flow_q=5.0,
                output_folder=output_dir,
                time_steps=2,
                bounding_box=None,
                resolution_factor=2
            )
            
            if result is not None:
                print("✅ Hydraulic integration coordination successful")
                print(f"   Water files: {len(result.get('water_files', []))}")
                print(f"   Final water file: {result.get('final_water', 'None')}")
            else:
                print("⚠️ Hydraulic integration returned None (may be expected in test environment)")
                
        except Exception as e:
            print(f"❌ Hydraulic integration failed: {e}")
            return False
        
        # Test 6: Test timestep simulation function (if available)
        print("\n6️⃣ Testing timestep simulation function...")
        try:
            # Test with simple timestep data
            water_levels = [9.0, 10.0, 11.0]
            time_steps = [1, 2, 3]
            
            # This will test the structure but might fail due to QGIS dependencies
            result = simulate_over_time(
                iface=mock_iface,
                dem_path=dem_path,
                water_levels=water_levels,
                time_steps=time_steps,
                output_folder=output_dir
            )
            
            if result:
                print(f"✅ Timestep simulation completed: {result}")
            else:
                print("⚠️ Timestep simulation returned None")
                
        except Exception as e:
            print(f"⚠️ Timestep simulation test failed: {e}")
            print("   (This may be expected due to QGIS dependencies)")
        
        print("\n🎉 Timestep coordination test completed successfully!")
        return True
        
    except Exception as e:
        print(f"❌ Test failed with error: {e}")
        return False
        
    finally:
        # Clean up test directory
        try:
            shutil.rmtree(test_dir)
            print(f"🧹 Cleaned up test directory: {test_dir}")
        except:
            print(f"⚠️ Could not clean up test directory: {test_dir}")

def create_test_dem(dem_path):
    """Create a simple test DEM for testing purposes"""
    try:
        from osgeo import gdal
        import numpy as np
        
        # Create a simple 20x20 DEM with elevation gradient
        width, height = 20, 20
        data = np.zeros((height, width), dtype=np.float32)
        
        # Create a simple terrain with a valley in the middle
        for i in range(height):
            for j in range(width):
                # Create a valley running diagonally
                dist_from_center = abs(i - height//2) + abs(j - width//2)
                data[i, j] = 5.0 + dist_from_center * 0.5
        
        # Create the GeoTIFF
        driver = gdal.GetDriverByName('GTiff')
        ds = driver.Create(dem_path, width, height, 1, gdal.GDT_Float32)
        
        # Set geotransform (simplified coordinates)
        ds.SetGeoTransform([0, 10, 0, 0, 0, -10])  # 10m resolution
        
        # Set simple projection (UTM-like)
        ds.SetProjection('PROJCS["UTM Zone 33N",GEOGCS["WGS 84",DATUM["WGS_1984",SPHEROID["WGS 84",6378137,298.257223563]],PRIMEM["Greenwich",0],UNIT["degree",0.0174532925199433]],PROJECTION["Transverse_Mercator"],PARAMETER["latitude_of_origin",0],PARAMETER["central_meridian",15],PARAMETER["scale_factor",0.9996],PARAMETER["false_easting",500000],PARAMETER["false_northing",0],UNIT["metre",1]]')
        
        # Write data
        band = ds.GetRasterBand(1)
        band.WriteArray(data)
        band.SetNoDataValue(-9999)
        
        # Cleanup
        ds = None
        
        print(f"✅ Created test DEM: {dem_path}")
        
    except ImportError:
        # Fallback: create a dummy file
        with open(dem_path, 'w') as f:
            f.write("DUMMY DEM FILE FOR TESTING")
        print(f"⚠️ Created dummy DEM file (GDAL not available): {dem_path}")

def main():
    """Main test function"""
    print("=" * 60)
    print("FloodEngine Timestep Integration Test")
    print("=" * 60)
    
    # Add current directory to Python path to import modules
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if current_dir not in sys.path:
        sys.path.insert(0, current_dir)
    
    success = test_timestep_coordination()
    
    if success:
        print("\n🎯 All tests passed! Timestep saving coordination is working.")
        return 0
    else:
        print("\n💥 Some tests failed. Check the output above.")
        return 1

if __name__ == "__main__":
    exit(main())
