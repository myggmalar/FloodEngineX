"""
Enhanced test script for FloodEngine water flow simulation
"""

import os
import sys
import numpy as np
import logging
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Import the model
from saint_venant_2d import SaintVenant2D

def create_test_dem(size=30, channel_width=3, dam_height=2.0):
    """
    Create a test DEM with a river channel and dam
    """
    print("\nCreating test DEM...")
    dem = np.ones((size, size)) * 100.0  # Base elevation
    
    # Create a channel with varying elevation (higher at top)
    channel_center = size // 2
    
    print("Adding river channel...")
    for i in range(size):
        # Calculate elevation (decreasing from top to bottom)
        channel_elevation = 98.0 - (i / size) * 4.0
        for j in range(channel_center - channel_width, channel_center + channel_width + 1):
            dem[i, j] = channel_elevation
    
    # Add a dam
    dam_row = size * 3 // 4  # Dam at 3/4 down the channel
    print(f"Adding dam at row {dam_row} with height {dam_height}m...")
    
    for j in range(channel_center - channel_width - 1, channel_center + channel_width + 2):
        dem[dam_row, j] = dem[dam_row, j] + dam_height
    
    # Create basin behind dam
    print("Creating basin behind dam...")
    basin_depth = 1.0
    for i in range(dam_row - 5, dam_row):
        for j in range(channel_center - channel_width, channel_center + channel_width + 1):
            # Deepen the area behind the dam
            dem[i, j] = min(dem[i, j], dem[dam_row, j] - basin_depth)
    
    # Print DEM statistics
    print(f"\nDEM Statistics:")
    print(f"Size: {dem.shape}")
    print(f"Elevation range: {np.min(dem):.2f} - {np.max(dem):.2f} m")
    print(f"Channel center: column {channel_center}")
    print(f"Dam location: row {dam_row}")
    
    return dem, channel_center, dam_row

def visualize_water_surface(dem, water_surface, title):
    """
    Visualize the water surface in 3D
    """
    try:
        fig = plt.figure(figsize=(12, 8))
        ax = fig.add_subplot(111, projection='3d')
        
        # Create a mesh grid for plotting
        x = np.arange(0, dem.shape[1], 1)
        y = np.arange(0, dem.shape[0], 1)
        X, Y = np.meshgrid(x, y)
        
        # Plot terrain
        terrain = ax.plot_surface(X, Y, dem, cmap=cm.terrain, alpha=0.7, linewidth=0)
        
        # Plot water surface
        water = ax.plot_surface(X, Y, water_surface, cmap=cm.Blues, alpha=0.5, linewidth=0)
        
        ax.set_title(title)
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('Elevation (m)')
        
        # Add colorbar
        fig.colorbar(terrain, ax=ax, shrink=0.5, aspect=5, label='Terrain Elevation (m)')
        
        plt.savefig(f"{title.replace(' ', '_')}.png")
        print(f"Saved visualization to {title.replace(' ', '_')}.png")
        
    except Exception as e:
        print(f"Visualization error: {e}")

def run_simulation(model, num_steps=10, dt=1.0):
    """
    Run a flow simulation for a given number of steps
    """
    print("\nRunning simulation...")
    for step in range(num_steps):
        # Advance simulation
        actual_dt = model.step(dt)
        
        # Calculate stats
        max_depth = np.max(model.h)
        wet_cells = np.sum(model.h > 0.01)
        water_volume = np.sum(model.h) * model.dx * model.dy
        
        # Calculate max flow velocity
        if max_depth > 0:
            max_velocity = np.max(np.sqrt(model.u**2 + model.v**2))
        else:
            max_velocity = 0
            
        print(f"Step {step+1}: dt={actual_dt:.3f}s, max_depth={max_depth:.3f}m, wet_cells={wet_cells}, "
              f"volume={water_volume:.1f}m³, max_vel={max_velocity:.3f}m/s")
        
        # Detect water reaching the dam
        if step == 0 or step == num_steps // 2 or step == num_steps - 1:
            water_surface = model.get_water_surface()
            visualize_water_surface(model.dem, water_surface, f"Water Surface - Step {step+1}")
    
    return model

def check_water_at_highpoints(model):
    """Verify that water is flowing from high points"""
    print("\nChecking water flow from high points...")
    
    # Get elevations of cells with water
    wet_cells = model.h > 0.01
    if np.sum(wet_cells) == 0:
        print("No wet cells found!")
        return False
    
    wet_elevations = model.dem[wet_cells]
    min_elev = np.min(wet_elevations)
    max_elev = np.max(wet_elevations)
    
    # Get river channel cells (assumes river is where elevation is lower than surroundings)
    river_cells = np.zeros_like(model.dem, dtype=bool)
    for i in range(1, model.dem.shape[0]-1):
        for j in range(1, model.dem.shape[1]-1):
            neighbors = [
                model.dem[i-1, j], model.dem[i+1, j],
                model.dem[i, j-1], model.dem[i, j+1]
            ]
            lower_count = sum(1 for n_elev in neighbors if model.dem[i, j] < n_elev)
            if lower_count >= 2:
                river_cells[i, j] = True
    
    # Find highest points in river that have water
    high_elev_threshold = np.percentile(model.dem[river_cells], 75)
    high_points_with_water = np.logical_and(model.dem > high_elev_threshold, model.h > 0.01)
    
    print(f"Elevation range of wet cells: {min_elev:.2f} - {max_elev:.2f} m")
    print(f"Number of river cells: {np.sum(river_cells)}")
    print(f"High elevation threshold (75th percentile): {high_elev_threshold:.2f} m")
    print(f"Number of high points with water: {np.sum(high_points_with_water)}")
    
    if np.sum(high_points_with_water) > 0:
        print("✓ PASS: Water is present at high elevation points")
        return True
    else:
        print("✗ FAIL: No water at high elevation points")
        return False

def check_dam_function(model, dam_row):
    """Verify dam is functioning properly"""
    print("\nChecking dam functionality...")
    
    # Check water levels before and after dam
    before_dam = np.mean(model.h[dam_row-3:dam_row-1, :])
    after_dam = np.mean(model.h[dam_row+1:dam_row+3, :])
    
    print(f"Average water depth before dam: {before_dam:.3f} m")
    print(f"Average water depth after dam: {after_dam:.3f} m")
    
    dam_height = np.max(model.dem[dam_row, :]) - np.min(model.dem[dam_row-1, :])
    print(f"Dam height: {dam_height:.2f} m")
    
    # Dam is functioning if water depth is higher behind dam
    if before_dam > after_dam:
        print("✓ PASS: Dam is blocking water flow (higher water level upstream)")
        return True
    else:
        print("✗ FAIL: Dam is not properly blocking water")
        return False

def main():
    """Test the fixed Saint-Venant 2D model"""
    print("=== Testing FloodEngine Water Flow Simulation ===")
    
    # Create test DEM
    dem, channel_center, dam_row = create_test_dem(size=30, channel_width=3, dam_height=2.0)
    
    # Initialize the model
    print("\nInitializing Saint-Venant 2D model...")
    geotransform = (0, 1, 0, 0, 0, -1)  # Simple 1x1 meter cells
    model = SaintVenant2D(dem, geotransform, manning_n=0.035)
    
    # Set initial conditions
    print("Setting initial conditions...")
    model.set_initial_condition(water_level=101.0, river_detection=True)
    
    # Run simulation
    model = run_simulation(model, num_steps=30, dt=0.5)
    
    # Check results
    high_points_passed = check_water_at_highpoints(model)
    dam_passed = check_dam_function(model, dam_row)
    
    if high_points_passed and dam_passed:
        print("\n✓ SUCCESS: All tests passed!")
    else:
        print("\n✗ FAILURE: Some tests failed.")
    
if __name__ == "__main__":
    main()
