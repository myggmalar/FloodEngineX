"""
FloodEngine Advanced Hydraulic Integration
----------------------------------------
Functions to integrate advanced hydraulic modeling into FloodEngine plugin.
Add these functions to your FloodEngine class.
"""

import os
try:
    from qgis.core import QgsRasterLayer, QgsProject, QgsMapLayer, QgsWkbTypes
except ImportError:
    # For testing environments without QGIS installed
    pass

import os
from qgis.core import QgsRasterLayer, QgsProject, QgsMapLayer, QgsWkbTypes

def select_calculation_area(self):
    """
    Open a dialog to select calculation area and resolution for optimization
    """
    from .bounding_box_dialog import show_bounding_box_dialog
    
    # Show the dialog
    result = show_bounding_box_dialog(self.iface)
    
    if result:
        # Store the results as instance variables
        self.bounding_box = result.get("bounding_box")
        self.resolution_factor = result.get("resolution_factor")
        
        # Show confirmation to user
        if self.bounding_box:
            bbox_str = f"({self.bounding_box[0]:.0f},{self.bounding_box[1]:.0f}) to ({self.bounding_box[2]:.0f},{self.bounding_box[3]:.0f})"
            resolution_str = "original resolution" if self.resolution_factor == 1 else f"1/{self.resolution_factor} resolution"
            
            self.iface.messageBar().pushInfo("FloodEngine", 
                                          f"Calculation area set to {bbox_str} at {resolution_str}")
        else:
            self.iface.messageBar().pushInfo("FloodEngine", 
                                          f"Using full DEM extent at 1/{self.resolution_factor} resolution")
        return True
    
    return False

def run_advanced_hydraulic_model(self):
    """
    Run the advanced 2D Saint-Venant hydraulic model
    """
    from .hydraulic_integration import run_saint_venant_simulation

    # Get input parameters from UI
    try:
        dem_path = self.dlg.dem_input.text()
        output_folder = self.dlg.output_folder.text()
        water_level_text = self.dlg.water_level_input.text()
        flow_q_text = self.dlg.flow_q_input.text() if hasattr(self.dlg, 'flow_q_input') else ""
        
        # Parse numeric values
        water_level = float(water_level_text) if water_level_text else None
        flow_q = float(flow_q_text) if flow_q_text else None
        
        # Set time steps (could be customizable in UI)
        time_steps = 10
        
        if hasattr(self.dlg, 'timestep_spinbox'):
            time_steps = self.dlg.timestep_spinbox.value()
            
        # Get optimization parameters if available from stored values (set by select_calculation_area)
        bounding_box = getattr(self, 'bounding_box', None)
        resolution_factor = getattr(self, 'resolution_factor', 1)
        
        # Validate inputs
        if not dem_path:
            self.iface.messageBar().pushWarning("FloodEngine", "Please select a DEM file")
            return
        
        if not output_folder:
            self.iface.messageBar().pushWarning("FloodEngine", "Please select an output folder")
            return
        
        if water_level is None and flow_q is None:
            self.iface.messageBar().pushWarning("FloodEngine", 
                                             "Please enter either a water level or a flow rate")
            return
        
        # Run the model
        results = run_saint_venant_simulation(
            iface=self.iface,
            dem_path=dem_path,
            water_level=water_level,
            flow_q=flow_q,
            output_folder=output_folder,
            time_steps=time_steps,
            bounding_box=bounding_box,
            resolution_factor=resolution_factor
        )
        
        if results:
            # Load result layers
            final_water = results.get("final_water")
            final_velocity = results.get("final_velocity")
            
            if final_water and os.path.exists(final_water):
                water_layer = QgsRasterLayer(final_water, "Final Water Surface")
                if water_layer.isValid():
                    QgsProject.instance().addMapLayer(water_layer)
            
            if final_velocity and os.path.exists(final_velocity):
                velocity_layer = QgsRasterLayer(final_velocity, "Final Velocity")
                if velocity_layer.isValid():
                    QgsProject.instance().addMapLayer(velocity_layer)
                    
            # Return results path for further operations
            return results
        
    except ValueError as e:
        self.iface.messageBar().pushCritical("FloodEngine", f"Invalid numeric value: {str(e)}")
    except Exception as e:
        self.iface.messageBar().pushCritical("FloodEngine", f"Error running model: {str(e)}")
        import traceback
        traceback.print_exc()
    
    return None

def generate_accurate_streamlines(self, flood_layer=None, dem_path=None, output_folder=None, flow_q=None):
    """
    Generate improved streamlines that accurately follow terrain and hydraulic principles.
    
    Parameters:
        flood_layer: QgsVectorLayer of the flood polygon (optional)
        dem_path: Path to the DEM file (optional)
        output_folder: Output folder (optional)
        flow_q: Flow rate in m³/s (optional)
    
    Returns:
        QgsVectorLayer: Layer with streamlines
    """
    from .hydraulic_integration import generate_improved_streamlines
    
    try:
        # Use provided parameters or get from UI
        if dem_path is None:
            dem_path = self.dlg.dem_input.text()
            
        if output_folder is None:
            output_folder = self.dlg.output_folder.text()
            
        if flow_q is None and hasattr(self.dlg, 'flow_q_input'):
            flow_q_text = self.dlg.flow_q_input.text()
            flow_q = float(flow_q_text) if flow_q_text else None
            
        # Get flood layer if not provided
        if flood_layer is None:
            # Try to find flood layer in current project
            layers = QgsProject.instance().mapLayers().values()
            flood_layers = [layer for layer in layers if 
                           layer.type() == QgsMapLayer.VectorLayer and
                           layer.geometryType() == QgsWkbTypes.PolygonGeometry and
                           "flood" in layer.name().lower()]
            
            if flood_layers:
                # Use the first found flood layer
                flood_layer = flood_layers[0]
                self.iface.messageBar().pushInfo("FloodEngine", 
                                              f"Using flood layer: {flood_layer.name()}")
            else:
                self.iface.messageBar().pushWarning("FloodEngine", 
                                                 "No flood layer found. Please run flood model first.")
                return None
        
        # Validate inputs
        if not dem_path:
            self.iface.messageBar().pushWarning("FloodEngine", "Please select a DEM file")
            return None
            
        if not output_folder:
            self.iface.messageBar().pushWarning("FloodEngine", "Please select an output folder")
            return None
            
        if not flood_layer or not flood_layer.isValid():
            self.iface.messageBar().pushWarning("FloodEngine", "Invalid flood layer")
            return None
        
        # Generate streamlines
        streamline_layer = generate_improved_streamlines(
            iface=self.iface,
            dem_path=dem_path,
            flood_layer=flood_layer,
            output_folder=output_folder,
            flow_q=flow_q
        )
        
        return streamline_layer
        
    except Exception as e:
        self.iface.messageBar().pushCritical("FloodEngine", f"Error generating streamlines: {str(e)}")
        import traceback
        traceback.print_exc()
        
    return None

def fix_flow_direction(self, dem_path=None, water_layer=None, output_folder=None):
    """
    Fix flow direction to ensure correct downhill flow.
    
    Parameters:
        dem_path: Path to DEM file (optional)
        water_layer: QgsRasterLayer of water surface (optional)
        output_folder: Output folder (optional)
        
    Returns:
        dict: Paths to corrected velocity files
    """
    from .hydraulic_integration import fix_flow_directions
    
    try:
        # Use provided parameters or get from UI
        if dem_path is None:
            dem_path = self.dlg.dem_input.text()
            
        if output_folder is None:
            output_folder = self.dlg.output_folder.text()
            
        # Get water surface layer if not provided
        if water_layer is None:
            # Try to find water layer in current project
            layers = QgsProject.instance().mapLayers().values()
            water_layers = [layer for layer in layers if 
                           layer.type() == QgsMapLayer.RasterLayer and
                           ("water" in layer.name().lower() or 
                            "surface" in layer.name().lower() or
                            "flood" in layer.name().lower())]
            
            if water_layers:
                # Use the first found water layer
                water_layer = water_layers[0]
                self.iface.messageBar().pushInfo("FloodEngine", 
                                              f"Using water surface layer: {water_layer.name()}")
            else:
                self.iface.messageBar().pushWarning("FloodEngine", 
                                                 "No water surface layer found.")
                return None
        
        # Validate inputs
        if not dem_path:
            self.iface.messageBar().pushWarning("FloodEngine", "Please select a DEM file")
            return None
            
        if not output_folder:
            self.iface.messageBar().pushWarning("FloodEngine", "Please select an output folder")
            return None
            
        if not water_layer or not water_layer.isValid():
            self.iface.messageBar().pushWarning("FloodEngine", "Invalid water surface layer")
            return None
          # Fix flow directions with bounding box
        result = fix_flow_directions(
            iface=self.iface,
            dem_path=dem_path,
            water_surface_path=water_layer.source(),
            output_folder=output_folder
        )
        
        if result:
            # Load result layers
            vx_path = result.get("velocity_x")
            vy_path = result.get("velocity_y")
            vmag_path = result.get("velocity_magnitude")
            
            if vmag_path and os.path.exists(vmag_path):
                vmag_layer = QgsRasterLayer(vmag_path, "Corrected Velocity")
                if vmag_layer.isValid():
                    QgsProject.instance().addMapLayer(vmag_layer)
        
        return result
        
    except Exception as e:
        self.iface.messageBar().pushCritical("FloodEngine", f"Error fixing flow direction: {str(e)}")
        import traceback
        traceback.print_exc()
        
    return None
