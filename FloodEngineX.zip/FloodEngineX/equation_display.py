"""
FloodEngine Equations Module
----------------------------
This module handles the display of mathematical equations used in the FloodEngine model.
It provides a dialog that can render LaTeX-style equations for different model components.
"""

from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, 
    QScrollArea, QWidget, QTabWidget, QTextBrowser
)
from PyQt5.QtGui import QPixmap, QFont
from PyQt5.QtCore import Qt


class EquationDisplay(QDialog):
    """Dialog for displaying equations related to the flood model."""
    
    def __init__(self, equation_type, parent=None):
        """Initialize the equation display dialog.
        
        Parameters:
            equation_type (str): Type of equation to display (e.g., "hydraulic_model", "erosion")
            parent (QWidget): Parent widget
        """
        super().__init__(parent)
        self.equation_type = equation_type
        self.setWindowTitle(f"FloodEngine - {self._get_title()}")
        self.resize(800, 600)
        self.setup_ui()
        self.load_equations()
        
    def _get_title(self):
        """Get a human-readable title based on the equation type."""
        titles = {
            "hydraulic_model": "Hydraulic Model Equations",
            "stream_processing": "Stream & Terrain Processing Equations",
            "erosion": "Erosion & Sediment Transport Equations",
            "groundwater": "Groundwater Model Equations",
            "urban_flood": "Urban Flood Modeling Equations"
        }
        return titles.get(self.equation_type, "Model Equations")
        
    def setup_ui(self):
        """Set up the user interface."""
        layout = QVBoxLayout()
        self.setLayout(layout)
        
        # Create tab widget for different equation categories
        self.tab_widget = QTabWidget()
        layout.addWidget(self.tab_widget)
        
        # Add close button at bottom
        button_layout = QHBoxLayout()
        close_button = QPushButton("Close")
        close_button.clicked.connect(self.close)
        button_layout.addStretch()
        button_layout.addWidget(close_button)
        layout.addLayout(button_layout)
        
    def load_equations(self):
        """Load and display the appropriate equations based on the type."""
        if self.equation_type == "hydraulic_model":
            self._load_hydraulic_equations()
        elif self.equation_type == "stream_processing":
            self._load_stream_equations()
        elif self.equation_type == "erosion":
            self._load_erosion_equations()
        elif self.equation_type == "groundwater":
            self._load_groundwater_equations()
        elif self.equation_type == "urban_flood":
            self._load_urban_equations()
    
    def _create_equation_tab(self, title, equations, descriptions):
        """Create a tab with equations and descriptions.
        
        Parameters:
            title (str): Tab title
            equations (list): List of equation strings in LaTeX format
            descriptions (list): List of descriptions corresponding to equations
        """
        # Create a widget for this tab
        tab = QWidget()
        tab_layout = QVBoxLayout()
        tab.setLayout(tab_layout)
        
        # Create a scroll area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll_content = QWidget()
        scroll_layout = QVBoxLayout()
        scroll_content.setLayout(scroll_layout)
        
        # Add equation-description pairs
        for i, (equation, description) in enumerate(zip(equations, descriptions)):
            # Create equation display
            eq_browser = QTextBrowser()
            eq_browser.setMaximumHeight(100)
            eq_browser.setHtml(f"<div style='text-align:center; font-size:16pt;'>{equation}</div>")
            
            # Create description
            desc_label = QLabel(description)
            desc_label.setWordWrap(True)
            desc_label.setStyleSheet("font-size: 10pt; padding: 10px;")
            
            # Add to layout with some spacing
            scroll_layout.addWidget(eq_browser)
            scroll_layout.addWidget(desc_label)
            
            # Add a separator line unless it's the last equation
            if i < len(equations) - 1:
                separator = QLabel()
                separator.setStyleSheet("background-color: #cccccc;")
                separator.setFixedHeight(1)
                scroll_layout.addWidget(separator)
        
        # Add some space at the end
        scroll_layout.addStretch()
        
        # Set the scroll content and add to tab
        scroll.setWidget(scroll_content)
        tab_layout.addWidget(scroll)
        
        # Add the tab to the tab widget
        self.tab_widget.addTab(tab, title)
    
    def _load_hydraulic_equations(self):
        """Load hydraulic model equations."""
        # Continuity equation
        continuity_eq = r"$$\frac{\partial h}{\partial t} + \frac{\partial (uh)}{\partial x} + \frac{\partial (vh)}{\partial y} = 0$$"
        continuity_desc = "The continuity equation represents conservation of mass in the system. " \
                        "It relates the rate of change of water height (h) to the spatial derivatives " \
                        "of discharge in x and y directions."
        
        # Momentum equations
        momentum_x_eq = r"$$\frac{\partial (uh)}{\partial t} + \frac{\partial}{\partial x}\left(uh^2 + \frac{1}{2}gh^2\right) + \frac{\partial (uvh)}{\partial y} = gh(S_{0x} - S_{fx})$$"
        momentum_x_desc = "The x-direction momentum equation relates the change in x-momentum to pressure forces, " \
                        "gravity forces, and friction forces. S₀ is the bed slope and Sf is the friction slope."
                        
        momentum_y_eq = r"$$\frac{\partial (vh)}{\partial t} + \frac{\partial (uvh)}{\partial x} + \frac{\partial}{\partial y}\left(vh^2 + \frac{1}{2}gh^2\right) = gh(S_{0y} - S_{fy})$$"
        momentum_y_desc = "The y-direction momentum equation relates the change in y-momentum to pressure forces, " \
                        "gravity forces, and friction forces."
        
        # Manning's equation
        manning_eq = r"$$S_f = \frac{n^2 u^2}{R_h^{4/3}}$$"
        manning_desc = "Manning's equation is used to compute the friction slope (Sf) based on Manning's roughness " \
                     "coefficient (n), flow velocity (u), and hydraulic radius (Rh)."
        
        self._create_equation_tab("2D Shallow Water", 
                                [continuity_eq, momentum_x_eq, momentum_y_eq], 
                                [continuity_desc, momentum_x_desc, momentum_y_desc])
        
        self._create_equation_tab("Friction", 
                                [manning_eq], 
                                [manning_desc])
                                
        # 1D simplified equations
        simple_eq = r"$$A = h \cdot w$$"
        simple_desc = "In the 1D simplified model, the cross-sectional area (A) is calculated as the product " \
                    "of water depth (h) and channel width (w)."
        
        flow_eq = r"$$Q = A \cdot v = A \cdot \frac{1}{n} \cdot R_h^{2/3} \cdot \sqrt{S}$$"
        flow_desc = "The flow rate (Q) is calculated using Manning's equation, where v is velocity, " \
                  "n is Manning's roughness coefficient, Rh is hydraulic radius, and S is channel slope."
        
        self._create_equation_tab("1D Simplified", 
                                [simple_eq, flow_eq], 
                                [simple_desc, flow_desc])
    
    def _load_stream_equations(self):
        """Load stream processing equations."""
        # Stream burning equation
        burn_eq = r"$$Z_{new} = Z_{original} - D_{burn} \cdot e^{-\frac{d^2}{2\sigma^2}}$$"
        burn_desc = "Stream burning modifies the original elevation (Z₀) by subtracting a burn depth (D_burn) " \
                  "that decays exponentially with distance (d) from the stream centerline. " \
                  "The parameter σ controls the width of the burn influence."
        
        # Undulation generation
        undulation_eq = r"$$Z_{bed} = Z_{burn} + A \cdot \sin\left(\frac{2\pi \cdot s}{L}\right)$$"
        undulation_desc = "Bottom undulations are generated using a sinusoidal function, where A is the amplitude, " \
                        "s is the distance along the stream, and L is the pool-riffle wavelength."
        
        self._create_equation_tab("Stream Burning", 
                                [burn_eq, undulation_eq], 
                                [burn_desc, undulation_desc])
    
    def _load_erosion_equations(self):
        """Load erosion and sediment transport equations."""
        # Meyer-Peter Müller equation
        mpm_eq = r"$$\Phi_b = 8 \cdot (\theta - \theta_c)^{3/2}$$"
        mpm_desc = "The Meyer-Peter Müller formula calculates the dimensionless bedload transport rate (Φ_b) " \
                 "based on the difference between the Shields parameter (θ) and the critical Shields parameter (θ_c)."
        
        shields_eq = r"$$\theta = \frac{\tau_0}{\rho_s - \rho) \cdot g \cdot d_{50}}$$"
        shields_desc = "The Shields parameter (θ) represents the ratio of drag force to gravitational force " \
                     "on a sediment particle. τ₀ is the bed shear stress, ρ_s and ρ are the densities of sediment " \
                     "and water, respectively, and d₅₀ is the median grain diameter."
        
        # van Rijn equation
        vanrijn_eq = r"$$q_b = 0.053 \cdot \left(\frac{\rho_s - \rho}{\rho}\right)^{0.5} \cdot g^{0.5} \cdot d_{50}^{1.5} \cdot D_*^{-0.3} \cdot T^{2.1}$$"
        vanrijn_desc = "The van Rijn formula calculates the dimensional bedload transport rate (q_b) " \
                     "using the dimensionless particle diameter (D_*) and the transport stage parameter (T)."
        
        # USLE equation
        usle_eq = r"$$A = R \cdot K \cdot LS \cdot C \cdot P$$"
        usle_desc = "The Universal Soil Loss Equation (USLE) estimates the annual soil loss (A) " \
                  "based on rainfall erosivity (R), soil erodibility (K), slope length and steepness (LS), " \
                  "cover management (C), and support practice (P) factors."
        
        self._create_equation_tab("Sediment Transport", 
                                [mpm_eq, shields_eq, vanrijn_eq], 
                                [mpm_desc, shields_desc, vanrijn_desc])
        
        self._create_equation_tab("Soil Erosion", 
                                [usle_eq], 
                                [usle_desc])
    
    def _load_groundwater_equations(self):
        """Load groundwater model equations."""
        # Darcy's Law
        darcy_eq = r"$$q = -K \cdot \nabla h$$"
        darcy_desc = "Darcy's Law relates the specific discharge (q) to the hydraulic conductivity (K) " \
                   "and the gradient of hydraulic head (∇h)."
        
        # Groundwater flow equation
        gw_eq = r"$$S \cdot \frac{\partial h}{\partial t} = \nabla \cdot (K \cdot \nabla h) + R$$"
        gw_desc = "The groundwater flow equation describes how hydraulic head (h) changes over time " \
                "in response to spatial variations in hydraulic conductivity (K), storage coefficient (S), " \
                "and recharge (R)."
        
        # Exchange flux
        exchange_eq = r"$$q_{ex} = K_z \cdot \frac{h_s - h_g}{b}$$"
        exchange_desc = "The exchange flux (q_ex) between surface water and groundwater depends on " \
                      "the vertical hydraulic conductivity (K_z), the difference between surface water head (h_s) " \
                      "and groundwater head (h_g), and the thickness of the exchange layer (b)."
        
        self._create_equation_tab("Flow Equations", 
                                [darcy_eq, gw_eq], 
                                [darcy_desc, gw_desc])
        
        self._create_equation_tab("SW-GW Exchange", 
                                [exchange_eq], 
                                [exchange_desc])
    
    def _load_urban_equations(self):
        """Load urban flood modeling equations."""
        # Building representation
        building_eq = r"$$n_{eff} = n_{base} + C_b \cdot \lambda_b$$"
        building_desc = "Buildings can be represented by increasing the effective roughness (n_eff) " \
                      "based on the base roughness (n_base), a coefficient (C_b), and the building density (λ_b)."
        
        # Drainage capacity
        drainage_eq = r"$$Q_d = C \cdot i \cdot A$$"
        drainage_desc = "The drainage capacity (Q_d) is calculated using the rational method, " \
                      "where C is the runoff coefficient, i is the rainfall intensity, and A is the catchment area."
        
        # Inlet capacity
        inlet_eq = r"$$Q_i = C_w \cdot P \cdot d^{3/2}$$"
        inlet_desc = "The inlet capacity (Q_i) depends on the weir coefficient (C_w), " \
                   "the perimeter of the inlet (P), and the water depth above the inlet (d)."
        
        self._create_equation_tab("Urban Features", 
                                [building_eq, drainage_eq], 
                                [building_desc, drainage_desc])
        
        self._create_equation_tab("Drainage", 
                                [inlet_eq], 
                                [inlet_desc])


def show_equations(equation_type, parent=None):
    """Show the equation display dialog for the specified equation type.
    
    Parameters:
        equation_type (str): Type of equation to display
        parent (QWidget): Parent widget
    """
    dialog = EquationDisplay(equation_type, parent)
    dialog.exec_()
