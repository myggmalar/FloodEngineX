#!/usr/bin/env python3
"""
Test Enhanced 2D Hydraulic Modeling with Flow Accumulation and Upstream Pressure
--------------------------------------------------------------------------------
This test verifies that the improved velocity calculation considers upstream flow
accumulation and hydraulic pressure effects, resulting in more realistic velocity
distributions where main channels have higher velocities.
"""

import numpy as np
import logging
from enhanced_flow_points import EnhancedFlowPoints

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_2d_hydraulic_modeling():
    """Test the enhanced 2D hydraulic modeling with upstream flow effects"""
    
    logger.info("Testing Enhanced 2D Hydraulic Modeling")
    
    # Create a synthetic river system with proper upstream-downstream flow
    # This simulates a river valley with a main channel and floodplains
    rows, cols = 50, 100
    
    # Create a sloping terrain from left to right (upstream to downstream)
    base_elevation = 100.0
    slope = 0.002  # 0.2% slope
    
    dem_array = np.zeros((rows, cols))
    for j in range(cols):
        for i in range(rows):
            # Create a valley cross-section
            # Center of valley (main channel) at row 25
            distance_from_center = abs(i - 25)
            
            # Main channel is deepest, sides are higher
            valley_depth = max(0, 10 - distance_from_center * 0.5)
            
            # Overall downstream slope
            base_elev = base_elevation - j * slope
            
            dem_array[i, j] = base_elev - valley_depth
    
    # Create water depth array
    # Water level is 5m above the main channel bottom
    water_level = base_elevation - 5.0
    water_depth = np.maximum(water_level - dem_array, 0.0)
    
    # Ensure we have a connected water body
    water_depth[water_depth < 0.1] = 0.0
    
    # Create geotransform (10m pixel size)
    geotransform = (0.0, 10.0, 0.0, 0.0, 0.0, -10.0)
    
    # Initialize the enhanced flow points generator
    flow_generator = EnhancedFlowPoints(dem_array, geotransform, water_depth=water_depth)
    
    # Calculate velocity field using 2D hydraulic modeling
    logger.info("Calculating velocity field with 2D hydraulic modeling...")
    velocity_x, velocity_y, velocity_mag = flow_generator.calculate_velocity_field(
        manning_n=0.035, method="hydraulic"
    )
    
    # Analyze results
    logger.info("Analyzing velocity field results...")
    
    # Check main channel velocities (center rows)
    main_channel_mask = (np.abs(np.arange(rows)[:, None] - 25) < 3) & (water_depth > 0)
    main_channel_velocities = velocity_mag[main_channel_mask]
    
    # Check floodplain velocities (outer rows)
    floodplain_mask = (np.abs(np.arange(rows)[:, None] - 25) > 10) & (water_depth > 0)
    floodplain_velocities = velocity_mag[floodplain_mask]
    
    # Check secondary channel velocities (intermediate rows)
    secondary_mask = ((np.abs(np.arange(rows)[:, None] - 25) >= 3) & 
                     (np.abs(np.arange(rows)[:, None] - 25) <= 10) & 
                     (water_depth > 0))
    secondary_velocities = velocity_mag[secondary_mask]
    
    # Print statistics
    logger.info("=== VELOCITY STATISTICS ===")
    logger.info(f"Main Channel (deep): {len(main_channel_velocities)} cells")
    logger.info(f"  Mean velocity: {np.mean(main_channel_velocities):.3f} m/s")
    logger.info(f"  Max velocity: {np.max(main_channel_velocities):.3f} m/s")
    logger.info(f"  Min velocity: {np.min(main_channel_velocities):.3f} m/s")
    
    logger.info(f"Secondary Channel: {len(secondary_velocities)} cells")
    logger.info(f"  Mean velocity: {np.mean(secondary_velocities):.3f} m/s")
    logger.info(f"  Max velocity: {np.max(secondary_velocities):.3f} m/s")
    logger.info(f"  Min velocity: {np.min(secondary_velocities):.3f} m/s")
    
    logger.info(f"Floodplain (shallow): {len(floodplain_velocities)} cells")
    logger.info(f"  Mean velocity: {np.mean(floodplain_velocities):.3f} m/s")
    logger.info(f"  Max velocity: {np.max(floodplain_velocities):.3f} m/s")
    logger.info(f"  Min velocity: {np.min(floodplain_velocities):.3f} m/s")
    
    # Test hydraulic expectations
    logger.info("\n=== HYDRAULIC VALIDATION ===")
    
    # Test 1: Main channel should have higher average velocity than floodplain
    main_avg = np.mean(main_channel_velocities)
    floodplain_avg = np.mean(floodplain_velocities)
    
    if main_avg > floodplain_avg:
        logger.info("✅ PASS: Main channel has higher average velocity than floodplain")
        logger.info(f"   Main channel: {main_avg:.3f} m/s > Floodplain: {floodplain_avg:.3f} m/s")
    else:
        logger.error("❌ FAIL: Main channel should have higher velocity than floodplain")
        logger.error(f"   Main channel: {main_avg:.3f} m/s <= Floodplain: {floodplain_avg:.3f} m/s")
    
    # Test 2: Velocities should be realistic (not too high or too low)
    max_velocity = np.max(velocity_mag[water_depth > 0])
    min_velocity = np.min(velocity_mag[water_depth > 0])
    
    if 0.01 <= min_velocity <= 0.5 and 0.5 <= max_velocity <= 10.0:
        logger.info("✅ PASS: Velocities are in realistic range")
        logger.info(f"   Range: {min_velocity:.3f} - {max_velocity:.3f} m/s")
    else:
        logger.error("❌ FAIL: Velocities are unrealistic")
        logger.error(f"   Range: {min_velocity:.3f} - {max_velocity:.3f} m/s")
    
    # Test 3: Flow should be predominantly downstream (negative y direction)
    downstream_flow = np.sum(velocity_y[water_depth > 0] < 0)
    total_flow = np.sum(water_depth > 0)
    downstream_percentage = (downstream_flow / total_flow) * 100
    
    if downstream_percentage > 70:
        logger.info("✅ PASS: Flow is predominantly downstream")
        logger.info(f"   {downstream_percentage:.1f}% of cells flow downstream")
    else:
        logger.error("❌ FAIL: Flow should be predominantly downstream")
        logger.error(f"   Only {downstream_percentage:.1f}% of cells flow downstream")
    
    # Test 4: Flow accumulation should increase downstream
    flow_acc = flow_generator._calculate_flow_accumulation(water_depth > 0.1)
    
    # Check flow accumulation from upstream (left) to downstream (right)
    upstream_acc = np.mean(flow_acc[:, :25][water_depth[:, :25] > 0])
    downstream_acc = np.mean(flow_acc[:, 75:][water_depth[:, 75:] > 0])
    
    if downstream_acc > upstream_acc:
        logger.info("✅ PASS: Flow accumulation increases downstream")
        logger.info(f"   Upstream: {upstream_acc:.1f}, Downstream: {downstream_acc:.1f}")
    else:
        logger.error("❌ FAIL: Flow accumulation should increase downstream")
        logger.error(f"   Upstream: {upstream_acc:.1f}, Downstream: {downstream_acc:.1f}")
    
    # Test 5: Upstream pressure should be higher in areas with high flow accumulation
    high_acc_mask = flow_acc > np.percentile(flow_acc[water_depth > 0], 80)
    low_acc_mask = flow_acc < np.percentile(flow_acc[water_depth > 0], 20)
    
    high_acc_velocities = velocity_mag[high_acc_mask & (water_depth > 0)]
    low_acc_velocities = velocity_mag[low_acc_mask & (water_depth > 0)]
    
    if len(high_acc_velocities) > 0 and len(low_acc_velocities) > 0:
        high_acc_avg = np.mean(high_acc_velocities)
        low_acc_avg = np.mean(low_acc_velocities)
        
        if high_acc_avg > low_acc_avg:
            logger.info("✅ PASS: High flow accumulation areas have higher velocities")
            logger.info(f"   High acc: {high_acc_avg:.3f} m/s > Low acc: {low_acc_avg:.3f} m/s")
        else:
            logger.error("❌ FAIL: High flow accumulation areas should have higher velocities")
            logger.error(f"   High acc: {high_acc_avg:.3f} m/s <= Low acc: {low_acc_avg:.3f} m/s")
    
    logger.info("\n=== 2D HYDRAULIC MODELING TEST COMPLETE ===")
    
    return {
        'main_channel_velocity': main_avg,
        'floodplain_velocity': floodplain_avg,
        'velocity_range': (min_velocity, max_velocity),
        'downstream_percentage': downstream_percentage,
        'flow_accumulation_trend': downstream_acc > upstream_acc
    }

if __name__ == "__main__":
    test_2d_hydraulic_modeling()
