#!/usr/bin/env python3
"""
Test Script for FloodEngine Time Series Animation
================================================
This script tests the animation controls implementation by creating a sample
flood simulation and launching the animation interface.
"""

import os
import sys
import logging
import tempfile
import numpy as np
from pathlib import Path

# Add FloodEngineX to path
script_dir = Path(__file__).parent
sys.path.insert(0, str(script_dir))

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("FloodEngine.TestAnimation")

def create_test_flood_data():
    """Create test flood simulation data for animation testing."""
    logger.info("🧪 Creating test flood simulation data...")
    
    # Grid setup
    nx, ny = 100, 80
    x = np.linspace(0, 1000, nx)  # 1km x 800m domain
    y = np.linspace(0, 800, ny)
    X, Y = np.meshgrid(x, y)
    
    # Create a realistic DEM (river valley with tributaries)
    # Main valley running east-west
    main_valley_depth = 20 * np.exp(-((Y - 400)**2) / (2 * 150**2))
    
    # Tributary valleys
    trib1_depth = 10 * np.exp(-((X - 300)**2 + (Y - 200)**2) / (2 * 80**2))
    trib2_depth = 10 * np.exp(-((X - 700)**2 + (Y - 600)**2) / (2 * 80**2))
    
    # Base elevation with some terrain variation
    base_elevation = 100 + 0.01 * X + 0.005 * Y  # Gentle slope
    dem = base_elevation - main_valley_depth - trib1_depth - trib2_depth
    
    # Add some random terrain variation
    np.random.seed(42)
    terrain_noise = 2 * np.random.randn(ny, nx)
    dem += terrain_noise
    
    # Time series parameters
    total_time = 300  # 5 minutes
    dt = 15  # 15 second intervals
    times = np.arange(0, total_time + dt, dt)
    num_timesteps = len(times)
    
    logger.info(f"Creating {num_timesteps} timesteps over {total_time} seconds")
    
    # Simulate a dam break flood
    water_depths = []
    velocity_x = []
    velocity_y = []
    
    for i, t in enumerate(times):
        # Dam break propagation
        # Initial dam location at x=100m
        dam_x = 100
        
        # Flood front propagation (simplified shallow water wave)
        wave_speed = 10  # m/s
        flood_front_x = dam_x + wave_speed * t
        
        # Water depth calculation
        depth = np.zeros_like(dem)
        
        # Flooded region (simplified)
        flooded_mask = (X <= flood_front_x) & (dem < 95)  # Below elevation 95m
        
        if np.any(flooded_mask):
            # Water depth in flooded areas
            water_level = 98 - 0.1 * t  # Decreasing water level over time
            depth[flooded_mask] = np.maximum(0, water_level - dem[flooded_mask])
            
            # Ensure no negative depths
            depth = np.maximum(0, depth)
            
            # Limit maximum depth for realism
            depth = np.minimum(depth, 15)  # Max 15m depth
        
        water_depths.append(depth)
        
        # Velocity calculation (simplified)
        vx = np.zeros_like(dem)
        vy = np.zeros_like(dem)
        
        # Velocity in flooded areas
        wet_mask = depth > 0.1
        if np.any(wet_mask):
            # Flow velocity based on depth and slope
            # Simplified momentum equation: v ~ sqrt(g * h * slope)
            vx[wet_mask] = np.minimum(5.0, 2.0 * np.sqrt(depth[wet_mask]))  # Eastward flow
            
            # Add some cross-valley flow component
            vy[wet_mask] = 0.5 * np.sin(2 * np.pi * X[wet_mask] / 1000) * vx[wet_mask]
        
        velocity_x.append(vx)
        velocity_y.append(vy)
    
    # Create geotransform (1m pixel size, origin at 0,0)
    geotransform = (0, 10, 0, 800, 0, -10)  # 10m pixel size
    
    # Simple WGS84 projection
    projection = '''GEOGCS["WGS 84",DATUM["WGS_1984",SPHEROID["WGS 84",6378137,298.257223563]],PRIMEM["Greenwich",0],UNIT["degree",0.0174532925199433]]'''
    
    results_data = {
        'times': times.tolist(),
        'water_depths': water_depths,
        'velocity_x': velocity_x,
        'velocity_y': velocity_y,
        'dem_array': dem,
        'geotransform': geotransform,
        'projection': projection,
        'final_water_depth': water_depths[-1],
        'final_velocity_x': velocity_x[-1],
        'final_velocity_y': velocity_y[-1],
        'final_velocity_magnitude': np.sqrt(velocity_x[-1]**2 + velocity_y[-1]**2),
        'water_surface_elevation': dem + water_depths[-1]
    }
    
    logger.info("✅ Test flood simulation data created")
    logger.info(f"Domain: {nx}x{ny} cells, {total_time}s simulation")
    logger.info(f"Max depth: {np.max([np.max(d) for d in water_depths]):.2f}m")
    logger.info(f"Max velocity: {np.max([np.max(v) for v in velocity_x]):.2f}m/s")
    
    return results_data

def test_animation_setup():
    """Test the animation setup and integration."""
    logger.info("🎬 Testing animation setup...")
    
    try:
        # Create test data
        results_data = create_test_flood_data()
        
        # Create temporary output folder
        temp_dir = tempfile.mkdtemp(prefix='floodengine_test_')
        logger.info(f"📁 Using temporary directory: {temp_dir}")
        
        # Test time series integration
        from time_series_integration import integrate_time_series_animation
        
        animation_result = integrate_time_series_animation(results_data, temp_dir)
        
        if animation_result['success']:
            logger.info("✅ Animation integration successful!")
            logger.info(f"Created {animation_result['num_timesteps']} timestep files")
            logger.info(f"Instructions: {animation_result['instructions_file']}")
            
            return temp_dir, results_data
        else:
            logger.error(f"❌ Animation integration failed: {animation_result.get('error')}")
            return None, None
            
    except Exception as e:
        logger.error(f"❌ Test animation setup failed: {e}")
        return None, None

def test_standalone_animator(temp_dir, results_data):
    """Test the standalone animation dialog."""
    logger.info("🖥️ Testing standalone animation dialog...")
    
    try:
        from PyQt5.QtWidgets import QApplication
        from time_series_animator import TimeSeriesAnimator
        
        # Create QApplication if needed
        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)
        
        # Create animator
        animator = TimeSeriesAnimator(results_data, temp_dir)
        animator.setWindowTitle("FloodEngine Test Animation")
        animator.show()
        
        logger.info("✅ Standalone animation dialog created successfully!")
        logger.info("🎮 Animation controls should be visible")
        logger.info("📊 Click anywhere to test point sampling")
        
        # Store reference to prevent garbage collection
        app._test_animator = animator
        
        return animator
        
    except ImportError as e:
        logger.error(f"❌ Cannot test standalone animation - missing PyQt5: {e}")
        return None
    except Exception as e:
        logger.error(f"❌ Standalone animation test failed: {e}")
        return None

def test_qgis_integration(temp_dir, results_data):
    """Test QGIS integration if available."""
    logger.info("🗺️ Testing QGIS integration...")
    
    try:
        from qgis.utils import iface
        
        if iface is None:
            logger.info("ℹ️ Not in QGIS environment - skipping QGIS test")
            return None
        
        from map_canvas_time_series import launch_time_series_animation
        
        result = launch_time_series_animation(results_data, temp_dir)
        
        if result:
            logger.info("✅ QGIS integration test successful!")
            return result
        else:
            logger.warning("⚠️ QGIS integration test returned no result")
            return None
            
    except ImportError:
        logger.info("ℹ️ QGIS not available - skipping QGIS test")
        return None
    except Exception as e:
        logger.error(f"❌ QGIS integration test failed: {e}")
        return None

def main():
    """Main test function."""
    logger.info("🚀 Starting FloodEngine Animation Test Suite")
    
    # Test 1: Animation setup
    temp_dir, results_data = test_animation_setup()
    if not temp_dir:
        logger.error("❌ Animation setup test failed - cannot continue")
        return 1
    
    logger.info(f"📁 Test files created in: {temp_dir}")
    
    # Test 2: Standalone animation
    animator = test_standalone_animator(temp_dir, results_data)
    if animator:
        logger.info("✅ Standalone animation test passed")
    else:
        logger.warning("⚠️ Standalone animation test failed")
    
    # Test 3: QGIS integration (if available)
    qgis_result = test_qgis_integration(temp_dir, results_data)
    if qgis_result:
        logger.info("✅ QGIS integration test passed")
    else:
        logger.info("ℹ️ QGIS integration test skipped or failed")
    
    # Summary
    logger.info("📊 Test Summary:")
    logger.info(f"  • Animation Setup: {'✅ PASS' if temp_dir else '❌ FAIL'}")
    logger.info(f"  • Standalone Dialog: {'✅ PASS' if animator else '❌ FAIL'}")
    logger.info(f"  • QGIS Integration: {'✅ PASS' if qgis_result else 'ℹ️ SKIP'}")
    
    # Provide usage instructions
    if temp_dir:
        logger.info("🔧 Manual Testing:")
        logger.info(f"  • Launch animation: python launch_animation.py \"{temp_dir}\"")
        logger.info(f"  • Check instructions: {os.path.join(temp_dir, 'ANIMATION_INSTRUCTIONS.md')}")
    
    # Keep application running if GUI is shown
    if animator and '--no-gui' not in sys.argv:
        logger.info("🖼️ Keeping GUI open for manual testing...")
        logger.info("   Close the animation window to exit")
        app = QApplication.instance()
        if app:
            return app.exec_()
    
    return 0

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Test FloodEngine Animation Controls")
    parser.add_argument('--no-gui', action='store_true', help='Skip GUI testing')
    
    args = parser.parse_args()
    
    if args.no_gui:
        sys.argv.append('--no-gui')
    
    sys.exit(main())
