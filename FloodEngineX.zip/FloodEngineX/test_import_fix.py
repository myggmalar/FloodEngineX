#!/usr/bin/env python3
"""
Test script to verify the import fix for load_bathymetry function.
This simulates the import that was causing the original error.
"""

import sys
import os

# Add the plugin directory to the path
plugin_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, plugin_dir)

def test_import_fix():
    """Test if the import issue has been resolved."""
    try:
        # This is the import that was failing before
        print("Testing import: from model_hydraulic import load_bathymetry")
        
        # Mock the GDAL imports to avoid dependency issues during testing
        import unittest.mock as mock
        
        with mock.patch.dict('sys.modules', {
            'osgeo': mock.MagicMock(),
            'osgeo.gdal': mock.MagicMock(),
            'osgeo.ogr': mock.MagicMock(),
            'osgeo.osr': mock.MagicMock(),
            'qgis': mock.MagicMock(),
            'qgis.core': mock.MagicMock(),
            'qgis.PyQt': mock.MagicMock(),
            'qgis.PyQt.QtCore': mock.MagicMock(),
        }):
            from model_hydraulic import load_bathymetry
            print("✓ SUCCESS: load_bathymetry imported successfully!")
            
            # Test if the function exists and is callable
            if callable(load_bathymetry):
                print("✓ SUCCESS: load_bathymetry is a callable function")
            else:
                print("✗ ERROR: load_bathymetry is not callable")
                return False
                
            return True
            
    except ImportError as e:
        print(f"✗ IMPORT ERROR: {e}")
        return False
    except Exception as e:
        print(f"✗ UNEXPECTED ERROR: {e}")
        return False

def test_ui_import():
    """Test if the UI module can import the function correctly."""
    try:
        print("\nTesting UI import pattern...")
        
        import unittest.mock as mock
        
        with mock.patch.dict('sys.modules', {
            'osgeo': mock.MagicMock(),
            'osgeo.gdal': mock.MagicMock(),
            'osgeo.ogr': mock.MagicMock(),
            'osgeo.osr': mock.MagicMock(),
            'qgis': mock.MagicMock(),
            'qgis.core': mock.MagicMock(),
            'qgis.PyQt': mock.MagicMock(),
            'qgis.PyQt.QtCore': mock.MagicMock(),
            'qgis.PyQt.QtGui': mock.MagicMock(),
            'qgis.PyQt.QtWidgets': mock.MagicMock(),
            'qgis.gui': mock.MagicMock(),
            'qgis.utils': mock.MagicMock(),
            'processing': mock.MagicMock(),
            'pandas': mock.MagicMock(),
        }):
            # This simulates the import pattern in floodengine_ui.py
            from model_hydraulic import load_bathymetry
            print("✓ SUCCESS: UI can import load_bathymetry from model_hydraulic")
            return True
            
    except Exception as e:
        print(f"✗ UI IMPORT ERROR: {e}")
        return False

if __name__ == "__main__":
    print("=" * 60)
    print("FLOODENGINE IMPORT FIX VERIFICATION TEST")
    print("=" * 60)
    
    # Test the main import fix
    success1 = test_import_fix()
    
    # Test the UI import pattern
    success2 = test_ui_import()
    
    print("\n" + "=" * 60)
    if success1 and success2:
        print("🎉 ALL TESTS PASSED! The import fix is working correctly.")
        print("The FloodEngine plugin should now load without import errors.")
    else:
        print("❌ SOME TESTS FAILED! There may still be import issues.")
    print("=" * 60)
