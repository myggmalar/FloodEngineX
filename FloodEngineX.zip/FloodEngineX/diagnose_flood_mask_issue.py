#!/usr/bin/env python3
"""
Diagnostic script to investigate why intermediate water levels produce empty flood layers
"""

import os
import sys
import numpy as np
from osgeo import gdal

def load_test_dem():
    """Load the actual DEM for testing"""
    dem_path = r"C:\Users\david\OneDrive\Dokument\GIS\FloodEngine\VSCode\Test_Data\DEM\DEM_20m_clipped.tif"
    
    if not os.path.exists(dem_path):
        print(f"❌ DEM file not found: {dem_path}")
        return None, None, None
    
    print("Loading DEM: {}".format(dem_path))
    ds = gdal.Open(dem_path)
    if ds is None:
        print("Could not open DEM file")
        return None, None, None
    
    dem_array = ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
    geotransform = ds.GetGeoTransform()
    
    # Handle NoData
    nodata = ds.GetRasterBand(1).GetNoDataValue()
    if nodata is not None:
        dem_array[dem_array == nodata] = np.nan
    
    # Create valid mask
    valid_mask = ~np.isnan(dem_array)
    
    print(f"✅ DEM loaded: {dem_array.shape}")
    print(f"📊 Elevation range: {np.nanmin(dem_array):.2f}m to {np.nanmax(dem_array):.2f}m")
    print(f"📊 Valid cells: {np.sum(valid_mask)} / {dem_array.size}")
    
    return dem_array, valid_mask, geotransform

def test_flood_mask_percentile_thresholds(dem_array, valid_mask, water_level):
    """Test different percentile thresholds for starting points"""
    print(f"\n🧪 TESTING PERCENTILE THRESHOLDS for water level {water_level:.2f}m")
    print("=" * 70)
    
    # Find all floodable areas
    floodable_mask = valid_mask & (dem_array < water_level)
    
    if not np.any(floodable_mask):
        print("❌ No areas can be flooded at this water level")
        return
    
    floodable_elevations = dem_array[floodable_mask]
    min_elev = np.min(floodable_elevations)
    max_elev = np.max(floodable_elevations)
    total_floodable = np.sum(floodable_mask)
    
    print(f"📊 Floodable area analysis:")
    print(f"   Elevation range: {min_elev:.2f}m to {max_elev:.2f}m")
    print(f"   Total floodable cells: {total_floodable:,}")
    print(f"   Water level: {water_level:.2f}m")
    
    # Test different percentile thresholds
    percentiles = [50, 60, 70, 80, 85, 90, 95, 99]
    
    print(f"\n🎯 Testing different starting point thresholds:")
    for pct in percentiles:
        threshold = np.percentile(floodable_elevations, pct)
        start_candidates = np.sum(floodable_mask & (dem_array >= threshold))
        
        print(f"   {pct:2d}th percentile (≥{threshold:6.2f}m): {start_candidates:5,} start points")
        
        # Test if we can achieve any flooding with this threshold
        if start_candidates > 0:
            flood_result = test_simple_downhill_flood(dem_array, valid_mask, water_level, threshold)
            print(f"      → Results in {flood_result:5,} flooded cells")
        else:
            print(f"      → No start points available!")

def test_simple_downhill_flood(dem_array, valid_mask, water_level, start_threshold):
    """Simplified downhill flooding algorithm for testing"""
    from collections import deque
    
    # Find floodable areas
    floodable_mask = valid_mask & (dem_array < water_level)
    
    # Find starting points
    start_mask = floodable_mask & (dem_array >= start_threshold)
    start_points = np.where(start_mask)
    
    if len(start_points[0]) == 0:
        return 0
    
    # Initialize flooding
    flooded = np.zeros_like(dem_array, dtype=bool)
    queue = deque()
    
    # Add starting points
    for i in range(len(start_points[0])):
        row, col = start_points[0][i], start_points[1][i]
        flooded[row, col] = True
        queue.append((row, col))
    
    # 8-directional neighbors
    directions = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]
    
    # Propagate downhill
    max_iterations = 50000
    iteration = 0
    
    while queue and iteration < max_iterations:
        current_row, current_col = queue.popleft()
        current_elevation = dem_array[current_row, current_col]
        iteration += 1
        
        for dr, dc in directions:
            new_row, new_col = current_row + dr, current_col + dc
            
            # Boundary and validity checks
            if (new_row < 0 or new_row >= dem_array.shape[0] or 
                new_col < 0 or new_col >= dem_array.shape[1]):
                continue
            
            if flooded[new_row, new_col] or not valid_mask[new_row, new_col]:
                continue
            
            neighbor_elevation = dem_array[new_row, new_col]
            
            # DOWNHILL FLOW: neighbor must be lower/equal AND below water level
            if (neighbor_elevation <= current_elevation and 
                neighbor_elevation < water_level):
                
                flooded[new_row, new_col] = True
                queue.append((new_row, new_col))
    
    return np.sum(flooded)

def test_bathtub_vs_flow_comparison(dem_array, valid_mask, water_levels):
    """Compare bathtub filling vs flow-based algorithms"""
    print(f"\n🏊 BATHTUB vs FLOW COMPARISON")
    print("=" * 70)
    
    results = []
    
    for water_level in water_levels:
        print(f"\n💧 Testing water level: {water_level:.2f}m")
        
        # Bathtub method (simple elevation check)
        bathtub_flooded = np.sum(valid_mask & (dem_array < water_level))
        
        # Flow method with 80th percentile (current algorithm)
        flow_80_flooded = test_flood_with_percentile(dem_array, valid_mask, water_level, 80)
        
        # Flow method with 70th percentile (less restrictive)
        flow_70_flooded = test_flood_with_percentile(dem_array, valid_mask, water_level, 70)
        
        # Flow method with 60th percentile (even less restrictive)
        flow_60_flooded = test_flood_with_percentile(dem_array, valid_mask, water_level, 60)
        
        results.append({
            'water_level': water_level,
            'bathtub': bathtub_flooded,
            'flow_80': flow_80_flooded,
            'flow_70': flow_70_flooded,
            'flow_60': flow_60_flooded
        })
        
        print(f"   Bathtub filling:     {bathtub_flooded:6,} cells")
        print(f"   Flow (80th pctl):    {flow_80_flooded:6,} cells ({flow_80_flooded/bathtub_flooded*100:.1f}%)")
        print(f"   Flow (70th pctl):    {flow_70_flooded:6,} cells ({flow_70_flooded/bathtub_flooded*100:.1f}%)")
        print(f"   Flow (60th pctl):    {flow_60_flooded:6,} cells ({flow_60_flooded/bathtub_flooded*100:.1f}%)")
        
        if flow_80_flooded == 0:
            print(f"   ❌ PROBLEM: 80th percentile produces NO flooding!")
            
            # Diagnostic: check if ANY start points exist
            floodable_mask = valid_mask & (dem_array < water_level)
            if np.any(floodable_mask):
                floodable_elevations = dem_array[floodable_mask]
                threshold_80 = np.percentile(floodable_elevations, 80)
                start_candidates = np.sum(floodable_mask & (dem_array >= threshold_80))
                print(f"      Start points available at 80th percentile: {start_candidates}")
                
                if start_candidates == 0:
                    print(f"      💡 SOLUTION: Need lower percentile threshold!")
    
    return results

def test_flood_with_percentile(dem_array, valid_mask, water_level, percentile):
    """Test flooding with specific percentile threshold"""
    floodable_mask = valid_mask & (dem_array < water_level)
    
    if not np.any(floodable_mask):
        return 0
    
    floodable_elevations = dem_array[floodable_mask]
    threshold = np.percentile(floodable_elevations, percentile)
    
    return test_simple_downhill_flood(dem_array, valid_mask, water_level, threshold)

def diagnose_water_level_ranges(dem_array, valid_mask):
    """Analyze what water level ranges make sense for this DEM"""
    print(f"\n📊 WATER LEVEL RANGE ANALYSIS")
    print("=" * 70)
    
    valid_elevations = dem_array[valid_mask]
    
    stats = {
        'min': np.min(valid_elevations),
        'max': np.max(valid_elevations),
        'mean': np.mean(valid_elevations),
        'median': np.median(valid_elevations),
        'q25': np.percentile(valid_elevations, 25),
        'q75': np.percentile(valid_elevations, 75)
    }
    
    print(f"DEM elevation statistics:")
    print(f"   Minimum:      {stats['min']:7.2f}m")
    print(f"   25th percentile: {stats['q25']:7.2f}m")
    print(f"   Median:       {stats['median']:7.2f}m")
    print(f"   Mean:         {stats['mean']:7.2f}m")
    print(f"   75th percentile: {stats['q75']:7.2f}m")
    print(f"   Maximum:      {stats['max']:7.2f}m")
    
    # Suggest realistic water level ranges
    print(f"\n💡 Suggested water level ranges for testing:")
    
    # Low-level flooding (bottom 25%)
    low_level = stats['q25'] + 2.0
    print(f"   Low flooding:     {low_level:.1f}m (covers bottom 25% + 2m)")
    
    # Medium-level flooding (bottom 50%)
    med_level = stats['median'] + 2.0
    print(f"   Medium flooding:  {med_level:.1f}m (covers bottom 50% + 2m)")
    
    # High-level flooding (bottom 75%)
    high_level = stats['q75'] + 2.0
    print(f"   High flooding:    {high_level:.1f}m (covers bottom 75% + 2m)")
    
    return [low_level, med_level, high_level]

def main():
    print("FLOOD MASK DIAGNOSTIC TOOL")
    print("=" * 70)
    print("This script will help diagnose why intermediate water levels")
    print("are producing empty flood layers in timestep simulations.")
    print("=" * 70)
    
    # Load DEM
    dem_array, valid_mask, geotransform = load_test_dem()
    if dem_array is None:
        print("❌ Cannot proceed without DEM data")
        return
    
    # Analyze DEM and suggest water levels
    suggested_levels = diagnose_water_level_ranges(dem_array, valid_mask)
    
    # Test with a range of water levels including the problematic ones
    test_levels = [
        32.0,  # Very low
        40.0,  # Low
        50.0,  # Medium-low
        60.0,  # Medium (current initial level)
        65.0,  # Medium-high  
        70.0,  # High
        80.0   # Very high
    ]
    
    print(f"\n🧪 Testing multiple water levels:")
    for level in test_levels:
        print(f"   {level:.1f}m")
    
    # Compare algorithms
    results = test_bathtub_vs_flow_comparison(dem_array, valid_mask, test_levels)
    
    # Test percentile thresholds for problematic levels
    problematic_levels = [level for level in test_levels if 50 <= level <= 70]
    
    for level in problematic_levels:
        test_flood_mask_percentile_thresholds(dem_array, valid_mask, level)
    
    # Summary and recommendations
    print(f"\n📋 DIAGNOSTIC SUMMARY")
    print("=" * 70)
    
    empty_results = [r for r in results if r['flow_80'] == 0]
    if empty_results:
        print(f"❌ PROBLEM IDENTIFIED:")
        print(f"   Water levels producing ZERO flooding with 80th percentile:")
        for r in empty_results:
            print(f"   - {r['water_level']:.1f}m")
        
        print(f"\n💡 RECOMMENDED FIXES:")
        print(f"1. Lower the percentile threshold from 80th to 60th-70th")
        print(f"2. Add fallback mechanism when no start points are found")
        print(f"3. Consider using bathtub filling for low water levels")
        print(f"4. Implement hybrid algorithm: flow-based for high levels, bathtub for low")
    else:
        print(f"✅ No empty results found with current algorithm")
    
    print(f"\nDiagnostic complete!")

if __name__ == "__main__":
    main()
