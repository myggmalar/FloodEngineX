#!/usr/bin/env python3
"""
FloodEngine v4.0 - Advanced Visualization Features Module
========================================================

Professional 3D visualization and animation capabilities for FloodEngine providing:
- 3D flood visualization engine with real-time rendering
- Animation generation framework for time-series flood progression
- Interactive analysis interface with real-time parameter adjustment
- VR/AR visualization support for immersive flood scenarios
- Multi-perspective rendering (bird's eye, cross-section, first-person)
- Export capabilities for various formats (video, images, 3D models)

Author: FloodEngine Development Team
Date: June 7, 2025
Version: 4.0
"""

import os
import sys
import json
import time
import logging
import tempfile
import shutil
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional, Any, Union, Callable
from dataclasses import dataclass, field
from pathlib import Path
from enum import Enum
import numpy as np
from concurrent.futures import ThreadPoolExecutor, as_completed

# 3D Visualization imports with graceful fallback
try:
    import vtk
    from vtk.util import numpy_support
    VTK_AVAILABLE = True
    print("✅ VTK visualization library loaded successfully!")
except ImportError:
    VTK_AVAILABLE = False
    print("⚠️ Warning: VTK not available - 3D visualization will be limited")

# OpenGL and graphics imports
try:
    import moderngl
    import PIL.Image
    MODERNGL_AVAILABLE = True
    print("✅ ModernGL rendering library loaded successfully!")
except ImportError:
    MODERNGL_AVAILABLE = False
    print("⚠️ Warning: ModernGL not available - GPU rendering will be limited")

# Animation and video generation
try:
    import imageio
    import matplotlib.pyplot as plt
    import matplotlib.animation as animation
    from matplotlib import cm
    ANIMATION_AVAILABLE = True
    print("✅ Animation libraries loaded successfully!")
except ImportError:
    ANIMATION_AVAILABLE = False
    print("⚠️ Warning: Animation libraries not available")

# VR/AR support
try:
    import openvr
    VR_AVAILABLE = True
    print("✅ OpenVR library loaded for VR/AR support!")
except ImportError:
    VR_AVAILABLE = False
    print("⚠️ Warning: OpenVR not available - VR/AR features disabled")

# Interactive plotting
try:
    import plotly.graph_objects as go
    import plotly.express as px
    from plotly.subplots import make_subplots
    import dash
    from dash import dcc, html, Input, Output
    INTERACTIVE_AVAILABLE = True
    print("✅ Interactive visualization libraries loaded!")
except ImportError:
    INTERACTIVE_AVAILABLE = False
    print("⚠️ Warning: Interactive visualization libraries not available")

# QGIS integration
try:
    from qgis.core import (
        QgsProject, QgsRasterLayer, QgsVectorLayer, QgsCoordinateReferenceSystem,
        QgsRasterDataProvider, QgsRectangle, QgsGeometry, QgsPointXY
    )
    QGIS_AVAILABLE = True
except ImportError:
    QGIS_AVAILABLE = False
    print("⚠️ Warning: QGIS not available for GIS integration")

# FloodEngine module imports
try:
    from .saint_venant_2d import SaintVenant2DSolver
    from .advanced_analysis_tools import FloodRiskAssessment
    from .database_connectivity import FloodEngineDatabase
    FLOODENGINE_MODULES_AVAILABLE = True
except ImportError:
    FLOODENGINE_MODULES_AVAILABLE = False
    print("⚠️ Warning: FloodEngine modules not fully available")


class VisualizationMode(Enum):
    """Visualization rendering modes."""
    WIREFRAME = "wireframe"
    SURFACE = "surface"
    VOLUME = "volume"
    CONTOUR = "contour"
    STREAMLINES = "streamlines"
    PARTICLES = "particles"


class RenderQuality(Enum):
    """Rendering quality settings."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    ULTRA = "ultra"


class CameraMode(Enum):
    """Camera perspective modes."""
    BIRDS_EYE = "birds_eye"
    CROSS_SECTION = "cross_section"
    FIRST_PERSON = "first_person"
    FOLLOW_FLOW = "follow_flow"
    ORBITAL = "orbital"


@dataclass
class VisualizationConfig:
    """Configuration for visualization rendering."""
    mode: VisualizationMode = VisualizationMode.SURFACE
    quality: RenderQuality = RenderQuality.MEDIUM
    camera_mode: CameraMode = CameraMode.BIRDS_EYE
    resolution: Tuple[int, int] = (1920, 1080)
    frame_rate: int = 30
    duration: float = 10.0  # seconds
    color_scheme: str = "blue_red"
    transparency: float = 0.7
    lighting_enabled: bool = True
    shadows_enabled: bool = True
    water_surface_effects: bool = True
    terrain_texturing: bool = True


@dataclass
class AnimationFrame:
    """Single frame of flood animation."""
    timestamp: float
    water_levels: np.ndarray
    velocities: Optional[np.ndarray] = None
    flow_vectors: Optional[np.ndarray] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RenderOutput:
    """Output from rendering operation."""
    success: bool
    file_path: Optional[str] = None
    file_paths: Optional[List[str]] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    render_time: float = 0.0
    error_message: Optional[str] = None


class FloodVisualization3D:
    """3D flood visualization engine using VTK."""
    
    def __init__(self, config: VisualizationConfig = None):
        """Initialize 3D visualization engine."""
        self.config = config or VisualizationConfig()
        self.logger = logging.getLogger(__name__)
        
        # VTK components
        self.renderer = None
        self.render_window = None
        self.interactor = None
        self.camera = None
        
        # Data objects
        self.terrain_actor = None
        self.water_actor = None
        self.streamlines_actor = None
        
        # Initialize VTK if available
        if VTK_AVAILABLE:
            self._initialize_vtk()
        else:
            self.logger.warning("VTK not available - 3D visualization disabled")
    
    def _initialize_vtk(self):
        """Initialize VTK rendering pipeline."""
        try:
            # Create renderer
            self.renderer = vtk.vtkRenderer()
            self.renderer.SetBackground(0.8, 0.9, 1.0)  # Sky blue background
            
            # Create render window
            self.render_window = vtk.vtkRenderWindow()
            self.render_window.AddRenderer(self.renderer)
            self.render_window.SetSize(*self.config.resolution)
            self.render_window.SetWindowName("FloodEngine 3D Visualization")
            
            # Create interactor
            self.interactor = vtk.vtkRenderWindowInteractor()
            self.interactor.SetRenderWindow(self.render_window)
            
            # Setup camera
            self.camera = self.renderer.GetActiveCamera()
            self._setup_camera()
            
            # Setup lighting
            if self.config.lighting_enabled:
                self._setup_lighting()
            
            self.logger.info("VTK 3D visualization initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize VTK: {e}")
            raise
    
    def _setup_camera(self):
        """Setup camera based on configuration."""
        if not self.camera:
            return
        
        if self.config.camera_mode == CameraMode.BIRDS_EYE:
            self.camera.SetPosition(0, 0, 1000)
            self.camera.SetFocalPoint(0, 0, 0)
            self.camera.SetViewUp(0, 1, 0)
        elif self.config.camera_mode == CameraMode.CROSS_SECTION:
            self.camera.SetPosition(1000, 0, 100)
            self.camera.SetFocalPoint(0, 0, 100)
            self.camera.SetViewUp(0, 0, 1)
        elif self.config.camera_mode == CameraMode.FIRST_PERSON:
            self.camera.SetPosition(0, 0, 50)
            self.camera.SetFocalPoint(100, 0, 50)
            self.camera.SetViewUp(0, 0, 1)
    
    def _setup_lighting(self):
        """Setup lighting for realistic rendering."""
        # Main light (sun)
        main_light = vtk.vtkLight()
        main_light.SetPosition(1000, 1000, 1000)
        main_light.SetFocalPoint(0, 0, 0)
        main_light.SetColor(1.0, 1.0, 0.9)
        main_light.SetIntensity(0.8)
        self.renderer.AddLight(main_light)
        
        # Fill light
        fill_light = vtk.vtkLight()
        fill_light.SetPosition(-500, 500, 800)
        fill_light.SetFocalPoint(0, 0, 0)
        fill_light.SetColor(0.8, 0.9, 1.0)
        fill_light.SetIntensity(0.3)
        self.renderer.AddLight(fill_light)
    
    def create_terrain_surface(self, dem_data: np.ndarray, extent: Tuple[float, float, float, float],
                             vertical_exaggeration: float = 2.0) -> bool:
        """Create 3D terrain surface from DEM data."""
        if not VTK_AVAILABLE:
            self.logger.warning("VTK not available for terrain rendering")
            return False
        
        try:
            rows, cols = dem_data.shape
            min_x, max_x, min_y, max_y = extent
            
            # Create structured grid
            points = vtk.vtkPoints()
            
            x_spacing = (max_x - min_x) / (cols - 1)
            y_spacing = (max_y - min_y) / (rows - 1)
            
            for j in range(rows):
                for i in range(cols):
                    x = min_x + i * x_spacing
                    y = max_y - j * y_spacing  # Flip Y coordinate
                    z = dem_data[j, i] * vertical_exaggeration
                    points.InsertNextPoint(x, y, z)
            
            # Create structured grid
            grid = vtk.vtkStructuredGrid()
            grid.SetDimensions(cols, rows, 1)
            grid.SetPoints(points)
            
            # Create mapper and actor
            mapper = vtk.vtkDataSetMapper()
            mapper.SetInputData(grid)
            
            self.terrain_actor = vtk.vtkActor()
            self.terrain_actor.SetMapper(mapper)
            
            # Setup terrain appearance
            property = self.terrain_actor.GetProperty()
            if self.config.terrain_texturing:
                property.SetColor(0.6, 0.4, 0.2)  # Brown terrain
            else:
                property.SetColor(0.8, 0.8, 0.8)  # Gray terrain
            
            if self.config.mode == VisualizationMode.WIREFRAME:
                property.SetRepresentationToWireframe()
            else:
                property.SetRepresentationToSurface()
            
            # Add to renderer
            self.renderer.AddActor(self.terrain_actor)
            
            self.logger.info(f"Created terrain surface with {rows}x{cols} points")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to create terrain surface: {e}")
            return False
    
    def create_water_surface(self, water_data: np.ndarray, extent: Tuple[float, float, float, float],
                           vertical_exaggeration: float = 2.0) -> bool:
        """Create 3D water surface with transparency and effects."""
        if not VTK_AVAILABLE:
            self.logger.warning("VTK not available for water rendering")
            return False
        
        try:
            rows, cols = water_data.shape
            min_x, max_x, min_y, max_y = extent
            
            # Filter out areas with no water
            water_mask = water_data > 0.01
            if not np.any(water_mask):
                self.logger.warning("No water data to visualize")
                return False
            
            # Create points for water surface
            points = vtk.vtkPoints()
            water_heights = vtk.vtkFloatArray()
            water_heights.SetName("WaterHeight")
            
            x_spacing = (max_x - min_x) / (cols - 1)
            y_spacing = (max_y - min_y) / (rows - 1)
            
            valid_points = 0
            for j in range(rows):
                for i in range(cols):
                    if water_mask[j, i]:
                        x = min_x + i * x_spacing
                        y = max_y - j * y_spacing
                        z = water_data[j, i] * vertical_exaggeration
                        points.InsertNextPoint(x, y, z)
                        water_heights.InsertNextValue(water_data[j, i])
                        valid_points += 1
            
            if valid_points == 0:
                return False
            
            # Create polydata
            polydata = vtk.vtkPolyData()
            polydata.SetPoints(points)
            polydata.GetPointData().SetScalars(water_heights)
            
            # Create Delaunay triangulation for surface
            delaunay = vtk.vtkDelaunay2D()
            delaunay.SetInputData(polydata)
            delaunay.Update()
            
            # Create mapper and actor
            mapper = vtk.vtkPolyDataMapper()
            mapper.SetInputConnection(delaunay.GetOutputPort())
            mapper.SetScalarRange(np.min(water_data[water_mask]), np.max(water_data[water_mask]))
            
            self.water_actor = vtk.vtkActor()
            self.water_actor.SetMapper(mapper)
            
            # Setup water appearance
            property = self.water_actor.GetProperty()
            property.SetColor(0.2, 0.6, 1.0)  # Blue water
            property.SetOpacity(self.config.transparency)
            
            if self.config.water_surface_effects:
                property.SetSpecular(0.8)
                property.SetSpecularPower(20)
                property.SetDiffuse(0.6)
            
            # Add to renderer
            self.renderer.AddActor(self.water_actor)
            
            self.logger.info(f"Created water surface with {valid_points} points")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to create water surface: {e}")
            return False
    
    def add_streamlines(self, velocity_u: np.ndarray, velocity_v: np.ndarray,
                       extent: Tuple[float, float, float, float], 
                       water_level: np.ndarray) -> bool:
        """Add streamlines showing flow direction."""
        if not VTK_AVAILABLE:
            return False
        
        try:
            rows, cols = velocity_u.shape
            min_x, max_x, min_y, max_y = extent
            
            # Create vector field
            points = vtk.vtkPoints()
            vectors = vtk.vtkFloatArray()
            vectors.SetNumberOfComponents(3)
            vectors.SetName("Velocity")
            
            x_spacing = (max_x - min_x) / (cols - 1)
            y_spacing = (max_y - min_y) / (rows - 1)
            
            for j in range(0, rows, 5):  # Sample every 5th point
                for i in range(0, cols, 5):
                    if water_level[j, i] > 0.01:  # Only where there's water
                        x = min_x + i * x_spacing
                        y = max_y - j * y_spacing
                        z = water_level[j, i]
                        points.InsertNextPoint(x, y, z)
                        vectors.InsertNextTuple3(velocity_u[j, i], velocity_v[j, i], 0)
            
            # Create polydata
            polydata = vtk.vtkPolyData()
            polydata.SetPoints(points)
            polydata.GetPointData().SetVectors(vectors)
            
            # Create streamlines
            streamline = vtk.vtkStreamTracer()
            streamline.SetInputData(polydata)
            streamline.SetIntegrationDirectionToBoth()
            streamline.SetMaximumPropagation(1000)
            streamline.SetIntegratorTypeToRungeKutta4()
            
            # Create tubes for streamlines
            tubes = vtk.vtkTubeFilter()
            tubes.SetInputConnection(streamline.GetOutputPort())
            tubes.SetRadius(2.0)
            tubes.SetNumberOfSides(6)
            
            # Create mapper and actor
            mapper = vtk.vtkPolyDataMapper()
            mapper.SetInputConnection(tubes.GetOutputPort())
            
            self.streamlines_actor = vtk.vtkActor()
            self.streamlines_actor.SetMapper(mapper)
            self.streamlines_actor.GetProperty().SetColor(1.0, 1.0, 0.0)  # Yellow streamlines
            
            self.renderer.AddActor(self.streamlines_actor)
            
            self.logger.info("Added streamlines to visualization")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to add streamlines: {e}")
            return False
    
    def render_frame(self, output_path: str = None) -> RenderOutput:
        """Render current frame to image."""
        if not VTK_AVAILABLE:
            return RenderOutput(success=False, error_message="VTK not available")
        
        try:
            start_time = time.time()
            
            # Setup render window for offscreen rendering
            self.render_window.SetOffScreenRendering(1)
            self.render_window.Render()
            
            # Capture image
            window_to_image = vtk.vtkWindowToImageFilter()
            window_to_image.SetInput(self.render_window)
            window_to_image.Update()
            
            # Save image
            if output_path:
                writer = vtk.vtkPNGWriter()
                writer.SetFileName(output_path)
                writer.SetInputConnection(window_to_image.GetOutputPort())
                writer.Write()
            
            render_time = time.time() - start_time
            
            return RenderOutput(
                success=True,
                file_path=output_path,
                render_time=render_time,
                metadata={
                    'resolution': self.config.resolution,
                    'quality': self.config.quality.value,
                    'camera_mode': self.config.camera_mode.value
                }
            )
            
        except Exception as e:
            return RenderOutput(
                success=False,
                error_message=f"Rendering failed: {str(e)}",
                render_time=time.time() - start_time
            )
    
    def cleanup(self):
        """Cleanup VTK resources."""
        if VTK_AVAILABLE and self.render_window:
            self.render_window.Finalize()


class FloodAnimationGenerator:
    """Animation generation framework for time-series flood progression."""
    
    def __init__(self, config: VisualizationConfig = None):
        """Initialize animation generator."""
        self.config = config or VisualizationConfig()
        self.logger = logging.getLogger(__name__)
        self.frames: List[AnimationFrame] = []
        self.visualization_3d = None
        
        # Initialize 3D visualization if available
        if VTK_AVAILABLE:
            self.visualization_3d = FloodVisualization3D(config)
    
    def add_frame(self, timestamp: float, water_levels: np.ndarray,
                  velocities: np.ndarray = None, flow_vectors: np.ndarray = None,
                  metadata: Dict[str, Any] = None) -> bool:
        """Add animation frame."""
        try:
            frame = AnimationFrame(
                timestamp=timestamp,
                water_levels=water_levels.copy(),
                velocities=velocities.copy() if velocities is not None else None,
                flow_vectors=flow_vectors.copy() if flow_vectors is not None else None,
                metadata=metadata or {}
            )
            
            self.frames.append(frame)
            self.logger.info(f"Added frame at t={timestamp:.2f}s")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to add frame: {e}")
            return False
    
    def generate_2d_animation(self, output_path: str, extent: Tuple[float, float, float, float],
                            dem_data: np.ndarray = None) -> RenderOutput:
        """Generate 2D animation using matplotlib."""
        if not ANIMATION_AVAILABLE:
            return RenderOutput(success=False, error_message="Animation libraries not available")
        
        try:
            start_time = time.time()
            
            if not self.frames:
                return RenderOutput(success=False, error_message="No frames to animate")
            
            # Setup figure
            fig, ax = plt.subplots(figsize=(12, 8))
            
            # Plot DEM background if available
            if dem_data is not None:
                min_x, max_x, min_y, max_y = extent
                im_dem = ax.imshow(dem_data, extent=extent, cmap='terrain', alpha=0.6)
            
            # Initialize water surface plot
            water_im = ax.imshow(self.frames[0].water_levels, extent=extent, 
                               cmap='Blues', alpha=0.8, vmin=0, 
                               vmax=np.max([np.max(f.water_levels) for f in self.frames]))
            
            # Add colorbar
            cbar = plt.colorbar(water_im, ax=ax, label='Water Level (m)')
            
            # Setup axes
            ax.set_xlabel('X (m)')
            ax.set_ylabel('Y (m)')
            ax.set_title('Flood Animation')
            
            # Animation function
            def animate(frame_idx):
                frame = self.frames[frame_idx]
                water_im.set_array(frame.water_levels)
                ax.set_title(f'Flood Animation - t={frame.timestamp:.2f}s')
                return [water_im]
            
            # Create animation
            anim = animation.FuncAnimation(
                fig, animate, frames=len(self.frames),
                interval=1000/self.config.frame_rate, blit=True, repeat=True
            )
            
            # Save animation
            if output_path.endswith('.mp4'):
                writer = animation.FFMpegWriter(fps=self.config.frame_rate)
                anim.save(output_path, writer=writer)
            elif output_path.endswith('.gif'):
                anim.save(output_path, writer='pillow', fps=self.config.frame_rate)
            else:
                return RenderOutput(success=False, error_message="Unsupported output format")
            
            plt.close(fig)
            
            render_time = time.time() - start_time
            
            return RenderOutput(
                success=True,
                file_path=output_path,
                render_time=render_time,
                metadata={
                    'frame_count': len(self.frames),
                    'duration': self.frames[-1].timestamp - self.frames[0].timestamp,
                    'frame_rate': self.config.frame_rate
                }
            )
            
        except Exception as e:
            return RenderOutput(
                success=False,
                error_message=f"2D animation generation failed: {str(e)}",
                render_time=time.time() - start_time
            )
    
    def generate_3d_animation(self, output_path: str, extent: Tuple[float, float, float, float],
                            dem_data: np.ndarray) -> RenderOutput:
        """Generate 3D animation using VTK."""
        if not VTK_AVAILABLE or not self.visualization_3d:
            return RenderOutput(success=False, error_message="3D visualization not available")
        
        try:
            start_time = time.time()
            
            if not self.frames:
                return RenderOutput(success=False, error_message="No frames to animate")
            
            # Create terrain surface
            self.visualization_3d.create_terrain_surface(dem_data, extent)
            
            # Generate frame images
            frame_paths = []
            temp_dir = Path(tempfile.mkdtemp())
            
            for i, frame in enumerate(self.frames):
                # Update water surface
                if hasattr(self.visualization_3d, 'water_actor') and self.visualization_3d.water_actor:
                    self.visualization_3d.renderer.RemoveActor(self.visualization_3d.water_actor)
                
                self.visualization_3d.create_water_surface(frame.water_levels, extent)
                
                # Add streamlines if velocity data available
                if frame.velocities is not None and len(frame.velocities.shape) == 3:
                    self.visualization_3d.add_streamlines(
                        frame.velocities[:,:,0], frame.velocities[:,:,1],
                        extent, frame.water_levels
                    )
                
                # Render frame
                frame_path = temp_dir / f"frame_{i:06d}.png"
                result = self.visualization_3d.render_frame(str(frame_path))
                
                if result.success:
                    frame_paths.append(str(frame_path))
                else:
                    self.logger.warning(f"Failed to render frame {i}")
            
            # Create video from frames
            if frame_paths and output_path.endswith('.mp4'):
                import imageio
                with imageio.get_writer(output_path, fps=self.config.frame_rate) as writer:
                    for frame_path in frame_paths:
                        image = imageio.imread(frame_path)
                        writer.append_data(image)
            
            # Cleanup
            shutil.rmtree(temp_dir)
            self.visualization_3d.cleanup()
            
            render_time = time.time() - start_time
            
            return RenderOutput(
                success=True,
                file_path=output_path,
                render_time=render_time,
                metadata={
                    'frame_count': len(frame_paths),
                    'duration': self.frames[-1].timestamp - self.frames[0].timestamp,
                    'frame_rate': self.config.frame_rate
                }
            )
            
        except Exception as e:
            return RenderOutput(
                success=False,
                error_message=f"3D animation generation failed: {str(e)}",
                render_time=time.time() - start_time
            )


class InteractiveFloodAnalysis:
    """Interactive analysis interface with real-time parameter adjustment."""
    
    def __init__(self, config: VisualizationConfig = None):
        """Initialize interactive analysis interface."""
        self.config = config or VisualizationConfig()
        self.logger = logging.getLogger(__name__)
        self.app = None
        self.server_thread = None
        
        # Data storage
        self.dem_data = None
        self.extent = None
        self.simulation_results = {}
        
        if INTERACTIVE_AVAILABLE:
            self._initialize_dash_app()
        else:
            self.logger.warning("Interactive visualization libraries not available")
    
    def _initialize_dash_app(self):
        """Initialize Dash application for interactive interface."""
        try:
            self.app = dash.Dash(__name__)
            
            # Define layout
            self.app.layout = html.Div([
                html.H1("FloodEngine Interactive Analysis", style={'textAlign': 'center'}),
                
                html.Div([
                    html.Div([
                        html.H3("Simulation Parameters"),
                        
                        html.Label("Water Level (m):"),
                        dcc.Slider(
                            id='water-level-slider',
                            min=0, max=100, step=0.5, value=50,
                            marks={i: str(i) for i in range(0, 101, 10)},
                            tooltip={"placement": "bottom", "always_visible": True}
                        ),
                        
                        html.Label("Flow Rate (m³/s):"),
                        dcc.Slider(
                            id='flow-rate-slider',
                            min=0, max=1000, step=10, value=100,
                            marks={i: str(i) for i in range(0, 1001, 200)},
                            tooltip={"placement": "bottom", "always_visible": True}
                        ),
                        
                        html.Label("Manning's n:"),
                        dcc.Slider(
                            id='manning-slider',
                            min=0.02, max=0.1, step=0.005, value=0.035,
                            marks={i/100: f"{i/100:.3f}" for i in range(2, 11, 2)},
                            tooltip={"placement": "bottom", "always_visible": True}
                        ),
                        
                        html.Button('Run Simulation', id='run-button', n_clicks=0,
                                  style={'margin': '20px 0'}),
                        
                        html.Div(id='simulation-status')
                        
                    ], style={'width': '30%', 'display': 'inline-block', 'vertical-align': 'top',
                             'padding': '20px'}),
                    
                    html.Div([
                        dcc.Graph(id='flood-visualization'),
                        dcc.Graph(id='cross-section-plot')
                    ], style={'width': '70%', 'display': 'inline-block'})
                ]),
                
                html.Div([
                    html.H3("Analysis Results"),
                    html.Div(id='analysis-results')
                ], style={'margin': '20px'})
            ])
            
            # Setup callbacks
            self._setup_callbacks()
            
            self.logger.info("Dash interactive interface initialized")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize Dash app: {e}")
            self.app = None
    
    def _setup_callbacks(self):
        """Setup Dash callbacks for interactivity."""
        if not self.app:
            return
        
        @self.app.callback(
            [Output('flood-visualization', 'figure'),
             Output('cross-section-plot', 'figure'),
             Output('analysis-results', 'children'),
             Output('simulation-status', 'children')],
            [Input('run-button', 'n_clicks')],
            [dash.dependencies.State('water-level-slider', 'value'),
             dash.dependencies.State('flow-rate-slider', 'value'),
             dash.dependencies.State('manning-slider', 'value')]
        )
        def update_visualization(n_clicks, water_level, flow_rate, manning_n):
            if n_clicks == 0 or self.dem_data is None:
                return {}, {}, "No data loaded", "Ready"
            
            try:
                # Run simulation with current parameters
                status = f"Running simulation: Water={water_level}m, Flow={flow_rate}m³/s, n={manning_n}"
                
                # Simulate flood extent (simplified)
                water_surface = np.maximum(0, water_level - self.dem_data)
                
                # Create 2D visualization
                fig_2d = go.Figure()
                
                # Add DEM
                fig_2d.add_trace(go.Heatmap(
                    z=self.dem_data,
                    colorscale='terrain',
                    opacity=0.6,
                    name='Elevation'
                ))
                
                # Add water surface
                water_masked = np.where(water_surface > 0.01, water_surface, np.nan)
                fig_2d.add_trace(go.Heatmap(
                    z=water_masked,
                    colorscale='Blues',
                    opacity=0.8,
                    name='Water'
                ))
                
                fig_2d.update_layout(
                    title=f"Flood Visualization - Water Level: {water_level}m",
                    xaxis_title="X (pixels)",
                    yaxis_title="Y (pixels)"
                )
                
                # Create cross-section plot
                center_row = self.dem_data.shape[0] // 2
                x_coords = np.arange(self.dem_data.shape[1])
                terrain_profile = self.dem_data[center_row, :]
                water_profile = water_level * np.ones_like(terrain_profile)
                
                fig_cross = go.Figure()
                fig_cross.add_trace(go.Scatter(
                    x=x_coords, y=terrain_profile,
                    fill='tonexty', name='Terrain',
                    line=dict(color='brown')
                ))
                fig_cross.add_trace(go.Scatter(
                    x=x_coords, y=water_profile,
                    fill='tonexty', name='Water Level',
                    line=dict(color='blue'), opacity=0.7
                ))
                
                fig_cross.update_layout(
                    title="Cross-Section View",
                    xaxis_title="Distance (pixels)",
                    yaxis_title="Elevation (m)"
                )
                
                # Analysis results
                flooded_area = np.sum(water_surface > 0.01) * 30 * 30  # Assuming 30m pixels
                max_depth = np.max(water_surface)
                
                results = html.Div([
                    html.P(f"Flooded Area: {flooded_area/1e6:.2f} km²"),
                    html.P(f"Maximum Depth: {max_depth:.2f} m"),
                    html.P(f"Flow Rate: {flow_rate} m³/s"),
                    html.P(f"Manning's n: {manning_n}")
                ])
                
                return fig_2d, fig_cross, results, "Simulation complete"
                
            except Exception as e:
                error_msg = f"Simulation failed: {str(e)}"
                return {}, {}, error_msg, error_msg
    
    def load_data(self, dem_path: str, extent: Tuple[float, float, float, float]):
        """Load DEM data for interactive analysis."""
        try:
            from osgeo import gdal
            
            # Open DEM
            dem_ds = gdal.Open(dem_path)
            if not dem_ds:
                raise Exception(f"Could not open DEM: {dem_path}")
            
            self.dem_data = dem_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
            self.extent = extent
            
            # Handle nodata values
            nodata = dem_ds.GetRasterBand(1).GetNoDataValue()
            if nodata is not None:
                self.dem_data[self.dem_data == nodata] = np.nan
            
            self.logger.info(f"Loaded DEM data: {self.dem_data.shape}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to load data: {e}")
            return False
    
    def start_server(self, host: str = "127.0.0.1", port: int = 8050, debug: bool = False):
        """Start interactive server."""
        if not self.app:
            self.logger.error("Dash app not initialized")
            return False
        
        try:
            def run_server():
                self.app.run_server(host=host, port=port, debug=debug)
            
            self.server_thread = threading.Thread(target=run_server, daemon=True)
            self.server_thread.start()
            
            self.logger.info(f"Interactive server started at http://{host}:{port}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to start server: {e}")
            return False


class VRFloodVisualization:
    """VR/AR visualization support for immersive flood scenarios."""
    
    def __init__(self, config: VisualizationConfig = None):
        """Initialize VR visualization."""
        self.config = config or VisualizationConfig()
        self.logger = logging.getLogger(__name__)
        self.vr_system = None
        
        if VR_AVAILABLE:
            self._initialize_vr()
        else:
            self.logger.warning("OpenVR not available - VR features disabled")
    
    def _initialize_vr(self):
        """Initialize OpenVR system."""
        try:
            openvr.init(openvr.VRApplication_Scene)
            self.vr_system = openvr.VRSystem()
            
            if self.vr_system:
                self.logger.info("VR system initialized successfully")
                return True
            else:
                self.logger.warning("VR system not available")
                return False
                
        except Exception as e:
            self.logger.error(f"Failed to initialize VR: {e}")
            return False
    
    def create_vr_scene(self, dem_data: np.ndarray, water_data: np.ndarray,
                       extent: Tuple[float, float, float, float]) -> bool:
        """Create VR scene with terrain and water."""
        if not VR_AVAILABLE or not self.vr_system:
            return False
        
        try:
            # This would create a full VR scene - simplified implementation
            self.logger.info("VR scene creation would be implemented here")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to create VR scene: {e}")
            return False
    
    def cleanup_vr(self):
        """Cleanup VR resources."""
        if VR_AVAILABLE and self.vr_system:
            openvr.shutdown()


class FloodEngineVisualizationManager:
    """Main manager for all FloodEngine visualization capabilities."""
    
    def __init__(self, output_dir: str = None):
        """Initialize visualization manager."""
        self.output_dir = Path(output_dir or tempfile.mkdtemp())
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        self.logger = logging.getLogger(__name__)
        self._setup_logging()
        
        # Initialize visualization components
        self.visualization_3d = None
        self.animation_generator = None
        self.interactive_analysis = None
        self.vr_visualization = None
        
        # Capability flags
        self.capabilities = {
            '3d_visualization': VTK_AVAILABLE,
            'animation_generation': ANIMATION_AVAILABLE,
            'interactive_analysis': INTERACTIVE_AVAILABLE,
            'vr_visualization': VR_AVAILABLE,
            'gpu_rendering': MODERNGL_AVAILABLE
        }
        
        self.logger.info("FloodEngine Visualization Manager initialized")
        self._log_capabilities()
    
    def _setup_logging(self):
        """Setup logging for visualization operations."""
        log_file = self.output_dir / f"visualization_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
        
        handler = logging.FileHandler(log_file)
        handler.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        
        self.logger.addHandler(handler)
    
    def _log_capabilities(self):
        """Log available visualization capabilities."""
        self.logger.info("Visualization Capabilities:")
        for capability, available in self.capabilities.items():
            status = "✅ Available" if available else "❌ Not Available"
            self.logger.info(f"  {capability}: {status}")
    
    def create_3d_visualization(self, config: VisualizationConfig = None) -> FloodVisualization3D:
        """Create 3D visualization instance."""
        if not self.capabilities['3d_visualization']:
            raise Exception("3D visualization not available - VTK required")
        
        self.visualization_3d = FloodVisualization3D(config)
        return self.visualization_3d
    
    def create_animation_generator(self, config: VisualizationConfig = None) -> FloodAnimationGenerator:
        """Create animation generator instance."""
        if not self.capabilities['animation_generation']:
            raise Exception("Animation generation not available - required libraries missing")
        
        self.animation_generator = FloodAnimationGenerator(config)
        return self.animation_generator
    
    def create_interactive_analysis(self, config: VisualizationConfig = None) -> InteractiveFloodAnalysis:
        """Create interactive analysis interface."""
        if not self.capabilities['interactive_analysis']:
            raise Exception("Interactive analysis not available - Plotly/Dash required")
        
        self.interactive_analysis = InteractiveFloodAnalysis(config)
        return self.interactive_analysis
    
    def create_vr_visualization(self, config: VisualizationConfig = None) -> VRFloodVisualization:
        """Create VR visualization instance."""
        if not self.capabilities['vr_visualization']:
            raise Exception("VR visualization not available - OpenVR required")
        
        self.vr_visualization = VRFloodVisualization(config)
        return self.vr_visualization
    
    def generate_complete_visualization_suite(self, dem_data: np.ndarray,
                                            simulation_results: List[Dict[str, Any]],
                                            extent: Tuple[float, float, float, float],
                                            project_name: str = "flood_analysis") -> Dict[str, RenderOutput]:
        """Generate complete visualization suite with all available formats."""
        results = {}
        
        try:
            self.logger.info(f"Generating complete visualization suite for {project_name}")
            
            # Setup output paths
            project_dir = self.output_dir / project_name
            project_dir.mkdir(exist_ok=True)
            
            # Extract time series data
            if simulation_results:
                animation_generator = self.create_animation_generator()
                
                for i, result in enumerate(simulation_results):
                    timestamp = result.get('time', i * 60)  # Default 1-minute intervals
                    water_levels = result.get('water_levels', np.zeros_like(dem_data))
                    velocities = result.get('velocities')
                    
                    animation_generator.add_frame(timestamp, water_levels, velocities)
                
                # Generate 2D animation
                if self.capabilities['animation_generation']:
                    animation_2d_path = project_dir / f"{project_name}_2d_animation.mp4"
                    results['2d_animation'] = animation_generator.generate_2d_animation(
                        str(animation_2d_path), extent, dem_data
                    )
                
                # Generate 3D animation
                if self.capabilities['3d_visualization']:
                    animation_3d_path = project_dir / f"{project_name}_3d_animation.mp4"
                    results['3d_animation'] = animation_generator.generate_3d_animation(
                        str(animation_3d_path), extent, dem_data
                    )
            
            # Generate static 3D visualization
            if self.capabilities['3d_visualization'] and simulation_results:
                viz_3d = self.create_3d_visualization()
                
                # Use final simulation result
                final_result = simulation_results[-1]
                water_levels = final_result.get('water_levels', np.zeros_like(dem_data))
                
                viz_3d.create_terrain_surface(dem_data, extent)
                viz_3d.create_water_surface(water_levels, extent)
                
                static_3d_path = project_dir / f"{project_name}_3d_visualization.png"
                results['3d_static'] = viz_3d.render_frame(str(static_3d_path))
                
                viz_3d.cleanup()
            
            # Setup interactive analysis
            if self.capabilities['interactive_analysis']:
                interactive = self.create_interactive_analysis()
                
                # Create a dummy DEM for demonstration
                if interactive.load_data("dummy_dem_path", extent):
                    # Would normally start server and provide access info
                    results['interactive'] = RenderOutput(
                        success=True,
                        metadata={'message': 'Interactive analysis interface ready'}
                    )
            
            # Generate summary report
            self._generate_visualization_report(results, project_dir / f"{project_name}_report.html")
            
            self.logger.info(f"Complete visualization suite generated: {len(results)} components")
            return results
            
        except Exception as e:
            self.logger.error(f"Failed to generate visualization suite: {e}")
            return {'error': RenderOutput(success=False, error_message=str(e))}
    
    def _generate_visualization_report(self, results: Dict[str, RenderOutput], output_path: Path):
        """Generate HTML report of visualization results."""
        try:
            html_content = """
<!DOCTYPE html>
<html>
<head>
    <title>FloodEngine Visualization Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .header { background-color: #2c3e50; color: white; padding: 20px; border-radius: 5px; }
        .section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
        .success { background-color: #d5f4e6; border-color: #27ae60; }
        .error { background-color: #fadbd8; border-color: #e74c3c; }
        .metadata { font-size: 0.9em; color: #666; }
    </style>
</head>
<body>
    <div class="header">
        <h1>FloodEngine v4.0 - Advanced Visualization Report</h1>
        <p>Generated: {timestamp}</p>
    </div>
    
    <h2>Visualization Results</h2>
""".format(timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
            
            for component, result in results.items():
                if result.success:
                    html_content += f"""
    <div class="section success">
        <h3>✅ {component.replace('_', ' ').title()}</h3>
        <p><strong>Status:</strong> Success</p>
        <p><strong>Render Time:</strong> {result.render_time:.2f} seconds</p>
        {f'<p><strong>Output:</strong> {result.file_path}</p>' if result.file_path else ''}
        <div class="metadata">
            <p><strong>Metadata:</strong> {json.dumps(result.metadata, indent=2)}</p>
        </div>
    </div>
"""
                else:
                    html_content += f"""
    <div class="section error">
        <h3>❌ {component.replace('_', ' ').title()}</h3>
        <p><strong>Status:</strong> Failed</p>
        <p><strong>Error:</strong> {result.error_message}</p>
    </div>
"""
            
            html_content += """
    <div class="section">
        <h3>System Capabilities</h3>
        <ul>
""" + "\n".join([
                f"<li>{'✅' if available else '❌'} {capability.replace('_', ' ').title()}</li>"
                for capability, available in self.capabilities.items()
            ]) + """
        </ul>
    </div>
</body>
</html>
"""
            
            with open(output_path, 'w') as f:
                f.write(html_content)
            
            self.logger.info(f"Visualization report generated: {output_path}")
            
        except Exception as e:
            self.logger.error(f"Failed to generate report: {e}")


# Utility functions for FloodEngine integration

def create_flood_visualization_from_qgis(layer_path: str, output_dir: str,
                                       visualization_type: str = "3d") -> RenderOutput:
    """Create flood visualization from QGIS layer."""
    try:
        if not QGIS_AVAILABLE:
            return RenderOutput(success=False, error_message="QGIS not available")
        
        # Load raster layer
        layer = QgsRasterLayer(layer_path, "flood_data")
        if not layer.isValid():
            return RenderOutput(success=False, error_message="Invalid layer")
        
        # Extract data
        provider = layer.dataProvider()
        extent = layer.extent()
        width = layer.width()
        height = layer.height()
        
        # Read data
        block = provider.block(1, extent, width, height)
        data_array = np.zeros((height, width), dtype=np.float32)
        
        for row in range(height):
            for col in range(width):
                data_array[row, col] = block.value(row, col)
        
        # PATCH: Set all dry/non-flooded cells to np.nan for proper transparency/clipping
        # This ensures that areas with no water (value == 0) are rendered as transparent
        # in QGIS outputs, preventing the "blue square" issue
        data_array[data_array == 0] = np.nan
        
        # Create visualization manager
        viz_manager = FloodEngineVisualizationManager(output_dir)
        
        # Generate visualization based on type
        if visualization_type == "3d" and viz_manager.capabilities['3d_visualization']:
            viz_3d = viz_manager.create_3d_visualization()
            viz_3d.create_water_surface(data_array, (extent.xMinimum(), extent.xMaximum(), 
                                                   extent.yMinimum(), extent.yMaximum()))
            
            output_path = os.path.join(output_dir, "flood_3d_visualization.png")
            return viz_3d.render_frame(output_path)
        else:
            return RenderOutput(success=False, error_message="Visualization type not supported")
        
    except Exception as e:
        return RenderOutput(success=False, error_message=f"Visualization failed: {str(e)}")


async def test_visualization_suite():
    """Test advanced visualization features."""
    print("FloodEngine v4.0 - Advanced Visualization Features Test")
    print("=" * 60)
    
    # Create test data
    rows, cols = 100, 150
    dem_data = np.random.rand(rows, cols) * 50 + 100  # Elevation 100-150m
    extent = (0, 1500, 0, 1000)  # 1.5km x 1km area
    
    # Create visualization manager
    viz_manager = FloodEngineVisualizationManager()
    
    # Test capabilities
    print("\nVisualization Capabilities:")
    for capability, available in viz_manager.capabilities.items():
        status = "✅ Available" if available else "❌ Not Available"
        print(f"  {capability}: {status}")
    
    # Create simulation results for animation
    simulation_results = []
    for t in range(0, 300, 30):  # 5-minute simulation, 30-second intervals
        water_level = 120 + 5 * np.sin(t / 60)  # Varying water level
        water_surface = np.maximum(0, water_level - dem_data)
        
        # Add some spatial variation
        center_y, center_x = rows // 2, cols // 2
        distance = np.sqrt((np.arange(rows)[:, None] - center_y)**2 + 
                          (np.arange(cols) - center_x)**2)
        water_surface *= np.exp(-distance / 50)  # Gaussian falloff
        
        simulation_results.append({
            'time': t,
            'water_levels': water_surface,
            'velocities': np.random.rand(rows, cols, 2) * 2  # Random velocities
        })
    
    # Generate complete visualization suite
    results = viz_manager.generate_complete_visualization_suite(
        dem_data, simulation_results, extent, "test_flood_scenario"
    )
    
    print(f"\nVisualization Results:")
    for component, result in results.items():
        status = "✅ Success" if result.success else "❌ Failed"
        print(f"  {component}: {status}")
        if result.success and result.file_path:
            print(f"    Output: {result.file_path}")
        if not result.success:
            print(f"    Error: {result.error_message}")
    
    print(f"\nVisualization test completed!")
    print(f"Output directory: {viz_manager.output_dir}")


if __name__ == "__main__":
    # Setup logging
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    
    # Run test
    import asyncio
    asyncio.run(test_visualization_suite())
