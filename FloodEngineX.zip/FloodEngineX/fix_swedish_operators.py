import re
import os
import sys

print("Starting comprehensive Swedish logical operators fix...")

try:
    # Path to the model_hydraulic.py file
    script_dir = os.path.dirname(os.path.abspath(__file__))
    filename = os.path.join(script_dir, "model_hydraulic.py")
    
    print(f"Opening file: {filename}")
    
    if not os.path.exists(filename):
        print(f"ERROR: File does not exist: {filename}")
        sys.exit(1)
    
    # Read the file content
    with open(filename, "r", encoding="utf-8") as f:
        content = f.read()
    
    print(f"File loaded, size: {len(content)} characters")
    
    # Count initial occurrences
    eller_count = content.count("eller")
    och_count = content.count("och")
    
    print(f"Found {eller_count} instances of 'eller'")
    print(f"Found {och_count} instances of 'och'")
    
    # First fix incorrect comparison operators like ">=="
    content_fixed = re.sub(r">==", r">=", content)
    
    # Replace Swedish logical operators with English equivalents
    content_fixed = content_fixed.replace("eller", "or")
    content_fixed = content_fixed.replace("och", "and")
    
    # Verify the replacements were made
    eller_count_after = content_fixed.count("eller")
    och_count_after = content_fixed.count("och")
    
    print(f"After replacements, found {eller_count_after} instances of 'eller' (should be 0)")
    print(f"After replacements, found {och_count_after} instances of 'och' (should be 0)")
    
    # Save the fixed file
    with open(filename, "w", encoding="utf-8") as f:
        f.write(content_fixed)
    
    print(f"Swedish operators fixed - eller: {eller_count} → or, och: {och_count} → and")
    print(f"Also fixed incorrect comparison operators like '>=='")
    print("File saved successfully!")

except Exception as e:
    print(f"ERROR: {e}")

print("Script completed.")