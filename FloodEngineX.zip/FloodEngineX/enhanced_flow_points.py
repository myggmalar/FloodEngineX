"""
Enhanced Flow Point Visualization for FloodEngine
------------------------------------------------
Advanced flow visualization using density-based points with velocity-dependent
colors and spacing. Points are denser in high-velocity areas (bottlenecks, steep slopes)
and use blue-to-red color gradient to show velocity magnitude.
"""

import os
import time
import math
import numpy as np
import random
import shutil
from osgeo import gdal
import logging
from scipy.ndimage import gaussian_filter
from qgis.core import (
    QgsVectorLayer, QgsField, QgsFeature, QgsGeometry, QgsPointXY,
    QgsWkbTypes, QgsVectorFileWriter, QgsPoint, QgsCoordinateReferenceSystem,
    QgsFields, QgsSymbol, QgsRendererCategory, QgsCategorizedSymbolRenderer,
    QgsGraduatedSymbolRenderer, QgsClassificationMethod, QgsStyle,
    QgsMarkerSymbol, QgsSingleSymbolRenderer
)
from PyQt5.QtCore import QVariant
from PyQt5.QtGui import QColor

logger = logging.getLogger("FloodEngine.EnhancedFlowPoints")

class EnhancedFlowPoints:
    """Advanced flow visualization using velocity-based point density and colors"""
    
    def __init__(self, dem_array, geotransform, water_depth=None, water_level=None):
        """
        Initialize flow point generator.
        
        Parameters:
            dem_array (numpy.ndarray): DEM array
            geotransform (tuple): GDAL geotransform
            water_depth (numpy.ndarray, optional): Water depth array
            water_level (float or numpy.ndarray, optional): Water level
        """
        self.dem = dem_array
        self.geotransform = geotransform
        self.shape = dem_array.shape
        
        # Calculate cell size from geotransform
        self.dx = abs(geotransform[1])
        self.dy = abs(geotransform[5])
        
        # Set water depth
        if water_depth is not None:
            self.water_depth = water_depth
        elif water_level is not None:
            if isinstance(water_level, (int, float)):
                self.water_depth = np.maximum(water_level - dem_array, 0)
            else:
                self.water_depth = np.maximum(water_level - dem_array, 0)
        else:
            self.water_depth = np.zeros_like(dem_array)
        
        # Initialize velocity fields
        self.velocity_x = np.zeros(self.shape)
        self.velocity_y = np.zeros(self.shape)
        self.velocity_mag = np.zeros(self.shape)
        
        # Parameters for flow point generation
        self.min_velocity = 0.001  # m/s - LOWERED to catch more points
        self.min_depth = 0.01     # m
        self.smoothing = 1.5      # smoothing parameter
        
        # Point density parameters - BALANCED with smaller points
        self.base_density = 0.05  # Base points per cell - Moderate density with small points
        self.max_density = 0.2    # Maximum points per cell - Reasonable for small points
        self.velocity_threshold_low = 0.05   # m/s - lower threshold for more inclusive distribution
        self.velocity_threshold_high = 1.0   # m/s - adjusted for typical flood velocities
        
    def calculate_velocity_field(self, manning_n=0.035, method="hydraulic", 
                                saint_venant_results=None):
        """
        Calculate velocity field based on 2D Saint-Venant results or water surface gradient.
        
        Parameters:
            manning_n (float or numpy.ndarray): Manning's roughness coefficient
            method (str): Method to use ("hydraulic", "diffusive", "saint_venant")
            saint_venant_results (dict): Results from Saint-Venant 2D solver containing velocity fields
            
        Returns:
            tuple: Velocity components and magnitude (vx, vy, vmag)
        """
        logger.info(f"Calculating velocity field using {method} method")
        
        # If we have Saint-Venant results, use the actual computed velocities
        if saint_venant_results is not None and method == "saint_venant":
            logger.info("Using Saint-Venant velocity field results")
            self.velocity_x = saint_venant_results.get('velocity_x', np.zeros(self.shape))
            self.velocity_y = saint_venant_results.get('velocity_y', np.zeros(self.shape))
            
            # CRITICAL FIX: Ensure velocity magnitude is always positive
            self.velocity_mag = np.sqrt(self.velocity_x**2 + self.velocity_y**2)
            
            # Debug: Check for any negative values in Saint-Venant results
            neg_vx = np.sum(self.velocity_x < 0)
            neg_vy = np.sum(self.velocity_y < 0)
            neg_vmag = np.sum(self.velocity_mag < 0)
            
            logger.info(f"Saint-Venant velocity field debugging:")
            logger.info(f"  • Negative velocity_x cells: {neg_vx}")
            logger.info(f"  • Negative velocity_y cells: {neg_vy}")
            logger.info(f"  • Negative velocity_mag cells: {neg_vmag} (should be 0!)")
            
            # SAFETY CHECK: Force velocity magnitude to be positive
            self.velocity_mag = np.abs(self.velocity_mag)
            
            # Additional safety: Replace any NaN or infinite values
            self.velocity_x = np.nan_to_num(self.velocity_x, nan=0.0, posinf=0.0, neginf=0.0)
            self.velocity_y = np.nan_to_num(self.velocity_y, nan=0.0, posinf=0.0, neginf=0.0)
            self.velocity_mag = np.nan_to_num(self.velocity_mag, nan=0.0, posinf=0.0, neginf=0.0)
            
            # DON'T apply flow direction correction to Saint-Venant results!
            # Saint-Venant already accounts for proper 2D hydraulic physics
            logger.info("✅ Using pure Saint-Venant velocity field (no direction correction)")
            logger.info(f"Saint-Venant velocity statistics (cleaned):")
            logger.info(f"  • Max velocity: {np.max(self.velocity_mag):.3f} m/s")
            logger.info(f"  • Mean velocity: {np.mean(self.velocity_mag[self.velocity_mag > 0]):.3f} m/s")
            logger.info(f"  • Cells with velocity > 0.1: {np.sum(self.velocity_mag > 0.1)}")
            
            return self.velocity_x, self.velocity_y, self.velocity_mag
        
        # Create a water surface array with proper padding to handle edges
        self.water_level = self.dem + self.water_depth
        water_surface = np.pad(self.water_level, pad_width=2, mode='edge')
        
        # Initial velocity arrays
        self.velocity_x = np.zeros(self.shape)
        self.velocity_y = np.zeros(self.shape)
        self.velocity_mag = np.zeros(self.shape)
        
        # Apply gaussian smoothing to water surface for stable gradient calculation
        water_surface = gaussian_filter(water_surface, sigma=self.smoothing)
        
        # Create a mask for valid flow calculation (areas with sufficient water)
        valid_mask = self.water_depth > self.min_depth
        
        if np.sum(valid_mask) == 0:
            logger.warning("No cells with sufficient water depth for velocity calculation!")
            return self.velocity_x, self.velocity_y, self.velocity_mag
        
        # Process only the valid cells for efficiency
        rows, cols = self.shape
        valid_indices = np.argwhere(valid_mask)
        
        # Ensure manning_n is array-like
        if isinstance(manning_n, (int, float)):
            manning_array = np.full(self.shape, manning_n)
        else:
            manning_array = manning_n
        
        # Calculate gradient and velocity for each valid cell
        # ENHANCED 2D HYDRAULIC MODELING: Include upstream flow accumulation and hydraulic pressure
        logger.info("🔧 ENHANCED: Using 2D hydraulic modeling with upstream flow accumulation")
        
        # Step 1: Calculate flow accumulation (upstream contributing area)
        flow_accumulation = self._calculate_flow_accumulation(valid_mask)
        
        # Step 2: Calculate bed slope using DEM
        padded_dem = np.pad(self.dem, pad_width=2, mode='edge')
        
        # Step 3: Calculate water surface slope (hydraulic gradient)
        water_surface_slope_x = np.zeros(self.shape)
        water_surface_slope_y = np.zeros(self.shape)
        
        for i, j in valid_indices:
            # Water surface slope (hydraulic gradient)
            ws_dh_dx = (water_surface[i+2, j+3] - water_surface[i+2, j+1]) / (2 * self.dx)
            ws_dh_dy = (water_surface[i+3, j+2] - water_surface[i+1, j+2]) / (2 * self.dy)
            
            water_surface_slope_x[i, j] = ws_dh_dx
            water_surface_slope_y[i, j] = ws_dh_dy
        
        # Step 4: Calculate velocities using 2D continuity and momentum equations
        for i, j in valid_indices:
            depth = self.water_depth[i, j]
            
            # Calculate BED SLOPE using DEM
            bed_dh_dx = (padded_dem[i+2, j+3] - padded_dem[i+2, j+1]) / (2 * self.dx)
            bed_dh_dy = (padded_dem[i+3, j+2] - padded_dem[i+1, j+2]) / (2 * self.dy)
            bed_slope_mag = np.sqrt(bed_dh_dx**2 + bed_dh_dy**2)
            
            # BATHYMETRY COMPENSATION: If no bathymetry, estimate channel slope
            # For deep areas (main channels), use a minimum realistic slope
            if depth > 1.5:  # Main channel - apply minimum slope for realistic flow
                min_channel_slope = 0.001  # 0.1% slope - typical for rivers
                if bed_slope_mag < min_channel_slope:
                    bed_slope_mag = min_channel_slope
                    logger.debug(f"Applied minimum channel slope at depth {depth:.2f}m")
            elif depth > 0.5:  # Secondary channels
                min_channel_slope = 0.0005  # 0.05% slope
                if bed_slope_mag < min_channel_slope:
                    bed_slope_mag = min_channel_slope
            
            # Get water surface slope (hydraulic gradient)
            ws_slope_x = water_surface_slope_x[i, j]
            ws_slope_y = water_surface_slope_y[i, j]
            ws_slope_mag = np.sqrt(ws_slope_x**2 + ws_slope_y**2)
            
            # Get upstream flow accumulation
            flow_acc = flow_accumulation[i, j]
            
            # Calculate discharge per unit width based on upstream flow
            # This represents the hydraulic pressure from upstream
            upstream_discharge = self._calculate_upstream_discharge(flow_acc, depth)
            
            # Enhanced velocity calculation considering 2D hydraulic effects
            if depth > 1.5:  # Main river channel (deep water)
                n_effective = manning_array[i, j] * 0.8  # Slightly higher roughness for realism
                channel_factor = 1.5  # Reduced from 2.0 for realistic speeds
                
            elif depth > 0.5:  # Secondary channels
                n_effective = manning_array[i, j] * 0.9  # Slightly higher roughness
                channel_factor = 1.2  # Reduced from 1.5 for realistic speeds
                
            else:  # Floodplain/shallow areas
                n_effective = manning_array[i, j] * 1.2  # Rougher flow on floodplains
                channel_factor = 0.8  # Slightly increased for balance
            
            # Primary velocity calculation using Manning's equation with bed slope
            if bed_slope_mag > 1e-6:
                hydraulic_radius = depth
                manning_vel = (1.0 / n_effective) * (hydraulic_radius ** (2/3)) * (bed_slope_mag ** 0.5)
                manning_vel = min(manning_vel, 2.0)  # Realistic cap for Manning's velocity
                
                # Direction from bed slope (or estimated direction for channels)
                if bed_slope_mag > 1e-6:
                    bed_dir_x = -bed_dh_dx / bed_slope_mag
                    bed_dir_y = -bed_dh_dy / bed_slope_mag
                else:
                    # Default downstream direction for channels with no slope
                    bed_dir_x = 0.0
                    bed_dir_y = -1.0
            else:
                manning_vel = 0.0
                bed_dir_x = 0.0
                bed_dir_y = -1.0  # Default downstream direction
            
            # Secondary velocity from hydraulic pressure (water surface gradient)
            if ws_slope_mag > 1e-6:
                # Velocity due to hydraulic pressure gradient
                pressure_vel = upstream_discharge / (depth * 1.0)  # Unit width = 1m
                pressure_vel = min(pressure_vel, 1.0)  # Realistic cap for pressure-driven velocity
                
                # Direction from water surface slope
                ws_dir_x = -ws_slope_x / ws_slope_mag
                ws_dir_y = -ws_slope_y / ws_slope_mag
            else:
                pressure_vel = 0.0
                ws_dir_x = 0.0
                ws_dir_y = -1.0
            
            # Combine velocities: Manning's (bed slope) + hydraulic pressure
            # Weight Manning's velocity higher for steep slopes, pressure velocity for gentle slopes
            if bed_slope_mag > 1e-4:  # Steep areas - bed slope dominates
                vel_magnitude = manning_vel * channel_factor + 0.3 * pressure_vel
                direction_x = bed_dir_x
                direction_y = bed_dir_y
            else:  # Gentle areas - hydraulic pressure dominates
                vel_magnitude = 0.3 * manning_vel + pressure_vel * channel_factor
                direction_x = ws_dir_x
                direction_y = ws_dir_y
            
            # Apply minimum velocity based on flow accumulation
            min_vel = min(0.05 + 0.02 * np.log10(max(flow_acc, 1)), 0.3)  # Reduced max min_vel
            vel_magnitude = max(vel_magnitude, min_vel)
            
            # ENHANCED: Apply flow concentration bonus for channels (REALISTIC VALUES)
            # This ensures main channels have higher velocities than floodplains
            if depth > 1.5:  # Main channel
                flow_concentration_bonus = 0.2 + 0.05 * np.log10(max(flow_acc, 1))  # Reduced bonus
                flow_concentration_bonus = min(flow_concentration_bonus, 0.5)  # Cap the bonus
                vel_magnitude += flow_concentration_bonus
                logger.debug(f"Main channel bonus: {flow_concentration_bonus:.3f} m/s at depth {depth:.2f}m")
            elif depth > 0.5:  # Secondary channel
                flow_concentration_bonus = 0.1 + 0.02 * np.log10(max(flow_acc, 1))  # Reduced bonus
                flow_concentration_bonus = min(flow_concentration_bonus, 0.3)  # Cap the bonus
                vel_magnitude += flow_concentration_bonus
            
            # REALISTIC FINAL VELOCITY CAP
            vel_magnitude = min(vel_magnitude, 2.5)  # Much more realistic maximum velocity
            
            # Store velocity components
            self.velocity_x[i, j] = vel_magnitude * direction_x
            self.velocity_y[i, j] = vel_magnitude * direction_y
            self.velocity_mag[i, j] = vel_magnitude
        
        # CRITICAL FIX: Final depth masking of velocity arrays
        # Ensure velocity is zero where depth < min_depth
        depth_mask = self.water_depth < self.min_depth
        self.velocity_x[depth_mask] = 0.0
        self.velocity_y[depth_mask] = 0.0
        self.velocity_mag[depth_mask] = 0.0
        
        logger.info(f"Velocity field calculated. Max velocity: {np.nanmax(self.velocity_mag):.2f} m/s")
        logger.info(f"DEPTH MASKING: Set velocity to zero in {np.sum(depth_mask)} cells where depth < {self.min_depth}m")
        
        return self.velocity_x, self.velocity_y, self.velocity_mag
    
    def _correct_flow_direction(self):
        """
        Correct flow direction to ensure water flows downhill and follows physical constraints.
        """
        logger.info("Correcting flow direction for physical consistency")
        
        # Calculate topographic gradients
        padded_dem = np.pad(self.dem, pad_width=1, mode='edge')
        topo_grad_x = np.zeros(self.shape)
        topo_grad_y = np.zeros(self.shape)
        
        rows, cols = self.shape
        for i in range(rows):
            for j in range(cols):
                # Calculate topographic gradient using central differences
                topo_grad_x[i, j] = (padded_dem[i+1, j+2] - padded_dem[i+1, j]) / (2 * self.dx)
                topo_grad_y[i, j] = (padded_dem[i+2, j+1] - padded_dem[i, j+1]) / (2 * self.dy)
        
        # Create mask for areas with water
        water_mask = self.water_depth > self.min_depth
        
        # For each cell with water, check if velocity is consistent with topography
        inconsistent_cells = 0
        for i in range(rows):
            for j in range(cols):
                if not water_mask[i, j]:
                    continue
                    
                # Check if velocity direction is opposite to topographic gradient
                vel_dot_grad = (self.velocity_x[i, j] * topo_grad_x[i, j] + 
                               self.velocity_y[i, j] * topo_grad_y[i, j])
                
                # If velocity is in the same direction as gradient (uphill), correct it
                if vel_dot_grad > 0:
                    # Redirect velocity to follow steepest descent
                    grad_mag = np.sqrt(topo_grad_x[i, j]**2 + topo_grad_y[i, j]**2)
                    if grad_mag > 1e-6:
                        # Maintain velocity magnitude but correct direction
                        vel_mag = np.sqrt(self.velocity_x[i, j]**2 + self.velocity_y[i, j]**2)
                        self.velocity_x[i, j] = -vel_mag * topo_grad_x[i, j] / grad_mag
                        self.velocity_y[i, j] = -vel_mag * topo_grad_y[i, j] / grad_mag
                        inconsistent_cells += 1
        
        # Recalculate velocity magnitude
        self.velocity_mag = np.sqrt(self.velocity_x**2 + self.velocity_y**2)
        
        if inconsistent_cells > 0:
            logger.info(f"Corrected {inconsistent_cells} cells with inconsistent flow direction")
    
    def generate_flow_points(self, flood_mask=None):
        """
        Generate flow visualization points with velocity-based density and colors.
        
        Parameters:
            flood_mask (numpy.ndarray): Boolean mask of flooded area
            
        Returns:
            list: List of point features with velocity attributes
        """
        logger.info("Generating velocity-based flow points")
        
        # Create flood mask if not provided
        if flood_mask is None:
            flood_mask = self.water_depth > self.min_depth
        
        # Get all flooded cells
        flooded_indices = np.argwhere(flood_mask)
        
        if len(flooded_indices) == 0:
            logger.warning("No flooded cells found for flow point generation!")
            return []
        
        points = []
        total_points = 0
        
        # Calculate velocity statistics for normalization
        velocities_in_flood = self.velocity_mag[flood_mask]
        velocities_in_flood = velocities_in_flood[velocities_in_flood > 0]
        
        if len(velocities_in_flood) == 0:
            logger.warning("No velocity data found in flooded areas!")
            return []
        
        v_min = np.percentile(velocities_in_flood, 5)   # 5th percentile
        v_max = np.percentile(velocities_in_flood, 95)  # 95th percentile
        v_mean = np.mean(velocities_in_flood)
        
        logger.info(f"Velocity range: {v_min:.3f} - {v_max:.3f} m/s (mean: {v_mean:.3f})")
        logger.info(f"Minimum velocity threshold: {self.min_velocity:.3f} m/s")
        logger.info(f"Total flooded cells: {len(flooded_indices)}")
        
        # Generate points for each flooded cell with RIVER CHANNEL PRIORITY
        points_generated = 0
        cells_processed = 0
        cells_skipped_low_velocity = 0
        cells_with_points = 0
        channel_points = 0
        floodplain_points = 0
        
        for i, j in flooded_indices:
            cells_processed += 1
            depth = self.water_depth[i, j]
            
            # CRITICAL FIX: Safe velocity extraction with depth masking
            # Only report velocity where depth > MIN_DEPTH, set to zero elsewhere
            if np.isnan(depth) or depth < self.min_depth:
                velocity = 0.0
                velocity_x_raw = 0.0
                velocity_y_raw = 0.0
            else:
                velocity = self.velocity_mag[i, j]
                velocity_x_raw = self.velocity_x[i, j]
                velocity_y_raw = self.velocity_y[i, j]
                
                # Additional safety: check for NaN or infinite values
                if not np.isfinite(velocity):
                    velocity = 0.0
                if not np.isfinite(velocity_x_raw):
                    velocity_x_raw = 0.0
                if not np.isfinite(velocity_y_raw):
                    velocity_y_raw = 0.0
            
            # ENHANCED: Prioritize river channels (deep areas) even with lower calculated velocities
            is_river_channel = depth > 1.0  # Main channel
            is_secondary_channel = depth > 0.5  # Secondary channel
            
            # Adjusted velocity threshold for different areas
            if is_river_channel:
                min_vel_threshold = 0.0001  # Very low threshold for main channels
                logger.debug(f"River channel at ({i},{j}): depth={depth:.2f}m, vel={velocity:.3f}m/s")
            elif is_secondary_channel:
                min_vel_threshold = 0.001   # Low threshold for secondary channels
            else:
                min_vel_threshold = self.min_velocity  # Normal threshold for floodplains
            
            # Skip cells with very low velocity (unless it's a river channel)
            if velocity < min_vel_threshold:
                cells_skipped_low_velocity += 1
                continue
            
            # ENHANCED: Skip cells randomly to reduce overall density significantly
            # This provides better spatial distribution while keeping density very manageable
            skip_probability = 0.92  # Skip 92% of cells for low density with tiny points
            if is_river_channel:
                skip_probability = 0.75  # Skip fewer river channel cells (25% kept)
            elif is_secondary_channel:
                skip_probability = 0.85  # Skip fewer secondary channel cells (15% kept)
            else:
                skip_probability = 0.95  # Skip most floodplain cells (5% kept)
            
            if random.random() < skip_probability:
                cells_skipped_low_velocity += 1
                continue
            
            # Enhanced point density calculation - BALANCED for readability
            if is_river_channel:
                # River channels get higher density but not excessive
                density = self.max_density * 2.0  # 2x max density for main channels
                channel_points += 1
                logger.debug(f"Main channel point density: {density}")
                
            elif is_secondary_channel:
                # Secondary channels get moderate density
                density = self.max_density * 1.5  # 1.5x max density for secondary channels
                channel_points += 1
                
            else:
                # Floodplains use velocity-based density
                normalized_velocity = np.clip((velocity - v_min) / (v_max - v_min), 0, 1)
                density = self.base_density + (self.max_density - self.base_density) * normalized_velocity
                floodplain_points += 1
            
            # Depth factor enhancement
            depth_factor = min(depth / 2.0, 1.0)
            density *= (0.3 + 0.7 * depth_factor)  # More bias toward deep areas
            
            # Calculate number of points for this cell - LIMIT TO 1 point per cell for readability
            # Even with density > 1, we limit to 1 point per cell to avoid clustering
            num_points = 1  # Always 1 point per selected cell
            cells_with_points += 1
            
            # Generate points within the cell
            for _ in range(num_points):
                # Random position within the cell
                offset_x = random.uniform(-0.4, 0.4) * self.dx
                offset_y = random.uniform(-0.4, 0.4) * self.dy
                
                # World coordinates
                world_x = self.geotransform[0] + j * self.geotransform[1] + offset_x
                world_y = self.geotransform[3] + i * self.geotransform[5] + offset_y
                
                # SAFETY CHECK: Use the already-masked velocity values
                velocity_safe = abs(float(velocity))  # Force positive
                velocity_x_safe = float(velocity_x_raw)
                velocity_y_safe = float(velocity_y_raw)
                
                # Create point feature
                point_data = {
                    'geometry': QgsPointXY(world_x, world_y),
                    'velocity': velocity_safe,  # Already masked for depth
                    'depth': float(depth),
                    'velocity_x': velocity_x_safe,
                    'velocity_y': velocity_y_safe,
                    'cell_i': int(i),
                    'cell_j': int(j)
                }
                
                points.append(point_data)
                points_generated += 1
        
        logger.info(f"🔧 ENHANCED FLOW POINTS GENERATION SUMMARY:")
        logger.info(f"  • Total flooded cells: {len(flooded_indices)}")
        logger.info(f"  • Cells processed: {cells_processed}")
        logger.info(f"  • Cells with points: {cells_with_points}")
        logger.info(f"  • River channel points: {channel_points}")
        logger.info(f"  • Floodplain points: {floodplain_points}")
        logger.info(f"  • Cells skipped (low velocity): {cells_skipped_low_velocity}")
        logger.info(f"  • Velocity threshold: {self.min_velocity} m/s")
        logger.info(f"  • Points generated: {points_generated}")
        logger.info(f"  • Velocity range: {v_min:.3f} - {v_max:.3f} m/s")
        logger.info(f"  🎯 FIXED: River channels prioritized for point generation!")
        
        # If we don't have enough points, create fallback points from low-velocity areas
        if points_generated < 10 and cells_skipped_low_velocity > 0:
            logger.info(f"⚠️  Only {points_generated} points generated, creating fallback points from low-velocity areas")
            
            # Sample some low-velocity cells to create additional points
            fallback_points = 0
            sample_size = min(50, cells_skipped_low_velocity)  # Sample up to 50 cells
            
            for i, j in flooded_indices:
                if fallback_points >= sample_size:
                    break
                    
                depth = self.water_depth[i, j]
                
                # CRITICAL FIX: Safe velocity extraction with depth masking
                # Only process cells with sufficient depth and apply depth mask to velocity
                if np.isnan(depth) or depth < self.min_depth:
                    continue  # Skip cells with insufficient depth
                    
                # Extract velocity with depth masking
                velocity = self.velocity_mag[i, j]
                velocity_x_raw = self.velocity_x[i, j]
                velocity_y_raw = self.velocity_y[i, j]
                
                # Additional safety: check for NaN or infinite values
                if not np.isfinite(velocity):
                    velocity = 0.0
                if not np.isfinite(velocity_x_raw):
                    velocity_x_raw = 0.0
                if not np.isfinite(velocity_y_raw):
                    velocity_y_raw = 0.0
                
                # Only process cells that were skipped due to low velocity
                if velocity < self.min_velocity:
                    # World coordinates (center of cell)
                    world_x = self.geotransform[0] + j * self.geotransform[1]
                    world_y = self.geotransform[3] + i * self.geotransform[5]
                    
                    # Create point feature
                    point_data = {
                        'geometry': QgsPointXY(world_x, world_y),
                        'velocity': float(velocity),
                        'depth': float(depth),
                        'velocity_x': float(velocity_x_raw),
                        'velocity_y': float(velocity_y_raw),
                        'cell_i': int(i),
                        'cell_j': int(j)
                    }
                    
                    points.append(point_data)
                    fallback_points += 1
                    
            logger.info(f"✅ Added {fallback_points} fallback points from low-velocity areas")
            points_generated += fallback_points
        
        # Final fallback: if still very few points, add uniform grid points
        if points_generated < 20:
            logger.info(f"⚠️  Still only {points_generated} points, adding uniform grid points")
            
            # Create a uniform grid across the flood area
            flood_bounds = self._get_flood_bounds(flooded_indices)
            min_i, max_i, min_j, max_j = flood_bounds
            
            # Create a 5x5 grid within the flood bounds
            grid_size = 5
            step_i = max(1, (max_i - min_i) // grid_size)
            step_j = max(1, (max_j - min_j) // grid_size)
            
            uniform_points = 0
            for grid_i in range(min_i, max_i, step_i):
                for grid_j in range(min_j, max_j, step_j):
                    if flood_mask[grid_i, grid_j]:  # Only in flooded areas
                        depth = self.water_depth[grid_i, grid_j]
                        
                        # CRITICAL FIX: Apply depth masking to velocity extraction
                        if np.isnan(depth) or depth < self.min_depth:
                            velocity = 0.0
                            velocity_x_raw = 0.0
                            velocity_y_raw = 0.0
                        else:
                            velocity = self.velocity_mag[grid_i, grid_j]
                            velocity_x_raw = self.velocity_x[grid_i, grid_j]
                            velocity_y_raw = self.velocity_y[grid_i, grid_j]
                            
                            # Additional safety: check for NaN or infinite values
                            if not np.isfinite(velocity):
                                velocity = 0.0
                            if not np.isfinite(velocity_x_raw):
                                velocity_x_raw = 0.0
                            if not np.isfinite(velocity_y_raw):
                                velocity_y_raw = 0.0
                        
                        # World coordinates
                        world_x = self.geotransform[0] + grid_j * self.geotransform[1]
                        world_y = self.geotransform[3] + grid_i * self.geotransform[5]
                        
                        point_data = {
                            'geometry': QgsPointXY(world_x, world_y),
                            'velocity': float(max(velocity, 0.0)),  # Ensure non-negative velocity
                            'depth': float(max(depth, 0.01)),       # Ensure minimum depth for display
                            'velocity_x': float(velocity_x_raw),
                            'velocity_y': float(velocity_y_raw),
                            'cell_i': int(grid_i),
                            'cell_j': int(grid_j)
                        }
                        
                        points.append(point_data)
                        uniform_points += 1
            
            logger.info(f"✅ Added {uniform_points} uniform grid points")
            points_generated += uniform_points
        
        total_points = points_generated
        
        logger.info(f"Generated {total_points} flow points from {len(flooded_indices)} flooded cells")
        
        return points
    
    def save_flow_points_shapefile(self, points, output_path, crs=None):
        """
        Save flow points to shapefile with velocity-based styling.
        
        Parameters:
            points (list): List of point data dictionaries
            output_path (str): Output shapefile path
            crs (str or QgsCoordinateReferenceSystem): Coordinate reference system
            
        Returns:
            QgsVectorLayer: The created flow points layer with styling
        """
        logger.info(f"Saving {len(points)} flow points to {output_path}")
        
        if not points:
            logger.error("No points to save! Flow points generation failed.")
            return None
        
        # Debug: Check first point
        logger.info(f"Sample point data: {points[0]}")
        
        # Create fields for the shapefile
        fields = QgsFields()
        fields.append(QgsField("id", QVariant.Int))
        fields.append(QgsField("velocity", QVariant.Double))
        fields.append(QgsField("depth", QVariant.Double))
        fields.append(QgsField("velocity_x", QVariant.Double))
        fields.append(QgsField("velocity_y", QVariant.Double))
        fields.append(QgsField("vel_class", QVariant.String))
        
        logger.info(f"Created fields: {[field.name() for field in fields]}")
        
        # Use provided CRS or default
        if crs is None:
            crs = "EPSG:4326"  # WGS84 as fallback
            logger.info("Using default CRS: EPSG:4326")
        
        if isinstance(crs, str):
            crs_obj = QgsCoordinateReferenceSystem(crs)
            logger.info(f"Created CRS object from string: {crs}")
            logger.info(f"CRS is valid: {crs_obj.isValid()}")
        else:
            crs_obj = crs
            logger.info(f"Using provided CRS object: {crs_obj}")
        
        logger.info(f"Using CRS: {crs}")
        logger.info(f"Output path for shapefile: {output_path}")
        logger.info(f"Output directory exists: {os.path.exists(os.path.dirname(output_path))}")
        logger.info(f"Output path already exists: {os.path.exists(output_path)}")
        
        # Create writer
        try:
            writer = QgsVectorFileWriter(
                output_path,
                "UTF-8",
                fields,
                QgsWkbTypes.Point,
                crs_obj if 'crs_obj' in locals() else QgsCoordinateReferenceSystem(crs),
                "ESRI Shapefile"
            )
            logger.info("QgsVectorFileWriter created successfully")
        except Exception as e:
            logger.error(f"Exception creating QgsVectorFileWriter: {e}")
            return None
        
        # Check for errors
        if writer.hasError() != QgsVectorFileWriter.NoError:
            error = writer.errorMessage()
            logger.error(f"Error creating shapefile: {error}")
            return None
        
        # Calculate velocity classes for color coding
        velocities = [p['velocity'] for p in points]
        v_min = min(velocities)
        v_max = max(velocities)
        
        # Write features
        features_written = 0
        for i, point_data in enumerate(points):
            try:
                feature = QgsFeature(fields)
                feature.setGeometry(QgsGeometry.fromPointXY(point_data['geometry']))
                
                # Classify velocity for color coding using actual m/s values
                velocity = point_data['velocity']
                
                # Use actual velocity thresholds in m/s (more intuitive)
                if velocity < 0.1:
                    vel_class = f"Very Low (<0.1 m/s)"
                elif velocity < 0.3:
                    vel_class = f"Low (0.1-0.3 m/s)"
                elif velocity < 0.6:
                    vel_class = f"Medium (0.3-0.6 m/s)"
                elif velocity < 1.0:
                    vel_class = f"High (0.6-1.0 m/s)"
                else:
                    vel_class = f"Very High (>1.0 m/s)"
                
                # Set attributes
                feature.setAttribute("id", i)
                feature.setAttribute("velocity", velocity)
                feature.setAttribute("depth", point_data['depth'])
                feature.setAttribute("velocity_x", point_data['velocity_x'])
                feature.setAttribute("velocity_y", point_data['velocity_y'])
                feature.setAttribute("vel_class", vel_class)
                
                # Write feature
                success = writer.addFeature(feature)
                if success:
                    features_written += 1
                else:
                    logger.warning(f"Failed to write feature {i}")
                    
            except Exception as e:
                logger.error(f"Error writing feature {i}: {e}")
        
        logger.info(f"Successfully wrote {features_written}/{len(points)} features to shapefile")
        
        # Clean up writer
        del writer
        
        # Load the layer and apply styling
        layer = QgsVectorLayer(output_path, "Flow Velocity Points", "ogr")
        
        if layer.isValid():
            try:
                self._apply_velocity_styling(layer)
                logger.info("Flow points created successfully with velocity-based styling")
                return layer
            except Exception as e:
                logger.warning(f"Could not apply styling: {e}")
                logger.info("Flow points created successfully without styling")
                return layer
        else:
            logger.error(f"Could not load created layer: {output_path}")
            return None
    
    def _apply_velocity_styling(self, layer):
        """
        Apply velocity-based color styling to the flow points layer.
        
        Parameters:
            layer (QgsVectorLayer): The flow points layer
        """
        logger.info("Applying velocity-based styling to flow points")
        
        try:
            # Create categorized symbol renderer (not graduated)
            renderer = QgsCategorizedSymbolRenderer()
            renderer.setClassAttribute("vel_class")
            
            # Define color ramp: GREEN (low) → BLUE → YELLOW → ORANGE → DARK RED (high)
            colors = [
                QColor(0, 255, 0),      # Green (very low velocity)
                QColor(0, 150, 255),    # Blue (low velocity) 
                QColor(255, 255, 0),    # Yellow (medium velocity)
                QColor(255, 165, 0),    # Orange (high velocity)
                QColor(139, 0, 0),      # Dark Red (very high velocity)
            ]
            
            # Create symbol categories with corrected color scheme
            categories = [
                ("Very Low (<0.1 m/s)", colors[0]),    # Green
                ("Low (0.1-0.3 m/s)", colors[1]),      # Blue
                ("Medium (0.3-0.6 m/s)", colors[2]),   # Yellow
                ("High (0.6-1.0 m/s)", colors[3]),     # Orange
                ("Very High (>1.0 m/s)", colors[4])    # Dark Red
            ]
            
            # Create renderer categories
            for label, color in categories:
                symbol = QgsMarkerSymbol.createSimple({
                    'name': 'circle',
                    'color': color.name(),
                    'size': '0.7',  # TINY points (was 1.0)
                    'outline_color': 'black',
                    'outline_width': '0.03',  # Very thin outline
                    'color_alpha': '150'  # More transparent (59% opacity)
                })
                
                category = QgsRendererCategory(label, symbol, label)
                renderer.addCategory(category)
            
            # Set the renderer to the layer
            layer.setRenderer(renderer)
            
            # Trigger a repaint
            layer.triggerRepaint()
            
            logger.info("Successfully applied velocity-based styling")
            
        except Exception as e:
            logger.error(f"Error applying styling: {e}")
            # Apply a simple single symbol renderer as fallback
            try:
                symbol = QgsMarkerSymbol.createSimple({
                    'name': 'circle',
                    'color': 'green',  # Green for fallback (low velocity)
                    'size': '0.7',  # TINY fallback points
                    'outline_color': 'black',
                    'outline_width': '0.03',
                    'color_alpha': '150'  # More transparent
                })
                renderer = QgsSingleSymbolRenderer(symbol)
                layer.setRenderer(renderer)
                layer.triggerRepaint()
                logger.info("Applied fallback single symbol styling with transparency")
            except Exception as e2:
                logger.error(f"Could not apply fallback styling: {e2}")

    def _get_flood_bounds(self, flooded_indices):
        """Get the bounding box of the flooded area in array indices"""
        if len(flooded_indices) == 0:
            return 0, 0, 0, 0
            
        min_i = np.min(flooded_indices[:, 0])
        max_i = np.max(flooded_indices[:, 0])
        min_j = np.min(flooded_indices[:, 1])
        max_j = np.max(flooded_indices[:, 1])
        
        return min_i, max_i, min_j, max_j

    def _calculate_flow_accumulation(self, valid_mask):
        """
        Calculate flow accumulation (upstream contributing area) for 2D hydraulic modeling.
        This represents the hydraulic pressure from upstream flow.
        
        Parameters:
            valid_mask (numpy.ndarray): Boolean mask of cells with water
            
        Returns:
            numpy.ndarray: Flow accumulation values
        """
        logger.info("Calculating flow accumulation for 2D hydraulic modeling")
        
        # Initialize flow accumulation array
        flow_acc = np.ones(self.shape, dtype=np.float32)
        
        # Create a list of all valid cells with their elevations
        valid_indices = np.argwhere(valid_mask)
        
        if len(valid_indices) == 0:
            return flow_acc
        
        # Sort cells by elevation (highest to lowest) for proper flow routing
        cell_elevations = []
        for i, j in valid_indices:
            elevation = self.dem[i, j]
            cell_elevations.append((elevation, i, j))
        
        # Sort by elevation (highest first)
        cell_elevations.sort(key=lambda x: x[0], reverse=True)
        
        # Process cells from highest to lowest elevation
        for elevation, i, j in cell_elevations:
            current_acc = flow_acc[i, j]
            
            # Find the steepest downhill neighbor
            max_slope = 0.0
            flow_i, flow_j = i, j
            
            # Check 8 neighbors
            for di in [-1, 0, 1]:
                for dj in [-1, 0, 1]:
                    if di == 0 and dj == 0:
                        continue
                    
                    ni, nj = i + di, j + dj
                    
                    # Check bounds
                    if (0 <= ni < self.shape[0] and 0 <= nj < self.shape[1] and 
                        valid_mask[ni, nj]):
                        
                        # Calculate slope to neighbor
                        distance = np.sqrt((di * self.dx)**2 + (dj * self.dy)**2)
                        slope = (self.dem[i, j] - self.dem[ni, nj]) / distance
                        
                        # Find steepest downhill slope
                        if slope > max_slope:
                            max_slope = slope
                            flow_i, flow_j = ni, nj
            
            # Route flow to the steepest downhill neighbor
            if flow_i != i or flow_j != j:
                flow_acc[flow_i, flow_j] += current_acc
        
        # Apply smoothing to reduce numerical noise
        flow_acc = gaussian_filter(flow_acc, sigma=1.0)
        
        # Log statistics
        max_acc = np.max(flow_acc[valid_mask])
        mean_acc = np.mean(flow_acc[valid_mask])
        logger.info(f"Flow accumulation: max={max_acc:.1f}, mean={mean_acc:.1f}")
        
        return flow_acc
    
    def _calculate_upstream_discharge(self, flow_accumulation, depth):
        """
        Calculate upstream discharge based on flow accumulation and local conditions.
        This represents the hydraulic pressure contribution from upstream flow.
        
        Parameters:
            flow_accumulation (float): Flow accumulation value
            depth (float): Local water depth
            
        Returns:
            float: Upstream discharge per unit width (m²/s)
        """
        # Base discharge calculation
        # Larger flow accumulation = more upstream contributing area = higher discharge
        base_discharge = 0.001 * flow_accumulation  # Base scaling factor
        
        # Adjust based on depth (deeper areas can handle more flow)
        if depth > 2.0:  # Deep channels
            depth_factor = 1.5
        elif depth > 1.0:  # Medium channels
            depth_factor = 1.2
        elif depth > 0.5:  # Shallow channels
            depth_factor = 1.0
        else:  # Very shallow areas
            depth_factor = 0.8
        
        # Calculate discharge per unit width
        discharge = base_discharge * depth_factor
        
        # Apply realistic limits
        discharge = min(discharge, 2.0)  # Cap at 2 m²/s per unit width
        discharge = max(discharge, 0.001)  # Minimum discharge
        
        return discharge

def create_enhanced_flow_points(dem_path, flood_layer, output_folder=None, flow_q=None, 
                             bathymetry=None, method="hydraulic"):
    """
    Create improved flow visualization using velocity-based point density and colors.
    
    Parameters:
        dem_path (str): Path to the DEM file
        flood_layer (QgsVectorLayer): Flood polygon layer
        output_folder (str): Output folder for results
        flow_q (float): Flow rate in m³/s
        bathymetry (list): Bathymetry points
        method (str): Hydraulic method to use
        
    Returns:
        QgsVectorLayer: Flow points layer
    """
    logger = logging.getLogger("FloodEngine.EnhancedFlowPoints")
    logger.setLevel(logging.INFO)
    
    if output_folder is None:
        output_folder = os.path.dirname(dem_path)
    
    # Ensure output folder exists and is writable
    try:
        os.makedirs(output_folder, exist_ok=True)
        logger.info(f"Output folder: {output_folder}")
        logger.info(f"Output folder exists: {os.path.exists(output_folder)}")
        logger.info(f"Output folder is directory: {os.path.isdir(output_folder)}")
    except Exception as e:
        logger.error(f"Could not create output folder {output_folder}: {e}")
        raise Exception(f"Could not create output folder: {e}")
    
    # Create unique output path to avoid file locks
    import time
    timestamp = int(time.time())
    base_name = f"enhanced_flow_points_{timestamp}"
    output_path = os.path.join(output_folder, f"{base_name}.shp")
    logger.info(f"Flow points output path: {output_path}")
    
    # Clean up any existing files with same base name (remove all related files)
    for ext in ['.shp', '.shx', '.dbf', '.prj', '.cpg']:
        old_file = os.path.join(output_folder, f"enhanced_flow_points{ext}")
        if os.path.exists(old_file):
            try:
                os.remove(old_file)
                logger.info(f"Removed existing file: {old_file}")
            except Exception as e:
                logger.warning(f"Could not remove {old_file}: {e}")
    
    # Also clean up the new files if they exist
    for ext in ['.shp', '.shx', '.dbf', '.prj', '.cpg']:
        new_file = os.path.join(output_folder, f"{base_name}{ext}")
        if os.path.exists(new_file):
            try:
                os.remove(new_file)
                logger.info(f"Removed existing file: {new_file}")
            except Exception as e:
                logger.warning(f"Could not remove {new_file}: {e}")
    
    # Step 1: Load DEM
    logger.info(f"Loading DEM from {dem_path}")
    try:
        dem_ds = gdal.Open(dem_path)
        dem_array = dem_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
        geotransform = dem_ds.GetGeoTransform()
        projection = dem_ds.GetProjection()
        nodata = dem_ds.GetRasterBand(1).GetNoDataValue()
        
        # Handle nodata values
        if nodata is None:
            nodata = -9999
        dem_array[dem_array == nodata] = np.nan
    except Exception as e:
        logger.error(f"Error loading DEM: {str(e)}")
        raise Exception(f"Could not load DEM: {str(e)}")
    
    # Step 2: Extract water level and flood polygon
    logger.info("Extracting water level and flood extent")
    try:
        water_levels = []
        flood_geom = None
        
        # Get water level and geometry from flood layer
        for feature in flood_layer.getFeatures():
            if 'water_lvl' in feature.fields().names():
                water_levels.append(float(feature['water_lvl']))
            
            if flood_geom is None:
                flood_geom = feature.geometry()
            else:
                flood_geom = flood_geom.combine(feature.geometry())
        
        # Check if we got the water level
        if not water_levels:
            raise Exception("Flood layer is missing 'water_lvl' attribute")
        
        # Use average water level if multiple values
        water_level = np.mean(water_levels)
        logger.info(f"Using water level: {water_level:.2f}m")
        
        # Check if we got a valid geometry
        if not flood_geom:
            raise Exception("Could not extract polygon from flood layer")
            
        # Create a mask for the flood area
        flood_mask = np.zeros(dem_array.shape, dtype=bool)
        bounds = flood_geom.boundingBox()
        
        # Create flood mask using flood polygon
        for y in range(dem_array.shape[0]):
            for x in range(dem_array.shape[1]):
                # Skip points outside bounding box for efficiency
                world_x = geotransform[0] + x * geotransform[1]
                world_y = geotransform[3] + y * geotransform[5]
                
                if (bounds.xMinimum() <= world_x <= bounds.xMaximum() and 
                    bounds.yMinimum() <= world_y <= bounds.yMaximum()):
                    if flood_geom.contains(QgsPointXY(world_x, world_y)):
                        flood_mask[y, x] = True
        
        logger.info(f"Flood area covers {np.sum(flood_mask)} cells")
    except Exception as e:
        logger.error(f"Error extracting water level: {str(e)}")
        raise Exception(f"Error extracting water level: {str(e)}")
        
    # Step 3: Calculate water depth
    water_depth = np.zeros_like(dem_array)
    water_depth[flood_mask] = water_level - dem_array[flood_mask]
    water_depth[water_depth < 0.01] = 0.0
    
    logger.info(f"Maximum water depth: {np.nanmax(water_depth):.2f}m")
    
    # Step 4: Initialize the flow point generator
    flow_generator = EnhancedFlowPoints(dem_array, geotransform, water_depth=water_depth)
    
    # Step 5: Try to load Saint-Venant velocity data if available
    saint_venant_results = None
    if method == "saint_venant" and output_folder:
        try:
            logger.info(f"Looking for Saint-Venant velocity files in: {output_folder}")
            # Look for velocity raster files in the output folder
            # FIXED: Look for the correct file pattern that Saint-Venant actually creates
            velocity_x_files = [f for f in os.listdir(output_folder) if f.startswith('velocity_x_') and f.endswith('.tif')]
            velocity_y_files = [f for f in os.listdir(output_folder) if f.startswith('velocity_y_') and f.endswith('.tif')]
            
            logger.info(f"Found velocity X files: {len(velocity_x_files)} files")
            logger.info(f"Found velocity Y files: {len(velocity_y_files)} files")
            
            if velocity_x_files and velocity_y_files:
                # Use the most recent timestep
                latest_vx_file = sorted(velocity_x_files)[-1]
                latest_vy_file = sorted(velocity_y_files)[-1]
                
                vx_path = os.path.join(output_folder, latest_vx_file)
                vy_path = os.path.join(output_folder, latest_vy_file)
                
                logger.info(f"Loading Saint-Venant velocity data:")
                logger.info(f"  - X component: {latest_vx_file}")
                logger.info(f"  - Y component: {latest_vy_file}")
                
                if os.path.exists(vx_path) and os.path.exists(vy_path):
                    logger.info(f"✅ Loading actual Saint-Venant velocity fields from 2D simulation")
                    
                    # Load velocity arrays
                    vx_ds = gdal.Open(vx_path)
                    vy_ds = gdal.Open(vy_path)
                    
                    vx_array = vx_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
                    vy_array = vy_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
                    
                    # Handle NoData values
                    vx_nodata = vx_ds.GetRasterBand(1).GetNoDataValue()
                    vy_nodata = vy_ds.GetRasterBand(1).GetNoDataValue()
                    
                    if vx_nodata is not None:
                        vx_array[vx_array == vx_nodata] = 0.0
                    if vy_nodata is not None:
                        vy_array[vy_array == vy_nodata] = 0.0
                    
                    # Debug velocity statistics
                    valid_vx = vx_array[np.isfinite(vx_array)]
                    valid_vy = vy_array[np.isfinite(vy_array)]
                    
                    if len(valid_vx) > 0 and len(valid_vy) > 0:
                        vx_stats = f"min: {np.min(valid_vx):.3f}, max: {np.max(valid_vx):.3f}, mean: {np.mean(valid_vx):.3f}"
                        vy_stats = f"min: {np.min(valid_vy):.3f}, max: {np.max(valid_vy):.3f}, mean: {np.mean(valid_vy):.3f}"
                        logger.info(f"Saint-Venant Velocity X: {vx_stats}")
                        logger.info(f"Saint-Venant Velocity Y: {vy_stats}")
                        
                        # Calculate velocity magnitude for debugging
                        vel_mag_sv = np.sqrt(vx_array**2 + vy_array**2)
                        valid_vel_mag = vel_mag_sv[np.isfinite(vel_mag_sv)]
                        
                        if len(valid_vel_mag) > 0:
                            vel_mag_stats = f"min: {np.min(valid_vel_mag):.3f}, max: {np.max(valid_vel_mag):.3f}, mean: {np.mean(valid_vel_mag):.3f}"
                            logger.info(f"Saint-Venant Velocity magnitude: {vel_mag_stats}")
                            logger.info(f"Cells with velocity > 0.001: {np.sum(vel_mag_sv > 0.001)}")
                            logger.info(f"Cells with velocity > 0.01: {np.sum(vel_mag_sv > 0.01)}")
                            logger.info(f"Cells with velocity > 0.1: {np.sum(vel_mag_sv > 0.1)}")
                            
                            saint_venant_results = {
                                'velocity_x': vx_array,
                                'velocity_y': vy_array
                            }
                            logger.info("🎉 SUCCESS: Loaded Saint-Venant 2D velocity field for flow points!")
                            logger.info("🚀 This means flow points will use REAL 2D Saint-Venant velocities, not approximations!")
                        else:
                            logger.warning("Saint-Venant velocity arrays contain no valid data")
                    else:
                        logger.warning("Saint-Venant velocity arrays are empty or invalid")
                else:
                    logger.warning(f"Saint-Venant velocity files not found: {vx_path}, {vy_path}")
            else:
                logger.warning("No Saint-Venant velocity component files found")
                logger.info("Available files in output folder:")
                for f in os.listdir(output_folder):
                    if 'velocity' in f.lower():
                        logger.info(f"  - {f}")
        except Exception as e:
            logger.warning(f"Could not load Saint-Venant velocity data: {e}")
            
    # Step 6: Calculate the velocity field
    logger.info("Calculating velocity field")
    
    # Apply Manning's roughness if available
    manning_n = 0.035  # Default value
    
    # If flow_q provided, adjust calculations
    if flow_q is not None:
        logger.info(f"Using flow rate Q = {flow_q} m³/s for velocity calculation")
        
        # Scale Manning's coefficient based on flow rate for more realistic velocities
        if flow_q > 100:
            manning_n = 0.03  # Lower roughness for larger flows (more efficient flow)
        elif flow_q < 10:
            manning_n = 0.04  # Higher roughness for smaller flows
    
    # Calculate velocity field
    velocity_x, velocity_y, velocity_mag = flow_generator.calculate_velocity_field(
        manning_n=manning_n, method=method, saint_venant_results=saint_venant_results
    )
    
    logger.info(f"Velocity field calculated:")
    logger.info(f"  - Max velocity: {np.nanmax(velocity_mag):.3f} m/s")
    logger.info(f"  - Min velocity: {np.nanmin(velocity_mag):.3f} m/s")
    logger.info(f"  - Mean velocity: {np.nanmean(velocity_mag):.3f} m/s")
    logger.info(f"  - Cells with velocity > 0: {np.sum(velocity_mag > 0)}")
    logger.info(f"  - Cells with velocity > 0.001: {np.sum(velocity_mag > 0.001)}")
    
    # Step 7: Generate flow points
    logger.info("Generating flow visualization points")
    flow_points = flow_generator.generate_flow_points(flood_mask=flood_mask)
    
    # Step 8: Save flow points to shapefile
    if flow_points:
        logger.info(f"Saving {len(flow_points)} flow points to shapefile")
        
        # Use DEM's CRS if available
        dem_crs = None
        if projection:
            try:
                dem_crs = QgsCoordinateReferenceSystem()
                dem_crs.createFromWkt(projection)
                logger.info(f"Using DEM CRS: {dem_crs.authid()}")
            except Exception as e:
                logger.warning(f"Could not create CRS from DEM projection: {e}")
                dem_crs = None
        
        points_layer = flow_generator.save_flow_points_shapefile(flow_points, output_path, crs=dem_crs)
        
        if points_layer:
            logger.info("Flow points created successfully")
            return points_layer
        else:
            logger.error(f"Could not create flow points layer")
            raise Exception(f"Could not create flow points layer")
    else:
        logger.warning("No flow points were generated")
        return None
