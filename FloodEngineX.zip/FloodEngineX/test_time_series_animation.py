#!/usr/bin/env python3
"""
Test Time Series Animation Integration
-------------------------------------
Tests the time series animation system with simulated flood data.
"""

import os
import sys
import numpy as np
import logging
from pathlib import Path

# Add the FloodEngineX directory to the path
sys.path.insert(0, str(Path(__file__).parent))

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def create_test_flood_data():
    """Create simulated flood data for testing animation."""
    logger.info("🌊 Creating test flood data...")
    
    # Create a simple 50x50 grid
    grid_size = 50
    
    # Create DEM (gentle slope from top-left to bottom-right)
    dem_array = np.zeros((grid_size, grid_size))
    for i in range(grid_size):
        for j in range(grid_size):
            dem_array[i, j] = 100 + 0.02 * i + 0.01 * j  # Gentle slope
    
    # Add a river channel (lower elevation)
    channel_i = grid_size // 2
    for j in range(grid_size):
        dem_array[channel_i-1:channel_i+2, j] -= 2.0  # 2m deep channel
    
    # Create geotransform (1m pixel size, starting at 0,0)
    geotransform = (0, 1, 0, grid_size, 0, -1)
    
    # Create time series (simulate flood wave)
    num_timesteps = 20
    total_time = 100.0  # 100 seconds
    timestamps = np.linspace(0, total_time, num_timesteps)
    
    water_depths = []
    velocity_x = []
    velocity_y = []
    
    for i, t in enumerate(timestamps):
        # Simulate spreading flood
        depth = np.zeros((grid_size, grid_size))
        vel_x = np.zeros((grid_size, grid_size))
        vel_y = np.zeros((grid_size, grid_size))
        
        # Flood starts in channel and spreads
        flood_progress = min(1.0, t / 60.0)  # Reaches full extent at 60s
        max_depth = 1.0 + 2.0 * np.sin(t * 0.1)  # Varying depth (flood wave)
        
        # Channel flooding
        channel_depth = max_depth * flood_progress
        depth[channel_i-1:channel_i+2, :] = channel_depth
        
        # Spreading to adjacent areas
        spread_distance = int(flood_progress * 10)  # Up to 10 cells from channel
        for offset in range(1, spread_distance + 1):
            spread_depth = channel_depth * np.exp(-offset * 0.3)  # Exponential decay
            
            # Spread up and down from channel
            if channel_i - offset >= 0:
                depth[channel_i - offset, :] = np.maximum(depth[channel_i - offset, :], spread_depth)
            if channel_i + offset < grid_size:
                depth[channel_i + offset, :] = np.maximum(depth[channel_i + offset, :], spread_depth)
        
        # Add some velocity (flow along channel and outward)
        for j in range(grid_size):
            # Along-channel velocity
            if depth[channel_i, j] > 0.01:
                vel_x[channel_i-1:channel_i+2, j] = 2.0 * np.sqrt(depth[channel_i, j])
            
            # Cross-channel velocity (spreading)
            for di in range(-spread_distance, spread_distance + 1):
                ii = channel_i + di
                if 0 <= ii < grid_size and depth[ii, j] > 0.01:
                    if di != 0:
                        vel_y[ii, j] = 0.5 * np.sign(di) * np.sqrt(depth[ii, j])
        
        # Apply velocity limits (realistic flood velocities)
        vel_mag = np.sqrt(vel_x**2 + vel_y**2)
        over_limit = vel_mag > 3.0
        if np.any(over_limit):
            scale = 3.0 / vel_mag[over_limit]
            vel_x[over_limit] *= scale
            vel_y[over_limit] *= scale
        
        water_depths.append(depth)
        velocity_x.append(vel_x)
        velocity_y.append(vel_y)
    
    # Create results dictionary
    results = {
        'times': timestamps.tolist(),
        'water_depths': water_depths,
        'velocity_x': velocity_x,
        'velocity_y': velocity_y,
        'dem_array': dem_array,
        'geotransform': geotransform,
        'final_water_depth': water_depths[-1],
        'final_velocity_x': velocity_x[-1],
        'final_velocity_y': velocity_y[-1],
        'final_velocity_magnitude': np.sqrt(velocity_x[-1]**2 + velocity_y[-1]**2),
        'water_surface_elevation': dem_array + water_depths[-1]
    }
    
    logger.info(f"✅ Created test data: {len(timestamps)} timesteps, {grid_size}x{grid_size} grid")
    return results

def test_time_series_integration():
    """Test the time series integration system."""
    logger.info("🧪 Testing time series animation integration...")
    
    try:
        # Create test data
        results_data = create_test_flood_data()
        
        # Set up output folder
        output_folder = os.path.join(os.getcwd(), 'test_time_series_output')
        
        # Test the integration
        from time_series_integration import integrate_time_series_animation
        
        animation_result = integrate_time_series_animation(results_data, output_folder)
        
        if animation_result['success']:
            logger.info("✅ Time series integration test PASSED!")
            logger.info(f"📁 Output folder: {animation_result['output_folder']}")
            logger.info(f"📊 Timesteps: {animation_result['num_timesteps']}")
            logger.info(f"📖 Instructions: {animation_result['instructions_file']}")
            
            # Check created files
            raster_folder = os.path.join(output_folder, 'rasters')
            if os.path.exists(raster_folder):
                raster_files = [f for f in os.listdir(raster_folder) if f.endswith('.tif')]
                logger.info(f"📊 Created {len(raster_files)} raster files")
                
                # Show some example files
                for i, filename in enumerate(raster_files[:5]):
                    logger.info(f"  • {filename}")
                if len(raster_files) > 5:
                    logger.info(f"  • ... and {len(raster_files) - 5} more files")
            
            return True
        else:
            logger.error(f"❌ Integration test FAILED: {animation_result.get('error', 'Unknown error')}")
            return False
            
    except Exception as e:
        logger.error(f"❌ Test failed with exception: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_coordinate_transformations():
    """Test coordinate system transformations."""
    logger.info("🗺️ Testing coordinate transformations...")
    
    try:
        # Test some coordinate conversions
        test_points = [
            (0, 0),           # Origin
            (100, 100),       # Center area
            (50, 25),         # Random point
        ]
        
        # Simple geotransform for testing
        geotransform = (0, 1, 0, 100, 0, -1)  # 1m pixels, origin at (0,100)
        
        for map_x, map_y in test_points:
            # Convert to pixel coordinates
            pixel_x = int((map_x - geotransform[0]) / geotransform[1])
            pixel_y = int((map_y - geotransform[3]) / geotransform[5])
            
            # Convert back to map coordinates  
            back_x = geotransform[0] + pixel_x * geotransform[1]
            back_y = geotransform[3] + pixel_y * geotransform[5]
            
            logger.info(f"Map ({map_x}, {map_y}) → Pixel ({pixel_x}, {pixel_y}) → Map ({back_x}, {back_y})")
            
            # Check conversion accuracy
            if abs(back_x - map_x) > 0.001 or abs(back_y - map_y) > 0.001:
                logger.warning(f"⚠️ Coordinate conversion inaccuracy detected")
        
        logger.info("✅ Coordinate transformation test completed")
        return True
        
    except Exception as e:
        logger.error(f"❌ Coordinate test failed: {e}")
        return False

def demonstrate_usage():
    """Demonstrate how to use the time series animation system."""
    logger.info("📖 Demonstrating time series animation usage...")
    
    print("\n" + "="*60)
    print("TIME SERIES ANIMATION SYSTEM DEMONSTRATION")
    print("="*60)
    
    print("\n1. 🌊 FLOOD SIMULATION WITH ANIMATION")
    print("   When you run a Saint-Venant simulation, the system will:")
    print("   • Automatically detect time series data")
    print("   • Create raster files for each timestep")
    print("   • Set up QGIS animation controls (if available)")
    print("   • Generate usage instructions")
    
    print("\n2. 📁 OUTPUT STRUCTURE")
    print("   Your output folder will contain:")
    print("   • rasters/ - Individual GeoTIFF files for each timestep")
    print("   • animations/ - Space for exported animation frames")
    print("   • exports/ - Space for data exports")
    print("   • ANIMATION_INSTRUCTIONS.md - Detailed usage guide")
    
    print("\n3. 🎮 ANIMATION CONTROLS")
    print("   In QGIS, you'll get a control panel with:")
    print("   • ▶️ Play/Pause buttons")
    print("   • Timeline slider for navigation")
    print("   • Speed control (0.1-10 fps)")
    print("   • Point sampling for interactive data viewing")
    
    print("\n4. 🎯 INTERACTIVE FEATURES")
    print("   Click anywhere on the map to see:")
    print("   • Water depth at that location")
    print("   • Surface elevation in RH2000 coordinates")
    print("   • Flow velocity (if available)")
    print("   • Complete time series for that point")
    
    print("\n5. 📊 DATA FORMATS")
    print("   • Depths: meters above ground")
    print("   • Elevations: meters above RH2000 datum")
    print("   • Velocities: meters per second")
    print("   • Times: seconds from simulation start")
    
    print("\n6. 🔧 INTEGRATION")
    print("   To use in your code:")
    print("   ```python")
    print("   from saint_venant_2d import simulate_saint_venant_2d")
    print("   ")
    print("   # Run simulation (animation setup is automatic)")
    print("   results = simulate_saint_venant_2d(")
    print("       dem_path='your_dem.tif',")
    print("       water_level=105.0,")
    print("       output_folder='output/',")
    print("       total_time=3600")
    print("   )")
    print("   ")
    print("   # Animation files will be in output/time_series_animation/")
    print("   ```")
    
    print("\n" + "="*60)
    print("Ready to create flood animations! 🎬")
    print("="*60)

if __name__ == "__main__":
    logger.info("🚀 Starting time series animation tests...")
    
    success = True
    
    # Test coordinate transformations
    if not test_coordinate_transformations():
        success = False
    
    # Test time series integration
    if not test_time_series_integration():
        success = False
    
    # Demonstrate usage
    demonstrate_usage()
    
    if success:
        logger.info("🎉 ALL TESTS PASSED: Time series animation system is ready!")
        print("\n✅ Time series animation system successfully tested!")
        print("📁 Check 'test_time_series_output' folder for example files")
        print("📖 Read ANIMATION_INSTRUCTIONS.md for detailed usage")
    else:
        logger.error("❌ SOME TESTS FAILED: Please check the implementation")
        sys.exit(1)
