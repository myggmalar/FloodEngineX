#!/usr/bin/env python3
"""Test the complete simulation flow to debug animation issues."""

import sys
import os
import tempfile
import shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Test if we can trace the full simulation flow
def test_simulation_flow():
    """Test the full simulation flow to find where animation fails."""
    print("🔍 Starting simulation flow test...")
    
    # Check if basic imports work
    try:
        from model_hydraulic import calculate_flood_area
        print("✅ model_hydraulic import successful")
    except Exception as e:
        print(f"❌ model_hydraulic import failed: {e}")
        return False
    
    try:
        from launch_animation import launch_animation_from_folder
        print("✅ launch_animation import successful")
    except Exception as e:
        print(f"❌ launch_animation import failed: {e}")
        return False
    
    # Create temporary test folders
    temp_dir = tempfile.mkdtemp()
    output_folder = os.path.join(temp_dir, "test_output")
    os.makedirs(output_folder, exist_ok=True)
    
    try:
        # Test creating animation folder structure (simulating what saint_venant_2d should do)
        animation_folder = os.path.join(output_folder, 'time_series_animation')
        os.makedirs(animation_folder, exist_ok=True)
        
        # Create a test file to simulate animation data
        test_file = os.path.join(animation_folder, "test_data.txt")
        with open(test_file, 'w') as f:
            f.write("Test animation data")
        
        print(f"📁 Created test animation folder: {animation_folder}")
        print(f"📄 Test file exists: {os.path.exists(test_file)}")
        
        # Test animation folder detection (from launch_animation_controls logic)
        if os.path.exists(os.path.join(output_folder, 'time_series_animation')):
            detected_folder = os.path.join(output_folder, 'time_series_animation')
            print(f"✅ Animation folder detected: {detected_folder}")
        elif os.path.exists(os.path.join(output_folder, 'rasters')):
            detected_folder = output_folder
            print(f"✅ Raster folder detected: {detected_folder}")
        else:
            print("❌ No animation data folder detected")
            return False
        
        # Test launching animation (standalone mode)
        print("🎬 Testing animation launch...")
        try:
            result = launch_animation_from_folder(detected_folder, standalone=True)
            print(f"🎬 Animation launch result: {result}")
            return True
        except Exception as e:
            print(f"❌ Animation launch failed: {e}")
            import traceback
            traceback.print_exc()
            return False
            
    finally:
        # Clean up
        try:
            shutil.rmtree(temp_dir)
            print(f"🧹 Cleaned up temp directory: {temp_dir}")
        except:
            pass

if __name__ == "__main__":
    success = test_simulation_flow()
    print(f"\n{'✅ Test PASSED' if success else '❌ Test FAILED'}")
