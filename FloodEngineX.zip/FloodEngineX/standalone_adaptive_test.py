#!/usr/bin/env python3
"""
Standalone Adaptive Threshold Test - Extract and test the core algorithm without GDAL
This test extracts just the adaptive threshold logic from model_hydraulic.py
"""

import numpy as np
from collections import deque
import time

def create_proper_flow_flood_mask_standalone(dem_array, water_level, valid_mask):
    """
    Standalone version of the adaptive threshold flood mask function
    This is extracted directly from model_hydraulic.py but without GDAL dependencies
    """
    print(f"🔧 CORRECTED ALGORITHM: Water flows from HIGH to LOW elevations")
    
    # Find all areas that CAN be flooded (below water level)
    floodable_mask = valid_mask & (dem_array < water_level)
    
    if not np.any(floodable_mask):
        print("❌ No areas can be flooded at this water level")
        return np.zeros_like(dem_array, dtype=np.uint8)
    
    # Get elevation statistics
    floodable_elevations = dem_array[floodable_mask]
    min_elev = np.min(floodable_elevations)
    max_elev = np.max(floodable_elevations)
    
    print(f"📊 Floodable elevation range: {min_elev:.2f}m to {max_elev:.2f}m")
    print(f"📊 Water level: {water_level:.2f}m")
    
    # CRITICAL FIX: Start from HIGHEST floodable points (not lowest!)
    # This simulates water entering from upstream/upslope areas
    # IMPROVED: Use adaptive percentile threshold for better intermediate water level coverage
    
    # Initialize flood tracking
    flooded = np.zeros_like(dem_array, dtype=bool)
    start_points = []
    
    # Try multiple percentile thresholds until we find adequate start points
    percentile_thresholds = [80, 70, 60, 50]  # From restrictive to permissive
    
    for percentile in percentile_thresholds:
        starting_threshold = np.percentile(floodable_elevations, percentile)
        start_candidates = np.where(floodable_mask & (dem_array >= starting_threshold))
        potential_start_points = list(zip(start_candidates[0], start_candidates[1]))
        
        # Use this threshold if we get adequate start points (at least 5, or any for high percentiles)
        if len(potential_start_points) >= 5 or (percentile >= 80 and len(potential_start_points) > 0):
            start_points = potential_start_points
            print(f"🎯 Using {percentile}th percentile threshold: {starting_threshold:.2f}m ({len(start_points)} start points)")
            break
        elif len(potential_start_points) > 0:
            # Keep this as backup but try more permissive thresholds
            start_points = potential_start_points
            starting_threshold_backup = starting_threshold
    
    # Final fallback: use the single highest floodable point
    if not start_points:
        highest_idx = np.unravel_index(np.argmax(dem_array * floodable_mask), dem_array.shape)
        start_points = [highest_idx]
        print(f"🔄 Fallback: Using single highest point at {dem_array[highest_idx]:.2f}m")
    
    print(f"🚀 Starting flood from {len(start_points)} high points")
    
    # Initialize BFS queue with starting points
    queue = deque()
    
    for row, col in start_points:
        flooded[row, col] = True
        queue.append((row, col))
    
    # 8-directional neighbors (including diagonals for better flow)
    directions = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]
    
    # Propagate flood DOWNHILL
    iteration = 0
    max_iterations = 100000
    
    while queue and iteration < max_iterations:
        current_row, current_col = queue.popleft()
        current_elevation = dem_array[current_row, current_col]
        iteration += 1
        
        # Check all 8 neighbors
        for dr, dc in directions:
            new_row, new_col = current_row + dr, current_col + dc
            
            # Boundary checks
            if (new_row < 0 or new_row >= dem_array.shape[0] or 
                new_col < 0 or new_col >= dem_array.shape[1]):
                continue
            
            # Skip if already processed
            if flooded[new_row, new_col] or not valid_mask[new_row, new_col]:
                continue
            
            neighbor_elevation = dem_array[new_row, new_col]
            
            # WATER FLOWS DOWNHILL: Only flood if neighbor is:
            # 1. Lower than or equal to current elevation (downhill/level flow)
            # 2. Below the water level (can be flooded)
            if (neighbor_elevation <= current_elevation and 
                neighbor_elevation < water_level):
                
                flooded[new_row, new_col] = True
                queue.append((new_row, new_col))
    
    # Convert to uint8 for GDAL compatibility
    flood_mask = flooded.astype(np.uint8)
    
    total_flooded = np.sum(flood_mask)
    print(f"✅ CORRECTED FLOW complete: {total_flooded} cells flooded in {iteration} iterations")
    
    # FALLBACK MECHANISM: If flow algorithm produces zero results, use bathtub model
    if total_flooded == 0:
        print("⚠️ Flow algorithm produced zero flooding - applying BATHTUB FALLBACK for intermediate water levels")
        
        # Simple bathtub model as fallback
        bathtub_mask = valid_mask & (dem_array < water_level)
        bathtub_flooded = np.sum(bathtub_mask)
        
        if bathtub_flooded > 0:
            print(f"🔄 Bathtub fallback: {bathtub_flooded} cells would be flooded")
            
            # Only use bathtub if it's reasonable (not the entire DEM)
            total_valid_cells = np.sum(valid_mask)
            flood_percentage = (bathtub_flooded / total_valid_cells) * 100
            
            if flood_percentage < 50:  # Less than 50% of DEM flooded
                flood_mask = bathtub_mask.astype(np.uint8)
                total_flooded = bathtub_flooded
                print(f"✅ Using bathtub fallback: {total_flooded} cells flooded ({flood_percentage:.1f}% of DEM)")
            else:
                print(f"❌ Bathtub fallback rejected: would flood {flood_percentage:.1f}% of DEM (too much)")
    
    # Validation check
    if total_flooded > 0:
        flooded_elevations = dem_array[flood_mask == 1]
        print(f"📊 Flooded elevation range: {np.min(flooded_elevations):.2f}m to {np.max(flooded_elevations):.2f}m")
        
        # Check for any invalid flooding (above water level)
        invalid_flood = np.sum(flooded_elevations >= water_level)
        if invalid_flood > 0:
            print(f"⚠️ WARNING: {invalid_flood} cells flooded above water level!")
        else:
            print(f"✅ All flooded areas are correctly below water level")
    
    return flood_mask


def test_adaptive_threshold_fixes():
    """
    Test the adaptive threshold and bathtub fallback fixes
    """
    print("=" * 80)
    print("🧪 TESTING ADAPTIVE THRESHOLD FIXES FOR INTERMEDIATE TIMESTEP LAYERS")
    print("=" * 80)
    
    # Create a realistic DEM for testing
    rows, cols = 80, 80
    dem = np.zeros((rows, cols), dtype=np.float32)
    
    # Create a river valley scenario with intermediate elevation zones
    for i in range(rows):
        for j in range(cols):
            # Distance from center line (river)
            dist_to_river = abs(i - rows//2) 
            # Distance from sides
            dist_to_sides = min(j, cols - j - 1)
            
            # Create valley profile: deeper in center, higher on sides
            valley_depth = max(0, 8 - dist_to_river * 0.4)
            side_elevation = dist_to_sides * 0.1
            
            base_elevation = 42.0 - valley_depth + side_elevation
            
            # Add realistic terrain noise
            noise = np.random.normal(0, 0.2)
            dem[i, j] = base_elevation + noise
    
    # Ensure elevation range is realistic
    dem = np.clip(dem, 35, 48)
    valid_mask = np.ones_like(dem, dtype=bool)
    
    print(f"📊 Test DEM created: {dem.shape}")
    print(f"📊 Elevation range: {dem.min():.2f}m to {dem.max():.2f}m")
    print(f"📊 Mean elevation: {dem.mean():.2f}m")
    
    # Test critical intermediate water levels that historically caused empty layers
    test_levels = [
        36.0,  # Very low - should trigger most adaptive mechanisms
        37.5,  # Low-intermediate
        39.0,  # Medium-low
        40.5,  # Medium
        42.0,  # Medium-high
        43.5,  # High
        45.0,  # Very high
    ]
    
    print(f"\n🌊 Testing {len(test_levels)} water levels...")
    print("-" * 80)
    
    successful_tests = 0
    failed_tests = 0
    results = []
    
    for water_level in test_levels:
        print(f"\n💧 TESTING WATER LEVEL: {water_level:.1f}m")
        print("─" * 50)
        
        start_time = time.time()
        
        try:
            flood_mask = create_proper_flow_flood_mask_standalone(dem, water_level, valid_mask)
            
            flooded_cells = np.sum(flood_mask > 0)
            total_cells = np.sum(valid_mask)
            flood_percentage = (flooded_cells / total_cells) * 100
            elapsed_time = time.time() - start_time
            
            if flooded_cells > 0:
                print(f"✅ SUCCESS: {flooded_cells} cells flooded ({flood_percentage:.1f}%) in {elapsed_time:.3f}s")
                successful_tests += 1
                
                # Additional validation
                flooded_elevations = dem[flood_mask > 0]
                elevation_range = np.max(flooded_elevations) - np.min(flooded_elevations)
                print(f"📊 Flooded elevation span: {elevation_range:.2f}m")
                
                results.append({
                    'water_level': water_level,
                    'success': True,
                    'flooded_cells': flooded_cells,
                    'percentage': flood_percentage,
                    'time': elapsed_time,
                    'elevation_range': elevation_range
                })
            else:
                print(f"❌ FAILED: No flooding detected at {water_level:.1f}m")
                failed_tests += 1
                results.append({
                    'water_level': water_level,
                    'success': False,
                    'flooded_cells': 0,
                    'percentage': 0,
                    'time': elapsed_time
                })
                
        except Exception as e:
            elapsed_time = time.time() - start_time
            print(f"💥 ERROR: {str(e)}")
            failed_tests += 1
            results.append({
                'water_level': water_level,
                'success': False,
                'error': str(e),
                'time': elapsed_time
            })
    
    # Summary
    print("\n" + "=" * 80)
    print("📊 TEST RESULTS SUMMARY")
    print("=" * 80)
    
    print(f"✅ Successful tests: {successful_tests}/{len(test_levels)} ({successful_tests/len(test_levels)*100:.1f}%)")
    print(f"❌ Failed tests: {failed_tests}/{len(test_levels)} ({failed_tests/len(test_levels)*100:.1f}%)")
    
    # Analysis
    if successful_tests == len(test_levels):
        print("\n🎉 PERFECT RESULTS!")
        print("✅ All intermediate water levels produce flooding")
        print("✅ Adaptive threshold fixes are working perfectly")
        print("✅ Critical timestep simulation issue is RESOLVED!")
        
    elif successful_tests >= len(test_levels) * 0.8:  # 80% success rate
        print("\n🟢 EXCELLENT RESULTS!")
        print("✅ Most intermediate water levels produce flooding")
        print("✅ Adaptive threshold fixes are working well")
        print("✅ Critical timestep simulation issue is largely RESOLVED!")
        
    elif successful_tests >= len(test_levels) * 0.6:  # 60% success rate
        print("\n🟡 GOOD RESULTS!")
        print("⚠️ Majority of water levels working, but some issues remain")
        print("✅ Adaptive threshold fixes show significant improvement")
        
    else:
        print("\n🔴 POOR RESULTS!")
        print("❌ Significant issues remain with intermediate water levels")
        print("🔧 Additional fixes may be needed")
    
    # Detailed failure analysis
    failed_levels = [r['water_level'] for r in results if not r['success']]
    if failed_levels:
        print(f"\n🚨 Failed water levels: {failed_levels}")
        
        # Check if failures are clustered in specific ranges
        low_failures = [wl for wl in failed_levels if wl < 38]
        mid_failures = [wl for wl in failed_levels if 38 <= wl <= 42]
        high_failures = [wl for wl in failed_levels if wl > 42]
        
        if low_failures:
            print(f"   📉 Low water level failures: {low_failures}")
        if mid_failures:
            print(f"   📊 Mid water level failures: {mid_failures}")
        if high_failures:
            print(f"   📈 High water level failures: {high_failures}")
    
    # Performance analysis
    successful_results = [r for r in results if r['success']]
    if successful_results:
        avg_time = np.mean([r['time'] for r in successful_results])
        avg_percentage = np.mean([r['percentage'] for r in successful_results])
        print(f"\n⏱️ Performance: Average {avg_time:.3f}s per test")
        print(f"📊 Coverage: Average {avg_percentage:.1f}% of DEM flooded")
    
    print(f"\n{'='*80}")
    
    return successful_tests == len(test_levels)


if __name__ == "__main__":
    # Run the comprehensive test
    success = test_adaptive_threshold_fixes()
    
    if success:
        print("🎯 CONCLUSION: Adaptive threshold fixes are working correctly!")
        print("✅ The critical timestep simulation issue has been resolved.")
    else:
        print("🔧 CONCLUSION: Some issues remain but significant progress made.")
        print("📝 Review failed cases and consider additional refinements.")
