#!/usr/bin/env python3
"""
Simple Animation Test - Launch animation dialog directly
"""

import sys
import os
from pathlib import Path

# Add current directory to path
sys.path.insert(0, str(Path(__file__).parent))

def force_launch_animation():
    """Force launch animation dialog to verify it works."""
    print("🎬 FORCING ANIMATION DIALOG LAUNCH")
    print("=" * 40)
    
    try:
        from PyQt5.QtWidgets import QApplication
        from time_series_animator import TimeSeriesAnimator
        import numpy as np
        
        # Create QApplication
        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)
            print("📱 Created QApplication")
        
        # Create minimal test data
        test_data = {
            'times': [0, 10, 20, 30, 40, 50],
            'water_depths': [np.zeros((50, 50)) for _ in range(6)],
            'geotransform': (0, 1, 0, 50, 0, -1),
            'projection': ''
        }
        
        # Create animation dialog
        animator = TimeSeriesAnimator(test_data, "test_output")
        animator.setWindowTitle("FloodEngine - Animation Test")
        animator.show()
        animator.raise_()
        animator.activateWindow()
        
        print("✅ Animation dialog created and shown!")
        print("🎮 You should see the animation controls window now!")
        print("   - Play/Pause buttons")
        print("   - Timeline slider") 
        print("   - Speed controls")
        print("   - Time display")
        
        # Store reference to prevent garbage collection
        app._test_animator = animator
        
        # Keep alive for 10 seconds for testing
        from PyQt5.QtCore import QTimer
        def close_test():
            print("⏰ Test timer finished - closing dialog")
            animator.close()
            app.quit()
        
        timer = QTimer()
        timer.timeout.connect(close_test)
        timer.start(10000)  # 10 seconds
        
        print("⏰ Dialog will auto-close in 10 seconds...")
        return app.exec_()
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        print("💡 Make sure PyQt5 is installed: pip install PyQt5")
        return 1
    except Exception as e:
        print(f"❌ Failed to launch animation: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(force_launch_animation())
