"""
Complete solution to force fixed flow direction and eliminate bathtub filling
This module provides a replacement for the problematic calculate_flood_area function
"""

import os
import numpy as np
from collections import deque

def calculate_flood_area_ALWAYS_FIXED(iface, dem_path, water_level, bathymetry=None, 
                                     output_folder=None, flow_q=None, threshold=None, 
                                     stream_path=None, use_fixed_flow=True):
    """
    MODIFIED VERSION: Always use the fixed flow algorithm
    No fallback to bathtub filling!
    """
    
    # FORCE the use of fixed flow algorithm
    try:
        from flow_direction_flood_fixed import calculate_flood_area_with_flow_direction_FIXED
        
        if flow_q is not None and flow_q > 0:
            print(f"🔧 FORCING FIXED FLOW-BASED model: Q={flow_q} m³/s")
            if hasattr(iface, 'messageBar'):
                iface.messageBar().pushInfo("FloodEngine", 
                                          f"FORCED FIXED flow model (Q={flow_q}) - water flows from HIGH to LOW")
        else:
            print(f"🔧 FORCING FIXED WATER LEVEL model: {water_level}m")
            if hasattr(iface, 'messageBar'):
                iface.messageBar().pushInfo("FloodEngine", 
                                          f"FORCED FIXED water level model ({water_level}m)")
        
        # ALWAYS call the fixed version
        return calculate_flood_area_with_flow_direction_FIXED(
            iface, dem_path, water_level, bathymetry, 
            output_folder, flow_q, threshold, stream_path
        )
        
    except ImportError as e:
        # If fixed module is not available, create a simple directional algorithm
        print(f"❌ Fixed module not available: {e}")
        print("🔧 Creating simple high-to-low flow algorithm...")
        
        return create_simple_high_to_low_flood(
            iface, dem_path, water_level, flow_q, output_folder
        )

def create_simple_high_to_low_flood(iface, dem_path, water_level, flow_q, output_folder):
    """
    Simple implementation that flows from high to low points
    Alternative when the fixed module is not available
    """
    try:
        from osgeo import gdal, ogr
        from qgis.core import QgsVectorLayer, QgsProject
    except ImportError:
        print("❌ GDAL/QGIS not available - using mock implementation")
        return None
    
    print("🔧 Using simple high-to-low flooding algorithm")
    
    # Load DEM
    dem_ds = gdal.Open(dem_path)
    if not dem_ds:
        print(f"❌ Cannot open DEM: {dem_path}")
        return None
        
    dem_array = dem_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
    geotransform = dem_ds.GetGeoTransform()
    projection = dem_ds.GetProjection()
    nodata = dem_ds.GetRasterBand(1).GetNoDataValue() or -9999
    
    # Replace nodata with NaN
    dem_array[dem_array == nodata] = np.nan
    valid_mask = ~np.isnan(dem_array)
    
    print(f"DEM range: {np.nanmin(dem_array):.2f} to {np.nanmax(dem_array):.2f}m")
    print(f"Water level: {water_level}m")
    
    # Initialize flood mask
    flooded = np.zeros_like(dem_array, dtype=bool)
    
    # STEP 1: Find starting points (highest elevations that can be flooded)
    floodable_mask = valid_mask & (dem_array < water_level)
    
    if not np.any(floodable_mask):
        print("❌ No areas can be flooded at this water level")
        return None
    
    # Find the highest points that can be flooded
    floodable_elevations = dem_array[floodable_mask]
    # Start from 95th percentile of floodable elevations
    start_threshold = np.percentile(floodable_elevations, 95)
    
    start_points = []
    rows, cols = np.where(floodable_mask & (dem_array >= start_threshold))
    
    for i in range(min(50, len(rows))):  # Limit to 50 starting points
        start_points.append((rows[i], cols[i]))
    
    print(f"Starting flood from {len(start_points)} high points at elevation ≥ {start_threshold:.2f}m")
    
    # STEP 2: Flood propagation from high to low
    # Use a queue-based approach to spread water from high to low
    queue = deque()
    
    # Initialize starting points
    for row, col in start_points:
        if not flooded[row, col]:
            flooded[row, col] = True
            queue.append((row, col))
    
    print(f"Initial flooded cells: {np.sum(flooded)}")
    
    # Propagate flooding
    directions = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]
    max_iterations = 10000
    iteration = 0
    
    while queue and iteration < max_iterations:
        iteration += 1
        current_row, current_col = queue.popleft()
        current_elevation = dem_array[current_row, current_col]
        current_water_level = water_level  # Simplified: constant water level
        
        # Check all 8 neighbors
        for dr, dc in directions:
            new_row, new_col = current_row + dr, current_col + dc
            
            # Check bounds
            if (new_row < 0 or new_row >= dem_array.shape[0] or 
                new_col < 0 or new_col >= dem_array.shape[1]):
                continue
            
            # Skip if already flooded or invalid
            if flooded[new_row, new_col] or not valid_mask[new_row, new_col]:
                continue
            
            neighbor_elevation = dem_array[new_row, new_col]
            
            # Water can only flow to cells that are:
            # 1. Lower or equal elevation
            # 2. Below the water level
            if (neighbor_elevation <= current_elevation and 
                neighbor_elevation < water_level):
                
                flooded[new_row, new_col] = True
                queue.append((new_row, new_col))
        
        # Progress reporting
        if iteration % 1000 == 0:
            current_flooded = np.sum(flooded)
            print(f"Iteration {iteration}: {current_flooded} cells flooded")
    
    final_flooded = np.sum(flooded)
    print(f"✅ Flooding complete: {final_flooded} cells flooded after {iteration} iterations")
    
    # STEP 3: Create output shapefile
    if output_folder is None:
        output_folder = os.path.dirname(dem_path)
    
    output_name = f"HIGH_TO_LOW_flood_{water_level}m"
    if flow_q:
        output_name = f"HIGH_TO_LOW_flood_{water_level}m_q{flow_q}"
    
    shp_path = os.path.join(output_folder, output_name + ".shp")
    
    # Convert to flood mask for polygonization
    flood_mask = flooded.astype(np.uint8)
    
    # Create temporary raster
    mem_driver = gdal.GetDriverByName('MEM')
    flood_ds = mem_driver.Create('', dem_array.shape[1], dem_array.shape[0], 1, gdal.GDT_Byte)
    flood_ds.SetGeoTransform(geotransform)
    flood_ds.SetProjection(projection)
    
    flood_band = flood_ds.GetRasterBand(1)
    flood_band.WriteArray(flood_mask)
    flood_band.SetNoDataValue(0)
    flood_band.FlushCache()
    
    # Create shapefile
    driver = ogr.GetDriverByName('ESRI Shapefile')
    if os.path.exists(shp_path):
        driver.DeleteDataSource(shp_path)
        
    ds = driver.CreateDataSource(shp_path)
    srs = ogr.osr.SpatialReference()
    srs.ImportFromEPSG(3006)
    layer = ds.CreateLayer('flood', srs, ogr.wkbPolygon)
    
    # Add fields
    layer.CreateField(ogr.FieldDefn('water_lvl', ogr.OFTReal))
    layer.CreateField(ogr.FieldDefn('method', ogr.OFTString))
    
    # Polygonize
    gdal.Polygonize(flood_band, flood_band, layer, 0, [])
    
    # Set attributes
    for feature in layer:
        feature.SetField('water_lvl', float(water_level))
        feature.SetField('method', 'HIGH_TO_LOW')
        layer.SetFeature(feature)
    
    # Cleanup
    ds = None
    flood_ds = None
    
    # Load in QGIS
    flood_layer = QgsVectorLayer(shp_path, f"HIGH-TO-LOW Flood {water_level}m", "ogr")
    if flood_layer.isValid():
        # Style with GREEN color to distinguish from other methods
        from qgis.core import QgsFillSymbol, QgsSingleSymbolRenderer
        symbol = QgsFillSymbol.createSimple({
            'color': '0,255,0,128',  # Green with transparency
            'outline_color': '0,200,0,255',
            'outline_width': '0.3'
        })
        renderer = QgsSingleSymbolRenderer(symbol)
        flood_layer.setRenderer(renderer)
        
        QgsProject.instance().addMapLayer(flood_layer)
        print("✅ HIGH-TO-LOW flood layer added to QGIS in GREEN")
        return flood_layer
    else:
        print("❌ Failed to create flood layer")
        return None

def create_directional_flood_mask(dem_array, water_level, start_points=None):
    """
    Create flood mask using directional flow from high to low points
    This replaces the problematic bathtub filling algorithm
    """
    print("🔧 Creating directional flood mask (HIGH to LOW flow)")
    
    # Initialize
    valid_mask = ~np.isnan(dem_array)
    flooded = np.zeros_like(dem_array, dtype=bool)
    
    # Find floodable areas
    floodable_mask = valid_mask & (dem_array < water_level)
    
    if not np.any(floodable_mask):
        print("❌ No areas can be flooded at this water level")
        return flooded
    
    # If no start points provided, find highest floodable points
    if start_points is None:
        floodable_elevations = dem_array[floodable_mask]
        start_threshold = np.percentile(floodable_elevations, 90)  # Top 10% of floodable elevations
        
        start_points = []
        rows, cols = np.where(floodable_mask & (dem_array >= start_threshold))
        
        for i in range(min(100, len(rows))):  # Limit starting points
            start_points.append((rows[i], cols[i]))
    
    print(f"Starting flood propagation from {len(start_points)} high points")
    
    # Queue-based flood propagation
    queue = deque()
    
    # Initialize starting points
    for row, col in start_points:
        if valid_mask[row, col] and dem_array[row, col] < water_level:
            flooded[row, col] = True
            queue.append((row, col))
    
    # 8-directional neighbors
    directions = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]
    
    # Propagate flooding
    iteration = 0
    max_iterations = 50000
    
    while queue and iteration < max_iterations:
        iteration += 1
        current_row, current_col = queue.popleft()
        current_elevation = dem_array[current_row, current_col]
        
        # Check all neighbors
        for dr, dc in directions:
            new_row, new_col = current_row + dr, current_col + dc
            
            # Check bounds
            if (new_row < 0 or new_row >= dem_array.shape[0] or 
                new_col < 0 or new_col >= dem_array.shape[1]):
                continue
            
            # Skip if already processed or invalid
            if flooded[new_row, new_col] or not valid_mask[new_row, new_col]:
                continue
            
            neighbor_elevation = dem_array[new_row, new_col]
            
            # Water flows downhill: neighbor must be lower or equal AND below water level
            if (neighbor_elevation <= current_elevation and 
                neighbor_elevation < water_level):
                
                flooded[new_row, new_col] = True
                queue.append((new_row, new_col))
        
        # Progress reporting
        if iteration % 5000 == 0:
            current_flooded = np.sum(flooded)
            print(f"Flood iteration {iteration}: {current_flooded} cells flooded")
    
    final_flooded = np.sum(flooded)
    print(f"✅ Directional flooding complete: {final_flooded} cells flooded")
    
    return flooded

def check_fixed_flow_status():
    """Check if the fixed flow module is properly loaded"""
    
    print("=== DEBUGGING FIXED FLOW AVAILABILITY ===")
    
    # Check 1: Try to import the fixed flow module
    try:
        from flow_direction_flood_fixed import (
            calculate_flood_area_with_flow_direction_FIXED,
            simulate_hydraulic_flow_FIXED
        )
        print("✅ Fixed flow module import: SUCCESS")
        FIXED_FLOW_AVAILABLE = True
    except ImportError as e:
        print(f"❌ Fixed flow module import: FAILED - {e}")
        FIXED_FLOW_AVAILABLE = False
    
    # Check 2: Print the status
    print(f"FIXED_FLOW_AVAILABLE = {FIXED_FLOW_AVAILABLE}")
    
    # Check 3: Look at model_hydraulic.py to see the current setting
    try:
        import model_hydraulic
        if hasattr(model_hydraulic, 'FIXED_FLOW_AVAILABLE'):
            print(f"model_hydraulic.FIXED_FLOW_AVAILABLE = {model_hydraulic.FIXED_FLOW_AVAILABLE}")
        else:
            print("❌ FIXED_FLOW_AVAILABLE not found in model_hydraulic")
    except Exception as e:
        print(f"❌ Error checking model_hydraulic: {e}")
    
    # Check 4: Verify the UI checkbox setting
    print("\n=== UI SETTINGS CHECK ===")
    print("Make sure in your UI:")
    print("- 'Use fixed flow direction' checkbox is CHECKED")
    print("- use_fixed_flow parameter is True when calling calculate_flood_area")
    
    return FIXED_FLOW_AVAILABLE

def diagnose_flood_algorithm():
    """Diagnose which algorithm is actually being used"""
    
    print("=== FLOODENGINE ALGORITHM DIAGNOSIS ===")
    
    # Check 1: Module availability
    print("\n1. Checking module availability:")
    try:
        import model_hydraulic
        print("✅ model_hydraulic imported")
        
        # Check if FIXED_FLOW_AVAILABLE is set
        if hasattr(model_hydraulic, 'FIXED_FLOW_AVAILABLE'):
            status = model_hydraulic.FIXED_FLOW_AVAILABLE
            print(f"   FIXED_FLOW_AVAILABLE = {status}")
            if not status:
                print("   ❌ PROBLEM: Fixed flow is disabled!")
        else:
            print("   ❌ PROBLEM: FIXED_FLOW_AVAILABLE not found in model_hydraulic")
            
    except ImportError as e:
        print(f"❌ Cannot import model_hydraulic: {e}")
        return
    
    # Check 2: Fixed flow module
    print("\n2. Checking fixed flow module:")
    try:
        from flow_direction_flood_fixed import calculate_flood_area_with_flow_direction_FIXED
        print("✅ Fixed flow module available")
    except ImportError as e:
        print(f"❌ PROBLEM: Cannot import fixed flow module: {e}")
        print("   This means FIXED_FLOW_AVAILABLE should be False")
    
    # Check 3: Look for the problematic original algorithm
    print("\n3. Checking for problematic code patterns:")
    print("   Look for this PROBLEMATIC line in your code:")
    print("   flood_mask[dem_array < water_level] = 1")
    print("   ↑ This causes 'bathtub filling' from all low points")
    
    # Check 4: UI settings
    print("\n4. UI Settings to check:")
    print("   - Make sure 'Use fixed flow direction' checkbox is CHECKED")
    print("   - Verify use_fixed_flow=True is passed to calculate_flood_area()")
    
    # Check 5: Expected vs actual behavior
    print("\n5. Expected vs Actual behavior:")
    print("   EXPECTED (fixed algorithm):")
    print("   - Water starts from HIGHEST points in channels")
    print("   - Water flows DOWNHILL following terrain")
    print("   - Results shown in RED color")
    print("   - Layer name contains 'FIXED'")
    print("")
    print("   ACTUAL (if you see bathtub filling):")
    print("   - Water fills ALL areas below water level")
    print("   - No respect for flow direction")
    print("   - Results shown in BLUE color")
    print("   - Layer name without 'FIXED'")
    
    # Recommendations
    print("\n=== RECOMMENDATIONS ===")
    print("1. First run: python debug_fixed_flow_availability.py")
    print("2. If fixed flow is not available, use the force_fixed_flow_solution.py")
    print("3. Look for console messages when running:")
    print("   - '🔧 Using FIXED FLOW-BASED model' = GOOD")
    print("   - '⚠️ Using original model as fallback' = PROBLEM")
    print("4. Check result layer color:")
    print("   - RED = Fixed algorithm working")
    print("   - BLUE = Original bathtub filling")
    print("   - GREEN = Simple high-to-low alternative")

# Usage instructions
if __name__ == "__main__":
    print("=== FORCE FIXED FLOW SOLUTION ===")
    print("")
    print("USAGE INSTRUCTIONS:")
    print("")
    print("1. Test the current status:")
    print("   python force_fixed_flow_solution.py")
    print("")
    print("2. Replace the problematic function in model_hydraulic.py:")
    print("   from force_fixed_flow_solution import calculate_flood_area_ALWAYS_FIXED")
    print("   # Then use calculate_flood_area_ALWAYS_FIXED instead of calculate_flood_area")
    print("")
    print("3. Look for result colors:")
    print("   - RED = Fixed algorithm (what you want)")
    print("   - BLUE = Original bathtub filling (the problem)")
    print("   - GREEN = Simple high-to-low alternative")
    print("")
    print("4. Check console messages:")
    print("   - '🔧 FORCING FIXED FLOW-BASED model' = Success")
    print("   - '🔧 Creating simple high-to-low flow algorithm' = Backup working")
    print("")
    
    # Run diagnostics
    check_fixed_flow_status()
    diagnose_flood_algorithm()