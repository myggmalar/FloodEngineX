#!/usr/bin/env python3
"""
Comprehensive Validation Test for FloodEngine Core Functionality
================================================================

This script tests all critical components of the FloodEngine system to ensure
proper operation after the core fixes implementation. It validates:

1. Core hydraulic calculations
2. 2D Saint-Venant solver
3. Mesh generation and interpolation
4. Flood analysis algorithms
5. Error handling and edge cases
6. Memory management
7. Performance benchmarks

Usage:
    python comprehensive_validation_test.py
"""

import sys
import os
import numpy as np
import time
import traceback
from pathlib import Path

# Add the FloodEngine path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_imports():
    """Test that all core modules can be imported successfully."""
    print("=" * 60)
    print("TESTING IMPORTS")
    print("=" * 60)
    
    try:
        # Test core hydraulic model import
        print("Importing model_hydraulic...")
        import model_hydraulic
        print("✓ model_hydraulic imported successfully")
        
        # Test advanced modules
        advanced_modules = [
            'quality_assurance_framework',
            'advanced_analysis_tools',
            'web_services_integration',
            'database_connectivity',
            'cloud_computing_interface',
            'restful_api_implementation',
            'advanced_visualization_features'
        ]
        
        imported_modules = []
        for module in advanced_modules:
            try:
                exec(f"import {module}")
                imported_modules.append(module)
                print(f"✓ {module} imported successfully")
            except ImportError as e:
                print(f"⚠ {module} not available: {e}")
        
        return model_hydraulic, imported_modules
        
    except Exception as e:
        print(f"✗ Import failed: {e}")
        traceback.print_exc()
        return None, []

def test_hydraulic_calculations():
    """Test core hydraulic calculation functions."""
    print("\n" + "=" * 60)
    print("TESTING HYDRAULIC CALCULATIONS")
    print("=" * 60)
    
    try:
        import model_hydraulic
        
        # Test 1: Basic flow calculations
        print("Testing basic flow calculations...")
        
        # Create test data
        test_dem = np.random.uniform(100, 200, (50, 50))
        test_flow_rate = 100.0  # m³/s
        
        # Test Manning's equation calculation
        if hasattr(model_hydraulic, 'calculate_manning_flow'):
            result = model_hydraulic.calculate_manning_flow(
                flow_rate=test_flow_rate,
                slope=0.01,
                manning_n=0.035,
                width=10.0
            )
            print(f"✓ Manning's flow calculation: {result:.2f} m/s")
        
        # Test 2: Depth calculation from flow
        print("Testing depth calculations...")
        if hasattr(model_hydraulic, 'calculate_depth_from_flow'):
            depth = model_hydraulic.calculate_depth_from_flow(
                flow_rate=test_flow_rate,
                velocity=2.0,
                width=10.0
            )
            print(f"✓ Depth calculation: {depth:.2f} m")
        
        # Test 3: Velocity calculations
        print("Testing velocity calculations...")
        test_velocity = test_flow_rate / (10.0 * 2.0)  # Q = A * V
        print(f"✓ Velocity calculation: {test_velocity:.2f} m/s")
        
        return True
        
    except Exception as e:
        print(f"✗ Hydraulic calculations failed: {e}")
        traceback.print_exc()
        return False

def test_2d_solver():
    """Test 2D Saint-Venant solver functionality."""
    print("\n" + "=" * 60)
    print("TESTING 2D SAINT-VENANT SOLVER")
    print("=" * 60)
    
    try:
        import model_hydraulic
        
        # Create a small test grid
        nx, ny = 20, 20
        dx, dy = 1.0, 1.0
        
        # Initialize test arrays
        h = np.ones((nx, ny)) * 0.1  # Water depth
        u = np.zeros((nx, ny))       # X-velocity
        v = np.zeros((nx, ny))       # Y-velocity
        z = np.random.uniform(0, 5, (nx, ny))  # Bed elevation
        
        # Add some initial water in the center
        h[8:12, 8:12] = 2.0
        
        print(f"Test grid: {nx}x{ny}, dx={dx}, dy={dy}")
        print(f"Initial water volume: {np.sum(h * dx * dy):.2f} m³")
        
        # Test if the solver class exists
        if hasattr(model_hydraulic, 'SaintVenant2DSolver'):
            solver = model_hydraulic.SaintVenant2DSolver(
                nx=nx, ny=ny, dx=dx, dy=dy
            )
            print("✓ 2D solver initialized")
            
            # Test one time step
            dt = 0.001  # Small time step for stability
            h_new, u_new, v_new = solver.solve_time_step(h, u, v, z, dt)
            
            print(f"✓ Time step completed")
            print(f"Water volume after step: {np.sum(h_new * dx * dy):.2f} m³")
            print(f"Max velocity: {np.max(np.sqrt(u_new**2 + v_new**2)):.4f} m/s")
            
        else:
            print("⚠ 2D solver class not found, testing alternative methods...")
            
            # Test individual solver components
            if hasattr(model_hydraulic, 'calculate_shallow_water_step'):
                result = model_hydraulic.calculate_shallow_water_step(h, u, v, z, 0.001)
                print("✓ Shallow water step calculation available")
        
        return True
        
    except Exception as e:
        print(f"✗ 2D solver test failed: {e}")
        traceback.print_exc()
        return False

def test_mesh_interpolation():
    """Test mesh generation and interpolation functions."""
    print("\n" + "=" * 60)
    print("TESTING MESH GENERATION AND INTERPOLATION")
    print("=" * 60)
    
    try:
        import model_hydraulic
        
        # Create test points
        x = np.linspace(0, 10, 11)
        y = np.linspace(0, 10, 11)
        X, Y = np.meshgrid(x, y)
        
        # Create test elevation data (simple paraboloid)
        Z = 100 + 0.1 * (X - 5)**2 + 0.1 * (Y - 5)**2
        
        print(f"Test mesh: {X.shape}, elevation range: {Z.min():.1f} - {Z.max():.1f} m")
        
        # Test interpolation if available
        if hasattr(model_hydraulic, 'interpolate_elevation'):
            # Test point interpolation
            test_x, test_y = 2.5, 7.5
            interp_z = model_hydraulic.interpolate_elevation(
                X.flatten(), Y.flatten(), Z.flatten(), test_x, test_y
            )
            print(f"✓ Point interpolation at ({test_x}, {test_y}): {interp_z:.2f} m")
        
        # Test mesh refinement if available
        if hasattr(model_hydraulic, 'refine_mesh'):
            refined_mesh = model_hydraulic.refine_mesh(X, Y, Z, factor=2)
            print("✓ Mesh refinement completed")
        
        # Test mesh quality metrics
        dx = np.diff(x)[0]
        dy = np.diff(y)[0]
        aspect_ratio = dx / dy
        print(f"✓ Mesh quality - Aspect ratio: {aspect_ratio:.2f}")
        
        return True
        
    except Exception as e:
        print(f"✗ Mesh interpolation test failed: {e}")
        traceback.print_exc()
        return False

def test_flood_analysis():
    """Test flood analysis algorithms."""
    print("\n" + "=" * 60)
    print("TESTING FLOOD ANALYSIS ALGORITHMS")
    print("=" * 60)
    
    try:
        import model_hydraulic
        
        # Create test flood scenario
        nx, ny = 30, 30
        dem = np.random.uniform(95, 105, (nx, ny))
        
        # Create a river channel
        center_row = ny // 2
        dem[center_row-2:center_row+3, :] -= 5  # 5m deep channel
        
        # Add flood water
        water_level = 100.0
        flood_depth = np.maximum(0, water_level - dem)
        
        print(f"DEM range: {dem.min():.1f} - {dem.max():.1f} m")
        print(f"Flooded area: {np.sum(flood_depth > 0)} cells")
        print(f"Max flood depth: {flood_depth.max():.2f} m")
        
        # Test flood extent calculation
        if hasattr(model_hydraulic, 'calculate_flood_extent'):
            extent = model_hydraulic.calculate_flood_extent(dem, water_level)
            print(f"✓ Flood extent: {np.sum(extent)} cells")
        
        # Test flow accumulation if available
        if hasattr(model_hydraulic, 'calculate_flow_accumulation'):
            flow_acc = model_hydraulic.calculate_flow_accumulation(dem)
            print(f"✓ Flow accumulation calculated, max: {flow_acc.max()}")
        
        # Test drainage analysis
        if hasattr(model_hydraulic, 'analyze_drainage'):
            drainage_info = model_hydraulic.analyze_drainage(dem, flood_depth)
            print("✓ Drainage analysis completed")
        
        # Calculate basic flood statistics
        total_volume = np.sum(flood_depth) * 1.0 * 1.0  # Assuming 1m cell size
        avg_depth = np.mean(flood_depth[flood_depth > 0]) if np.any(flood_depth > 0) else 0
        
        print(f"✓ Flood volume: {total_volume:.0f} m³")
        print(f"✓ Average depth in flooded areas: {avg_depth:.2f} m")
        
        return True
        
    except Exception as e:
        print(f"✗ Flood analysis test failed: {e}")
        traceback.print_exc()
        return False

def test_error_handling():
    """Test error handling and edge cases."""
    print("\n" + "=" * 60)
    print("TESTING ERROR HANDLING AND EDGE CASES")
    print("=" * 60)
    
    try:
        import model_hydraulic
        
        # Test 1: Empty arrays
        print("Testing empty array handling...")
        empty_array = np.array([])
        try:
            if hasattr(model_hydraulic, 'process_elevation_data'):
                result = model_hydraulic.process_elevation_data(empty_array)
                print("✓ Empty array handled gracefully")
        except Exception as e:
            print(f"⚠ Empty array handling: {e}")
        
        # Test 2: Invalid values
        print("Testing invalid value handling...")
        invalid_dem = np.array([[np.nan, np.inf, -np.inf], [1, 2, 3]])
        try:
            cleaned_dem = np.nan_to_num(invalid_dem, nan=0, posinf=1000, neginf=-1000)
            print(f"✓ Invalid values cleaned: {np.isfinite(cleaned_dem).all()}")
        except Exception as e:
            print(f"⚠ Invalid value handling: {e}")
        
        # Test 3: Memory constraints
        print("Testing memory constraints...")
        try:
            # Create a reasonably large array to test memory handling
            large_array = np.zeros((1000, 1000))
            memory_usage = large_array.nbytes / 1024 / 1024  # MB
            print(f"✓ Large array created: {memory_usage:.1f} MB")
            del large_array  # Clean up
        except MemoryError:
            print("⚠ Memory constraint reached (expected for very large arrays)")
        
        # Test 4: Boundary conditions
        print("Testing boundary conditions...")
        test_grid = np.ones((5, 5))
        
        # Test edge access
        try:
            edge_values = [
                test_grid[0, :],    # Top edge
                test_grid[-1, :],   # Bottom edge
                test_grid[:, 0],    # Left edge
                test_grid[:, -1]    # Right edge
            ]
            print("✓ Boundary access successful")
        except IndexError as e:
            print(f"✗ Boundary access failed: {e}")
        
        return True
        
    except Exception as e:
        print(f"✗ Error handling test failed: {e}")
        traceback.print_exc()
        return False

def test_performance():
    """Test performance benchmarks."""
    print("\n" + "=" * 60)
    print("TESTING PERFORMANCE BENCHMARKS")
    print("=" * 60)
    
    try:
        import model_hydraulic
        
        # Performance test sizes
        test_sizes = [(100, 100), (200, 200), (500, 500)]
        
        for nx, ny in test_sizes:
            print(f"\nTesting performance for {nx}x{ny} grid...")
            
            # Create test data
            start_time = time.time()
            dem = np.random.uniform(0, 100, (nx, ny))
            setup_time = time.time() - start_time
            
            # Test array operations
            start_time = time.time()
            
            # Basic operations
            gradient_x = np.gradient(dem, axis=1)
            gradient_y = np.gradient(dem, axis=0)
            slope = np.sqrt(gradient_x**2 + gradient_y**2)
            
            # Statistical operations
            mean_elevation = np.mean(dem)
            std_elevation = np.std(dem)
            min_elevation = np.min(dem)
            max_elevation = np.max(dem)
            
            calc_time = time.time() - start_time
            
            # Memory usage estimate
            memory_mb = (dem.nbytes + gradient_x.nbytes + gradient_y.nbytes + slope.nbytes) / 1024 / 1024
            
            print(f"  Setup time: {setup_time*1000:.1f} ms")
            print(f"  Calculation time: {calc_time*1000:.1f} ms")
            print(f"  Memory usage: {memory_mb:.1f} MB")
            print(f"  Mean elevation: {mean_elevation:.1f} m")
            print(f"  Elevation range: {min_elevation:.1f} - {max_elevation:.1f} m")
            
            # Performance threshold checks
            if calc_time > 1.0:  # More than 1 second for basic operations
                print(f"  ⚠ Performance warning: calculation took {calc_time:.2f}s")
            else:
                print(f"  ✓ Performance good: {calc_time*1000:.1f} ms")
        
        return True
        
    except Exception as e:
        print(f"✗ Performance test failed: {e}")
        traceback.print_exc()
        return False

def run_comprehensive_test():
    """Run all validation tests."""
    print("FloodEngine Comprehensive Validation Test")
    print("========================================")
    print(f"Python version: {sys.version}")
    print(f"NumPy version: {np.__version__}")
    print(f"Test started at: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    
    # Track test results
    test_results = {}
    start_time = time.time()
    
    # Run all tests
    tests = [
        ("imports", test_imports),
        ("hydraulic_calculations", test_hydraulic_calculations),
        ("2d_solver", test_2d_solver),
        ("mesh_interpolation", test_mesh_interpolation),
        ("flood_analysis", test_flood_analysis),
        ("error_handling", test_error_handling),
        ("performance", test_performance)
    ]
    
    for test_name, test_func in tests:
        try:
            if test_name == "imports":
                model_hydraulic, imported_modules = test_func()
                test_results[test_name] = model_hydraulic is not None
            else:
                test_results[test_name] = test_func()
        except Exception as e:
            print(f"\n✗ Test {test_name} crashed: {e}")
            test_results[test_name] = False
    
    # Summary
    total_time = time.time() - start_time
    passed_tests = sum(test_results.values())
    total_tests = len(test_results)
    
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    
    for test_name, result in test_results.items():
        status = "✓ PASS" if result else "✗ FAIL"
        print(f"{test_name:25} {status}")
    
    print(f"\nTotal tests: {total_tests}")
    print(f"Passed: {passed_tests}")
    print(f"Failed: {total_tests - passed_tests}")
    print(f"Success rate: {passed_tests/total_tests*100:.1f}%")
    print(f"Total time: {total_time:.2f} seconds")
    
    if passed_tests == total_tests:
        print("\n🎉 ALL TESTS PASSED! FloodEngine is ready for production.")
    elif passed_tests >= total_tests * 0.8:
        print("\n✓ Most tests passed. FloodEngine is mostly functional.")
    else:
        print("\n⚠ Several tests failed. Review issues before production use.")
    
    return test_results

if __name__ == "__main__":
    run_comprehensive_test()
