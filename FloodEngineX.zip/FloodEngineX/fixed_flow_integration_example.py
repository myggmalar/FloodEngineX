"""
Integration Example for Fixed Flow Direction
-------------------------------------------
Shows how to use the fixed flow direction algorithm in your code
and how to integrate the UI components
"""

def use_fixed_flow_in_your_code(iface, dem_path, water_level, flow_q=None, use_fixed_flow=True):
    """
    Example of how to use the fixed flow direction in your own code
    
    :param iface: QGIS interface
    :param dem_path: Path to DEM
    :param water_level: Water level in meters
    :param flow_q: Flow rate in m³/s (optional)
    :param use_fixed_flow: Whether to use fixed flow direction (default: True)
    :return: Flood layer
    """
    try:
        # Import the model_hydraulic module for calculate_flood_area
        from model_hydraulic import calculate_flood_area
        
        # Call the function with use_fixed_flow parameter
        return calculate_flood_area(
            iface, dem_path, water_level, 
            flow_q=flow_q,
            use_fixed_flow=use_fixed_flow
        )
        
    except ImportError as e:
        print(f"Error importing modules: {e}")
        return None

def add_fixed_flow_ui_to_your_dialog(dialog):
    """
    Example of how to add fixed flow UI controls to your own dialog
    
    :param dialog: Your dialog class instance
    """
    from PyQt5.QtWidgets import QCheckBox, QHBoxLayout
    
    # Create checkbox for flow Q mode
    flow_direction_layout = QHBoxLayout()
    dialog.use_fixed_flow = QCheckBox("Use fixed flow direction (water flows from high to low)")
    dialog.use_fixed_flow.setToolTip("Enable the fixed flow algorithm which ensures water only flows downhill from high points")
    dialog.use_fixed_flow.setChecked(True)  # Enable by default
    flow_direction_layout.addWidget(dialog.use_fixed_flow)
    flow_direction_layout.addStretch()
    
    # Create checkbox for water level mode
    water_direction_layout = QHBoxLayout()
    dialog.use_fixed_flow_wl = QCheckBox("Use fixed flow direction (propagate from high points)")
    dialog.use_fixed_flow_wl.setToolTip("Enable the fixed flow direction for water level mode")
    dialog.use_fixed_flow_wl.setChecked(True)  # Enable by default
    water_direction_layout.addWidget(dialog.use_fixed_flow_wl)
    water_direction_layout.addStretch()
    
    # Add layouts to your dialog's layouts as needed
    # Example: dialog.q_layout.addLayout(flow_direction_layout)
    # Example: dialog.water_level_layout.addLayout(water_direction_layout)
    
    return flow_direction_layout, water_direction_layout

def compare_original_vs_fixed(iface, dem_path, water_level, flow_q=50.0):
    """
    Compare the original vs fixed flow direction algorithms
    
    :param iface: QGIS interface
    :param dem_path: Path to DEM
    :param water_level: Water level in meters
    :param flow_q: Flow rate in m³/s
    :return: Tuple of (original_layer, fixed_layer)
    """
    import os
    
    # Create output folders
    base_folder = os.path.dirname(dem_path)
    original_folder = os.path.join(base_folder, "original_flow")
    fixed_folder = os.path.join(base_folder, "fixed_flow")
    
    os.makedirs(original_folder, exist_ok=True)
    os.makedirs(fixed_folder, exist_ok=True)
    
    # Import the model_hydraulic module
    from model_hydraulic import calculate_flood_area
    
    # Run original algorithm
    print("\n=== RUNNING ORIGINAL ALGORITHM ===")
    original_layer = calculate_flood_area(
        iface, dem_path, water_level,
        output_folder=original_folder,
        flow_q=flow_q,
        use_fixed_flow=False  # Force original algorithm
    )
    
    # Run fixed algorithm
    print("\n=== RUNNING FIXED ALGORITHM ===")
    fixed_layer = calculate_flood_area(
        iface, dem_path, water_level,
        output_folder=fixed_folder,
        flow_q=flow_q,
        use_fixed_flow=True  # Force fixed algorithm
    )
      print("\n=== COMPARISON COMPLETE ===")
    print("Original results in blue: Check for 'bathtub filling' from low points")
    print("Fixed results in red: Check for flow from high points following channels")
    
    return original_layer, fixed_layer

# Example of how to use these functions from the QGIS Python Console
if __name__ == "__main__":
    print("FIXED FLOW DIRECTION INTEGRATION EXAMPLE")
    print("This script demonstrates how to use the fixed flow direction algorithm")
    print("It should be run from within QGIS Python Console")
    
    # Example usage:
    # 1. Open QGIS and load your DEM
    # 2. Run this script from the Python Console
    # 3. Call one of these functions:
    #
    # # Use fixed flow in your own code:
    # layer = use_fixed_flow_in_your_code(iface, "C:/path/to/dem.tif", 10.0, flow_q=50.0)
    # 
    # # Compare original vs fixed algorithms:
    # original, fixed = compare_original_vs_fixed(iface, "C:/path/to/dem.tif", 10.0, flow_q=50.0)
    #
    # # Add fixed flow UI to your own dialog:
    # from PyQt5.QtWidgets import QDialog
    # dialog = QDialog()
    # flow_layout, water_layout = add_fixed_flow_ui_to_your_dialog(dialog)
    # compare_original_vs_fixed(iface, dem_path, water_level=100.0, flow_q=50.0)
