def classFactory(iface):
    from .floodengine import FloodEngine
    return FloodEngine(iface)
