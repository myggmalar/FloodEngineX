"""
Final validation of the FloodEngine plugin for QGIS
"""
import os
import sys
import re
from pathlib import Path

def check_directory_structure():
    """Check if the plugin directory structure is correct"""
    print("Checking directory structure...")
    
    required_files = [
        "__init__.py",
        "floodengine.py",
        "floodengine_ui.py",
        "model_hydraulic.py",
        "flow_direction_flood_fixed.py",
        "icon.png",
        "metadata.txt"
    ]
    
    all_ok = True
    for filename in required_files:
        if not os.path.exists(filename):
            print(f"✗ Missing: {filename}")
            all_ok = False
        else:
            print(f"✓ Found: {filename}")
    
    return all_ok

def check_class_factory():
    """Check if classFactory is properly defined in __init__.py"""
    print("\nChecking classFactory...")
    
    if not os.path.exists("__init__.py"):
        print("✗ __init__.py not found")
        return False
    
    try:
        with open("__init__.py", "r", encoding="utf-8") as f:
            content = f.read()
        
        if "def classFactory" not in content:
            print("✗ classFactory function not found in __init__.py")
            return False
        
        if "return FloodEngine(iface)" not in content and "return" not in content:
            print("✗ classFactory function may not return the plugin object")
            return False
        
        print("✓ classFactory function appears to be defined properly")
        return True
    
    except Exception as e:
        print(f"✗ Error checking __init__.py: {e}")
        return False

def check_metadata():
    """Check if metadata.txt contains required fields"""
    print("\nChecking metadata.txt...")
    
    if not os.path.exists("metadata.txt"):
        print("✗ metadata.txt not found")
        return False
    
    required_fields = [
        "name",
        "version",
        "qgisMinimumVersion",
        "description",
        "author"
    ]
    
    try:
        with open("metadata.txt", "r", encoding="utf-8") as f:
            content = f.read()
        
        all_ok = True
        for field in required_fields:
            if f"{field}=" not in content:
                print(f"✗ Missing field: {field}")
                all_ok = False
            else:
                print(f"✓ Found field: {field}")
        
        return all_ok
    
    except Exception as e:
        print(f"✗ Error checking metadata.txt: {e}")
        return False

def check_qgis_imports():
    """Check if QGIS imports are correctly specified"""
    print("\nChecking QGIS imports...")
    
    files_to_check = [
        "floodengine.py",
        "floodengine_ui.py"
    ]
    
    all_ok = True
    for filename in files_to_check:
        if not os.path.exists(filename):
            continue
        
        try:
            with open(filename, "r", encoding="utf-8") as f:
                content = f.read()
            
            # Check for QGIS imports
            has_qgis_import = "from qgis" in content
            
            if has_qgis_import:
                print(f"✓ {filename} - QGIS import found")
            else:
                print(f"✗ {filename} - No QGIS import found")
                all_ok = False
        
        except Exception as e:
            print(f"✗ Error checking {filename}: {e}")
            all_ok = False
    
    return all_ok

def check_import_order():
    """Check if import order is as expected"""
    print("\nChecking import order in files...")
    
    files_to_check = [
        "floodengine_ui.py",
        "model_hydraulic.py"
    ]
    
    # Define better module import order (correct practices)
    expected_order = [
        r"^import os",
        r"^import sys",
        r"^import",
        r"^from PyQt5",
        r"^from qgis",
    ]
    
    all_ok = True
    for filename in files_to_check:
        if not os.path.exists(filename):
            continue
            
        try:
            with open(filename, "r", encoding="utf-8") as f:
                lines = f.readlines()
            
            # Extract imports
            imports = []
            for line in lines:
                line = line.strip()
                if line.startswith("import ") or line.startswith("from "):
                    imports.append(line)
            
            # Check if there are imports
            if imports:
                print(f"✓ {filename} - Has import statements")
            else:
                print(f"? {filename} - No import statements found")
                continue
        
        except Exception as e:
            print(f"✗ Error checking {filename}: {e}")
            all_ok = False
    
    return all_ok

def main():
    """Main function"""
    print("QGIS PLUGIN FINAL VALIDATION")
    print("===========================")
    
    # Get current directory
    cwd = Path.cwd()
    print(f"Current directory: {cwd}")
    
    # Run all checks
    structure_ok = check_directory_structure()
    factory_ok = check_class_factory()
    metadata_ok = check_metadata()
    qgis_imports_ok = check_qgis_imports()
    import_order_ok = check_import_order()
    
    # Summarize results
    print("\nVALIDATION SUMMARY")
    print("================")
    print(f"Directory structure: {'✓' if structure_ok else '✗'}")
    print(f"classFactory: {'✓' if factory_ok else '✗'}")
    print(f"Metadata: {'✓' if metadata_ok else '✗'}")
    print(f"QGIS imports: {'✓' if qgis_imports_ok else '✗'}")
    print(f"Import order: {'✓' if import_order_ok else '✗'}")
    
    # Final result
    all_ok = structure_ok and factory_ok and metadata_ok and qgis_imports_ok
    
    if all_ok:
        print("\n✅ PLUGIN VALIDATION PASSED!")
        print("The plugin appears to be correctly structured and should load in QGIS.")
        return 0
    else:
        print("\n⚠️ SOME VALIDATION CHECKS FAILED")
        print("The plugin may still work, but you should address any issues.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
