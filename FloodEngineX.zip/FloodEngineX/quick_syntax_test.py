"""
Quick UI syntax test
"""
import os
import sys
import tokenize
import io

print("Starting test...")
print(f"Current directory: {os.getcwd()}")

def check_indentation(filename):
    """Check file for indentation errors"""
    try:
        with open(filename, 'rb') as f:
            tokens = list(tokenize.tokenize(f.readline))
        print(f"✅ {filename}: No tokenization errors")
        return True
    except tokenize.TokenError as e:
        print(f"❌ {filename}: Tokenization error: {e}")
        return False
    except Exception as e:
        print(f"❌ {filename}: Error during tokenization: {e}")
        return False

files_to_check = [
    "floodengine_ui.py", 
    "model_hydraulic.py", 
    "flow_direction_flood_fixed.py"
]

for filename in files_to_check:
    print(f"\nChecking {filename}...")
      if not os.path.exists(filename):
        print(f"❌ File not found: {filename}")
        continue
    
    try:
        with open(filename, "r", encoding="utf-8") as f:
            content = f.read()
    except UnicodeDecodeError:
        try:
            with open(filename, "r", encoding="latin-1") as f:
                content = f.read()
            print("Note: Used latin-1 encoding")
        except Exception as e:
            print(f"❌ Error reading file: {e}")
            continue
        
    # Try to compile
    try:
        compile(content, filename, "exec")
        print(f"✅ {filename}: Compilation successful!")
    except SyntaxError as e:
        print(f"❌ {filename}: Syntax error: {e}")
        print(f"  Line {e.lineno}, Column {e.offset}")
        print(f"  {e.text.strip()}")
          # Show context
        print("\nContext:")
        try:
            with open(filename, "r", encoding="utf-8") as f:
                lines = f.readlines()
        except UnicodeDecodeError:
            try:
                with open(filename, "r", encoding="latin-1") as f:
                    lines = f.readlines()
            except Exception:
                print("Could not read file for context")
                lines = []
            
        start = max(0, e.lineno - 5)
        end = min(len(lines), e.lineno + 5)
        
        for i in range(start, end):
            prefix = "→ " if i == e.lineno - 1 else "  "
            print(f"{prefix}{i+1}: {lines[i].rstrip()}")
    except Exception as e:
        print(f"❌ {filename}: Error: {e}")

print("\nTest complete")
