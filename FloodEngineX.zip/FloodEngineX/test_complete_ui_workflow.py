#!/usr/bin/env python3
"""
Final comprehensive test that simulates the exact UI workflow
"""

import sys
import os
from pathlib import Path

# Add current directory to path
script_dir = Path(__file__).parent
sys.path.insert(0, str(script_dir))

def create_realistic_animation_data():
    """Create realistic animation data that mimics actual simulation output."""
    
    output_folder = "test_simulation_output"
    animation_folder = os.path.join(output_folder, "time_series_animation")
    
    # Create directories
    os.makedirs(animation_folder, exist_ok=True)
    
    # Create realistic file structure
    files_to_create = [
        "depth_t000.tif",
        "depth_t001.tif", 
        "depth_t002.tif",
        "velocity_x_t000.tif",
        "velocity_x_t001.tif",
        "velocity_x_t002.tif",
        "velocity_y_t000.tif",
        "velocity_y_t001.tif", 
        "velocity_y_t002.tif",
        "timesteps.txt"
    ]
    
    for filename in files_to_create:
        filepath = os.path.join(animation_folder, filename)
        with open(filepath, "w") as f:
            if filename.endswith(".txt"):
                f.write("0.0\n1.0\n2.0\n")
            else:
                f.write("dummy raster content")
    
    print(f"✅ Created realistic test data in: {animation_folder}")
    print(f"📁 Created {len(files_to_create)} animation files")
    return output_folder

def simulate_ui_workflow():
    """Simulate the exact workflow that happens in the UI."""
    
    print("🧪 Simulating complete UI animation workflow...")
    output_folder = None
    
    try:
        # Step 1: Create test simulation output
        output_folder = create_realistic_animation_data()
        print("✅ Step 1: Created simulation output")
        
        # Step 2: Check animation checkbox state (simulated as True)
        create_animation = True
        print(f"✅ Step 2: Animation checkbox enabled: {create_animation}")
        
        # Step 3: Simulate completion of model run
        print("✅ Step 3: Model run completed successfully")
        
        # Step 4: Check for animation data (as UI does)
        animation_folder = os.path.join(output_folder, 'time_series_animation')
        raster_folder = os.path.join(output_folder, 'rasters')
        
        print(f"🔍 Checking for animation folder: {animation_folder}")
        print(f"🔍 Animation folder exists: {os.path.exists(animation_folder)}")
        print(f"🔍 Checking for raster folder: {raster_folder}")  
        print(f"🔍 Raster folder exists: {os.path.exists(raster_folder)}")
        
        if os.path.exists(animation_folder) or os.path.exists(raster_folder):
            print("✅ Step 4: Animation data found")
            
            # Step 5: Import and call launch_animation_controls (UI method simulation)
            print("🎬 Step 5: Launching animation controls...")
            
            # Simulate UI launch_animation_controls method
            from launch_animation import launch_animation_from_folder
            from PyQt5.QtWidgets import QApplication, QWidget
            
            # Create QApplication if needed
            app = QApplication.instance()
            if app is None:
                app = QApplication(sys.argv)
                print("📱 Created QApplication")
            
            # Simulate getting parent window (as UI does)
            parent_window = None
            try:
                # This simulates the QGIS check in the UI
                # from qgis.utils import iface  # This would fail in standalone
                # parent_window = iface.mainWindow()
                pass
            except:
                # Fall back to widget parent (simulated)
                parent_widget = QWidget()
                parent_widget.setWindowTitle("Simulated UI Parent")
                parent_window = parent_widget
                print("✅ Using simulated widget parent")
            
            # Simulate the exact call from UI
            print("🖥️ Launching animation with proper parent management...")
            result = launch_animation_from_folder(output_folder, standalone=True, parent=parent_window)
            
            if result:
                print("✅ Step 6: Animation controls launched successfully!")
                print("ℹ️ Animation dialog should be visible and persistent")
                
                # Brief pause to verify visibility
                import time
                time.sleep(3)
                
                return True
            else:
                print("❌ Animation launch returned False")
                return False
                
        else:
            print("❌ No animation data found")
            return False
            
    except Exception as e:
        print(f"❌ Error in UI workflow simulation: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    finally:
        # Cleanup
        try:
            import shutil
            if output_folder and os.path.exists(output_folder):
                shutil.rmtree(output_folder, ignore_errors=True)
                print("🧹 Cleaned up test data")
        except:
            pass

if __name__ == "__main__":
    print("=" * 60)
    print("🧪 COMPREHENSIVE UI ANIMATION WORKFLOW TEST")
    print("=" * 60)
    
    success = simulate_ui_workflow()
    
    print("=" * 60)
    if success:
        print("✅ COMPLETE UI WORKFLOW TEST PASSED")
        print("✅ Animation dialog should be working properly in the UI")
    else:
        print("❌ UI WORKFLOW TEST FAILED")
        print("❌ There may be an issue with the animation integration")
    print("=" * 60)
