#!/usr/bin/env python3
"""
Test script for adaptive threshold flood mask generation
"""
import numpy as np
from collections import deque

def simple_bathtub_flood(dem_array, water_level):
    """Simple bathtub flood model for comparison"""
    return (dem_array < water_level) & (~np.isnan(dem_array))

def adaptive_threshold_flood_mask(dem_array, water_level):
    """
    Implements the adaptive threshold approach for flow-based flood simulation
    This mimics the fixes we made to create_proper_flow_flood_mask
    """
    # Find all cells that could be flooded (below water level)
    floodable_mask = (dem_array < water_level) & (~np.isnan(dem_array))
    
    if not np.any(floodable_mask):
        print(f"   No floodable cells at water level {water_level}m")
        return np.zeros_like(dem_array, dtype=bool)
    
    floodable_elevations = dem_array[floodable_mask]
    
    # Try different percentile thresholds: 80th, 70th, 60th, 50th
    percentiles = [80, 70, 60, 50]
    
    for percentile in percentiles:
        start_threshold = np.percentile(floodable_elevations, percentile)
        
        # Find start points at this threshold
        start_mask = floodable_mask & (dem_array >= start_threshold)
        start_points = np.sum(start_mask)
        
        print(f"   Trying {percentile}th percentile (≥{start_threshold:.2f}m): {start_points} start points")
        
        # Accept if we have enough start points (or if this is a high percentile)
        if start_points >= 5 or (percentile >= 70 and start_points > 0):
            print(f"   ✓ Using {percentile}th percentile threshold: {start_points} start points")
            
            # Simulate flow from start points (simplified BFS)
            flooded = np.zeros_like(dem_array, dtype=bool)
            queue = deque()
            
            # Initialize start points
            start_rows, start_cols = np.where(start_mask)
            for row, col in zip(start_rows, start_cols):
                flooded[row, col] = True
                queue.append((row, col))
            
            # Simple flow propagation (BFS downhill)
            rows, cols = dem_array.shape
            directions = [(-1,-1), (-1,0), (-1,1), (0,-1), (0,1), (1,-1), (1,0), (1,1)]
            
            iterations = 0
            max_iterations = 1000
            
            while queue and iterations < max_iterations:
                iterations += 1
                row, col = queue.popleft()
                current_elevation = dem_array[row, col]
                
                for dr, dc in directions:
                    new_row, new_col = row + dr, col + dc
                    
                    # Check bounds
                    if not (0 <= new_row < rows and 0 <= new_col < cols):
                        continue
                    
                    # Skip if already flooded
                    if flooded[new_row, new_col]:
                        continue
                    
                    neighbor_elevation = dem_array[new_row, new_col]
                    
                    # Skip invalid elevations
                    if np.isnan(neighbor_elevation):
                        continue
                    
                    # Flow downhill only and flood if below water level
                    if (neighbor_elevation <= current_elevation and 
                        neighbor_elevation < water_level):
                        flooded[new_row, new_col] = True
                        queue.append((new_row, new_col))
            
            total_flooded = np.sum(flooded)
            print(f"   → Flow simulation: {total_flooded} cells flooded in {iterations} iterations")
            
            # If flow algorithm produces reasonable results, use it
            if total_flooded > 0:
                return flooded
    
    # Fallback to bathtub model if flow algorithm fails
    print(f"   ⚠️ Flow algorithm failed, using bathtub fallback")
    bathtub_result = simple_bathtub_flood(dem_array, water_level)
    bathtub_count = np.sum(bathtub_result)
    
    # Safety check: reject if >50% of DEM would be flooded
    total_valid_cells = np.sum(~np.isnan(dem_array))
    if bathtub_count > 0.5 * total_valid_cells:
        print(f"   ⚠️ Bathtub result too large ({bathtub_count}/{total_valid_cells} = {100*bathtub_count/total_valid_cells:.1f}%), returning empty")
        return np.zeros_like(dem_array, dtype=bool)
    
    print(f"   → Bathtub fallback: {bathtub_count} cells flooded")
    return bathtub_result

def test_adaptive_approach():
    """Test the adaptive threshold approach with synthetic data"""
    print("ADAPTIVE THRESHOLD FLOOD MASK TEST")
    print("=" * 50)
    
    # Create synthetic DEM (100x100) with elevation range 38-46m
    np.random.seed(42)  # For reproducible results
    dem = np.random.rand(100, 100) * 8 + 38  # 38m to 46m range
    
    print(f"Synthetic DEM: {dem.shape}")
    print(f"Elevation range: {np.min(dem):.1f}m to {np.max(dem):.1f}m")
    print()
    
    # Test water levels - including intermediate levels
    water_levels = [40.0, 42.0, 44.0, 46.0, 48.0]
    
    print("Testing water levels:")
    print("-" * 50)
    
    for water_level in water_levels:
        print(f"Water Level: {water_level}m")
        
        # Test adaptive approach
        flood_mask = adaptive_threshold_flood_mask(dem, water_level)
        flooded_cells = np.sum(flood_mask)
        percent_flooded = (flooded_cells / dem.size) * 100
        
        # Compare with simple bathtub
        bathtub_mask = simple_bathtub_flood(dem, water_level)
        bathtub_cells = np.sum(bathtub_mask)
        bathtub_percent = (bathtub_cells / dem.size) * 100
        
        print(f"  Adaptive approach: {flooded_cells} cells ({percent_flooded:.1f}%)")
        print(f"  Bathtub model:     {bathtub_cells} cells ({bathtub_percent:.1f}%)")
        print(f"  Difference:        {flooded_cells - bathtub_cells:+d} cells")
        print()

if __name__ == "__main__":
    test_adaptive_approach()
