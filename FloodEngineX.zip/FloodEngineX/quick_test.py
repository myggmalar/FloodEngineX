#!/usr/bin/env python3
"""
Quick FloodEngine Test
=====================

Test key components of the FloodEngine plugin fixes.
"""

import sys
import os
from pathlib import Path

print("=== FloodEngine Quick Test ===")
print(f"Python version: {sys.version}")
print(f"Working directory: {os.getcwd()}")

# Test 1: Saint-Venant 2D module compilation
print("\n1. Testing Saint-Venant 2D compilation...")
try:
    import py_compile
    py_compile.compile('saint_venant_2d.py', doraise=True)
    print("✓ Saint-Venant 2D module compiles successfully")
except Exception as e:
    print(f"✗ Saint-Venant 2D compilation failed: {e}")

# Test 2: Check model_hydraulic for safety functions
print("\n2. Checking model_hydraulic safety functions...")
try:
    with open('model_hydraulic.py', 'r') as f:
        content = f.read()
    
    safety_functions = [
        'safe_csv_value_conversion',
        'fix_nodata_handling', 
        'create_proper_geotiff',
        'generate_variable_water_levels',
        'validate_water_levels',
        'safe_streamlines_parameters'
    ]
    
    found_functions = []
    for func in safety_functions:
        if f"def {func}" in content:
            found_functions.append(func)
            print(f"✓ Found {func}")
        else:
            print(f"✗ Missing {func}")
    
    print(f"Found {len(found_functions)}/{len(safety_functions)} safety functions")
    
except Exception as e:
    print(f"✗ Error checking safety functions: {e}")

# Test 3: Check UI model_type fix
print("\n3. Checking UI model_type initialization...")
try:
    with open('floodengine_ui.py', 'r') as f:
        lines = f.readlines()
    
    # Look for the fix around line 68
    fix_found = False
    for i, line in enumerate(lines[60:75], 61):  # Check lines 61-75
        if 'model_type' in line and ('=' in line or 'self.' in line):
            print(f"✓ Found model_type initialization at line {i}: {line.strip()}")
            fix_found = True
            break
    
    if not fix_found:
        print("✗ model_type initialization fix not found")
        
except Exception as e:
    print(f"✗ Error checking UI fix: {e}")

# Test 4: Simple Saint-Venant function test
print("\n4. Testing Saint-Venant function availability...")
try:
    # Add current directory to Python path
    sys.path.insert(0, os.getcwd())
    
    # Try to import the module
    import saint_venant_2d
    
    # Check if main function exists
    if hasattr(saint_venant_2d, 'simulate_saint_venant_2d'):
        print("✓ Main simulation function found")
    else:
        print("✗ Main simulation function missing")
        
    # Check if helper functions exist  
    helper_functions = ['_calculate_time_step', '_apply_boundary_conditions', '_save_raster']
    for func in helper_functions:
        if hasattr(saint_venant_2d, func):
            print(f"✓ Helper function {func} found")
        else:
            print(f"✗ Helper function {func} missing")
            
except Exception as e:
    print(f"✗ Error testing Saint-Venant module: {e}")

print("\n=== Test Complete ===")
