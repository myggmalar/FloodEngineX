#!/usr/bin/env python3
"""
Test streamline generation with the newly fixed Saint-Venant velocities.
"""
import os
import sys
import numpy as np
from osgeo import gdal
import logging

# Add the current directory to sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("StreamlineTest")

def test_streamline_generation():
    """Test streamline generation with the fixed velocity files."""
    
    output_folder = r"C:\Plugin\VSCode\output"
    
    # Check if velocity files exist
    velocity_files = []
    for i in range(1, 6):  # Check timesteps 1-5
        vx_file = os.path.join(output_folder, f"velocity_x_step_{i:03d}.tif")
        vy_file = os.path.join(output_folder, f"velocity_y_step_{i:03d}.tif")
        
        if os.path.exists(vx_file) and os.path.exists(vy_file):
            velocity_files.append((i, vx_file, vy_file))
    
    logger.info(f"Found {len(velocity_files)} velocity file pairs")
    
    # Test the latest timestep
    if velocity_files:
        timestep, vx_file, vy_file = velocity_files[-1]
        logger.info(f"Testing timestep {timestep}: {os.path.basename(vx_file)}, {os.path.basename(vy_file)}")
        
        # Load velocity data
        try:
            vx_ds = gdal.Open(vx_file)
            vy_ds = gdal.Open(vy_file)
            
            velocity_x = vx_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
            velocity_y = vy_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
            
            # Handle NaN values
            velocity_x = np.nan_to_num(velocity_x, nan=0.0)
            velocity_y = np.nan_to_num(velocity_y, nan=0.0)
            
            # Calculate velocity magnitude
            velocity_mag = np.sqrt(velocity_x**2 + velocity_y**2)
            
            # Statistics
            valid_mask = velocity_mag > 0.01
            
            logger.info(f"📊 Velocity statistics for timestep {timestep}:")
            logger.info(f"  • Total cells: {velocity_mag.size}")
            logger.info(f"  • Cells with flow: {np.sum(valid_mask)}")
            logger.info(f"  • Max velocity: {np.max(velocity_mag):.3f} m/s")
            logger.info(f"  • Mean velocity (flowing cells): {np.mean(velocity_mag[valid_mask]):.3f} m/s")
            logger.info(f"  • Velocity range: {np.min(velocity_mag[valid_mask]):.3f} to {np.max(velocity_mag[valid_mask]):.3f} m/s")
            
            # Check for main channel (areas with high velocity)
            high_velocity_mask = velocity_mag > 3.0
            logger.info(f"  • High velocity cells (>3 m/s): {np.sum(high_velocity_mask)}")
            
            if np.sum(high_velocity_mask) > 0:
                logger.info("✅ Main channel areas detected (high velocity zones)")
                
                # Find center of high velocity areas
                high_vel_indices = np.argwhere(high_velocity_mask)
                center_idx = high_vel_indices[len(high_vel_indices)//2]
                center_vel = velocity_mag[center_idx[0], center_idx[1]]
                
                logger.info(f"  • Main channel center velocity: {center_vel:.3f} m/s at pixel [{center_idx[0]}, {center_idx[1]}]")
            else:
                logger.warning("⚠️  No high velocity areas detected - may indicate missing main channel flow")
            
            # Check velocity direction distribution
            vx_stats = velocity_x[valid_mask]
            vy_stats = velocity_y[valid_mask]
            
            logger.info(f"📊 Velocity direction statistics:")
            logger.info(f"  • VX range: {np.min(vx_stats):.3f} to {np.max(vx_stats):.3f} m/s")
            logger.info(f"  • VY range: {np.min(vy_stats):.3f} to {np.max(vy_stats):.3f} m/s")
            logger.info(f"  • Positive VX cells: {np.sum(velocity_x > 0.1)} (flow east)")
            logger.info(f"  • Negative VX cells: {np.sum(velocity_x < -0.1)} (flow west)")
            logger.info(f"  • Positive VY cells: {np.sum(velocity_y > 0.1)} (flow south)")
            logger.info(f"  • Negative VY cells: {np.sum(velocity_y < -0.1)} (flow north)")
            
            return True
            
        except Exception as e:
            logger.error(f"Error loading velocity data: {str(e)}")
            return False
    else:
        logger.error("No velocity files found")
        return False

def test_saint_venant_loading():
    """Test loading Saint-Venant files with the enhanced streamlines code."""
    try:
        from enhanced_streamlines import load_saint_venant_velocity_files
        
        output_folder = r"C:\Plugin\VSCode\output"
        logger.info(f"Testing Saint-Venant file loading from: {output_folder}")
        
        # Load the latest velocity files
        saint_venant_results = load_saint_venant_velocity_files(output_folder)
        
        if saint_venant_results is not None:
            max_vel = np.max(saint_venant_results['velocity_magnitude'])
            mean_vel = np.mean(saint_venant_results['velocity_magnitude'])
            cells_over_5 = np.sum(saint_venant_results['velocity_magnitude'] > 5.0)
            cells_over_10 = np.sum(saint_venant_results['velocity_magnitude'] > 10.0)
            
            logger.info("✅ Saint-Venant files loaded successfully:")
            logger.info(f"  • Max velocity: {max_vel:.3f} m/s")
            logger.info(f"  • Mean velocity: {mean_vel:.3f} m/s")
            logger.info(f"  • Cells > 5 m/s: {cells_over_5}")
            logger.info(f"  • Cells > 10 m/s: {cells_over_10}")
            
            # Test validation with updated thresholds
            should_reject = False
            if max_vel > 8.0:
                should_reject = True
                logger.warning("❌ Would reject: max velocity > 8.0 m/s")
            if mean_vel > 6.0:
                should_reject = True
                logger.warning("❌ Would reject: mean velocity > 6.0 m/s")
            if cells_over_5 > 1000:
                should_reject = True
                logger.warning("❌ Would reject: too many cells > 5 m/s")
            if cells_over_10 > 10:
                should_reject = True
                logger.warning("❌ Would reject: too many cells > 10 m/s")
            
            if not should_reject:
                logger.info("✅ Saint-Venant results would be ACCEPTED with updated thresholds")
            else:
                logger.warning("❌ Saint-Venant results would still be REJECTED")
            
            return True
        else:
            logger.error("❌ Failed to load Saint-Venant files")
            return False
            
    except Exception as e:
        logger.error(f"Error testing Saint-Venant loading: {str(e)}")
        return False

if __name__ == "__main__":
    logger.info("🧪 Testing streamline generation with fixed velocities...")
    
    # Test velocity file analysis
    if test_streamline_generation():
        logger.info("✅ Velocity file analysis completed")
    else:
        logger.error("❌ Velocity file analysis failed")
    
    print()
    
    # Test Saint-Venant loading
    if test_saint_venant_loading():
        logger.info("✅ Saint-Venant loading test completed")
    else:
        logger.error("❌ Saint-Venant loading test failed")
