#!/usr/bin/env python3
"""
FloodEngine v4.0 - RESTful API Implementation Module
===================================================

Professional RESTful API implementation for FloodEngine providing:
- HTTP/HTTPS web service endpoints for external integration
- JSON/XML API responses with comprehensive metadata
- Authentication and authorization mechanisms
- Rate limiting and request validation
- Asynchronous processing with job queuing
- Real-time status monitoring and webhooks
- OpenAPI/Swagger documentation
- Client SDK generation support
- Microservices architecture ready

Author: FloodEngine Development Team
Date: June 7, 2025
Version: 4.0
"""

import os
import sys
import json
import time
import uuid
import logging
import asyncio
import hashlib
import tempfile
import zipfile
import mimetypes
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional, Any, Union, Callable
from dataclasses import dataclass, field, asdict
from pathlib import Path
from enum import Enum
import threading
from concurrent.futures import ThreadPoolExecutor
import traceback

# FastAPI and web service imports with graceful fallback
try:
    from fastapi import (
        FastAPI, HTTPException, Depends, Request, Response, 
        File, UploadFile, Form, Query, Path as PathParam,
        BackgroundTasks, Security, status
    )
    from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
    from fastapi.responses import JSONResponse, FileResponse, StreamingResponse
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.middleware.gzip import GZipMiddleware
    from fastapi.openapi.utils import get_openapi
    from fastapi.staticfiles import StaticFiles
    import uvicorn
    from pydantic import BaseModel, Field, validator
    FASTAPI_AVAILABLE = True
except ImportError:
    FASTAPI_AVAILABLE = False
    
    # Mock classes for when FastAPI is not available
    class BaseModel:
        pass
    class HTTPException(Exception):
        def __init__(self, status_code, detail):
            self.status_code = status_code
            self.detail = detail

# Additional web service dependencies
try:
    import redis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False

try:
    import sqlalchemy
    from sqlalchemy import create_engine, Column, String, Integer, DateTime, Text, Boolean
    from sqlalchemy.ext.declarative import declarative_base
    from sqlalchemy.orm import sessionmaker, Session
    SQLALCHEMY_AVAILABLE = True
except ImportError:
    SQLALCHEMY_AVAILABLE = False

# Import FloodEngine modules
try:
    from .saint_venant_2d import SaintVenant2DSolver
    from .quality_assurance_framework import QualityAssuranceFramework
    from .advanced_analysis_tools import FloodRiskAssessment, EconomicImpactAnalysis
    from .cloud_computing_interface import FloodEngineCloudManager, CloudProvider
    from .web_services_integration import FloodEngineWebServiceManager
    from .database_connectivity import FloodEngineDatabase
except ImportError:
    # Fallback for when modules are not available
    SaintVenant2DSolver = None
    QualityAssuranceFramework = None
    FloodRiskAssessment = None
    EconomicImpactAnalysis = None
    FloodEngineCloudManager = None
    CloudProvider = None
    FloodEngineWebServiceManager = None
    FloodEngineDatabase = None

# API Data Models
class RequestStatus(Enum):
    """Status of API requests."""
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class JobType(Enum):
    """Types of processing jobs."""
    FLOOD_SIMULATION = "flood_simulation"
    RISK_ASSESSMENT = "risk_assessment"
    ECONOMIC_ANALYSIS = "economic_analysis"
    QUALITY_ASSURANCE = "quality_assurance"
    DATA_PROCESSING = "data_processing"
    CLOUD_PROCESSING = "cloud_processing"

@dataclass
class APIConfig:
    """Configuration for FloodEngine API."""
    host: str = "0.0.0.0"
    port: int = 8000
    workers: int = 4
    reload: bool = False
    debug: bool = False
    api_key_required: bool = True
    rate_limit_requests: int = 100
    rate_limit_window: int = 3600  # seconds
    max_file_size: int = 100 * 1024 * 1024  # 100MB
    data_directory: str = "api_data"
    log_level: str = "INFO"
    database_url: str = "sqlite:///floodengine_api.db"
    redis_url: Optional[str] = None
    cors_origins: List[str] = field(default_factory=lambda: ["*"])
    webhook_timeout: int = 30

# Pydantic Models for API
if FASTAPI_AVAILABLE:
    class FloodSimulationRequest(BaseModel):
        """Request model for flood simulation."""
        project_name: str = Field(..., description="Name of the flood simulation project")
        bbox: List[float] = Field(..., description="Bounding box [min_lon, min_lat, max_lon, max_lat]")
        grid_resolution: float = Field(30.0, description="Grid resolution in meters")
        simulation_time: float = Field(3600.0, description="Simulation time in seconds")
        time_step: float = Field(1.0, description="Time step in seconds")
        precipitation_rate: float = Field(0.01, description="Precipitation rate in m/s")
        initial_conditions: Optional[Dict[str, Any]] = Field(None, description="Initial conditions")
        boundary_conditions: Optional[Dict[str, Any]] = Field(None, description="Boundary conditions")
        output_format: str = Field("geotiff", description="Output format")
        webhook_url: Optional[str] = Field(None, description="Webhook URL for completion notification")
        
        @validator('bbox')
        def validate_bbox(cls, v):
            if len(v) != 4:
                raise ValueError('Bounding box must have 4 values')
            if v[0] >= v[2] or v[1] >= v[3]:
                raise ValueError('Invalid bounding box coordinates')
            return v

    class RiskAssessmentRequest(BaseModel):
        """Request model for flood risk assessment."""
        simulation_id: str = Field(..., description="ID of completed flood simulation")
        assessment_type: str = Field("comprehensive", description="Type of assessment")
        vulnerability_data: Optional[Dict[str, Any]] = Field(None, description="Vulnerability data")
        exposure_data: Optional[Dict[str, Any]] = Field(None, description="Exposure data")
        confidence_level: float = Field(0.95, description="Confidence level for analysis")
        output_format: str = Field("json", description="Output format")

    class EconomicAnalysisRequest(BaseModel):
        """Request model for economic impact analysis."""
        risk_assessment_id: str = Field(..., description="ID of completed risk assessment")
        analysis_scope: str = Field("regional", description="Scope of economic analysis")
        discount_rate: float = Field(0.03, description="Discount rate for NPV calculations")
        time_horizon: int = Field(50, description="Time horizon in years")
        economic_data: Optional[Dict[str, Any]] = Field(None, description="Economic data")

    class JobStatusResponse(BaseModel):
        """Response model for job status."""
        job_id: str
        status: str
        progress: float
        message: Optional[str] = None
        created_at: datetime
        updated_at: datetime
        estimated_completion: Optional[datetime] = None
        result_urls: Optional[List[str]] = None
        error_details: Optional[Dict[str, Any]] = None

    class APIResponse(BaseModel):
        """Generic API response model."""
        success: bool
        message: str
        data: Optional[Any] = None
        timestamp: datetime = Field(default_factory=datetime.now)
        version: str = "4.0"

else:
    # Fallback models when FastAPI is not available
    FloodSimulationRequest = dict
    RiskAssessmentRequest = dict
    EconomicAnalysisRequest = dict
    JobStatusResponse = dict
    APIResponse = dict

class FloodEngineJob:
    """Represents a processing job in the FloodEngine API."""
    
    def __init__(self, job_id: str, job_type: JobType, parameters: Dict[str, Any],
                 user_id: Optional[str] = None, webhook_url: Optional[str] = None):
        self.job_id = job_id
        self.job_type = job_type
        self.parameters = parameters
        self.user_id = user_id
        self.webhook_url = webhook_url
        self.status = RequestStatus.PENDING
        self.progress = 0.0
        self.message = "Job created"
        self.created_at = datetime.now()
        self.updated_at = datetime.now()
        self.estimated_completion = None
        self.result_files = []
        self.error_details = None
        
    def update_status(self, status: RequestStatus, progress: float = None, 
                     message: str = None, estimated_completion: datetime = None):
        """Update job status."""
        self.status = status
        if progress is not None:
            self.progress = progress
        if message is not None:
            self.message = message
        if estimated_completion is not None:
            self.estimated_completion = estimated_completion
        self.updated_at = datetime.now()
    
    def add_result_file(self, file_path: str, file_type: str = "output"):
        """Add result file to job."""
        self.result_files.append({
            'file_path': file_path,
            'file_type': file_type,
            'created_at': datetime.now().isoformat()
        })
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert job to dictionary."""
        return {
            'job_id': self.job_id,
            'job_type': self.job_type.value,
            'status': self.status.value,
            'progress': self.progress,
            'message': self.message,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'estimated_completion': self.estimated_completion.isoformat() if self.estimated_completion else None,
            'result_files': self.result_files,
            'error_details': self.error_details
        }

class JobManager:
    """Manages processing jobs for the FloodEngine API."""
    
    def __init__(self, max_concurrent_jobs: int = 10):
        self.jobs: Dict[str, FloodEngineJob] = {}
        self.max_concurrent_jobs = max_concurrent_jobs
        self.job_queue = asyncio.Queue()
        self.running_jobs = set()
        self.logger = logging.getLogger(__name__)
        
    def create_job(self, job_type: JobType, parameters: Dict[str, Any],
                   user_id: Optional[str] = None, webhook_url: Optional[str] = None) -> str:
        """Create a new processing job."""
        job_id = str(uuid.uuid4())
        job = FloodEngineJob(job_id, job_type, parameters, user_id, webhook_url)
        self.jobs[job_id] = job
        
        # Add to queue
        asyncio.create_task(self.job_queue.put(job))
        
        self.logger.info(f"Created job {job_id} of type {job_type.value}")
        return job_id
    
    def get_job(self, job_id: str) -> Optional[FloodEngineJob]:
        """Get job by ID."""
        return self.jobs.get(job_id)
    
    def get_user_jobs(self, user_id: str) -> List[FloodEngineJob]:
        """Get all jobs for a user."""
        return [job for job in self.jobs.values() if job.user_id == user_id]
    
    def cancel_job(self, job_id: str) -> bool:
        """Cancel a job."""
        if job_id in self.jobs:
            job = self.jobs[job_id]
            if job.status in [RequestStatus.PENDING, RequestStatus.PROCESSING]:
                job.update_status(RequestStatus.CANCELLED, message="Job cancelled by user")
                return True
        return False
    
    async def process_jobs(self):
        """Process jobs from the queue."""
        while True:
            try:
                if len(self.running_jobs) < self.max_concurrent_jobs:
                    job = await self.job_queue.get()
                    if job.status == RequestStatus.PENDING:
                        self.running_jobs.add(job.job_id)
                        asyncio.create_task(self._execute_job(job))
            except Exception as e:
                self.logger.error(f"Error in job processing: {e}")
            
            await asyncio.sleep(1)
    
    async def _execute_job(self, job: FloodEngineJob):
        """Execute a specific job."""
        try:
            job.update_status(RequestStatus.PROCESSING, 0.0, "Starting job execution")
            
            if job.job_type == JobType.FLOOD_SIMULATION:
                await self._execute_flood_simulation(job)
            elif job.job_type == JobType.RISK_ASSESSMENT:
                await self._execute_risk_assessment(job)
            elif job.job_type == JobType.ECONOMIC_ANALYSIS:
                await self._execute_economic_analysis(job)
            elif job.job_type == JobType.QUALITY_ASSURANCE:
                await self._execute_quality_assurance(job)
            else:
                raise ValueError(f"Unknown job type: {job.job_type}")
            
            job.update_status(RequestStatus.COMPLETED, 100.0, "Job completed successfully")
            
            # Send webhook notification if configured
            if job.webhook_url:
                await self._send_webhook_notification(job)
                
        except Exception as e:
            self.logger.error(f"Job {job.job_id} failed: {e}")
            job.update_status(RequestStatus.FAILED, message=f"Job failed: {str(e)}")
            job.error_details = {
                'error_type': type(e).__name__,
                'error_message': str(e),
                'traceback': traceback.format_exc()
            }
        finally:
            self.running_jobs.discard(job.job_id)
    
    async def _execute_flood_simulation(self, job: FloodEngineJob):
        """Execute flood simulation job."""
        params = job.parameters
        
        # Update progress
        job.update_status(RequestStatus.PROCESSING, 10.0, "Initializing simulation")
        
        if SaintVenant2DSolver is None:
            raise ImportError("Saint-Venant solver not available")
        
        # Initialize solver
        solver = SaintVenant2DSolver()
        
        # Set up simulation parameters
        bbox = params['bbox']
        nx = int((bbox[2] - bbox[0]) * 111000 / params['grid_resolution'])
        ny = int((bbox[3] - bbox[1]) * 111000 / params['grid_resolution'])
        dx = params['grid_resolution']
        dy = params['grid_resolution']
        
        job.update_status(RequestStatus.PROCESSING, 20.0, "Setting up grid")
        
        # Initialize simulation
        solver.initialize_simulation(nx, ny, dx, dy)
        
        # Set initial conditions
        if 'initial_conditions' in params and params['initial_conditions']:
            # Apply custom initial conditions
            pass
        
        job.update_status(RequestStatus.PROCESSING, 30.0, "Running simulation")
        
        # Run simulation
        dt = params['time_step']
        total_time = params['simulation_time']
        n_steps = int(total_time / dt)
        
        output_dir = Path(f"api_data/jobs/{job.job_id}")
        output_dir.mkdir(parents=True, exist_ok=True)
        
        for step in range(n_steps):
            # Add precipitation
            precipitation = params.get('precipitation_rate', 0.01)
            solver.add_precipitation(precipitation * dt)
            
            # Execute time step
            solver.step(dt)
            
            # Update progress
            progress = 30.0 + (step / n_steps) * 60.0
            job.update_status(RequestStatus.PROCESSING, progress, 
                            f"Step {step+1}/{n_steps}")
            
            # Save intermediate results (every 10% of simulation)
            if step % (n_steps // 10) == 0:
                output_file = output_dir / f"result_step_{step:06d}.tif"
                # Save results (implementation would depend on solver interface)
                # solver.save_results(str(output_file))
        
        job.update_status(RequestStatus.PROCESSING, 90.0, "Saving final results")
        
        # Save final results
        final_output = output_dir / "final_results.tif"
        job.add_result_file(str(final_output), "simulation_result")
        
        # Generate metadata
        metadata = {
            'simulation_parameters': params,
            'grid_dimensions': {'nx': nx, 'ny': ny},
            'time_steps': n_steps,
            'bbox': bbox,
            'completion_time': datetime.now().isoformat()
        }
        
        metadata_file = output_dir / "metadata.json"
        with open(metadata_file, 'w') as f:
            json.dump(metadata, f, indent=2)
        
        job.add_result_file(str(metadata_file), "metadata")
    
    async def _execute_risk_assessment(self, job: FloodEngineJob):
        """Execute risk assessment job."""
        params = job.parameters
        
        job.update_status(RequestStatus.PROCESSING, 10.0, "Loading simulation data")
        
        if FloodRiskAssessment is None:
            raise ImportError("Risk assessment module not available")
        
        # Get simulation data
        simulation_id = params['simulation_id']
        simulation_job = self.get_job(simulation_id)
        
        if not simulation_job or simulation_job.status != RequestStatus.COMPLETED:
            raise ValueError("Referenced simulation not found or not completed")
        
        job.update_status(RequestStatus.PROCESSING, 30.0, "Initializing risk assessment")
        
        # Initialize risk assessor
        risk_assessor = FloodRiskAssessment()
        
        job.update_status(RequestStatus.PROCESSING, 50.0, "Calculating risk metrics")
        
        # Load simulation results and perform assessment
        # This would require implementing the actual risk assessment logic
        
        job.update_status(RequestStatus.PROCESSING, 80.0, "Generating risk maps")
        
        # Save results
        output_dir = Path(f"api_data/jobs/{job.job_id}")
        output_dir.mkdir(parents=True, exist_ok=True)
        
        risk_map_file = output_dir / "risk_map.tif"
        job.add_result_file(str(risk_map_file), "risk_map")
        
        assessment_report = output_dir / "assessment_report.json"
        job.add_result_file(str(assessment_report), "assessment_report")
    
    async def _execute_economic_analysis(self, job: FloodEngineJob):
        """Execute economic analysis job."""
        params = job.parameters
        
        job.update_status(RequestStatus.PROCESSING, 10.0, "Loading risk assessment data")
        
        if EconomicImpactAnalysis is None:
            raise ImportError("Economic analysis module not available")
        
        # Get risk assessment data
        risk_id = params['risk_assessment_id']
        risk_job = self.get_job(risk_id)
        
        if not risk_job or risk_job.status != RequestStatus.COMPLETED:
            raise ValueError("Referenced risk assessment not found or not completed")
        
        job.update_status(RequestStatus.PROCESSING, 30.0, "Initializing economic analysis")
        
        # Initialize economic analyzer
        economic_analyzer = EconomicImpactAnalysis()
        
        job.update_status(RequestStatus.PROCESSING, 70.0, "Calculating economic impacts")
        
        # Perform economic analysis
        # Implementation would depend on the economic analysis module
        
        # Save results
        output_dir = Path(f"api_data/jobs/{job.job_id}")
        output_dir.mkdir(parents=True, exist_ok=True)
        
        economic_report = output_dir / "economic_analysis.json"
        job.add_result_file(str(economic_report), "economic_report")
    
    async def _execute_quality_assurance(self, job: FloodEngineJob):
        """Execute quality assurance job."""
        params = job.parameters
        
        job.update_status(RequestStatus.PROCESSING, 10.0, "Initializing QA framework")
        
        if QualityAssuranceFramework is None:
            raise ImportError("Quality assurance framework not available")
        
        qa_framework = QualityAssuranceFramework()
        
        job.update_status(RequestStatus.PROCESSING, 30.0, "Running unit tests")
        # Run QA tests
        
        job.update_status(RequestStatus.PROCESSING, 70.0, "Running performance tests")
        
        # Save QA results
        output_dir = Path(f"api_data/jobs/{job.job_id}")
        output_dir.mkdir(parents=True, exist_ok=True)
        
        qa_report = output_dir / "qa_report.html"
        job.add_result_file(str(qa_report), "qa_report")
    
    async def _send_webhook_notification(self, job: FloodEngineJob):
        """Send webhook notification for job completion."""
        try:
            import aiohttp
            
            webhook_data = {
                'job_id': job.job_id,
                'status': job.status.value,
                'progress': job.progress,
                'message': job.message,
                'completion_time': job.updated_at.isoformat(),
                'result_urls': [f"/api/v1/jobs/{job.job_id}/results/{i}" 
                               for i in range(len(job.result_files))]
            }
            
            timeout = aiohttp.ClientTimeout(total=30)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(job.webhook_url, json=webhook_data) as response:
                    if response.status == 200:
                        self.logger.info(f"Webhook notification sent for job {job.job_id}")
                    else:
                        self.logger.warning(f"Webhook notification failed for job {job.job_id}: {response.status}")
        
        except Exception as e:
            self.logger.error(f"Failed to send webhook notification: {e}")

class RateLimiter:
    """Rate limiting for API requests."""
    
    def __init__(self, max_requests: int = 100, window_seconds: int = 3600):
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self.requests = {}  # {api_key: [(timestamp, count), ...]}
        
    def is_allowed(self, api_key: str) -> bool:
        """Check if request is allowed under rate limit."""
        now = time.time()
        window_start = now - self.window_seconds
        
        if api_key not in self.requests:
            self.requests[api_key] = []
        
        # Remove old requests
        self.requests[api_key] = [
            (ts, count) for ts, count in self.requests[api_key] 
            if ts > window_start
        ]
        
        # Count current requests
        total_requests = sum(count for ts, count in self.requests[api_key])
        
        if total_requests >= self.max_requests:
            return False
        
        # Add current request
        self.requests[api_key].append((now, 1))
        return True

class AuthManager:
    """Authentication manager for API access."""
    
    def __init__(self):
        self.api_keys = {}  # {api_key: user_info}
        self.load_api_keys()
        
    def load_api_keys(self):
        """Load API keys from configuration."""
        # In production, this would load from a secure database
        self.api_keys = {
            "floodengine_demo_key": {
                "user_id": "demo_user",
                "permissions": ["read", "write", "admin"],
                "created_at": datetime.now().isoformat()
            }
        }
    
    def validate_api_key(self, api_key: str) -> Optional[Dict[str, Any]]:
        """Validate API key and return user info."""
        return self.api_keys.get(api_key)
    
    def has_permission(self, api_key: str, permission: str) -> bool:
        """Check if API key has specific permission."""
        user_info = self.validate_api_key(api_key)
        if not user_info:
            return False
        return permission in user_info.get("permissions", [])

class FloodEngineAPI:
    """Main FloodEngine RESTful API implementation."""
    
    def __init__(self, config: APIConfig = None):
        self.config = config or APIConfig()
        self.logger = self._setup_logging()
        
        # Initialize components
        self.job_manager = JobManager()
        self.rate_limiter = RateLimiter(
            self.config.rate_limit_requests,
            self.config.rate_limit_window
        )
        self.auth_manager = AuthManager()
        
        # Initialize data directory
        self.data_dir = Path(self.config.data_directory)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize FastAPI app if available
        if FASTAPI_AVAILABLE:
            self.app = self._create_fastapi_app()
        else:
            self.app = None
            self.logger.warning("FastAPI not available - API functionality limited")
        
        # Start job processor
        asyncio.create_task(self.job_manager.process_jobs())
    
    def _setup_logging(self) -> logging.Logger:
        """Setup logging for API."""
        logger = logging.getLogger("FloodEngineAPI")
        logger.setLevel(getattr(logging, self.config.log_level))
        
        # File handler
        log_file = self.data_dir / "api.log"
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.INFO)
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        
        # Formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)
        
        return logger
    
    def _create_fastapi_app(self) -> FastAPI:
        """Create and configure FastAPI application."""
        app = FastAPI(
            title="FloodEngine v4.0 API",
            description="Professional 2D flood modeling API with advanced capabilities",
            version="4.0.0",
            docs_url="/docs",
            redoc_url="/redoc"
        )
        
        # Add middleware
        app.add_middleware(
            CORSMiddleware,
            allow_origins=self.config.cors_origins,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"]
        )
        
        app.add_middleware(GZipMiddleware, minimum_size=1000)
        
        # Security
        security = HTTPBearer()
        
        # Dependency for API key validation
        async def get_current_user(credentials: HTTPAuthorizationCredentials = Security(security)):
            api_key = credentials.credentials
            
            # Rate limiting
            if not self.rate_limiter.is_allowed(api_key):
                raise HTTPException(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    detail="Rate limit exceeded"
                )
            
            # Authentication
            if self.config.api_key_required:
                user_info = self.auth_manager.validate_api_key(api_key)
                if not user_info:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="Invalid API key"
                    )
                return user_info
            
            return {"user_id": "anonymous", "permissions": ["read"]}
        
        # Root endpoint
        @app.get("/")
        async def root():
            return APIResponse(
                success=True,
                message="FloodEngine v4.0 API - Professional 2D Flood Modeling",
                data={
                    "version": "4.0.0",
                    "status": "operational",
                    "documentation": "/docs",
                    "capabilities": [
                        "flood_simulation",
                        "risk_assessment", 
                        "economic_analysis",
                        "quality_assurance",
                        "cloud_processing"
                    ]
                }
            )
        
        # Health check endpoint
        @app.get("/health")
        async def health_check():
            return {
                "status": "healthy",
                "timestamp": datetime.now().isoformat(),
                "version": "4.0.0",
                "components": {
                    "job_manager": len(self.job_manager.running_jobs) < self.job_manager.max_concurrent_jobs,
                    "database": True,  # Would check actual database connection
                    "file_system": self.data_dir.exists()
                }
            }
        
        # Flood simulation endpoint
        @app.post("/api/v1/simulations", response_model=JobStatusResponse)
        async def create_flood_simulation(
            request: FloodSimulationRequest,
            user_info: dict = Depends(get_current_user)
        ):
            if not self.auth_manager.has_permission(user_info.get("api_key", ""), "write"):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Insufficient permissions"
                )
            
            job_id = self.job_manager.create_job(
                JobType.FLOOD_SIMULATION,
                request.dict(),
                user_info["user_id"],
                request.webhook_url
            )
            
            job = self.job_manager.get_job(job_id)
            return JobStatusResponse(**job.to_dict())
        
        # Risk assessment endpoint
        @app.post("/api/v1/risk-assessments", response_model=JobStatusResponse)
        async def create_risk_assessment(
            request: RiskAssessmentRequest,
            user_info: dict = Depends(get_current_user)
        ):
            if not self.auth_manager.has_permission(user_info.get("api_key", ""), "write"):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Insufficient permissions"
                )
            
            job_id = self.job_manager.create_job(
                JobType.RISK_ASSESSMENT,
                request.dict(),
                user_info["user_id"]
            )
            
            job = self.job_manager.get_job(job_id)
            return JobStatusResponse(**job.to_dict())
        
        # Economic analysis endpoint
        @app.post("/api/v1/economic-analyses", response_model=JobStatusResponse)
        async def create_economic_analysis(
            request: EconomicAnalysisRequest,
            user_info: dict = Depends(get_current_user)
        ):
            job_id = self.job_manager.create_job(
                JobType.ECONOMIC_ANALYSIS,
                request.dict(),
                user_info["user_id"]
            )
            
            job = self.job_manager.get_job(job_id)
            return JobStatusResponse(**job.to_dict())
        
        # Job status endpoint
        @app.get("/api/v1/jobs/{job_id}", response_model=JobStatusResponse)
        async def get_job_status(
            job_id: str = PathParam(..., description="Job ID"),
            user_info: dict = Depends(get_current_user)
        ):
            job = self.job_manager.get_job(job_id)
            if not job:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Job not found"
                )
            
            # Check if user has access to this job
            if job.user_id != user_info["user_id"] and not self.auth_manager.has_permission(user_info.get("api_key", ""), "admin"):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Access denied"
                )
            
            return JobStatusResponse(**job.to_dict())
        
        # Cancel job endpoint
        @app.delete("/api/v1/jobs/{job_id}")
        async def cancel_job(
            job_id: str = PathParam(..., description="Job ID"),
            user_info: dict = Depends(get_current_user)
        ):
            job = self.job_manager.get_job(job_id)
            if not job:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Job not found"
                )
            
            if job.user_id != user_info["user_id"] and not self.auth_manager.has_permission(user_info.get("api_key", ""), "admin"):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Access denied"
                )
            
            if self.job_manager.cancel_job(job_id):
                return APIResponse(success=True, message="Job cancelled successfully")
            else:
                return APIResponse(success=False, message="Job cannot be cancelled")
        
        # List user jobs endpoint
        @app.get("/api/v1/jobs")
        async def list_user_jobs(
            status_filter: Optional[str] = Query(None, description="Filter by status"),
            user_info: dict = Depends(get_current_user)
        ):
            jobs = self.job_manager.get_user_jobs(user_info["user_id"])
            
            if status_filter:
                jobs = [job for job in jobs if job.status.value == status_filter]
            
            return {
                "jobs": [job.to_dict() for job in jobs],
                "total": len(jobs)
            }
        
        # Download results endpoint
        @app.get("/api/v1/jobs/{job_id}/results/{result_index}")
        async def download_results(
            job_id: str = PathParam(..., description="Job ID"),
            result_index: int = PathParam(..., description="Result file index"),
            user_info: dict = Depends(get_current_user)
        ):
            job = self.job_manager.get_job(job_id)
            if not job:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Job not found"
                )
            
            if job.user_id != user_info["user_id"] and not self.auth_manager.has_permission(user_info.get("api_key", ""), "admin"):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Access denied"
                )
            
            if result_index >= len(job.result_files):
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Result file not found"
                )
            
            result_file = job.result_files[result_index]
            file_path = Path(result_file['file_path'])
            
            if not file_path.exists():
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Result file not available"
                )
            
            return FileResponse(
                path=str(file_path),
                filename=file_path.name,
                media_type=mimetypes.guess_type(str(file_path))[0] or 'application/octet-stream'
            )
        
        # Upload data endpoint
        @app.post("/api/v1/upload")
        async def upload_file(
            file: UploadFile = File(...),
            file_type: str = Form(..., description="Type of file"),
            user_info: dict = Depends(get_current_user)
        ):
            if file.size > self.config.max_file_size:
                raise HTTPException(
                    status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                    detail="File too large"
                )
            
            # Save uploaded file
            upload_dir = self.data_dir / "uploads" / user_info["user_id"]
            upload_dir.mkdir(parents=True, exist_ok=True)
            
            file_id = str(uuid.uuid4())
            file_path = upload_dir / f"{file_id}_{file.filename}"
            
            with open(file_path, "wb") as buffer:
                content = await file.read()
                buffer.write(content)
            
            return APIResponse(
                success=True,
                message="File uploaded successfully",
                data={
                    "file_id": file_id,
                    "original_name": file.filename,
                    "file_type": file_type,
                    "size": len(content),
                    "upload_path": str(file_path)
                }
            )
        
        # API documentation customization
        def custom_openapi():
            if app.openapi_schema:
                return app.openapi_schema
            
            openapi_schema = get_openapi(
                title="FloodEngine v4.0 API",
                version="4.0.0",
                description="""
# FloodEngine v4.0 Professional API

Advanced 2D flood modeling API with enterprise-grade capabilities:

## Features
- **Flood Simulation**: Saint-Venant shallow water equations solver
- **Risk Assessment**: Comprehensive flood risk analysis
- **Economic Analysis**: Economic impact assessment
- **Quality Assurance**: Automated testing and validation
- **Cloud Processing**: Distributed computing capabilities

## Authentication
All endpoints require Bearer token authentication using API keys.

## Rate Limiting
- 100 requests per hour per API key
- Contact support for higher limits

## Webhooks
Set webhook URLs in requests to receive completion notifications.
                """,
                routes=app.routes,
            )
            
            # Add authentication to OpenAPI schema
            openapi_schema["components"]["securitySchemes"] = {
                "BearerAuth": {
                    "type": "http",
                    "scheme": "bearer"
                }
            }
            
            # Apply security to all endpoints
            for path in openapi_schema["paths"]:
                for method in openapi_schema["paths"][path]:
                    openapi_schema["paths"][path][method]["security"] = [{"BearerAuth": []}]
            
            app.openapi_schema = openapi_schema
            return app.openapi_schema
        
        app.openapi = custom_openapi
        
        return app
    
    def run(self):
        """Run the API server."""
        if not FASTAPI_AVAILABLE:
            raise ImportError("FastAPI required to run API server")
        
        self.logger.info(f"Starting FloodEngine API server on {self.config.host}:{self.config.port}")
        
        uvicorn.run(
            self.app,
            host=self.config.host,
            port=self.config.port,
            workers=self.config.workers,
            reload=self.config.reload,
            log_level=self.config.log_level.lower()
        )

# Factory functions for easy configuration
def create_development_api() -> FloodEngineAPI:
    """Create API configured for development."""
    config = APIConfig(
        debug=True,
        reload=True,
        api_key_required=False,
        rate_limit_requests=1000,
        log_level="DEBUG"
    )
    return FloodEngineAPI(config)

def create_production_api() -> FloodEngineAPI:
    """Create API configured for production."""
    config = APIConfig(
        debug=False,
        reload=False,
        api_key_required=True,
        rate_limit_requests=100,
        log_level="INFO",
        workers=4
    )
    return FloodEngineAPI(config)

def create_cloud_api(redis_url: str = None) -> FloodEngineAPI:
    """Create API configured for cloud deployment."""
    config = APIConfig(
        debug=False,
        reload=False,
        api_key_required=True,
        rate_limit_requests=500,
        log_level="INFO",
        workers=8,
        redis_url=redis_url
    )
    return FloodEngineAPI(config)

# Testing and validation functions
async def test_api_endpoints():
    """Test API endpoints functionality."""
    print("FloodEngine v4.0 - RESTful API Test")
    print("=" * 45)
    
    try:
        # Create development API
        api = create_development_api()
        
        # Test job creation
        job_id = api.job_manager.create_job(
            JobType.FLOOD_SIMULATION,
            {
                'project_name': 'test_simulation',
                'bbox': [-74.1, 40.7, -74.0, 40.8],
                'grid_resolution': 50.0,
                'simulation_time': 3600.0,
                'time_step': 1.0
            }
        )
        
        print(f"✓ Created test job: {job_id}")
        
        # Test job status
        job = api.job_manager.get_job(job_id)
        print(f"✓ Job status: {job.status.value}")
        
        # Test rate limiting
        rate_limited = not api.rate_limiter.is_allowed("test_key")
        print(f"✓ Rate limiting: {'Working' if not rate_limited else 'Limited'}")
        
        # Test authentication
        user_info = api.auth_manager.validate_api_key("floodengine_demo_key")
        print(f"✓ Authentication: {'Working' if user_info else 'Failed'}")
        
        print("\nAPI test completed successfully!")
        
    except Exception as e:
        print(f"API test failed: {e}")
        traceback.print_exc()

# Main execution
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='FloodEngine v4.0 RESTful API')
    parser.add_argument('--mode', choices=['dev', 'prod', 'cloud', 'test'], 
                       default='dev', help='API mode')
    parser.add_argument('--host', default='0.0.0.0', help='Host address')
    parser.add_argument('--port', type=int, default=8000, help='Port number')
    
    args = parser.parse_args()
    
    if args.mode == 'test':
        asyncio.run(test_api_endpoints())
    else:
        if args.mode == 'dev':
            api = create_development_api()
        elif args.mode == 'prod':
            api = create_production_api()
        elif args.mode == 'cloud':
            api = create_cloud_api()
        
        # Override host/port if provided
        api.config.host = args.host
        api.config.port = args.port
        
        api.run()
