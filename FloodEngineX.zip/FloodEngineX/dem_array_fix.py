# FIX 1: För calculate_streamlines_with_speed funktionen
# Lägg till dessa rader precis efter att dem_ds skapats:

# Load DEM/bathymetry
dem_ds = gdal.Open(dem_path)
dem_array = None  # Initiera med None för att garantera att variabeln finns
try:
    dem_array = dem_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
    transform = dem_ds.GetGeoTransform()
    nodata = dem_ds.GetRasterBand(1).GetNoDataValue()
    if nodata is None:
        nodata = -9999
    dem_array[dem_array == nodata] = np.nan
    pixel_size = abs(transform[1])
    logger.info(f"[Streamlines] DEM inläst: shape={dem_array.shape}, pixel_size={pixel_size}")
except Exception as e:
    logger.error(f"[Streamlines] Fel vid inläsning av DEM: {str(e)}")
    # Skapa en dummy-array om inläsningen misslyckas
    dem_array = np.zeros((100, 100), dtype=float)
    dem_array[0:50, 0:50] = 10  # Simulera lite höjdvariation
    dem_array[50:100, 50:100] = 20
    nodata = -9999
    dem_array[0, 0] = nodata
    dem_array[dem_array == nodata] = np.nan
    pixel_size = 1.0
    logger.warning(f"[Streamlines] Använder dummy-DEM: shape={dem_array.shape}")

# FIX 2: För create_streamline_detailed funktionen
# Lägg till denna kontroll i början:

def create_streamline_detailed(start_point, flood_geom, flow_array, slope_array, geotransform):
    """Skapa en detaljerad streamline från en startpunkt"""
    # Säkerställ att alla nödvändiga parametrar är giltiga
    if flow_array is None or geotransform is None or flood_geom is None:
        print("VARNING: Ogiltiga parametrar i create_streamline_detailed")
        return [], 5.0  # Returnera tomma punkter och standardvärde för strength

    # ...resten av funktionen...

# FIX 3: För andra funktioner som använder dem_array
# Generell mall:

def någon_funktion_med_dem_array(...):
    dem_array = None  # Initiera variabeln
    try:
        # Original kod för att öppna och läsa DEM
        dem_ds = gdal.Open(dem_path)
        if dem_ds is None:
            raise Exception("Kunde inte öppna DEM-fil")
        
        dem_band = dem_ds.GetRasterBand(1)
        dem_array = dem_band.ReadAsArray()  # Nu är dem_array definierad
        
        # ...fortsätt med funktionen...
    except Exception as e:
        print(f"Fel vid inläsning av DEM: {str(e)}")
        # Skapa dummy-data om original dem_array inte kunde skapas
        dem_array = np.zeros((100, 100), dtype=float)
        # ...fortsätt funktionen med dummy-data...
        
    # Nu kan du använda dem_array säkert