#!/usr/bin/env python3
"""
Comprehensive Workflow Test - Real Scenario Simulation
-----------------------------------------------------
This test simulates the actual workflow that the user experiences
to identify why velocity fixes work in isolation but fail in practice.

This test will:
1. Create realistic test data that mimics the user's actual scenario
2. Run the complete workflow end-to-end
3. Identify where extreme velocities are still being generated
4. Test both Saint-Venant and hydraulic paths
5. Validate streamline generation and seeding
"""

import numpy as np
import os
import sys
import logging
import tempfile
import shutil
from osgeo import gdal, osr
from qgis.core import (
    QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY, QgsField,
    QgsVectorFileWriter, QgsWkbTypes, QgsCoordinateReferenceSystem, QgsFields
)
from PyQt5.QtCore import QVariant

# Add the current directory to the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def create_test_dem(width=200, height=200, output_path=None):
    """Create a realistic test DEM that mimics real-world terrain."""
    if output_path is None:
        output_path = os.path.join(tempfile.gettempdir(), "test_dem.tif")
    
    # Create realistic terrain with a river valley
    x = np.linspace(0, width-1, width)
    y = np.linspace(0, height-1, height)
    X, Y = np.meshgrid(x, y)
    
    # Base elevation (sloping terrain)
    base_elevation = 100 + 0.01 * Y  # Gentle slope from 100m to 102m
    
    # Add river valley (lower elevation channel)
    river_center_x = width // 2
    river_width = 30
    
    # Create river valley
    river_distance = np.abs(X - river_center_x)
    river_mask = river_distance < river_width
    river_depth = np.maximum(0, river_width - river_distance) / river_width * 5.0
    
    # Apply river valley
    elevation = base_elevation - river_depth
    
    # Add some terrain variation
    elevation += 0.5 * np.sin(X / 20) * np.cos(Y / 30)
    
    # Add some hills outside the river
    hill1 = 3.0 * np.exp(-((X - 50)**2 + (Y - 50)**2) / 1000)
    hill2 = 2.0 * np.exp(-((X - 150)**2 + (Y - 150)**2) / 800)
    elevation += hill1 + hill2
    
    # Ensure river is the lowest area
    elevation[river_mask] = np.minimum(elevation[river_mask], base_elevation[river_mask] - 2.0)
    
    # Create GeoTIFF
    driver = gdal.GetDriverByName('GTiff')
    dataset = driver.Create(output_path, width, height, 1, gdal.GDT_Float32)
    
    # Set geotransform (1m pixel size, starting at 0,0)
    geotransform = (0, 1, 0, 0, 0, -1)
    dataset.SetGeoTransform(geotransform)
    
    # Set projection (UTM Zone 33N)
    srs = osr.SpatialReference()
    srs.ImportFromEPSG(32633)
    dataset.SetProjection(srs.ExportToWkt())
    
    # Write data
    band = dataset.GetRasterBand(1)
    band.WriteArray(elevation.astype(np.float32))
    band.SetNoDataValue(-9999)
    
    dataset = None
    
    print(f"✅ Created test DEM: {output_path}")
    print(f"   Elevation range: {np.min(elevation):.2f}m to {np.max(elevation):.2f}m")
    print(f"   River valley at x={river_center_x}, depth up to 5m")
    
    return output_path, elevation

def create_test_flood_layer(dem_elevation, water_level=103.0, output_dir=None):
    """Create a test flood layer that covers the river valley and some floodplain."""
    if output_dir is None:
        output_dir = tempfile.gettempdir()
    
    output_path = os.path.join(output_dir, "test_flood.shp")
    
    # Remove existing files
    for ext in ['.shp', '.shx', '.dbf', '.prj', '.cpg']:
        file_path = output_path.replace('.shp', ext)
        if os.path.exists(file_path):
            os.remove(file_path)
    
    # Create flood polygon based on water level
    height, width = dem_elevation.shape
    flood_mask = dem_elevation < water_level
    
    # Find flood boundary (simplified - just create a large polygon covering flooded areas)
    flooded_indices = np.where(flood_mask)
    
    if len(flooded_indices[0]) == 0:
        raise ValueError(f"No flooding at water level {water_level}m")
    
    # Create bounding polygon of flooded area
    min_y, max_y = np.min(flooded_indices[0]), np.max(flooded_indices[0])
    min_x, max_x = np.min(flooded_indices[1]), np.max(flooded_indices[1])
    
    # Add some padding
    min_y = max(0, min_y - 5)
    max_y = min(height - 1, max_y + 5)
    min_x = max(0, min_x - 5)
    max_x = min(width - 1, max_x + 5)
    
    # Create polygon geometry (simple rectangle for this test)
    polygon_points = [
        QgsPointXY(min_x, max_y),  # Top-left
        QgsPointXY(max_x, max_y),  # Top-right
        QgsPointXY(max_x, min_y),  # Bottom-right
        QgsPointXY(min_x, min_y),  # Bottom-left
        QgsPointXY(min_x, max_y)   # Close polygon
    ]
    
    # Create shapefile
    fields = QgsFields()
    fields.append(QgsField("water_lvl", QVariant.Double))
    fields.append(QgsField("id", QVariant.Int))
    
    writer = QgsVectorFileWriter(
        output_path,
        "UTF-8",
        fields,
        QgsWkbTypes.Polygon,
        QgsCoordinateReferenceSystem("EPSG:32633"),
        "ESRI Shapefile"
    )
    
    if writer.hasError() != QgsVectorFileWriter.NoError:
        raise Exception(f"Error creating flood shapefile: {writer.errorMessage()}")
    
    # Create feature
    feature = QgsFeature(fields)
    feature.setGeometry(QgsGeometry.fromPolygonXY([polygon_points]))
    feature.setAttribute("water_lvl", water_level)
    feature.setAttribute("id", 1)
    
    writer.addFeature(feature)
    del writer
    
    # Load as QgsVectorLayer
    flood_layer = QgsVectorLayer(output_path, "Test Flood", "ogr")
    
    if not flood_layer.isValid():
        raise Exception(f"Created flood layer is not valid: {output_path}")
    
    flooded_pixels = np.sum(flood_mask)
    total_pixels = height * width
    flood_percentage = (flooded_pixels / total_pixels) * 100
    
    print(f"✅ Created test flood layer: {output_path}")
    print(f"   Water level: {water_level}m")
    print(f"   Flooded area: {flooded_pixels} pixels ({flood_percentage:.1f}% of DEM)")
    print(f"   Polygon bounds: x=[{min_x},{max_x}], y=[{min_y},{max_y}]")
    
    return flood_layer, flood_mask

def create_extreme_saint_venant_files(output_dir, dem_shape):
    """Create Saint-Venant velocity files with extreme velocities to test the fixes."""
    height, width = dem_shape
    
    # Create extreme velocity fields (hundreds of m/s)
    velocity_x = np.random.uniform(-500, 500, (height, width)).astype(np.float32)
    velocity_y = np.random.uniform(-500, 500, (height, width)).astype(np.float32)
    velocity_magnitude = np.sqrt(velocity_x**2 + velocity_y**2)
    
    max_vel = np.max(velocity_magnitude)
    print(f"🚨 Creating EXTREME Saint-Venant files with max velocity: {max_vel:.1f} m/s")
    
    # Save velocity files
    geotransform = (0, 1, 0, 0, 0, -1)
    srs = osr.SpatialReference()
    srs.ImportFromEPSG(32633)
    projection = srs.ExportToWkt()
    
    files_created = []
    
    for data, filename in [
        (velocity_x, "velocity_x.tif"),
        (velocity_y, "velocity_y.tif"),
        (velocity_magnitude, "velocity_magnitude.tif")
    ]:
        file_path = os.path.join(output_dir, filename)
        
        driver = gdal.GetDriverByName('GTiff')
        dataset = driver.Create(file_path, width, height, 1, gdal.GDT_Float32)
        dataset.SetGeoTransform(geotransform)
        dataset.SetProjection(projection)
        
        band = dataset.GetRasterBand(1)
        band.WriteArray(data)
        band.SetNoDataValue(-9999)
        
        dataset = None
        files_created.append(file_path)
        print(f"   📁 Created: {filename} (max: {np.max(data):.1f})")
    
    return files_created

def test_complete_workflow():
    """Test the complete workflow end-to-end."""
    logger = logging.getLogger("test_complete_workflow")
    logger.info("🧪 Starting complete workflow test...")
    
    # Create temporary directory for test files
    test_dir = tempfile.mkdtemp(prefix="floodengine_test_")
    print(f"📁 Test directory: {test_dir}")
    
    try:
        # Step 1: Create test DEM
        print("\n📊 STEP 1: Creating test DEM...")
        dem_path, dem_elevation = create_test_dem(output_path=os.path.join(test_dir, "test_dem.tif"))
        
        # Step 2: Create test flood layer
        print("\n🌊 STEP 2: Creating test flood layer...")
        flood_layer, flood_mask = create_test_flood_layer(
            dem_elevation, 
            water_level=103.0, 
            output_dir=test_dir
        )
        
        # Step 3: Test scenario 1 - Hydraulic approximation only
        print("\n🔧 STEP 3: Testing hydraulic approximation method...")
        test_hydraulic_method(dem_path, flood_layer, test_dir)
        
        # Step 4: Test scenario 2 - With extreme Saint-Venant files
        print("\n🚨 STEP 4: Testing with extreme Saint-Venant files...")
        saint_venant_files = create_extreme_saint_venant_files(test_dir, dem_elevation.shape)
        test_saint_venant_with_extreme_files(dem_path, flood_layer, test_dir)
        
        # Step 5: Test scenario 3 - With realistic Saint-Venant files
        print("\n✅ STEP 5: Testing with realistic Saint-Venant files...")
        create_realistic_saint_venant_files(test_dir, dem_elevation.shape, flood_mask)
        test_saint_venant_with_realistic_files(dem_path, flood_layer, test_dir)
        
        print("\n🎉 COMPLETE WORKFLOW TEST FINISHED!")
        return True
        
    except Exception as e:
        print(f"\n❌ WORKFLOW TEST FAILED: {str(e)}")
        import traceback
        traceback.print_exc()
        return False
        
    finally:
        # Cleanup
        try:
            shutil.rmtree(test_dir)
            print(f"🗑️ Cleaned up test directory: {test_dir}")
        except Exception as e:
            print(f"⚠️ Could not clean up test directory: {e}")

def test_hydraulic_method(dem_path, flood_layer, output_dir):
    """Test the hydraulic approximation method."""
    print("   🔧 Testing hydraulic approximation method...")
    
    try:
        # Import the fixed enhanced streamlines
        from enhanced_streamlines_fixed import create_enhanced_streamlines
        
        # Test with hydraulic method only
        result = create_enhanced_streamlines(
            dem_path=dem_path,
            flood_layer=flood_layer,
            output_folder=output_dir,
            flow_q=50.0,
            method="hydraulic"
        )
        
        if result is not None and result.isValid():
            print(f"   ✅ Hydraulic method: {result.featureCount()} streamlines created")
            return True
        else:
            print("   ❌ Hydraulic method: No valid streamlines created")
            return False
            
    except Exception as e:
        print(f"   ❌ Hydraulic method failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def test_saint_venant_with_extreme_files(dem_path, flood_layer, output_dir):
    """Test with extreme Saint-Venant files to verify they are rejected."""
    print("   🚨 Testing with extreme Saint-Venant files (should be rejected)...")
    
    try:
        # Import the fixed enhanced streamlines
        from enhanced_streamlines_fixed import create_enhanced_streamlines
        
        # Test - this should detect extreme velocities and fall back to hydraulic
        result = create_enhanced_streamlines(
            dem_path=dem_path,
            flood_layer=flood_layer,
            output_folder=output_dir,
            flow_q=50.0,
            method="saint_venant"  # Request Saint-Venant but should fallback
        )
        
        if result is not None and result.isValid():
            print(f"   ✅ Extreme Saint-Venant files correctly handled: {result.featureCount()} streamlines")
            return True
        else:
            print("   ❌ Failed to handle extreme Saint-Venant files")
            return False
            
    except Exception as e:
        print(f"   ❌ Extreme Saint-Venant test failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def create_realistic_saint_venant_files(output_dir, dem_shape, flood_mask):
    """Create realistic Saint-Venant velocity files for testing."""
    height, width = dem_shape
    
    # Create realistic velocity fields (0-3 m/s)
    velocity_x = np.zeros((height, width), dtype=np.float32)
    velocity_y = np.zeros((height, width), dtype=np.float32)
    
    # Add realistic flow patterns in flooded areas
    flooded_indices = np.where(flood_mask)
    
    if len(flooded_indices[0]) > 0:
        # Create flow towards the center and downstream
        center_x = width // 2
        
        for i, j in zip(flooded_indices[0], flooded_indices[1]):
            # Flow towards river center
            flow_x = (center_x - j) * 0.01  # Gentle flow towards center
            flow_y = 0.5  # Downstream flow
            
            # Add some randomness but keep it realistic
            flow_x += np.random.normal(0, 0.1)
            flow_y += np.random.normal(0, 0.1)
            
            # Limit to realistic velocities
            velocity_x[i, j] = np.clip(flow_x, -2.0, 2.0)
            velocity_y[i, j] = np.clip(flow_y, -2.0, 2.0)
    
    velocity_magnitude = np.sqrt(velocity_x**2 + velocity_y**2)
    
    max_vel = np.max(velocity_magnitude)
    mean_vel = np.mean(velocity_magnitude[velocity_magnitude > 0])
    
    print(f"✅ Creating REALISTIC Saint-Venant files:")
    print(f"   Max velocity: {max_vel:.3f} m/s")
    print(f"   Mean velocity: {mean_vel:.3f} m/s")
    
    # Remove old extreme files
    for filename in ["velocity_x.tif", "velocity_y.tif", "velocity_magnitude.tif"]:
        file_path = os.path.join(output_dir, filename)
        if os.path.exists(file_path):
            os.remove(file_path)
    
    # Save realistic velocity files
    geotransform = (0, 1, 0, 0, 0, -1)
    srs = osr.SpatialReference()
    srs.ImportFromEPSG(32633)
    projection = srs.ExportToWkt()
    
    files_created = []
    
    for data, filename in [
        (velocity_x, "velocity_x.tif"),
        (velocity_y, "velocity_y.tif"),
        (velocity_magnitude, "velocity_magnitude.tif")
    ]:
        file_path = os.path.join(output_dir, filename)
        
        driver = gdal.GetDriverByName('GTiff')
        dataset = driver.Create(file_path, width, height, 1, gdal.GDT_Float32)
        dataset.SetGeoTransform(geotransform)
        dataset.SetProjection(projection)
        
        band = dataset.GetRasterBand(1)
        band.WriteArray(data)
        band.SetNoDataValue(-9999)
        
        dataset = None
        files_created.append(file_path)
        print(f"   📁 Created: {filename}")
    
    return files_created

def test_saint_venant_with_realistic_files(dem_path, flood_layer, output_dir):
    """Test with realistic Saint-Venant files."""
    print("   ✅ Testing with realistic Saint-Venant files (should be accepted)...")
    
    try:
        # Import the fixed enhanced streamlines
        from enhanced_streamlines_fixed import create_enhanced_streamlines
        
        # Test - this should accept the realistic velocities
        result = create_enhanced_streamlines(
            dem_path=dem_path,
            flood_layer=flood_layer,
            output_folder=output_dir,
            flow_q=50.0,
            method="saint_venant"
        )
        
        if result is not None and result.isValid():
            print(f"   ✅ Realistic Saint-Venant files accepted: {result.featureCount()} streamlines")
            return True
        else:
            print("   ❌ Failed to use realistic Saint-Venant files")
            return False
            
    except Exception as e:
        print(f"   ❌ Realistic Saint-Venant test failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def test_velocity_validation_logic():
    """Test the velocity validation logic in isolation."""
    print("\n🔍 TESTING VELOCITY VALIDATION LOGIC...")
    
    try:
        from enhanced_streamlines_fixed import load_saint_venant_velocity_files
        
        # Test 1: Create a temporary directory with extreme velocities
        test_dir = tempfile.mkdtemp(prefix="velocity_test_")
        
        # Create extreme velocity files
        extreme_files = create_extreme_saint_venant_files(test_dir, (50, 50))
        
        # Test loading - should return None (rejected)
        result = load_saint_venant_velocity_files(test_dir)
        
        if result is None:
            print("   ✅ Extreme velocities correctly rejected")
            test1_passed = True
        else:
            max_vel = np.max(result['velocity_magnitude'])
            print(f"   ❌ Extreme velocities not rejected (max: {max_vel:.1f} m/s)")
            test1_passed = False
        
        # Cleanup
        shutil.rmtree(test_dir)
        
        # Test 2: Create realistic velocities
        test_dir2 = tempfile.mkdtemp(prefix="velocity_test2_")
        
        # Create simple flood mask
        flood_mask = np.ones((50, 50), dtype=bool)
        
        # Create realistic files
        realistic_files = create_realistic_saint_venant_files(test_dir2, (50, 50), flood_mask)
        
        # Test loading - should return valid results
        result2 = load_saint_venant_velocity_files(test_dir2)
        
        if result2 is not None:
            max_vel = np.max(result2['velocity_magnitude'])
            print(f"   ✅ Realistic velocities accepted (max: {max_vel:.3f} m/s)")
            test2_passed = True
        else:
            print("   ❌ Realistic velocities incorrectly rejected")
            test2_passed = False
        
        # Cleanup
        shutil.rmtree(test_dir2)
        
        return test1_passed and test2_passed
        
    except Exception as e:
        print(f"   ❌ Velocity validation test failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("=" * 80)
    print("COMPREHENSIVE WORKFLOW TEST - REAL SCENARIO SIMULATION")
    print("=" * 80)
    print("This test simulates the actual user workflow to identify")
    print("why velocity fixes work in isolation but fail in practice.")
    print("=" * 80)
    
    # Set up logging
    logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
    
    # Test 1: Velocity validation logic
    validation_test_passed = test_velocity_validation_logic()
    
    # Test 2: Complete workflow
    workflow_test_passed = test_complete_workflow()
    
    # Summary
    print("\n" + "=" * 80)
    print("COMPREHENSIVE TEST RESULTS")
    print("=" * 80)
    
    if validation_test_passed:
        print("✅ Velocity validation logic: PASSED")
    else:
        print("❌ Velocity validation logic: FAILED")
    
    if workflow_test_passed:
        print("✅ Complete workflow test: PASSED")
    else:
        print("❌ Complete workflow test: FAILED")
    
    if validation_test_passed and workflow_test_passed:
        print("\n🎉 ALL TESTS PASSED!")
        print("✅ The velocity fixes should now work correctly in the real workflow.")
    else:
        print("\n❌ SOME TESTS FAILED!")
        print("🔧 Additional fixes may be needed based on the test results above.")
    
    print("=" * 80)
