# FloodEngine Plugin - Deployment Guide
========================================

## Quick Start Guide

The FloodEngine plugin is now ready for deployment in QGIS. This guide covers installation and basic usage.

## 🔧 Installation

### Prerequisites
- QGIS 3.x with Python 3.7+
- Required Python packages:
  - numpy
  - gdal (included with QGIS)
  - PyQt5 (included with QGIS)

### Plugin Installation
1. Copy the entire `FloodEngine_fixed_v8` folder to your QGIS plugins directory:
   - Windows: `%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\`
   - Linux: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`
   - macOS: `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`

2. Restart QGIS
3. Enable the plugin in `Plugins > Manage and Install Plugins > Installed`

## 🌊 Using the Saint-Venant 2D Model

### Basic Workflow

1. **Prepare Input Data**
   - DEM raster (GeoTIFF format recommended)
   - Initial water level (meters)
   - Output directory for results

2. **Launch FloodEngine**
   - Open from `Plugins > FloodEngine > FloodEngine`
   - Select "2D Shallow Water" model type

3. **Configure Parameters**
   ```
   DEM Path: /path/to/your/elevation.tif
   Water Level: 2.0  (meters)
   Output Folder: /path/to/results/
   Time Steps: 100
   Total Time: 3600  (seconds)
   Manning's n: 0.035
   ```

4. **Run Simulation**
   - Click "Run Analysis"
   - Monitor progress in QGIS message bar
   - Results saved as GeoTIFF files

### Advanced Options

#### Dam Simulation
```python
# For dam break scenarios
dam_locations = [(x1, y1), (x2, y2)]  # Dam coordinates
dam_heights = [5.0, 3.0]  # Dam heights in meters
```

#### Source Points
```python
# For continuous water input
source_points = [
    {"x": 100, "y": 200, "flow_rate": 10.0},  # m³/s
    {"x": 150, "y": 250, "flow_rate": 5.0}
]
```

## 📊 Output Files

The plugin generates several output files:

### Water Depth Time Series
- `water_depth_t000.tif` - Initial conditions
- `water_depth_t001.tif` - Time step 1
- `water_depth_t002.tif` - Time step 2
- ... (one file per time step)

### Velocity Components
- `velocity_u_final.tif` - Final U velocity (east-west)
- `velocity_v_final.tif` - Final V velocity (north-south)

### Maximum Values
- `max_water_depth.tif` - Maximum depth throughout simulation
- `max_velocity.tif` - Maximum velocity magnitude

## 🛠️ Troubleshooting

### Common Issues and Solutions

#### 1. "No module named 'osgeo'" Error
**Solution**: Ensure you're running the plugin within QGIS, not standalone Python.

#### 2. "Invalid DEM path" Error
**Solution**: 
- Check file path is correct
- Ensure DEM is in supported format (GeoTIFF, ASCII grid)
- Verify file permissions

#### 3. Memory Issues with Large DEMs
**Solution**:
- Reduce DEM resolution
- Decrease number of time steps
- Use smaller spatial extent

#### 4. Simulation Takes Too Long
**Solution**:
- Reduce total simulation time
- Increase time step size (check stability)
- Use coarser DEM resolution

#### 5. Unrealistic Results
**Solution**:
- Check Manning's coefficient (typical: 0.02-0.1)
- Verify initial water level is reasonable
- Ensure DEM has proper elevation units (meters)

## 📈 Performance Optimization

### For Large Simulations
1. **Adaptive Time Stepping**: Enabled by default for stability
2. **Memory Management**: Arrays pre-allocated for efficiency
3. **Boundary Conditions**: Optimized outflow handling
4. **Numerical Stability**: CFL condition automatically enforced

### Recommended Settings
- **Small watersheds** (<1 km²): 100-500 time steps
- **Medium watersheds** (1-10 km²): 500-1000 time steps  
- **Large watersheds** (>10 km²): 1000+ time steps

## 🔍 Validation

### Checking Results
1. **Water Balance**: Total volume should be conserved
2. **Physical Realism**: Flow should follow topography
3. **Boundary Behavior**: Water should exit at outlets
4. **Stability**: No oscillations or unrealistic velocities

### Example Validation
```python
# Check maximum velocities are realistic
# Typical range: 0.1 - 10 m/s for flood scenarios
# Above 15 m/s may indicate numerical issues
```

## 📚 Technical Support

### Error Handling
The plugin includes comprehensive error handling:
- CSV parsing errors are caught and logged
- NoData values properly handled in visualization
- Parameter validation prevents crashes
- Context-aware error messages

### Logging
Check QGIS message log for detailed information:
- `View > Panels > Log Messages`
- Look for "FloodEngine" entries

## 🎯 Best Practices

1. **Data Preparation**
   - Use high-quality DEMs with consistent projection
   - Fill sinks and remove artifacts before simulation
   - Ensure proper NoData handling

2. **Parameter Selection**
   - Start with conservative Manning's coefficients
   - Use realistic initial conditions
   - Consider dam locations carefully

3. **Result Interpretation**
   - Always validate against known flood events
   - Check for physical consistency
   - Compare with other modeling approaches

## 📞 Support

For technical issues or questions:
- Check QGIS documentation for general plugin issues
- Review the `FINAL_STATUS_REPORT.md` for implementation details
- Examine the source code for advanced customization

---
**FloodEngine Plugin v1.0 - Production Ready**
