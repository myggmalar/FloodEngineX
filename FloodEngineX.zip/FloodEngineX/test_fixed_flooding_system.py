#!/usr/bin/env python3
"""
Test the fixed timestep system and water level generation
"""

import sys
import os
import numpy as np

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_water_level_generation():
    """Test the new water level generation logic"""
    
    print("🧪 Testing realistic water level generation...")
    
    # Simulate DEM data similar to the user's DEM (8.85m to 44.04m)
    dem_min, dem_max = 8.85, 44.04
    dem_range = dem_max - dem_min
    
    # Create fake elevation data for testing
    np.random.seed(42)  # For reproducible results
    valid_elevations = np.random.uniform(dem_min, dem_max, 1000)
    
    # Calculate percentiles like the improved code does
    dem_5th = np.percentile(valid_elevations, 5)
    dem_25th = np.percentile(valid_elevations, 25) 
    dem_50th = np.percentile(valid_elevations, 50)
    dem_75th = np.percentile(valid_elevations, 75)
    
    print(f"\n📊 Simulated DEM Statistics (like user's real DEM):")
    print(f"   Range: {dem_min:.2f}m to {dem_max:.2f}m")
    print(f"   5th percentile: {dem_5th:.2f}m")
    print(f"   25th percentile: {dem_25th:.2f}m") 
    print(f"   50th percentile (median): {dem_50th:.2f}m")
    print(f"   75th percentile: {dem_75th:.2f}m")
    
    # Test the new water level generation logic
    output_timesteps = 10
    
    start_level = dem_5th + 0.1
    end_level = dem_50th + 2.0
    max_reasonable_level = dem_min + min(20.0, dem_range * 0.4)
    end_level = min(end_level, max_reasonable_level)
    
    water_levels = list(np.linspace(start_level, end_level, output_timesteps))
    
    print(f"\n🌊 NEW Water Level Generation (FIXED):")
    print(f"   Start level: {water_levels[0]:.2f}m")
    print(f"   End level: {water_levels[-1]:.2f}m")
    print(f"   Progression: {', '.join([f'{wl:.1f}m' for wl in water_levels])}")
    
    # Calculate how much of the terrain will flood at each level
    flood_percentages = []
    for wl in water_levels:
        flooded_area = np.sum(valid_elevations <= wl) / len(valid_elevations) * 100
        flood_percentages.append(flooded_area)
    
    print(f"\n📈 Flooding Analysis:")
    for i, (wl, pct) in enumerate(zip(water_levels, flood_percentages)):
        print(f"   Step {i+1:2d}: {wl:5.1f}m water → {pct:4.1f}% of terrain flooded")
    
    print(f"\n✅ This will create REALISTIC flooding that actually shows results!")
    
    # Compare with the old broken system
    print(f"\n❌ OLD BROKEN System (what was causing 'No flooded area found'):")
    old_base = dem_min + 0.5  # 9.35m
    old_max = dem_min + min(10.0, dem_range * 0.3)  # 19.15m
    old_levels = list(np.linspace(old_base, old_max, 5))
    print(f"   Range: {old_levels[0]:.1f}m to {old_levels[-1]:.1f}m")
    
    for wl in old_levels:
        flooded_area = np.sum(valid_elevations <= wl) / len(valid_elevations) * 100
        print(f"   {wl:5.1f}m water → {flooded_area:4.1f}% flooded (TOO LITTLE!)")

def test_time_progression():
    """Test the new time-based progression system"""
    
    print(f"\n🕐 Testing realistic time progression...")
    
    simulation_duration_hours = 24
    output_timesteps = 10
    flow_rate = 150.0
    
    print(f"\n⏱️ Simulation Parameters:")
    print(f"   Duration: {simulation_duration_hours} hours")
    print(f"   Outputs: {output_timesteps} timesteps")
    print(f"   Flow rate: {flow_rate} m³/s")
    
    print(f"\n📊 Time-based Flood Progression:")
    
    for i in range(output_timesteps):
        timestep = i + 1
        output_interval_hours = simulation_duration_hours / output_timesteps
        simulation_time_hours = timestep * output_interval_hours
        
        # Calculate progression factors (like the improved code)
        simulation_time_fraction = simulation_time_hours / simulation_duration_hours
        time_factor = 1.0 - np.exp(-3.0 * simulation_time_fraction)
        
        flow_factor = min(2.0, 1.0 + (flow_rate - 50.0) / 100.0)
        depth_progression = time_factor * flow_factor
        
        print(f"   Step {timestep:2d}: {simulation_time_hours:5.1f}h ({simulation_time_fraction*100:5.1f}% complete) → depth factor: {depth_progression:.2f}")
    
    print(f"\n✅ This creates realistic time-based progression instead of instant flooding!")

def main():
    """Run all tests"""
    
    print("🚀 FloodEngine Fixed Timestep & Water Level System Test")
    print("=" * 60)
    
    test_water_level_generation()
    test_time_progression()
    
    print("\n" + "=" * 60)
    print("✅ SUMMARY OF FIXES:")
    print("   🎯 Water levels now based on actual DEM elevations")
    print("   ⏱️ Time-based flood progression (not instant)")
    print("   🌊 Realistic flooding that will actually show results")
    print("   📊 User-friendly timestep controls in UI")
    print("   💧 Physics-based depth progression over time")
    print("   🔧 Flow rate influences flood development speed")
    
    print("\n💡 The user should now see:")
    print("   - Visible flood areas (not empty layers)")
    print("   - Realistic progression over time")
    print("   - Controllable simulation parameters")
    print("   - Proper time delays (not instant completion)")

if __name__ == "__main__":
    main()
