"""
Syntax checker for FloodEngine files
This script checks for syntax errors in key Python files
"""
import os
import py_compile
import sys

# Define key files that need to be checked
KEY_FILES = [
    "floodengine_ui.py",
    "floodengine.py",
    "model_hydraulic.py",
    "flow_direction_flood_fixed.py"
]

def check_syntax(file_path):
    """Check syntax of a Python file"""
    try:
        py_compile.compile(file_path, doraise=True)
        print(f"✅ {file_path}: No syntax errors")
        return True
    except py_compile.PyCompileError as e:
        print(f"❌ {file_path}: Syntax error: {str(e)}")
        return False
    except Exception as e:
        print(f"❓ {file_path}: Unexpected error: {str(e)}")
        return False

def main():
    """Main function"""
    all_ok = True
    for file_name in KEY_FILES:
        file_path = os.path.join(os.path.dirname(__file__), file_name)
        if not os.path.exists(file_path):
            print(f"⚠️ {file_path}: File not found")
            all_ok = False
            continue
            
        if not check_syntax(file_path):
            all_ok = False
    
    if all_ok:
        print("\n✅ All files passed syntax check!")
        return 0
    else:
        print("\n❌ Some files have syntax errors")
        return 1

if __name__ == "__main__":
    sys.exit(main())
