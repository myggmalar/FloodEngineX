#!/usr/bin/env python3
"""
Comprehensive test of all channel-based flood improvements
"""

import os
import sys
import numpy as np
from osgeo import gdal

# Add plugin directory to path
plugin_dir = r"c:\Plugin\VSCode\Alt2\FloodEngine_fixed_v8"
if plugin_dir not in sys.path:
    sys.path.insert(0, plugin_dir)

def comprehensive_flood_test():
    """Test all aspects of the improved flood algorithm"""
    
    print("🧪 COMPREHENSIVE CHANNEL-BASED FLOOD TEST")
    print("=" * 60)
    
    # Test 1: Module imports
    print("\n1. TESTING MODULE IMPORTS...")
    try:
        from model_hydraulic_q import calculate_water_level_from_flow
        from model_hydraulic import create_proper_flow_flood_mask, create_simple_streamlines
        print("✅ All modules imported successfully")
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False
    
    # Test 2: Synthetic DEM test
    print("\n2. TESTING WITH SYNTHETIC CHANNEL DEM...")
    
    # Create a synthetic DEM with a clear channel
    width, height = 200, 200
    dem_synthetic = np.zeros((height, width), dtype=np.float32)
    
    # Create a terrain with a central valley (channel)
    for y in range(height):
        for x in range(width):
            # Base elevation rises from center
            dist_from_center = abs(x - width//2)
            base_elevation = 10.0 + dist_from_center * 0.05  # Gentle slope from center
            
            # Add a central channel (river)
            if abs(x - width//2) < 10:  # 20-pixel wide channel
                channel_depth = 2.0 - abs(x - width//2) * 0.15  # Deeper in center
                base_elevation -= channel_depth
            
            dem_synthetic[y, x] = base_elevation
    
    # Add some terrain variation
    np.random.seed(42)
    dem_synthetic += np.random.normal(0, 0.1, dem_synthetic.shape)
    
    # Valid mask (all valid for synthetic data)
    valid_mask = np.ones_like(dem_synthetic, dtype=bool)
    
    # Test water level calculation with synthetic data
    print("\n3. TESTING WATER LEVEL CALCULATION...")
    
    # Create synthetic geotransform for testing
    geotransform = (0, 1.0, 0, 0, 0, -1.0)  # 1m pixel size
    
    # Analyze synthetic DEM
    min_elev = np.min(dem_synthetic)
    max_elev = np.max(dem_synthetic)
    median_elev = np.median(dem_synthetic)
    percentile_5 = np.percentile(dem_synthetic, 5)
    percentile_10 = np.percentile(dem_synthetic, 10)
    percentile_15 = np.percentile(dem_synthetic, 15)
    
    print(f"📊 Synthetic DEM statistics:")
    print(f"   Range: {min_elev:.2f}m to {max_elev:.2f}m")
    print(f"   Channel level (5%): {percentile_5:.2f}m")
    print(f"   Channel system (10%): {percentile_10:.2f}m")
    print(f"   Extended channels (15%): {percentile_15:.2f}m")
    print(f"   Median terrain: {median_elev:.2f}m")
    
    # Simulate realistic water level calculation
    channel_elevation = percentile_10  # Use 10th percentile as channel level
    flood_depth = 2.0  # 2m flood depth
    test_water_level = channel_elevation + flood_depth
    
    print(f"\n   Simulated water level: {test_water_level:.2f}m")
    print(f"   (Channel: {channel_elevation:.2f}m + {flood_depth:.2f}m flood depth)")
    
    # Test 4: Flood mask creation
    print("\n4. TESTING FLOOD MASK CREATION...")
    
    flood_mask = create_proper_flow_flood_mask(dem_synthetic, test_water_level, valid_mask)
    
    # Analyze flood results
    total_cells = width * height
    flooded_cells = np.sum(flood_mask)
    flood_percentage = (flooded_cells / total_cells) * 100
    
    print(f"📊 Flood mask results:")
    print(f"   Total cells: {total_cells}")
    print(f"   Flooded cells: {flooded_cells}")
    print(f"   Flood coverage: {flood_percentage:.2f}%")
    
    if flooded_cells > 0:
        flooded_elevations = dem_synthetic[flood_mask == 1]
        min_flood = np.min(flooded_elevations)
        max_flood = np.max(flooded_elevations)
        avg_flood = np.mean(flooded_elevations)
        
        print(f"   Flooded elevation range: {min_flood:.2f}m to {max_flood:.2f}m")
        print(f"   Average flooded elevation: {avg_flood:.2f}m")
        print(f"   Water level clearance: {test_water_level - avg_flood:.2f}m")
        
        # Check if flooding is following the channel
        center_column = width // 2
        channel_flooded = np.sum(flood_mask[:, center_column-5:center_column+5])
        total_channel_cells = height * 10  # 10 pixel wide channel
        channel_flood_percentage = (channel_flooded / total_channel_cells) * 100
        
        print(f"   Channel flooding: {channel_flood_percentage:.1f}% of channel area")
        
        # Validation checks
        success_criteria = {
            "Reasonable flood extent": 5 <= flood_percentage <= 50,
            "Channel focused": channel_flood_percentage > 80,
            "Below water level": max_flood < test_water_level,
            "Realistic clearance": test_water_level - avg_flood > 0.5
        }
        
        print(f"\n✅ VALIDATION RESULTS:")
        all_passed = True
        for criterion, passed in success_criteria.items():
            status = "✅" if passed else "❌"
            print(f"   {status} {criterion}: {passed}")
            if not passed:
                all_passed = False
        
        if all_passed:
            print(f"\n🎉 ALL TESTS PASSED - Channel-based flooding is working correctly!")
            return True
        else:
            print(f"\n⚠️ Some tests failed - Algorithm needs further tuning")
            return False
    else:
        print(f"\n❌ NO FLOODING OCCURRED - Check water level or algorithm")
        return False

def test_with_real_dem(dem_path):
    """Test with a real DEM file if provided"""
    
    if not os.path.exists(dem_path):
        print(f"⚠️ DEM file not found: {dem_path}")
        return False
    
    print(f"\n5. TESTING WITH REAL DEM: {os.path.basename(dem_path)}")
    
    try:
        from model_hydraulic_q import calculate_water_level_from_flow
        from model_hydraulic import create_proper_flow_flood_mask
        
        # Test realistic flow scenarios
        flow_rates = [50, 100, 200, 500]  # m³/s
        
        for flow_q in flow_rates:
            print(f"\n   Testing flow rate: {flow_q} m³/s")
            
            water_level = calculate_water_level_from_flow(flow_q, dem_path)
            print(f"   → Water level: {water_level:.2f}m")
            
            # Load DEM
            dem_ds = gdal.Open(dem_path)
            dem_array = dem_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
            nodata = dem_ds.GetRasterBand(1).GetNoDataValue()
            if nodata is None:
                nodata = -9999
            
            valid_mask = (dem_array != nodata) & ~np.isnan(dem_array)
            
            # Test flood mask
            flood_mask = create_proper_flow_flood_mask(dem_array, water_level, valid_mask)
            
            flooded_cells = np.sum(flood_mask)
            total_valid = np.sum(valid_mask)
            flood_percentage = (flooded_cells / total_valid) * 100
            
            print(f"   → Flood coverage: {flood_percentage:.2f}%")
            
            if flooded_cells > 0:
                flooded_elevations = dem_array[flood_mask == 1]
                avg_flood = np.mean(flooded_elevations)
                print(f"   → Avg flooded elevation: {avg_flood:.2f}m")
                print(f"   → Clearance: {water_level - avg_flood:.2f}m")
            
        return True
        
    except Exception as e:
        print(f"❌ Real DEM test failed: {e}")
        return False

if __name__ == "__main__":
    # Run synthetic test
    success = comprehensive_flood_test()
    
    # If you have a real DEM, uncomment and update this path:
    # real_dem_path = r"C:\path\to\your\real\dem.tif"
    # test_with_real_dem(real_dem_path)
    
    if success:
        print(f"\n🎉 CHANNEL-BASED FLOOD ALGORITHM IS READY!")
        print(f"   - Water levels are calculated from channel elevations")
        print(f"   - Flooding starts from the deepest channels")
        print(f"   - Flood extent is realistic and follows natural drainage")
        print(f"   - Test the plugin in QGIS to see the improvements!")
    else:
        print(f"\n⚠️ ALGORITHM NEEDS FURTHER ADJUSTMENT")
        print(f"   Please review the test output and make necessary changes")
