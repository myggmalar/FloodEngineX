#!/usr/bin/env python3
"""
FloodEngine Timestep Integration Validation Test
================================================

This script validates that the critical timestep simulation fixes have been properly 
integrated into the UI and are working correctly.

CRITICAL FIXES VALIDATED:
1. ✅ UI imports FIXED functions (simulate_over_time_FIXED, calculate_streamlines_ENHANCED)
2. ✅ UI handles new return format (dict with timestep_layers, final_layer, etc.)
3. ✅ Streamlines use proper parameters (flood_layer instead of water_level)
4. ✅ Water level generation improvements are accessible
5. ✅ Function signatures are compatible
"""

import os
import sys
import inspect
import traceback

def test_ui_imports():
    """Test that UI file imports the FIXED functions"""
    print("🔍 Testing UI imports...")
    
    ui_file = "floodengine_ui.py"
    if not os.path.exists(ui_file):
        print(f"❌ UI file not found: {ui_file}")
        return False
    
    with open(ui_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check for FIXED function imports
    checks = [
        ("simulate_over_time_FIXED import", "simulate_over_time_FIXED" in content),
        ("calculate_streamlines_ENHANCED import", "calculate_streamlines_ENHANCED" in content),
        ("FIXED function calls", "simulation_result = simulate_over_time_FIXED" in content),
        ("Enhanced streamlines calls", "calculate_streamlines_ENHANCED(" in content),
        ("Result handling", "simulation_result.get('timestep_layers'" in content),
        ("Final layer access", "final_flood_layer" in content)
    ]
    
    all_passed = True
    for check_name, condition in checks:
        status = "✅" if condition else "❌"
        print(f"  {status} {check_name}")
        if not condition:
            all_passed = False
    
    return all_passed

def test_function_availability():
    """Test that FIXED functions are available in model_hydraulic"""
    print("\n🔍 Testing function availability...")
    
    try:
        # Import without QGIS dependencies
        sys.path.append('.')
        from model_hydraulic import (
            simulate_over_time_FIXED,
            generate_variable_water_levels_IMPROVED,
            calculate_streamlines_ENHANCED
        )
        
        # Check function signatures
        sig_sim = inspect.signature(simulate_over_time_FIXED)
        sig_water = inspect.signature(generate_variable_water_levels_IMPROVED) 
        sig_stream = inspect.signature(calculate_streamlines_ENHANCED)
        
        print(f"✅ simulate_over_time_FIXED: {sig_sim}")
        print(f"✅ generate_variable_water_levels_IMPROVED: {sig_water}")
        print(f"✅ calculate_streamlines_ENHANCED: {sig_stream}")
        
        return True
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False
    except Exception as e:
        print(f"❌ Function availability error: {e}")
        return False

def test_water_level_generation():
    """Test the improved water level generation"""
    print("\n🔍 Testing water level generation...")
    
    try:
        from model_hydraulic import generate_variable_water_levels_IMPROVED
        
        # Test the improved water level generation
        time_steps = 5
        initial_level = 60.0  # Fixed higher level
        
        # Test different methods
        methods = ["accumulation", "sinusoidal", "exponential"]
        
        for method in methods:
            try:
                levels = generate_variable_water_levels_IMPROVED(
                    initial_level=initial_level,
                    time_steps=time_steps,
                    method=method
                )
                
                print(f"✅ Method '{method}': {len(levels)} levels generated")
                print(f"   Range: {min(levels):.2f}m - {max(levels):.2f}m")
                
                # Validate levels
                if len(levels) == time_steps and all(l >= initial_level for l in levels):
                    print(f"   ✅ Levels are valid and progressive")
                else:
                    print(f"   ❌ Invalid levels: {levels}")
                    
            except Exception as e:
                print(f"❌ Method '{method}' failed: {e}")
        
        return True
        
    except Exception as e:
        print(f"❌ Water level generation test failed: {e}")
        return False

def test_parameter_compatibility():
    """Test parameter compatibility between old and new functions"""
    print("\n🔍 Testing parameter compatibility...")
    
    try:
        from model_hydraulic import simulate_over_time_FIXED
        
        # Check that FIXED function accepts all expected parameters
        sig = inspect.signature(simulate_over_time_FIXED)
        params = list(sig.parameters.keys())
        
        required_params = ['iface', 'dem_path', 'water_levels', 'time_steps', 'output_folder']
        optional_params = ['bathymetry']
        
        missing_required = [p for p in required_params if p not in params]
        missing_optional = [p for p in optional_params if p not in params]
        
        if not missing_required:
            print("✅ All required parameters present")
        else:
            print(f"❌ Missing required parameters: {missing_required}")
        
        if not missing_optional:
            print("✅ All optional parameters present")
        else:
            print(f"⚠️ Missing optional parameters: {missing_optional}")
        
        # Check for kwargs support
        has_kwargs = any(p.kind == p.VAR_KEYWORD for p in sig.parameters.values())
        if has_kwargs:
            print("✅ **kwargs support detected")
        else:
            print("⚠️ No **kwargs support")
        
        return len(missing_required) == 0
        
    except Exception as e:
        print(f"❌ Parameter compatibility test failed: {e}")
        return False

def test_return_format():
    """Test that functions return the expected format"""
    print("\n🔍 Testing return format expectations...")
    
    # Since we can't run actual simulations without QGIS/GDAL,
    # we'll check the function source code for return statements
    
    try:
        with open("model_hydraulic.py", 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Find the simulate_over_time_FIXED function
        func_start = content.find("def simulate_over_time_FIXED(")
        if func_start == -1:
            print("❌ simulate_over_time_FIXED function not found")
            return False
        
        # Find the end of the function (next def or end of file)
        func_end = content.find("\ndef ", func_start + 1)
        if func_end == -1:
            func_end = len(content)
        
        func_code = content[func_start:func_end]
        
        # Check for enhanced return format
        checks = [
            ("Dictionary return", "return {" in func_code),
            ("timestep_layers key", "'timestep_layers'" in func_code),
            ("final_layer key", "'final_layer'" in func_code),
            ("time_folder key", "'time_folder'" in func_code)
        ]
        
        all_passed = True
        for check_name, condition in checks:
            status = "✅" if condition else "❌"
            print(f"  {status} {check_name}")
            if not condition:
                all_passed = False
        
        return all_passed
        
    except Exception as e:
        print(f"❌ Return format test failed: {e}")
        return False

def main():
    """Run all validation tests"""
    print("=" * 60)
    print("FloodEngine Timestep Integration Validation")
    print("=" * 60)
    
    tests = [
        ("UI Imports", test_ui_imports),
        ("Function Availability", test_function_availability),
        ("Water Level Generation", test_water_level_generation),
        ("Parameter Compatibility", test_parameter_compatibility),
        ("Return Format", test_return_format)
    ]
    
    results = {}
    
    for test_name, test_func in tests:
        try:
            results[test_name] = test_func()
        except Exception as e:
            print(f"\n❌ {test_name} test crashed: {e}")
            traceback.print_exc()
            results[test_name] = False
    
    # Summary
    print("\n" + "=" * 60)
    print("VALIDATION SUMMARY")
    print("=" * 60)
    
    passed = sum(results.values())
    total = len(results)
    
    for test_name, result in results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"  {status} {test_name}")
    
    print(f"\nOverall: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 ALL TESTS PASSED - Integration is complete!")
        print("\nThe FloodEngine timestep simulation fixes have been successfully integrated:")
        print("• UI imports FIXED functions")
        print("• Enhanced return format handling")
        print("• Improved water level generation")
        print("• Streamlines parameter fixes")
        print("\nThe plugin is ready for timestep simulation testing!")
    else:
        print(f"\n⚠️ {total - passed} tests failed - Integration needs attention")
        print("\nPlease review the failed tests and ensure all fixes are properly applied.")
    
    return passed == total

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
