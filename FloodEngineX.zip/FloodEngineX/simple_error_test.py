#!/usr/bin/env python3
# Simple error diagnostic for FloodEngine

import traceback
import os

print("=== FLOODENGINE ERROR DIAGNOSTIC ===")

# Test 1: Check if model_type is undefined somewhere
print("\n1. Testing model_type variable issue...")
try:
    # Try to import and see if we get NameError on model_type
    import floodengine_ui
    print("✅ floodengine_ui imported successfully")
    
    # Check if there's any reference to bare model_type (not self.model_type)
    import model_hydraulic
    print("✅ model_hydraulic imported successfully")
    
except NameError as e:
    if 'model_type' in str(e):
        print(f"❌ Found model_type NameError: {e}")
    else:
        print(f"❌ NameError (not model_type): {e}")
except Exception as e:
    print(f"❌ Import error: {e}")

# Test 2: Check for int() conversion issues
print("\n2. Testing int() conversion issues...")
try:
    # Test what happens when we try to convert 'depth' to int
    test_value = 'depth'
    int_result = int(test_value)
    print(f"✅ Converted '{test_value}' to int: {int_result}")
except ValueError as e:
    print(f"❌ int() conversion error with 'depth': {e}")
    print("   This matches the expected error pattern!")

# Test 3: Test CSV parsing with problematic data
print("\n3. Testing CSV parsing...")
try:
    import csv
    import io
    
    # Create a test CSV with 'depth' in header
    test_csv = '''x,y,depth,elevation
100,200,depth,50
101,201,5.5,45
102,202,3.2,47'''
    
    csv_file = io.StringIO(test_csv)
    reader = csv.reader(csv_file)
    header = next(reader)
    print(f"✅ CSV header read: {header}")
    
    # Test parsing rows
    for i, row in enumerate(reader):
        print(f"   Row {i+1}: {row}")
        # Try to convert each value
        for j, value in enumerate(row):
            try:
                # This is where the error might occur if code tries int() on header values
                if value.strip().replace('.', '').replace('-', '').isdigit():
                    float_val = float(value.strip())
                    print(f"     Column {j} ('{value}') -> {float_val}")
                else:
                    print(f"     Column {j} ('{value}') -> non-numeric")
            except Exception as conv_error:
                print(f"     ❌ Conversion error for '{value}': {conv_error}")

except Exception as e:
    print(f"❌ CSV parsing error: {e}")
    traceback.print_exc()

# Test 4: Test water level variation in timesteps
print("\n4. Testing timestep water level variation...")
try:
    # Test the timestep generation
    import numpy as np
    
    start_level = 10.0
    end_level = 15.0
    num_steps = 5
    
    # This should create different levels per timestep
    water_levels = np.linspace(start_level, end_level, num_steps)
    print(f"✅ Generated water levels: {water_levels}")
    
    if len(set(water_levels)) == 1:
        print("❌ All water levels are the same!")
    else:
        print("✅ Water levels vary properly")

except Exception as e:
    print(f"❌ Timestep generation error: {e}")

print("\n=== DIAGNOSTIC COMPLETE ===")
