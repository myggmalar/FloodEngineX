#!/usr/bin/env python3
"""
UI Patch: Fix timestep result handling
"""

import os
import re

def patch_ui_timestep_handling():
    """Patch the UI to show enhanced timestep messages"""
    
    ui_file = "floodengine_ui.py"
    if not os.path.exists(ui_file):
        print(f"❌ UI file not found: {ui_file}")
        return False
    
    with open(ui_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Use regex to find and replace the specific patterns
    pattern1 = r'(print\(f"✅ Timestep simulation created \{len\(timestep_layers\)\} layers"\))'
    replacement1 = '''timestep_results = simulation_result.get('timestep_results', [])
                        successful_count = simulation_result.get('successful_timesteps', 0)
                        total_count = simulation_result.get('total_timesteps', 0)
                        print(f"✅ Timestep simulation created {len(timestep_layers)} layers ({successful_count}/{total_count} successful)")
                        
                        # Show success message
                        if timestep_layers:
                            self.iface.messageBar().pushSuccess(
                                "FloodEngine", 
                                f"Timestep simulation complete: {len(timestep_layers)} flood layers created and added to project"
                            )'''
    
    # Apply the replacement
    new_content = re.sub(pattern1, replacement1, content)
    
    if new_content != content:
        with open(ui_file, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print("✅ UI timestep handling patched successfully")
        return True
    else:
        print("⚠️ No changes needed or pattern not found")
        return False

if __name__ == "__main__":
    patch_ui_timestep_handling()
