#!/usr/bin/env python3
"""
Launch Time Series Animation Dialog - Standalone Mode
----------------------------------------------------
Launches the time series animation dialog in standalone mode with a proper Qt event loop.
Use this script when you want to run the animation dialog independently.
"""

import os
import sys
import logging
from pathlib import Path

# Add the FloodEngineX directory to the path
sys.path.insert(0, str(Path(__file__).parent))

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def launch_animation_with_event_loop(results_data, output_folder):
    """
    Launch animation dialog with a proper Qt event loop.
    
    Parameters:
        results_data (dict): Simulation results with time series data
        output_folder (str): Path to animation output folder
    """
    try:
        logger.info("🎬 Starting standalone animation dialog with event loop...")
        
        # Import Qt components
        from PyQt5.QtWidgets import QApplication
        from time_series_animator import TimeSeriesAnimator
        
        # Create QApplication
        app = QApplication(sys.argv)
        app.setApplicationName("FloodEngine Time Series Animation")
        logger.info("📱 Created QApplication with event loop")
        
        # Create and show the animation dialog
        animator = TimeSeriesAnimator(results_data, output_folder)
        animator.setWindowTitle("FloodEngine - Time Series Animation")
        animator.resize(1200, 800)  # Set a good default size
        animator.show()
        animator.raise_()  # Bring to front
        animator.activateWindow()  # Make it active
        
        logger.info("✅ Animation dialog launched successfully!")
        logger.info("🎮 Use the controls to play/pause and navigate through timesteps")
        logger.info("📍 Click on the map to sample depth and elevation data")
        logger.info("❌ Close the dialog or press Ctrl+C to exit")
        
        # Run the event loop
        logger.info("🔄 Starting Qt event loop...")
        exit_code = app.exec_()
        logger.info(f"🏁 Animation dialog closed with exit code: {exit_code}")
        
        return exit_code
        
    except ImportError as e:
        logger.error(f"❌ Could not import Qt components: {e}")
        logger.info("💡 Install PyQt5 to use animation controls: pip install PyQt5")
        logger.info(f"📁 Animation files are available in: {output_folder}")
        return 1
        
    except Exception as e:
        logger.error(f"❌ Failed to launch animation dialog: {e}")
        logger.info(f"📁 Animation files are available in: {output_folder}")
        logger.info("📖 Check ANIMATION_INSTRUCTIONS.md for manual setup")
        return 1

def load_results_from_folder(results_folder):
    """
    Load simulation results from a folder for animation.
    
    Parameters:
        results_folder (str): Path to folder containing simulation results
        
    Returns:
        dict: Results data for animation, or None if not found
    """
    try:
        # Look for time series animation folder
        animation_folder = os.path.join(results_folder, "time_series_animation")
        if not os.path.exists(animation_folder):
            logger.error(f"❌ Animation folder not found: {animation_folder}")
            return None
            
        # Look for rasters folder
        rasters_folder = os.path.join(animation_folder, "rasters")
        if not os.path.exists(rasters_folder):
            logger.error(f"❌ Rasters folder not found: {rasters_folder}")
            return None
            
        # Count raster files to determine number of timesteps
        depth_files = [f for f in os.listdir(rasters_folder) if f.startswith("depth_") and f.endswith(".tif")]
        num_timesteps = len(depth_files)
        
        if num_timesteps == 0:
            logger.error(f"❌ No depth raster files found in: {rasters_folder}")
            return None
            
        logger.info(f"✅ Found {num_timesteps} timesteps in animation folder")
        
        # Create minimal results data structure
        results_data = {
            'num_timesteps': num_timesteps,
            'total_time': num_timesteps * 10.0,  # Assume 10 seconds per timestep
            'grid_shape': (100, 100),  # Will be determined from raster
            'geotransform': (0, 1, 0, 100, 0, -1),  # Will be determined from raster
            'animation_folder': animation_folder
        }
        
        return results_data
        
    except Exception as e:
        logger.error(f"❌ Error loading results from folder: {e}")
        return None

def main():
    """Main function to launch the animation dialog."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Launch FloodEngine Time Series Animation")
    parser.add_argument("results_folder", nargs="?", 
                       help="Path to folder containing simulation results")
    parser.add_argument("--test", action="store_true",
                       help="Run with test data")
    
    args = parser.parse_args()
    
    if args.test:
        logger.info("🧪 Creating test data for animation...")
        # Create simple test data
        results_data = {
            'num_timesteps': 10,
            'total_time': 100.0,
            'grid_shape': (50, 50),
            'geotransform': (0, 1, 0, 50, 0, -1),
            'animation_folder': None  # Will create test data
        }
        output_folder = "test_animation_output"
        
    elif args.results_folder:
        logger.info(f"📁 Loading results from: {args.results_folder}")
        results_data = load_results_from_folder(args.results_folder)
        if results_data is None:
            logger.error("❌ Could not load results data")
            return 1
        output_folder = os.path.join(args.results_folder, "time_series_animation")
        
    else:
        logger.error("❌ No results folder specified")
        parser.print_help()
        return 1
    
    # Launch the animation dialog
    return launch_animation_with_event_loop(results_data, output_folder)

if __name__ == "__main__":
    sys.exit(main())
