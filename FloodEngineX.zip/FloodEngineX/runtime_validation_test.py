#!/usr/bin/env python3
"""
FloodEngine Runtime Validation Test
Final validation to ensure all AttributeError issues are resolved
"""

import sys
import os
import importlib.util
import traceback

def test_ui_module_import():
    """Test that the UI module can be imported without errors"""
    print("🔍 Testing UI Module Import...")
    print("=" * 50)
    
    try:
        # Import the main UI module
        from floodengine_ui import FloodEngineDialog
        print("✅ FloodEngineDialog imported successfully")
        return True
    
    except ImportError as e:
        print(f"❌ Import Error: {e}")
        return False
    except SyntaxError as e:
        print(f"❌ Syntax Error: {e}")
        print(f"   Line {e.lineno}: {e.text}")
        return False
    except Exception as e:
        print(f"❌ Unexpected Error: {type(e).__name__}: {e}")
        traceback.print_exc()
        return False

def test_connect_signals_method():
    """Test that connect_signals method exists and has all required UI elements"""
    print("\n🔗 Testing connect_signals Method...")
    print("=" * 50)
    
    try:
        from floodengine_ui import FloodEngineDialog
        
        # Check if connect_signals method exists
        if not hasattr(FloodEngineDialog, 'connect_signals'):
            print("❌ connect_signals method not found")
            return False
        
        print("✅ connect_signals method exists")
        
        # Read the method source to check for required elements
        import inspect
        source = inspect.getsource(FloodEngineDialog.connect_signals)
        
        # Check for key UI elements that were previously missing
        required_elements = [
            'adv_hydrograph_btn',
            'adv_buildings_btn', 
            'adv_soil_btn',
            'adv_enable_groundwater',
            'adv_enable_urban',
            'adv_hydraulic_conductivity',
            'adv_storage_coefficient',
            'adv_drainage_capacity',
            'adv_include_sewers',
            'adv_include_culverts',
            'adv_length',
            'adv_width',
            'adv_shape',
            'adv_side_slope',
            'adv_manning',
            'adv_draw_threshold'
        ]
        
        missing_elements = []
        found_elements = []
        
        for element in required_elements:
            if element in source:
                found_elements.append(element)
                print(f"✅ {element} found in connect_signals")
            else:
                missing_elements.append(element)
                print(f"❌ {element} missing from connect_signals")
        
        print(f"\nSummary: {len(found_elements)}/{len(required_elements)} elements found")
        
        if missing_elements:
            print(f"Missing elements: {missing_elements}")
            return False
        else:
            print("✅ All required UI elements are referenced in connect_signals")
            return True
            
    except Exception as e:
        print(f"❌ Error testing connect_signals: {e}")
        traceback.print_exc()
        return False

def test_toggle_methods():
    """Test that all toggle methods exist and are properly implemented"""
    print("\n🔄 Testing Toggle Methods...")
    print("=" * 50)
    
    try:
        from floodengine_ui import FloodEngineDialog
        
        # Required toggle methods
        toggle_methods = [
            'toggle_groundwater_controls',
            'toggle_urban_controls', 
            'toggle_advanced_engine',
            'toggle_advanced_stream_burning'
        ]
        
        all_methods_found = True
        
        for method_name in toggle_methods:
            if hasattr(FloodEngineDialog, method_name):
                method = getattr(FloodEngineDialog, method_name)
                if callable(method):
                    print(f"✅ {method_name} exists and is callable")
                    
                    # Check method signature
                    import inspect
                    sig = inspect.signature(method)
                    params = list(sig.parameters.keys())
                    if 'enabled' in params:
                        print(f"   - Correct signature: {method_name}(self, enabled)")
                    else:
                        print(f"   ⚠️  Unexpected signature: {method_name}{sig}")
                else:
                    print(f"❌ {method_name} exists but is not callable")
                    all_methods_found = False
            else:
                print(f"❌ {method_name} not found")
                all_methods_found = False
        
        return all_methods_found
        
    except Exception as e:
        print(f"❌ Error testing toggle methods: {e}")
        traceback.print_exc()
        return False

def test_ui_setup_completeness():
    """Test that UI setup methods create all required elements"""
    print("\n🖼️ Testing UI Setup Completeness...")
    print("=" * 50)
    
    try:
        from floodengine_ui import FloodEngineDialog
        
        # Check if setup_advanced_tab method exists
        if not hasattr(FloodEngineDialog, 'setup_advanced_tab'):
            print("❌ setup_advanced_tab method not found")
            return False
        
        print("✅ setup_advanced_tab method exists")
        
        # Read method source to check for UI element creation
        import inspect
        source = inspect.getsource(FloodEngineDialog.setup_advanced_tab)
        
        # Check for UI sections that were added
        required_sections = [
            'Flow Parameters',
            'Urban Features', 
            'Groundwater',
            'Advanced Threshold',
            'QLineEdit',  # Input fields
            'QPushButton',  # Buttons
            'QCheckBox',  # Checkboxes
        ]
        
        missing_sections = []
        found_sections = []
        
        for section in required_sections:
            if section in source:
                found_sections.append(section)
                print(f"✅ {section} section found in setup_advanced_tab")
            else:
                missing_sections.append(section)
                print(f"❌ {section} section missing from setup_advanced_tab")
        
        print(f"\nSummary: {len(found_sections)}/{len(required_sections)} sections found")
        
        if missing_sections:
            print(f"Missing sections: {missing_sections}")
            return False
        else:
            print("✅ All required UI sections are present in setup_advanced_tab")
            return True
            
    except Exception as e:
        print(f"❌ Error testing UI setup: {e}")
        traceback.print_exc()
        return False

def test_specific_ui_elements():
    """Test that specific UI elements that caused AttributeErrors are now created"""
    print("\n🎯 Testing Specific UI Elements...")
    print("=" * 50)
    
    try:
        # Read the UI file to check for element creation
        with open('floodengine_ui.py', 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Elements that were previously missing and causing AttributeErrors
        critical_elements = [
            'self.adv_hydrograph = QCheckBox',
            'self.adv_hydrograph_path = QLineEdit',
            'self.adv_hydrograph_btn = QPushButton',
            'self.adv_buildings_path = QLineEdit',
            'self.adv_buildings_btn = QPushButton',
            'self.adv_enable_groundwater = QCheckBox',
            'self.adv_hydraulic_conductivity = QDoubleSpinBox',
            'self.adv_storage_coefficient = QDoubleSpinBox',
            'self.adv_enable_urban = QCheckBox',
            'self.adv_drainage_capacity = QDoubleSpinBox',
            'self.adv_include_sewers = QCheckBox',
            'self.adv_include_culverts = QCheckBox',
            'self.adv_length = QDoubleSpinBox',
            'self.adv_width = QDoubleSpinBox',
            'self.adv_shape = QComboBox',
            'self.adv_side_slope = QDoubleSpinBox',
            'self.adv_manning = QDoubleSpinBox',
            'self.adv_draw_threshold = QPushButton'
        ]
        
        missing_elements = []
        found_elements = []
        
        for element in critical_elements:
            if element in content:
                found_elements.append(element)
                print(f"✅ {element}")
            else:
                missing_elements.append(element)
                print(f"❌ {element}")
        
        print(f"\nSummary: {len(found_elements)}/{len(critical_elements)} critical elements found")
        
        if missing_elements:
            print(f"Missing critical elements: {len(missing_elements)}")
            return False
        else:
            print("✅ All critical UI elements are properly created")
            return True
            
    except Exception as e:
        print(f"❌ Error testing specific UI elements: {e}")
        traceback.print_exc()
        return False

def run_comprehensive_validation():
    """Run all validation tests"""
    print("🚀 FloodEngine Runtime Validation Test")
    print("=" * 70)
    print("Testing connect_signals completion and AttributeError resolution")
    print("=" * 70)
    
    # Run all tests
    tests = [
        ("UI Module Import", test_ui_module_import),
        ("connect_signals Method", test_connect_signals_method),
        ("Toggle Methods", test_toggle_methods),
        ("UI Setup Completeness", test_ui_setup_completeness),
        ("Specific UI Elements", test_specific_ui_elements)
    ]
    
    results = []
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"❌ {test_name} test failed with exception: {e}")
            results.append((test_name, False))
    
    # Summary
    print("\n" + "=" * 70)
    print("📊 VALIDATION SUMMARY")
    print("=" * 70)
    
    passed = 0
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} {test_name}")
        if result:
            passed += 1
    
    print(f"\nResult: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 SUCCESS! All validation tests PASSED!")
        print("✅ FloodEngine connect_signals implementation is COMPLETE")
        print("✅ All AttributeError issues have been resolved")
        print("✅ Plugin should now load successfully in QGIS")
        return True
    else:
        print(f"\n❌ VALIDATION FAILED: {total - passed} tests failed")
        print("⚠️  Some issues remain that need to be addressed")
        return False

if __name__ == "__main__":
    success = run_comprehensive_validation()
    sys.exit(0 if success else 1)
