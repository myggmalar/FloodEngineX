#!/usr/bin/env python3
"""
FloodEngine Current Status Validation - June 2025
Validates that all core components are functional and production-ready
"""

import sys
import os
import traceback
from pathlib import Path

def main():
    print("=" * 60)
    print("FloodEngine v4.0 - Current Status Validation")
    print("June 7, 2025")
    print("=" * 60)
    
    plugin_dir = Path(__file__).parent
    sys.path.insert(0, str(plugin_dir))
    
    validation_results = []
    
    # Test 1: Core Module Imports
    print("\n1. Testing Core Module Imports...")
    try:
        import floodengine
        import floodengine_ui
        import model_hydraulic
        import saint_venant_2d_fixed
        import enhanced_streamlines
        import flow_direction_fix_v2
        print("   ✅ All core modules import successfully")
        validation_results.append("Core Imports: PASS")
    except Exception as e:
        print(f"   ❌ Import error: {e}")
        validation_results.append("Core Imports: FAIL")
        return
    
    # Test 2: Critical Functions Availability
    print("\n2. Testing Critical Functions...")
    try:
        from model_hydraulic import safe_csv_value_conversion
        print("   ✅ CSV safety function available")
        
        # Test the function works
        test_result = safe_csv_value_conversion("123.45", "test_value")
        if test_result == 123.45:
            print("   ✅ CSV safety function works correctly")
        
        validation_results.append("Critical Functions: PASS")
    except Exception as e:
        print(f"   ❌ Function test error: {e}")
        validation_results.append("Critical Functions: FAIL")
    
    # Test 3: UI Model Type Initialization
    print("\n3. Testing UI Initialization...")
    try:
        # Check if floodengine_ui has proper model_type initialization
        with open('floodengine_ui.py', 'r') as f:
            content = f.read()
            if 'self.model_type = "2D Shallow Water"' in content:
                print("   ✅ UI model_type initialization found")
                validation_results.append("UI Initialization: PASS")
            else:
                print("   ❌ UI model_type initialization missing")
                validation_results.append("UI Initialization: FAIL")
    except Exception as e:
        print(f"   ❌ UI test error: {e}")
        validation_results.append("UI Initialization: FAIL")
    
    # Test 4: Saint-Venant 2D Solver
    print("\n4. Testing Saint-Venant 2D Solver...")
    try:
        from saint_venant_2d_fixed import SaintVenant2D
        print("   ✅ Saint-Venant 2D class available")
        validation_results.append("Saint-Venant Solver: PASS")
    except Exception as e:
        print(f"   ❌ Saint-Venant test error: {e}")
        validation_results.append("Saint-Venant Solver: FAIL")
    
    # Test 5: Production Package Existence
    print("\n5. Testing Production Package...")
    try:
        prod_package = plugin_dir / "FloodEngine_v4.0_Production.zip"
        if prod_package.exists():
            size_mb = prod_package.stat().st_size / (1024*1024)
            print(f"   ✅ Production package exists ({size_mb:.1f} MB)")
            validation_results.append("Production Package: PASS")
        else:
            print("   ❌ Production package missing")
            validation_results.append("Production Package: FAIL")
    except Exception as e:
        print(f"   ❌ Package test error: {e}")
        validation_results.append("Production Package: FAIL")
    
    # Summary
    print("\n" + "=" * 60)
    print("VALIDATION SUMMARY")
    print("=" * 60)
    
    passed = 0
    total = len(validation_results)
    
    for result in validation_results:
        print(f"  {result}")
        if "PASS" in result:
            passed += 1
    
    print(f"\nResults: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 FloodEngine v4.0 - ALL VALIDATIONS PASSED")
        print("   Plugin is PRODUCTION READY")
        status = "PRODUCTION_READY"
    else:
        print(f"\n⚠️  FloodEngine v4.0 - {total-passed} validation(s) failed")
        print("   Plugin needs attention")
        status = "NEEDS_ATTENTION"
    
    # Write status file
    with open('CURRENT_STATUS.txt', 'w') as f:
        f.write(f"FloodEngine v4.0 Status - {status}\n")
        f.write(f"Validation Date: June 7, 2025\n")
        f.write(f"Tests Passed: {passed}/{total}\n")
        for result in validation_results:
            f.write(f"{result}\n")
    
    print(f"\nStatus written to: CURRENT_STATUS.txt")
    return passed == total

if __name__ == "__main__":
    try:
        success = main()
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"Validation script error: {e}")
        traceback.print_exc()
        sys.exit(1)
