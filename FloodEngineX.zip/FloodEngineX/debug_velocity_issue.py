#!/usr/bin/env python3
"""
Debug the velocity issue by directly testing the enhanced streamlines code.
"""
import os
import sys
import numpy as np
import logging

# Add the current directory to sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("VelocityDebug")

def test_velocity_calculation():
    """Test the velocity calculation directly."""
    logger.info("🔍 Testing velocity calculation directly")
    
    try:
        # Import the enhanced streamlines
        from enhanced_streamlines import EnhancedStreamlines
        
        # Create a simple test case
        shape = (100, 100)
        dem_array = np.random.rand(*shape) * 10.0  # 0-10m elevation
        
        # Create geotransform
        geotransform = (0.0, 1.0, 0.0, 0.0, 0.0, -1.0)
        
        # Create water depth (1-3m in flooded areas)
        water_depth = np.zeros_like(dem_array)
        water_depth[20:80, 20:80] = np.random.rand(60, 60) * 2.0 + 1.0  # 1-3m depth
        
        logger.info(f"Test setup: DEM shape = {shape}, water depth max = {np.max(water_depth):.2f}m")
        
        # Initialize streamline generator
        streamline_gen = EnhancedStreamlines(dem_array, geotransform, water_depth=water_depth)
        
        # Test hydraulic method
        logger.info("Testing hydraulic method...")
        vx, vy, vmag = streamline_gen.calculate_velocity_field(method="hydraulic")
        
        logger.info(f"✅ Hydraulic method results:")
        logger.info(f"  • Max velocity: {np.max(vmag):.3f} m/s")
        logger.info(f"  • Mean velocity: {np.mean(vmag[vmag > 0]):.3f} m/s")
        logger.info(f"  • Cells with flow: {np.sum(vmag > 0.01)}")
        
        # Test with mock Saint-Venant results
        logger.info("Testing with mock Saint-Venant results...")
        
        # Create realistic Saint-Venant results
        saint_venant_results = {
            'velocity_x': np.random.rand(*shape) * 0.5 - 0.25,  # -0.25 to 0.25 m/s
            'velocity_y': np.random.rand(*shape) * 0.5 - 0.25,  # -0.25 to 0.25 m/s
        }
        saint_venant_results['velocity_magnitude'] = np.sqrt(
            saint_venant_results['velocity_x']**2 + saint_venant_results['velocity_y']**2
        )
        
        # Make it more realistic (higher velocities in deeper water)
        deep_mask = water_depth > 2.0
        saint_venant_results['velocity_magnitude'][deep_mask] *= 3.0  # Up to ~1.5 m/s in deep areas
        
        # Test Saint-Venant method
        vx2, vy2, vmag2 = streamline_gen.calculate_velocity_field(
            method="saint_venant", 
            saint_venant_results=saint_venant_results
        )
        
        logger.info(f"✅ Saint-Venant method results:")
        logger.info(f"  • Max velocity: {np.max(vmag2):.3f} m/s")
        logger.info(f"  • Mean velocity: {np.mean(vmag2[vmag2 > 0]):.3f} m/s")
        logger.info(f"  • Cells with flow: {np.sum(vmag2 > 0.01)}")
        
        # Test with extreme Saint-Venant results (should be rejected)
        logger.info("Testing with extreme Saint-Venant results (should be rejected)...")
        
        extreme_results = {
            'velocity_x': np.random.rand(*shape) * 20.0 - 10.0,  # -10 to 10 m/s
            'velocity_y': np.random.rand(*shape) * 20.0 - 10.0,  # -10 to 10 m/s
        }
        extreme_results['velocity_magnitude'] = np.sqrt(
            extreme_results['velocity_x']**2 + extreme_results['velocity_y']**2
        )
        
        vx3, vy3, vmag3 = streamline_gen.calculate_velocity_field(
            method="saint_venant", 
            saint_venant_results=extreme_results
        )
        
        logger.info(f"✅ Extreme Saint-Venant test results:")
        logger.info(f"  • Max velocity: {np.max(vmag3):.3f} m/s")
        logger.info(f"  • Mean velocity: {np.mean(vmag3[vmag3 > 0]):.3f} m/s")
        logger.info(f"  • Cells with flow: {np.sum(vmag3 > 0.01)}")
        
        # All tests passed
        logger.info("🎯 All velocity tests completed successfully!")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Error during velocity testing: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def check_code_version():
    """Check if we're using the correct version of the code."""
    logger.info("🔍 Checking code version...")
    
    try:
        # Check the enhanced_streamlines.py file
        script_dir = os.path.dirname(os.path.abspath(__file__))
        enhanced_file = os.path.join(script_dir, "enhanced_streamlines.py")
        
        if not os.path.exists(enhanced_file):
            logger.error(f"❌ enhanced_streamlines.py not found at {enhanced_file}")
            return False
        
        # Read the first few lines to check for our fixed version
        with open(enhanced_file, 'r') as f:
            first_lines = f.read(500)
            
        if "CRITICAL VELOCITY FIXES" in first_lines:
            logger.info("✅ Code version: FIXED version detected")
            return True
        else:
            logger.warning("⚠️  Code version: May not be the fixed version")
            return False
            
    except Exception as e:
        logger.error(f"❌ Error checking code version: {str(e)}")
        return False

if __name__ == "__main__":
    logger.info("🚀 Starting velocity debugging...")
    
    # Check code version
    if not check_code_version():
        logger.error("❌ Code version check failed")
        sys.exit(1)
    
    # Test velocity calculation
    if test_velocity_calculation():
        logger.info("✅ All tests passed - velocity calculation is working correctly")
    else:
        logger.error("❌ Tests failed - there may be an issue with the velocity calculation")
        sys.exit(1)
