# FloodEngine Time Series Animation Controls

## Overview

The FloodEngine time series animation controls provide a comprehensive system for visualizing and interacting with flood simulation results over time. The system supports both standalone operation and QGIS integration.

## Features

### 🎮 Playback Controls
- **Play/Pause**: Start and stop animation playback
- **Stop**: Stop animation and return to first timestep  
- **Step Forward/Backward**: Navigate through individual timesteps
- **Timeline Slider**: Direct navigation to any timestep
- **Speed Control**: Adjust animation speed (0.1 - 10 fps)
- **Loop Option**: Automatically restart animation when reaching the end

### 📍 Interactive Point Sampling
- **Map Clicking**: Click anywhere to sample flood data at that location
- **Real-time Data**: View depth, elevation, and velocity at selected points
- **Time Series Display**: See complete time series for any location
- **Coordinate Systems**: Support for multiple coordinate systems including RH2000 (EPSG:3006)

### 🗺️ Data Visualization
- **Water Depth Layers**: Animated depth visualization
- **Water Surface Elevation**: Surface elevation with RH2000 support
- **Flow Velocity**: Velocity magnitude and direction (if available)
- **Layer Management**: Auto-hide non-current timesteps for clean visualization

### 🔧 Technical Features
- **QGIS Integration**: Full integration with QGIS map canvas and layer management
- **Standalone Mode**: PyQt5-based interface for use without QGIS
- **Raster Export**: Automatic creation of time series raster files
- **Coordinate Transformation**: Automatic coordinate system conversion

## Installation & Dependencies

### Required Dependencies
```bash
pip install numpy PyQt5
```

### Optional Dependencies (for full functionality)
```bash
pip install GDAL
# QGIS (for map integration)
```

## Usage

### 1. Basic Usage
```python
# Run a FloodEngine simulation
from saint_venant_2d import simulate_saint_venant_2d

results = simulate_saint_venant_2d(
    dem_path="path/to/dem.tif",
    water_level=100.0,
    output_folder="simulation_output",
    time_steps=50,
    total_time=300
)

# Animation controls are automatically launched if dependencies are available
```

### 2. Manual Launch
```bash
# Launch from existing simulation results
python launch_animation.py /path/to/simulation/output

# Launch with sample data for testing
python launch_animation.py --sample

# Check system dependencies
python launch_animation.py --check-deps
```

### 3. Programmatic Usage
```python
from time_series_animator import TimeSeriesAnimator
from PyQt5.QtWidgets import QApplication

# Create application
app = QApplication([])

# Create animator with results data
animator = TimeSeriesAnimator(results_data, output_folder)
animator.show()

# Run application
app.exec_()
```

## File Structure

When a simulation with animation is run, the following structure is created:

```
simulation_output/
├── time_series_animation/
│   ├── rasters/
│   │   ├── flood_depth_t0000_0.0s.tif
│   │   ├── flood_depth_t0001_15.0s.tif
│   │   ├── water_surface_t0000_0.0s.tif
│   │   ├── water_surface_t0001_15.0s.tif
│   │   └── ...
│   ├── ANIMATION_INSTRUCTIONS.md
│   └── animations/ (for exports)
├── saint_venant_water_depth.tif
├── saint_venant_water_surface.tif
└── saint_venant_velocity.tif
```

## Animation Interface

### Main Controls Panel
- **Timestep Information**: Current timestep and simulation time
- **Timeline Slider**: Visual timeline with direct navigation
- **Playback Buttons**: Play, pause, stop, step forward/backward
- **Animation Settings**: Speed, loop option, layer visibility

### Interactive Information Panel
- **Coordinate Display**: Map coordinates and RH2000 coordinates
- **Point Data**: Water depth, surface elevation, DEM elevation, velocity
- **Time Series**: Complete time series data for selected point

## QGIS Integration

When running within QGIS:

1. **Automatic Layer Loading**: Time series layers are automatically added to the project
2. **Map Canvas Integration**: Full integration with QGIS map canvas
3. **Layer Tree Management**: Automatic visibility management in layer tree
4. **Coordinate Transformation**: Automatic transformation between map CRS and RH2000

## Standalone Mode

When QGIS is not available:

1. **Independent Interface**: Complete PyQt5-based interface
2. **GDAL Sampling**: Direct raster sampling using GDAL
3. **Simplified Visualization**: Basic raster display and interaction
4. **File-based Operation**: Operates directly on raster files

## API Reference

### TimeSeriesAnimator Class

```python
class TimeSeriesAnimator(QDialog):
    def __init__(self, results_data, output_folder, parent=None):
        """
        Initialize time series animator.
        
        Parameters:
            results_data (dict): Simulation results with time series data
            output_folder (str): Path to animation output folder
            parent: Parent widget (optional)
        """
```

### Key Methods

```python
# Playback control
animator.start_animation()
animator.pause_animation()
animator.stop_animation()
animator.next_timestep()
animator.previous_timestep()

# Data access
animator.sample_data_at_point(point)
animator.generate_time_series(point)

# Settings
animator.update_animation_speed(fps)
animator.update_visible_layers()
```

### Signal Events

```python
# Connect to animation events
animator.animation_started.connect(callback)
animator.animation_stopped.connect(callback)
animator.timestep_changed.connect(callback)
```

## Coordinate Systems

### RH2000 Support
The system provides automatic support for Sweden's RH2000 coordinate system (EPSG:3006):

- **Automatic Detection**: Detects and converts between coordinate systems
- **Elevation Reference**: Water surface elevations referenced to RH2000 datum
- **Display**: Shows both map coordinates and RH2000 coordinates
- **Sampling**: Point sampling works in both coordinate systems

### Custom Coordinate Systems
```python
# Set custom coordinate system in animator
animator.rh2000_crs = QgsCoordinateReferenceSystem("EPSG:your_code")
```

## Troubleshooting

### Common Issues

1. **Animation Not Starting**
   - Check PyQt5 installation: `pip install PyQt5`
   - Verify results data format
   - Check output folder permissions

2. **Point Sampling Not Working**
   - Ensure GDAL is installed for standalone mode
   - Check raster file paths
   - Verify coordinate system setup

3. **QGIS Integration Issues**
   - Confirm QGIS environment is active
   - Check QGIS Python path
   - Verify layer loading permissions

4. **Performance Issues**
   - Reduce animation speed
   - Close unused layers
   - Consider smaller datasets for testing

### Debug Mode
```bash
# Enable debug logging
python launch_animation.py --debug /path/to/folder
```

### System Check
```bash
# Check all dependencies
python launch_animation.py --check-deps

# Test with sample data
python demo_animation_controls.py --sample
```

## Examples

### Example 1: Basic Flood Simulation with Animation
```python
from saint_venant_2d import simulate_saint_venant_2d

results = simulate_saint_venant_2d(
    dem_path="terrain.tif",
    water_level=95.0,
    output_folder="flood_sim_001",
    time_steps=100,
    total_time=1800,  # 30 minutes
    manning_n=0.035
)

# Animation automatically launches if available
# Manual launch: python launch_animation.py flood_sim_001
```

### Example 2: Custom Animation Setup
```python
from time_series_integration import integrate_time_series_animation
from time_series_animator import TimeSeriesAnimator

# Set up animation for existing results
animation_result = integrate_time_series_animation(results_data, "animation_output")

if animation_result['success']:
    # Launch custom animator
    animator = TimeSeriesAnimator(results_data, "animation_output")
    animator.setWindowTitle("Custom Flood Animation")
    animator.show()
```

### Example 3: QGIS Plugin Integration
```python
# In QGIS plugin
from map_canvas_time_series import launch_time_series_animation

def run_flood_analysis(self):
    # Run simulation
    results = self.run_simulation()
    
    # Launch animation in QGIS
    launch_time_series_animation(results, self.output_folder)
```

## Performance Optimization

### For Large Datasets
1. **Reduce Timesteps**: Use fewer output timesteps
2. **Spatial Downsampling**: Reduce grid resolution
3. **Compression**: Use compressed raster formats
4. **Memory Management**: Close unused timestep layers

### Animation Smoothness
1. **Optimal Speed**: 1-3 fps for most flood simulations
2. **Preloading**: Allow rasters to load before starting animation
3. **Layer Caching**: Enable layer caching in QGIS

## Future Enhancements

- **Video Export**: Direct export to MP4/AVI formats
- **3D Visualization**: Integration with 3D rendering
- **Web Interface**: Browser-based animation viewer
- **Advanced Analytics**: Statistical analysis tools
- **Multi-simulation Comparison**: Side-by-side comparison tools

## Support

For issues, feature requests, or questions:

1. Check the troubleshooting section above
2. Review the ANIMATION_INSTRUCTIONS.md file created with each animation
3. Test with sample data using `demo_animation_controls.py --sample`
4. Enable debug logging for detailed error information

## License

Part of FloodEngine - Advanced Hydraulic Modeling System
