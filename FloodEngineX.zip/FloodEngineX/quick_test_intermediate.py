#!/usr/bin/env python3
"""
Quick Test: Verify intermediate timestep flood calculation works
"""

import sys
import os
import numpy as np
from pathlib import Path

# Add the plugin directory to path
plugin_dir = Path(__file__).parent
sys.path.insert(0, str(plugin_dir))

try:
    # Import the fixed functions
    from model_hydraulic import create_proper_flow_flood_mask
    print("✅ Successfully imported create_proper_flow_flood_mask")
    
    # Create simple test DEM
    rows, cols = 50, 50
    dem = np.zeros((rows, cols), dtype=np.float32)
    
    # Create a simple valley
    for i in range(rows):
        for j in range(cols):
            # Sloping terrain with valley in center
            base_elevation = 40 + (i + j) * 0.1
            center_distance = abs(i - rows//2) + abs(j - cols//2)
            valley_depth = max(0, 5 - center_distance * 0.2)
            dem[i, j] = base_elevation - valley_depth
    
    valid_mask = np.ones_like(dem, dtype=bool)
    
    print(f"📊 Test DEM range: {dem.min():.2f}m to {dem.max():.2f}m")
    
    # Test 5 different water levels (including intermediate ones)
    water_levels = [41, 42, 43, 44, 45]
    
    print("\n🧪 Testing intermediate water levels:")
    results = []
    
    for wl in water_levels:
        try:
            flood_mask = create_proper_flow_flood_mask(dem, valid_mask, wl)
            flooded_cells = np.sum(flood_mask)
            
            if flooded_cells > 0:
                print(f"✅ Water level {wl}m: {flooded_cells} cells flooded")
                results.append(True)
            else:
                print(f"❌ Water level {wl}m: NO FLOODING")
                results.append(False)
                
        except Exception as e:
            print(f"💥 Water level {wl}m: ERROR - {e}")
            results.append(False)
    
    # Summary
    successful = sum(results)
    print(f"\n📊 Results: {successful}/{len(water_levels)} water levels produced flooding")
    
    if successful == len(water_levels):
        print("🎉 SUCCESS: All intermediate levels working!")
    elif successful >= len(water_levels) - 1:
        print("⚠️ MOSTLY WORKING: Minor issues remain")
    else:
        print("❌ FAILED: Multiple intermediate levels not working")
        
except ImportError as e:
    print(f"❌ Import error: {e}")
except Exception as e:
    print(f"💥 Unexpected error: {e}")
    import traceback
    traceback.print_exc()
