#!/usr/bin/env python3
"""
Force animation dialog launch with QGIS module reload
"""

import sys
import os
from pathlib import Path

# Add current directory to path
script_dir = Path(__file__).parent
sys.path.insert(0, str(script_dir))

def force_launch_animation():
    """Force launch animation dialog with module reload."""
    
    print("🧪 Testing forced animation launch with module reload...")
    
    # Specify the actual animation folder from the recent run
    animation_folder = r"C:\Plugin\VSCode\output\time_series_animation"
    
    if not os.path.exists(animation_folder):
        print(f"❌ Animation folder not found: {animation_folder}")
        return False
    
    print(f"✅ Animation folder found: {animation_folder}")
    
    try:
        # Force reload the module
        import importlib
        
        # Try to reload if already imported
        if 'launch_animation' in sys.modules:
            import launch_animation
            importlib.reload(launch_animation)
            print("✅ Reloaded launch_animation module")
        
        from launch_animation import launch_animation_from_folder
        
        # Check function signature
        import inspect
        sig = inspect.signature(launch_animation_from_folder)
        print(f"✅ Function signature: {sig}")
        
        # Try to launch with debugging
        print("🚀 Attempting to launch animation dialog...")
        
        # Create a QApplication if needed
        from PyQt5.QtWidgets import QApplication
        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)
            print("📱 Created QApplication")
        
        # Try with parent argument first
        try:
            result = launch_animation_from_folder(animation_folder, standalone=True, parent=None)
            print(f"✅ Launch result: {result}")
            
            if result:
                print("🎉 Animation dialog launched successfully!")
                
                # Keep it alive for a few seconds
                import time
                time.sleep(5)
                
                return True
            else:
                print("❌ Launch returned False")
                return False
                
        except TypeError as e:
            if "unexpected keyword argument 'parent'" in str(e):
                print("⚠️ Function doesn't accept parent, trying without...")
                result = launch_animation_from_folder(animation_folder, standalone=True)
                print(f"✅ Launch result (no parent): {result}")
                return result
            else:
                raise e
                
    except Exception as e:
        print(f"❌ Error during forced launch: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("=" * 60)
    print("🔄 FORCED ANIMATION LAUNCH TEST")
    print("=" * 60)
    
    success = force_launch_animation()
    
    print("=" * 60)
    if success:
        print("✅ FORCED LAUNCH TEST PASSED")
    else:
        print("❌ FORCED LAUNCH TEST FAILED")
    print("=" * 60)
