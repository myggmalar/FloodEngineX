"""
Test that saint_venant_2d.py can be imported without errors
"""

try:
    from saint_venant_2d import SaintVenant2D
    print("Successfully imported SaintVenant2D class")
    
    # Create a minimal test to ensure the class initializes
    import numpy as np
    dem = np.ones((10, 10)) * 100.0
    geotransform = (0, 1, 0, 0, 0, -1)
    
    model = SaintVenant2D(dem, geotransform)
    print("Successfully initialized SaintVenant2D instance")
    
    # Try to call set_initial_condition method
    model.set_initial_condition(water_level=101.0)
    print("Successfully set initial condition")
    
except Exception as e:
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()
