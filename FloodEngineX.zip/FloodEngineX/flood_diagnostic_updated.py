#!/usr/bin/env python3
"""
Flood Mask Issue Diagnostic - Updated
"""

import os
import sys
import numpy as np

def run_flood_mask_diagnostic():
    """Main diagnostic function"""
    print("FLOOD MASK DIAGNOSTIC TOOL - UPDATED")
    print("=" * 50)
    print("This script will diagnose the flood mask generation issues")
    print("by analyzing the actual flood calculation algorithm.")
    print("=" * 50)

    # First, let's directly analyze the flood calculation algorithm
    analyze_flood_algorithm()
    
    # Create a synthetic test to understand the issue
    test_synthetic_dem()
    
    # Provide specific recommendations
    provide_recommendations()

def analyze_flood_algorithm():
    """Analyze the actual flood algorithm implementation"""
    print("\n1. ANALYZING FLOOD ALGORITHM")
    print("-" * 40)
    
    try:
        # Try to import the main function
        sys.path.insert(0, os.getcwd())
        from model_hydraulic import create_proper_flow_flood_mask
        
        print("Successfully imported create_proper_flow_flood_mask")
        
        # Analyze the function signature and docstring
        import inspect
        sig = inspect.signature(create_proper_flow_flood_mask)
        print(f"Function signature: {sig}")
        
        if hasattr(create_proper_flow_flood_mask, '__doc__') and create_proper_flow_flood_mask.__doc__:
            print(f"Function docs: {create_proper_flow_flood_mask.__doc__[:200]}...")
        
    except ImportError as e:
        print(f"Could not import flood mask function: {e}")
        
    except Exception as e:
        print(f"Error analyzing function: {e}")

def test_synthetic_dem():
    """Test with synthetic DEM data to isolate the issue"""
    print("\n2. SYNTHETIC TEST DATA")
    print("-" * 40)
    
    # Create a simple test DEM
    print("Creating synthetic DEM...")
    size = 50
    dem_array = np.ones((size, size), dtype=np.float32) * 35.0  # Base elevation 35m
    
    # Add a valley
    center = size // 2
    for i in range(size):
        for j in range(size):
            dist = np.sqrt((i - center)**2 + (j - center)**2)
            if dist < 15:
                # Create a valley that gets deeper toward center
                dem_array[i, j] = 35.0 - (15 - dist) * 0.5
    
    valid_mask = np.ones_like(dem_array, dtype=bool)
    
    print(f"DEM created: {dem_array.shape}")
    print(f"Elevation range: {np.min(dem_array):.2f}m to {np.max(dem_array):.2f}m")
    
    # Test flood mask at different water levels
    test_water_levels = [30.0, 32.0, 34.0, 36.0, 38.0]
    
    print("\n📊 TESTING DIFFERENT WATER LEVELS:")
    print("Water Level | Flooded Cells | 80th Percentile Threshold | Start Points")
    print("-" * 75)
    
    for water_level in test_water_levels:
        # Simple bathtub model
        floodable_mask = valid_mask & (dem_array < water_level)
        flooded_count = np.sum(floodable_mask)
        
        if flooded_count == 0:
            print(f"{water_level:8.1f}m | {:10d} | {'N/A':20s} | {'N/A':10s}")
            continue
            
        # Calculate 80th percentile threshold
        floodable_elevations = dem_array[floodable_mask]
        threshold_80 = np.percentile(floodable_elevations, 80)
        start_points = np.sum(floodable_mask & (dem_array >= threshold_80))
        
        print(f"{water_level:8.1f}m | {flooded_count:10d} | {threshold_80:16.2f}m | {start_points:10d}")
        
        # Check if this would be problematic
        if start_points == 0:
            print(f"    ❌ PROBLEM: Zero start points at {water_level}m!")
        elif start_points < 5:
            print(f"    ⚠️  WARNING: Very few start points ({start_points})")

def provide_recommendations():
    """Provide specific recommendations based on analysis"""
    print("\n3. RECOMMENDATIONS")
    print("-" * 40)
    
    print("Based on the analysis, here are the key issues and fixes:")
    print()
    print("🔍 IDENTIFIED PROBLEMS:")
    print("1. 80th percentile threshold is too restrictive for intermediate water levels")
    print("2. Flow-based algorithm fails when insufficient start points are available")
    print("3. No fallback mechanism when flow algorithm produces zero results")
    print()
    print("💡 RECOMMENDED FIXES:")
    print("1. LOWER PERCENTILE THRESHOLD:")
    print("   - Change from 80th percentile to 60th-70th percentile")
    print("   - This will provide more starting points for flow calculation")
    print()
    print("2. ADD ADAPTIVE THRESHOLD:")
    print("   - If 80th percentile gives <5 start points, try 70th, then 60th")
    print("   - Continue until adequate start points are found")
    print()
    print("3. IMPLEMENT FALLBACK MECHANISM:")
    print("   - If flow-based algorithm returns zero flooding, use bathtub model")
    print("   - Especially important for intermediate water levels")
    print()
    print("4. HYBRID APPROACH:")
    print("   - High water levels: Use flow-based algorithm")
    print("   - Low-medium water levels: Use bathtub model or lower percentile")
    print()
    print("🔧 NEXT STEPS:")
    print("1. Modify create_proper_flow_flood_mask() function")
    print("2. Add percentile threshold parameter (default 60-70)")
    print("3. Add fallback to bathtub model when flow algorithm fails")
    print("4. Test with range of water levels to verify fix")

if __name__ == "__main__":
    run_flood_mask_diagnostic()
