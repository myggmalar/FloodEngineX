from PyQt5.QtWidgets import QDialog
from .model_hydraulic import calculate_flood_area

class FloodEngineDialog(QDialog):
    def __init__(self, iface):
        super().__init__()
        self.iface = iface
        # Din UI-initiering/knappar/dialoger exakt som tidigare!

    def run_model(self):
        # ... samla in parametrar från UI som du är van vid ...
        dem_path = self.dem_input.text()
        output_folder = self.outdir_input.text()
        water_levels = self.levels_input.getLevels()
        flow_q = self.q_input.value()
        manning_n = self.manning_input.value()
        # Kör wrapper – alltid SV, aldrig fallback!
        calculate_flood_area(
            self.iface,
            dem_path,
            water_levels,
            output_folder,
            flow_q=flow_q,
            manning_n=manning_n
        )
        # Meddela klart i UI om du vill!
