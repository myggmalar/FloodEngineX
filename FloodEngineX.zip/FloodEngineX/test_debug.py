#!/usr/bin/env python3
"""
Quick test debug script
"""

import os
import sys

print("="*50)
print("DEBUG TEST - DEM Elevation Fix Status")
print("="*50)

# Check if we're in the right directory
print(f"Current directory: {os.getcwd()}")

# Check for key files
key_files = ["model_hydraulic.py", "fix_dem_elevation_issues.py"]
for file in key_files:
    if os.path.exists(file):
        size = os.path.getsize(file)
        print(f"✅ {file} exists ({size} bytes)")
    else:
        print(f"❌ {file} missing")

# Test basic function import
try:
    print("\nTesting basic function import...")
    
    # Read model_hydraulic.py to check for our functions
    with open("model_hydraulic.py", 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check for our key functions
    functions_to_check = [
        "load_and_integrate_bathymetry_FIXED",
        "apply_geoid_correction_only", 
        "apply_dem_styling"
    ]
    
    for func in functions_to_check:
        if f"def {func}(" in content:
            print(f"✅ Function {func} found")
        else:
            print(f"❌ Function {func} missing")
    
    # Check for the main integration fix
    if "load_and_integrate_bathymetry_FIXED(" in content:
        print("✅ Main code updated to use fixed function")
    else:
        print("❌ Main code not updated")
        
    # Check for RT2000 configuration
    if "geoid_correction=42.0" in content:
        print("✅ RT2000 geoid correction configured")
    else:
        print("❌ RT2000 geoid correction not configured")
        
    print("\n🎯 QUICK STATUS: DEM elevation fix appears to be implemented!")
    
except Exception as e:
    print(f"❌ Error during test: {e}")

print("="*50)
