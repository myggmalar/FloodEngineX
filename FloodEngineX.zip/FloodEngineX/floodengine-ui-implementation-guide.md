# FloodEngine UI Implementation Guide

This document provides detailed implementation specifications for the FloodEngine QGIS plugin UI redesign. Use this guide to direct GitHub Copilot or manual implementation efforts.

## Table of Contents

1. [Overall UI Structure](#overall-ui-structure)
2. [Basic Mode Implementation](#basic-mode-implementation)
3. [Advanced Mode Implementation](#advanced-mode-implementation)
4. [Equation Display System](#equation-display-system)
5. [Component Styling Guide](#component-styling-guide)
6. [Implementation Sequence](#implementation-sequence)

## Overall UI Structure

### Main Window Organization

```python
# Main dialog layout structure
main_layout = QVBoxLayout()

# Top section with mode selection
mode_selection_layout = QHBoxLayout()
self.basic_radio = QRadioButton("Basic Mode")
self.advanced_radio = QRadioButton("Advanced Mode")
self.basic_radio.setChecked(True)  # Default to Basic mode
mode_selection_layout.addWidget(QLabel("<b>Model Mode:</b>"))
mode_selection_layout.addWidget(self.basic_radio)
mode_selection_layout.addWidget(self.advanced_radio)
mode_selection_layout.addStretch()
main_layout.addLayout(mode_selection_layout)

# Stacked widget to switch between basic and advanced
self.mode_stack = QStackedWidget()
self.basic_page = QWidget()
self.advanced_page = QWidget()
self.mode_stack.addWidget(self.basic_page)
self.mode_stack.addWidget(self.advanced_page)
main_layout.addWidget(self.mode_stack)

# Bottom section with run button and progress
bottom_layout = QHBoxLayout()
self.progress_bar = QProgressBar()
self.run_button = QPushButton("Run Model")
self.run_button.setMinimumHeight(40)
bottom_layout.addWidget(self.progress_bar)
bottom_layout.addWidget(self.run_button)
main_layout.addLayout(bottom_layout)

# Connect mode selection signals
self.basic_radio.toggled.connect(self.toggle_mode)
self.advanced_radio.toggled.connect(self.toggle_mode)

def toggle_mode(self):
    if self.basic_radio.isChecked():
        self.mode_stack.setCurrentIndex(0)
    else:
        self.mode_stack.setCurrentIndex(1)
```

### Common Elements

Create a consistent function to build section headers:

```python
def create_section_header(title, tooltip=None, show_equation=False):
    """Creates a standardized section header with optional equation button"""
    header_layout = QHBoxLayout()
    
    # Create label with consistent styling
    label = QLabel(f"<b>{title}</b>")
    label.setStyleSheet("font-size: 11pt;")
    if tooltip:
        label.setToolTip(tooltip)
    header_layout.addWidget(label)
    
    header_layout.addStretch()
    
    # Add equation button if requested
    if show_equation:
        equation_btn = QPushButton()
        equation_btn.setIcon(QIcon(":/icons/equation.svg"))
        equation_btn.setToolTip(f"Show equations for {title}")
        equation_btn.setFixedSize(24, 24)
        equation_btn.setObjectName(f"equation_btn_{title.lower().replace(' ', '_')}")
        header_layout.addWidget(equation_btn)
    
    return header_layout
```

## Basic Mode Implementation

### Data Input Section

```python
def create_basic_data_inputs(self):
    """Creates the data inputs section for Basic mode"""
    group_box = QGroupBox("Data Inputs")
    layout = QVBoxLayout()
    
    # DEM file input
    dem_layout = QHBoxLayout()
    dem_layout.addWidget(QLabel("DEM File:"))
    self.basic_dem_path = QLineEdit()
    dem_layout.addWidget(self.basic_dem_path)
    self.basic_dem_btn = QPushButton("Browse...")
    dem_layout.addWidget(self.basic_dem_btn)
    layout.addLayout(dem_layout)
    
    # Bathymetry file input (optional)
    bathy_layout = QHBoxLayout()
    bathy_layout.addWidget(QLabel("Bathymetry (optional):"))
    self.basic_bathy_path = QLineEdit()
    bathy_layout.addWidget(self.basic_bathy_path)
    self.basic_bathy_btn = QPushButton("Browse...")
    bathy_layout.addWidget(self.basic_bathy_btn)
    layout.addLayout(bathy_layout)
    
    # Soil data input (for erosion)
    soil_layout = QHBoxLayout()
    soil_layout.addWidget(QLabel("Soil Data (for erosion):"))
    self.basic_soil_path = QLineEdit()
    soil_layout.addWidget(self.basic_soil_path)
    self.basic_soil_btn = QPushButton("Browse...")
    soil_layout.addWidget(self.basic_soil_btn)
    layout.addLayout(soil_layout)
    
    # Connect browse buttons
    self.basic_dem_btn.clicked.connect(lambda: self.select_file(self.basic_dem_path, "DEM Files (*.tif *.asc)"))
    self.basic_bathy_btn.clicked.connect(lambda: self.select_file(self.basic_bathy_path, "CSV Files (*.csv)"))
    self.basic_soil_btn.clicked.connect(lambda: self.select_file(self.basic_soil_path, "Shapefile (*.shp)"))
    
    group_box.setLayout(layout)
    return group_box
```

### Flood Parameters Section

```python
def create_basic_flood_parameters(self):
    """Creates the flood parameters section for Basic mode"""
    group_box = QGroupBox("Flood Parameters")
    group_box.setToolTip("Configure the basic flood simulation parameters")
    layout = QVBoxLayout()
    
    # Grid layout for parameters with sliders
    params_layout = QGridLayout()
    
    # Water Level row
    params_layout.addWidget(QLabel("Water Level (m):"), 0, 0)
    self.basic_water_level = QLineEdit()
    self.basic_water_level.setText("10.00")
    self.basic_water_level.setMaximumWidth(80)
    params_layout.addWidget(self.basic_water_level, 0, 1)
    self.basic_water_level_slider = QSlider(Qt.Horizontal)
    self.basic_water_level_slider.setMinimum(0)
    self.basic_water_level_slider.setMaximum(100)
    self.basic_water_level_slider.setValue(10)
    params_layout.addWidget(self.basic_water_level_slider, 0, 2)
    
    # Threshold row
    params_layout.addWidget(QLabel("Threshold (m):"), 1, 0)
    self.basic_threshold = QLineEdit()
    self.basic_threshold.setText("0.00")
    self.basic_threshold.setMaximumWidth(80)
    self.basic_threshold.setToolTip("Minimum elevation that will be flooded")
    params_layout.addWidget(self.basic_threshold, 1, 1)
    self.basic_threshold_slider = QSlider(Qt.Horizontal)
    self.basic_threshold_slider.setMinimum(0)
    self.basic_threshold_slider.setMaximum(100)
    self.basic_threshold_slider.setValue(0)
    params_layout.addWidget(self.basic_threshold_slider, 1, 2)
    
    # Flow Q row
    params_layout.addWidget(QLabel("Flow Q (m³/s):"), 2, 0)
    self.basic_flow_q = QLineEdit()
    self.basic_flow_q.setText("")
    self.basic_flow_q.setPlaceholderText("Optional")
    self.basic_flow_q.setMaximumWidth(80)
    self.basic_flow_q.setToolTip("Flow rate (optional)")
    params_layout.addWidget(self.basic_flow_q, 2, 1)
    
    layout.addLayout(params_layout)
    
    # Add visual diagram explaining the relationship between parameters
    diagram_layout = QHBoxLayout()
    diagram_label = QLabel()
    # Replace this with actual diagram image
    diagram_label.setText("[Diagram: Water Level vs Threshold visualization]")
    diagram_label.setStyleSheet("border: 1px solid #cccccc; padding: 5px; background-color: #f5f5f5;")
    diagram_label.setMinimumHeight(100)
    diagram_label.setAlignment(Qt.AlignCenter)
    diagram_layout.addWidget(diagram_label)
    layout.addLayout(diagram_layout)
    
    # Connect signals for synchronized updates
    self.basic_water_level_slider.valueChanged.connect(self.update_basic_water_level)
    self.basic_water_level.textChanged.connect(self.update_basic_water_slider)
    self.basic_threshold_slider.valueChanged.connect(self.update_basic_threshold)
    self.basic_threshold.textChanged.connect(self.update_basic_threshold_slider)
    
    group_box.setLayout(layout)
    return group_box
```

### Basic Erosion Section

```python
def create_basic_erosion_parameters(self):
    """Creates the erosion parameters section for Basic mode"""
    group_box = QGroupBox("Erosion Parameters")
    layout = QVBoxLayout()
    
    # Enable erosion checkbox
    self.basic_erosion_enable = QCheckBox("Calculate erosion risk")
    self.basic_erosion_enable.setChecked(True)
    layout.addWidget(self.basic_erosion_enable)
    
    # Soil type selection
    soil_layout = QHBoxLayout()
    soil_layout.addWidget(QLabel("Soil Type:"))
    self.basic_soil_type = QComboBox()
    soil_types = ["Select soil type...", "Sand", "Silt", "Clay", "Gravel", "Mixed", "Organic", "Rock"]
    self.basic_soil_type.addItems(soil_types)
    soil_layout.addWidget(self.basic_soil_type)
    layout.addLayout(soil_layout)
    
    # Erosion sensitivity
    sensitivity_layout = QHBoxLayout()
    sensitivity_layout.addWidget(QLabel("Erosion Sensitivity:"))
    self.basic_erosion_sensitivity = QComboBox()
    sensitivity_options = ["Low", "Medium", "High"]
    self.basic_erosion_sensitivity.addItems(sensitivity_options)
    self.basic_erosion_sensitivity.setCurrentIndex(1)  # Default to Medium
    sensitivity_layout.addWidget(self.basic_erosion_sensitivity)
    layout.addLayout(sensitivity_layout)
    
    # Note about more advanced options
    note_label = QLabel("Note: For more complex erosion models with custom parameters, use Advanced Mode")
    note_label.setStyleSheet("font-style: italic; color: #555555;")
    layout.addWidget(note_label)
    
    group_box.setLayout(layout)
    return group_box
```

### Basic Output Options

```python
def create_basic_output_options(self):
    """Creates the output options section for Basic mode"""
    group_box = QGroupBox("Output Options")
    layout = QVBoxLayout()
    
    # Checkboxes for output options
    self.basic_output_flood_map = QCheckBox("Generate flood map")
    self.basic_output_flood_map.setChecked(True)
    layout.addWidget(self.basic_output_flood_map)
    
    self.basic_output_flood_stats = QCheckBox("Calculate inundation statistics")
    self.basic_output_flood_stats.setChecked(True)
    layout.addWidget(self.basic_output_flood_stats)
    
    self.basic_output_flow_arrows = QCheckBox("Show flow directions")
    layout.addWidget(self.basic_output_flow_arrows)
    
    # Output folder
    output_layout = QHBoxLayout()
    output_layout.addWidget(QLabel("Output Folder:"))
    self.basic_output_folder = QLineEdit()
    output_layout.addWidget(self.basic_output_folder)
    self.basic_output_folder_btn = QPushButton("Browse...")
    output_layout.addWidget(self.basic_output_folder_btn)
    layout.addLayout(output_layout)
    
    # Connect browse button
    self.basic_output_folder_btn.clicked.connect(self.select_output_folder)
    
    group_box.setLayout(layout)
    return group_box
```

## Advanced Mode Implementation

### Hydraulic Model Section

```python
def create_advanced_hydraulic_model(self):
    """Creates the hydraulic model section for Advanced mode"""
    group_box = QGroupBox("Hydraulic Model")
    layout = QVBoxLayout()
    
    # Add header with equation button
    layout.addLayout(self.create_section_header("Hydraulic Model Configuration", 
                                               "Configure the hydraulic modeling approach",
                                               show_equation=True))
    
    # Model type selection
    model_layout = QHBoxLayout()
    model_layout.addWidget(QLabel("Model Type:"))
    self.adv_model_type = QComboBox()
    model_types = ["1D Simplified", "2D Shallow Water", "2D SWE with Momentum"]
    self.adv_model_type.addItems(model_types)
    model_layout.addWidget(self.adv_model_type)
    layout.addLayout(model_layout)
    
    # Model state options
    state_layout = QHBoxLayout()
    self.adv_steady_state = QRadioButton("Steady State")
    self.adv_dynamic = QRadioButton("Dynamic")
    self.adv_steady_state.setChecked(True)
    state_group = QButtonGroup()
    state_group.addButton(self.adv_steady_state)
    state_group.addButton(self.adv_dynamic)
    state_layout.addWidget(QLabel("Simulation Type:"))
    state_layout.addWidget(self.adv_steady_state)
    state_layout.addWidget(self.adv_dynamic)
    state_layout.addStretch()
    layout.addLayout(state_layout)
    
    # Numerical method
    num_layout = QHBoxLayout()
    num_layout.addWidget(QLabel("Numerical Method:"))
    self.adv_numerical_method = QComboBox()
    num_methods = ["Finite Difference", "Finite Volume"]
    self.adv_numerical_method.addItems(num_methods)
    num_layout.addWidget(self.adv_numerical_method)
    layout.addLayout(num_layout)
    
    # Timestep and grid resolution (enabled only for dynamic models)
    grid_layout = QGridLayout()
    grid_layout.addWidget(QLabel("Timestep:"), 0, 0)
    self.adv_timestep = QLineEdit("60")
    self.adv_timestep.setMaximumWidth(80)
    grid_layout.addWidget(self.adv_timestep, 0, 1)
    grid_layout.addWidget(QLabel("seconds"), 0, 2)
    
    grid_layout.addWidget(QLabel("Grid Resolution:"), 1, 0)
    self.adv_grid_res = QLineEdit("5")
    self.adv_grid_res.setMaximumWidth(80)
    grid_layout.addWidget(self.adv_grid_res, 1, 1)
    grid_layout.addWidget(QLabel("meters"), 1, 2)
    layout.addLayout(grid_layout)
    
    # Advanced options
    self.adv_adaptive_mesh = QCheckBox("Use adaptive mesh refinement")
    self.adv_momentum = QCheckBox("Apply momentum conservation")
    self.adv_momentum.setToolTip("Increases accuracy but more computationally intensive")
    layout.addWidget(self.adv_adaptive_mesh)
    layout.addWidget(self.adv_momentum)
    
    # Enable/disable appropriate controls based on model selection
    self.adv_model_type.currentIndexChanged.connect(self.update_hydraulic_model_options)
    self.adv_steady_state.toggled.connect(self.update_hydraulic_model_options)
    self.adv_dynamic.toggled.connect(self.update_hydraulic_model_options)
    
    group_box.setLayout(layout)
    return group_box
```

### Stream & Terrain Processing Section

```python
def create_advanced_stream_processing(self):
    """Creates the stream and terrain processing section for Advanced mode"""
    group_box = QGroupBox("Stream & Terrain Processing")
    layout = QVBoxLayout()
    
    # Add header with equation button
    layout.addLayout(self.create_section_header("Stream & Terrain Processing", 
                                              "Configure stream burning and terrain modifications",
                                              show_equation=True))
    
    # Enable stream burning
    self.adv_enable_stream_burning = QCheckBox("Enable advanced stream burning")
    layout.addWidget(self.adv_enable_stream_burning)
    
    # Stream options container (enabled only when stream burning is checked)
    stream_container = QWidget()
    stream_layout = QVBoxLayout()
    stream_container.setLayout(stream_layout)
    stream_container.setEnabled(False)
    layout.addWidget(stream_container)
    
    # Stream file input
    stream_file_layout = QHBoxLayout()
    stream_file_layout.addWidget(QLabel("Stream file:"))
    self.adv_stream_file = QLineEdit()
    stream_file_layout.addWidget(self.adv_stream_file)
    self.adv_stream_file_btn = QPushButton("Browse...")
    stream_file_layout.addWidget(self.adv_stream_file_btn)
    stream_layout.addLayout(stream_file_layout)
    
    # Burn depth
    burn_layout = QHBoxLayout()
    burn_layout.addWidget(QLabel("Burn depth:"))
    self.adv_burn_depth = QLineEdit("5")
    self.adv_burn_depth.setMaximumWidth(80)
    burn_layout.addWidget(self.adv_burn_depth)
    burn_layout.addWidget(QLabel("meters"))
    stream_layout.addLayout(burn_layout)
    
    # Advanced stream options
    self.adv_consider_soil = QCheckBox("Consider soil erodibility")
    stream_layout.addWidget(self.adv_consider_soil)
    
    self.adv_bottom_undulations = QCheckBox("Generate bottom undulations")
    self.adv_bottom_undulations.setToolTip("Creates natural pool-riffle sequences in the stream")
    stream_layout.addWidget(self.adv_bottom_undulations)
    
    # Connect signals
    self.adv_enable_stream_burning.toggled.connect(stream_container.setEnabled)
    self.adv_stream_file_btn.clicked.connect(lambda: self.select_file(self.adv_stream_file, "Shapefile (*.shp)"))
    
    group_box.setLayout(layout)
    return group_box
```

### Erosion & Sediment Section

```python
def create_advanced_erosion_section(self):
    """Creates the erosion and sediment section for Advanced mode"""
    group_box = QGroupBox("Erosion & Sediment")
    layout = QVBoxLayout()
    
    # Add header with equation button
    layout.addLayout(self.create_section_header("Erosion & Sediment Transport", 
                                              "Configure advanced erosion and sediment models",
                                              show_equation=True))
    
    # Erosion model selection
    model_layout = QHBoxLayout()
    model_layout.addWidget(QLabel("Erosion Model:"))
    self.adv_erosion_model = QComboBox()
    erosion_models = ["Basic (Slope-based)", "Meyer-Peter Müller", "van Rijn", "USLE"]
    self.adv_erosion_model.addItems(erosion_models)
    self.adv_erosion_model.setCurrentIndex(1)  # Default to MPM
    model_layout.addWidget(self.adv_erosion_model)
    layout.addLayout(model_layout)
    
    # Soil data input
    soil_layout = QHBoxLayout()
    soil_layout.addWidget(QLabel("Soil Data:"))
    self.adv_soil_data = QLineEdit()
    soil_layout.addWidget(self.adv_soil_data)
    self.adv_soil_data_btn = QPushButton("Browse...")
    soil_layout.addWidget(self.adv_soil_data_btn)
    layout.addLayout(soil_layout)
    
    # Enable sediment transport
    self.adv_enable_sediment = QCheckBox("Enable sediment transport")
    layout.addWidget(self.adv_enable_sediment)
    
    # Sediment options container
    sediment_container = QWidget()
    sediment_layout = QVBoxLayout()
    sediment_container.setLayout(sediment_layout)
    sediment_container.setEnabled(False)
    layout.addWidget(sediment_container)
    
    # Sediment parameters
    grain_layout = QHBoxLayout()
    grain_layout.addWidget(QLabel("D50 Grain Size:"))
    self.adv_grain_size = QLineEdit("1.0")
    self.adv_grain_size.setMaximumWidth(80)
    grain_layout.addWidget(self.adv_grain_size)
    grain_layout.addWidget(QLabel("mm"))
    sediment_layout.addLayout(grain_layout)
    
    density_layout = QHBoxLayout()
    density_layout.addWidget(QLabel("Sediment Density:"))
    self.adv_sediment_density = QLineEdit("2650")
    self.adv_sediment_density.setMaximumWidth(80)
    density_layout.addWidget(self.adv_sediment_density)
    density_layout.addWidget(QLabel("kg/m³"))
    sediment_layout.addLayout(density_layout)
    
    # Transport options
    transport_layout = QHBoxLayout()
    transport_layout.addWidget(QLabel("Transport Mode:"))
    self.adv_transport_mode = QComboBox()
    transport_modes = ["Bedload only", "Suspended only", "Bedload + Suspended"]
    self.adv_transport_mode.addItems(transport_modes)
    self.adv_transport_mode.setCurrentIndex(2)  # Default to both
    transport_layout.addWidget(self.adv_transport_mode)
    sediment_layout.addLayout(transport_layout)
    
    # Connect signals
    self.adv_enable_sediment.toggled.connect(sediment_container.setEnabled)
    self.adv_soil_data_btn.clicked.connect(lambda: self.select_file(self.adv_soil_data, "Shapefile (*.shp)"))
    
    group_box.setLayout(layout)
    return group_box
```

### Groundwater Section

```python
def create_advanced_groundwater_section(self):
    """Creates the groundwater section for Advanced mode"""
    group_box = QGroupBox("Groundwater")
    layout = QVBoxLayout()
    
    # Add header with equation button
    layout.addLayout(self.create_section_header("Groundwater Modeling", 
                                              "Configure groundwater and surface water interaction",
                                              show_equation=True))
    
    # Enable groundwater modeling
    self.adv_enable_groundwater = QCheckBox("Enable groundwater modeling")
    layout.addWidget(self.adv_enable_groundwater)
    
    # Groundwater options container
    gw_container = QWidget()
    gw_layout = QVBoxLayout()
    gw_container.setLayout(gw_layout)
    gw_container.setEnabled(False)
    layout.addWidget(gw_container)
    
    # Aquifer type
    aquifer_layout = QHBoxLayout()
    aquifer_layout.addWidget(QLabel("Aquifer Type:"))
    self.adv_aquifer_type = QComboBox()
    aquifer_types = ["Unconfined", "Confined", "Leaky confined"]
    self.adv_aquifer_type.addItems(aquifer_types)
    aquifer_layout.addWidget(self.adv_aquifer_type)
    gw_layout.addLayout(aquifer_layout)
    
    # Hydraulic conductivity
    k_layout = QHBoxLayout()
    k_layout.addWidget(QLabel("Hydraulic Conductivity:"))
    self.adv_hydraulic_k = QLineEdit("1.0")
    self.adv_hydraulic_k.setMaximumWidth(80)
    k_layout.addWidget(self.adv_hydraulic_k)
    k_layout.addWidget(QLabel("m/day"))
    gw_layout.addLayout(k_layout)
    
    # Storage coefficient
    storage_layout = QHBoxLayout()
    storage_layout.addWidget(QLabel("Storage Coefficient:"))
    self.adv_storage_coef = QLineEdit("0.1")
    self.adv_storage_coef.setMaximumWidth(80)
    storage_layout.addWidget(self.adv_storage_coef)
    gw_layout.addLayout(storage_layout)
    
    # Exchange rate
    exchange_layout = QHBoxLayout()
    exchange_layout.addWidget(QLabel("SW-GW Exchange Rate:"))
    self.adv_exchange_rate = QLineEdit("0.01")
    self.adv_exchange_rate.setMaximumWidth(80)
    exchange_layout.addWidget(self.adv_exchange_rate)
    exchange_layout.addWidget(QLabel("m/day"))
    gw_layout.addLayout(exchange_layout)
    
    # Initial groundwater level
    gw_level_layout = QHBoxLayout()
    gw_level_layout.addWidget(QLabel("Initial Groundwater Level:"))
    self.adv_init_gw_level = QComboBox()
    gw_level_options = ["Auto (based on DEM)", "Relative to surface", "Absolute elevation"]
    self.adv_init_gw_level.addItems(gw_level_options)
    gw_level_layout.addWidget(self.adv_init_gw_level)
    gw_layout.addLayout(gw_level_layout)
    
    # Connect signals
    self.adv_enable_groundwater.toggled.connect(gw_container.setEnabled)
    
    group_box.setLayout(layout)
    return group_box
```

### Urban Features Section

```python
def create_advanced_urban_section(self):
    """Creates the urban features section for Advanced mode"""
    group_box = QGroupBox("Urban Features")
    layout = QVBoxLayout()
    
    # Add header with equation button
    layout.addLayout(self.create_section_header("Urban Flood Modeling", 
                                              "Configure urban infrastructure and drainage",
                                              show_equation=True))
    
    # Enable urban modeling
    self.adv_enable_urban = QCheckBox("Enable urban flood modeling")
    layout.addWidget(self.adv_enable_urban)
    
    # Urban options container
    urban_container = QWidget()
    urban_layout = QVBoxLayout()
    urban_container.setLayout(urban_layout)
    urban_container.setEnabled(False)
    layout.addWidget(urban_container)
    
    # Buildings file
    buildings_layout = QHBoxLayout()
    buildings_layout.addWidget(QLabel("Buildings:"))
    self.adv_buildings_file = QLineEdit()
    buildings_layout.addWidget(self.adv_buildings_file)
    self.adv_buildings_btn = QPushButton("Browse...")
    buildings_layout.addWidget(self.adv_buildings_btn)
    urban_layout.addLayout(buildings_layout)
    
    # Drainage file
    drainage_layout = QHBoxLayout()
    drainage_layout.addWidget(QLabel("Drainage Network:"))
    self.adv_drainage_file = QLineEdit()
    drainage_layout.addWidget(self.adv_drainage_file)
    self.adv_drainage_btn = QPushButton("Browse...")
    drainage_layout.addWidget(self.adv_drainage_btn)
    urban_layout.addLayout(drainage_layout)
    
    # Urban options
    self.adv_include_culverts = QCheckBox("Include culverts and bridges")
    urban_layout.addWidget(self.adv_include_culverts)
    
    self.adv_urban_runoff = QCheckBox("Model urban surface runoff")
    urban_layout.addWidget(self.adv_urban_runoff)
    
    # Drainage capacity
    drainage_cap_layout = QHBoxLayout()
    drainage_cap_layout.addWidget(QLabel("Drainage Capacity:"))
    self.adv_drainage_capacity = QLineEdit("50")
    self.adv_drainage_capacity.setMaximumWidth(80)
    drainage_cap_layout.addWidget(self.adv_drainage_capacity)
    drainage_cap_layout.addWidget(QLabel("mm/hour"))
    urban_layout.addLayout(drainage_cap_layout)
    
    # Connect signals
    self.adv_enable_urban.toggled.connect(urban_container.setEnabled)
    self.adv_buildings_btn.clicked.connect(lambda: self.select_file(self.adv_buildings_file, "Shapefile (*.shp)"))
    self.adv_drainage_btn.clicked.connect(lambda: self.select_file(self.adv_drainage_file, "Shapefile (*.shp)"))
    
    group_box.setLayout(layout)
    return group_box
```

### Time Series Section

```python
def create_advanced_time_series_section(self):
    """Creates the time series section for Advanced mode"""
    group_box = QGroupBox("Time Series")
    layout = QVBoxLayout()
    
    # Add header with equation button
    layout.addLayout(self.create_section_header("Time Series Simulation", 
                                              "Configure temporal simulation settings",
                                              show_equation=False))
    
    # Enable time series
    self.adv_enable_time_series = QCheckBox("Run time-series simulation")
    layout.addWidget(self.adv_enable_time_series)
    
    # Time series options container
    timeseries_container = QWidget()
    timeseries_layout = QVBoxLayout()
    timeseries_container.setLayout(timeseries_layout)
    timeseries_container.setEnabled(False)
    layout.addWidget(timeseries_container)
    
    # Duration
    duration_layout = QHBoxLayout()
    duration_layout.addWidget(QLabel("Duration:"))
    self.adv_duration = QLineEdit("24")
    self.adv_duration.setMaximumWidth(80)
    duration_layout.addWidget(self.adv_duration)
    duration_layout.addWidget(QLabel("hours"))
    timeseries_layout.addLayout(duration_layout)
    
    # Timestep
    timestep_layout = QHBoxLayout()
    timestep_layout.addWidget(QLabel("Output Timestep:"))
    self.adv_output_timestep = QLineEdit("60")
    self.adv_output_timestep.setMaximumWidth(80)
    timestep_layout.addWidget(self.adv_output_timestep)
    timestep_layout.addWidget(QLabel("minutes"))
    timeseries_layout.addLayout(timestep_layout)
    
    # Output options
    self.adv_create_animation = QCheckBox("Create animation")
    timeseries_layout.addWidget(self.adv_create_animation)
    
    self.adv_export_timeseries = QCheckBox("Export time series data")
    timeseries_layout.addWidget(self.adv_export_timeseries)
    
    # Hydrograph input
    hydrograph_layout = QVBoxLayout()
    hydrograph_header = QHBoxLayout()
    hydrograph_header.addWidget(QLabel("Input Hydrograph:"))
    self.adv_use_hydrograph = QCheckBox("Use input hydrograph")
    hydrograph_header.addWidget(self.adv_use_hydrograph)
    hydrograph_layout.addLayout(hydrograph_header)
    
    hydrograph_file_layout = QHBoxLayout()
    self.adv_hydrograph_file = QLineEdit()
    self.adv_hydrograph_file.setEnabled(False)
    hydrograph_file_layout.addWidget(self.adv_hydrograph_file)
    self.adv_hydrograph_btn = QPushButton("Browse...")
    self.adv_hydrograph_btn.setEnabled(False)
    hydrograph_file_layout.addWidget(self.adv_hydrograph_btn)
    hydrograph_layout.addLayout(hydrograph_file_layout)
    timeseries_layout.addLayout(hydrograph_layout)
    
    # Connect signals
    self.adv_enable_time_series.toggled.connect(timeseries_container.setEnabled)
    self.adv_use_hydrograph.toggled.connect(self.adv_hydrograph_file.setEnabled)
    self.adv_use_hydrograph.toggled.connect(self.adv_hydrograph_btn.setEnabled)
    self.adv_hydrograph_btn.clicked.connect(lambda: self.select_file(self.adv_hydrograph_file, "CSV Files (*.csv)"))
    
    group_box.setLayout(layout)
    return group_box