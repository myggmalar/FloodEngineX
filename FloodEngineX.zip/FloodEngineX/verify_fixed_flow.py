"""
Script to verify the fixed flow direction implementation
"""
import os
import sys

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def check_fixed_flow_availability():
    """Check if the fixed flow direction module is available"""
    print("=== FLOW DIRECTION FIX VERIFICATION ===")
    
    # Try to import the fixed flow module
    try:
        from flow_direction_flood_fixed import (
            calculate_flood_area_with_flow_direction_FIXED,
            simulate_hydraulic_flow_FIXED
        )
        fixed_available = True
        print("✅ Flow direction fix is AVAILABLE")
        print("   - calculate_flood_area_with_flow_direction_FIXED imported successfully")
        print("   - simulate_hydraulic_flow_FIXED imported successfully")
    except ImportError as e:
        fixed_available = False
        print(f"❌ Flow direction fix is NOT available: {e}")
    
    # Try to import the model_hydraulic module to check if it's been updated
    try:
        import model_hydraulic
        
        # Check if the FIXED_FLOW_AVAILABLE flag exists
        if hasattr(model_hydraulic, 'FIXED_FLOW_AVAILABLE'):
            print(f"✅ model_hydraulic.py has been updated with FIXED_FLOW_AVAILABLE flag")
            print(f"   - FIXED_FLOW_AVAILABLE = {model_hydraulic.FIXED_FLOW_AVAILABLE}")
        else:
            print("❌ model_hydraulic.py is missing the FIXED_FLOW_AVAILABLE flag")
        
        # Check if the model hydraulic function has been updated
        if "FIXED" in model_hydraulic.calculate_flood_area.__doc__:
            print("✅ calculate_flood_area function has been updated")
        else:
            print("❌ calculate_flood_area function has not been updated")
        
    except (ImportError, AttributeError) as e:
        print(f"❌ Could not verify model_hydraulic.py updates: {e}")
    
    print("\n=== SUMMARY ===")
    if fixed_available:
        print("The flow direction fix has been successfully implemented!")
        print("When you run the plugin in QGIS, it will use the fixed flow direction.")
    else:
        print("The flow direction fix needs more work.")
        print("Check that flow_direction_flood_fixed.py exists and is properly formatted.")
    
    return fixed_available

if __name__ == "__main__":
    success = check_fixed_flow_availability()
    sys.exit(0 if success else 1)
