#!/usr/bin/env python3
"""
Update the FloodEngine UI to use the safe animation launch method.
This script directly updates the launch_animation_controls method to use the QGIS-safe approach.
"""

import os

def update_ui_file():
    """Update the UI file with the corrected method."""
    ui_file_path = r"c:\Plugin\VSCode\Alt3\FloodEngineX\floodengine_ui.py"
    
    # Read the current file
    with open(ui_file_path, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()
    
    # Define the new method content
    new_method = '''    def launch_animation_controls(self, output_folder):
        """Launch animation controls after simulation completion."""
        print(f"🎬 Attempting to launch animation from: {output_folder}")
        
        try:
            # Use the safe launcher that handles QGIS module reload issues
            from qgis_module_reload_helper import launch_animation_safe
            
            # Get the parent window for proper dialog management
            parent_window = None
            try:
                # Try to get QGIS main window first
                from qgis.utils import iface
                if iface and hasattr(iface, 'mainWindow') and iface.mainWindow():
                    parent_window = iface.mainWindow()
                    print("✅ Using QGIS main window as parent")
                else:
                    # Fall back to this widget's parent
                    parent_window = self.parent() if hasattr(self, 'parent') else None
                    print(f"✅ Using widget parent: {type(parent_window).__name__ if parent_window else 'None'}")
            except ImportError:
                # Not in QGIS, use this widget's parent
                parent_window = self.parent() if hasattr(self, 'parent') else None
                print(f"✅ Using widget parent (no QGIS): {type(parent_window).__name__ if parent_window else 'None'}")
            
            # Launch using the safe method
            result = launch_animation_safe(output_folder, parent_window)
            
            if result:
                print("✅ Animation controls launched successfully!")
                
                # Store persistent reference in the UI to prevent garbage collection
                self._animation_dialog = result
                print("✅ Stored persistent reference to animation dialog")
                
                # Also store in dialog manager for extra persistence
                try:
                    from dialog_manager import store_animation_dialog
                    store_animation_dialog(result)
                    print("✅ Stored in dialog manager")
                except Exception as e:
                    print(f"⚠️ Could not store in dialog manager: {e}")
                
                self.show_message("Animation controls are now available!")
            else:
                print("❌ Animation launch failed")
                self.show_message("Animation launch failed - check console for details")
                
        except ImportError as e:
            print(f"❌ Cannot import animation launcher: {e}")
            self.show_message("Animation module not available")
        except Exception as e:
            print(f"❌ Unexpected animation error: {e}")
            import traceback
            traceback.print_exc()
            self.show_message(f"Animation error: {e}")'''
    
    # Find the start and end of the current method
    method_start = content.find("    def launch_animation_controls(self, output_folder):")
    if method_start == -1:
        print("❌ Could not find the launch_animation_controls method")
        return False
    
    # Find the next method (or end of class) to determine where this method ends
    lines = content[method_start:].split('\n')
    method_end_line = 1  # Start after the def line
    
    for i, line in enumerate(lines[1:], 1):
        # Check if this is the start of a new method or end of class
        if line.strip() and not line.startswith('        ') and not line.startswith('\t\t'):
            # This line is not indented as part of the method
            if line.strip().startswith('def ') or line.strip() in ['', 'class ', '}']:
                method_end_line = i
                break
    
    # Calculate the actual position in the content
    method_end_pos = method_start
    for i in range(method_end_line):
        method_end_pos = content.find('\n', method_end_pos) + 1
    
    # Replace the method
    new_content = content[:method_start] + new_method + content[method_end_pos:]
    
    # Write the updated content back
    try:
        with open(ui_file_path + '.backup', 'w', encoding='utf-8') as f:
            f.write(content)
        print("✅ Created backup file")
        
        with open(ui_file_path, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print("✅ Updated UI file successfully")
        return True
    except Exception as e:
        print(f"❌ Error writing file: {e}")
        return False

if __name__ == "__main__":
    print("FloodEngine UI Update Script")
    print("=" * 40)
    
    if update_ui_file():
        print("✅ UI file updated successfully!")
        print("📝 The launch_animation_controls method now uses the safe launcher")
        print("🔄 QGIS will need to be restarted or the plugin reloaded")
    else:
        print("❌ Failed to update UI file")
