# -*- coding: utf-8 -*-
"""
FloodEngine v4.0 - Performance Optimization Module
==================================================

This module provides comprehensive performance optimization capabilities for FloodEngine
including memory management, parallel processing, adaptive algorithms, and performance
monitoring. Designed to handle large-scale flood simulations efficiently.

Features:
- Memory-optimized data structures and algorithms
- Multi-threading and multiprocessing support
- Adaptive time stepping and grid refinement
- Performance profiling and monitoring
- Caching systems for repeated computations
- Memory-mapped file operations for large datasets
- Efficient sparse matrix operations

Author: FloodEngine Development Team
Date: June 7, 2025
Version: 4.0
"""

import numpy as np
import os
import sys
import time
import psutil
import threading
import multiprocessing as mp
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
from functools import lru_cache, wraps
from typing import Optional, Tuple, Dict, Any, List, Callable, Union
import json
import logging
import gc
from dataclasses import dataclass
from contextlib import contextmanager

# Memory mapping support
try:
    import h5py
    HDF5_AVAILABLE = True
except ImportError:
    HDF5_AVAILABLE = False
    h5py = None

# Sparse matrix operations
try:
    from scipy import sparse
    SPARSE_AVAILABLE = True
except ImportError:
    SPARSE_AVAILABLE = False
    sparse = None

@dataclass
class PerformanceMetrics:
    """Container for performance monitoring data."""
    computation_time: float = 0.0
    memory_usage_mb: float = 0.0
    peak_memory_mb: float = 0.0
    cpu_usage_percent: float = 0.0
    io_time: float = 0.0
    cache_hits: int = 0
    cache_misses: int = 0
    grid_cells_processed: int = 0
    time_steps_computed: int = 0

class MemoryManager:
    """
    Advanced memory management for large-scale flood simulations.
    """
    
    def __init__(self, max_memory_gb: float = None):
        """
        Initialize memory manager.
        
        Args:
            max_memory_gb: Maximum memory to use (None for auto-detect)
        """
        self.process = psutil.Process()
        self.max_memory_bytes = self._determine_max_memory(max_memory_gb)
        self.memory_pools = {}
        self.cached_arrays = {}
        self.logger = logging.getLogger(__name__)
        
        # Memory monitoring
        self.peak_memory = 0.0
        self.memory_warnings = 0
        
    def _determine_max_memory(self, max_memory_gb: Optional[float]) -> int:
        """Determine maximum memory allocation."""
        if max_memory_gb is not None:
            return int(max_memory_gb * 1e9)
        
        # Use 80% of available system memory
        available_memory = psutil.virtual_memory().available
        return int(0.8 * available_memory)
    
    def get_memory_usage(self) -> Dict[str, float]:
        """Get current memory usage statistics."""
        memory_info = self.process.memory_info()
        virtual_memory = psutil.virtual_memory()
        
        usage = {
            'process_rss_mb': memory_info.rss / 1e6,
            'process_vms_mb': memory_info.vms / 1e6,
            'system_available_mb': virtual_memory.available / 1e6,
            'system_used_percent': virtual_memory.percent,
            'peak_memory_mb': self.peak_memory / 1e6
        }
        
        # Update peak memory
        self.peak_memory = max(self.peak_memory, memory_info.rss)
        
        return usage
    
    def check_memory_pressure(self) -> bool:
        """Check if system is under memory pressure."""
        memory_info = self.process.memory_info()
        
        # Check if we're approaching limits
        if memory_info.rss > self.max_memory_bytes * 0.9:
            self.memory_warnings += 1
            self.logger.warning(f"High memory usage: {memory_info.rss / 1e6:.1f} MB")
            return True
        
        return False
    
    def create_memory_mapped_array(self, filename: str, shape: Tuple[int, ...], 
                                 dtype: np.dtype = np.float32) -> np.ndarray:
        """Create memory-mapped array for large data handling."""
        try:
            # Create memory-mapped array
            array = np.memmap(filename, dtype=dtype, mode='w+', shape=shape)
            self.logger.info(f"Created memory-mapped array: {filename}, shape={shape}")
            return array
        except Exception as e:
            self.logger.error(f"Failed to create memory-mapped array: {e}")
            # Fall back to regular array
            return np.zeros(shape, dtype=dtype)
    
    def optimize_array_layout(self, array: np.ndarray) -> np.ndarray:
        """Optimize array memory layout for better cache performance."""
        if not array.flags.c_contiguous:
            self.logger.debug("Converting array to C-contiguous layout")
            return np.ascontiguousarray(array)
        return array
    
    def cleanup_memory(self):
        """Force memory cleanup and garbage collection."""
        # Clear cached arrays
        for key in list(self.cached_arrays.keys()):
            del self.cached_arrays[key]
        
        # Force garbage collection
        collected = gc.collect()
        self.logger.debug(f"Garbage collector freed {collected} objects")
        
        # Clear memory pools
        self.memory_pools.clear()

class ParallelProcessor:
    """
    Parallel processing manager for computational acceleration.
    """
    
    def __init__(self, max_workers: Optional[int] = None, use_processes: bool = False):
        """
        Initialize parallel processor.
        
        Args:
            max_workers: Maximum number of worker threads/processes
            use_processes: Use multiprocessing instead of threading
        """
        self.max_workers = max_workers or min(mp.cpu_count(), 8)
        self.use_processes = use_processes
        self.logger = logging.getLogger(__name__)
        
    def parallel_grid_operation(self, operation: Callable, grid: np.ndarray, 
                              *args, **kwargs) -> np.ndarray:
        """
        Apply operation to grid in parallel chunks.
        
        Args:
            operation: Function to apply to each chunk
            grid: Input grid to process
            *args, **kwargs: Additional arguments for operation
            
        Returns:
            Processed grid
        """
        if grid.size < 10000:  # Use serial for small grids
            return operation(grid, *args, **kwargs)
        
        # Determine chunk strategy
        ny, nx = grid.shape
        chunk_size = max(ny // self.max_workers, 10)
        
        # Create chunks
        chunks = []
        for i in range(0, ny, chunk_size):
            end_i = min(i + chunk_size, ny)
            chunks.append((i, end_i, grid[i:end_i, :]))
        
        # Process chunks in parallel
        if self.use_processes:
            with ProcessPoolExecutor(max_workers=self.max_workers) as executor:
                futures = [executor.submit(operation, chunk, *args, **kwargs) 
                          for _, _, chunk in chunks]
                results = [future.result() for future in futures]
        else:
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                futures = [executor.submit(operation, chunk, *args, **kwargs) 
                          for _, _, chunk in chunks]
                results = [future.result() for future in futures]
        
        # Reassemble results
        output_grid = np.zeros_like(grid)
        for (start_i, end_i, _), result in zip(chunks, results):
            output_grid[start_i:end_i, :] = result
        
        return output_grid
    
    def parallel_time_steps(self, step_function: Callable, initial_state: Dict[str, Any],
                          num_steps: int, dt: float) -> List[Dict[str, Any]]:
        """
        Process multiple time steps with parallel preprocessing.
        
        Args:
            step_function: Function to compute single time step
            initial_state: Initial state dictionary
            num_steps: Number of time steps
            dt: Time step size
            
        Returns:
            List of states for each time step
        """
        states = [initial_state.copy()]
        current_state = initial_state.copy()
        
        # Sequential time stepping (dependency chain)
        # Parallel optimization applied within each step
        for step in range(num_steps):
            current_state = step_function(current_state, dt, step)
            states.append(current_state.copy())
        
        return states

class AdaptiveTimestepping:
    """
    Adaptive time stepping for numerical stability and efficiency.
    """
    
    def __init__(self, initial_dt: float = 0.01, min_dt: float = 1e-6, 
                 max_dt: float = 1.0, cfl_target: float = 0.8):
        """
        Initialize adaptive time stepping.
        
        Args:
            initial_dt: Initial time step
            min_dt: Minimum allowed time step
            max_dt: Maximum allowed time step
            cfl_target: Target CFL number
        """
        self.dt = initial_dt
        self.min_dt = min_dt
        self.max_dt = max_dt
        self.cfl_target = cfl_target
        self.dt_history = [initial_dt]
        self.cfl_history = []
        
    def compute_cfl_number(self, h: np.ndarray, u: np.ndarray, v: np.ndarray,
                          dx: float, dy: float, g: float = 9.81) -> float:
        """
        Compute CFL number for shallow water equations.
        
        Args:
            h: Water depth
            u: X-velocity
            v: Y-velocity
            dx: Grid spacing X
            dy: Grid spacing Y
            g: Gravitational acceleration
            
        Returns:
            Maximum CFL number
        """
        # Wave speed
        valid_mask = h > 1e-6
        if not np.any(valid_mask):
            return 0.0
        
        wave_speed = np.sqrt(g * h[valid_mask])
        velocity_magnitude = np.sqrt(u[valid_mask]**2 + v[valid_mask]**2)
        characteristic_speed = wave_speed + velocity_magnitude
        
        # CFL number
        cfl_x = np.max(characteristic_speed * self.dt / dx)
        cfl_y = np.max(characteristic_speed * self.dt / dy)
        
        return max(cfl_x, cfl_y)
    
    def adapt_timestep(self, current_cfl: float) -> float:
        """
        Adapt time step based on CFL number.
        
        Args:
            current_cfl: Current CFL number
            
        Returns:
            New time step
        """
        self.cfl_history.append(current_cfl)
        
        if current_cfl > 0:
            # Adjust time step to target CFL
            dt_new = self.dt * (self.cfl_target / current_cfl)
            
            # Apply damping to prevent oscillations
            damping_factor = 0.8
            dt_new = self.dt + damping_factor * (dt_new - self.dt)
            
            # Enforce limits
            dt_new = np.clip(dt_new, self.min_dt, self.max_dt)
            
            # Prevent too rapid changes
            max_change = 1.5
            if dt_new > max_change * self.dt:
                dt_new = max_change * self.dt
            elif dt_new < self.dt / max_change:
                dt_new = self.dt / max_change
                
            self.dt = dt_new
        
        self.dt_history.append(self.dt)
        return self.dt

class CacheManager:
    """
    Intelligent caching system for repeated computations.
    """
    
    def __init__(self, max_cache_size: int = 100):
        """
        Initialize cache manager.
        
        Args:
            max_cache_size: Maximum number of cached items
        """
        self.max_cache_size = max_cache_size
        self.cache_stats = {'hits': 0, 'misses': 0}
        self.logger = logging.getLogger(__name__)
    
    def cached_computation(self, cache_key: str = None):
        """
        Decorator for caching expensive computations.
        
        Args:
            cache_key: Optional custom cache key
        """
        def decorator(func):
            func._cache = {}
            
            @wraps(func)
            def wrapper(*args, **kwargs):
                # Generate cache key
                if cache_key:
                    key = cache_key
                else:
                    # Create key from function name and arguments
                    key = f"{func.__name__}_{hash(str(args) + str(sorted(kwargs.items())))}"
                
                # Check cache
                if key in func._cache:
                    self.cache_stats['hits'] += 1
                    return func._cache[key]
                
                # Compute and cache
                result = func(*args, **kwargs)
                
                # Manage cache size
                if len(func._cache) >= self.max_cache_size:
                    # Remove oldest entry (simple FIFO)
                    oldest_key = next(iter(func._cache))
                    del func._cache[oldest_key]
                
                func._cache[key] = result
                self.cache_stats['misses'] += 1
                
                return result
            
            return wrapper
        return decorator
    
    def get_cache_efficiency(self) -> float:
        """Calculate cache hit rate."""
        total = self.cache_stats['hits'] + self.cache_stats['misses']
        if total == 0:
            return 0.0
        return self.cache_stats['hits'] / total

class PerformanceProfiler:
    """
    Performance profiling and monitoring system.
    """
    
    def __init__(self):
        """Initialize performance profiler."""
        self.metrics = PerformanceMetrics()
        self.profile_stack = []
        self.function_profiles = {}
        self.logger = logging.getLogger(__name__)
    
    @contextmanager
    def profile_section(self, section_name: str):
        """Context manager for profiling code sections."""
        start_time = time.time()
        start_memory = psutil.Process().memory_info().rss
        
        self.profile_stack.append(section_name)
        
        try:
            yield
        finally:
            end_time = time.time()
            end_memory = psutil.Process().memory_info().rss
            
            execution_time = end_time - start_time
            memory_delta = end_memory - start_memory
            
            # Store profile data
            if section_name not in self.function_profiles:
                self.function_profiles[section_name] = {
                    'total_time': 0.0,
                    'call_count': 0,
                    'avg_time': 0.0,
                    'max_time': 0.0,
                    'memory_usage': []
                }
            
            profile = self.function_profiles[section_name]
            profile['total_time'] += execution_time
            profile['call_count'] += 1
            profile['avg_time'] = profile['total_time'] / profile['call_count']
            profile['max_time'] = max(profile['max_time'], execution_time)
            profile['memory_usage'].append(memory_delta)
            
            self.profile_stack.pop()
    
    def profile_function(self, func):
        """Decorator for automatic function profiling."""
        @wraps(func)
        def wrapper(*args, **kwargs):
            with self.profile_section(func.__name__):
                return func(*args, **kwargs)
        return wrapper
    
    def get_performance_report(self) -> Dict[str, Any]:
        """Generate comprehensive performance report."""
        total_time = sum(p['total_time'] for p in self.function_profiles.values())
        
        report = {
            'total_execution_time': total_time,
            'peak_memory_mb': self.metrics.peak_memory_mb,
            'function_profiles': {},
            'top_time_consumers': [],
            'memory_efficiency': {}
        }
        
        # Function-level analysis
        for func_name, profile in self.function_profiles.items():
            report['function_profiles'][func_name] = {
                'total_time': profile['total_time'],
                'avg_time': profile['avg_time'],
                'max_time': profile['max_time'],
                'call_count': profile['call_count'],
                'time_percentage': (profile['total_time'] / total_time * 100) if total_time > 0 else 0,
                'avg_memory_mb': np.mean(profile['memory_usage']) / 1e6 if profile['memory_usage'] else 0
            }
        
        # Top time consumers
        sorted_functions = sorted(self.function_profiles.items(), 
                                key=lambda x: x[1]['total_time'], reverse=True)
        report['top_time_consumers'] = [
            {'function': name, 'time': profile['total_time'], 
             'percentage': profile['total_time'] / total_time * 100 if total_time > 0 else 0}
            for name, profile in sorted_functions[:10]
        ]
        
        return report

class PerformanceOptimizer:
    """
    Main performance optimization coordinator.
    """
    
    def __init__(self, max_memory_gb: Optional[float] = None, 
                 max_workers: Optional[int] = None):
        """
        Initialize performance optimizer.
        
        Args:
            max_memory_gb: Maximum memory allocation
            max_workers: Maximum parallel workers
        """
        self.memory_manager = MemoryManager(max_memory_gb)
        self.parallel_processor = ParallelProcessor(max_workers)
        self.adaptive_timestepping = AdaptiveTimestepping()
        self.cache_manager = CacheManager()
        self.profiler = PerformanceProfiler()
        self.logger = logging.getLogger(__name__)
        
        # Optimization settings
        self.auto_optimize = True
        self.optimization_history = []
    
    def optimize_simulation_setup(self, grid_shape: Tuple[int, int], 
                                 simulation_time: float, dt: float) -> Dict[str, Any]:
        """
        Optimize simulation parameters based on problem size.
        
        Args:
            grid_shape: (ny, nx) grid dimensions
            simulation_time: Total simulation time
            dt: Initial time step
            
        Returns:
            Optimization recommendations
        """
        ny, nx = grid_shape
        total_cells = ny * nx
        estimated_steps = int(simulation_time / dt)
        
        # Memory requirements estimation
        bytes_per_cell = 4 * 5  # 5 float32 arrays (h, u, v, z, etc.)
        estimated_memory_mb = (total_cells * bytes_per_cell) / 1e6
        
        # Performance recommendations
        recommendations = {
            'grid_cells': total_cells,
            'estimated_memory_mb': estimated_memory_mb,
            'estimated_time_steps': estimated_steps,
            'use_memory_mapping': estimated_memory_mb > 1000,
            'parallel_processing': total_cells > 50000,
            'adaptive_timestepping': estimated_steps > 1000,
            'gpu_acceleration': total_cells > 100000,
            'optimization_level': self._determine_optimization_level(total_cells, estimated_memory_mb)
        }
        
        # Detailed recommendations
        if recommendations['use_memory_mapping']:
            recommendations['memory_mapping_note'] = "Large grid detected. Consider memory-mapped arrays for efficiency."
        
        if recommendations['parallel_processing']:
            optimal_workers = min(self.parallel_processor.max_workers, max(2, total_cells // 25000))
            recommendations['recommended_workers'] = optimal_workers
        
        if recommendations['gpu_acceleration']:
            recommendations['gpu_note'] = "Large computation detected. GPU acceleration strongly recommended."
        
        return recommendations
    
    def _determine_optimization_level(self, total_cells: int, memory_mb: float) -> str:
        """Determine appropriate optimization level."""
        if total_cells > 500000 or memory_mb > 2000:
            return "aggressive"
        elif total_cells > 100000 or memory_mb > 500:
            return "moderate"
        else:
            return "basic"
    
    def optimized_shallow_water_step(self, h: np.ndarray, u: np.ndarray, v: np.ndarray,
                                   z: np.ndarray, dt: float, dx: float, dy: float) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Optimized Saint-Venant shallow water step with all optimizations applied.
        
        Args:
            h: Water depth
            u: X-velocity
            v: Y-velocity
            z: Bed elevation
            dt: Time step
            dx: Grid spacing X
            dy: Grid spacing Y
            
        Returns:
            Updated (h, u, v) arrays
        """
        with self.profiler.profile_section("shallow_water_step"):
            # Memory optimization
            h = self.memory_manager.optimize_array_layout(h)
            u = self.memory_manager.optimize_array_layout(u)
            v = self.memory_manager.optimize_array_layout(v)
            
            # Check memory pressure
            if self.memory_manager.check_memory_pressure():
                self.memory_manager.cleanup_memory()
            
            # Adaptive time stepping
            current_cfl = self.adaptive_timestepping.compute_cfl_number(h, u, v, dx, dy)
            adapted_dt = self.adaptive_timestepping.adapt_timestep(current_cfl)
            
            # Use adapted time step if significantly different
            if abs(adapted_dt - dt) / dt > 0.1:
                dt = adapted_dt
                self.logger.debug(f"Adapted timestep: {dt:.6f}, CFL: {current_cfl:.3f}")
            
            # Parallel computation for large grids
            if h.size > 50000:
                return self._parallel_shallow_water_step(h, u, v, z, dt, dx, dy)
            else:
                return self._serial_shallow_water_step(h, u, v, z, dt, dx, dy)
    
    def _parallel_shallow_water_step(self, h, u, v, z, dt, dx, dy):
        """Parallel implementation of shallow water step."""
        def compute_chunk(chunk_data):
            h_chunk, u_chunk, v_chunk, z_chunk = chunk_data
            return self._serial_shallow_water_step(h_chunk, u_chunk, v_chunk, z_chunk, dt, dx, dy)
        
        # This is a simplified parallel approach
        # In practice, would need careful handling of boundary conditions
        return self.parallel_processor.parallel_grid_operation(compute_chunk, h, u, v, z)
    
    @staticmethod
    def _serial_shallow_water_step(h, u, v, z, dt, dx, dy, g=9.81):
        """Optimized serial implementation."""
        ny, nx = h.shape
        h_new = np.zeros_like(h)
        u_new = np.zeros_like(u)
        v_new = np.zeros_like(v)
        
        # Vectorized computation for internal cells
        i_slice = slice(1, nx-1)
        j_slice = slice(1, ny-1)
        
        # Water surface elevation
        eta = h + z
        
        # Compute gradients (vectorized)
        deta_dx = (eta[j_slice, 2:] - eta[j_slice, :-2]) / (2 * dx)
        deta_dy = (eta[2:, i_slice] - eta[:-2, i_slice]) / (2 * dy)
        
        du_dx = (u[j_slice, 2:] - u[j_slice, :-2]) / (2 * dx)
        dv_dy = (v[2:, i_slice] - v[:-2, i_slice]) / (2 * dy)
        
        # Current values
        h_c = h[j_slice, i_slice]
        u_c = u[j_slice, i_slice]
        v_c = v[j_slice, i_slice]
        
        # Only process wet cells
        wet_mask = h_c > 1e-6
        
        # Saint-Venant equations (vectorized)
        dh_dt = np.zeros_like(h_c)
        du_dt = np.zeros_like(u_c)
        dv_dt = np.zeros_like(v_c)
        
        dh_dt[wet_mask] = -h_c[wet_mask] * (du_dx[wet_mask] + dv_dy[wet_mask])
        du_dt[wet_mask] = -g * deta_dx[wet_mask]
        dv_dt[wet_mask] = -g * deta_dy[wet_mask]
        
        # Update (vectorized)
        h_new[j_slice, i_slice] = np.maximum(0, h_c + dt * dh_dt)
        u_new[j_slice, i_slice] = u_c + dt * du_dt
        v_new[j_slice, i_slice] = v_c + dt * dv_dt
        
        return h_new, u_new, v_new
    
    def generate_optimization_report(self) -> Dict[str, Any]:
        """Generate comprehensive optimization report."""
        memory_usage = self.memory_manager.get_memory_usage()
        performance_report = self.profiler.get_performance_report()
        cache_efficiency = self.cache_manager.get_cache_efficiency()
        
        report = {
            'timestamp': time.time(),
            'memory_management': {
                'current_usage_mb': memory_usage['process_rss_mb'],
                'peak_usage_mb': memory_usage['peak_memory_mb'],
                'system_available_mb': memory_usage['system_available_mb'],
                'memory_warnings': self.memory_manager.memory_warnings
            },
            'parallel_processing': {
                'max_workers': self.parallel_processor.max_workers,
                'use_processes': self.parallel_processor.use_processes
            },
            'adaptive_timestepping': {
                'current_dt': self.adaptive_timestepping.dt,
                'min_dt': self.adaptive_timestepping.min_dt,
                'max_dt': self.adaptive_timestepping.max_dt,
                'cfl_target': self.adaptive_timestepping.cfl_target,
                'dt_adaptations': len(self.adaptive_timestepping.dt_history) - 1
            },
            'caching': {
                'cache_efficiency': cache_efficiency,
                'cache_hits': self.cache_manager.cache_stats['hits'],
                'cache_misses': self.cache_manager.cache_stats['misses']
            },
            'performance_profile': performance_report,
            'optimization_recommendations': self._generate_recommendations()
        }
        
        return report
    
    def _generate_recommendations(self) -> List[str]:
        """Generate optimization recommendations based on current state."""
        recommendations = []
        
        memory_usage = self.memory_manager.get_memory_usage()
        
        # Memory recommendations
        if memory_usage['process_rss_mb'] > 2000:
            recommendations.append("Consider using memory-mapped arrays for large datasets")
        
        if self.memory_manager.memory_warnings > 5:
            recommendations.append("Frequent memory warnings detected. Reduce grid size or increase available memory")
        
        # Cache recommendations
        cache_efficiency = self.cache_manager.get_cache_efficiency()
        if cache_efficiency < 0.5 and self.cache_manager.cache_stats['misses'] > 100:
            recommendations.append("Low cache efficiency. Consider increasing cache size or optimizing computation patterns")
        
        # Time stepping recommendations
        if len(self.adaptive_timestepping.dt_history) > 100:
            recent_adaptations = len([dt for dt in self.adaptive_timestepping.dt_history[-50:] 
                                    if abs(dt - self.adaptive_timestepping.dt_history[-51]) / self.adaptive_timestepping.dt_history[-51] > 0.1])
            if recent_adaptations > 25:
                recommendations.append("Frequent timestep adaptations. Consider adjusting CFL target or initial timestep")
        
        return recommendations

# Factory function for easy integration
def create_performance_optimizer(max_memory_gb: Optional[float] = None,
                               max_workers: Optional[int] = None) -> PerformanceOptimizer:
    """
    Factory function to create performance optimizer.
    
    Args:
        max_memory_gb: Maximum memory allocation
        max_workers: Maximum parallel workers
        
    Returns:
        Configured PerformanceOptimizer instance
    """
    return PerformanceOptimizer(max_memory_gb, max_workers)

# Example usage and testing
if __name__ == "__main__":
    print("FloodEngine Performance Optimization Test")
    print("========================================")
    
    # Create optimizer
    optimizer = create_performance_optimizer(max_memory_gb=4.0, max_workers=4)
    
    # Test with sample data
    nx, ny = 500, 400
    h = np.random.uniform(0.1, 2.0, (ny, nx)).astype(np.float32)
    u = np.random.uniform(-0.5, 0.5, (ny, nx)).astype(np.float32)
    v = np.random.uniform(-0.5, 0.5, (ny, nx)).astype(np.float32)
    z = np.random.uniform(0, 5, (ny, nx)).astype(np.float32)
    
    dt, dx, dy = 0.01, 1.0, 1.0
    
    print(f"Testing {nx}x{ny} grid...")
    
    # Get optimization recommendations
    recommendations = optimizer.optimize_simulation_setup((ny, nx), 100.0, dt)
    print(f"Optimization level: {recommendations['optimization_level']}")
    print(f"Estimated memory: {recommendations['estimated_memory_mb']:.1f} MB")
    
    # Test optimized computation
    start_time = time.time()
    h_new, u_new, v_new = optimizer.optimized_shallow_water_step(h, u, v, z, dt, dx, dy)
    end_time = time.time()
    
    print(f"Computation time: {end_time - start_time:.4f} seconds")
    print(f"Performance: {(nx * ny) / (end_time - start_time):.0f} cells/second")
    
    # Generate optimization report
    report = optimizer.generate_optimization_report()
    print(f"\nMemory usage: {report['memory_management']['current_usage_mb']:.1f} MB")
    print(f"Cache efficiency: {report['caching']['cache_efficiency']:.2%}")
    print(f"Current timestep: {report['adaptive_timestepping']['current_dt']:.6f}")
    
    if report['optimization_recommendations']:
        print("\nRecommendations:")
        for rec in report['optimization_recommendations']:
            print(f"- {rec}")
    else:
        print("\nNo optimization recommendations at this time.")
    
    print("\nPerformance optimization test completed!")
