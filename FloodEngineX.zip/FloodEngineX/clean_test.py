# Basic test for SaintVenant2D
print("Starting SaintVenant2D test...")

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import numpy as np
from saint_venant_2d import SaintVenant2D

# Create a simple DEM array
print("Creating test DEM...")
dem_size = 20
dem = np.ones((dem_size, dem_size)) * 100.0

# Create a river channel that runs from top to bottom with decreasing elevation
for i in range(dem_size):
    # Make a channel in the middle
    dem[i, 8:12] = 98.0 - i * 0.2  # Channel slopes downward

# Create the model
print("Initializing Saint-Venant model...")
model = SaintVenant2D(dem, (0, 1, 0, 0, 0, -1), manning_n=0.035)

# Set initial water level at 98.1 (just above highest part of river)
print("Setting initial water level...")
model.set_initial_condition(water_level=98.1)

# Check that water was set correctly
if np.max(model.h) > 0:
    print(f"Water initialized successfully. Max depth: {np.max(model.h):.3f}m")
else:
    print("ERROR: No water was initialized")
    sys.exit(1)

# Find the highest point in the river
river_mask = model.h > 0.001
if np.sum(river_mask) > 0:
    river_elevations = np.where(river_mask, dem, -np.inf)
    highest_idx = np.unravel_index(np.argmax(river_elevations), dem.shape)
    py, px = highest_idx
    print(f"Highest point in river found at ({px}, {py}) with elevation {dem[py, px]:.2f}m")
    
    # Ensure water at the source
    model.h[py, px] = 0.5  # Set to 0.5m depth
    
    # Run a few simulation steps
    print("\nRunning simulation steps...")
    for step in range(3):
        # Step the model
        dt = model.step()
        
        # Print statistics
        print(f"Step {step+1}: dt={dt:.3f}s, Max depth={np.max(model.h):.3f}m")
        
        # Count wet cells
        wet_cells = np.sum(model.h > 0.01)
        print(f"  Water present in {wet_cells} cells")
        
        # Check velocity
        if np.max(model.velocity_mag) > 0:
            print(f"  Water is flowing with max velocity={np.max(model.velocity_mag):.3f}m/s")
    
    print("\nTEST COMPLETED SUCCESSFULLY!")
else:
    print("ERROR: No cells in river network")
    sys.exit(1)
