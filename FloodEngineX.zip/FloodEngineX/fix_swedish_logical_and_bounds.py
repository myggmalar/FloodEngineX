import re
import os
import traceback

# Add debug print at the start
print("Starting Swedish logical operators and comparison fixes script...")

try:
    # Get absolute path to the script's directory and the model_hydraulic.py file
    script_dir = os.path.dirname(os.path.abspath(__file__))
    filename = os.path.join(script_dir, "model_hydraulic.py")

    print(f"Opening file: {filename}")

    with open(filename, "r", encoding="utf-8") as f:
        code = f.read()
    
    print(f"File loaded, size: {len(code)} characters")

    # Replace Swedish logical operators 
    eller_count = code.count("eller")
    och_count = code.count("och")
    
    code = code.replace("eller", "or")
    code = code.replace("och", "and")
    
    print(f"Swedish operators found - eller: {eller_count}, och: {och_count}")

    # Patterns for array bounds with assignment instead of comparison
    patterns = [
        # Fix if condition with assignment for array bounds
        (r"if\s*\(\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*velocity_x\.shape\[1\]", 
         r"if (\1 < 0 or \1 >= velocity_x.shape[1]"),
        (r"if\s*\(\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*velocity_y\.shape\[0\]", 
         r"if (\1 < 0 or \1 >= velocity_y.shape[0]"),
        
        # Handle specific cases from the errors
        (r"if\s*\(\s*next_px\s*=\s*velocity_x\.shape\[1\]", 
         r"if (next_px < 0 or next_px >= velocity_x.shape[1]"),
        (r"if\s*\(\s*next_py\s*=\s*velocity_y\.shape\[0\]", 
         r"if (next_py < 0 or next_py >= velocity_y.shape[0]"),
        (r"if\s*\(\s*full_px\s*=\s*velocity_x\.shape\[1\]", 
         r"if (full_px < 0 or full_px >= velocity_x.shape[1]"),
        (r"if\s*\(\s*full_py\s*=\s*velocity_y\.shape\[0\]", 
         r"if (full_py < 0 or full_py >= velocity_y.shape[0]"),
        (r"if\s*\(\s*mid_px\s*=\s*velocity_x\.shape\[1\]", 
         r"if (mid_px < 0 or mid_px >= velocity_x.shape[1]"),
        (r"if\s*\(\s*mid_py\s*=\s*velocity_y\.shape\[0\]", 
         r"if (mid_py < 0 or mid_py >= velocity_y.shape[0]"),
        
        # Handle any assignment in if statements (more general)
        (r"if\s*\(\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*([^=])", 
         r"if (\1 == \2"),
    ]

    replacements_made = 0

    for pat, repl in patterns:
        print(f"Checking pattern: {pat}")
        new_code, count = re.subn(pat, repl, code)
        if count > 0:
            code = new_code
            replacements_made += count
            print(f"Made {count} replacements with pattern: {pat}")

    print(f"Writing changes back to file with {replacements_made} fixes...")
    # Save the fixed file
    with open(filename, "w", encoding="utf-8") as f:
        f.write(code)

    print(f"Fixed {replacements_made} syntax issues in model_hydraulic.py")
    print(f"Replaced {eller_count} instances of 'eller' with 'or'")
    print(f"Replaced {och_count} instances of 'och' with 'and'")

    # Run a quick verification
    try:
        print("Running syntax check...")
        # Try to compile the file to check for syntax errors
        with open(filename, "r", encoding="utf-8") as f:
            compile(f.read(), filename, "exec")
        print("Syntax check passed! The file should now be error-free.")
    except SyntaxError as e:
        print(f"WARNING: There are still syntax errors in the file: {e}")
        print(f"Error occurred at line {e.lineno}: {e.text.strip()}")
        print("You may need to manually fix this issue.")
except Exception as e:
    print(f"ERROR: {e}")
    traceback.print_exc()

print("Script completed.")

# Run this script automatically when imported
if __name__ == "__main__":
    print("Script executed directly.")
else:
    print("Script imported and running automatically.")