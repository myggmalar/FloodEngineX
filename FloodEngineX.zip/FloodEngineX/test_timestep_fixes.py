#!/usr/bin/env python3
"""
Test script for timestep simulation fixes in FloodEngine plugin.
Tests the three critical issues that were fixed:
1. Water level too low (changed from 10m to 60m)
2. Streamlines parameter fix (flood_layer vs water_level)
3. Enhanced water level generation
"""

import os
import sys
import re

def test_water_level_fix():
    """Test if initial water level was changed from 10m to 60m"""
    print("=" * 60)
    print("WATER LEVEL FIX TEST")
    print("=" * 60)
    
    ui_file = "floodengine_ui.py.normalized"
    if not os.path.exists(ui_file):
        print(f"   ❌ UI file not found: {ui_file}")
        return False
    
    with open(ui_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Look for the fixed water level
    if "initial_water_level = 60.0" in content:
        print("   ✅ Water level correctly set to 60.0m")
        return True
    elif "initial_water_level = 10.0" in content:
        print("   ❌ Water level still at old value of 10.0m")
        return False
    else:
        print("   ⚠️  Water level setting not found")
        return False

def test_streamlines_parameter_fix():
    """Test if streamlines function gets correct parameter"""
    print("\n" + "=" * 60)
    print("STREAMLINES PARAMETER FIX TEST")
    print("=" * 60)
    
    ui_file = "floodengine_ui.py.normalized"
    if not os.path.exists(ui_file):
        print(f"   ❌ UI file not found: {ui_file}")
        return False
    
    with open(ui_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Look for the streamlines call with flood_layer parameter
    if "flood_layer=final_flood_layer" in content:
        print("   ✅ Streamlines correctly uses flood_layer parameter")
        return True
    elif "water_level=final_water_level" in content and "calculate_streamlines_ENHANCED" in content:
        print("   ❌ Streamlines still uses wrong water_level parameter")
        return False
    else:
        print("   ⚠️  Streamlines parameter usage not clearly identified")
        return False

def test_enhanced_water_level_generation():
    """Test if water level generation was enhanced"""
    print("\n" + "=" * 60)
    print("ENHANCED WATER LEVEL GENERATION TEST")
    print("=" * 60)
    
    model_file = "model_hydraulic.py"
    if not os.path.exists(model_file):
        print(f"   ❌ Model file not found: {model_file}")
        return False
    
    with open(model_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Look for enhanced water level generation
    enhanced_found = "generate_variable_water_levels_IMPROVED" in content
    base_accumulation_enhanced = "base_accumulation = 0.5" in content
    min_variation_enhanced = "min_variation = 0.2" in content
    
    if enhanced_found and (base_accumulation_enhanced or min_variation_enhanced):
        print("   ✅ Enhanced water level generation found")
        print(f"      - Function name: {'✅' if enhanced_found else '❌'}")
        print(f"      - Base accumulation (0.5m): {'✅' if base_accumulation_enhanced else '❌'}")
        print(f"      - Min variation (0.2m): {'✅' if min_variation_enhanced else '❌'}")
        return True
    else:
        print("   ❌ Enhanced water level generation not found or incomplete")
        return False

def test_dem_elevation_compatibility():
    """Test if water levels are compatible with DEM elevation range"""
    print("\n" + "=" * 60)
    print("DEM ELEVATION COMPATIBILITY TEST")
    print("=" * 60)
    
    # Expected DEM range after geoid correction: 32.6m to 86.0m
    dem_min = 32.6
    dem_max = 86.0
    water_level = 60.0  # New water level
    
    print(f"   DEM elevation range: {dem_min}m to {dem_max}m")
    print(f"   Initial water level: {water_level}m")
    
    if dem_min <= water_level <= dem_max:
        flood_area_pct = ((water_level - dem_min) / (dem_max - dem_min)) * 100
        print(f"   ✅ Water level is within DEM range")
        print(f"   📊 Expected flood coverage: ~{flood_area_pct:.1f}% of terrain")
        return True
    else:
        print(f"   ❌ Water level is outside DEM range")
        return False

def test_function_signatures():
    """Test if function signatures are compatible"""
    print("\n" + "=" * 60)
    print("FUNCTION SIGNATURE TEST")
    print("=" * 60)
    
    # Check if streamlines function accepts flood_layer parameter
    streamlines_files = [
        "enhanced_streamlines.py",
        "model_hydraulic.py"
    ]
    
    found_enhanced_streamlines = False
    for file in streamlines_files:
        if os.path.exists(file):
            with open(file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            if "def calculate_streamlines_ENHANCED" in content:
                print(f"   ✅ Found calculate_streamlines_ENHANCED in {file}")
                
                # Look for flood_layer parameter
                if "flood_layer" in content:
                    print("   ✅ Function accepts flood_layer parameter")
                    found_enhanced_streamlines = True
                    break
    
    if not found_enhanced_streamlines:
        print("   ❌ Enhanced streamlines function not found or missing flood_layer parameter")
        return False
    
    return True

def main():
    """Run all tests"""
    print("FLOODENGINE TIMESTEP SIMULATION FIXES - VALIDATION TEST")
    print("=" * 80)
    print("Testing fixes for three critical issues:")
    print("1. Water level too low (10m → 60m)")
    print("2. Streamlines parameter error (water_level → flood_layer)")
    print("3. Enhanced water level generation")
    print("=" * 80)
    
    tests = [
        ("Water Level Fix", test_water_level_fix),
        ("Streamlines Parameter Fix", test_streamlines_parameter_fix),
        ("Enhanced Water Level Generation", test_enhanced_water_level_generation),
        ("DEM Elevation Compatibility", test_dem_elevation_compatibility),
        ("Function Signatures", test_function_signatures)
    ]
    
    results = []
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"   ❌ Error in {test_name}: {e}")
            results.append((test_name, False))
    
    # Summary
    print("\n" + "=" * 80)
    print("TEST SUMMARY")
    print("=" * 80)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"   {status}: {test_name}")
    
    print(f"\n📊 Overall Success Rate: {passed}/{total} ({(passed/total)*100:.1f}%)")
    
    if passed == total:
        print("🎉 ALL TESTS PASSED!")
        print("   The timestep simulation fixes are ready for deployment.")
        print("\n🚀 NEXT STEPS:")
        print("   1. Test with real QGIS environment")
        print("   2. Verify layers are added to canvas during simulation")
        print("   3. Check that flooding occurs at the new water level")
        print("   4. Validate streamlines generation works without errors")
    else:
        print("⚠️  SOME TESTS FAILED!")
        print("   Please review and fix the failing components before deployment.")

if __name__ == "__main__":
    main()
