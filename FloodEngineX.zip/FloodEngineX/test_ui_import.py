#!/usr/bin/env python3
"""Test FloodEngine UI import and basic validation"""

import sys
import os

def test_ui_import():
    """Test importing FloodEngine UI"""
    print("Testing FloodEngine UI import...")
    
    try:
        # Add current directory to path
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        
        # Try to import
        from floodengine_ui import FloodEngineDialog
        print("✅ FloodEngineDialog imported successfully")
        
        # Check if class has required methods
        required_methods = [
            'connect_signals',
            'toggle_groundwater_controls', 
            'toggle_urban_controls',
            'toggle_advanced_engine',
            'toggle_advanced_stream_burning'
        ]
        
        missing_methods = []
        for method in required_methods:
            if hasattr(FloodEngineDialog, method):
                print(f"✅ Method {method} found")
            else:
                print(f"❌ Method {method} missing")
                missing_methods.append(method)
        
        if missing_methods:
            print(f"\n❌ Missing methods: {missing_methods}")
            return False
        else:
            print("\n✅ All required methods found!")
            return True
            
    except SyntaxError as e:
        print(f"❌ Syntax Error: {e}")
        print(f"   Line {e.lineno}: {e.text}")
        return False
    except ImportError as e:
        print(f"❌ Import Error: {e}")
        return False
    except Exception as e:
        print(f"❌ Other Error: {type(e).__name__}: {e}")
        return False

if __name__ == "__main__":
    success = test_ui_import()
    sys.exit(0 if success else 1)
