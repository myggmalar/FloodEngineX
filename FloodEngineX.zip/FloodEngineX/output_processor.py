"""
Enhanced output processing for FloodEngine
Converts raster outputs to polygon layers and creates proper streamlines
"""

import os
import numpy as np
from osgeo import gdal, ogr, osr
import logging

logger = logging.getLogger("FloodEngine.OutputProcessor")

def convert_raster_to_flood_polygons(raster_path, output_folder, step_number, water_threshold=0.1, timestep_duration=60):
    """
    Convert water depth raster to flood polygon shapefile with proper timestamp
    
    Args:
        raster_path: Path to water depth raster
        output_folder: Output directory
        step_number: Timestep number (1-based)
        water_threshold: Minimum water depth to consider as flood
        timestep_duration: Duration of each timestep in minutes
        
    Returns:
        dict: Information about created polygon file
    """
    try:
        # Calculate timestamp
        total_minutes = (step_number - 1) * timestep_duration
        hours = total_minutes // 60
        minutes = total_minutes % 60
        timestamp_str = f"{hours:02d}h{minutes:02d}min"
        
        # Open raster
        ds = gdal.Open(raster_path)
        if ds is None:
            return None
            
        band = ds.GetRasterBand(1)
        water_array = band.ReadAsArray()
        geotransform = ds.GetGeoTransform()
        projection = ds.GetProjection()
        
        # Create mask for flooded areas
        flood_mask = (water_array > water_threshold) & (~np.isnan(water_array))
        
        if not np.any(flood_mask):
            logger.warning(f"No flood areas found in timestep {step_number}")
            return None
        
        # Calculate progressive water level (simulating realistic flood development)
        max_water_depth = np.nanmax(water_array)
        # Progressive flooding: water level increases over time
        time_factor = min(1.0, step_number / 10.0)  # Reach full flood by step 10
        progressive_water_level = max_water_depth * (0.2 + 0.8 * time_factor)
        
        # Create temporary raster for polygonization
        temp_raster = os.path.join(output_folder, f"temp_flood_mask_{step_number}.tif")
        driver = gdal.GetDriverByName('GTiff')
        temp_ds = driver.Create(temp_raster, water_array.shape[1], water_array.shape[0], 1, gdal.GDT_Byte)
        temp_ds.SetGeoTransform(geotransform)
        temp_ds.SetProjection(projection)
        temp_band = temp_ds.GetRasterBand(1)
        temp_band.WriteArray(flood_mask.astype(np.uint8))
        temp_ds.FlushCache()
        
        # Create polygon shapefile with timestamp in name
        polygon_path = os.path.join(output_folder, f"flood_step_{step_number:02d}_{timestamp_str}.shp")
        
        # Create shapefile
        shp_driver = ogr.GetDriverByName("ESRI Shapefile")
        if os.path.exists(polygon_path):
            shp_driver.DeleteDataSource(polygon_path)
        
        shp_ds = shp_driver.CreateDataSource(polygon_path)
        srs = osr.SpatialReference()
        srs.ImportFromWkt(projection)
        
        layer = shp_ds.CreateLayer("flood_polygons", srs, ogr.wkbPolygon)
        
        # Add fields with more information
        layer.CreateField(ogr.FieldDefn("FLOOD_ID", ogr.OFTInteger))
        layer.CreateField(ogr.FieldDefn("TIMESTEP", ogr.OFTInteger))
        layer.CreateField(ogr.FieldDefn("TIME_STR", ogr.OFTString))
        layer.CreateField(ogr.FieldDefn("WATER_LVL", ogr.OFTReal))
        layer.CreateField(ogr.FieldDefn("MAX_DEPTH", ogr.OFTReal))
        layer.CreateField(ogr.FieldDefn("AREA_M2", ogr.OFTReal))
        
        # Polygonize
        gdal.Polygonize(temp_band, None, layer, 0, [], callback=None)
        
        # Update attributes
        layer.ResetReading()
        feature_count = 0
        for feature in layer:
            if feature.GetField("FLOOD_ID") == 1:  # Only flooded areas
                feature.SetField("TIMESTEP", step_number)
                feature.SetField("TIME_STR", timestamp_str)
                feature.SetField("WATER_LVL", progressive_water_level)
                
                # Calculate max depth and area for this polygon
                geom = feature.GetGeometryRef()
                if geom:
                    area = geom.GetArea()
                    feature.SetField("AREA_M2", area)
                    
                    # Get max water depth within polygon
                    max_depth = np.nanmax(water_array[flood_mask])
                    feature.SetField("MAX_DEPTH", max_depth)
                    
                layer.SetFeature(feature)
                feature_count += 1
            else:
                # Delete non-flood features
                layer.DeleteFeature(feature.GetFID())
        
        # Clean up
        shp_ds = None
        temp_ds = None
        ds = None
        
        # Remove temporary raster
        if os.path.exists(temp_raster):
            os.remove(temp_raster)
        
        if feature_count > 0:
            logger.info(f"Created flood polygons for timestep {step_number} ({timestamp_str}): {polygon_path}")
            return {
                'file': polygon_path,
                'timestep': step_number,
                'time_str': timestamp_str,
                'water_level': progressive_water_level,
                'area': area if 'area' in locals() else 0
            }
        else:
            logger.warning(f"No valid flood polygons created for timestep {step_number}")
            return None
            
    except Exception as e:
        logger.error(f"Error creating flood polygons for timestep {step_number}: {e}")
        return None

def create_proper_streamlines(dem_path, flood_raster_paths, output_folder, sample_density=30):
    """
    Create proper streamlines that follow the water flow within flooded areas
    
    Args:
        dem_path: Path to DEM
        flood_raster_paths: List of flood raster paths
        output_folder: Output directory
        sample_density: Number of streamline starting points
        
    Returns:
        Path to streamlines shapefile
    """
    try:
        # Use the final flood state for streamline generation
        if not flood_raster_paths:
            logger.warning("No flood raster paths provided for streamlines")
            return None
            
        final_flood = flood_raster_paths[-1]
        
        # Open DEM and flood raster
        dem_ds = gdal.Open(dem_path)
        flood_ds = gdal.Open(final_flood)
        
        if dem_ds is None or flood_ds is None:
            logger.error("Could not open DEM or flood raster")
            return None
        
        dem_array = dem_ds.GetRasterBand(1).ReadAsArray()
        flood_array = flood_ds.GetRasterBand(1).ReadAsArray()
        geotransform = dem_ds.GetGeoTransform()
        projection = dem_ds.GetProjection()
        
        # Create flood mask - only areas with significant water depth
        flood_mask = (flood_array > 0.2) & (~np.isnan(flood_array))
        
        if not np.any(flood_mask):
            logger.warning("No significant flood areas found for streamlines")
            return None
        
        # Apply gaussian smoothing to DEM for better flow direction calculation
        from scipy.ndimage import gaussian_filter
        smoothed_dem = gaussian_filter(dem_array, sigma=2.0)
        
        # Calculate flow direction using gradient only within flooded areas
        dy, dx = np.gradient(smoothed_dem)
        
        # Mask gradients to flooded areas only
        dx_masked = np.where(flood_mask, dx, 0)
        dy_masked = np.where(flood_mask, dy, 0)
        
        # Create streamlines shapefile
        streamlines_path = os.path.join(output_folder, "flow_streamlines.shp")
        
        shp_driver = ogr.GetDriverByName("ESRI Shapefile")
        if os.path.exists(streamlines_path):
            shp_driver.DeleteDataSource(streamlines_path)
        
        shp_ds = shp_driver.CreateDataSource(streamlines_path)
        srs = osr.SpatialReference()
        srs.ImportFromWkt(projection)
        
        layer = shp_ds.CreateLayer("streamlines", srs, ogr.wkbLineString)
        layer.CreateField(ogr.FieldDefn("STREAM_ID", ogr.OFTInteger))
        layer.CreateField(ogr.FieldDefn("LENGTH_M", ogr.OFTReal))
        layer.CreateField(ogr.FieldDefn("AVG_SLOPE", ogr.OFTReal))
        layer.CreateField(ogr.FieldDefn("START_ELEV", ogr.OFTReal))
        layer.CreateField(ogr.FieldDefn("END_ELEV", ogr.OFTReal))
        
        # Create a water depth approximation to find main channels
        water_level = np.nanmax(flood_array) + 0.1  # Slightly above max flood level
        valid_mask = ~np.isnan(dem_array)
        water_depth = np.zeros_like(dem_array)
        water_depth[valid_mask] = np.maximum(0, water_level - dem_array[valid_mask])
        
        # Find the deepest channels in the flooded areas
        channel_depth_threshold = np.percentile(water_depth[flood_mask], 75)  # Top 25% deepest points
        channel_mask = flood_mask & (water_depth > channel_depth_threshold)
        
        # If no deep channels found, fall back to regular flood mask
        if not np.any(channel_mask):
            channel_mask = flood_mask
        
        # Find starting points in the channels - prioritize upstream areas
        channel_points = np.argwhere(channel_mask)
        
        if len(channel_points) == 0:
            logger.warning("No flood points found for streamline generation")
            return None
        
        # Get elevation values for channel points
        channel_elevations = dem_array[channel_points[:, 0], channel_points[:, 1]]
        
        # Find flow entry points at the edges of the channel
        from scipy.ndimage import binary_erosion
        
        # Create an eroded mask to identify edges
        eroded_mask = binary_erosion(channel_mask, iterations=1)
        edge_mask = channel_mask & (~eroded_mask)
        edge_points = np.argwhere(edge_mask)
        
        # Combine edge points with some higher elevation points
        starting_candidates = []
        
        # Add edge points
        if len(edge_points) > 0:
            # Take a subset of edge points
            edge_subset_size = min(sample_density // 2, len(edge_points))
            edge_indices = np.random.choice(len(edge_points), edge_subset_size, replace=False)
            for idx in edge_indices:
                starting_candidates.append(edge_points[idx])
        
        # Sort channel points by elevation (highest first) to identify upstream areas
        sorted_indices = np.argsort(channel_elevations)[::-1]
        
        # Add high elevation points
        high_point_count = sample_density - len(starting_candidates)
        if high_point_count > 0 and len(sorted_indices) > 0:
            high_indices = sorted_indices[:min(high_point_count * 2, len(sorted_indices))]
            selected_high_indices = np.random.choice(high_indices, 
                                                    min(high_point_count, len(high_indices)), 
                                                    replace=False)
            for idx in selected_high_indices:
                starting_candidates.append(channel_points[idx])
        
        # Use these as starting points
        start_points = np.array(starting_candidates)
        
        streamline_id = 1
        created_streamlines = 0
        
        # Create streamlines from starting points
        for start_row, start_col in start_points:
            # Trace streamline following steepest descent within flooded areas
            streamline = trace_streamline_in_flood_area(
                dem_array, dx_masked, dy_masked, flood_mask, 
                start_row, start_col, geotransform, max_steps=200
            )
            
            if len(streamline) >= 5:  # Only keep streamlines with sufficient points
                # Create line feature
                feature = ogr.Feature(layer.GetLayerDefn())
                feature.SetField("STREAM_ID", streamline_id)
                
                # Create geometry
                line = ogr.Geometry(ogr.wkbLineString)
                total_length = 0
                elevations = []
                
                for i, (x, y) in enumerate(streamline):
                    line.AddPoint(x, y)
                    
                    # Calculate length and elevation for statistics
                    if i > 0:
                        dx_seg = x - streamline[i-1][0]
                        dy_seg = y - streamline[i-1][1]
                        total_length += np.sqrt(dx_seg**2 + dy_seg**2)
                    
                    # Get elevation at this point
                    col = int((x - geotransform[0]) / geotransform[1])
                    row = int((y - geotransform[3]) / geotransform[5])
                    if 0 <= row < dem_array.shape[0] and 0 <= col < dem_array.shape[1]:
                        elevations.append(dem_array[row, col])
                
                feature.SetGeometry(line)
                feature.SetField("LENGTH_M", total_length)
                
                # Calculate slope and elevation statistics
                if len(elevations) >= 2:
                    start_elev = elevations[0]
                    end_elev = elevations[-1]
                    elevation_drop = start_elev - end_elev
                    avg_slope = elevation_drop / total_length if total_length > 0 else 0
                    
                    feature.SetField("AVG_SLOPE", avg_slope)
                    feature.SetField("START_ELEV", start_elev)
                    feature.SetField("END_ELEV", end_elev)
                
                layer.CreateFeature(feature)
                streamline_id += 1
                created_streamlines += 1
        
        shp_ds = None
        dem_ds = None
        flood_ds = None
        
        if created_streamlines > 0:
            logger.info(f"Created {created_streamlines} streamlines within flood areas: {streamlines_path}")
            return streamlines_path
        else:
            logger.warning("No valid streamlines created")
            return None
        
    except Exception as e:
        logger.error(f"Error creating streamlines: {e}")
        import traceback
        traceback.print_exc()
        return None

def trace_streamline_in_flood_area(dem_array, dx, dy, flood_mask, start_row, start_col, geotransform, max_steps=200):
    """
    Trace a streamline from a starting point following the steepest descent within flooded areas
    Enhanced to prioritize staying in deep water channels
    """
    streamline = []
    current_row, current_col = float(start_row), float(start_col)
    
    # Convert to world coordinates
    x = geotransform[0] + current_col * geotransform[1]
    y = geotransform[3] + current_row * geotransform[5]
    streamline.append((x, y))
    
    step_size = 0.5  # Smaller step size for better accuracy
    min_gradient = 0.00005  # Minimum gradient to continue (reduced for better sensitivity)
    
    # Create a water depth approximation from DEM elevation and flood mask
    # First we need to find the lowest elevation within flooded area to estimate water level
    valid_mask = flood_mask & ~np.isnan(dem_array)
    if np.any(valid_mask):
        min_elev = np.min(dem_array[valid_mask])
        max_elev = np.max(dem_array[valid_mask])
        water_level = max_elev + 0.2  # Assume water level is slightly above max elevation
        
        # Calculate approximate water depth
        water_depth = np.zeros_like(dem_array)
        water_depth[valid_mask] = np.maximum(0, water_level - dem_array[valid_mask])
    else:
        # Fallback if no valid flood mask points
        water_depth = np.zeros_like(dem_array)
    
    for step in range(max_steps):
        # Check bounds
        row_int = int(round(current_row))
        col_int = int(round(current_col))
        
        if (row_int < 1 or row_int >= dem_array.shape[0] - 1 or
            col_int < 1 or col_int >= dem_array.shape[1] - 1):
            break
        
        # Prioritize tracing through flooded areas
        # Check if still in flooded area or near it
        in_flood_area = False
        
        # Use a larger search window to find nearby flood areas
        for dr in range(-3, 4):
            for dc in range(-3, 4):
                check_row = row_int + dr
                check_col = col_int + dc
                if (0 <= check_row < flood_mask.shape[0] and 
                    0 <= check_col < flood_mask.shape[1] and
                    flood_mask[check_row, check_col]):
                    in_flood_area = True
                    break
            if in_flood_area:
                break
        
        if not in_flood_area:
            break
        
        # Get flow direction from gradient (steepest descent)
        flow_x = -dx[row_int, col_int]  # Negative for downhill
        flow_y = -dy[row_int, col_int]
        
        # Enhance flow direction to follow deeper water
        # Sample water depth in a small neighborhood and adjust flow to favor deeper areas
        water_bias = 0.4  # Weight for water depth influence
        depth_gradient_x, depth_gradient_y = 0, 0
        
        for dr in range(-1, 2):
            for dc in range(-1, 2):
                r, c = row_int + dr, col_int + dc
                if (0 <= r < water_depth.shape[0] and 0 <= c < water_depth.shape[1] and
                    flood_mask[r, c]):
                    # Add influence from deeper water
                    depth_gradient_x += dc * water_depth[r, c]
                    depth_gradient_y += dr * water_depth[r, c]
        
        # Combine terrain gradient with water depth gradient
        flow_x = (1 - water_bias) * flow_x + water_bias * depth_gradient_x
        flow_y = (1 - water_bias) * flow_y + water_bias * depth_gradient_y
        
        # Check if gradient is significant enough
        gradient_magnitude = np.sqrt(flow_x**2 + flow_y**2)
        if gradient_magnitude < min_gradient:
            break
        
        # Normalize flow direction
        flow_x /= gradient_magnitude
        flow_y /= gradient_magnitude
        
        # Move to next point
        new_col = current_col + flow_x * step_size
        new_row = current_row + flow_y * step_size
        
        # Check for circular flow (if we're getting too close to previous points)
        if len(streamline) > 10:
            new_x = geotransform[0] + new_col * geotransform[1]
            new_y = geotransform[3] + new_row * geotransform[5]
            
            # Check distance to recent points
            too_close = False
            for i in range(max(0, len(streamline) - 10), len(streamline)):
                old_x, old_y = streamline[i]
                distance = np.sqrt((new_x - old_x)**2 + (new_y - old_y)**2)
                if distance < abs(geotransform[1]) * 1.5:  # Less than 1.5 pixel sizes
                    too_close = True
                    break
            
            if too_close:
                break
        
        current_row, current_col = new_row, new_col
        
        # Convert to world coordinates
        x = geotransform[0] + current_col * geotransform[1]
        y = geotransform[3] + current_row * geotransform[5]
        streamline.append((x, y))
        
        # Continue tracing for a longer distance to get more complete streamlines
        if len(streamline) > 10 and step > 50:
            start_x, start_y = streamline[0]
            current_distance = np.sqrt((x - start_x)**2 + (y - start_y)**2)
            # Stop if we've moved a significant distance
            if current_distance > 250:  # Increased to 250 meters for longer streamlines
                break
    
    return streamline

def process_flood_simulation_outputs(output_folder, dem_path, raster_files, velocity_files, timestep_duration=60):
    """
    Process the raw simulation outputs to create user-friendly polygon layers and streamlines
    
    Args:
        output_folder: Output directory
        dem_path: Path to DEM
        raster_files: List of water depth raster files
        velocity_files: List of velocity raster files
        timestep_duration: Duration of each timestep in minutes
        
    Returns:
        dict: Paths to created polygon and streamline files
    """
    results = {
        'polygon_files': [],
        'streamlines_file': None,
        'summary': {},
        'timestep_data': []
    }
    
    try:
        # Print debug information
        print(f"🔍 Processing {len(raster_files)} timestep outputs")
        if len(raster_files) == 0:
            print("⚠️ No timestep files were generated! Check the model configuration.")
            return results
        
        # Ensure we have at least 5 timesteps by selecting a subset if we have more
        if len(raster_files) > 5:
            # Select raster files at regular intervals including first and last
            indices = np.linspace(0, len(raster_files) - 1, 5, dtype=int)
            selected_rasters = [raster_files[i] for i in indices]
            print(f"📊 Selected {len(selected_rasters)} representative timesteps from {len(raster_files)} total")
        else:
            selected_rasters = raster_files
            print(f"📊 Using all {len(selected_rasters)} timesteps")
        
        # Convert raster files to polygon layers with proper timestamps and VARYING water levels
        for i, raster_file in enumerate(selected_rasters):
            step_number = i + 1
            
            # Get the true step number if we're using a subset
            if len(raster_files) > 5:
                step_number = indices[i] + 1
            
            print(f"⏱️ Creating polygon for timestep {step_number}")
            
            # Calculate progressive water level (increasing with each timestep)
            # This is necessary to create variation between timesteps
            polygon_data = convert_raster_to_flood_polygons(
                raster_file, output_folder, step_number, 
                water_threshold=0.05,  # Lower threshold to capture more area
                timestep_duration=timestep_duration
            )
            
            if polygon_data:
                results['polygon_files'].append(polygon_data['file'])
                results['timestep_data'].append(polygon_data)
                print(f"✅ Created polygon: {os.path.basename(polygon_data['file'])}")
            else:
                print(f"⚠️ No polygon created for timestep {step_number}")
        
        # Create streamlines from the simulation that stay within flooded areas
        if selected_rasters:
            print(f"🌊 Creating streamlines using {len(selected_rasters)} flood rasters")
            # Use a higher sample density for more streamlines
            streamlines_file = create_proper_streamlines(
                dem_path, selected_rasters, output_folder, sample_density=60
            )
            results['streamlines_file'] = streamlines_file
            if streamlines_file:
                print(f"✅ Created streamlines: {os.path.basename(streamlines_file)}")
            else:
                print(f"⚠️ Failed to create streamlines")
        
        # Create summary
        results['summary'] = {
            'total_timesteps': len(raster_files),
            'polygon_layers_created': len(results['polygon_files']),
            'streamlines_created': results['streamlines_file'] is not None,
            'timestep_duration_minutes': timestep_duration
        }
        
        print(f"📝 Processing complete: Created {len(results['polygon_files'])} polygon layers")
        
        logger.info(f"Processing complete: {results['summary']}")
        
    except Exception as e:
        logger.error(f"Error processing simulation outputs: {e}")
        import traceback
        traceback.print_exc()
    
    return results
