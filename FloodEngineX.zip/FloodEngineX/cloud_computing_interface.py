#!/usr/bin/env python3
"""
FloodEngine v4.0 - Cloud Computing Interface Module
==================================================

Professional cloud computing integration for FloodEngine providing:
- AWS cloud processing capabilities (EC2, S3, Lambda)
- Microsoft Azure cloud integration (Compute, Storage, Functions)
- Google Cloud Platform support (Compute Engine, Cloud Storage)
- Cloud job scheduling and monitoring
- Distributed processing coordination
- Cloud-based result storage and retrieval
- Cost optimization and resource management

Author: FloodEngine Development Team
Date: June 7, 2025
Version: 4.0
"""

import os
import sys
import json
import time
import logging
import asyncio
import tempfile
import zipfile
import shutil
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional, Any, Union, Callable
from dataclasses import dataclass, field
from pathlib import Path
from enum import Enum
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

# Cloud provider imports with graceful fallback
try:
    import boto3
    from botocore.exceptions import ClientError, NoCredentialsError
    AWS_AVAILABLE = True
except ImportError:
    AWS_AVAILABLE = False
    boto3 = None
    ClientError = Exception
    NoCredentialsError = Exception

try:
    from azure.storage.blob import BlobServiceClient
    from azure.compute import ComputeManagementClient
    from azure.identity import DefaultAzureCredential
    AZURE_AVAILABLE = True
except ImportError:
    AZURE_AVAILABLE = False
    BlobServiceClient = None
    ComputeManagementClient = None
    DefaultAzureCredential = None

try:
    from google.cloud import storage as gcs
    from google.cloud import compute_v1
    from google.oauth2 import service_account
    GCP_AVAILABLE = True
except ImportError:
    GCP_AVAILABLE = False
    gcs = None
    compute_v1 = None
    service_account = None

# Configuration and data structures

class CloudProvider(Enum):
    """Supported cloud providers."""
    AWS = "aws"
    AZURE = "azure"
    GCP = "gcp"
    LOCAL = "local"

class JobStatus(Enum):
    """Cloud job status."""
    PENDING = "pending"
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

@dataclass
class CloudResourceConfig:
    """Configuration for cloud computing resources."""
    provider: CloudProvider
    instance_type: str
    region: str
    storage_bucket: str
    max_instances: int = 10
    auto_scaling: bool = True
    spot_instances: bool = False
    custom_image: Optional[str] = None
    security_groups: List[str] = field(default_factory=list)
    subnet_id: Optional[str] = None
    key_pair: Optional[str] = None

@dataclass
class CloudJob:
    """Cloud computing job specification."""
    job_id: str
    job_name: str
    job_type: str
    input_files: List[str]
    parameters: Dict[str, Any]
    resource_config: CloudResourceConfig
    priority: int = 5
    max_runtime_hours: int = 24
    retry_count: int = 3
    notification_emails: List[str] = field(default_factory=list)
    
    # Runtime fields
    status: JobStatus = JobStatus.PENDING
    created_time: Optional[datetime] = None
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    instance_id: Optional[str] = None
    error_message: Optional[str] = None
    output_files: List[str] = field(default_factory=list)
    logs: List[str] = field(default_factory=list)
    cost_estimate: float = 0.0

@dataclass
class CloudJobResult:
    """Result from cloud job execution."""
    job_id: str
    success: bool
    output_files: List[str]
    logs: List[str]
    execution_time: float
    cost: float
    error_message: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

class CloudStorageManager:
    """Manages cloud storage operations across providers."""
    
    def __init__(self, provider: CloudProvider, config: Dict[str, Any]):
        """Initialize cloud storage manager.
        
        Args:
            provider: Cloud provider
            config: Provider-specific configuration
        """
        self.provider = provider
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Initialize provider-specific clients
        self._init_storage_client()
    
    def _init_storage_client(self):
        """Initialize storage client for the specified provider."""
        try:
            if self.provider == CloudProvider.AWS and AWS_AVAILABLE:
                self.s3_client = boto3.client(
                    's3',
                    aws_access_key_id=self.config.get('access_key_id'),
                    aws_secret_access_key=self.config.get('secret_access_key'),
                    region_name=self.config.get('region', 'us-east-1')
                )
                
            elif self.provider == CloudProvider.AZURE and AZURE_AVAILABLE:
                credential = DefaultAzureCredential()
                self.blob_client = BlobServiceClient(
                    account_url=f"https://{self.config['account_name']}.blob.core.windows.net",
                    credential=credential
                )
                
            elif self.provider == CloudProvider.GCP and GCP_AVAILABLE:
                if 'service_account_path' in self.config:
                    credentials = service_account.Credentials.from_service_account_file(
                        self.config['service_account_path']
                    )
                    self.gcs_client = gcs.Client(credentials=credentials)
                else:
                    self.gcs_client = gcs.Client()
                    
            else:
                self.logger.warning(f"Cloud provider {self.provider} not available or not configured")
                
        except Exception as e:
            self.logger.error(f"Failed to initialize {self.provider} storage client: {e}")
            raise
    
    async def upload_file(self, local_path: str, remote_path: str, 
                         bucket: str) -> bool:
        """Upload file to cloud storage.
        
        Args:
            local_path: Local file path
            remote_path: Remote file path
            bucket: Storage bucket name
            
        Returns:
            Success status
        """
        try:
            if self.provider == CloudProvider.AWS:
                self.s3_client.upload_file(local_path, bucket, remote_path)
                
            elif self.provider == CloudProvider.AZURE:
                blob_client = self.blob_client.get_blob_client(
                    container=bucket, blob=remote_path
                )
                with open(local_path, 'rb') as data:
                    blob_client.upload_blob(data, overwrite=True)
                    
            elif self.provider == CloudProvider.GCP:
                bucket_obj = self.gcs_client.bucket(bucket)
                blob = bucket_obj.blob(remote_path)
                blob.upload_from_filename(local_path)
                
            self.logger.info(f"Successfully uploaded {local_path} to {self.provider}/{bucket}/{remote_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to upload {local_path}: {e}")
            return False
    
    async def download_file(self, remote_path: str, local_path: str, 
                           bucket: str) -> bool:
        """Download file from cloud storage.
        
        Args:
            remote_path: Remote file path
            local_path: Local file path
            bucket: Storage bucket name
            
        Returns:
            Success status
        """
        try:
            # Create local directory if needed
            os.makedirs(os.path.dirname(local_path), exist_ok=True)
            
            if self.provider == CloudProvider.AWS:
                self.s3_client.download_file(bucket, remote_path, local_path)
                
            elif self.provider == CloudProvider.AZURE:
                blob_client = self.blob_client.get_blob_client(
                    container=bucket, blob=remote_path
                )
                with open(local_path, 'wb') as download_file:
                    download_file.write(blob_client.download_blob().readall())
                    
            elif self.provider == CloudProvider.GCP:
                bucket_obj = self.gcs_client.bucket(bucket)
                blob = bucket_obj.blob(remote_path)
                blob.download_to_filename(local_path)
                
            self.logger.info(f"Successfully downloaded {self.provider}/{bucket}/{remote_path} to {local_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to download {remote_path}: {e}")
            return False
    
    async def list_files(self, bucket: str, prefix: str = "") -> List[str]:
        """List files in cloud storage bucket.
        
        Args:
            bucket: Storage bucket name
            prefix: File prefix filter
            
        Returns:
            List of file paths
        """
        try:
            files = []
            
            if self.provider == CloudProvider.AWS:
                response = self.s3_client.list_objects_v2(
                    Bucket=bucket, Prefix=prefix
                )
                files = [obj['Key'] for obj in response.get('Contents', [])]
                
            elif self.provider == CloudProvider.AZURE:
                container_client = self.blob_client.get_container_client(bucket)
                blobs = container_client.list_blobs(name_starts_with=prefix)
                files = [blob.name for blob in blobs]
                
            elif self.provider == CloudProvider.GCP:
                bucket_obj = self.gcs_client.bucket(bucket)
                blobs = bucket_obj.list_blobs(prefix=prefix)
                files = [blob.name for blob in blobs]
                
            return files
            
        except Exception as e:
            self.logger.error(f"Failed to list files in {bucket}: {e}")
            return []
    
    async def delete_file(self, remote_path: str, bucket: str) -> bool:
        """Delete file from cloud storage.
        
        Args:
            remote_path: Remote file path
            bucket: Storage bucket name
            
        Returns:
            Success status
        """
        try:
            if self.provider == CloudProvider.AWS:
                self.s3_client.delete_object(Bucket=bucket, Key=remote_path)
                
            elif self.provider == CloudProvider.AZURE:
                blob_client = self.blob_client.get_blob_client(
                    container=bucket, blob=remote_path
                )
                blob_client.delete_blob()
                
            elif self.provider == CloudProvider.GCP:
                bucket_obj = self.gcs_client.bucket(bucket)
                blob = bucket_obj.blob(remote_path)
                blob.delete()
                
            self.logger.info(f"Successfully deleted {self.provider}/{bucket}/{remote_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to delete {remote_path}: {e}")
            return False

class CloudComputeManager:
    """Manages cloud compute instances and job execution."""
    
    def __init__(self, provider: CloudProvider, config: Dict[str, Any]):
        """Initialize cloud compute manager.
        
        Args:
            provider: Cloud provider
            config: Provider-specific configuration
        """
        self.provider = provider
        self.config = config
        self.logger = logging.getLogger(__name__)
        self.active_instances = {}
        self.job_queue = []
        self.running_jobs = {}
        
        # Initialize provider-specific clients
        self._init_compute_client()
    
    def _init_compute_client(self):
        """Initialize compute client for the specified provider."""
        try:
            if self.provider == CloudProvider.AWS and AWS_AVAILABLE:
                self.ec2_client = boto3.client(
                    'ec2',
                    aws_access_key_id=self.config.get('access_key_id'),
                    aws_secret_access_key=self.config.get('secret_access_key'),
                    region_name=self.config.get('region', 'us-east-1')
                )
                
            elif self.provider == CloudProvider.AZURE and AZURE_AVAILABLE:
                credential = DefaultAzureCredential()
                self.compute_client = ComputeManagementClient(
                    credential, self.config['subscription_id']
                )
                
            elif self.provider == CloudProvider.GCP and GCP_AVAILABLE:
                if 'service_account_path' in self.config:
                    credentials = service_account.Credentials.from_service_account_file(
                        self.config['service_account_path']
                    )
                else:
                    credentials = None
                self.compute_client = compute_v1.InstancesClient(credentials=credentials)
                
        except Exception as e:
            self.logger.error(f"Failed to initialize {self.provider} compute client: {e}")
            raise
    
    async def launch_instance(self, resource_config: CloudResourceConfig) -> Optional[str]:
        """Launch a new compute instance.
        
        Args:
            resource_config: Instance configuration
            
        Returns:
            Instance ID if successful
        """
        try:
            if self.provider == CloudProvider.AWS:
                return await self._launch_aws_instance(resource_config)
            elif self.provider == CloudProvider.AZURE:
                return await self._launch_azure_instance(resource_config)
            elif self.provider == CloudProvider.GCP:
                return await self._launch_gcp_instance(resource_config)
                
        except Exception as e:
            self.logger.error(f"Failed to launch instance: {e}")
            return None
    
    async def _launch_aws_instance(self, config: CloudResourceConfig) -> Optional[str]:
        """Launch AWS EC2 instance."""
        try:
            # Prepare launch parameters
            launch_params = {
                'ImageId': config.custom_image or 'ami-0abcdef1234567890',  # Default FloodEngine AMI
                'InstanceType': config.instance_type,
                'KeyName': config.key_pair,
                'SecurityGroupIds': config.security_groups,
                'SubnetId': config.subnet_id,
                'MinCount': 1,
                'MaxCount': 1,
                'UserData': self._generate_user_data_script(),
                'TagSpecifications': [{
                    'ResourceType': 'instance',
                    'Tags': [
                        {'Key': 'Name', 'Value': 'FloodEngine-Worker'},
                        {'Key': 'Application', 'Value': 'FloodEngine'},
                        {'Key': 'CreatedBy', 'Value': 'FloodEngine-Cloud-Interface'}
                    ]
                }]
            }
            
            # Use spot instances if requested
            if config.spot_instances:
                launch_params['InstanceMarketOptions'] = {
                    'MarketType': 'spot',
                    'SpotOptions': {
                        'SpotInstanceType': 'one-time'
                    }
                }
            
            response = self.ec2_client.run_instances(**launch_params)
            instance_id = response['Instances'][0]['InstanceId']
            
            self.logger.info(f"Launched AWS instance {instance_id}")
            return instance_id
            
        except Exception as e:
            self.logger.error(f"Failed to launch AWS instance: {e}")
            return None
    
    async def _launch_azure_instance(self, config: CloudResourceConfig) -> Optional[str]:
        """Launch Azure VM instance."""
        # Azure implementation would go here
        self.logger.warning("Azure instance launch not yet implemented")
        return None
    
    async def _launch_gcp_instance(self, config: CloudResourceConfig) -> Optional[str]:
        """Launch GCP Compute Engine instance."""
        # GCP implementation would go here
        self.logger.warning("GCP instance launch not yet implemented")
        return None
    
    def _generate_user_data_script(self) -> str:
        """Generate user data script for instance initialization."""
        return """#!/bin/bash
# FloodEngine Cloud Worker Initialization Script

# Update system
sudo apt-get update -y
sudo apt-get install -y python3 python3-pip awscli

# Install FloodEngine dependencies
pip3 install numpy scipy matplotlib qgis

# Download FloodEngine worker script
aws s3 cp s3://floodengine-workers/worker.py /home/ubuntu/worker.py

# Set up worker environment
cd /home/ubuntu
python3 worker.py --start-worker

# Signal completion
aws s3 cp /dev/null s3://floodengine-workers/instances/$(curl -s http://169.254.169.254/latest/meta-data/instance-id)/ready
"""
    
    async def terminate_instance(self, instance_id: str) -> bool:
        """Terminate a compute instance.
        
        Args:
            instance_id: Instance identifier
            
        Returns:
            Success status
        """
        try:
            if self.provider == CloudProvider.AWS:
                self.ec2_client.terminate_instances(InstanceIds=[instance_id])
                self.logger.info(f"Terminated AWS instance {instance_id}")
                return True
                
            elif self.provider == CloudProvider.AZURE:
                # Azure termination implementation
                pass
                
            elif self.provider == CloudProvider.GCP:
                # GCP termination implementation
                pass
                
        except Exception as e:
            self.logger.error(f"Failed to terminate instance {instance_id}: {e}")
            return False
    
    async def get_instance_status(self, instance_id: str) -> Optional[str]:
        """Get instance status.
        
        Args:
            instance_id: Instance identifier
            
        Returns:
            Instance status string
        """
        try:
            if self.provider == CloudProvider.AWS:
                response = self.ec2_client.describe_instances(InstanceIds=[instance_id])
                if response['Reservations']:
                    instance = response['Reservations'][0]['Instances'][0]
                    return instance['State']['Name']
                    
        except Exception as e:
            self.logger.error(f"Failed to get status for instance {instance_id}: {e}")
            
        return None

class FloodEngineCloudManager:
    """Main cloud computing interface for FloodEngine."""
    
    def __init__(self, provider: CloudProvider, config: Dict[str, Any]):
        """Initialize cloud manager.
        
        Args:
            provider: Cloud provider
            config: Provider configuration
        """
        self.provider = provider
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Initialize cloud services
        self.storage_manager = CloudStorageManager(provider, config.get('storage', {}))
        self.compute_manager = CloudComputeManager(provider, config.get('compute', {}))
        
        # Job management
        self.jobs = {}
        self.job_callbacks = {}
        self.monitoring_thread = None
        self.monitoring_active = False
        
        # Cost tracking
        self.cost_tracker = {
            'compute_hours': 0.0,
            'storage_gb_hours': 0.0,
            'data_transfer_gb': 0.0,
            'total_cost': 0.0
        }
    
    async def submit_flood_modeling_job(self, job_name: str, 
                                      dem_file: str,
                                      parameters: Dict[str, Any],
                                      resource_config: CloudResourceConfig,
                                      output_directory: str = None) -> str:
        """Submit a flood modeling job to the cloud.
        
        Args:
            job_name: Descriptive job name
            dem_file: Path to DEM file
            parameters: Modeling parameters
            resource_config: Cloud resource configuration
            output_directory: Local output directory
            
        Returns:
            Job ID
        """
        job_id = f"flood_{int(time.time())}_{hash(job_name) % 10000:04d}"
        
        # Create job specification
        job = CloudJob(
            job_id=job_id,
            job_name=job_name,
            job_type="flood_modeling",
            input_files=[dem_file],
            parameters=parameters,
            resource_config=resource_config,
            created_time=datetime.now()
        )
        
        # Store job
        self.jobs[job_id] = job
        
        try:
            # Upload input files
            await self._upload_job_inputs(job)
            
            # Launch compute instance
            instance_id = await self.compute_manager.launch_instance(resource_config)
            if not instance_id:
                raise Exception("Failed to launch compute instance")
            
            job.instance_id = instance_id
            job.status = JobStatus.QUEUED
            
            # Start job monitoring
            if not self.monitoring_active:
                self._start_job_monitoring()
            
            self.logger.info(f"Submitted flood modeling job {job_id} on instance {instance_id}")
            return job_id
            
        except Exception as e:
            job.status = JobStatus.FAILED
            job.error_message = str(e)
            self.logger.error(f"Failed to submit job {job_id}: {e}")
            raise
    
    async def _upload_job_inputs(self, job: CloudJob):
        """Upload job input files to cloud storage."""
        bucket = job.resource_config.storage_bucket
        
        for local_file in job.input_files:
            if os.path.exists(local_file):
                remote_path = f"jobs/{job.job_id}/inputs/{os.path.basename(local_file)}"
                success = await self.storage_manager.upload_file(
                    local_file, remote_path, bucket
                )
                if not success:
                    raise Exception(f"Failed to upload {local_file}")
        
        # Upload job configuration
        job_config = {
            'job_id': job.job_id,
            'job_type': job.job_type,
            'parameters': job.parameters,
            'input_files': [os.path.basename(f) for f in job.input_files]
        }
        
        config_file = tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False)
        json.dump(job_config, config_file, indent=2)
        config_file.close()
        
        config_remote_path = f"jobs/{job.job_id}/config.json"
        success = await self.storage_manager.upload_file(
            config_file.name, config_remote_path, bucket
        )
        os.unlink(config_file.name)
        
        if not success:
            raise Exception("Failed to upload job configuration")
    
    def _start_job_monitoring(self):
        """Start background thread for job monitoring."""
        if not self.monitoring_active:
            self.monitoring_active = True
            self.monitoring_thread = threading.Thread(target=self._monitor_jobs_loop, daemon=True)
            self.monitoring_thread.start()
    
    def _monitor_jobs_loop(self):
        """Background loop for monitoring job status."""
        while self.monitoring_active:
            try:
                # Check status of all running jobs
                for job_id, job in self.jobs.items():
                    if job.status in [JobStatus.QUEUED, JobStatus.RUNNING]:
                        asyncio.run(self._check_job_status(job))
                
                time.sleep(30)  # Check every 30 seconds
                
            except Exception as e:
                self.logger.error(f"Error in job monitoring loop: {e}")
                time.sleep(60)  # Wait longer on error
    
    async def _check_job_status(self, job: CloudJob):
        """Check and update job status."""
        if not job.instance_id:
            return
        
        # Check instance status
        instance_status = await self.compute_manager.get_instance_status(job.instance_id)
        
        if instance_status == 'running' and job.status == JobStatus.QUEUED:
            job.status = JobStatus.RUNNING
            job.start_time = datetime.now()
            
        elif instance_status in ['stopped', 'terminated']:
            # Check if job completed successfully
            success = await self._check_job_completion(job)
            if success:
                job.status = JobStatus.COMPLETED
                job.end_time = datetime.now()
                await self._download_job_outputs(job)
            else:
                job.status = JobStatus.FAILED
                job.end_time = datetime.now()
            
            # Terminate instance if needed
            if instance_status != 'terminated':
                await self.compute_manager.terminate_instance(job.instance_id)
            
            # Trigger callback if registered
            if job.job_id in self.job_callbacks:
                callback = self.job_callbacks[job.job_id]
                callback(job)
    
    async def _check_job_completion(self, job: CloudJob) -> bool:
        """Check if job completed successfully by looking for output files."""
        bucket = job.resource_config.storage_bucket
        output_prefix = f"jobs/{job.job_id}/outputs/"
        
        output_files = await self.storage_manager.list_files(bucket, output_prefix)
        return len(output_files) > 0
    
    async def _download_job_outputs(self, job: CloudJob):
        """Download job output files from cloud storage."""
        bucket = job.resource_config.storage_bucket
        output_prefix = f"jobs/{job.job_id}/outputs/"
        
        output_files = await self.storage_manager.list_files(bucket, output_prefix)
        
        # Create local output directory
        local_output_dir = f"cloud_outputs/{job.job_id}"
        os.makedirs(local_output_dir, exist_ok=True)
        
        for remote_file in output_files:
            filename = os.path.basename(remote_file)
            local_path = os.path.join(local_output_dir, filename)
            
            success = await self.storage_manager.download_file(
                remote_file, local_path, bucket
            )
            
            if success:
                job.output_files.append(local_path)
    
    def get_job_status(self, job_id: str) -> Optional[CloudJob]:
        """Get current job status.
        
        Args:
            job_id: Job identifier
            
        Returns:
            Job object with current status
        """
        return self.jobs.get(job_id)
    
    def register_job_callback(self, job_id: str, callback: Callable[[CloudJob], None]):
        """Register callback for job completion.
        
        Args:
            job_id: Job identifier
            callback: Function to call when job completes
        """
        self.job_callbacks[job_id] = callback
    
    async def cancel_job(self, job_id: str) -> bool:
        """Cancel a running job.
        
        Args:
            job_id: Job identifier
            
        Returns:
            Success status
        """
        job = self.jobs.get(job_id)
        if not job:
            return False
        
        if job.status in [JobStatus.QUEUED, JobStatus.RUNNING]:
            job.status = JobStatus.CANCELLED
            
            if job.instance_id:
                await self.compute_manager.terminate_instance(job.instance_id)
            
            self.logger.info(f"Cancelled job {job_id}")
            return True
        
        return False
    
    def get_cost_estimate(self, resource_config: CloudResourceConfig, 
                         runtime_hours: float) -> float:
        """Estimate cost for cloud job execution.
        
        Args:
            resource_config: Resource configuration
            runtime_hours: Expected runtime in hours
            
        Returns:
            Estimated cost in USD
        """
        # Simplified cost estimation (provider-specific rates would be more accurate)
        base_rates = {
            CloudProvider.AWS: {'compute': 0.10, 'storage': 0.023, 'transfer': 0.09},
            CloudProvider.AZURE: {'compute': 0.096, 'storage': 0.0184, 'transfer': 0.087},
            CloudProvider.GCP: {'compute': 0.095, 'storage': 0.020, 'transfer': 0.08}
        }
        
        rates = base_rates.get(self.provider, base_rates[CloudProvider.AWS])
        
        # Estimate compute cost
        compute_cost = runtime_hours * rates['compute']
        
        # Estimate storage cost (assume 10GB for 24 hours)
        storage_cost = 10 * 24 * rates['storage'] / (30 * 24)  # Monthly rate to daily
        
        # Estimate transfer cost (assume 5GB up/down)
        transfer_cost = 10 * rates['transfer']
        
        total_cost = compute_cost + storage_cost + transfer_cost
        
        return total_cost
    
    def generate_cloud_usage_report(self) -> Dict[str, Any]:
        """Generate comprehensive cloud usage report.
        
        Returns:
            Dictionary with usage statistics and costs
        """
        total_jobs = len(self.jobs)
        completed_jobs = sum(1 for job in self.jobs.values() if job.status == JobStatus.COMPLETED)
        failed_jobs = sum(1 for job in self.jobs.values() if job.status == JobStatus.FAILED)
        running_jobs = sum(1 for job in self.jobs.values() if job.status == JobStatus.RUNNING)
        
        total_runtime = sum(
            (job.end_time - job.start_time).total_seconds() / 3600
            for job in self.jobs.values()
            if job.start_time and job.end_time
        )
        
        return {
            'provider': self.provider.value,
            'summary': {
                'total_jobs': total_jobs,
                'completed_jobs': completed_jobs,
                'failed_jobs': failed_jobs,
                'running_jobs': running_jobs,
                'success_rate': completed_jobs / total_jobs if total_jobs > 0 else 0,
                'total_runtime_hours': total_runtime
            },
            'costs': self.cost_tracker,
            'jobs': [
                {
                    'job_id': job.job_id,
                    'job_name': job.job_name,
                    'status': job.status.value,
                    'runtime_hours': (
                        (job.end_time - job.start_time).total_seconds() / 3600
                        if job.start_time and job.end_time else 0
                    ),
                    'cost_estimate': job.cost_estimate
                }
                for job in self.jobs.values()
            ]
        }
    
    def stop_monitoring(self):
        """Stop job monitoring thread."""
        self.monitoring_active = False
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=5)

# Factory functions for easy integration

def create_aws_cloud_manager(access_key_id: str, secret_access_key: str, 
                           region: str = 'us-east-1') -> FloodEngineCloudManager:
    """Create AWS cloud manager with credentials.
    
    Args:
        access_key_id: AWS access key
        secret_access_key: AWS secret key
        region: AWS region
        
    Returns:
        Configured cloud manager
    """
    config = {
        'storage': {
            'access_key_id': access_key_id,
            'secret_access_key': secret_access_key,
            'region': region
        },
        'compute': {
            'access_key_id': access_key_id,
            'secret_access_key': secret_access_key,
            'region': region
        }
    }
    
    return FloodEngineCloudManager(CloudProvider.AWS, config)

def create_azure_cloud_manager(subscription_id: str, account_name: str) -> FloodEngineCloudManager:
    """Create Azure cloud manager.
    
    Args:
        subscription_id: Azure subscription ID
        account_name: Storage account name
        
    Returns:
        Configured cloud manager
    """
    config = {
        'storage': {
            'account_name': account_name
        },
        'compute': {
            'subscription_id': subscription_id
        }
    }
    
    return FloodEngineCloudManager(CloudProvider.AZURE, config)

def create_gcp_cloud_manager(project_id: str, service_account_path: str = None) -> FloodEngineCloudManager:
    """Create GCP cloud manager.
    
    Args:
        project_id: GCP project ID
        service_account_path: Path to service account JSON file
        
    Returns:
        Configured cloud manager
    """
    config = {
        'storage': {
            'project_id': project_id,
            'service_account_path': service_account_path
        },
        'compute': {
            'project_id': project_id,
            'service_account_path': service_account_path
        }
    }
    
    return FloodEngineCloudManager(CloudProvider.GCP, config)

# Example usage and testing
if __name__ == "__main__":
    import asyncio
    
    async def test_cloud_interface():
        """Test cloud computing interface."""
        print("FloodEngine v4.0 - Cloud Computing Interface Test")
        print("=" * 55)
        
        # Test with local mode for development
        config = {
            'storage': {},
            'compute': {}
        }
        
        cloud_manager = FloodEngineCloudManager(CloudProvider.LOCAL, config)
        
        # Test resource configuration
        resource_config = CloudResourceConfig(
            provider=CloudProvider.AWS,
            instance_type="c5.large",
            region="us-east-1",
            storage_bucket="floodengine-test",
            max_instances=5
        )
        
        # Test cost estimation
        estimated_cost = cloud_manager.get_cost_estimate(resource_config, 2.0)
        print(f"Estimated cost for 2-hour job: ${estimated_cost:.2f}")
        
        # Generate usage report
        usage_report = cloud_manager.generate_cloud_usage_report()
        print("\nCloud Usage Report:")
        print(json.dumps(usage_report, indent=2))
        
        print("\nCloud interface test completed!")
    
    # Run test
    asyncio.run(test_cloud_interface())
