#!/usr/bin/env python3
"""Test import of model_hydraulic module."""

try:
    from model_hydraulic import calculate_flood_area
    print("✅ calculate_flood_area imported successfully!")
    
    from model_hydraulic import simulate_saint_venant_2d
    print("✅ simulate_saint_venant_2d imported successfully!")
    
    from model_hydraulic import create_hillshade_gdal
    print("✅ create_hillshade_gdal imported successfully!")
    
    print("🎉 ALL IMPORTS SUCCESSFUL - Plugin is ready!")
    
except ImportError as e:
    print(f"❌ Import error: {e}")
    print("   Check that all dependencies are installed")
    
except Exception as e:
    print(f"❌ Unexpected error: {e}")
    import traceback
    traceback.print_exc()
