"""
2D Saint-Venant Equations Module for FloodEngine
------------------------------------------------
This module implements the full 2D Saint-Venant equations for advanced hydraulic modeling,
providing more accurate flow simulation, especially in complex terrain.
"""

import os
import time
import numpy as np
from osgeo import gdal
import logging
from scipy.ndimage import gaussian_filter, zoom
import math

# Set up logging
logger = logging.getLogger("FloodEngine.SaintVenant")

class SaintVenant2D:
    """
    Implementation of the full 2D Saint-Venant equations for surface water flow.
    Handles continuity and momentum equations in both x and y directions.
    """
    
    def __init__(self, dem_array, geotransform, dx=None, dy=None, manning_n=0.035):
        """
        Initialize the 2D Saint-Venant model.
        
        Parameters:
            dem_array (numpy.ndarray): Digital Elevation Model array
            geotransform (tuple): GDAL geotransform for the DEM
            dx (float): Cell size in x-direction (if None, calculated from geotransform)
            dy (float): Cell size in y-direction (if None, calculated from geotransform)
            manning_n (float or numpy.ndarray): Manning's roughness coefficient
        """
        self.dem = dem_array
        self.geotransform = geotransform
        
        # Calculate cell size from geotransform if not provided
        self.dx = dx if dx is not None else abs(geotransform[1])
        self.dy = dy if dy is not None else abs(geotransform[5])
        
        # Initialize flow state arrays
        self.shape = dem_array.shape
        self.h = np.zeros(self.shape)  # Water depth
        self.qx = np.zeros(self.shape)  # Unit discharge in x-direction
        self.qy = np.zeros(self.shape)  # Unit discharge in y-direction
        self.u = np.zeros(self.shape)   # Velocity in x-direction
        self.v = np.zeros(self.shape)   # Velocity in y-direction
        
        # Set Manning's n coefficient (can be constant or spatially variable)
        if isinstance(manning_n, (int, float)):
            self.manning = np.full(self.shape, manning_n)
        else:
            self.manning = manning_n
            
        # Physical constants
        self.g = 9.81  # Gravitational acceleration (m/s²)
        
        # Numerical parameters
        self.cfl = 0.45  # CFL condition for stability (should be < 0.5)
        self.epsilon = 1e-6  # Small value to prevent division by zero
        self.min_depth = 0.001  # Minimum water depth for computation (m)
        
        # Initialize velocity arrays
        self.velocity_x = np.zeros(self.shape)
        self.velocity_y = np.zeros(self.shape)
        self.velocity_mag = np.zeros(self.shape)
        
        logger.info(f"Initialized Saint-Venant 2D model with shape {self.shape}, dx={self.dx}, dy={self.dy}")
        
    def set_initial_condition(self, water_level=None, water_depth=None, initial_velocity=(0,0)):
        """
        Set initial condition for water depth and velocity.
        
        Parameters:
            water_level (float or numpy.ndarray): Water surface elevation
            water_depth (numpy.ndarray): Water depth
            initial_velocity (tuple): Initial velocity (ux, uy) in m/s
        """
        logger.info("Setting initial conditions...")
        if water_level is not None:
            logger.info(f"Using water level: {water_level}")
        elif water_depth is not None:
            logger.info(f"Using provided water depth array, max depth: {np.max(water_depth)}")
        logger.info(f"Initial velocity: {initial_velocity}")
        
        if water_depth is not None:
            self.h = water_depth.copy()
        elif water_level is not None:
            if isinstance(water_level, (int, float)):
                # Create a more natural initial water state using a comprehensive analysis
                logger.info("Analyzing terrain and identifying river network...")
                
                # First identify river network including potential source points
                river_tolerance = 1.0  # Allow 1m above water level for dam identification
                river_mask = (self.dem <= water_level + river_tolerance) & (~np.isnan(self.dem))
                
                if np.sum(river_mask) > 0:
                    # Find all potential source points (local elevation maximums in river network)
                    padded_dem = np.pad(self.dem, 1, mode='edge')
                    source_points = []
                    
                    for i in range(1, self.shape[0] + 1):
                        for j in range(1, self.shape[1] + 1):
                            if not river_mask[i-1, j-1]:
                                continue
                                
                            # Check if this is a local maximum
                            window = padded_dem[i-1:i+2, j-1:j+2]
                            if padded_dem[i,j] >= np.max(window):
                                source_points.append((i-1, j-1))
                    
                    logger.info(f"Found {len(source_points)} potential source points")
                    
                    # Initialize water depths - start with base river depth
                    self.h = np.zeros_like(self.dem)
                    river_depths = np.maximum(water_level - self.dem, 0)
                    
                    # Scale depths to prevent numerical instability
                    max_initial_depth = 1.0  # Maximum initial depth
                    if np.max(river_depths) > 0:
                        scale_factor = min(1.0, max_initial_depth / np.max(river_depths))
                        river_depths *= scale_factor
                    
                    # Add extra depth at source points
                    source_depth = 0.5  # Initial depth at source points
                    self.h[river_mask] = river_depths[river_mask]
                    for src_i, src_j in source_points:
                        self.h[src_i, src_j] = max(source_depth, self.h[src_i, src_j])
                    
                    # Set initial velocities based on terrain gradients
                    ux, uy = initial_velocity
                    self.u = np.full(self.shape, ux)
                    self.v = np.full(self.shape, uy)
                    
                    # Calculate initial flow directions based on terrain
                    for i in range(1, self.shape[0] + 1):
                        for j in range(1, self.shape[1] + 1):
                            if self.h[i-1, j-1] > self.min_depth:
                                # Calculate terrain gradient (using padded DEM)
                                dx = (padded_dem[i, j+1] - padded_dem[i, j-1]) / (2 * self.dx)
                                dy = (padded_dem[i+1, j] - padded_dem[i-1, j]) / (2 * self.dy)
                                
                                if dx*dx + dy*dy > 1e-6:  # If there's a significant gradient
                                    # Initialize flow downhill
                                    grad_mag = np.sqrt(dx*dx + dy*dy)
                                    self.u[i-1, j-1] = -dx/grad_mag * 0.2  # Initial velocity magnitude 0.2 m/s
                                    self.v[i-1, j-1] = -dy/grad_mag * 0.2
                                    
                    # Set initial unit discharges
                    self.qx = self.h * self.u
                    self.qy = self.h * self.v
                else:
                    # Fallback to simple initialization if no river network found
                    self.h = np.maximum(water_level - self.dem, 0)
                    ux, uy = initial_velocity
                    self.u = np.full(self.shape, ux)
                    self.v = np.full(self.shape, uy)
                    self.qx = self.h * self.u
                    self.qy = self.h * self.v
            else:
                # Handle array water level
                self.h = np.maximum(water_level - self.dem, 0)
                ux, uy = initial_velocity
                self.u = np.full(self.shape, ux)
                self.v = np.full(self.shape, uy)
                self.qx = self.h * self.u
                self.qy = self.h * self.v
        
        logger.info(f"Initial condition set with max depth: {np.nanmax(self.h):.3f}m")
        
    def calculate_timestep(self):
        """
        Calculate a stable time step based on the CFL condition.
        
        Returns:
            float: Time step in seconds
        """
        # Find maximum velocity (including wave celerity)
        max_depth = np.nanmax(self.h)
        if max_depth < self.min_depth:
            return 1.0  # Default if no water
            
        max_u = np.nanmax(np.abs(self.u))
        max_v = np.nanmax(np.abs(self.v))
        max_depth_velocity = np.sqrt(self.g * max_depth)
        
        # CFL condition - ensure stability with a more conservative factor for river flows
        self.cfl = min(0.45, 0.45 * (1.0 - 0.5 * max_depth / (max_depth + 0.1)))  # Adaptive CFL
        
        dt_x = self.cfl * self.dx / (max_u + max_depth_velocity + self.epsilon)
        dt_y = self.cfl * self.dy / (max_v + max_depth_velocity + self.epsilon)
        
        # Take the minimum time step
        dt = min(dt_x, dt_y)
        
        # Limit maximum time step for better stability in river flow
        max_dt = 5.0  # Maximum allowable time step (s)
        min_dt = 0.1  # Minimum time step to ensure smooth progression
        
        # Use smaller time steps when there's significant water
        if max_depth > 0.5:
            max_dt = 2.0
        
        return max(min_dt, min(dt, max_dt))
        
    def step(self, dt=None):
        """
        Advance the solution by one time step using a second-order TVD Runge-Kutta scheme.
        
        Parameters:
            dt (float): Time step in seconds. If None, calculated automatically.
            
        Returns:
            float: Actual time step used
        """
        if dt is None:
            dt = self.calculate_timestep()
            
        # Store current state
        h_old = self.h.copy()
        qx_old = self.qx.copy()
        qy_old = self.qy.copy()
        
        # First RK step
        self._update_fluxes(dt)
        
        # Store intermediate values
        h_int = self.h.copy()
        qx_int = self.qx.copy()
        qy_int = self.qy.copy()
        
        # Reset to old values for second step
        self.h = h_old
        self.qx = qx_old
        self.qy = qy_old
        
        # Second RK step
        self._update_fluxes(dt)
        
        # Combine steps (0.5 * old + 0.5 * intermediate)
        self.h = 0.5 * (h_old + h_int)
        self.qx = 0.5 * (qx_old + qx_int)
        self.qy = 0.5 * (qy_old + qy_int)
        
        # Apply boundary conditions
        self._apply_boundaries()
        
        # Update velocities
        self._update_velocities()
        
        return dt
    
    def _update_fluxes(self, dt):
        """
        Update water depth and momentum using finite volume discretization.
        Handles dams and barriers through modified flux calculations.
        
        Parameters:
            dt (float): Time step
        """
        # Create padded arrays for flux calculation with ghost cells
        h_pad = np.pad(self.h, 1, mode='edge')
        qx_pad = np.pad(self.qx, 1, mode='edge')
        qy_pad = np.pad(self.qy, 1, mode='edge')
        z_pad = np.pad(self.dem, 1, mode='edge')
        n_pad = np.pad(self.manning, 1, mode='edge')
        
        # Parameters for dam detection and handling
        dam_threshold = 0.5  # Minimum height difference to consider as a dam
        
        # Calculate fluxes at cell interfaces
        for i in range(1, self.shape[0] + 1):
            for j in range(1, self.shape[1] + 1):
                if h_pad[i, j] < self.min_depth:
                    continue
                
                # Get current cell's water surface elevation
                cell_water_surface = z_pad[i, j] + h_pad[i, j]
                
                # Calculate neighboring water surfaces
                water_surface_j_plus_1 = z_pad[i, j+1] + h_pad[i, j+1]
                water_surface_j_minus_1 = z_pad[i, j-1] + h_pad[i, j-1]
                water_surface_i_plus_1 = z_pad[i+1, j] + h_pad[i+1, j]
                water_surface_i_minus_1 = z_pad[i-1, j] + h_pad[i-1, j]
                
                # Check for dams/barriers in each direction
                dam_right = z_pad[i, j+1] - z_pad[i, j] > dam_threshold
                dam_left = z_pad[i, j-1] - z_pad[i, j] > dam_threshold
                dam_up = z_pad[i-1, j] - z_pad[i, j] > dam_threshold
                dam_down = z_pad[i+1, j] - z_pad[i, j] > dam_threshold
                
                # Calculate water surface gradients, accounting for dams
                if dam_right and cell_water_surface < z_pad[i, j+1]:
                    water_surface_j_plus_1 = z_pad[i, j+1]
                if dam_left and cell_water_surface < z_pad[i, j-1]:
                    water_surface_j_minus_1 = z_pad[i, j-1]
                if dam_up and cell_water_surface < z_pad[i-1, j]:
                    water_surface_i_minus_1 = z_pad[i-1, j]
                if dam_down and cell_water_surface < z_pad[i+1, j]:
                    water_surface_i_plus_1 = z_pad[i+1, j]
                
                # Calculate gradients for flow computation
                dz_dx = (water_surface_j_plus_1 - water_surface_j_minus_1) / (2 * self.dx)
                dz_dy = (water_surface_i_plus_1 - water_surface_i_minus_1) / (2 * self.dy)
                
                # Calculate velocities where depth is sufficient
                if h_pad[i, j] > self.min_depth:
                    u = qx_pad[i, j] / h_pad[i, j]
                    v = qy_pad[i, j] / h_pad[i, j]
                else:
                    u, v = 0, 0
                
                # Calculate friction term (Manning's equation)
                vel_mag = np.sqrt(u**2 + v**2)
                if vel_mag > self.epsilon:
                    sf_x = n_pad[i, j]**2 * u * vel_mag / (h_pad[i, j]**(4/3))
                    sf_y = n_pad[i, j]**2 * v * vel_mag / (h_pad[i, j]**(4/3))
                else:
                    sf_x, sf_y = 0, 0
                
                # Momentum equation terms
                source_x = -self.g * h_pad[i, j] * dz_dx - self.g * h_pad[i, j] * sf_x
                source_y = -self.g * h_pad[i, j] * dz_dy - self.g * h_pad[i, j] * sf_y
                
                # Dam flow handling - block flow if water can't overtop the dam
                # For Right direction
                if dam_right and (water_surface_j_plus_1 > z_pad[i, j+1] or water_surface_j_plus_1 < z_pad[i, j]):
                    # Water is either above the dam or hasn't reached it yet
                    pass  # Allow normal flow calculation
                elif dam_right:
                    # Dam is blocking flow in this direction
                    if dz_dx > 0:  # Only block flow toward the dam, not away from it
                        source_x = 0  # Block flow by zeroing the momentum source term
                
                # For Left direction
                if dam_left and (water_surface_j_minus_1 > z_pad[i, j-1] or water_surface_j_minus_1 < z_pad[i, j]):
                    # Water is either above the dam or hasn't reached it yet
                    pass  # Allow normal flow calculation
                elif dam_left:
                    # Dam is blocking flow in this direction
                    if dz_dx < 0:  # Only block flow toward the dam, not away from it
                        source_x = 0  # Block flow by zeroing the momentum source term
                
                # For Down direction (increasing i)
                if dam_down and (water_surface_i_plus_1 > z_pad[i+1, j] or water_surface_i_plus_1 < z_pad[i, j]):
                    # Water is either above the dam or hasn't reached it yet
                    pass  # Allow normal flow calculation
                elif dam_down:
                    # Dam is blocking flow in this direction
                    if dz_dy > 0:  # Only block flow toward the dam, not away from it
                        source_y = 0  # Block flow by zeroing the momentum source term
                
                # For Up direction (decreasing i)
                if dam_up and (water_surface_i_minus_1 > z_pad[i-1, j] or water_surface_i_minus_1 < z_pad[i, j]):
                    # Water is either above the dam or hasn't reached it yet
                    pass  # Allow normal flow calculation
                elif dam_up:
                    # Dam is blocking flow in this direction
                    if dz_dy < 0:  # Only block flow toward the dam, not away from it
                        source_y = 0  # Block flow by zeroing the momentum source term
                
                # Apply continuity equation (volume conservation)
                flux_h_x = (qx_pad[i, j+1] - qx_pad[i, j-1]) / (2 * self.dx)
                flux_h_y = (qy_pad[i+1, j] - qy_pad[i-1, j]) / (2 * self.dy)
                
                # Calculate momentum fluxes
                if h_pad[i, j] > self.min_depth:
                    flux_qx_x = (qx_pad[i, j+1]**2/h_pad[i, j+1] - qx_pad[i, j-1]**2/h_pad[i, j-1]) / (2 * self.dx)
                    flux_qx_y = (qx_pad[i+1, j]*qy_pad[i+1, j]/h_pad[i+1, j] - qx_pad[i-1, j]*qy_pad[i-1, j]/h_pad[i-1, j]) / (2 * self.dy)
                    
                    flux_qy_x = (qy_pad[i, j+1]*qx_pad[i, j+1]/h_pad[i, j+1] - qy_pad[i, j-1]*qx_pad[i, j-1]/h_pad[i, j-1]) / (2 * self.dx)
                    flux_qy_y = (qy_pad[i+1, j]**2/h_pad[i+1, j] - qy_pad[i-1, j]**2/h_pad[i-1, j]) / (2 * self.dy)
                else:
                    flux_qx_x, flux_qx_y, flux_qy_x, flux_qy_y = 0, 0, 0, 0
                
                # Update conserved variables
                self.h[i-1, j-1] -= dt * (flux_h_x + flux_h_y)
                self.qx[i-1, j-1] -= dt * (flux_qx_x + flux_qx_y - source_x)
                self.qy[i-1, j-1] -= dt * (flux_qy_x + flux_qy_y - source_y)
                
                # Ensure non-negative water depth
                self.h[i-1, j-1] = max(0, self.h[i-1, j-1])
                
                # Final dam blocking check - ensure no flow through unsubmerged dams
                cell_water_surface = self.dem[i-1, j-1] + self.h[i-1, j-1]
                for dy, dx in [(-1, 0), (1, 0), (0, -1), (0, 1)]:  # Up, Down, Left, Right
                    ni, nj = i-1+dy, j-1+dx
                    if 0 <= ni < self.shape[0] and 0 <= nj < self.shape[1]:
                        if self.dem[ni, nj] - self.dem[i-1, j-1] > dam_threshold and cell_water_surface < self.dem[ni, nj]:
                            if dx == 1:  # Right
                                self.qx[i-1, j-1] = max(0, self.qx[i-1, j-1])  # Allow only leftward flow
                            elif dx == -1:  # Left
                                self.qx[i-1, j-1] = min(0, self.qx[i-1, j-1])  # Allow only rightward flow
                            elif dy == 1:  # Down
                                self.qy[i-1, j-1] = max(0, self.qy[i-1, j-1])  # Allow only upward flow
                            elif dy == -1:  # Up
                                self.qy[i-1, j-1] = min(0, self.qy[i-1, j-1])  # Allow only downward flow
    
    def _apply_boundaries(self):
        """
        Apply boundary conditions. Handles both reflection and outflow at domain boundaries.
        """
        # Apply standard reflective boundary for water depth
        self.h[0, :] = self.h[1, :]
        self.h[-1, :] = self.h[-2, :]
        self.h[:, 0] = self.h[:, 1]
        self.h[:, -1] = self.h[:, -2]
        
        # Set up boundary velocities - reflection for closed boundaries
        self.qx[0, :] = -self.qx[1, :]
        self.qx[-1, :] = -self.qx[-2, :]
        self.qx[:, 0] = self.qx[:, 1]
        self.qx[:, -1] = self.qx[:, -2]
        
        self.qy[0, :] = self.qy[1, :]
        self.qy[-1, :] = self.qy[-2, :]
        self.qy[:, 0] = -self.qy[:, 1]
        self.qy[:, -1] = -self.qy[:, -2]
        
        # Allow outflow at domain boundaries where water depth is significant
        depth_threshold = 0.1  # meters
        
        # North boundary
        north_wet = self.h[0, :] > depth_threshold
        outflow = self.qy[0, :] < 0  # Negative y velocity = outward flow at north boundary
        self.qy[0, north_wet & outflow] = self.qy[1, north_wet & outflow]
        
        # South boundary
        south_wet = self.h[-1, :] > depth_threshold
        outflow = self.qy[-1, :] > 0  # Positive y velocity = outward flow at south boundary
        self.qy[-1, south_wet & outflow] = self.qy[-2, south_wet & outflow]
        
        # West boundary
        west_wet = self.h[:, 0] > depth_threshold
        outflow = self.qx[:, 0] < 0  # Negative x velocity = outward flow at west boundary
        self.qx[west_wet & outflow, 0] = self.qx[west_wet & outflow, 1]
        
        # East boundary
        east_wet = self.h[:, -1] > depth_threshold
        outflow = self.qx[:, -1] > 0  # Positive x velocity = outward flow at east boundary
        self.qx[east_wet & outflow, -1] = self.qx[east_wet & outflow, -2]
    
    def _update_velocities(self):
        """Update velocity fields based on unit discharges and water depth."""
        # Only calculate velocities where there is sufficient water
        mask = self.h > self.min_depth
        
        # Initialize velocities to zero
        self.u = np.zeros(self.shape)
        self.v = np.zeros(self.shape)
        
        # Calculate velocities where there's enough water
        self.u[mask] = self.qx[mask] / self.h[mask]
        self.v[mask] = self.qy[mask] / self.h[mask]
        
        # Limit velocities to physical values
        max_vel = 10.0  # m/s
        self.u = np.clip(self.u, -max_vel, max_vel)
        self.v = np.clip(self.v, -max_vel, max_vel)
        
        # Calculate velocity magnitude
        self.velocity_mag = np.sqrt(self.u**2 + self.v**2)
        
        # Store velocity components
        self.velocity_x = self.u.copy()
        self.velocity_y = self.v.copy()
    
    def get_water_surface(self):
        """Get water surface elevation."""
        return self.dem + self.h
    
    def get_velocity_field(self):
        """Get velocity components and magnitude."""
        return self.velocity_x, self.velocity_y, self.velocity_mag
