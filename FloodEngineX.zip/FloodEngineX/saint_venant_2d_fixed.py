"""
2D Saint-Venant Equations Module for FloodEngine
------------------------------------------------
This module implements the full 2D Saint-Venant equations for advanced hydraulic modeling,
providing more accurate flow simulation, especially in complex terrain.
"""

import os
import time
import numpy as np
from osgeo import gdal
import logging
from scipy.ndimage import gaussian_filter, zoom
import math

# Import numba for performance optimization
try:
    import numba
    from numba import jit, njit
    NUMBA_AVAILABLE = True
    print("✅ Numba optimization available - expect 5-10x faster simulation")
except ImportError:
    print("⚠️ Numba not available - simulation will be slower")
    NUMBA_AVAILABLE = False
    # Create dummy decorators
    def jit(*args, **kwargs):
        def decorator(func):
            return func
        return decorator
    def njit(*args, **kwargs):
        def decorator(func):
            return func
        return decorator


# Try to import numba for performance optimization
try:
    from numba import jit, njit, prange
    NUMBA_AVAILABLE = True
    print("✅ Numba available - using optimized computation")
except ImportError:
    print("⚠️ Numba not available - using standard numpy")
    NUMBA_AVAILABLE = False
    # Create dummy decorators
    def jit(func):
        return func
    def njit(func):
        return func
    def prange(x):
        return range(x)

# Set up logging
logger = logging.getLogger("FloodEngine.SaintVenant")

class SaintVenant2D:
    """
    Implementation of the full 2D Saint-Venant equations for surface water flow.
    Handles continuity and momentum equations in both x and y directions.
    """
    
    def __init__(self, dem_array, geotransform, dx=None, dy=None, manning_n=0.035):
        """
        Initialize the 2D Saint-Venant model.
        
        Parameters:
            dem_array (numpy.ndarray): Digital Elevation Model array
            geotransform (tuple): GDAL geotransform for the DEM
            dx (float): Cell size in x-direction (if None, calculated from geotransform)
            dy (float): Cell size in y-direction (if None, calculated from geotransform)
            manning_n (float or numpy.ndarray): Manning's roughness coefficient
        """
        self.dem = dem_array
        self.geotransform = geotransform
        
        # Calculate cell size from geotransform if not provided
        self.dx = dx if dx is not None else abs(geotransform[1])
        self.dy = dy if dy is not None else abs(geotransform[5])
        
        # Initialize flow state arrays
        self.shape = dem_array.shape
        self.h = np.zeros(self.shape)  # Water depth
        self.qx = np.zeros(self.shape)  # Unit discharge in x-direction
        self.qy = np.zeros(self.shape)  # Unit discharge in y-direction
        self.u = np.zeros(self.shape)   # Velocity in x-direction
        self.v = np.zeros(self.shape)   # Velocity in y-direction
        
        # Set Manning's n coefficient (can be constant or spatially variable)
        if isinstance(manning_n, (int, float)):
            self.manning = np.full(self.shape, manning_n)
        else:
            self.manning = manning_n
            
        # Physical constants
        self.g = 9.81  # Gravitational acceleration (m/s²)
        
        # Numerical parameters
        self.cfl = 0.45  # CFL condition for stability (should be < 0.5)
        self.epsilon = 1e-6  # Small value to prevent division by zero
        self.min_depth = 0.001  # Minimum water depth for computation (m)
        
        # Initialize velocity arrays
        self.velocity_x = np.zeros(self.shape)
        self.velocity_y = np.zeros(self.shape)
        self.velocity_mag = np.zeros(self.shape)
        
        logger.info(f"Initialized Saint-Venant 2D model with shape {self.shape}, dx={self.dx}, dy={self.dy}")

    def set_initial_condition(self, water_level=None, water_depth=None, initial_velocity=(0,0)):
        """
        Set initial condition for water depth and velocity.
        
        Parameters:
            water_level (float or numpy.ndarray): Water surface elevation
            water_depth (numpy.ndarray): Water depth
            initial_velocity (tuple): Initial velocity (ux, uy) in m/s
        """
        if water_depth is not None:
            self.h = water_depth.copy()
        elif water_level is not None:
            if isinstance(water_level, (int, float)):
                # Create a more natural initial water state - use a gradient
                # to simulate that water naturally starts from higher elevations
                # Calculate river network based on elevation threshold
                river_mask = (self.dem < water_level) & (~np.isnan(self.dem))
                
                if np.sum(river_mask) > 0:
                    # Basic river depth - deeper where elevation is lower
                    self.h = np.zeros_like(self.dem)
                    river_depths = np.maximum(water_level - self.dem, 0)
                    
                    # Scale the depths to ensure there's not too much water initially
                    # This prevents numerical issues in very steep terrain
                    max_initial_depth = 1.0  # Maximum initial depth
                    if np.max(river_depths) > 0:
                        scale_factor = min(1.0, max_initial_depth / np.max(river_depths))
                        river_depths *= scale_factor
                    
                    # Set the scaled depths
                    self.h[river_mask] = river_depths[river_mask]
                else:
                    # Fallback to simple calculation
                    self.h = np.maximum(water_level - self.dem, 0)
            else:
                self.h = np.maximum(water_level - self.dem, 0)
        
        # Set initial velocities
        ux, uy = initial_velocity
        self.u = np.full(self.shape, ux)
        self.v = np.full(self.shape, uy)
        
        # Set initial unit discharges
        self.qx = self.h * self.u
        self.qy = self.h * self.v
        
        # Additional step: Calculate initial flow direction based on terrain gradient
        # This helps establish the river's flow pattern from higher to lower elevations
        if np.sum(self.h > self.min_depth) > 0:
            # Compute terrain gradient
            padded_dem = np.pad(self.dem, 1, mode='edge')
            for i in range(1, self.shape[0] + 1):
                for j in range(1, self.shape[1] + 1):
                    if self.h[i-1, j-1] > self.min_depth:
                        # Calculate terrain gradient (central difference)
                        dx = (padded_dem[i, j+1] - padded_dem[i, j-1]) / (2 * self.dx)
                        dy = (padded_dem[i+1, j] - padded_dem[i-1, j]) / (2 * self.dy)
                        
                        if dx*dx + dy*dy > 1e-6:  # If there is a significant gradient
                            # Initialize flow downhill
                            grad_mag = np.sqrt(dx*dx + dy*dy)
                            self.u[i-1, j-1] = -dx/grad_mag * 0.2  # Mild initial velocity
                            self.v[i-1, j-1] = -dy/grad_mag * 0.2  # Mild initial velocity
                            
                            # Update unit discharge
                            self.qx[i-1, j-1] = self.h[i-1, j-1] * self.u[i-1, j-1]
                            self.qy[i-1, j-1] = self.h[i-1, j-1] * self.v[i-1, j-1]
        
        logger.info(f"Initial condition set with max depth: {np.nanmax(self.h):.3f}m")

    def calculate_timestep(self):
        """
        Calculate a stable time step based on the CFL condition.
        
        Returns:
            float: Time step in seconds
        """
        # Find maximum velocity (including wave celerity)
        max_depth = np.nanmax(self.h)
        if max_depth < self.min_depth:
            return 1.0  # Default if no water
            
        max_u = np.nanmax(np.abs(self.u))
        max_v = np.nanmax(np.abs(self.v))
        max_depth_velocity = np.sqrt(self.g * max_depth)
        
        # CFL condition - ensure stability with a more conservative factor for river flows
        self.cfl = min(0.45, 0.45 * (1.0 - 0.5 * max_depth / (max_depth + 0.1)))  # Adaptive CFL
        
        dt_x = self.cfl * self.dx / (max_u + max_depth_velocity + self.epsilon)
        dt_y = self.cfl * self.dy / (max_v + max_depth_velocity + self.epsilon)
        
        # Take the minimum time step
        dt = min(dt_x, dt_y)
        
        # Limit maximum time step for stability and better accuracy in river flow
        max_dt = 5.0  # Reduced maximum allowable time step (s) for better river representation
        min_dt = 0.1  # Minimum time step to ensure smooth progression
        
        # If using an inflow, further restrict the time step to capture the inflow dynamics
        if np.nanmax(self.h) > 0.5:  # If there's significant water
            # Use smaller time steps for better stability
            max_dt = 2.0
        
        return max(min_dt, min(dt, max_dt))
    
    def step(self, dt=None):
        """
        Advance the solution by one time step using a second-order TVD Runge-Kutta scheme.
        
        Parameters:
            dt (float): Time step in seconds. If None, calculated automatically.
            
        Returns:
            float: Actual time step used
        """
        if dt is None:
            dt = self.calculate_timestep()
            
        # Store current state
        h_old = self.h.copy()
        qx_old = self.qx.copy()
        qy_old = self.qy.copy()
        
        # First RK step
        self._update_fluxes(dt)
        
        # Store intermediate values
        h_int = self.h.copy()
        qx_int = self.qx.copy()
        qy_int = self.qy.copy()
        
        # Reset to old values for second step
        self.h = h_old
        self.qx = qx_old
        self.qy = qy_old
        
        # Second RK step
        self._update_fluxes(dt)
        
        # Combine steps (0.5 * old + 0.5 * intermediate)
        self.h = 0.5 * (h_old + h_int)
        self.qx = 0.5 * (qx_old + qx_int)
        self.qy = 0.5 * (qy_old + qy_int)
        
        # Apply boundary conditions
        self._apply_boundaries()
        
        # Update velocities
        self._update_velocities()
        
        # Add debug output - calculate maximum velocity and water depth
        max_velocity = np.sqrt(np.nanmax(self.u**2 + self.v**2))
        max_depth = np.nanmax(self.h)
        
        if max_velocity < 0.0001 and max_depth < 0.01:
            print(f"WARNING: Very small velocities and depths - simulation may be stagnant")
        
        return dt
    
    def step_numba_optimized(self, dt=None):
        """
        Advance the solution by one time step using numba optimization.
        
        Parameters:
            dt (float): Time step in seconds. If None, calculated automatically.
            
        Returns:
            float: Actual time step used
        """
        if dt is None:
            # Use numba-optimized timestep calculation
            dt = calculate_cfl_timestep_numba(
                self.h, self.qx, self.qy, self.dx, self.dy, 
                self.cfl, self.min_depth, self.g
            )
            dt = max(0.001, min(dt, 10.0))  # Clamp timestep
        
        # Use numba-optimized computation for the time step
        compute_saint_venant_step_numba(
            self.h, self.qx, self.qy, self.dem, self.manning, 
            self.dx, self.dy, dt, self.g, self.min_depth, self.shape
        )
        
        # Apply boundary conditions
        apply_boundary_conditions_numba(self.h, self.qx, self.qy, self.shape)
        
        # Update velocities
        self._update_velocities()
        
        return dt

    def _update_fluxes(self, dt):
        """
        Update water depth and momentum using finite volume discretization.
        
        Parameters:
            dt (float): Time step
        """
        # Create padded arrays for flux calculation with ghost cells
        h_pad = np.pad(self.h, 1, mode='edge')
        qx_pad = np.pad(self.qx, 1, mode='edge')
        qy_pad = np.pad(self.qy, 1, mode='edge')
        z_pad = np.pad(self.dem, 1, mode='edge')
        n_pad = np.pad(self.manning, 1, mode='edge')
        
        # Calculate fluxes at cell interfaces
        for i in range(1, self.shape[0] + 1):
            for j in range(1, self.shape[1] + 1):
                if h_pad[i, j] < self.min_depth:
                    continue
                
                # Calculate slopes of water surface (not just terrain) in x and y directions
                # Water surface = terrain elevation + water depth
                water_surface_j_plus_1 = z_pad[i, j+1] + h_pad[i, j+1]
                water_surface_j_minus_1 = z_pad[i, j-1] + h_pad[i, j-1]
                water_surface_i_plus_1 = z_pad[i+1, j] + h_pad[i+1, j]
                water_surface_i_minus_1 = z_pad[i-1, j] + h_pad[i-1, j]
                
                # Calculate water surface gradients
                dz_dx = (water_surface_j_plus_1 - water_surface_j_minus_1) / (2 * self.dx)
                dz_dy = (water_surface_i_plus_1 - water_surface_i_minus_1) / (2 * self.dy)
                
                # Calculate velocities where depth is sufficient
                if h_pad[i, j] > self.min_depth:
                    u = qx_pad[i, j] / h_pad[i, j]
                    v = qy_pad[i, j] / h_pad[i, j]
                else:
                    u, v = 0, 0
                
                # Calculate friction term (Manning's equation)
                vel_mag = np.sqrt(u**2 + v**2)
                if vel_mag > self.epsilon:
                    sf_x = n_pad[i, j]**2 * u * vel_mag / (h_pad[i, j]**(4/3))
                    sf_y = n_pad[i, j]**2 * v * vel_mag / (h_pad[i, j]**(4/3))
                else:
                    sf_x, sf_y = 0, 0
                
                # Momentum equation terms
                source_x = -self.g * h_pad[i, j] * dz_dx - self.g * h_pad[i, j] * sf_x
                source_y = -self.g * h_pad[i, j] * dz_dy - self.g * h_pad[i, j] * sf_y
                
                # Apply continuity equation (volume conservation)
                # Finite volume approach: fluxes across cell interfaces
                flux_h_x = (qx_pad[i, j+1] - qx_pad[i, j-1]) / (2 * self.dx)
                flux_h_y = (qy_pad[i+1, j] - qy_pad[i-1, j]) / (2 * self.dy)
                
                # Calculate momentum fluxes
                if h_pad[i, j] > self.min_depth:
                    flux_qx_x = (qx_pad[i, j+1]**2/h_pad[i, j+1] - qx_pad[i, j-1]**2/h_pad[i, j-1]) / (2 * self.dx)
                    flux_qx_y = (qx_pad[i+1, j]*qy_pad[i+1, j]/h_pad[i+1, j] - qx_pad[i-1, j]*qy_pad[i-1, j]/h_pad[i-1, j]) / (2 * self.dy)
                    
                    flux_qy_x = (qy_pad[i, j+1]*qx_pad[i, j+1]/h_pad[i, j+1] - qy_pad[i, j-1]*qx_pad[i, j-1]/h_pad[i, j-1]) / (2 * self.dx)
                    flux_qy_y = (qy_pad[i+1, j]**2/h_pad[i+1, j] - qy_pad[i-1, j]**2/h_pad[i-1, j]) / (2 * self.dy)
                else:
                    flux_qx_x, flux_qx_y, flux_qy_x, flux_qy_y = 0, 0, 0, 0
                
                # Update conserved variables
                self.h[i-1, j-1] -= dt * (flux_h_x + flux_h_y)
                self.qx[i-1, j-1] -= dt * (flux_qx_x + flux_qx_y - source_x)
                self.qy[i-1, j-1] -= dt * (flux_qy_x + flux_qy_y - source_y)
                
                # Ensure non-negative water depth
                self.h[i-1, j-1] = max(0, self.h[i-1, j-1])

    def _apply_boundaries(self):
        """Apply boundary conditions"""
        # Reflective boundary conditions with modification to allow water to exit at lowest points
        
        # First, find the lowest elevation points along each boundary
        # These will serve as outlets where water can leave the domain
        
        # Create arrays for boundary elevations
        west_elevations = self.dem[:, 0]
        east_elevations = self.dem[:, -1]
        north_elevations = self.dem[0, :]
        south_elevations = self.dem[-1, :]
        
        # Apply standard reflective boundary for most boundary points
        self.h[0, :] = self.h[1, :]
        self.h[-1, :] = self.h[-2, :]
        self.h[:, 0] = self.h[:, 1]
        self.h[:, -1] = self.h[:, -2]
        
        # Reflection means negative velocity at boundaries to prevent water from crossing
        self.qx[0, :] = -self.qx[1, :]
        self.qx[-1, :] = -self.qx[-2, :]
        self.qx[:, 0] = self.qx[:, 1]
        self.qx[:, -1] = self.qx[:, -2]
        
        self.qy[0, :] = self.qy[1, :]
        self.qy[-1, :] = self.qy[-2, :]
        self.qy[:, 0] = -self.qy[:, 1]
        self.qy[:, -1] = -self.qy[:, -2]
        
        # Special handling for boundary cells with water depth
        # This ensures water can flow out of the domain at low points
        # Water will naturally accumulate at topographic lows and should be allowed
        # to exit the domain rather than getting "stuck" at the boundary
        
        # Find cells at the boundary with significant water (> 10cm) and with outward velocity
        # North boundary (top)
        north_wet = self.h[0, :] > 0.1
        if np.any(north_wet):
            # Allow outward flow (negative y velocity) at wet north boundary cells
            outward_flow = self.qy[0, :] < 0
            self.qy[0, north_wet & outward_flow] = self.qy[1, north_wet & outward_flow]
        
        # South boundary (bottom)
        south_wet = self.h[-1, :] > 0.1
        if np.any(south_wet):
            # Allow outward flow (positive y velocity) at wet south boundary cells
            outward_flow = self.qy[-1, :] > 0
            self.qy[-1, south_wet & outward_flow] = self.qy[-2, south_wet & outward_flow]
        
        # West boundary (left)
        west_wet = self.h[:, 0] > 0.1
        if np.any(west_wet):
            # Allow outward flow (negative x velocity) at wet west boundary cells
            outward_flow = self.qx[:, 0] < 0
            self.qx[west_wet & outward_flow, 0] = self.qx[west_wet & outward_flow, 1]
        
        # East boundary (right)
        east_wet = self.h[:, -1] > 0.1
        if np.any(east_wet):
            # Allow outward flow (positive x velocity) at wet east boundary cells
            outward_flow = self.qx[:, -1] > 0
            self.qx[east_wet & outward_flow, -1] = self.qx[east_wet & outward_flow, -2]
    
    def _update_velocities(self):
        """Update velocity fields based on unit discharges and water depth."""
        # Only calculate velocities where there is sufficient water
        mask = self.h > self.min_depth
        
        # Initialize velocities to zero
        self.u = np.zeros(self.shape)
        self.v = np.zeros(self.shape)
        
        # Calculate velocities only where there's enough water
        self.u[mask] = self.qx[mask] / self.h[mask]
        self.v[mask] = self.qy[mask] / self.h[mask]
        
        # Limit velocities to physical values (optional)
        max_vel = 10.0  # m/s
        self.u = np.clip(self.u, -max_vel, max_vel)
        self.v = np.clip(self.v, -max_vel, max_vel)
        
        # Calculate velocity magnitude for visualization
        self.velocity_mag = np.sqrt(self.u**2 + self.v**2)
        
        # Store velocity components for streamline calculation
        self.velocity_x = self.u.copy()
        self.velocity_y = self.v.copy()
        
        # Apply flow direction correction to ensure water flows downhill
        try:
            from flow_direction import ensure_correct_flow_directions
            self.velocity_x, self.velocity_y = ensure_correct_flow_directions(
                self.dem, self.h, self.velocity_x, self.velocity_y)
        except ImportError:
            # Fallback if flow_direction module cannot be imported
            pass
    
    def get_water_surface(self):
        """Get water surface elevation."""
        return self.dem + self.h
    
    def get_velocity_field(self):
        """Get velocity components and magnitude."""
        return self.velocity_x, self.velocity_y, self.velocity_mag


def simulate_saint_venant_2d(dem_path, initial_water_level, output_folder, 
                            time_steps=50, time_step_seconds=None,
                            inflow_rate=None, inflow_location=None,
                            manning_n=0.035, bounding_box=None, resolution_factor=1, **kwargs):
    """
    Run a 2D Saint-Venant simulation and save results.
    
    Parameters:
        dem_path (str): Path to DEM raster file
        initial_water_level (float): Initial water level elevation
        output_folder (str): Folder to save output files
        time_steps (int): Number of time steps to simulate
        time_step_seconds (float): Time step in seconds (if None, calculated automatically)
        inflow_rate (float): Water inflow rate in m³/s
        inflow_location (tuple): (x, y) coordinates for inflow
        manning_n (float or str): Manning's roughness coefficient or path to Manning's n raster
        bounding_box (tuple): Bounding box to limit calculation area (xmin, ymin, xmax, ymax)
        resolution_factor (float): Factor to reduce resolution (1=original, 2=half resolution, etc.)
        
    Returns:
        list: Paths to output water surface files
    """
    os.makedirs(output_folder, exist_ok=True)
    
    # Read DEM
    dem_ds = gdal.Open(dem_path)
    
    # Handle bounding box if specified
    if bounding_box is not None:
        xmin, ymin, xmax, ymax = bounding_box
        logger.info(f"Using bounding box: ({xmin}, {ymin}, {xmax}, {ymax})")
        
        # Get raster info
        geotransform = dem_ds.GetGeoTransform()
        projection = dem_ds.GetProjection()
        
        # Convert world coordinates to pixel coordinates
        pixel_xmin = int((xmin - geotransform[0]) / geotransform[1])
        pixel_ymin = int((ymin - geotransform[3]) / geotransform[5])
        pixel_xmax = int((xmax - geotransform[0]) / geotransform[1])
        pixel_ymax = int((ymax - geotransform[3]) / geotransform[5])
        
        # Ensure correct ordering (in case of negative pixel size)
        if pixel_xmin > pixel_xmax:
            pixel_xmin, pixel_xmax = pixel_xmax, pixel_xmin
        if pixel_ymin > pixel_ymax:
            pixel_ymin, pixel_ymax = pixel_ymax, pixel_ymin
            
        # Calculate width and height
        width = pixel_xmax - pixel_xmin
        height = pixel_ymax - pixel_ymin
        
        # Update geotransform for the subset
        subset_geotransform = list(geotransform)
        subset_geotransform[0] = geotransform[0] + pixel_xmin * geotransform[1]
        subset_geotransform[3] = geotransform[3] + pixel_ymin * geotransform[5]
        
        # Read subset of the DEM
        dem_band = dem_ds.GetRasterBand(1)
        dem_array = dem_band.ReadAsArray(pixel_xmin, pixel_ymin, width, height).astype(np.float32)
        geotransform = tuple(subset_geotransform)
        logger.info(f"Using DEM subset: {width}x{height} pixels")
    else:
        # Read the full DEM
        dem_array = dem_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
        geotransform = dem_ds.GetGeoTransform()
        projection = dem_ds.GetProjection()
        
    # Handle resolution reduction if requested
    if resolution_factor > 1:
        logger.info(f"Reducing resolution by factor {resolution_factor}")
        
        # Calculate new dimensions
        new_height = int(dem_array.shape[0] / resolution_factor)
        new_width = int(dem_array.shape[1] / resolution_factor)
        
        # Downsample the DEM using box averaging
        from scipy.ndimage import zoom
        dem_array = zoom(dem_array, 1/resolution_factor, order=1)
        
        # Update geotransform
        new_geotransform = list(geotransform)
        new_geotransform[1] *= resolution_factor  # Adjust pixel width
        new_geotransform[5] *= resolution_factor  # Adjust pixel height
        geotransform = tuple(new_geotransform)
        
        logger.info(f"Reduced DEM size to {new_width}x{new_height} pixels")
    
    nodata = dem_ds.GetRasterBand(1).GetNoDataValue()
    
    # Replace nodata values with NaN
    dem_array[dem_array == nodata] = np.nan
    
    # Initialize Manning's n (spatially variable or constant)
    if isinstance(manning_n, str) and os.path.exists(manning_n):
        # Load Manning's n from raster
        n_ds = gdal.Open(manning_n)
        n_array = n_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
        # Replace invalid values
        n_array[np.isnan(n_array) | (n_array <= 0)] = 0.035
    else:
        # Use constant Manning's n
        n_array = np.full_like(dem_array, manning_n)
    
    # Initialize Saint-Venant model
    model = SaintVenant2D(dem_array, geotransform, manning_n=n_array)
    
    # Set initial condition
    model.set_initial_condition(water_level=initial_water_level)
    
    # Prepare for inflow if specified
    if inflow_rate is not None:
        # Calculate cell area
        cell_area = abs(geotransform[1] * geotransform[5])
        
        # Calculate inflow depth rate (m/s)
        inflow_depth_rate = inflow_rate / cell_area
        
        if inflow_location is not None:
            # Convert world coordinates to array indices
            x, y = inflow_location
            px = int((x - geotransform[0]) / geotransform[1])
            py = int((y - geotransform[3]) / geotransform[5])
        else:
            # Automatically find highest point in river network
            # Create a river mask based on water depth threshold
            river_mask = (dem_array < initial_water_level) & (~np.isnan(dem_array))
            
            if np.sum(river_mask) > 0:
                # Find highest elevation point in the river network
                river_elevations = np.where(river_mask, dem_array, -np.inf)
                highest_idx = np.unravel_index(np.argmax(river_elevations), dem_array.shape)
                py, px = highest_idx
                
                logger.info(f"Automatically found river source at elevation {dem_array[py, px]:.2f}m at position ({px}, {py})")
            else:
                # Fallback to center of the highest 10% of valid DEM cells
                valid_mask = ~np.isnan(dem_array)
                if np.sum(valid_mask) > 0:
                    valid_dem = dem_array[valid_mask]
                    threshold = np.percentile(valid_dem, 90)  # Top 10% elevation
                    high_points = (dem_array > threshold) & valid_mask
                    
                    if np.sum(high_points) > 0:
                        high_indices = np.argwhere(high_points)
                        center_idx = high_indices[len(high_indices)//2]
                        py, px = center_idx
                    else:
                        py, px = dem_array.shape[0]//2, dem_array.shape[1]//2  # Center of DEM
                else:
                    py, px = dem_array.shape[0]//2, dem_array.shape[1]//2  # Center of DEM
    else:
        inflow_depth_rate = 0
        px, py = 0, 0  # Dummy values
    
    # List to store output file paths
    output_files = []
    velocity_files = []
    
    # Main simulation loop
    total_sim_time = 0
    print(f"🚀 Starting Saint-Venant simulation with {time_steps} timesteps")
    
    for step in range(time_steps):
        # Calculate adaptive time step if not specified with performance optimization
        if time_step_seconds is not None:
            dt = time_step_seconds
        else:
            dt = model.calculate_timestep()
            # Ensure minimum progress by preventing extremely small timesteps
            if dt < 0.001:  # Less than 1ms
                dt = 0.001
            # But also prevent instability from too large timesteps
            elif dt > 10.0:  # More than 10 seconds
                dt = 10.0
        
        # Add inflow at the specified point (representing river source)
        if inflow_rate is not None and 0 <= px < model.shape[1] and 0 <= py < model.shape[0]:
            # Add water at the inflow point
            model.h[py, px] += inflow_depth_rate * dt
            
            # Since this is the source of the river, ensure there's enough water depth here
            # to initiate flow - a minimum source depth ensures river forms properly
            min_source_depth = 0.5  # minimum half meter depth at source
            if model.h[py, px] < min_source_depth:
                model.h[py, px] = min_source_depth
        
        # Advance simulation using optimized step function
        if NUMBA_AVAILABLE:
            # Use numba-optimized computation
            actual_dt = model.step_numba_optimized(dt)
        else:
            # Fall back to standard computation
            actual_dt = model.step(dt)
        
        total_sim_time += actual_dt
        
        # Progress reporting every 5% of simulation for better user feedback
        progress_percent = int((step + 1) / time_steps * 100)
        progress_interval = max(1, time_steps // 20)  # Report every 5%
        if step % progress_interval == 0 or step == time_steps - 1:
            max_depth = np.nanmax(model.h)
            max_vel = np.nanmax(np.sqrt(model.u**2 + model.v**2))
            print(f"  ⏱️ Step {step+1}/{time_steps} ({progress_percent}%): t={total_sim_time:.2f}s, max_depth={max_depth:.3f}m, max_vel={max_vel:.3f}m/s")            # Get water surface
            water_surface = model.get_water_surface()
            
            # Only save every few steps to reduce file count but still get temporal coverage
            save_interval = max(1, time_steps // 10)  # Save about 10 outputs
            if step % save_interval == 0 or step == time_steps - 1:  # Always save last timestep
                # Save water surface raster
                water_path = os.path.join(output_folder, f"water_step_{step:03d}.tif")
                driver = gdal.GetDriverByName("GTiff")
                out_ds = driver.Create(water_path, dem_array.shape[1], dem_array.shape[0], 1, gdal.GDT_Float32)
                out_ds.SetGeoTransform(geotransform)
                out_ds.SetProjection(projection)
                out_band = out_ds.GetRasterBand(1)
                out_band.SetNoDataValue(-9999)
                # PATCH: Set all dry/non-flooded cells to np.nan for proper transparency/clipping
                # This ensures that areas with no water (h == 0) are rendered as transparent
                water_surface_output = water_surface.copy()
                water_surface_output[model.h <= 0] = np.nan  # Use water depth mask
                out_band.WriteArray(np.where(np.isnan(water_surface_output), -9999, water_surface_output))
                out_ds.FlushCache()
                output_files.append(water_path)
                
                print(f"  Step {step+1}/{time_steps}: Saved water surface raster")
        
        # Save velocity magnitude raster (for visualization)
        velocity_x, velocity_y, velocity_mag = model.get_velocity_field()
        velocity_path = os.path.join(output_folder, f"velocity_step_{step:03d}.tif")
        driver = gdal.GetDriverByName("GTiff")
        out_ds = driver.Create(velocity_path, dem_array.shape[1], dem_array.shape[0], 1, gdal.GDT_Float32)
        out_ds.SetGeoTransform(geotransform)
        out_ds.SetProjection(projection)
        out_band = out_ds.GetRasterBand(1)
        out_band.SetNoDataValue(-9999)
        # PATCH: Set all dry/non-flooded cells to np.nan for proper transparency/clipping
        # This ensures that areas with no water (h == 0) are rendered as transparent
        velocity_mag_output = velocity_mag.copy()
        velocity_mag_output[model.h <= 0] = np.nan  # Use water depth mask
        out_band.WriteArray(np.where(np.isnan(velocity_mag_output), -9999, velocity_mag_output))
        out_ds.FlushCache()
        velocity_files.append(velocity_path)
        
        # *** CRITICAL FIX: Save velocity components for flow points and streamlines ***
        # This was the missing link preventing Saint-Venant integration!
        
        # Save velocity X component
        velocity_x_path = os.path.join(output_folder, f"velocity_x_step_{step:03d}.tif")
        out_ds_x = driver.Create(velocity_x_path, dem_array.shape[1], dem_array.shape[0], 1, gdal.GDT_Float32)
        out_ds_x.SetGeoTransform(geotransform)
        out_ds_x.SetProjection(projection)
        out_band_x = out_ds_x.GetRasterBand(1)
        out_band_x.SetNoDataValue(-9999)
        velocity_x_output = velocity_x.copy()
        velocity_x_output[model.h <= 0] = np.nan
        out_band_x.WriteArray(np.where(np.isnan(velocity_x_output), -9999, velocity_x_output))
        out_ds_x.FlushCache()
        out_ds_x = None  # Close file
        
        # Save velocity Y component  
        velocity_y_path = os.path.join(output_folder, f"velocity_y_step_{step:03d}.tif")
        out_ds_y = driver.Create(velocity_y_path, dem_array.shape[1], dem_array.shape[0], 1, gdal.GDT_Float32)
        out_ds_y.SetGeoTransform(geotransform)
        out_ds_y.SetProjection(projection)
        out_band_y = out_ds_y.GetRasterBand(1)
        out_band_y.SetNoDataValue(-9999)
        velocity_y_output = velocity_y.copy()
        velocity_y_output[model.h <= 0] = np.nan
        out_band_y.WriteArray(np.where(np.isnan(velocity_y_output), -9999, velocity_y_output))
        out_ds_y.FlushCache()
        out_ds_y = None  # Close file
        
        logger.info(f"✅ Saved velocity components: velocity_x_step_{step:03d}.tif, velocity_y_step_{step:03d}.tif")
        
        logger.info(f"Step {step+1}/{time_steps} complete. Time: {total_sim_time:.2f}s, Max depth: {np.nanmax(model.h):.3f}m")
    
    logger.info(f"Simulation complete. Total simulation time: {total_sim_time:.2f}s")
    
    return output_files, velocity_files

# Numba-optimized computation functions
@njit
def compute_saint_venant_step_numba(h, qx, qy, dem, manning, dx, dy, dt, g, min_depth, shape):
    """
    Numba-optimized Saint-Venant computation for one time step.
    This function is compiled to machine code for maximum performance.
    """
    rows, cols = shape
    h_new = h.copy()
    qx_new = qx.copy()
    qy_new = qy.copy()
    
    # Apply boundary conditions (zero gradient at boundaries)
    for i in prange(rows):
        for j in prange(cols):
            # Skip boundary cells
            if i == 0 or i == rows-1 or j == 0 or j == cols-1:
                continue
                
            # Skip dry cells
            if h[i, j] < min_depth:
                h_new[i, j] = 0.0
                qx_new[i, j] = 0.0
                qy_new[i, j] = 0.0
                continue
            
            # Continuity equation: ∂h/∂t + ∂qx/∂x + ∂qy/∂y = 0
            dqx_dx = (qx[i, j+1] - qx[i, j-1]) / (2 * dx)
            dqy_dy = (qy[i+1, j] - qy[i-1, j]) / (2 * dy)
            
            h_new[i, j] = h[i, j] - dt * (dqx_dx + dqy_dy)
            
            # Ensure positive depth
            if h_new[i, j] < min_depth:
                h_new[i, j] = 0.0
                qx_new[i, j] = 0.0
                qy_new[i, j] = 0.0
                continue
            
            # Calculate velocities
            u = qx[i, j] / max(h[i, j], min_depth)
            v = qy[i, j] / max(h[i, j], min_depth)
            
            # X-momentum equation
            # ∂qx/∂t + ∂(qx²/h + gh²/2)/∂x + ∂(qxqy/h)/∂y = -gh∂z/∂x - gn²qx√(qx²+qy²)/h^(4/3)
            
            # Pressure gradient term
            dh_dx = (h[i, j+1] - h[i, j-1]) / (2 * dx)
            dz_dx = (dem[i, j+1] - dem[i, j-1]) / (2 * dx)
            pressure_grad_x = g * h[i, j] * (dh_dx + dz_dx)
            
            # Friction term (Manning's equation)
            velocity_mag = math.sqrt(u*u + v*v)
            if velocity_mag > 1e-6:
                friction_x = g * manning[i, j]**2 * qx[i, j] * velocity_mag / (h[i, j]**(4.0/3.0))
            else:
                friction_x = 0.0
            
            # Advection terms
            if h[i, j+1] > min_depth and h[i, j-1] > min_depth:
                duudx = ((qx[i, j+1]/h[i, j+1])**2 - (qx[i, j-1]/h[i, j-1])**2) / (2 * dx)
            else:
                duudx = 0.0
                
            if h[i+1, j] > min_depth and h[i-1, j] > min_depth:
                duvdy = ((qx[i+1, j]*qy[i+1, j]/h[i+1, j]) - (qx[i-1, j]*qy[i-1, j]/h[i-1, j])) / (2 * dy)
            else:
                duvdy = 0.0
            
            qx_new[i, j] = qx[i, j] - dt * (h[i, j] * duudx + h[i, j] * duvdy + pressure_grad_x + friction_x)
            
            # Y-momentum equation
            # ∂qy/∂t + ∂(qxqy/h)/∂x + ∂(qy²/h + gh²/2)/∂y = -gh∂z/∂y - gn²qy√(qx²+qy²)/h^(4/3)
            
            # Pressure gradient term
            dh_dy = (h[i+1, j] - h[i-1, j]) / (2 * dy)
            dz_dy = (dem[i+1, j] - dem[i-1, j]) / (2 * dy)
            pressure_grad_y = g * h[i, j] * (dh_dy + dz_dy)
            
            # Friction term
            if velocity_mag > 1e-6:
                friction_y = g * manning[i, j]**2 * qy[i, j] * velocity_mag / (h[i, j]**(4.0/3.0))
            else:
                friction_y = 0.0
            
            # Advection terms
            if h[i, j+1] > min_depth and h[i, j-1] > min_depth:
                duvdx = ((qx[i, j+1]*qy[i, j+1]/h[i, j+1]) - (qx[i, j-1]*qy[i, j-1]/h[i, j-1])) / (2 * dx)
            else:
                duvdx = 0.0
                
            if h[i+1, j] > min_depth and h[i-1, j] > min_depth:
                dvvdy = ((qy[i+1, j]/h[i+1, j])**2 - (qy[i-1, j]/h[i-1, j])**2) / (2 * dy)
            else:
                dvvdy = 0.0
            
            qy_new[i, j] = qy[i, j] - dt * (h[i, j] * duvdx + h[i, j] * dvvdy + pressure_grad_y + friction_y)
    
    return h_new, qx_new, qy_new

@njit
def calculate_cfl_timestep_numba(h, qx, qy, dx, dy, cfl, min_depth, g):
    """
    Numba-optimized CFL timestep calculation.
    """
    max_speed = 0.0
    rows, cols = h.shape
    
    for i in prange(rows):
        for j in prange(cols):
            if h[i, j] > min_depth:
                # Calculate velocities
                u = qx[i, j] / h[i, j]
                v = qy[i, j] / h[i, j]
                
                # Wave celerity
                c = math.sqrt(g * h[i, j])
                
                # Maximum characteristic speed
                speed_x = abs(u) + c
                speed_y = abs(v) + c
                
                max_speed = max(max_speed, max(speed_x/dx, speed_y/dy))
    
    if max_speed > 1e-6:
        return cfl / max_speed
    else:
        return 1.0  # Default timestep when no flow

@njit  
def apply_boundary_conditions_numba(h, qx, qy, shape):
    """
    Apply boundary conditions with numba optimization.
    """
    rows, cols = shape
    
    # Zero gradient boundary conditions
    for i in prange(rows):
        # Left and right boundaries
        h[i, 0] = h[i, 1]
        h[i, cols-1] = h[i, cols-2]
        qx[i, 0] = qx[i, 1]
        qx[i, cols-1] = qx[i, cols-2]
        qy[i, 0] = qy[i, 1]
        qy[i, cols-1] = qy[i, cols-2]
    
    for j in prange(cols):
        # Top and bottom boundaries
        h[0, j] = h[1, j]
        h[rows-1, j] = h[rows-2, j]
        qx[0, j] = qx[1, j]
        qx[rows-1, j] = qx[rows-2, j]
        qy[0, j] = qy[1, j]
        qy[rows-1, j] = qy[rows-2, j]
