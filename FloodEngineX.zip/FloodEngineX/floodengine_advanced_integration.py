# -*- coding: utf-8 -*-
"""
FloodEngine Advanced Integration Module
Integrates sophisticated hydraulic modeling with QGIS interface
"""

import os
import numpy as np
import time
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass

from qgis.core import (
    QgsProject, QgsVectorLayer, QgsRasterLayer, QgsField, QgsFeature, 
    QgsGeometry, QgsPointXY, QgsWkbTypes, QgsVectorFileWriter,
    QgsCoordinateReferenceSystem, QgsFields, QgsRasterFileWriter,
    QgsLayerTreeGroup, QgsMessageLog, QgsTask, QgsApplication
)
from qgis.PyQt.QtCore import QVariant, pyqtSignal, QObject
from osgeo import gdal, osr, ogr

# Import our advanced hydraulic engine
from .advanced_hydraulic_engine import (
    AdvancedHydraulicEngine, HydraulicParameters, BoundaryCondition,
    ModelComplexity, HydraulicStructures
)


@dataclass
class FloodAnalysisConfig:
    """Configuration for flood analysis"""
    complexity: ModelComplexity = ModelComplexity.KINEMATIC
    simulation_time: float = 3600  # seconds
    output_interval: float = 300   # seconds
    manning_n: float = 0.035
    use_structures: bool = False
    export_velocity: bool = True
    export_depth: bool = True
    export_timeseries: bool = False


class AdvancedFloodTask(QgsTask):
    """Background task for running advanced flood simulations"""
    
    def __init__(self, description: str, engine: AdvancedHydraulicEngine, config: FloodAnalysisConfig):
        super().__init__(description)
        self.engine = engine
        self.config = config
        self.results = None
        self.exception = None
    
    def run(self):
        """Run the simulation in background"""
        try:
            # Determine solution method based on complexity
            method_map = {
                ModelComplexity.SIMPLE: "explicit",
                ModelComplexity.KINEMATIC: "explicit", 
                ModelComplexity.DIFFUSIVE: "semi_implicit",
                ModelComplexity.DYNAMIC: "semi_implicit"
            }
            
            method = method_map.get(self.config.complexity, "semi_implicit")
            
            # Run simulation
            self.results = self.engine.run_simulation(
                total_time=self.config.simulation_time,
                output_interval=self.config.output_interval,
                method=method
            )
            
            return True
            
        except Exception as e:
            self.exception = e
            return False


class AdvancedFloodEngine:
    """
    Advanced flood modeling engine for QGIS integration
    Provides sophisticated hydraulic modeling capabilities
    """
    
    def __init__(self, iface):
        self.iface = iface
        self.engine = None
        self.last_results = None
        
    def calculate_advanced_flood(self, dem_path: str, water_level: float = None, 
                               flow_q: float = None, boundary_conditions: List = None,
                               output_folder: str = None, config: FloodAnalysisConfig = None) -> Dict:
        """
        Advanced flood calculation with full hydraulic modeling
        
        Args:
            dem_path: Path to DEM file
            water_level: Water level for static analysis (m)
            flow_q: Flow discharge for dynamic analysis (m³/s)
            boundary_conditions: List of boundary conditions
            output_folder: Output directory
            config: Analysis configuration
            
        Returns:
            Dictionary with results and output paths
        """
        
        if config is None:
            config = FloodAnalysisConfig()
            
        if output_folder is None:
            output_folder = os.path.dirname(dem_path)
            
        print(f"🌊 Starting advanced flood analysis")
        print(f"   Complexity: {config.complexity.value}")
        print(f"   Simulation time: {config.simulation_time/3600:.1f} hours")
        
        # Load and prepare DEM
        dem_ds = gdal.Open(dem_path)
        if not dem_ds:
            raise Exception(f"Cannot open DEM file: {dem_path}")
            
        dem_array = dem_ds.GetRasterBand(1).ReadAsArray().astype(np.float64)
        geotransform = dem_ds.GetGeoTransform()
        projection = dem_ds.GetProjection()
        
        # Calculate grid spacing
        dx = abs(geotransform[1])
        dy = abs(geotransform[5])
        
        # Handle NoData
        nodata = dem_ds.GetRasterBand(1).GetNoDataValue()
        if nodata is not None:
            dem_array[dem_array == nodata] = np.nan
            
        # Create hydraulic parameters
        params = HydraulicParameters(
            manning_n=config.manning_n,
            cfl_number=0.3 if config.complexity == ModelComplexity.DYNAMIC else 0.5,
            max_iterations=50 if config.complexity == ModelComplexity.DYNAMIC else 20
        )
        
        # Create engine
        self.engine = AdvancedHydraulicEngine(dem_array, dx, dy, params)
        
        # Set initial conditions
        if water_level is not None:
            # Static water level analysis
            initial_depth = np.maximum(water_level - dem_array, 0.0)
            initial_depth[np.isnan(dem_array)] = 0.0
            self.engine.set_initial_conditions(initial_depth)
            
        elif flow_q is not None:
            # Dynamic flow analysis - start dry and add inflow
            initial_depth = np.zeros_like(dem_array)
            self.engine.set_initial_conditions(initial_depth)
            
            # Add inflow boundary condition
            # Find suitable inflow location (high elevation)
            valid_mask = ~np.isnan(dem_array)
            high_elevation_threshold = np.percentile(dem_array[valid_mask], 90)
            high_points = np.where((dem_array >= high_elevation_threshold) & valid_mask)
            
            if len(high_points[0]) > 0:
                # Choose a point near the edge for inflow
                inflow_i = high_points[0][0]
                inflow_j = min(10, high_points[1][0])  # Near left edge
                
                # Calculate inflow velocity based on flow and estimated width
                channel_width = max(dx * 5, 10.0)  # Minimum 10m width
                inflow_depth = max(1.0, flow_q / (channel_width * 2.0))  # Rough estimate
                inflow_velocity = flow_q / (channel_width * inflow_depth)
                
                inflow_bc = BoundaryCondition(
                    location=(inflow_i, inflow_j),
                    bc_type="inflow",
                    values=np.array([inflow_depth, inflow_velocity]),
                    times=np.array([0.0])
                )
                self.engine.add_boundary_condition(inflow_bc)
                
                print(f"   Added inflow: Q={flow_q:.1f} m³/s at location ({inflow_i}, {inflow_j})")
                print(f"   Estimated depth: {inflow_depth:.2f}m, velocity: {inflow_velocity:.2f}m/s")
        
        # Add custom boundary conditions
        if boundary_conditions:
            for bc in boundary_conditions:
                self.engine.add_boundary_condition(bc)
        
        # Run simulation
        if config.complexity == ModelComplexity.SIMPLE:
            # Simple flood fill for comparison
            results = self._run_simple_flood_fill(water_level or 10.0)
        else:
            # Advanced hydraulic simulation
            task = AdvancedFloodTask("Advanced Flood Simulation", self.engine, config)
            
            # Run task (could be made asynchronous in QGIS)
            success = task.run()
            
            if not success:
                raise Exception(f"Simulation failed: {task.exception}")
                
            results = task.results
        
        # Store results
        self.last_results = results
        
        # Export results to QGIS
        output_paths = self._export_results_to_qgis(
            results, dem_path, output_folder, geotransform, projection, config
        )
        
        return {
            'success': True,
            'results': results,
            'output_paths': output_paths,
            'config': config
        }
    
    def _run_simple_flood_fill(self, water_level: float) -> Dict:
        """Simple flood fill for comparison"""
        # Use the original algorithm from your code
        valid_mask = ~np.isnan(self.engine.dem)
        flood_mask = valid_mask & (self.engine.dem < water_level)
        
        final_depth = np.where(flood_mask, water_level - self.engine.dem, 0.0)
        
        return {
            'times': [0.0],
            'depths': [final_depth],
            'velocities_x': [np.zeros_like(final_depth)],
            'velocities_y': [np.zeros_like(final_depth)],
            'water_surface': [self.engine.dem + final_depth],
            'mass_balance': [np.sum(final_depth) * self.engine.dx * self.engine.dy],
            'max_velocities': [0.0],
            'simulation_info': {
                'method': 'simple_flood_fill',
                'total_steps': 1,
                'computation_time': 0.1
            }
        }
    
    def _export_results_to_qgis(self, results: Dict, dem_path: str, output_folder: str,
                               geotransform: Tuple, projection: str, config: FloodAnalysisConfig) -> Dict:
        """Export simulation results to QGIS layers"""
        
        output_paths = {}
        
        # Get final time step results
        final_depth = results['depths'][-1]
        final_velocity_x = results['velocities_x'][-1]
        final_velocity_y = results['velocities_y'][-1]
        final_water_surface = results['water_surface'][-1]
        
        # Calculate derived quantities
        velocity_magnitude = np.sqrt(final_velocity_x**2 + final_velocity_y**2)
        flood_mask = final_depth > 0.001  # 1mm threshold
        
        # 1. Export final flood depth raster
        if config.export_depth:
            depth_path = os.path.join(output_folder, "flood_depth_advanced.tif")
            self._export_raster(final_depth, depth_path, geotransform, projection)
            
            depth_layer = QgsRasterLayer(depth_path, "Flood Depth (Advanced)")
            if depth_layer.isValid():
                QgsProject.instance().addMapLayer(depth_layer)
                output_paths['depth_raster'] = depth_path
        
        # 2. Export velocity magnitude raster
        if config.export_velocity:
            velocity_path = os.path.join(output_folder, "flood_velocity_advanced.tif")
            self._export_raster(velocity_magnitude, velocity_path, geotransform, projection)
            
            velocity_layer = QgsRasterLayer(velocity_path, "Flood Velocity (Advanced)")
            if velocity_layer.isValid():
                QgsProject.instance().addMapLayer(velocity_layer)
                output_paths['velocity_raster'] = velocity_path
        
        # 3. Export flood extent polygon
        extent_path = os.path.join(output_folder, "flood_extent_advanced.shp")
        self._export_flood_polygon(flood_mask, final_depth, extent_path, geotransform, projection, results)
        
        extent_layer = QgsVectorLayer(extent_path, "Flood Extent (Advanced)", "ogr")
        if extent_layer.isValid():
            # Style the flood extent
            self._style_flood_extent(extent_layer)
            QgsProject.instance().addMapLayer(extent_layer)
            output_paths['extent_polygon'] = extent_path
        
        # 4. Export time series if requested
        if config.export_timeseries and len(results['times']) > 1:
            timeseries_folder = os.path.join(output_folder, "timeseries_advanced")
            os.makedirs(timeseries_folder, exist_ok=True)
            
            self._export_timeseries(results, timeseries_folder, geotransform, projection)
            output_paths['timeseries_folder'] = timeseries_folder
        
        # 5. Create summary report
        report_path = os.path.join(output_folder, "flood_analysis_report.html")
        self._create_analysis_report(results, config, report_path)
        output_paths['report'] = report_path
        
        print(f"✅ Results exported to QGIS")
        print(f"   Output folder: {output_folder}")
        
        return output_paths
    
    def _export_raster(self, data: np.ndarray, output_path: str, 
                      geotransform: Tuple, projection: str):
        """Export numpy array as GeoTIFF"""
        driver = gdal.GetDriverByName('GTiff')
        rows, cols = data.shape
        
        # Create dataset
        dataset = driver.Create(output_path, cols, rows, 1, gdal.GDT_Float32)
        dataset.SetGeoTransform(geotransform)
        dataset.SetProjection(projection)
        
        # Write data
        band = dataset.GetRasterBand(1)
        # PATCH: Set all dry/non-flooded cells to np.nan for proper transparency/clipping
        # This ensures that areas with no water (value == 0) are rendered as transparent
        data_output = data.copy()
        data_output[data_output == 0] = np.nan
        band.WriteArray(data_output.astype(np.float32))
        band.SetNoDataValue(-9999)
        band.FlushCache()
        
        dataset = None
    
    def _export_flood_polygon(self, flood_mask: np.ndarray, depth_array: np.ndarray,
                             output_path: str, geotransform: Tuple, projection: str, results: Dict):
        """Export flood extent as polygon shapefile"""
        
        # Create memory raster for polygonization
        mem_driver = gdal.GetDriverByName('MEM')
        rows, cols = flood_mask.shape
        mem_ds = mem_driver.Create('', cols, rows, 1, gdal.GDT_Byte)
        mem_ds.SetGeoTransform(geotransform)
        mem_ds.SetProjection(projection)
        
        # Write flood mask
        band = mem_ds.GetRasterBand(1)
        band.WriteArray(flood_mask.astype(np.uint8))
        band.SetNoDataValue(0)
        band.FlushCache()
        
        # Create shapefile
        shp_driver = ogr.GetDriverByName('ESRI Shapefile')
        if os.path.exists(output_path):
            shp_driver.DeleteDataSource(output_path)
            
        shp_ds = shp_driver.CreateDataSource(output_path)
        
        # Create spatial reference
        srs = osr.SpatialReference()
        srs.ImportFromWkt(projection)
        
        # Create layer
        layer = shp_ds.CreateLayer('flood_extent', srs, ogr.wkbPolygon)
        
        # Add fields
        layer.CreateField(ogr.FieldDefn('depth_avg', ogr.OFTReal))
        layer.CreateField(ogr.FieldDefn('depth_max', ogr.OFTReal))
        layer.CreateField(ogr.FieldDefn('area_m2', ogr.OFTReal))
        layer.CreateField(ogr.FieldDefn('volume_m3', ogr.OFTReal))
        layer.CreateField(ogr.FieldDefn('model_type', ogr.OFTString))
        
        # Polygonize
        gdal.Polygonize(band, band, layer, 0, [], callback=None)
        
        # Add attributes
        pixel_area = abs(geotransform[1] * geotransform[5])
        
        for feature in layer:
            if feature.GetField(0) == 1:  # Flooded area
                # Calculate statistics
                geom = feature.GetGeometryRef()
                area = geom.GetArea()
                
                # Get depth statistics for this polygon (simplified)
                avg_depth = np.mean(depth_array[flood_mask])
                max_depth = np.max(depth_array[flood_mask])
                volume = np.sum(depth_array[flood_mask]) * pixel_area
                
                feature.SetField('depth_avg', float(avg_depth))
                feature.SetField('depth_max', float(max_depth))
                feature.SetField('area_m2', float(area))
                feature.SetField('volume_m3', float(volume))
                feature.SetField('model_type', results['simulation_info']['method'])
                
                layer.SetFeature(feature)
        
        # Cleanup
        shp_ds = None
        mem_ds = None
    
    def _style_flood_extent(self, layer: QgsVectorLayer):
        """Apply styling to flood extent layer"""
        from qgis.core import QgsSingleSymbolRenderer, QgsFillSymbol
        
        # Create blue semi-transparent fill
        symbol = QgsFillSymbol.createSimple({
            'color': '30,144,255,100',  # Blue with transparency
            'outline_color': '0,0,139,255',  # Dark blue outline
            'outline_width': '0.5'
        })
        
        renderer = QgsSingleSymbolRenderer(symbol)
        layer.setRenderer(renderer)
        layer.triggerRepaint()
    
    def _export_timeseries(self, results: Dict, output_folder: str,
                          geotransform: Tuple, projection: str):
        """Export time series results"""
        
        for i, (time_val, depth, vel_x, vel_y) in enumerate(zip(
            results['times'], results['depths'], 
            results['velocities_x'], results['velocities_y']
        )):
            
            # Export depth
            depth_path = os.path.join(output_folder, f"depth_{i:03d}_{time_val:.0f}s.tif")
            self._export_raster(depth, depth_path, geotransform, projection)
            
            # Export velocity magnitude
            vel_mag = np.sqrt(vel_x**2 + vel_y**2)
            vel_path = os.path.join(output_folder, f"velocity_{i:03d}_{time_val:.0f}s.tif")
            self._export_raster(vel_mag, vel_path, geotransform, projection)
    
    def _create_analysis_report(self, results: Dict, config: FloodAnalysisConfig, output_path: str):
        """Create HTML analysis report"""
        
        sim_info = results['simulation_info']
        final_mass = results['mass_balance'][-1]
        max_velocity = max(results['max_velocities'])
        
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>FloodEngine Advanced Analysis Report</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .header {{ background-color: #2E86AB; color: white; padding: 10px; }}
                .section {{ margin: 20px 0; }}
                .metric {{ background-color: #f5f5f5; padding: 10px; margin: 5px 0; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>🌊 FloodEngine Advanced Analysis Report</h1>
                <p>Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}</p>
            </div>
            
            <div class="section">
                <h2>Simulation Parameters</h2>
                <div class="metric">Model Complexity: {config.complexity.value}</div>
                <div class="metric">Simulation Time: {config.simulation_time/3600:.1f} hours</div>
                <div class="metric">Manning's n: {config.manning_n}</div>
                <div class="metric">Solution Method: {sim_info['method']}</div>
            </div>
            
            <div class="section">
                <h2>Computational Performance</h2>
                <div class="metric">Total Time Steps: {sim_info['total_steps']}</div>
                <div class="metric">Computation Time: {sim_info['computation_time']:.2f} seconds</div>
                <div class="metric">Grid Size: {sim_info['grid_size'][0]} × {sim_info['grid_size'][1]}</div>
                <div class="metric">Grid Resolution: {sim_info['dx']:.1f}m × {sim_info['dy']:.1f}m</div>
            </div>
            
            <div class="section">
                <h2>Hydraulic Results</h2>
                <div class="metric">Final Water Volume: {final_mass:.0f} m³</div>
                <div class="metric">Maximum Velocity: {max_velocity:.2f} m/s</div>
                <div class="metric">Output Time Steps: {len(results['times'])}</div>
            </div>
            
            <div class="section">
                <h2>Mass Balance</h2>
                <div class="metric">Initial Mass: {results['mass_balance'][0]:.0f} m³</div>
                <div class="metric">Final Mass: {results['mass_balance'][-1]:.0f} m³</div>
                <div class="metric">Mass Change: {((results['mass_balance'][-1]/results['mass_balance'][0])-1)*100:.2f}%</div>
            </div>
        </body>
        </html>
        """
        
        with open(output_path, 'w') as f:
            f.write(html_content)


# Integration function to add to your existing model_hydraulic.py
def calculate_flood_area_ADVANCED(iface, dem_path, water_level=None, flow_q=None, 
                                 boundary_conditions=None, output_folder=None, 
                                 complexity=ModelComplexity.KINEMATIC, **kwargs):
    """
    Advanced flood calculation function that integrates with existing FloodEngine
    
    This function can be called from your existing UI to provide advanced modeling
    """
    
    # Create configuration
    config = FloodAnalysisConfig(
        complexity=complexity,
        simulation_time=kwargs.get('simulation_time', 3600),
        output_interval=kwargs.get('output_interval', 300),
        manning_n=kwargs.get('manning_n', 0.035),
        export_velocity=kwargs.get('export_velocity', True),
        export_depth=kwargs.get('export_depth', True),
        export_timeseries=kwargs.get('export_timeseries', False)
    )
    
    # Create advanced engine
    advanced_engine = AdvancedFloodEngine(iface)
    
    # Run analysis
    try:
        result = advanced_engine.calculate_advanced_flood(
            dem_path=dem_path,
            water_level=water_level,
            flow_q=flow_q,
            boundary_conditions=boundary_conditions,
            output_folder=output_folder,
            config=config
        )
        
        if result['success']:
            iface.messageBar().pushSuccess(
                "FloodEngine Advanced", 
                f"Advanced flood analysis completed! Method: {config.complexity.value}"
            )
            
            # Return a layer compatible with existing code
            if 'extent_polygon' in result['output_paths']:
                return QgsVectorLayer(result['output_paths']['extent_polygon'], 
                                    f"Advanced Flood ({config.complexity.value})", "ogr")
        else:
            iface.messageBar().pushCritical("FloodEngine Advanced", "Analysis failed!")
            return None
            
    except Exception as e:
        iface.messageBar().pushCritical("FloodEngine Advanced", f"Error: {str(e)}")
        print(f"Advanced flood analysis error: {str(e)}")
        return None

def add_unique_hillshade(hillshade_path):
    try:
        from qgis.core import QgsProject, QgsRasterLayer
        # Remove old hillshade layers
        for layer in QgsProject.instance().mapLayersByName("Hillshade"):
            QgsProject.instance().removeMapLayer(layer)
        # Add the new hillshade
        hillshade = QgsRasterLayer(hillshade_path, "Hillshade")
        if hillshade.isValid():
            QgsProject.instance().addMapLayer(hillshade)
    except Exception as e:
        print(f"⚠️ Failed to add unique hillshade: {e}")
