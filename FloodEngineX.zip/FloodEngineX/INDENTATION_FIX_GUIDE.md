# Fixing Indentation Issues in QGIS Plugins

This guide provides instructions on how to fix indentation issues in QGIS plugins, which are a common source of errors when loading plugins.

## Understanding the Problem

The error message you received:
```
IndentationError: unexpected indent 
```

This happens when Python code has inconsistent indentation, which Python cannot parse correctly since indentation defines code blocks in Python.

## How the Problem Was Fixed

The indentation issues in the FloodEngine plugin were fixed using the following steps:

1. We identified the problematic files by analyzing the error message
2. We normalized the indentation in those files using a Python script
3. We verified that the indentation issues were fixed by checking the tokenization

## Files That Were Fixed

The main files that had indentation issues were:
- `floodengine_ui.py` - This had inconsistent indentation around line 148
- We also checked other key files to ensure they had no indentation issues

## How to Fix These Issues Yourself

If you encounter similar issues in other plugins, follow these steps:

### Manual Fix

1. Open the file mentioned in the error message
2. Look for the line mentioned in the error
3. Check for inconsistent indentation compared to surrounding lines
4. Fix the indentation to match the expected level (usually 4 spaces per level)
5. Save the file and test the plugin again

### Automated Fix Using the Provided Scripts

We've included several scripts to help diagnose and fix indentation issues:

#### Check Indentation
```python
python check_final_indentation.py
```
This will check for indentation issues in key files without changing them.

#### Fix Indentation
```python
python fix_ui_indentation.py
```
This will create a normalized version of the file that you can use to replace the original.

#### Verify Plugin Compatibility
```python
python verify_qgis_compatibility.py
```
This performs a comprehensive check of the plugin for QGIS compatibility.

## Tips for Preventing Indentation Issues

1. Use a consistent number of spaces for indentation (4 spaces is standard)
2. Use a code editor that highlights indentation issues
3. Configure your editor to use spaces instead of tabs
4. Use an automatic code formatter like Black or YAPF

## Key Points to Remember

- Python uses indentation to define code blocks
- Mixing tabs and spaces can cause indentation errors
- Indentation must be consistent throughout the file
- Each level of indentation should use the same number of spaces

By following these guidelines, you can avoid indentation issues in your QGIS plugins and ensure they load correctly.
