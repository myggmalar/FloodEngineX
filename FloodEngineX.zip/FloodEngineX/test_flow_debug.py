"""
Test script to verify water flow from highest points with debug logging
"""

import os
import sys
import numpy as np
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

try:
    # Import the model
    from saint_venant_2d import SaintVenant2D
    
    # Create a test DEM with a river channel and dam
    print("\nCreating test DEM...")
    dem_size = 30
    dem = np.ones((dem_size, dem_size)) * 100.0  # Base elevation
    
    # Create a channel with varying elevation (higher at top)
    channel_width = 3
    channel_center = dem_size // 2
    
    print("Adding river channel...")
    for i in range(dem_size):
        # Calculate elevation (decreasing from top to bottom)
        channel_elevation = 98.0 - (i / dem_size) * 4.0
        for j in range(channel_center - channel_width, channel_center + channel_width + 1):
            dem[i, j] = channel_elevation
    
    # Add a dam
    dam_row = dem_size * 3 // 4  # Dam at 3/4 down the channel
    dam_height = 2.0
    print(f"Adding dam at row {dam_row} with height {dam_height}m...")
    
    for j in range(channel_center - channel_width - 1, channel_center + channel_width + 2):
        dem[dam_row, j] = dem[dam_row, j] + dam_height
    
    # Create basin behind dam
    print("Creating basin behind dam...")
    basin_depth = 1.0
    for i in range(dam_row - 5, dam_row):
        for j in range(channel_center - channel_width, channel_center + channel_width + 1):
            # Deepen the area behind the dam
            dem[i, j] = min(dem[i, j], dem[dam_row, j] - basin_depth)
    
    # Print DEM statistics
    print(f"\nDEM Statistics:")
    print(f"Size: {dem.shape}")
    print(f"Elevation range: {np.min(dem):.1f}m to {np.max(dem):.1f}m")
    print(f"Channel start elevation: {dem[0, channel_center]:.1f}m")
    print(f"Dam elevation: {dem[dam_row, channel_center]:.1f}m")
    print(f"Channel end elevation: {dem[-1, channel_center]:.1f}m")
    
    # Create and initialize model
    print("\nInitializing model...")
    geotransform = (0, 10, 0, 0, 0, -10)  # 10m cell size
    model = SaintVenant2D(dem, geotransform)
    
    # Set initial water level slightly above the highest channel point
    initial_water_level = dem[0, channel_center] + 0.2
    print(f"Setting initial water level to {initial_water_level:.1f}m")
    
    model.set_initial_condition(water_level=initial_water_level)
    
    # Run simulation steps
    print("\nRunning simulation...")
    total_steps = 20
    
    for step in range(total_steps):
        print(f"\nStep {step + 1}/{total_steps}")
        
        # Calculate timestep
        dt = model.calculate_timestep()
        print(f"Calculated timestep: {dt:.3f}s")
        
        # Run step
        actual_dt = model.step(dt)
        
        # Get results
        water_surface = model.get_water_surface()
        water_depth = np.maximum(water_surface - dem, 0)
        
        # Check conditions around dam
        upstream_depths = water_depth[dam_row-3:dam_row, channel_center-channel_width:channel_center+channel_width+1]
        downstream_depths = water_depth[dam_row+1:dam_row+4, channel_center-channel_width:channel_center+channel_width+1]
        
        print(f"Water depths:")
        print(f"  Max depth: {np.max(water_depth):.2f}m")
        print(f"  Upstream avg: {np.mean(upstream_depths):.2f}m")
        print(f"  Downstream avg: {np.mean(downstream_depths):.2f}m")
        
        # Add some water at the source (top of channel)
        inflow_rate = 2.0  # m³/s
        cell_area = 100.0  # 10m x 10m cells
        source_addition = (inflow_rate / cell_area) * actual_dt
        model.h[0, channel_center] += source_addition
        
    # Final analysis
    print("\nFinal Results:")
    upstream_avg = np.mean(water_depth[dam_row-5:dam_row, channel_center-channel_width:channel_center+channel_width+1])
    downstream_avg = np.mean(water_depth[dam_row+1:dam_row+6, channel_center-channel_width:channel_center+channel_width+1])
    
    print(f"Final upstream average depth: {upstream_avg:.2f}m")
    print(f"Final downstream average depth: {downstream_avg:.2f}m")
    
    # Check dam overflow
    dam_top = dem[dam_row, channel_center]
    water_at_dam = water_surface[dam_row, channel_center]
    if water_at_dam > dam_top:
        print(f"Dam is overtopped by {water_at_dam - dam_top:.2f}m of water")
    else:
        print(f"Water level is {dam_top - water_at_dam:.2f}m below dam top")
    
    # Success criteria
    if upstream_avg > downstream_avg * 1.5:
        print("\nSUCCESS: Water properly accumulated behind dam")
        print(f"Upstream depth is {upstream_avg/downstream_avg:.1f}x greater than downstream")
    else:
        print("\nISSUE: Water did not properly accumulate behind dam")
    
    print("\nTest completed successfully!")

except Exception as e:
    print(f"\nError occurred: {str(e)}")
    import traceback
    traceback.print_exc()
