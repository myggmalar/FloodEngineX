#!/usr/bin/env python3
"""
Test script to verify the fixes for DEM coloring and timestep variation issues.
"""

import sys
import os
import numpy as np

def test_variable_water_levels():
    """Test the water level generation function"""
    print("🧪 Testing Variable Water Level Generation")
    print("=" * 50)
    
    try:
        # Import the function
        sys.path.append(os.path.dirname(__file__))
        from model_hydraulic import generate_variable_water_levels
        
        # Test different methods
        methods = ['linear', 'exponential', 'accumulation']
        
        for method in methods:
            print(f"\n📊 Testing method: {method}")
            
            water_levels = generate_variable_water_levels(
                initial_level=10.0,
                time_steps=5,
                flow_q=100.0,
                method=method
            )
            
            print(f"   Generated levels: {[f'{level:.2f}' for level in water_levels]}")
            
            # Check variation
            if len(set(water_levels)) > 1:
                variation = max(water_levels) - min(water_levels)
                print(f"   ✅ Water levels vary properly: {variation:.2f}m range")
            else:
                print(f"   ❌ Water levels are constant: {water_levels[0]:.2f}m")
        
        return True
        
    except Exception as e:
        print(f"❌ Error testing water levels: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_simulate_over_time_signature():
    """Test that simulate_over_time function has the correct signature"""
    print("\n🔧 Testing simulate_over_time Function Signature")
    print("=" * 50)
    
    try:
        # Import the function
        from model_hydraulic import simulate_over_time
        import inspect
        
        # Get function signature
        sig = inspect.signature(simulate_over_time)
        params = list(sig.parameters.keys())
        
        print(f"Function parameters: {params}")
        
        # Check for expected parameters
        expected_params = ['iface', 'dem_path', 'water_levels', 'time_steps', 'output_folder']
        
        missing_params = []
        for param in expected_params:
            if param not in params:
                missing_params.append(param)
        
        if missing_params:
            print(f"❌ Missing expected parameters: {missing_params}")
            return False
        else:
            print("✅ Function signature is correct")
            return True
            
    except Exception as e:
        print(f"❌ Error testing function signature: {e}")
        return False

def test_dem_coloring_logic():
    """Test the DEM coloring logic without QGIS dependencies"""
    print("\n🎨 Testing DEM Coloring Logic")
    print("=" * 50)
    
    try:
        # Simulate different elevation scenarios
        scenarios = [
            {"name": "Mixed terrain", "min_val": -10.0, "max_val": 100.0},
            {"name": "All above sea level", "min_val": 5.0, "max_val": 500.0},
            {"name": "All underwater", "min_val": -50.0, "max_val": -2.0},
        ]
        
        for scenario in scenarios:
            print(f"\n📍 Scenario: {scenario['name']}")
            min_val = scenario['min_val']
            max_val = scenario['max_val']
            sea_level = 0.0
            
            # Apply the same logic as in the fix
            if min_val < sea_level < max_val:
                land_start = sea_level + 0.1
                print(f"   Mixed terrain: Land starts at {land_start:.1f}m")
            elif min_val >= sea_level:
                land_start = min_val + 0.1
                print(f"   All above sea level: Land starts at {land_start:.1f}m")
            else:
                land_start = min_val + (max_val - min_val) * 0.8
                print(f"   All underwater: Land boundary at {land_start:.1f}m")
            
            # Calculate color distribution
            water_range = land_start - min_val
            land_range = max_val - land_start
            
            print(f"   Water range: {water_range:.1f}m ({min_val:.1f} to {land_start:.1f})")
            print(f"   Land range: {land_range:.1f}m ({land_start:.1f} to {max_val:.1f})")
            
            # Check if distribution makes sense
            if water_range > 0 and land_range > 0:
                print("   ✅ Good color distribution")
            elif water_range <= 0:
                print("   ⚠️ No water colors (all land)")
            elif land_range <= 0:
                print("   ⚠️ No land colors (all water)")
        
        return True
        
    except Exception as e:
        print(f"❌ Error testing DEM coloring: {e}")
        return False

def main():
    """Run all tests"""
    print("🚀 Testing FloodEngine Fixes")
    print("=" * 60)
    
    tests = [
        test_variable_water_levels,
        test_simulate_over_time_signature,
        test_dem_coloring_logic
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        if test():
            passed += 1
    
    print(f"\n📋 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All fixes appear to be working correctly!")
        print("\nNext steps:")
        print("1. Test in QGIS environment with real DEM data")
        print("2. Verify DEM coloring shows proper earth tones")
        print("3. Confirm timestep simulations show progressive flooding")
    else:
        print("⚠️ Some tests failed - review the issues above")
    
    return passed == total

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
