#!/usr/bin/env python3
"""
Basic Test: Check if we can import the module
"""

print("Starting basic import test...")

try:
    import sys
    import os
    import numpy as np
    print("Basic imports successful")
    
    # Try importing our module
    from model_hydraulic import create_proper_flow_flood_mask
    print("Successfully imported create_proper_flow_flood_mask")
    
    # Create minimal test data
    dem_array = np.array([[1, 2], [3, 4]], dtype=np.float32)
    water_level = 2.5
    
    print(f"Test DEM shape: {dem_array.shape}")
    print(f"Test water level: {water_level}")
    
    # Try to call the function
    result = create_proper_flow_flood_mask(dem_array, water_level, -9999)
    print(f"Function call successful, result shape: {result.shape}")
    print(f"Flooded cells: {np.sum(result > 0)}")
    
    print("TEST PASSED!")
    
except Exception as e:
    print(f"ERROR: {e}")
    import traceback
    traceback.print_exc()
