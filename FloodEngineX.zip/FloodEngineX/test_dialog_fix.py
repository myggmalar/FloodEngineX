#!/usr/bin/env python3
"""
URGENT TEST: Animation Dialog Garbage Collection Fix
===================================================
"""

import sys
import os
sys.path.insert(0, '.')

def test_animation_dialog_fix():
    """Test the animation dialog fix immediately."""
    print("🔧 TESTING ANIMATION DIALOG FIX...")
    print("=" * 50)
    
    # Check for animation data
    output_folder = 'C:/Plugin/VSCode/output'
    animation_folder = os.path.join(output_folder, 'time_series_animation')
    
    print(f"📁 Checking: {animation_folder}")
    
    if not os.path.exists(animation_folder):
        print("❌ No animation data found")
        print("💡 Run a simulation with 'Create animation' checked first")
        return False
    
    print("✅ Animation data found!")
    
    try:
        # Import the fixed launcher
        from launch_animation import launch_animation_from_folder
        print("✅ Import successful")
        
        # Test the launch with all our fixes
        print("🚀 Launching animation dialog with fixes...")
        result = launch_animation_from_folder(output_folder, standalone=True)
        
        if result:
            print("✅ DIALOG LAUNCHED SUCCESSFULLY!")
            print(f"🔍 Dialog type: {type(result).__name__}")
            
            # Check if dialog is visible
            if hasattr(result, 'isVisible'):
                visible = result.isVisible()
                print(f"🔍 Dialog visible: {visible}")
                
                if visible:
                    print("🎉 SUCCESS! Animation dialog is visible and persistent!")
                    print("🎮 You should now see the animation controls window")
                    return True
                else:
                    print("⚠️ Dialog created but not visible")
            else:
                print("🔍 Cannot check visibility")
                
            print("✅ Dialog object created and stored - should prevent garbage collection")
            return True
        else:
            print("❌ Launch returned False/None")
            return False
            
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_animation_dialog_fix()
    if success:
        print("\n🎉 TEST PASSED - Animation dialog fix working!")
    else:
        print("\n❌ TEST FAILED - Dialog fix needs more work")
