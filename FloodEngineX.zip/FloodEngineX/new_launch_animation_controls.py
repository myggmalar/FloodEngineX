#!/usr/bin/env python3
"""
Replacement method for floodengine_ui.py launch_animation_controls
"""

def launch_animation_controls(self, output_folder):
    """Launch animation controls after simulation completion."""
    print(f"🎬 Attempting to launch animation from: {output_folder}")
    
    try:
        # Use the safe launcher that handles QGIS module reload issues
        from qgis_module_reload_helper import launch_animation_safe
        
        # Get the parent window for proper dialog management
        parent_window = None
        try:
            # Try to get QGIS main window first
            from qgis.utils import iface
            if iface and hasattr(iface, 'mainWindow') and iface.mainWindow():
                parent_window = iface.mainWindow()
                print("✅ Using QGIS main window as parent")
            else:
                # Fall back to this widget's parent
                parent_window = self.parent() if hasattr(self, 'parent') else None
                print(f"✅ Using widget parent: {type(parent_window).__name__ if parent_window else 'None'}")
        except ImportError:
            # Not in QGIS, use this widget's parent
            parent_window = self.parent() if hasattr(self, 'parent') else None
            print(f"✅ Using widget parent (no QGIS): {type(parent_window).__name__ if parent_window else 'None'}")
        
        # Launch using the safe method
        result = launch_animation_safe(output_folder, parent_window)
        
        if result:
            print("✅ Animation controls launched successfully!")
            
            # Store persistent reference in the UI to prevent garbage collection
            self._animation_dialog = result
            print("✅ Stored persistent reference to animation dialog")
            
            # Also store in dialog manager for extra persistence
            try:
                from dialog_manager import store_animation_dialog
                store_animation_dialog(result)
                print("✅ Stored in dialog manager")
            except Exception as e:
                print(f"⚠️ Could not store in dialog manager: {e}")
            
            self.show_message("Animation controls are now available!")
        else:
            print("❌ Animation launch failed")
            self.show_message("Animation launch failed - check console for details")
            
    except ImportError as e:
        print(f"❌ Cannot import animation launcher: {e}")
        self.show_message("Animation module not available")
    except Exception as e:
        print(f"❌ Unexpected animation error: {e}")
        import traceback
        traceback.print_exc()
        self.show_message(f"Animation error: {e}")
