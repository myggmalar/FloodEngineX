from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
import os
from .floodengine_ui import FloodEngineDialog

class FloodEngine:
    def __init__(self, iface):
        self.iface = iface
        self.dlg = None
        self.actions = []

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        if not os.path.exists(icon_path):
            icon_path = ':/images/themes/default/mActionAddRasterLayer.svg'
        
        self.action = QAction(QIcon(icon_path), "FloodEngine", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.action.setEnabled(True)
        self.action.setStatusTip("Open FloodEngine")
        self.action.setWhatsThis("FloodEngine 2D Saint-Venant flood simulation")

        # Add to menu and toolbar
        self.iface.addPluginToMenu("FloodEngine", self.action)
        self.iface.addToolBarIcon(self.action)
        self.actions.append(self.action)

    def unload(self):
        """Remove the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu("FloodEngine", action)
            self.iface.removeToolBarIcon(action)
        if self.dlg:
            self.dlg.close()

    def run(self):
        """Run method that performs all the real work"""
        if not self.dlg:
            self.dlg = FloodEngineDialog(self.iface)
        self.dlg.show()
        self.dlg.raise_()
        self.dlg.activateWindow()
