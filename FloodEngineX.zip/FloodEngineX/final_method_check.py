#!/usr/bin/env python3
"""
Final verification that all signal connection methods exist
"""

import sys
import os

def main():
    """Check that all signal connection methods exist"""
    ui_file = "floodengine_ui.py"
    
    if not os.path.exists(ui_file):
        print(f"❌ File {ui_file} not found")
        return False
    
    print("🔍 Final verification of FloodEngine UI signal connections...")
    
    try:
        with open(ui_file, 'r', encoding='utf-8') as f:
            code = f.read()
        
        # Check for all methods that were causing AttributeError
        required_methods = [
            'toggle_simulation_type',
            'load_csv_preview', 
            'toggle_2d_flow_controls',
            'toggle_groundwater_controls',
            'toggle_urban_controls',
            'draw_threshold_on_map',
            'run_model',
            'toggle_night_mode',
            'apply_night_mode',
            'browse_file',
            'browse_folder',
            'select_calculation_area',
            'toggle_advanced_stream_burning',
            'toggle_gpu_controls',
            'toggle_qa_controls',
            'toggle_cloud_controls',
            'toggle_viz_controls',
            'toggle_web_services_controls',
            'run_gpu_benchmark',
            'toggle_manning_zones_controls',
            'open_manning_zones_dialog'
        ]
        
        missing_methods = []
        for method in required_methods:
            if f'def {method}(' in code:
                print(f"✓ {method}")
            else:
                print(f"❌ {method} - MISSING")
                missing_methods.append(method)
        
        if missing_methods:
            print(f"\n❌ FAILED: {len(missing_methods)} methods still missing:")
            for method in missing_methods:
                print(f"  - {method}")
            return False
        
        print(f"\n🎉 SUCCESS: All {len(required_methods)} required methods found!")
        print("✓ No more AttributeError issues should occur")
        print("✓ UI consolidation fully complete")
        print("✓ All signal connections properly implemented")
        
        return True
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)
