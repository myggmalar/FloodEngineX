#!/usr/bin/env python3
"""
Test script to verify QGIS plugin reload and function signature issues.
"""

import sys
import os
import importlib

# Add the FloodEngineX directory to path
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

def test_function_signature():
    """Test the function signature directly."""
    print("=" * 60)
    print("TESTING FUNCTION SIGNATURE")
    print("=" * 60)
    
    try:
        # Force reload if already imported
        if 'launch_animation' in sys.modules:
            print("🔄 Reloading launch_animation module...")
            importlib.reload(sys.modules['launch_animation'])
        
        from launch_animation import launch_animation_from_folder
        
        # Check function signature
        import inspect
        sig = inspect.signature(launch_animation_from_folder)
        print(f"✅ Function signature: {sig}")
        
        # Test calling with and without parent
        print("\n🧪 Testing function calls:")
        
        # Create a test folder
        test_folder = os.path.join(current_dir, "test_animation_data")
        if not os.path.exists(test_folder):
            os.makedirs(test_folder)
            
        # Test with parent=None
        try:
            result = launch_animation_from_folder(test_folder, standalone=True, parent=None)
            print("✅ Call with parent=None succeeded")
        except TypeError as e:
            print(f"❌ Call with parent=None failed: {e}")
            
        # Test without parent argument
        try:
            result = launch_animation_from_folder(test_folder, standalone=True)
            print("✅ Call without parent argument succeeded")
        except TypeError as e:
            print(f"❌ Call without parent argument failed: {e}")
            
        # Clean up
        if os.path.exists(test_folder):
            os.rmdir(test_folder)
            
    except Exception as e:
        print(f"❌ Error testing function signature: {e}")
        import traceback
        traceback.print_exc()

def test_qgis_environment():
    """Test if we're in a QGIS environment."""
    print("\n" + "=" * 60)
    print("TESTING QGIS ENVIRONMENT")
    print("=" * 60)
    
    try:
        from qgis.utils import iface
        if iface:
            print("✅ QGIS interface available")
            if hasattr(iface, 'mainWindow'):
                print("✅ QGIS main window available")
            else:
                print("⚠️ QGIS main window not available")
        else:
            print("⚠️ QGIS interface is None")
    except ImportError:
        print("❌ Not in QGIS environment")
    except Exception as e:
        print(f"❌ QGIS environment error: {e}")

def test_module_reload():
    """Test module reloading capabilities."""
    print("\n" + "=" * 60)
    print("TESTING MODULE RELOAD")
    print("=" * 60)
    
    try:
        # First import
        import launch_animation
        print(f"✅ Initial import: {launch_animation.__file__}")
        
        # Reload
        importlib.reload(launch_animation)
        print("✅ Module reloaded successfully")
        
        # Check if function signature is correct after reload
        from launch_animation import launch_animation_from_folder
        import inspect
        sig = inspect.signature(launch_animation_from_folder)
        print(f"✅ Function signature after reload: {sig}")
        
    except Exception as e:
        print(f"❌ Module reload error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    print("FloodEngine QGIS Plugin Reload Test")
    print("=" * 60)
    
    test_qgis_environment()
    test_module_reload()
    test_function_signature()
    
    print("\n" + "=" * 60)
    print("TEST COMPLETE")
    print("=" * 60)
