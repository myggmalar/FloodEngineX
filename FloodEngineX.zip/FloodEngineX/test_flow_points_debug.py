#!/usr/bin/env python3
"""
Debug test for flow points generation
"""

import os
import sys
import numpy as np
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_flow_points_debug():
    """Test flow points generation with debug output"""
    
    print("=== Flow Points Debug Test ===")
    
    # Check if the enhanced_flow_points.py file exists
    flow_points_file = "enhanced_flow_points.py"
    if not os.path.exists(flow_points_file):
        print(f"❌ {flow_points_file} not found!")
        return False
    
    print(f"✅ Found {flow_points_file}")
    
    # Check key functions
    try:
        with open(flow_points_file, 'r', encoding='utf-8') as f:
            content = f.read()
            
        # Check for key improvements
        checks = [
            ("Enhanced debugging", "Output path for shapefile" in content),
            ("Directory existence check", "Output directory exists" in content),
            ("CRS validation", "CRS is valid" in content),
            ("Exception handling", "Exception creating QgsVectorFileWriter" in content),
            ("Path cleanup", "Output path is a directory" in content),
            ("DEM CRS usage", "Using DEM CRS" in content),
        ]
        
        for check_name, check_result in checks:
            if check_result:
                print(f"✅ {check_name}")
            else:
                print(f"❌ {check_name}")
    
    except Exception as e:
        print(f"❌ Error checking file: {e}")
        return False
    
    # Check if the debug improvements are in place
    debug_keywords = [
        "logger.info(f\"Output folder: {output_folder}\")",
        "logger.info(f\"Flow points output path: {output_path}\")",
        "logger.info(f\"Output directory exists:",
        "logger.info(f\"CRS is valid:",
        "logger.info(\"QgsVectorFileWriter created successfully\")",
        "Exception creating QgsVectorFileWriter",
        "shutil.rmtree(output_path)"
    ]
    
    missing_debug = []
    for keyword in debug_keywords:
        if keyword not in content:
            missing_debug.append(keyword)
    
    if missing_debug:
        print(f"❌ Missing debug statements:")
        for missing in missing_debug:
            print(f"   - {missing}")
    else:
        print("✅ All debug statements present")
    
    # Check for potential issues
    issues = []
    
    # Check for import issues
    if "import shutil" not in content:
        issues.append("Missing 'import shutil' for directory cleanup")
    
    # Check for proper path handling
    if "os.path.join(output_folder, \"enhanced_flow_points.shp\")" not in content:
        issues.append("Potential path joining issue")
    
    if issues:
        print(f"⚠️  Potential issues found:")
        for issue in issues:
            print(f"   - {issue}")
    else:
        print("✅ No obvious issues found")
    
    print("\n=== Summary ===")
    print("The enhanced_flow_points.py file has been updated with:")
    print("1. Enhanced debugging for path creation and validation")
    print("2. Directory existence and writability checks")
    print("3. CRS validation and error handling")
    print("4. Path cleanup to handle existing files/directories")
    print("5. Better exception handling for QgsVectorFileWriter")
    print("6. DEM CRS usage for proper coordinate system")
    
    print("\nNext steps:")
    print("1. Run the flow points generation in QGIS")
    print("2. Check the console output for detailed debugging information")
    print("3. Look for specific error messages about:")
    print("   - Output folder creation")
    print("   - CRS validation")
    print("   - Shapefile writer creation")
    print("   - Path conflicts")
    
    return True

if __name__ == "__main__":
    test_flow_points_debug()
