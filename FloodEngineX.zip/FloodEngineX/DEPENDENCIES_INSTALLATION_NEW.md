# FloodEngine Dependencies Installation Guide

## Overview
FloodEngine now uses QGIS/GDAL for all raster operations and no longer requires rasterio. This makes installation much easier as most dependencies are already available in QGIS.

## Required Dependencies

### Core Dependencies (Install via pip)
```bash
pip install scipy pandas geopandas shapely fiona numpy
```

### QGIS Dependencies (Already Available)
- GDAL/OGR (bundled with QGIS)
- PyQt5 (bundled with QGIS)
- NumPy (bundled with QGIS)

## Installation Steps

### Option 1: Install via requirements.txt (Recommended)
```bash
cd FloodEngineX
pip install -r requirements.txt
```

### Option 2: Install dependencies individually
```bash
pip install scipy
pip install pandas
pip install geopandas
pip install shapely
pip install fiona
pip install numpy
```

## Verifying Installation

Run this Python script in QGIS Python Console to verify all dependencies:

```python
try:
    import numpy as np
    print("✅ NumPy:", np.__version__)
except ImportError as e:
    print("❌ NumPy:", e)

try:
    import scipy
    print("✅ SciPy:", scipy.__version__)
except ImportError as e:
    print("❌ SciPy:", e)

try:
    import pandas as pd
    print("✅ Pandas:", pd.__version__)
except ImportError as e:
    print("❌ Pandas:", e)

try:
    import geopandas as gpd
    print("✅ GeoPandas:", gpd.__version__)
except ImportError as e:
    print("❌ GeoPandas:", e)

try:
    from osgeo import gdal, ogr, osr
    print("✅ GDAL:", gdal.__version__)
except ImportError as e:
    print("❌ GDAL:", e)

try:
    import shapely
    print("✅ Shapely:", shapely.__version__)
except ImportError as e:
    print("❌ Shapely:", e)

try:
    import fiona
    print("✅ Fiona:", fiona.__version__)
except ImportError as e:
    print("❌ Fiona:", e)

print("\n🎉 If all packages show ✅, FloodEngine is ready to use!")
```

## Key Changes

### Removed Dependencies
- ❌ **rasterio** - No longer required! All raster operations now use GDAL directly
- ❌ **affine** - Handled by GDAL geotransform
- ❌ **cmasher** - Not essential for core functionality

### What This Means
1. **Easier Installation**: Fewer external dependencies to manage
2. **Better QGIS Integration**: Uses native QGIS/GDAL for all raster operations
3. **More Reliable**: Less dependency conflicts
4. **Maintained Performance**: All core functionality preserved

## Troubleshooting

### Common Issues

1. **SciPy Installation Error**
   ```bash
   # Try installing with conda instead
   conda install scipy
   ```

2. **GeoPandas Installation Issues**
   ```bash
   # Install via conda for better dependency management
   conda install geopandas
   ```

3. **GDAL Import Error**
   - GDAL should be automatically available in QGIS
   - If missing, reinstall QGIS or check QGIS installation

### Platform-Specific Notes

#### Windows
- Use the OSGeo4W installer for QGIS for best GDAL support
- Consider using conda for package management

#### Linux
- GDAL usually available via system package manager
- `sudo apt-get install gdal-bin python3-gdal` (Ubuntu/Debian)

#### macOS
- Use QGIS.org installer for best results
- Homebrew can provide additional packages if needed

## Advanced Features

### Saint-Venant 2D Solver
The plugin automatically detects and uses your advanced `saint_venant_2d.py` solver if available. If not found, it falls back to a basic flood simulation that still provides:

- Dynamic water level calculation based on duration and timesteps
- Flow rate-dependent flooding patterns
- Temporal progression of flood events
- Streamline generation for flow visualization

### Performance Optimization

For large datasets, consider:
1. Using smaller DEM tiles for testing
2. Reducing the number of timesteps for initial runs
3. Increasing timestep intervals for longer simulations

## Support

If you encounter issues:
1. Check the QGIS Python Console for error messages
2. Verify QGIS installation includes GDAL
3. Run the verification script above
4. Check that the output folder has write permissions
