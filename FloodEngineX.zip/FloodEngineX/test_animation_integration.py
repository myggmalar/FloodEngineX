#!/usr/bin/env python3
"""
Test Animation Integration - Verify animation controls work
"""

import os
import sys
import tempfile
import numpy as np
from pathlib import Path

# Add current directory to path
sys.path.insert(0, str(Path(__file__).parent))

def test_animation_checkbox():
    """Test that the animation checkbox is working."""
    print("🧪 Testing Animation Checkbox Integration")
    print("=" * 50)
    
    try:
        # Test UI checkbox
        print("1. Testing UI checkbox...")
        with open('floodengine_ui.py', 'r', encoding='utf-8') as f:
            ui_content = f.read()
        
        if 'adv_create_animation' in ui_content and 'setChecked(True)' in ui_content:
            print("✅ Animation checkbox exists and is checked by default")
        else:
            print("❌ Animation checkbox issue")
            return False
        
        if 'launch_animation_controls' in ui_content:
            print("✅ Animation launch method exists in UI")
        else:
            print("❌ Animation launch method missing from UI")
            return False
            
        # Test model integration
        print("2. Testing model integration...")
        with open('model_hydraulic.py', 'r', encoding='utf-8') as f:
            model_content = f.read()
        
        if 'create_animation=False' in model_content and 'if create_animation:' in model_content:
            print("✅ Model has animation parameter and conditional logic")
        else:
            print("❌ Model missing animation integration")
            return False
            
        # Test launcher
        print("3. Testing animation launcher...")
        if os.path.exists('launch_animation.py'):
            print("✅ Animation launcher exists")
        else:
            print("❌ Animation launcher missing")
            return False
            
        print("\n✅ All animation integration tests passed!")
        return True
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        return False

def test_sample_animation():
    """Test animation with sample data."""
    print("\n🎬 Testing Sample Animation Launch")
    print("=" * 40)
    
    try:
        # Create sample data
        from launch_animation import create_sample_animation
        print("📊 Creating sample animation data...")
        results_data = create_sample_animation()
        
        # Create temporary folder
        temp_folder = tempfile.mkdtemp(prefix='test_animation_')
        print(f"📁 Using temp folder: {temp_folder}")
        
        # Set up animation
        from time_series_integration import integrate_time_series_animation
        print("🔧 Setting up animation integration...")
        animation_result = integrate_time_series_animation(results_data, temp_folder)
        
        if animation_result['success']:
            print("✅ Animation setup successful!")
            
            # Try to launch animation
            from launch_animation import launch_animation_from_folder
            print("🚀 Attempting to launch animation...")
            
            result = launch_animation_from_folder(temp_folder, standalone=True)
            if result:
                print("✅ Animation launched successfully!")
                print("🎮 Animation controls should be visible now!")
                return True
            else:
                print("❌ Animation launch failed")
                return False
        else:
            print(f"❌ Animation setup failed: {animation_result.get('error')}")
            return False
            
    except ImportError as e:
        print(f"❌ Import error: {e}")
        print("💡 Make sure PyQt5 is installed: pip install PyQt5")
        return False
    except Exception as e:
        print(f"❌ Test failed: {e}")
        return False

def main():
    """Run all tests."""
    print("🧪 FLOODENGINE ANIMATION INTEGRATION TEST")
    print("=" * 60)
    
    # Test 1: Integration
    test1_passed = test_animation_checkbox()
    
    # Test 2: Sample animation
    if test1_passed:
        test2_passed = test_sample_animation()
    else:
        test2_passed = False
        print("⏭️ Skipping sample animation test due to integration failure")
    
    print("\n" + "=" * 60)
    print("🎯 TEST SUMMARY:")
    print(f"  Integration Test: {'✅ PASS' if test1_passed else '❌ FAIL'}")
    print(f"  Animation Test:   {'✅ PASS' if test2_passed else '❌ FAIL'}")
    
    if test1_passed and test2_passed:
        print("\n🎉 ALL TESTS PASSED! Animation should work in the UI.")
        print("💡 Make sure to check the '🎬 Create time series animation' checkbox in Advanced mode!")
    else:
        print("\n❌ TESTS FAILED! Animation integration needs fixing.")
    
    return 0 if (test1_passed and test2_passed) else 1

if __name__ == "__main__":
    sys.exit(main())
