# FloodEngine 4.0+ - Implementationsplan för avancerade hydrauliska modeller

## Innehållsförteckning

1. [Introduktion och bakgrund](#introduktion-och-bakgrund)
2. [Övergripande arkitektur](#övergripande-arkitektur)
3. [Funktionsuppdelning (Gratis vs. Premium)](#funktionsuppdelning-gratis-vs-premium)
4. [Implementationsfaser](#implementationsfaser)
5. [Strategier för datahantering](#strategier-för-datahantering)
6. [Användargränssnittsdesign](#användargränssnittsdesign)
7. [Specifika modellekvationer och implementationer](#specifika-modellekvationer-och-implementationer)
8. [Optimering och prestanda](#optimering-och-prestanda)
9. [Licenshantering och aktivering](#licenshantering-och-aktivering)
10. [Testning och validering](#testning-och-validering)
11. [Dokumentation och hjälpresurser](#dokumentation-och-hjälpresurser)

## Introduktion och bakgrund

FloodEngine är ett QGIS-plugin för avancerad modellering av översvämning och erosion. Version 4.0 har introducerat grundläggande stöd för Q-relaterade funktioner och meandringssimulering genom stubbar. Denna plan beskriver hur full funktionalitet för avancerade hydrauliska och hydrologiska ekvationer kan implementeras med en tydlig uppdelning mellan gratis och premiumfunktioner.

### Designfilosofi

1. **Minimal handpåläggning**: Användare ska kunna köra modellerna med minimal manuell datainmatning
2. **Flexibla inmatningsmetoder**: Stöd för både manuell inmatning och automatisk datahämtning via API
3. **Automatisk parameterisering**: Härledning av parameteruppsättningar från grundläggande indata
4. **Skalbar komplexitet**: Användare ska kunna välja modellkomplexitet efter behov
5. **Tydlig värdeproposition**: Gratisversionen ska vara funktionell men premium ska erbjuda tydligt mervärde

## Övergripande arkitektur

Den uppdaterade arkitekturen bygger vidare på FloodEngine 4.0 med tillägg av moduler för avancerade hydrauliska modeller, smartare datahantering och licenshantering.

### Nya och modifierade moduler

```
FloodEngine/
├── __init__.py               # (Befintlig) Plugin-initialisering
├── floodengine.py            # (Modifierad) Huvudklass med nya funktioner
├── ui_dialog.py              # (Modifierad) Utökat användargränssnitt
├── model_hydraulic.py        # (Modifierad) Grundläggande hydrauliska modeller
├── advanced_hydraulics.py    # (Ny) Avancerade hydrauliska modeller
├── data_manager.py           # (Ny) Automatisk data-hantering och API-integration
├── parameter_utils.py        # (Ny) Verktyg för automatisk parameterisering
├── visualization.py          # (Ny) Utökade visualiseringsverktyg
├── license_manager.py        # (Ny) Hantering av licenser och premium-funktioner 
└── resources/                # (Modifierad) Resursfiler och ikoner
    ├── default_params/       # (Ny) Standardparametrar för olika regioner/scenarier
    └── templates/            # (Ny) Mallar för rapportgenerering
```

## Funktionsuppdelning (Gratis vs. Premium)

För att skapa en tydlig värdeproposition och inkomstmöjlighet, delas funktionaliteten upp mellan gratisversion och premiumversion.

### Gratisversion (Basic-flik)

1. **Grundläggande översvämningsberäkning** - Enkel vattennivåbaserad översvämningsmodell
2. **DEM-inmatning** - Manuell inläsning av höjdmodeller
3. **Bathymetri-inmatning** - Grundläggande inläsning av djupdata (CSV)
4. **Vattennivåkontroller** - Inställning av vattennivåer och visualisering
5. **Inbränning av vattendrag** - Grundläggande inbränningsfunktionalitet
6. **Flödesvisualisering** - Enkla flödespilar baserat på terränglutnig
7. **Grundläggande rapportering** - Export av översvämningspolygoner
8. **Erosionsrisk** - Grundläggande erosionsriskbedömning baserat på lutning
9. **Streamlines** - Visualisering av flödesvägar med bashastighetsindikatorer
10. **Hillshade-generering** - Bakgrundsgenerering för visualisering

### Betalversion (Advanced-flik)

#### Hydraulik-grupp
1. **2D Shallow Water Equations** - Fullständig lösning med momentbevarande
2. **Tidsberoende simulering** - Dynamisk simulering av översvämningsutbredning
3. **Adaptiva beräkningsnät** - Högre upplösning i komplexa områden
4. **Hastighetsfält** - Detaljerade flödeshastigheter och strömningsriktningar
5. **Hydrauliska strukturer** - Modellering av dammar, kulvertar, etc.
6. **Volymbevarande beräkningar** - Massbevarande för högnoggrannhet
7. **Flödesjustering (Q)** - Dynamisk beräkning baserat på inflöden

#### Jordprocesser-grupp
8. **Avancerad sedimenttransport** - Meyer-Peter Müller och suspenderad sediment
9. **Erosion och deposition** - Dynamisk uppdatering av bottentopografi
10. **Meandringssimulering** - Simulering av vattendragsmigrering över tid
11. **Bankstabilitet** - Beräkning av bankstabilitet och erosionsrisk
12. **Jordartskänslighet** - Anpassad erosion baserat på jordegenskaper
13. **Hölja/nacke-simulering** - Automatisk generering av naturlig bottenundulering

#### Grundvatten-grupp
14. **Grundvatten-ytvattenmodell** - Kopplad modellering av båda systemen
15. **Infiltration/exfiltration** - Utbytesflöden mellan grund- och ytvatten
16. **Permeabilitetsberoende** - Hantering av olika jordartsgenomsläpplighet
17. **Grundvattennivåvisualisering** - Visualisering av grundvattenflöden

#### Urban/infrastruktur-grupp
18. **Urban översvämningsmodell** - Hantering av infrastruktur i städer
19. **Dagvattensystem** - Koppling till brunnar och ledningar
20. **Kulvertmodellering** - Detaljerad rörnätsmodellering
21. **Översvämningsbarriärer** - Simulering av permanenta/temporära barriärer
22. **Byggnadsinteraktioner** - Hantering av byggnader i översvämningsmodellen

#### Data och integration-grupp
23. **Automatisk datahämtning** - API-integration med datakällor (Lantmäteriet, SMHI, SGU)
24. **Scenario-hantering** - Jämförelse av olika scenarier
25. **Batch-simulering** - Körning av multipla scenarier i batch
26. **Avancerad resultatanalys** - Statistik och jämförelser av resultat
27. **Animerad visualisering** - Högkvalitativa animationer av dynamiska resultat
28. **Rapportgenerator** - Automatiserad skapande av rapporter med resultat
29. **Export till externa format** - Export till HEC-RAS, MIKE eller andra format

## Implementationsfaser

### Fas 1: Datahanteringsramverk och grundläggande integration (2 veckor)

1. **Skapa data_manager.py:**
   - Implementera ramverk för automatisk datahämtning
   - Integrera API-anrop till öppna datakällor (Lantmäteriet, SMHI, SGU, OSM)
   - Skapa funktioner för att konvertera data till rätt format
   - **Licensintegrering:** Begränsa API-åtkomst till premiumversion

2. **Skapa parameter_utils.py:**
   - Implementera funktioner för att härleda modellparametrar från grunddata
   - Skapa uppslagstabeller för olika jordarter, markanvändning, etc.
   - Implementera smarta standardvärden baserade på geografisk kontext
   - **Licensintegrering:** Begränsa avancerade parameterar till premiumversion

3. **Skapa license_manager.py:**
   - Implementera verifiering av licensnyckel
   - Skapa mekanism för att aktivera/avaktivera premium-funktioner
   - Implementera tidsbegränsade licenser och förnyelse

4. **Utöka ui_dialog.py:**
   - Lägg till "Datahanterare"-flik för datainmatning/import
   - Implementera funktioner för att växla mellan manuell och automatisk datainmatning
   - Skapa gränssnitt för licenshantering och uppgradering

```python
# Exempel för license_manager.py
class LicenseManager:
    def __init__(self, license_key=None):
        self.license_key = license_key
        self.features = self._validate_license()
        
    def _validate_license(self):
        """Validera licens och returnera aktiverade funktioner"""
        if not self.license_key:
            # Gratis version - endast kärnfunktioner
            return {'core': True}
            
        try:
            # Dekryptera och validera licensnyckel
            # I verkligheten skulle du använda ordentlig kryptering
            # och kommunikation med licensserver
            import hashlib
            import json
            from datetime import datetime
            
            # Simulerad licensvalidering
            hash_obj = hashlib.sha256(self.license_key.encode())
            digest = hash_obj.hexdigest()
            
            # I verkligheten skulle detta vara betydligt mer sofistikerat
            if digest.startswith('a'):  # Pro-licens
                return {
                    'core': True,
                    'advanced_hydraulics': True,
                    'sediment': True,
                    'meander': True,
                    'expiry_date': '2023-12-31'
                }
            elif digest.startswith('b'):  # Enterprise-licens
                return {
                    'core': True,
                    'advanced_hydraulics': True,
                    'sediment': True,
                    'meander': True,
                    'groundwater': True,
                    'urban': True,
                    'api_access': True,
                    'expiry_date': '2023-12-31'
                }
            else:
                # Ogiltig licens - returnera bara kärnfunktioner
                return {'core': True}
                
        except Exception as e:
            print(f"Licensvalideringsfel: {e}")
            return {'core': True}  # Fallback till gratisversion vid fel
    
    def has_feature(self, feature_name):
        """Kontrollera om en specifik funktion är licensierad"""
        return self.features.get(feature_name, False)
```

### Fas 2: Implementation av Shallow Water Equations (SWE) (2 veckor)

1. **Skapa modul för 2D SWE:**
   - Implementera Shallow Water-lösare i advanced_hydraulics.py
   - Fokusera på numerisk stabilitet och hantering av torrceller
   - Implementera gränsvillkor och flödeshantering
   - **Licensintegrering:** Endast tillgänglig i premiumversion

2. **Integration med befintligt gränssnitt:**
   - Utöka ui_dialog.py med SWE-specifika inställningar i Advanced-fliken
   - Skapa översvämningsstyrka- och hastighetsvisualisering
   - Implementera uppgraderingsuppmaning när användare försöker använda premium-funktioner

```python
# Exempel för advanced_hydraulics.py - SWE-implementering
class ShallowWaterModel:
    def __init__(self, dem_array, manning_array, dx, timestep=1.0, license_manager=None):
        self.dem = dem_array
        self.manning = manning_array
        self.dx = dx
        self.timestep = timestep
        self.h = np.zeros_like(dem_array)  # Vattendjup
        self.u = np.zeros_like(dem_array)  # x-hastighet
        self.v = np.zeros_like(dem_array)  # y-hastighet
        self.g = 9.81  # Gravitation
        
        # Licensverifiering
        self.license_manager = license_manager
        self.premium_enabled = self.check_license()
        
    def check_license(self):
        """Kontrollera om premium-funktionalitet är tillgänglig"""
        if self.license_manager is None:
            return False
        return self.license_manager.has_feature('advanced_hydraulics')
        
    def set_boundary_conditions(self, boundaries):
        """Sätter gränsvillkor för modellen"""
        if not self.premium_enabled:
            raise LicenseError("Advance boundary conditions require premium license")
        # Implementering...
        
    def run_simulation(self, total_time, output_interval=None):
        """Kör simulering över angiven tid"""
        if not self.premium_enabled:
            raise LicenseError("SWE simulation requires premium license")
        
        # Implementera tidslösning av SWE med finita differenser
        # Inkludera CFL-kontroll för stabilitet
        # Sammankoppla med resultatlagring
```

### Fas 3: Implementation av sedimenttransport och meandring (3 veckor)

1. **Implementera sedimenttransportmodell:**
   - Skapa klasser för bottentransport och suspenderad transport
   - Implementera erosions- och depositionsberäkningar
   - Integrera med SWE-modellen
   - **Licensintegrering:** Endast tillgänglig i premiumversion

2. **Implementera meandringssimulering:**
   - Fullständig implementation av stubbade meandringsfunktioner
   - Koppla bankstabilitet till jordegenskaper och flöde
   - Skapa visualiseringsverktyg för meanderutveckling
   - **Licensintegrering:** Endast tillgänglig i premiumversion

### Fas 4: Grundvatten-ytvatten och urban översvämning (3 veckor)

1. **Implementera kopplad grundvattenmodell:**
   - Skapa klasser för Darcy-flöde i grundvatten
   - Implementera utbytesflöden mellan grund- och ytvatten
   - Integrera med SWE-modellen
   - **Licensintegrering:** Endast tillgänglig i premiumversion

2. **Implementera urban översvämningsmodell:**
   - Skapa klasser för infrastrukturelement (brunnar, kulvertar, etc.)
   - Implementera interaktion mellan infrastruktur och vattenflöde
   - Skapa visualiseringsverktyg för urban översvämning
   - **Licensintegrering:** Endast tillgänglig i premiumversion

### Fas 5: Data-integrationstjänster och rapportering (2 veckor)

1. **Implementera avancerade datatjänster:**
   - Integrera API-anslutningar till Lantmäteriet, SMHI, etc.
   - Skapa automatiserad datahämtning och förbehandling
   - **Licensintegrering:** Endast tillgänglig i premiumversion

2. **Implementera avancerade rapporter:**
   - Skapa mallar för professionella rapporter
   - Implementera animerade visualiseringar
   - Automatisera analys och dataextraktion
   - **Licensintegrering:** Endast grundläggande rapporter i gratisversion

### Fas 6: Optimering, testning och dokumentation (2 veckor)

1. **Prestandaoptimering:**
   - Implementera parallellberäkningar där möjligt
   - Optimera minnesanvändning för stora dataset
   - Implementera adaptiva tidssteg för ökad stabilitet

2. **Testning och validering:**
   - Skapa testfall för alla implementerade modeller
   - Validera mot analytiska lösningar och kända testfall
   - Genomför fälttester med verkliga data

3. **Dokumentation:**
   - Skapa användardokumentation
   - Implementera kontextuell hjälp i gränssnittet
   - Skapa handledningar för typiska användningsfall
   - Dokumentera licensmodell och uppgraderingsvägar

## Strategier för datahantering

### Automatisk datahämtning (Premium)

För minimalt handpåläggning i premiumversionen, implementera följande för automatisk datahämtning:

1. **API-integrationer:**
   - Lantmäteriet Höjddata API
   - SMHI Open Data API
   - SGU:s API (där tillgängligt)
   - OpenStreetMap Overpass API

2. **Smarta åtgärder vid databrist:**
   - Implementera hierarki av datakällor med fallback-alternativ
   - Härleda saknade parametrar från tillgängliga data
   - Erbjuda användaren möjlighet att godkänna uppskattningar

```python
def get_best_available_data(data_type, bbox, license_manager=None):
    """Hämtar bästa tillgängliga data för given typ och område"""
    premium_access = license_manager and license_manager.has_feature('api_access')
    
    if premium_access:
        # Premium-användare får tillgång till API-datakällor
        data_sources = PREMIUM_DATA_SOURCE_HIERARCHY[data_type]
    else:
        # Gratis användare får endast tillgång till lokala/öppna datakällor
        data_sources = FREE_DATA_SOURCE_HIERARCHY[data_type]
    
    for source in data_sources:
        try:
            data = fetch_from_source(source, bbox)
            if data is not None:
                return data, source
        except Exception as e:
            logger.warning(f"Kunde inte hämta {data_type} från {source}: {e}")
    
    # Om ingen data kunde hämtas, generera uppskattning
    return estimate_data(data_type, bbox), "estimated"
```

### Flexibel datainmatning

För att stödja både automatisk (premium) och manuell datainmatning:

1. **Dubbla inmatningsvägar:**
   - Implementera "Auto" (premium) och "Manuell" (gratis) flikar för varje datatyp
   - Gör Auto-funktioner tillgängliga baserat på licensstatus

2. **Validering och konvertering:**
   - Validera manuell indata mot förväntade format
   - Konvertera mellan olika dataformat (t.ex. shapefile -> raster)
   - Implementera förhandsgranskning av indata

## Användargränssnittsdesign

### Hierarkisk modellkomplexitet

För att hantera olika användarbehov:

1. **Två huvudflöden:**
   - **Basic-flik (Gratis):** Grundläggande översvämningsmodellering och visualisering
   - **Advanced-flik (Premium):** Avancerade hydrauliska modeller och analyser

2. **Kontextkänsliga gränssnitt:**
   - Visa endast relevanta parametrar baserat på vald modell
   - Anpassa inmatningsfält efter datatillgänglighet
   - Markera premium-funktioner med tydlig visuell indikation

```python
def create_ui_tabs(self, license_manager):
    """Skapar flikar i gränssnittet baserat på licensstatus"""
    self.tab_widget = QTabWidget()
    
    # Basic-fliken (tillgänglig för alla)
    self.basic_tab = self.create_basic_tab()
    self.tab_widget.addTab(self.basic_tab, "Basic")
    
    # Advanced-fliken (premium)
    self.advanced_tab = self.create_advanced_tab()
    self.tab_widget.addTab(self.advanced_tab, "Advanced")
    
    # Hantera premium-funktioner
    has_premium = license_manager.has_feature('advanced_hydraulics')
    
    if not has_premium:
        # Lägg till "uppgradera" overlay på advanced-fliken
        self.add_upgrade_overlay(self.advanced_tab)
    
    return self.tab_widget
    
def add_upgrade_overlay(self, tab_widget):
    """Lägger till uppgraderingsöverlay på premium-flikar"""
    overlay = QWidget(tab_widget)
    overlay.setStyleSheet("background-color: rgba(0, 0, 0, 50%);")
    overlay_layout = QVBoxLayout()
    
    # Skapa uppgraderingsmeddelande
    message = QLabel("Premium Feature")
    message.setStyleSheet("color: white; font-size: 18pt; font-weight: bold;")
    message.setAlignment(Qt.AlignCenter)
    
    upgrade_btn = QPushButton("Upgrade to Premium")
    upgrade_btn.setStyleSheet("background-color: #2980b9; color: white; padding: 10px;")
    upgrade_btn.clicked.connect(self.show_license_dialog)
    
    overlay_layout.addStretch()
    overlay_layout.addWidget(message)
    overlay_layout.addWidget(upgrade_btn)
    overlay_layout.addStretch()
    
    overlay.setLayout(overlay_layout)
    overlay.setGeometry(tab_widget.rect())
    
    # Se till att overlay visas ovanpå andra widgets
    overlay.raise_()
    overlay.show()
```

### Datahanteringsdialoger

För att förenkla datainmatning:

1. **Enkel datainsamlingsdialog:**
   - Stegvis process för att definiera studieområde och datakällor
   - Automatisk datahämtning i bakgrunden (premium)
   - Förlopp och statusuppdateringar

2. **Förhandsgranskning av data:**
   - Visuell förhandsgranskning av hämtad/inmatad data
   - Möjlighet att justera/redigera innan modelkörning
   - Validering och felindikation

### Licenshanteringsdialog

```python
class LicenseDialog(QDialog):
    def __init__(self, parent, license_manager):
        super().__init__(parent)
        self.license_manager = license_manager
        self.setWindowTitle("FloodEngine License Manager")
        
        layout = QVBoxLayout()
        
        # Visa aktuell licensinformation
        license_info = self.license_manager.get_license_info()
        info_group = QGroupBox("Current License")
        info_layout = QFormLayout()
        
        info_layout.addRow("License Type:", QLabel(license_info['type']))
        info_layout.addRow("Expiry Date:", QLabel(license_info['expiry']))
        
        features_label = QLabel("Enabled Features:")
        features_list = QListWidget()
        features_list.addItems(license_info['features'])
        
        info_layout.addRow(features_label, features_list)
        info_group.setLayout(info_layout)
        
        # Sektion för att aktivera ny licens
        activate_group = QGroupBox("Activate License")
        activate_layout = QVBoxLayout()
        
        license_key_label = QLabel("Enter License Key:")
        self.license_key_input = QLineEdit()
        activate_button = QPushButton("Activate")
        activate_button.clicked.connect(self.activate_license)
        
        activate_layout.addWidget(license_key_label)
        activate_layout.addWidget(self.license_key_input)
        activate_layout.addWidget(activate_button)
        
        activate_group.setLayout(activate_layout)
        
        # Köp-sektion
        purchase_group = QGroupBox("Purchase License")
        purchase_layout = QVBoxLayout()
        
        pro_btn = QPushButton("Purchase Pro License")
        enterprise_btn = QPushButton("Purchase Enterprise License")
        custom_btn = QPushButton("Contact for Custom License")
        
        purchase_layout.addWidget(pro_btn)
        purchase_layout.addWidget(enterprise_btn)
        purchase_layout.addWidget(custom_btn)
        
        purchase_group.setLayout(purchase_layout)
        
        # Lägg till alla sektioner
        layout.addWidget(info_group)
        layout.addWidget(activate_group)
        layout.addWidget(purchase_group)
        
        # Knappar
        button_box = QDialogButtonBox(QDialogButtonBox.Close)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
        
        self.setLayout(layout)
    
    def activate_license(self):
        """Aktivera licens med angiven nyckel"""
        license_key = self.license_key_input.text()
        if not license_key:
            QMessageBox.warning(self, "Error", "Please enter a license key")
            return
            
        success = self.license_manager.activate_license(license_key)
        if success:
            QMessageBox.information(self, "Success", "License activated successfully")
            self.accept()
        else:
            QMessageBox.warning(self, "Error", "Invalid license key")
```

## Specifika modellekvationer och implementationer

Här följer en detaljerad beskrivning av de specifika ekvationerna som ska implementeras i de premium-modulerna.

### 2D Shallow Water Equations (SWE)

```python
class ShallowWaterModel:
    def __init__(self, dem_array, manning_array, dx, timestep=1.0, license_manager=None):
        # Initialisering, inklusive licenskontroll...
        
    def calculate_timestep(self):
        """Beräknar adaptivt tidssteg baserat på CFL-villkor"""
        if not self.premium_enabled:
            return self.timestep  # Standardtidssteg i gratisversion
            
        if np.max(self.h) < 0.01:
            return self.timestep  # Standardvärde för nästan torr domän
            
        # Beräkna vågutbredningshastighet
        wave_speed = np.sqrt(self.g * self.h)
        
        # Beräkna maximal flödeshastighet
        flow_speed = np.maximum(np.abs(self.u), np.abs(self.v))
        max_speed = np.nanmax(wave_speed + flow_speed)
        
        # Använd CFL-villkor för att beräkna säkert tidssteg
        dt = 0.4 * self.dx / max_speed if max_speed > 0 else self.timestep
        
        # Begränsa till rimliga värden
        return min(max(dt, 0.1), self.timestep)
        
    def solve_timestep(self):
        """Löser ett tidssteg av SWE med finita differenser"""
        if not self.premium_enabled:
            # Fallback till enklare modell för gratisversion
            return self.solve_simplified_timestep()
            
        # Adaptivt tidssteg
        dt = self.calculate_timestep()
        
        # Beräkna flöden och uppdatera vattendjup och hastigheter med finita differenser
        # Implementera kontinuitetsekvation och rörelsemängdsekvationer
        # Hantera torrceller och friktionstermer
```

### Sedimenttransport (Premium)

```python
class SedimentTransport:
    def __init__(self, hydraulic_model, soil_properties, license_manager=None):
        # Initialisering, inklusive licenskontroll...
        
    def calculate_shear_stress(self):
        """Beräknar bottenskjuvspänning baserat på vattendjup och hastighet"""
        if not self.premium_enabled:
            raise LicenseError("Sediment transport requires premium license")
            
        h = self.hydraulic.h
        u = self.hydraulic.u
        v = self.hydraulic.v
        
        # Flödeshastighet
        velocity_mag = np.sqrt(u**2 + v**2)
        
        # Bottenskjuvspänning (förenklad formel)
        rho = 1000  # kg/m^3, vattnets densitet
        n = self.manning_n  # Manning's n
        
        # Tau = rho * g * h * S, där S approx. med n^2 * u^2 / h^(4/3)
        tau = rho * self.g * n**2 * velocity_mag**2 / np.power(h, 1/3)
        
        # Sätt till noll i torrceller
        tau[h < 0.01] = 0
        
        return tau
        
    def calculate_bedload(self, tau):
        """Beräknar bottenlast med Meyer-Peter Müller ekvation"""
        if not self.premium_enabled:
            raise LicenseError("Sediment transport requires premium license")
            
        # Parameterinställning
        rho_s = 2650  # kg/m^3, sedimentdensitet
        rho = 1000    # kg/m^3, vattnets densitet
        d50 = self.soil.d50  # m, medelkornstorlek
        tau_cr = self.soil.critical_shear  # N/m^2, kritisk skjuvspänning
        
        # Shields parameter (dimensionslös bottenskjuvspänning)
        shields = tau / ((rho_s - rho) * self.g * d50)
        
        # Meyer-Peter Müller ekvation
        q_b = np.zeros_like(tau)
        active = (shields > tau_cr)
        q_b# FloodEngine 4.0+ - Implementationsplan för avancerade hydrauliska modeller

## Innehållsförteckning

1. [Introduktion och bakgrund](#introduktion-och-bakgrund)
2. [Övergripande arkitektur](#övergripande-arkitektur)
3. [Implementationsfaser](#implementationsfaser)
4. [Strategier för datahantering](#strategier-för-datahantering)
5. [Användargränssnittsdesign](#användargränssnittsdesign)
6. [Specifika modellekvationer och implementationer](#specifika-modellekvationer-och-implementationer)
7. [Optimering och prestanda](#optimering-och-prestanda)
8. [Testning och validering](#testning-och-validering)
9. [Dokumentation och hjälpresurser](#dokumentation-och-hjälpresurser)

## Introduktion och bakgrund

FloodEngine är ett QGIS-plugin för avancerad modellering av översvämning och erosion. Version 4.0 har introducerat grundläggande stöd för Q-relaterade funktioner och meandringssimulering genom stubbar. Denna plan beskriver hur full funktionalitet för avancerade hydrauliska och hydrologiska ekvationer kan implementeras samtidigt som användarvänligheten behålls.

### Designfilosofi

1. **Minimal handpåläggning**: Användare ska kunna köra modellerna med minimal manuell datainmatning
2. **Flexibla inmatningsmetoder**: Stöd för både manuell inmatning och automatisk datahämtning via API
3. **Automatisk parameterisering**: Härledning av parameteruppsättningar från grundläggande indata
4. **Skalbar komplexitet**: Användare ska kunna välja modellkomplexitet efter behov

## Övergripande arkitektur

Den uppdaterade arkitekturen bygger vidare på FloodEngine 4.0 med tillägg av moduler för avancerade hydrauliska modeller och smartare datahantering.

### Nya och modifierade moduler

```
FloodEngine/
├── __init__.py               # (Befintlig) Plugin-initialisering
├── floodengine.py            # (Modifierad) Huvudklass med nya funktioner
├── ui_dialog.py              # (Modifierad) Utökat användargränssnitt
├── model_hydraulic.py        # (Modifierad) Grundläggande hydrauliska modeller
├── advanced_hydraulics.py    # (Ny) Avancerade hydrauliska modeller
├── data_manager.py           # (Ny) Automatisk data-hantering och API-integration
├── parameter_utils.py        # (Ny) Verktyg för automatisk parameterisering
├── visualization.py          # (Ny) Utökade visualiseringsverktyg
└── resources/                # (Modifierad) Resursfiler och ikoner
    ├── default_params/       # (Ny) Standardparametrar för olika regioner/scenarier
    └── templates/            # (Ny) Mallar för rapportgenerering
```

## Implementationsfaser

### Fas 1: Datahanteringsramverk och grundläggande integration (2 veckor)

1. **Skapa data_manager.py:**
   - Implementera ramverk för automatisk datahämtning
   - Integrera API-anrop till öppna datakällor (Lantmäteriet, SMHI, SGU, OSM)
   - Skapa funktioner för att konvertera data till rätt format

2. **Skapa parameter_utils.py:**
   - Implementera funktioner för att härleda modellparametrar från grunddata
   - Skapa uppslagstabeller för olika jordarter, markanvändning, etc.
   - Implementera smarta standardvärden baserade på geografisk kontext

3. **Utöka ui_dialog.py:**
   - Lägg till "Datahanterare"-flik för datainmatning/import
   - Implementera funktioner för att växla mellan manuell och automatisk datainmatning

```python
# Exempel för data_manager.py
class DataManager:
    def __init__(self, iface):
        self.iface = iface
        self.data_sources = {
            'dem': {
                'api': self.fetch_dem_lantmateriet,
                'manual': self.load_dem_from_file
            },
            'landcover': {
                'api': self.fetch_landcover_nmd,
                'manual': self.load_landcover_from_file
            },
            # Fler datakällor...
        }
    
    def fetch_data(self, data_type, bbox, method='api', **kwargs):
        """Hämtar data av angiven typ inom bbox, antingen via API eller manuell inläsning"""
        if method == 'api':
            return self.data_sources[data_type]['api'](bbox, **kwargs)
        else:
            return self.data_sources[data_type]['manual'](**kwargs)
            
    def fetch_dem_lantmateriet(self, bbox, resolution="2m"):
        """Hämtar höjddata från Lantmäteriet inom angivet område"""
        # Implementering av API-anrop...
```

### Fas 2: Implementation av Shallow Water Equations (SWE) (2 veckor)

1. **Skapa modul för 2D SWE:**
   - Implementera Shallow Water-lösare i advanced_hydraulics.py
   - Fokusera på numerisk stabilitet och hantering av torrceller
   - Implementera gränsvillkor och flödeshantering

2. **Integration med befintligt gränssnitt:**
   - Utöka ui_dialog.py med SWE-specifika inställningar
   - Skapa översvämningsstyrka- och hastighetsvisualisering
   - Koppla samman SWE med befintlig översvämningsmodellering

```python
# Exempel för advanced_hydraulics.py - SWE-implementering
class ShallowWaterModel:
    def __init__(self, dem_array, manning_array, dx, timestep=1.0):
        self.dem = dem_array
        self.manning = manning_array
        self.dx = dx
        self.timestep = timestep
        self.h = np.zeros_like(dem_array)  # Vattendjup
        self.u = np.zeros_like(dem_array)  # x-hastighet
        self.v = np.zeros_like(dem_array)  # y-hastighet
        self.g = 9.81  # Gravitation
        
    def set_boundary_conditions(self, boundaries):
        """Sätter gränsvillkor för modellen"""
        # Implementering...
        
    def run_simulation(self, total_time, output_interval=None):
        """Kör simulering över angiven tid"""
        # Implementera tidslösning av SWE med finita differenser
        # Inkludera CFL-kontroll för stabilitet
        # Sammankoppla med resultatlagring
```

### Fas 3: Implementation av sedimenttransport och meandring (3 veckor)

1. **Implementera sedimenttransportmodell:**
   - Skapa klasser för bottentransport och suspenderad transport
   - Implementera erosions- och depositionsberäkningar
   - Integrera med SWE-modellen

2. **Implementera meandringssimulering:**
   - Fullständig implementation av stubbade meandringsfunktioner
   - Koppla bankstabilitet till jordegenskaper och flöde
   - Skapa visualiseringsverktyg för meanderutveckling

```python
# Exempel för sedimenttransportmodell
class SedimentTransport:
    def __init__(self, hydraulic_model, soil_properties):
        self.hydraulic = hydraulic_model
        self.soil = soil_properties
        self.concentration = np.zeros_like(hydraulic_model.h)
        self.erosion = np.zeros_like(hydraulic_model.h)
        self.deposition = np.zeros_like(hydraulic_model.h)
        
    def calculate_transport(self, timestep):
        """Beräkna sedimenttransport, erosion och deposition för ett tidssteg"""
        # Implementera Meyer-Peter Müller för bottentransport
        # Implementera advektions-diffusionsekvation för suspenderad transport
        # Uppdatera botten baserat på erosion/deposition
```

### Fas 4: Grundvatten-ytvatten och urban översvämning (3 veckor)

1. **Implementera kopplad grundvattenmodell:**
   - Skapa klasser för Darcy-flöde i grundvatten
   - Implementera utbytesflöden mellan grund- och ytvatten
   - Integrera med SWE-modellen

2. **Implementera urban översvämningsmodell:**
   - Skapa klasser för infrastrukturelement (brunnar, kulvertar, etc.)
   - Implementera interaktion mellan infrastruktur och vattenflöde
   - Skapa visualiseringsverktyg för urban översvämning

```python
# Exempel för grundvatten-ytvattenmodell
class CoupledGroundwaterModel:
    def __init__(self, dem_array, hydraulic_conductivity, storage_coefficient):
        self.dem = dem_array
        self.k = hydraulic_conductivity  # Hydraulisk konduktivitet
        self.s = storage_coefficient     # Magasinskoefficient
        self.h_gw = np.zeros_like(dem_array)  # Grundvattennivå
        
    def set_initial_groundwater_level(self, initial_gw_level=None):
        """Sätter initial grundvattennivå, antingen från indata eller uppskattad"""
        if initial_gw_level is not None:
            self.h_gw = initial_gw_level
        else:
            # Uppskatta grundvattennivå från topografi
            # Implementera TWI-baserad uppskattning
            
    def calculate_exchange_flux(self, surface_water):
        """Beräkna utbytesflöde mellan grund- och ytvatten"""
        # Implementera utbytesterm baserad på nivåskillnad
```

### Fas 5: Optimering, testning och dokumentation (2 veckor)

1. **Prestandaoptimering:**
   - Implementera parallellberäkningar där möjligt
   - Optimera minnesanvändning för stora dataset
   - Implementera adaptiva tidssteg för ökad stabilitet

2. **Testning och validering:**
   - Skapa testfall för alla implementerade modeller
   - Validera mot analytiska lösningar och kända testfall
   - Genomför fälttester med verkliga data

3. **Dokumentation:**
   - Skapa användardokumentation
   - Implementera kontextuell hjälp i gränssnittet
   - Skapa handledningar för typiska användningsfall

## Strategier för datahantering

### Automatisk datahämtning

För minimalt handpåläggning, implementera följande för automatisk datahämtning:

1. **API-integrationer:**
   - Lantmäteriet Höjddata API
   - SMHI Open Data API
   - SGU:s API (där tillgängligt)
   - OpenStreetMap Overpass API

2. **Smarta åtgärder vid databrist:**
   - Implementera hierarki av datakällor med fallback-alternativ
   - Härleda saknade parametrar från tillgängliga data
   - Erbjuda användaren möjlighet att godkänna uppskattningar

```python
def get_best_available_data(data_type, bbox):
    """Hämtar bästa tillgängliga data för given typ och område"""
    data_sources = DATA_SOURCE_HIERARCHY[data_type]
    
    for source in data_sources:
        try:
            data = fetch_from_source(source, bbox)
            if data is not None:
                return data, source
        except Exception as e:
            logger.warning(f"Kunde inte hämta {data_type} från {source}: {e}")
    
    # Om ingen data kunde hämtas, generera uppskattning
    return estimate_data(data_type, bbox), "estimated"
```

### Flexibel datainmatning

För att stödja både automatisk och manuell datainmatning:

1. **Dubbla inmatningsvägar:**
   - Implementera "Auto" och "Manuell" flikar för varje datatyp
   - Lagra inmatningsmetod för varje parameter

2. **Validering och konvertering:**
   - Validera manuell indata mot förväntade format
   - Konvertera mellan olika dataformat (t.ex. shapefile -> raster)
   - Implementera förhandsgranskning av indata

```python
class DataInput:
    def __init__(self, data_type, name):
        self.data_type = data_type
        self.name = name
        self.auto_widget = AutoDataWidget(data_type)
        self.manual_widget = ManualDataWidget(data_type)
        self.current_method = 'auto'  # Default
        
    def get_data(self):
        """Hämtar data från vald inmatningsmetod"""
        if self.current_method == 'auto':
            return self.auto_widget.get_data()
        else:
            return self.manual_widget.get_data()
            
    def switch_method(self, method):
        """Byter inmatningsmetod"""
        if method in ['auto', 'manual']:
            self.current_method = method
```

### Automatisk parameterisering

För att minimera manuell parameterinmatning:

1. **Parameteruppslagstabeller:**
   - Skapa tabeller för standardparametrar baserat på region, jordart, etc.
   - Implementera hierarki av parameteruppslagstabeller

2. **Parameteruppskattning från grunddata:**
   - Härleda Manning-koefficienter från markanvändningsdata
   - Uppskatta hydrauliska parametrar från jordartskarta
   - Beräkna avrinningskoefficienter från topografi och markanvändning

```python
def derive_parameters(dem, landcover, soil, region="sweden"):
    """Härleder modellparametrar från grundläggande indata"""
    params = {}
    
    # Härleda Manning-koefficienter
    params['manning'] = landcover_to_manning(landcover, region)
    
    # Härleda hydrauliska parametrar
    params['hydraulic_conductivity'] = soil_to_conductivity(soil)
    params['storage_coefficient'] = soil_to_storage(soil)
    
    # Härleda erosionsparametrar
    params['critical_shear'] = soil_to_critical_shear(soil)
    params['erodibility'] = soil_to_erodibility(soil, landcover)
    
    return params
```

## Användargränssnittsdesign

### Hierarkisk modellkomplexitet

För att hantera olika användarbehov:

1. **Tre komplexitetsnivåer:**
   - **Enkel:** Endast grundläggande indata och standardparametrar
   - **Mellan:** Några nyckelparametrar exponerade, resten automatiska
   - **Avancerad:** Full kontroll över alla parametrar

2. **Kontextkänsliga gränssnitt:**
   - Visa endast relevanta parametrar baserat på vald modell
   - Anpassa inmatningsfält efter datatillgänglighet

```python
def create_model_tab(self, complexity_level="simple"):
    """Skapar modellflik med angiven komplexitetsnivå"""
    tab = QWidget()
    layout = QVBoxLayout()
    
    # Gemensamma basparametrar för alla nivåer
    base_params = self.create_base_parameters()
    layout.addWidget(base_params)
    
    # Nivåspecifika parametrar
    if complexity_level == "medium":
        medium_params = self.create_medium_parameters()
        layout.addWidget(medium_params)
    elif complexity_level == "advanced":
        medium_params = self.create_medium_parameters()
        advanced_params = self.create_advanced_parameters()
        layout.addWidget(medium_params)
        layout.addWidget(advanced_params)
    
    tab.setLayout(layout)
    return tab
```

### Datahanteringsdialoger

För att förenkla datainmatning:

1. **Enkel datainsamlingsdialog:**
   - Stegvis process för att definiera studieområde och datakällor
   - Automatisk datahämtning i bakgrunden
   - Förlopp och statusuppdateringar

2. **Förhandsgranskning av data:**
   - Visuell förhandsgranskning av hämtad/inmatad data
   - Möjlighet att justera/redigera innan modelkörning
   - Validering och felindikation

```python
class DataManagerDialog(QDialog):
    def __init__(self, parent, iface):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("FloodEngine - Datahanterare")
        
        # Skapa layouter och widgets
        self.create_ui()
        
        # Koppla signaler
        self.area_btn.clicked.connect(self.define_study_area)
        self.fetch_btn.clicked.connect(self.fetch_all_data)
        self.validate_btn.clicked.connect(self.validate_data)
        self.ok_btn.clicked.connect(self.accept)
        self.cancel_btn.clicked.connect(self.reject)
    
    def create_ui(self):
        """Skapar användargränssnittet för dialogen"""
        layout = QVBoxLayout()
        
        # Studieområde
        area_group = QGroupBox("Studieområde")
        area_layout = QHBoxLayout()
        self.area_combo = QComboBox()
        self.area_combo.addItems(["Aktuell kartvvy", "Välj på karta", "Från fil..."])
        self.area_btn = QPushButton("Definiera")
        area_layout.addWidget(self.area_combo)
        area_layout.addWidget(self.area_btn)
        area_group.setLayout(area_layout)
        
        # Datakällor
        sources_group = QGroupBox("Datakällor")
        sources_layout = QGridLayout()
        
        # Lägg till checkboxar för olika datakällor
        self.dem_check = QCheckBox("Höjddata (DEM)")
        self.dem_check.setChecked(True)
        self.dem_method = QComboBox()
        self.dem_method.addItems(["Auto (Lantmäteriet)", "Manuell"])
        sources_layout.addWidget(self.dem_check, 0, 0)
        sources_layout.addWidget(self.dem_method, 0, 1)
        
        # Lägg till fler datakällor...
        
        self.fetch_btn = QPushButton("Hämta alla data")
        sources_layout.addWidget(self.fetch_btn, 6, 0, 1, 2)
        sources_group.setLayout(sources_layout)
        
        # Validering
        validation_group = QGroupBox("Datavalidering")
        validation_layout = QVBoxLayout()
        self.status_text = QTextEdit()
        self.status_text.setReadOnly(True)
        self.validate_btn = QPushButton("Validera data")
        validation_layout.addWidget(self.status_text)
        validation_layout.addWidget(self.validate_btn)
        validation_group.setLayout(validation_layout)
        
        # Knappar
        button_layout = QHBoxLayout()
        self.ok_btn = QPushButton("OK")
        self.cancel_btn = QPushButton("Avbryt")
        button_layout.addWidget(self.cancel_btn)
        button_layout.addWidget(self.ok_btn)
        
        # Lägg till allt till huvudlayouten
        layout.addWidget(area_group)
        layout.addWidget(sources_group)
        layout.addWidget(validation_group)
        layout.addLayout(button_layout)
        
        self.setLayout(layout)
```

### Scenariogenereringsverktyg

För att förenkla uppsättning av simuleringar:

1. **Fördefinierade scenarier:**
   - Mallar för vanliga scenariotyper (10-årsregn, dammbrott, etc.)
   - Automatisk parameterisering baserat på scenario

2. **Guidat scenarioskapande:**
   - Stegvis process för att definiera skräddarsydda scenarier
   - Hjälp och förklaringar för varje parameter

```python
class ScenarioManager:
    def __init__(self):
        self.scenarios = self.load_default_scenarios()
        
    def load_default_scenarios(self):
        """Laddar fördefinierade scenariotyper"""
        # Läs in från konfigurationsfiler
        
    def create_scenario(self, scenario_type, study_area, params=None):
        """Skapa ett scenario baserat på typ och studieområde"""
        # Hämta standardparametrar för scenariotyp
        default_params = self.scenarios.get(scenario_type, {})
        
        # Kombinera med användarspecifika parametrar om de finns
        if params:
            scenario_params = {**default_params, **params}
        else:
            scenario_params = default_params
            
        # Anpassa parametrar till studieområdet
        adapted_params = self.adapt_to_study_area(scenario_params, study_area)
        
        return adapted_params
```

## Specifika modellekvationer och implementationer

Här följer en detaljerad beskrivning av de specifika ekvationerna som ska implementeras i de avancerade modellerna.

### 2D Shallow Water Equations (SWE)

```python
class ShallowWaterModel:
    def __init__(self, dem_array, manning_array, dx, timestep=1.0):
        # Initialisering...
        
    def calculate_timestep(self):
        """Beräknar adaptivt tidssteg baserat på CFL-villkor"""
        if np.max(self.h) < 0.01:
            return self.timestep  # Standardvärde för nästan torr domän
            
        # Beräkna vågutbredningshastighet
        wave_speed = np.sqrt(self.g * self.h)
        
        # Beräkna maximal flödeshastighet
        flow_speed = np.maximum(np.abs(self.u), np.abs(self.v))
        max_speed = np.nanmax(wave_speed + flow_speed)
        
        # Använd CFL-villkor för att beräkna säkert tidssteg
        dt = 0.4 * self.dx / max_speed if max_speed > 0 else self.timestep
        
        # Begränsa till rimliga värden
        return min(max(dt, 0.1), self.timestep)
        
    def solve_timestep(self):
        """Löser ett tidssteg av SWE med finita differenser"""
        # Adaptivt tidssteg
        dt = self.calculate_timestep()
        
        # Beräkna flöden och uppdatera vattendjup och hastigheter med finita differenser
        # Implementera kontinuitetsekvation och rörelsemängdsekvationer
        # Hantera torrceller och friktionstermer
```

### Sedimenttransport

```python
class SedimentTransport:
    def __init__(self, hydraulic_model, soil_properties):
        # Initialisering...
        
    def calculate_shear_stress(self):
        """Beräknar bottenskjuvspänning baserat på vattendjup och hastighet"""
        h = self.hydraulic.h
        u = self.hydraulic.u
        v = self.hydraulic.v
        
        # Flödeshastighet
        velocity_mag = np.sqrt(u**2 + v**2)
        
        # Bottenskjuvspänning (förenklad formel)
        rho = 1000  # kg/m^3, vattnets densitet
        n = self.manning_n  # Manning's n
        
        # Tau = rho * g * h * S, där S approx. med n^2 * u^2 / h^(4/3)
        tau = rho * self.g * n**2 * velocity_mag**2 / np.power(h, 1/3)
        
        # Sätt till noll i torrceller
        tau[h < 0.01] = 0
        
        return tau
        
    def calculate_bedload(self, tau):
        """Beräknar bottenlast med Meyer-Peter Müller ekvation"""
        # Parameterinställning
        rho_s = 2650  # kg/m^3, sedimentdensitet
        rho = 1000    # kg/m^3, vattnets densitet
        d50 = self.soil.d50  # m, medelkornstorlek
        tau_cr = self.soil.critical_shear  # N/m^2, kritisk skjuvspänning
        
        # Shields parameter (dimensionslös bottenskjuvspänning)
        shields = tau / ((rho_s - rho) * self.g * d50)
        
        # Meyer-Peter Müller ekvation
        q_b = np.zeros_like(tau)
        active = (shields > tau_cr)
        q_b[active] = 8 * np.sqrt((shields[active] - tau_cr) * 
                               (rho_s - rho) * self.g * d50**3 / rho)
        
        return q_b
```

### Grundvatten-ytvattenmodell

```python
class CoupledGroundwaterModel:
    def __init__(self, dem_array, hydraulic_conductivity, storage_coefficient):
        # Initialisering...
        
    def calculate_darcy_flow(self, h_gw, dt, dx):
        """Beräknar grundvattenflöde med Darcy's lag"""
        # Beräkna gradienter
        dh_dx = np.zeros_like(h_gw)
        dh_dy = np.zeros_like(h_gw)
        
        # Centrerad differens för inre punkter
        dh_dx[1:-1, 1:-1] = (h_gw[1:-1, 2:] - h_gw[1:-1, :-2]) / (2 * dx)
        dh_dy[1:-1, 1:-1] = (h_gw[2:, 1:-1] - h_gw[:-2, 1:-1]) / (2 * dx)
        
        # Beräkna flöden
        qx = -self.k * dh_dx
        qy = -self.k * dh_dy
        
        # Beräkna divergens av flöde
        div_q = np.zeros_like(h_gw)
        div_q[1:-1, 1:-1] = ((qx[1:-1, 2:] - qx[1:-1, :-2]) / (2 * dx) + 
                            (qy[2:, 1:-1] - qy[:-2, 1:-1]) / (2 * dx))
        
        # Uppdatera grundvattennivå
        h_gw_new = h_gw + dt * div_q / self.s
        
        return h_gw_new
        
    def calculate_exchange(self, h_gw, h_surface, dem, dt, k_exchange):
        """Beräknar utbytesflöde mellan grund- och ytvatten"""
        # Surface water level (DEM + water depth)
        surface_level = dem + h_surface
        
        # Exchange flux (positive: gw->surface, negative: surface->gw)
        exchange = k_exchange * (h_gw - surface_level)
        
        # Uppdatera grundvatten och ytvatten
        h_gw_new = h_gw - dt * exchange / self.s
        h_surface_new = h_surface + dt * exchange
        
        return h_gw_new, h_surface_new
```

### Meandringssimulering

```python
class MeanderModel:
    def __init__(self, stream_geometry, flow_field, dem):
        # Initialisering...
        
    def calculate_curvature(self, points):
        """Beräknar kurvatur längs en linje"""
        n_points = len(points)
        curvature = np.zeros(n_points)
        
        # För varje punkt utom ändpunkterna
        for i in range(1, n_points-1):
            # Beräkna vektorer till intilliggande punkter
            v1 = points[i-1] - points[i]
            v2 = points[i+1] - points[i]
            
            # Normalisera vektorer
            v1 = v1 / np.linalg.norm(v1)
            v2 = v2 / np.linalg.norm(v2)
            
            # Beräkna vinkel mellan vektorerna
            dot_product = np.dot(v1, v2)
            # Hanterar numeriska problem
            dot_product = min(max(dot_product, -1.0), 1.0)
            angle = np.arccos(dot_product)
            
            # Kurvatur är omvänt proportionell mot radien, approximeras med vinkeln
            curvature[i] = angle
        
        return curvature
        
    def calculate_bank_erosion(self, points, curvature, flow_field, soil_properties):
        """Beräknar bankerosion baserat på kurvatur och flöde"""
        n_points = len(points)
        erosion_rate = np.zeros((n_points, 2))  # x,y-komponenter
        
        for i in range(1, n_points-1):
            # Beräkna normal till kurvan
            tangent = points[i+1] - points[i-1]
            tangent = tangent / np.linalg.norm(tangent)
            normal = np.array([-tangent[1], tangent[0]])  # Vinkelrät
            
            # Hämta flödesparametrar vid punkten
            flow_velocity = interpolate_flow_at_point(flow_field, points[i])
            flow_speed = np.linalg.norm(flow_velocity)
            
            # Beräkna bottenskjuvspänning
            tau = 1000 * 0.01 * flow_speed**2  # Förenklad formel
            
            # Justera för kurvatur (högre erosion i ytterkurvor)
            tau_adjusted = tau * (1 + 5 * curvature[i])
            
            # Hämta jordartsegenskaper
            tau_cr = soil_properties.get('critical_shear', 10)  # N/m^2
            k_e = soil_properties.get('erosion_coefficient', 0.005)  # m/s/Pa
            
            # Beräkna erosionshastighet
            if tau_adjusted > tau_cr:
                # Excessiv skjuvspänning ger erosion
                rate = k_e * (tau_adjusted - tau_cr)
                
                # Riktning (vinkelrät mot strömlinjen, justerad för kurvatur)
                phase_shift = np.pi / 4  # 45 grader fasförskjutning
                modified_normal = normal
                
                # Skalera med erosionshastighet
                erosion_rate[i] = rate * modified_normal
            
        return erosion_rate
```

### Urban översvämningsmodell

```python
class UrbanFloodModel:
    def __init__(self, dem_array, imperviousness, infrastructure):
        # Initialisering...
        
    def calculate_flow_at_culvert(self, culvert, h, dem, timestep):
        """Beräknar flöde genom en kulvert"""
        # Hämta kulvertegenskaper
        from_idx, to_idx, diameter = culvert[0], culvert[1], culvert[2]
        
        # Vattennivåer vid in- och utlopp
        from_level = dem[from_idx] + h[from_idx]
        to_level = dem[to_idx] + h[to_idx]
        
        # Flödesriktning
        if from_level <= to_level:
            return 0.0  # Inget flöde eller omvänd riktning
        
        # Höjdskillnad
        dh = from_level - to_level
        
        # Beräkna flöde med enkel hydraulisk formel för rör
        # Q = A * C * sqrt(2*g*dh)
        area = np.pi * (diameter/2)**2
        coefficient = 0.6  # Utflödeskoefficient
        g = 9.81  # Gravitation
        
        flow = area * coefficient * np.sqrt(2 * g * dh)
        
        # Begränsa flöde baserat på tillgänglig volym
        cell_area = self.dx * self.dy
        available_volume = h[from_idx] * cell_area
        max_volume = available_volume * 0.5  # Max 50% för stabilitet
        
        # Volym som överförs under tidssteg
        volume = flow * timestep
        volume = min(volume, max_volume)
        
        # Omvandla tillbaka till flöde
        adjusted_flow = volume / timestep
        
        return adjusted_flow
        
    def calculate_drain_flow(self, drain_idx, capacity, h, timestep):
        """Beräknar flöde genom en dagvattenbrunn"""
        if h[drain_idx] <= 0.01:  # Minimal vattendjup
            return 0.0
            
        # Beräkna flöde baserat på kapacitet och tillgängligt vatten
        cell_area = self.dx * self.dy
        available_volume = h[drain_idx] * cell_area
        
        # Max volym som kan dräneras under tidssteg
        max_drain_volume = capacity * timestep
        
        # Faktisk volym som dräneras
        drain_volume = min(max_drain_volume, available_volume * 0.8)
        
        return drain_volume / timestep
```

## Optimering och prestanda

För att säkerställa att modellerna är beräkningseffektiva även för stora dataset:

### Vektorisering och parallellisering

```python
# Exempel på vektoriserad beräkning av bottenskjuvspänning
def calculate_shear_stress_vectorized(h, u, v, manning_n, g=9.81, rho=1000):
    """Beräknar bottenskjuvspänning med vektoriserad NumPy-operation"""
    # Snabbare än loopbaserad implementering
    velocity_mag = np.sqrt(u**2 + v**2)
    h_valid = np.maximum(h, 0.01)  # Undvik division med noll
    
    # Tau = rho * g * h * S, där S approx. med n^2 * u^2 / h^(4/3)
    tau = rho * g * manning_n**2 * velocity_mag**2 / np.power(h_valid, 1/3)
    
    # Nollställ där h är för litet
    tau = np.where(h > 0.01, tau, 0)
    
    return tau
```

### Minnesmappade arrays för stora dataset

```python
def create_memory_mapped_array(filename, shape, dtype=np.float32):
    """Skapar en minnesmappad array för stora dataset"""
    return np.memmap(filename, dtype=dtype, mode='w+', shape=shape)

def run_large_model(dem_path, output_folder, **params):
    """Kör modell för stora dataset med minnesmappade arrays"""
    # Läs metadata från DEM utan att läsa hela filen
    dem_ds = gdal.Open(dem_path)
    width = dem_ds.RasterXSize
    height = dem_ds.RasterYSize
    
    # Skapa minnesmappade arrays för mellanresultat
    temp_path = os.path.join(output_folder, "temp")
    os.makedirs(temp_path, exist_ok=True)
    
    h_file = os.path.join(temp_path, "h.dat")
    u_file = os.path.join(temp_path, "u.dat")
    v_file = os.path.join(temp_path, "v.dat")
    
    h = create_memory_mapped_array(h_file, (height, width))
    u = create_memory_mapped_array(u_file, (height, width))
    v = create_memory_mapped_array(v_file, (height, width))
    
    # Läs DEM i block för att minska minnesanvändning
    block_size = 1024  # Anpassa efter tillgängligt minne
    
    for y in range(0, height, block_size):
        y_size = min(block_size, height - y)
        for x in range(0, width, block_size):
            x_size = min(block_size, width - x)
            
            # Läs DEM-block
            dem_array = dem_ds.ReadAsArray(x, y, x_size, y_size)
            
            # Bearbeta blocket
            # ...
            
            # Skriv resultat till minnesmappade arrays
            h[y:y+y_size, x:x+x_size] = h_block
            u[y:y+y_size, x:x+x_size] = u_block
            v[y:y+y_size, x:x+x_size] = v_block
    
    # Stäng och rensa
    h.flush()
    u.flush()
    v.flush()
    dem_ds = None
    
    # Konvertera resultat till GeoTIFF
    # ...
    
    # Rensa temporära filer
    os.remove(h_file)
    os.remove(u_file)
    os.remove(v_file)
```

### Adaptiva beräkningstekniker

```python
class AdaptiveGrid:
    """Implementerar adaptiv grid för detaljerad beräkning där det behövs"""
    def __init__(self, base_dem, min_level=0, max_level=3):
        self.base_dem = base_dem
        self.min_level = min_level
        self.max_level = max_level
        self.grids = {}  # Dictionary för olika upplösningsnivåer
        
        # Skapa basgrid
        self.create_base_grid()
        
    def create_base_grid(self):
        """Skapar basgrid på lägsta nivån"""
        self.grids[self.min_level] = {
            'dem': self.base_dem,
            'h': np.zeros_like(self.base_dem),
            'u': np.zeros_like(self.base_dem),
            'v': np.zeros_like(self.base_dem),
            'cell_size': self.base_cell_size
        }
        
    def refine_grid(self, region, level):
        """Förfinar grid i angiven region till angiven nivå"""
        if level <= self.min_level or level > self.max_level:
            return
            
        if level not in self.grids:
            # Skapa ny gridnivå om den inte finns
            prev_grid = self.grids[level-1]
            cell_size = prev_grid['cell_size'] / 2
            
            # Interpolera DEM till högre upplösning
            dem_high_res = self.interpolate_dem(prev_grid['dem'], factor=2)
            
            self.grids[level] = {
                'dem': dem_high_res,
                'h': np.zeros_like(dem_high_res),
                'u': np.zeros_like(dem_high_res),
                'v': np.zeros_like(dem_high_res),
                'cell_size': cell_size,
                'regions': []  # Lista med aktiva regioner på denna nivå
            }
        
        # Lägg till region till aktiva regioner på denna nivå
        self.grids[level]['regions'].append(region)
```

## Testning och validering

För att säkerställa att implementationen är korrekt:

### Testfall för validering

```python
def validate_shallow_water_model():
    """Validera SWE-modellen mot analytiska lösningar"""
    # Testfall 1: Dammbrott med horisontell botten
    # Analytisk lösning finns tillgänglig för jämförelse
    
    # Testfall 2: Stående våg
    # Kontrollera att energin bevaras och att vågen oscillerar korrekt
    
    # Testfall 3: Kritiskt flöde över tröskel
    # Kontrollera att flödet övergår från subkritiskt till superkritiskt korrekt
```

### Regressionstest

```python
def regression_test(model_function, test_data_path, tolerance=1e-6):
    """Kör regressionstest med befintliga testdata"""
    # Ladda testindata
    test_input = load_test_data(test_data_path, "input")
    
    # Ladda förväntade resultat
    expected_output = load_test_data(test_data_path, "expected")
    
    # Kör modellen med testindata
    actual_output = model_function(test_input)
    
    # Jämför med förväntade resultat
    diff = np.abs(actual_output - expected_output)
    max_diff = np.max(diff)
    
    # Kontrollera om skillnaden är inom toleransgränsen
    if max_diff <= tolerance:
        print(f"Regressionstest godkänt: max diff = {max_diff}")
        return True
    else:
        print(f"Regressionstest misslyckat: max diff = {max_diff}")
        # Skriv ut detaljer om var de största skillnaderna finns
        max_idx = np.unravel_index(np.argmax(diff), diff.shape)
        print(f"Största skillnad vid {max_idx}: förväntat {expected_output[max_idx]}, faktiskt {actual_output[max_idx]}")
        return False
```

## Dokumentation och hjälpresurser

För att stödja användare:

### Användarguider

```python
def create_documentation():
    """Skapar användardokumentation"""
    # Skapa mappar för dokumentation
    os.makedirs("docs/user_guides", exist_ok=True)
    os.makedirs("docs/technical", exist_ok=True)
    os.makedirs("docs/examples", exist_ok=True)
    
    # Skapa användarguider
    create_user_guide("quick_start", "Kom igång med FloodEngine", 
                     ["installation", "basic_usage", "first_model"])
    
    create_user_guide("advanced_models", "Avancerade hydrauliska modeller",
                     ["swe_model", "sediment_transport", "groundwater", "meander", "urban"])
    
    # Skapa teknisk dokumentation
    create_technical_doc("model_equations", "Ekvationer och numeriska metoder")
    create_technical_doc("data_formats", "Dataformat och -struktur")
    
    # Skapa exempelprojekt
    create_example("simple_flood", "Enkel översvämningsmodellering")
    create_example("river_erosion", "Floderosion och meandring")
    create_example("urban_flood", "Urban översvämning med infrastruktur")
```

### Kontextuell hjälp i gränssnittet

```python
class HelpSystem:
    def __init__(self):
        self.help_texts = self.load_help_texts()
        
    def load_help_texts(self):
        """Laddar hjälptexter från resursfiler"""
        help_file = os.path.join("resources", "help_texts.json")
        with open(help_file, 'r', encoding='utf-8') as f:
            return json.load(f)
            
    def get_help_text(self, context, item=None):
        """Hämtar hjälptext för given kontext och objekt"""
        if context in self.help_texts:
            if item and item in self.help_texts[context]:
                return self.help_texts[context][item]
            elif not item:
                return self.help_texts[context].get("_general", "")
        return ""
        
    def show_context_help(self, parent, context, item=None):
        """Visar kontextuell hjälp i dialogruta"""
        help_text = self.get_help_text(context, item)
        if not help_text:
            return
            
        dialog = QDialog(parent)
        dialog.setWindowTitle("FloodEngine - Hjälp")
        layout = QVBoxLayout()
        
        text_browser = QTextBrowser()
        text_browser.setHtml(help_text)
        layout.addWidget(text_browser)
        
        close_btn = QPushButton("Stäng")
        close_btn.clicked.connect(dialog.accept)
        layout.addWidget(close_btn)
        
        dialog.setLayout(layout)
        dialog.exec_()
```

## Konklusioner och nästa steg

Denna implementationsplan beskriver en heltäckande strategi för att implementera avancerade hydrauliska modeller i FloodEngine 4.0 med fokus på användarvänlighet och minimal handpåläggning. Genom automatisk datahämtning, smart parameterisering och hierarkiska användargränssnitt kan pluginet erbjuda avancerad funktionalitet samtidigt som det förblir tillgängligt för användare på olika kunskapsnivåer.

### Nästa steg

1. **Prioritera implementationsordning** baserat på användarnytta och komplexitet
2. **Skapa separata grenar** i versionshanteringssystemet för olika moduler
3. **Implementera inkrementellt** med regelbundna tester och användartester
4. **Dokumentera kontinuerligt** under utvecklingsprocessen

Med denna approach kan FloodEngine utvecklas till ett kraftfullt verktyg för hydraulisk modellering som kombinerar avancerad funktionalitet med användarvänlighet och öppen källkod.
