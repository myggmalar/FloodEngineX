# Flow Direction Fix for FloodEngine

This file contains a fix for flow direction issues in the FloodEngine plugin, where water sometimes flows in the incorrect direction or uphill. The issue is particularly noticeable in the streamline generation and 2D hydraulic model.

## How to apply the fix:

1. Open the `flow_direction.py` file and add the new correction function at the top (after the imports):

```python
def ensure_correct_flow_directions(dem_array, water_depth, velocity_x, velocity_y):
    """
    Ensure that water flows correctly downhill by checking and adjusting velocity vectors.
    This is a critical fix for cases where mathematical approximations might cause incorrect flow.
    
    Parameters:
        dem_array (numpy.ndarray): Digital Elevation Model array
        water_depth (numpy.ndarray): Water depth array
        velocity_x (numpy.ndarray): X component of velocity
        velocity_y (numpy.ndarray): Y component of velocity
        
    Returns:
        tuple: Corrected velocity arrays (velocity_x, velocity_y)
    """
    rows, cols = dem_array.shape
    min_depth = 0.05  # Only consider cells with at least 5cm of water
    
    # Create water surface elevation array
    water_surface = dem_array + water_depth
    
    # Smooth the water surface slightly to reduce noise
    valid_mask = water_depth > min_depth
    smoothed_surface = np.copy(water_surface)
    if np.sum(valid_mask) > 0:  # Only smooth if we have water
        smoothed_surface[valid_mask] = gaussian_filter(
            water_surface[valid_mask], sigma=1.0)
    
    # Pad the surface for gradient calculation
    padded = np.pad(smoothed_surface, 1, mode='edge')
    
    # Calculate surface gradient (water flows from high to low)
    for i in range(1, rows-1):
        for j in range(1, cols-1):
            if water_depth[i, j] <= min_depth:
                continue
                
            # Calculate gradient of water surface using central difference
            dx = (padded[i+1, j+2] - padded[i+1, j]) / 2.0
            dy = (padded[i+2, j+1] - padded[i, j+1]) / 2.0
            
            # Check if velocity direction is consistent with surface gradient
            # If water is flowing uphill, reverse the direction
            if (dx * velocity_x[i, j] > 0) or (dy * velocity_y[i, j] > 0):
                # Velocity direction is wrong (water flowing uphill)
                # Correct the flow direction to follow the gradient
                grad_mag = np.sqrt(dx*dx + dy*dy)
                if grad_mag > 1e-6:
                    # Set velocity to flow downhill following the surface gradient
                    v_mag = np.sqrt(velocity_x[i, j]**2 + velocity_y[i, j]**2)
                    velocity_x[i, j] = -v_mag * (dx / grad_mag)
                    velocity_y[i, j] = -v_mag * (dy / grad_mag)
    
    return velocity_x, velocity_y
```

2. In the `saint_venant_2d.py` file, find the `_update_velocities` method and add the flow direction correction at the end:

```python
def _update_velocities(self):
    # Existing code...
    
    # Store velocity components for streamline calculation
    self.velocity_x = self.u.copy()
    self.velocity_y = self.v.copy()
    
    # Apply flow direction correction to ensure water flows downhill
    try:
        from flow_direction import ensure_correct_flow_directions
        self.velocity_x, self.velocity_y = ensure_correct_flow_directions(
            self.dem, self.h, self.velocity_x, self.velocity_y)
    except ImportError:
        # Fallback if flow_direction module cannot be imported
        pass
```

3. In the `model_hydraulic.py` file, find the `calculate_streamlines_with_speed` function and add the flow direction correction right after velocity calculation:

```python
# Find this block in each streamline function:
# After calculating the velocity field and before creating seed points
logger.info(f"[Streamlines] Calculated velocity field, max velocity: {np.nanmax(velocity_mag):.2f} m/s")

# Add this code after the line above:
# Fix: Apply flow direction correction to ensure water always flows downhill
try:
    from flow_direction import ensure_correct_flow_directions
    logger.info("[Streamlines] Applying flow direction correction")
    velocity_x, velocity_y = ensure_correct_flow_directions(
        dem_array, water_depth, velocity_x, velocity_y)
    
    # Recalculate velocity magnitude after correction
    velocity_mag = np.sqrt(velocity_x**2 + velocity_y**2)
    logger.info("[Streamlines] Flow direction correction applied")
except ImportError:
    logger.warning("[Streamlines] Could not import flow_direction module")
except Exception as e:
    logger.error(f"[Streamlines] Error in flow correction: {str(e)}")
```

## What this fix does:

1. Calculates the water surface elevation gradient correctly
2. Checks if the velocity vectors are consistent with the gradient
3. Corrects velocity vectors that are pointing in the wrong direction
4. Ensures water always flows downhill following the water surface gradient

This fix should resolve issues with water flowing in the wrong direction and improve the accuracy of streamline generation.
