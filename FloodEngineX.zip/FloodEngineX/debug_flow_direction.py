"""
Debug Flow Direction
------------------
Functions to verify and debug flow direction calculations
"""

import numpy as np
import random
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import os
import tempfile
from osgeo import gdal

def debug_flow_direction_sample(dem_array, flow_dir, sample_points=10):
    """Debug function to check if flow directions make sense"""
    import random
    
    valid_points = []
    for i in range(1, dem_array.shape[0]-1):
        for j in range(1, dem_array.shape[1]-1):
            if not np.isnan(dem_array[i, j]) and flow_dir[i, j] > 0:
                valid_points.append((i, j))
    
    # Sample random points
    if len(valid_points) == 0:
        print("No valid points found with flow direction!")
        return
    
    sample = random.sample(valid_points, min(sample_points, len(valid_points)))
    
    dir_map = {1: (0, 1), 2: (1, 1), 4: (1, 0), 8: (1, -1),
               16: (0, -1), 32: (-1, -1), 64: (-1, 0), 128: (-1, 1)}
    
    uphill_count = 0
    downhill_count = 0
    
    print("\n=== Flow Direction Verification ===")
    for i, j in sample:
        center_elev = dem_array[i, j]
        flow_code = flow_dir[i, j]
        
        if flow_code in dir_map:
            dr, dc = dir_map[flow_code]
            ni, nj = i + dr, j + dc
            neighbor_elev = dem_array[ni, nj]
            
            slope = (center_elev - neighbor_elev)
            print(f"Point ({i},{j}): elev={center_elev:.2f}, "
                  f"flows to ({ni},{nj}): elev={neighbor_elev:.2f}, "
                  f"slope={slope:.2f}")
            
            # Should be positive slope (downhill)
            if slope <= 0:
                print(f"  WARNING: Uphill flow detected!")
                uphill_count += 1
            else:
                downhill_count += 1
    
    print(f"\nVerification Results: {downhill_count} downhill flows, {uphill_count} uphill flows")
    if uphill_count > 0:
        print(f"WARNING: {uphill_count} of {uphill_count + downhill_count} flows are UPHILL!")
    else:
        print("SUCCESS: All flows are correctly flowing DOWNHILL!")
    
    return uphill_count, downhill_count

def visualize_flow_direction(dem_array, flow_dir, output_file=None):
    """Create a visualization of flow directions on the DEM"""
    if output_file is None:
        output_file = os.path.join(tempfile.gettempdir(), "flow_direction_debug.png")
    
    # Create figure
    fig = plt.figure(figsize=(12, 10))
    ax = fig.add_subplot(111, projection='3d')
    
    # Create a downsampled grid for arrows (too many makes it unreadable)
    rows, cols = dem_array.shape
    step = max(1, min(rows, cols) // 30)  # Adjust step size based on dem size
    
    # Direction mappings
    dir_map = {1: (0, 1), 2: (1, 1), 4: (1, 0), 8: (1, -1),
               16: (0, -1), 32: (-1, -1), 64: (-1, 0), 128: (-1, 1)}
    
    # Create grid for plotting
    X, Y = np.meshgrid(np.arange(0, cols, step), np.arange(0, rows, step))
    Z = np.zeros_like(X, dtype=float)
    U = np.zeros_like(X, dtype=float)
    V = np.zeros_like(X, dtype=float)
    
    for i in range(X.shape[0]):
        for j in range(X.shape[1]):
            r, c = Y[i, j], X[i, j]
            if r < rows and c < cols and not np.isnan(dem_array[r, c]):
                Z[i, j] = dem_array[r, c]
                flow_code = flow_dir[r, c]
                if flow_code in dir_map:
                    dr, dc = dir_map[flow_code]
                    # Scale arrows by slope if desired
                    nr, nc = r + dr, c + dc
                    if nr < rows and nc < cols and not np.isnan(dem_array[nr, nc]):
                        slope = max(0.1, dem_array[r, c] - dem_array[nr, nc])
                        U[i, j] = dc * slope
                        V[i, j] = dr * slope
    
    # Plot the DEM surface
    surf = ax.plot_surface(X, Y, Z, cmap='terrain', alpha=0.7, linewidth=0)
    
    # Plot flow direction arrows
    ax.quiver(X, Y, Z, U, V, np.zeros_like(U), length=step/2, normalize=True, 
              color='blue', arrow_length_ratio=0.5)
    
    # Set labels and title
    ax.set_xlabel('Column')
    ax.set_ylabel('Row')
    ax.set_zlabel('Elevation')
    ax.set_title('DEM with Flow Directions')
    
    # Add colorbar
    fig.colorbar(surf, ax=ax, shrink=0.5, aspect=5, label='Elevation')
    
    # Save figure
    plt.savefig(output_file, dpi=200, bbox_inches='tight')
    print(f"Flow direction visualization saved to: {output_file}")
    
    return output_file
