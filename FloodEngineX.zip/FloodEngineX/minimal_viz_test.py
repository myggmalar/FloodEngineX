#!/usr/bin/env python3
"""
Minimal test for FloodEngine visualization features
"""

print("Starting minimal visualization test...")

try:
    # Test basic import
    print("Testing import of advanced_visualization_features...")
    import advanced_visualization_features
    print("✅ Successfully imported advanced_visualization_features module")
    
    # Test visualization manager import
    from advanced_visualization_features import FloodEngineVisualizationManager
    print("✅ Successfully imported FloodEngineVisualizationManager")
    
    # Test manager initialization
    viz_manager = FloodEngineVisualizationManager("test_output")
    print("✅ Successfully initialized visualization manager")
    
    # Check capabilities
    print("\n📊 Checking available capabilities:")
    for capability, available in viz_manager.capabilities.items():
        status = "✅" if available else "⚠️"
        print(f"  {status} {capability}: {available}")
    
    print("\n🎉 Minimal visualization test completed successfully!")
    
except ImportError as e:
    print(f"❌ Import error: {e}")
    import traceback
    traceback.print_exc()
except Exception as e:
    print(f"❌ Unexpected error: {e}")
    import traceback
    traceback.print_exc()
