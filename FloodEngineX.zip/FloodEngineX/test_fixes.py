#!/usr/bin/env python3
"""
Test script to validate the FloodEngine plugin fixes
"""

import os
import sys

def test_ui_model_type_fix():
    """Test if model_type initialization is present in UI"""
    print("Testing UI model_type fix...")
    
    try:
        with open('floodengine_ui.py', 'r') as f:
            ui_content = f.read()
            
        # Check for model_type initialization
        if 'self.model_type = "2D Shallow Water"' in ui_content:
            print("✓ model_type initialization found in UI constructor")
            return True
        else:
            print("✗ model_type initialization NOT found")
            return False
            
    except Exception as e:
        print(f"✗ Error reading UI file: {e}")
        return False

def test_csv_safety_functions():
    """Test if CSV safety functions are present"""
    print("\nTesting CSV safety functions...")
    
    try:
        with open('model_hydraulic.py', 'r') as f:
            hydraulic_content = f.read()
            
        checks = [
            ('safe_csv_value_conversion', 'CSV value conversion safety'),
            ('load_and_integrate_bathymetry', 'Bathymetry loading integration'),
            ('create_bathymetry_tin_and_merge_with_dem', 'TIN creation with safety'),
            ('fix_nodata_handling', 'NoData handling fix'),
            ('create_proper_geotiff', 'Proper GeoTIFF creation'),
            ('generate_variable_water_levels', 'Variable water levels'),
            ('safe_streamlines_parameters', 'Safe streamlines parameters')
        ]
        
        results = []
        for func_name, description in checks:
            if f'def {func_name}(' in hydraulic_content:
                print(f"✓ {description} function found")
                results.append(True)
            else:
                print(f"✗ {description} function NOT found")
                results.append(False)
                
        return all(results)
        
    except Exception as e:
        print(f"✗ Error reading hydraulic model file: {e}")
        return False

def test_error_handling_patterns():
    """Test if error handling patterns are implemented"""
    print("\nTesting error handling patterns...")
    
    try:
        with open('model_hydraulic.py', 'r') as f:
            hydraulic_content = f.read()
            
        patterns = [
            ('try:', 'Exception handling blocks'),
            ('except', 'Exception catching'),
            ('ValueError', 'Value error handling'),
            ('TypeError', 'Type error handling'),
            ('logging.error', 'Error logging'),
            ('context=', 'Context tracking')
        ]
        
        results = []
        for pattern, description in patterns:
            count = hydraulic_content.count(pattern)
            if count > 0:
                print(f"✓ {description}: {count} instances found")
                results.append(True)
            else:
                print(f"✗ {description}: No instances found")
                results.append(False)
                
        return any(results)  # At least some error handling should be present
        
    except Exception as e:
        print(f"✗ Error analyzing error handling: {e}")
        return False

def test_file_integrity():
    """Test if all modified files exist and are valid Python"""
    print("\nTesting file integrity...")
    
    files_to_check = [
        'floodengine_ui.py',
        'model_hydraulic.py'
    ]
    
    results = []
    for filename in files_to_check:
        try:
            if os.path.exists(filename):
                # Try to compile the file to check syntax
                with open(filename, 'r') as f:
                    content = f.read()
                
                compile(content, filename, 'exec')
                print(f"✓ {filename}: File exists and has valid Python syntax")
                results.append(True)
            else:
                print(f"✗ {filename}: File does not exist")
                results.append(False)
                
        except SyntaxError as e:
            print(f"✗ {filename}: Syntax error at line {e.lineno}: {e.msg}")
            results.append(False)
        except Exception as e:
            print(f"✗ {filename}: Error checking file: {e}")
            results.append(False)
            
    return all(results)

def main():
    """Run all tests"""
    print("=" * 60)
    print("FLOODENGINE PLUGIN FIXES VALIDATION")
    print("=" * 60)
    
    # Change to the correct directory
    os.chdir(r"c:\Plugin\VSCode\FloodEngine_fixed_v8")
    
    tests = [
        ("File Integrity", test_file_integrity),
        ("UI Model Type Fix", test_ui_model_type_fix),
        ("CSV Safety Functions", test_csv_safety_functions),
        ("Error Handling Patterns", test_error_handling_patterns)
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        print(f"\n[TEST] {test_name}")
        print("-" * 40)
        
        try:
            if test_func():
                print(f"[PASS] {test_name}")
                passed += 1
            else:
                print(f"[FAIL] {test_name}")
        except Exception as e:
            print(f"[ERROR] {test_name}: {e}")
    
    print("\n" + "=" * 60)
    print(f"SUMMARY: {passed}/{total} tests passed")
    print("=" * 60)
    
    if passed == total:
        print("✓ All fixes are properly implemented!")
    else:
        print("✗ Some fixes may need attention")
    
    return passed == total

if __name__ == "__main__":
    main()
