#!/usr/bin/env python3
"""
HYDRAULIC FIX VERIFICATION SCRIPT
================================

This script verifies that the critical hardcoded water level issue 
has been properly fixed with Manning's equation hydraulic calculations.
"""

import os
import sys

def test_hardcoded_removal():
    """Test that hardcoded water levels have been removed"""
    print("🔍 TESTING: Hardcoded Water Level Removal")
    print("=" * 50)
    
    ui_files = [
        "floodengine_ui.py.normalized",
        "floodengine_ui.py"
    ]
    
    issues_found = []
    fixes_found = []
    
    for ui_file in ui_files:
        if not os.path.exists(ui_file):
            continue
            
        with open(ui_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Check for old hardcoded values
        hardcoded_patterns = [
            "initial_water_level = 60.0",
            "initial_water_level = 10.0", 
            "water_level = 10.0",
            "water_levels=[10.0]",
            "water_levels=[flow_q * 0.1]"
        ]
        
        for pattern in hardcoded_patterns:
            if pattern in content:
                issues_found.append(f"{ui_file}: {pattern}")
        
        # Check for hydraulic fixes
        hydraulic_patterns = [
            "calculate_water_level_from_flow",
            "from .model_hydraulic_q import",
            "Manning's equation",
            "hydraulically calculated"
        ]
        
        for pattern in hydraulic_patterns:
            if pattern in content:
                fixes_found.append(f"{ui_file}: {pattern}")
    
    # Report results
    if issues_found:
        print("❌ REMAINING HARDCODED VALUES FOUND:")
        for issue in issues_found:
            print(f"   {issue}")
    else:
        print("✅ No hardcoded water levels found")
    
    if fixes_found:
        print("✅ HYDRAULIC FIXES FOUND:")
        for fix in fixes_found:
            print(f"   {fix}")
    else:
        print("❌ No hydraulic fixes found")
    
    return len(issues_found) == 0 and len(fixes_found) > 0

def test_hydraulic_function_availability():
    """Test that the hydraulic calculation function is available"""
    print("\n🔍 TESTING: Hydraulic Function Availability")
    print("=" * 50)
    
    # Check if the hydraulic function file exists
    hydraulic_file = "model_hydraulic_q.py"
    if not os.path.exists(hydraulic_file):
        print(f"❌ Hydraulic file missing: {hydraulic_file}")
        return False
    
    with open(hydraulic_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check for Manning's equation implementation
    required_elements = [
        "def calculate_water_level_from_flow",
        "manning_n",
        "flow_q",
        "dem_path",
        "Manning's equation",
        "hydraulic_radius",
        "calculated_q",
        "slope"
    ]
    
    missing_elements = []
    for element in required_elements:
        if element not in content:
            missing_elements.append(element)
    
    if missing_elements:
        print("❌ MISSING HYDRAULIC ELEMENTS:")
        for element in missing_elements:
            print(f"   {element}")
        return False
    else:
        print("✅ All hydraulic elements found")
        return True

def test_ui_integration():
    """Test that UI properly integrates hydraulic calculations"""
    print("\n🔍 TESTING: UI Integration")
    print("=" * 50)
    
    normalized_ui = "floodengine_ui.py.normalized"
    if not os.path.exists(normalized_ui):
        print(f"❌ Main UI file missing: {normalized_ui}")
        return False
    
    with open(normalized_ui, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check for proper integration pattern
    integration_checks = [
        "from .model_hydraulic_q import calculate_water_level_from_flow",
        "calculate_water_level_from_flow(",
        "flow_q=flow_q",
        "dem_path=dem_path",
        "Hydraulically calculated"
    ]
    
    missing_integration = []
    for check in integration_checks:
        if check not in content:
            missing_integration.append(check)
    
    if missing_integration:
        print("❌ MISSING UI INTEGRATION:")
        for missing in missing_integration:
            print(f"   {missing}")
        return False
    else:
        print("✅ UI properly integrated with hydraulic calculations")
        return True

def main():
    """Main validation function"""
    print("🌊 HYDRAULIC FIX VALIDATION")
    print("=" * 60)
    print("Verifying that hardcoded water levels have been replaced")
    print("with proper Manning's equation hydraulic calculations.")
    print("=" * 60)
    
    # Run all tests
    test_results = []
    
    test_results.append(test_hardcoded_removal())
    test_results.append(test_hydraulic_function_availability()) 
    test_results.append(test_ui_integration())
    
    # Final summary
    print("\n" + "=" * 60)
    print("🎯 VALIDATION SUMMARY")
    print("=" * 60)
    
    if all(test_results):
        print("✅ ALL TESTS PASSED")
        print("🎉 HYDRAULIC FIX SUCCESSFULLY IMPLEMENTED!")
        print()
        print("✅ Hardcoded water levels eliminated")
        print("✅ Manning's equation calculations implemented")
        print("✅ UI properly integrated with hydraulic functions")
        print("✅ FloodEngine now uses scientific hydraulic modeling")
        print()
        print("The plugin is now hydraulically correct! 🌊")
        return 0
    else:
        print("❌ SOME TESTS FAILED")
        print("🔧 Additional fixes may be needed")
        failed_tests = sum(1 for result in test_results if not result)
        print(f"📊 {failed_tests}/{len(test_results)} tests failed")
        return 1

if __name__ == "__main__":
    sys.exit(main())
