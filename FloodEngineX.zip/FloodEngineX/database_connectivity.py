#!/usr/bin/env python3
"""
FloodEngine v4.0 - Database Connectivity Framework
=================================================

Professional database connectivity for FloodEngine providing:
- PostGIS spatial database integration
- SQLite project database management
- PostgreSQL enterprise database support
- MongoDB NoSQL data storage
- Database connection pooling and management
- Spatial data import/export capabilities
- Query optimization and indexing

Author: FloodEngine Development Team
Date: June 7, 2025
Version: 4.0
"""

import os
import sys
import json
import logging
import sqlite3
import time
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional, Any, Union
from dataclasses import dataclass, field
from pathlib import Path
import threading
from contextlib import contextmanager
import uuid

# Optional database drivers (will be imported if available)
try:
    import psycopg2
    from psycopg2 import pool
    from psycopg2.extras import RealDictCursor
    POSTGRES_AVAILABLE = True
except ImportError:
    POSTGRES_AVAILABLE = False

try:
    import pymongo
    MONGODB_AVAILABLE = True
except ImportError:
    MONGODB_AVAILABLE = False

# Spatial libraries
try:
    from shapely import wkt, wkb
    from shapely.geometry import Point, Polygon, LineString
    SHAPELY_AVAILABLE = True
except ImportError:
    SHAPELY_AVAILABLE = False

@dataclass
class DatabaseConfig:
    """Database connection configuration."""
    db_type: str  # 'sqlite', 'postgresql', 'mongodb'
    host: Optional[str] = None
    port: Optional[int] = None
    database: str = ""
    username: Optional[str] = None
    password: Optional[str] = None
    ssl_mode: Optional[str] = None
    connection_timeout: int = 30
    max_connections: int = 10
    min_connections: int = 1
    additional_params: Dict[str, Any] = field(default_factory=dict)

@dataclass
class QueryResult:
    """Container for database query results."""
    success: bool
    data: Optional[List[Dict[str, Any]]] = None
    row_count: int = 0
    execution_time: float = 0.0
    error_message: Optional[str] = None
    query_id: Optional[str] = None

class DatabaseConnectionManager:
    """Manages database connections with pooling support."""
    
    def __init__(self, config: DatabaseConfig):
        """Initialize database connection manager.
        
        Args:
            config: Database configuration
        """
        self.config = config
        self.logger = logging.getLogger(__name__)
        self._connection_pool = None
        self._lock = threading.Lock()
        
        # Initialize connection pool
        self._initialize_connection_pool()
    
    def _initialize_connection_pool(self):
        """Initialize database connection pool."""
        try:
            if self.config.db_type == 'postgresql' and POSTGRES_AVAILABLE:
                self._initialize_postgres_pool()
            elif self.config.db_type == 'sqlite':
                self._initialize_sqlite_pool()
            elif self.config.db_type == 'mongodb' and MONGODB_AVAILABLE:
                self._initialize_mongodb_pool()
            else:
                raise ValueError(f"Unsupported database type: {self.config.db_type}")
        
        except Exception as e:
            self.logger.error(f"Failed to initialize connection pool: {e}")
            raise
    
    def _initialize_postgres_pool(self):
        """Initialize PostgreSQL connection pool."""
        if not POSTGRES_AVAILABLE:
            raise ImportError("psycopg2 not available for PostgreSQL connections")
        
        connection_string = (
            f"host={self.config.host} "
            f"port={self.config.port} "
            f"database={self.config.database} "
            f"user={self.config.username} "
            f"password={self.config.password}"
        )
        
        if self.config.ssl_mode:
            connection_string += f" sslmode={self.config.ssl_mode}"
        
        self._connection_pool = psycopg2.pool.ThreadedConnectionPool(
            minconn=self.config.min_connections,
            maxconn=self.config.max_connections,
            dsn=connection_string,
            cursor_factory=RealDictCursor
        )
        
        self.logger.info("PostgreSQL connection pool initialized")
    
    def _initialize_sqlite_pool(self):
        """Initialize SQLite connection pool (simplified)."""
        # SQLite doesn't have traditional connection pooling
        # We'll manage connections manually
        self._connection_pool = {
            'db_path': self.config.database,
            'connections': {},
            'max_connections': self.config.max_connections
        }
        
        self.logger.info(f"SQLite connection manager initialized: {self.config.database}")
    
    def _initialize_mongodb_pool(self):
        """Initialize MongoDB connection pool."""
        if not MONGODB_AVAILABLE:
            raise ImportError("pymongo not available for MongoDB connections")
        
        connection_string = f"mongodb://"
        if self.config.username and self.config.password:
            connection_string += f"{self.config.username}:{self.config.password}@"
        
        connection_string += f"{self.config.host}:{self.config.port}/{self.config.database}"
        
        self._connection_pool = pymongo.MongoClient(
            connection_string,
            maxPoolSize=self.config.max_connections,
            minPoolSize=self.config.min_connections,
            serverSelectionTimeoutMS=self.config.connection_timeout * 1000
        )
        
        self.logger.info("MongoDB connection pool initialized")
    
    @contextmanager
    def get_connection(self):
        """Get database connection from pool."""
        connection = None
        try:
            if self.config.db_type == 'postgresql':
                connection = self._connection_pool.getconn()
                yield connection
            
            elif self.config.db_type == 'sqlite':
                # For SQLite, create connection on demand
                connection = sqlite3.connect(
                    self.config.database,
                    timeout=self.config.connection_timeout
                )
                connection.row_factory = sqlite3.Row
                yield connection
            
            elif self.config.db_type == 'mongodb':
                # MongoDB connection is always available
                yield self._connection_pool[self.config.database]
            
        except Exception as e:
            self.logger.error(f"Database connection error: {e}")
            raise
        
        finally:
            if connection:
                if self.config.db_type == 'postgresql':
                    self._connection_pool.putconn(connection)
                elif self.config.db_type == 'sqlite':
                    connection.close()
    
    def test_connection(self) -> bool:
        """Test database connection."""
        try:
            with self.get_connection() as conn:
                if self.config.db_type in ['postgresql', 'sqlite']:
                    cursor = conn.cursor()
                    cursor.execute("SELECT 1")
                    cursor.fetchone()
                elif self.config.db_type == 'mongodb':
                    conn.command('ping')
                
                self.logger.info("Database connection test successful")
                return True
        
        except Exception as e:
            self.logger.error(f"Database connection test failed: {e}")
            return False
    
    def close_all_connections(self):
        """Close all connections in pool."""
        try:
            if self.config.db_type == 'postgresql' and self._connection_pool:
                self._connection_pool.closeall()
            elif self.config.db_type == 'mongodb' and self._connection_pool:
                self._connection_pool.close()
            
            self.logger.info("All database connections closed")
        
        except Exception as e:
            self.logger.error(f"Error closing connections: {e}")

class SpatialDatabaseManager:
    """Manager for spatial database operations."""
    
    def __init__(self, connection_manager: DatabaseConnectionManager):
        """Initialize spatial database manager.
        
        Args:
            connection_manager: Database connection manager
        """
        self.connection_manager = connection_manager
        self.logger = logging.getLogger(__name__)
        
        # Check if spatial extensions are available
        self.spatial_enabled = self._check_spatial_support()
    
    def _check_spatial_support(self) -> bool:
        """Check if spatial functions are available."""
        try:
            if self.connection_manager.config.db_type == 'postgresql':
                return self._check_postgis()
            elif self.connection_manager.config.db_type == 'sqlite':
                return self._check_spatialite()
            else:
                return False
        
        except Exception as e:
            self.logger.warning(f"Could not check spatial support: {e}")
            return False
    
    def _check_postgis(self) -> bool:
        """Check if PostGIS extension is available."""
        try:
            with self.connection_manager.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT PostGIS_Version();")
                version = cursor.fetchone()[0]
                self.logger.info(f"PostGIS version: {version}")
                return True
        
        except Exception:
            self.logger.warning("PostGIS extension not available")
            return False
    
    def _check_spatialite(self) -> bool:
        """Check if SpatiaLite extension is available."""
        try:
            with self.connection_manager.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT spatialite_version();")
                version = cursor.fetchone()[0]
                self.logger.info(f"SpatiaLite version: {version}")
                return True
        
        except Exception:
            self.logger.warning("SpatiaLite extension not available")
            return False
    
    def create_spatial_table(self, table_name: str, 
                           geometry_type: str = 'GEOMETRY',
                           srid: int = 4326,
                           additional_columns: Dict[str, str] = None) -> bool:
        """Create spatial table with geometry column.
        
        Args:
            table_name: Name of table to create
            geometry_type: Type of geometry (POINT, POLYGON, etc.)
            srid: Spatial reference system ID
            additional_columns: Additional columns to create
        
        Returns:
            True if successful
        """
        try:
            additional_columns = additional_columns or {}
            
            if self.connection_manager.config.db_type == 'postgresql':
                return self._create_postgis_table(
                    table_name, geometry_type, srid, additional_columns
                )
            elif self.connection_manager.config.db_type == 'sqlite':
                return self._create_spatialite_table(
                    table_name, geometry_type, srid, additional_columns
                )
            else:
                self.logger.error("Spatial tables not supported for this database type")
                return False
        
        except Exception as e:
            self.logger.error(f"Failed to create spatial table: {e}")
            return False
    
    def _create_postgis_table(self, table_name: str, geometry_type: str,
                            srid: int, additional_columns: Dict[str, str]) -> bool:
        """Create PostGIS spatial table."""
        
        with self.connection_manager.get_connection() as conn:
            cursor = conn.cursor()
            
            # Create base table
            columns = ['id SERIAL PRIMARY KEY']
            columns.extend([f"{col} {dtype}" for col, dtype in additional_columns.items()])
            
            create_sql = f"""
                CREATE TABLE {table_name} (
                    {', '.join(columns)}
                );
            """
            
            cursor.execute(create_sql)
            
            # Add geometry column
            cursor.execute(f"""
                SELECT AddGeometryColumn('{table_name}', 'geom', {srid}, 
                                       '{geometry_type}', 2);
            """)
            
            # Create spatial index
            cursor.execute(f"""
                CREATE INDEX idx_{table_name}_geom 
                ON {table_name} USING GIST (geom);
            """)
            
            conn.commit()
            self.logger.info(f"PostGIS table '{table_name}' created successfully")
            return True
    
    def _create_spatialite_table(self, table_name: str, geometry_type: str,
                               srid: int, additional_columns: Dict[str, str]) -> bool:
        """Create SpatiaLite spatial table."""
        
        with self.connection_manager.get_connection() as conn:
            cursor = conn.cursor()
            
            # Create base table
            columns = ['id INTEGER PRIMARY KEY AUTOINCREMENT']
            columns.extend([f"{col} {dtype}" for col, dtype in additional_columns.items()])
            
            create_sql = f"""
                CREATE TABLE {table_name} (
                    {', '.join(columns)}
                );
            """
            
            cursor.execute(create_sql)
            
            # Add geometry column
            cursor.execute(f"""
                SELECT AddGeometryColumn('{table_name}', 'geom', {srid}, 
                                       '{geometry_type}', 'XY');
            """)
            
            # Create spatial index
            cursor.execute(f"""
                SELECT CreateSpatialIndex('{table_name}', 'geom');
            """)
            
            conn.commit()
            self.logger.info(f"SpatiaLite table '{table_name}' created successfully")
            return True
    
    def insert_geometry(self, table_name: str, geometry_wkt: str,
                       attributes: Dict[str, Any] = None,
                       srid: int = 4326) -> bool:
        """Insert geometry into spatial table.
        
        Args:
            table_name: Target table name
            geometry_wkt: Geometry in WKT format
            attributes: Additional attribute values
            srid: Spatial reference system ID
        
        Returns:
            True if successful
        """
        try:
            attributes = attributes or {}
            
            if self.connection_manager.config.db_type == 'postgresql':
                return self._insert_postgis_geometry(
                    table_name, geometry_wkt, attributes, srid
                )
            elif self.connection_manager.config.db_type == 'sqlite':
                return self._insert_spatialite_geometry(
                    table_name, geometry_wkt, attributes, srid
                )
            else:
                return False
        
        except Exception as e:
            self.logger.error(f"Failed to insert geometry: {e}")
            return False
    
    def _insert_postgis_geometry(self, table_name: str, geometry_wkt: str,
                               attributes: Dict[str, Any], srid: int) -> bool:
        """Insert geometry into PostGIS table."""
        
        with self.connection_manager.get_connection() as conn:
            cursor = conn.cursor()
            
            # Prepare column names and values
            columns = list(attributes.keys()) + ['geom']
            values = list(attributes.values())
            
            # Create SQL with proper geometry transformation
            placeholders = ', '.join(['%s'] * len(attributes))
            if placeholders:
                placeholders += ', '
            
            sql = f"""
                INSERT INTO {table_name} ({', '.join(columns)})
                VALUES ({placeholders}ST_GeomFromText(%s, {srid}))
            """
            
            cursor.execute(sql, values + [geometry_wkt])
            conn.commit()
            
            return True
    
    def _insert_spatialite_geometry(self, table_name: str, geometry_wkt: str,
                                  attributes: Dict[str, Any], srid: int) -> bool:
        """Insert geometry into SpatiaLite table."""
        
        with self.connection_manager.get_connection() as conn:
            cursor = conn.cursor()
            
            columns = list(attributes.keys()) + ['geom']
            values = list(attributes.values())
            
            placeholders = ', '.join(['?'] * len(attributes))
            if placeholders:
                placeholders += ', '
            
            sql = f"""
                INSERT INTO {table_name} ({', '.join(columns)})
                VALUES ({placeholders}GeomFromText(?, {srid}))
            """
            
            cursor.execute(sql, values + [geometry_wkt])
            conn.commit()
            
            return True
    
    def query_spatial_bbox(self, table_name: str,
                         bbox: Tuple[float, float, float, float],
                         srid: int = 4326) -> List[Dict[str, Any]]:
        """Query features within bounding box.
        
        Args:
            table_name: Table to query
            bbox: Bounding box (min_x, min_y, max_x, max_y)
            srid: Spatial reference system ID
        
        Returns:
            List of feature dictionaries
        """
        try:
            min_x, min_y, max_x, max_y = bbox
            
            if self.connection_manager.config.db_type == 'postgresql':
                return self._query_postgis_bbox(table_name, bbox, srid)
            elif self.connection_manager.config.db_type == 'sqlite':
                return self._query_spatialite_bbox(table_name, bbox, srid)
            else:
                return []
        
        except Exception as e:
            self.logger.error(f"Spatial bbox query failed: {e}")
            return []
    
    def _query_postgis_bbox(self, table_name: str,
                          bbox: Tuple[float, float, float, float],
                          srid: int) -> List[Dict[str, Any]]:
        """Query PostGIS table with bounding box."""
        
        min_x, min_y, max_x, max_y = bbox
        
        with self.connection_manager.get_connection() as conn:
            cursor = conn.cursor()
            
            sql = f"""
                SELECT *, ST_AsText(geom) as geometry_wkt
                FROM {table_name}
                WHERE geom && ST_MakeEnvelope(%s, %s, %s, %s, {srid})
            """
            
            cursor.execute(sql, [min_x, min_y, max_x, max_y])
            
            return [dict(row) for row in cursor.fetchall()]
    
    def _query_spatialite_bbox(self, table_name: str,
                             bbox: Tuple[float, float, float, float],
                             srid: int) -> List[Dict[str, Any]]:
        """Query SpatiaLite table with bounding box."""
        
        min_x, min_y, max_x, max_y = bbox
        
        with self.connection_manager.get_connection() as conn:
            cursor = conn.cursor()
            
            sql = f"""
                SELECT *, AsText(geom) as geometry_wkt
                FROM {table_name}
                WHERE MbrIntersects(geom, BuildMbr(?, ?, ?, ?, {srid}))
            """
            
            cursor.execute(sql, [min_x, min_y, max_x, max_y])
            
            # Convert sqlite3.Row to dict
            columns = [description[0] for description in cursor.description]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]

class FloodEngineProjectDatabase:
    """Project-specific database for FloodEngine simulations."""
    
    def __init__(self, project_name: str, database_config: DatabaseConfig = None):
        """Initialize project database.
        
        Args:
            project_name: Name of the flood modeling project
            database_config: Database configuration (uses SQLite by default)
        """
        self.project_name = project_name
        self.logger = logging.getLogger(__name__)
        
        # Use SQLite by default for project databases
        if database_config is None:
            project_db_path = f"{project_name}_floodengine.db"
            database_config = DatabaseConfig(
                db_type='sqlite',
                database=project_db_path
            )
        
        self.connection_manager = DatabaseConnectionManager(database_config)
        self.spatial_manager = SpatialDatabaseManager(self.connection_manager)
        
        # Initialize project database schema
        self._initialize_project_schema()
    
    def _initialize_project_schema(self):
        """Initialize database schema for FloodEngine project."""
        try:
            # Create project metadata table
            self._create_project_tables()
            
            # Create spatial tables if supported
            if self.spatial_manager.spatial_enabled:
                self._create_spatial_tables()
            
            self.logger.info(f"Project database '{self.project_name}' initialized")
        
        except Exception as e:
            self.logger.error(f"Failed to initialize project schema: {e}")
            raise
    
    def _create_project_tables(self):
        """Create non-spatial project tables."""
        
        with self.connection_manager.get_connection() as conn:
            cursor = conn.cursor()
            
            # Project metadata
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS project_metadata (
                    id INTEGER PRIMARY KEY,
                    project_name TEXT NOT NULL,
                    created_date TEXT NOT NULL,
                    modified_date TEXT NOT NULL,
                    description TEXT,
                    extent_min_x REAL,
                    extent_min_y REAL,
                    extent_max_x REAL,
                    extent_max_y REAL,
                    coordinate_system TEXT DEFAULT 'EPSG:4326'
                )
            """)
            
            # Simulation runs
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS simulation_runs (
                    id INTEGER PRIMARY KEY,
                    run_name TEXT NOT NULL,
                    created_date TEXT NOT NULL,
                    parameters TEXT,
                    status TEXT DEFAULT 'pending',
                    execution_time REAL,
                    output_files TEXT,
                    error_message TEXT
                )
            """)
            
            # Model parameters
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS model_parameters (
                    id INTEGER PRIMARY KEY,
                    simulation_run_id INTEGER,
                    parameter_name TEXT NOT NULL,
                    parameter_value TEXT NOT NULL,
                    parameter_type TEXT DEFAULT 'string',
                    FOREIGN KEY (simulation_run_id) REFERENCES simulation_runs (id)
                )
            """)
            
            # Results metadata
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS simulation_results (
                    id INTEGER PRIMARY KEY,
                    simulation_run_id INTEGER,
                    result_type TEXT NOT NULL,
                    file_path TEXT,
                    statistics TEXT,
                    created_date TEXT NOT NULL,
                    FOREIGN KEY (simulation_run_id) REFERENCES simulation_runs (id)
                )
            """)
            
            conn.commit()
            self.logger.info("Project tables created successfully")
    
    def _create_spatial_tables(self):
        """Create spatial tables for project."""
        
        # Study area boundary
        self.spatial_manager.create_spatial_table(
            'study_area',
            'POLYGON',
            4326,
            {
                'name': 'TEXT',
                'area_sqkm': 'REAL',
                'description': 'TEXT'
            }
        )
        
        # Flood boundary results
        self.spatial_manager.create_spatial_table(
            'flood_boundaries',
            'POLYGON',
            4326,
            {
                'simulation_run_id': 'INTEGER',
                'return_period': 'INTEGER',
                'max_depth': 'REAL',
                'area_sqkm': 'REAL'
            }
        )
        
        # Point observations
        self.spatial_manager.create_spatial_table(
            'observation_points',
            'POINT',
            4326,
            {
                'station_id': 'TEXT',
                'station_name': 'TEXT',
                'elevation': 'REAL',
                'data_type': 'TEXT'
            }
        )
        
        self.logger.info("Spatial tables created successfully")
    
    def save_simulation_run(self, run_name: str, parameters: Dict[str, Any],
                          status: str = 'pending') -> int:
        """Save simulation run to database.
        
        Args:
            run_name: Name of simulation run
            parameters: Simulation parameters
            status: Current status
        
        Returns:
            Simulation run ID
        """
        try:
            with self.connection_manager.get_connection() as conn:
                cursor = conn.cursor()
                
                # Insert simulation run
                cursor.execute("""
                    INSERT INTO simulation_runs 
                    (run_name, created_date, parameters, status)
                    VALUES (?, ?, ?, ?)
                """, [
                    run_name,
                    datetime.now().isoformat(),
                    json.dumps(parameters),
                    status
                ])
                
                run_id = cursor.lastrowid
                
                # Insert individual parameters
                for param_name, param_value in parameters.items():
                    cursor.execute("""
                        INSERT INTO model_parameters
                        (simulation_run_id, parameter_name, parameter_value, parameter_type)
                        VALUES (?, ?, ?, ?)
                    """, [
                        run_id,
                        param_name,
                        str(param_value),
                        type(param_value).__name__
                    ])
                
                conn.commit()
                self.logger.info(f"Simulation run '{run_name}' saved with ID: {run_id}")
                return run_id
        
        except Exception as e:
            self.logger.error(f"Failed to save simulation run: {e}")
            raise
    
    def update_simulation_status(self, run_id: int, status: str,
                               execution_time: float = None,
                               error_message: str = None):
        """Update simulation run status.
        
        Args:
            run_id: Simulation run ID
            status: New status
            execution_time: Execution time in seconds
            error_message: Error message if failed
        """
        try:
            with self.connection_manager.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute("""
                    UPDATE simulation_runs
                    SET status = ?, execution_time = ?, error_message = ?
                    WHERE id = ?
                """, [status, execution_time, error_message, run_id])
                
                conn.commit()
                self.logger.info(f"Simulation run {run_id} status updated to: {status}")
        
        except Exception as e:
            self.logger.error(f"Failed to update simulation status: {e}")
            raise
    
    def save_flood_boundary(self, simulation_run_id: int, 
                          boundary_wkt: str,
                          return_period: int,
                          max_depth: float,
                          area_sqkm: float):
        """Save flood boundary to spatial table.
        
        Args:
            simulation_run_id: ID of simulation run
            boundary_wkt: Flood boundary in WKT format
            return_period: Return period (years)
            max_depth: Maximum flood depth (meters)
            area_sqkm: Flooded area (square kilometers)
        """
        try:
            attributes = {
                'simulation_run_id': simulation_run_id,
                'return_period': return_period,
                'max_depth': max_depth,
                'area_sqkm': area_sqkm
            }
            
            success = self.spatial_manager.insert_geometry(
                'flood_boundaries',
                boundary_wkt,
                attributes
            )
            
            if success:
                self.logger.info(f"Flood boundary saved for simulation {simulation_run_id}")
            else:
                self.logger.error("Failed to save flood boundary")
        
        except Exception as e:
            self.logger.error(f"Failed to save flood boundary: {e}")
            raise
    
    def get_simulation_history(self) -> List[Dict[str, Any]]:
        """Get simulation run history.
        
        Returns:
            List of simulation run records
        """
        try:
            with self.connection_manager.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute("""
                    SELECT id, run_name, created_date, status, execution_time,
                           error_message
                    FROM simulation_runs
                    ORDER BY created_date DESC
                """)
                
                if self.connection_manager.config.db_type == 'sqlite':
                    columns = [description[0] for description in cursor.description]
                    return [dict(zip(columns, row)) for row in cursor.fetchall()]
                else:
                    return [dict(row) for row in cursor.fetchall()]
        
        except Exception as e:
            self.logger.error(f"Failed to get simulation history: {e}")
            return []
    
    def query_flood_boundaries_by_area(self, bbox: Tuple[float, float, float, float]) -> List[Dict[str, Any]]:
        """Query flood boundaries within bounding box.
        
        Args:
            bbox: Bounding box (min_x, min_y, max_x, max_y)
        
        Returns:
            List of flood boundary records
        """
        if not self.spatial_manager.spatial_enabled:
            self.logger.warning("Spatial queries not available")
            return []
        
        return self.spatial_manager.query_spatial_bbox('flood_boundaries', bbox)
    
    def export_project_data(self, output_file: str) -> bool:
        """Export project data to file.
        
        Args:
            output_file: Output file path
        
        Returns:
            True if successful
        """
        try:
            project_data = {
                'project_name': self.project_name,
                'export_date': datetime.now().isoformat(),
                'simulation_history': self.get_simulation_history(),
                'spatial_data_available': self.spatial_manager.spatial_enabled
            }
            
            with open(output_file, 'w') as f:
                json.dump(project_data, f, indent=2, default=str)
            
            self.logger.info(f"Project data exported to: {output_file}")
            return True
        
        except Exception as e:
            self.logger.error(f"Failed to export project data: {e}")
            return False

def create_project_database(project_name: str, 
                          database_type: str = 'sqlite',
                          connection_params: Dict[str, Any] = None) -> FloodEngineProjectDatabase:
    """Create new FloodEngine project database.
    
    Args:
        project_name: Name of the project
        database_type: Type of database ('sqlite', 'postgresql')
        connection_params: Database connection parameters
    
    Returns:
        FloodEngineProjectDatabase instance
    """
    connection_params = connection_params or {}
    
    if database_type == 'sqlite':
        config = DatabaseConfig(
            db_type='sqlite',
            database=f"{project_name}_floodengine.db"
        )
    elif database_type == 'postgresql':
        config = DatabaseConfig(
            db_type='postgresql',
            **connection_params
        )
    else:
        raise ValueError(f"Unsupported database type: {database_type}")
    
    return FloodEngineProjectDatabase(project_name, config)

def main():
    """Example usage of database connectivity."""
    
    print("FloodEngine v4.0 - Database Connectivity Framework")
    print("=" * 50)
    
    try:
        # Create test project database
        project_db = create_project_database("test_flood_project")
        
        # Test basic functionality
        print("✓ Project database created")
        
        # Save test simulation run
        test_params = {
            'dem_file': 'test_dem.tif',
            'flow_rate': 100.0,
            'duration': 3600,
            'time_step': 1.0
        }
        
        run_id = project_db.save_simulation_run("Test Run 1", test_params)
        print(f"✓ Simulation run saved with ID: {run_id}")
        
        # Update status
        project_db.update_simulation_status(run_id, "completed", 45.2)
        print("✓ Simulation status updated")
        
        # Get history
        history = project_db.get_simulation_history()
        print(f"✓ Retrieved {len(history)} simulation runs")
        
        # Test spatial functionality if available
        if project_db.spatial_manager.spatial_enabled:
            print("✓ Spatial database features available")
            
            # Example flood boundary
            test_boundary = "POLYGON((-74.1 40.7, -74.0 40.7, -74.0 40.8, -74.1 40.8, -74.1 40.7))"
            project_db.save_flood_boundary(run_id, test_boundary, 100, 2.5, 1.2)
            print("✓ Flood boundary saved")
        
        print("\nDatabase connectivity test completed successfully!")
        
    except Exception as e:
        print(f"Database test failed: {e}")

if __name__ == "__main__":
    main()
