#!/usr/bin/env python3
"""
Test script to debug channel-based flood algorithm
"""

import os
import sys
import numpy as np
from osgeo import gdal

# Add the plugin directory to the path
plugin_dir = r"c:\Plugin\VSCode\Alt2\FloodEngine_fixed_v8"
if plugin_dir not in sys.path:
    sys.path.insert(0, plugin_dir)

def test_channel_flood_algorithm():
    """Test the new channel-based flood algorithm"""
    
    print("🧪 TESTING CHANNEL-BASED FLOOD ALGORITHM")
    print("=" * 50)
    
    # Import the modules
    try:
        from model_hydraulic_q import calculate_water_level_from_flow
        from model_hydraulic import create_proper_flow_flood_mask
        print("✅ Successfully imported flood modules")
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False
    
    # Test with a sample DEM (you'll need to provide a path to your DEM)
    dem_path = r"C:\path\to\your\dem.tif"  # UPDATE THIS PATH
    
    if not os.path.exists(dem_path):
        print(f"⚠️ DEM file not found: {dem_path}")
        print("Please update the dem_path variable in this script")
        return False
    
    try:
        # Test water level calculation
        print("\n1. Testing water level calculation...")
        flow_q = 100.0  # m³/s
        water_level = calculate_water_level_from_flow(flow_q, dem_path)
        print(f"   Flow rate: {flow_q} m³/s → Water level: {water_level:.2f}m")
        
        # Load DEM for flood mask testing
        print("\n2. Testing flood mask creation...")
        dem_ds = gdal.Open(dem_path)
        dem_array = dem_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
        nodata = dem_ds.GetRasterBand(1).GetNoDataValue()
        if nodata is None:
            nodata = -9999
        
        # Create valid mask
        valid_mask = (dem_array != nodata) & ~np.isnan(dem_array)
        
        # Test flood mask
        flood_mask = create_proper_flow_flood_mask(dem_array, water_level, valid_mask)
        
        # Analyze results
        total_flooded = np.sum(flood_mask)
        total_valid = np.sum(valid_mask)
        flood_percentage = (total_flooded / total_valid) * 100
        
        print(f"\n📊 FLOOD ANALYSIS RESULTS:")
        print(f"   Total valid cells: {total_valid}")
        print(f"   Flooded cells: {total_flooded}")
        print(f"   Flood coverage: {flood_percentage:.2f}% of valid area")
        
        if total_flooded > 0:
            flooded_elevations = dem_array[flood_mask == 1]
            min_flood = np.min(flooded_elevations)
            max_flood = np.max(flooded_elevations)
            avg_flood = np.mean(flooded_elevations)
            
            print(f"   Flooded elevation range: {min_flood:.2f}m to {max_flood:.2f}m")
            print(f"   Average flooded elevation: {avg_flood:.2f}m")
            print(f"   Water level: {water_level:.2f}m")
            print(f"   Clearance above avg flood: {water_level - avg_flood:.2f}m")
            
            # DEM statistics
            dem_min = np.nanmin(dem_array[valid_mask])
            dem_max = np.nanmax(dem_array[valid_mask])
            dem_median = np.nanmedian(dem_array[valid_mask])
            
            print(f"\n📊 DEM STATISTICS:")
            print(f"   DEM range: {dem_min:.2f}m to {dem_max:.2f}m")
            print(f"   DEM median: {dem_median:.2f}m")
            print(f"   Water level vs median: {water_level - dem_median:.2f}m")
            
            # Check if flooding is realistic
            if avg_flood < water_level - 0.5 and max_flood < water_level:
                print(f"\n✅ REALISTIC FLOOD PATTERN DETECTED")
                print(f"   - Flooding stays below water level")
                print(f"   - Average flood elevation well below water surface")
                print(f"   - Likely following natural drainage")
            else:
                print(f"\n⚠️ POTENTIAL ISSUES:")
                if max_flood >= water_level:
                    print(f"   - Some flooding at or above water level")
                if avg_flood >= water_level - 0.5:
                    print(f"   - Average flooding too close to water level")
        else:
            print("\n❌ NO FLOODING OCCURRED")
            print("   Check if water level is too low or DEM has issues")
        
        print(f"\n✅ Test completed successfully")
        return True
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    # Update this path to point to your actual DEM file
    print("NOTE: Update the dem_path variable in this script to test with your DEM")
    test_channel_flood_algorithm()
