#!/usr/bin/env python3
"""
Simple Animation Controls Test
=============================
This creates a quick test to verify animation controls are working.
"""

import sys
import os
import numpy as np
from pathlib import Path

# Add FloodEngineX to path
script_dir = Path(__file__).parent
sys.path.insert(0, str(script_dir))

def test_simple_simulation():
    """Run a simple 2-hour vs 10-hour test to verify time stepping is working."""
    print("🧪 Testing time stepping fix...")
    
    try:
        from saint_venant_2d import simulate_saint_venant_2d
        import tempfile
        
        # Create a simple test DEM
        test_dem_path = "test_dem.tif"
        create_test_dem(test_dem_path)
        
        # Test 1: 10 timesteps over 2 hours (7200 seconds)
        print("\n📊 Test 1: 10 timesteps over 2 hours...")
        temp_dir1 = tempfile.mkdtemp(prefix='flood_test_2h_')
        
        results_2h = simulate_saint_venant_2d(
            dem_path=test_dem_path,
            water_level=102.0,
            output_folder=temp_dir1,
            time_steps=10,
            total_time=7200,  # 2 hours
            manning_n=0.035
        )
        
        # Test 2: 10 timesteps over 10 hours (36000 seconds)
        print("\n📊 Test 2: 10 timesteps over 10 hours...")
        temp_dir2 = tempfile.mkdtemp(prefix='flood_test_10h_')
        
        results_10h = simulate_saint_venant_2d(
            dem_path=test_dem_path,
            water_level=102.0,
            output_folder=temp_dir2,
            time_steps=10,
            total_time=36000,  # 10 hours
            manning_n=0.035
        )
        
        # Compare results
        print("\n📈 Comparing results...")
        
        times_2h = results_2h['times']
        times_10h = results_10h['times']
        
        depths_2h = [np.max(d) for d in results_2h['water_depths']]
        depths_10h = [np.max(d) for d in results_10h['water_depths']]
        
        print(f"2-hour simulation times: {[f'{t:.0f}s' for t in times_2h]}")
        print(f"10-hour simulation times: {[f'{t:.0f}s' for t in times_10h]}")
        
        print(f"2-hour max depths: {[f'{d:.3f}m' for d in depths_2h]}")
        print(f"10-hour max depths: {[f'{d:.3f}m' for d in depths_10h]}")
        
        # Check if results are different (they should be!)
        final_depth_2h = depths_2h[-1]
        final_depth_10h = depths_10h[-1]
        
        if abs(final_depth_2h - final_depth_10h) > 0.001:
            print("✅ GOOD: Results are different between 2h and 10h simulations")
            print(f"   Final depth difference: {abs(final_depth_2h - final_depth_10h):.3f}m")
        else:
            print("❌ PROBLEM: Results are identical - time stepping may still be broken")
        
        # Test animation launch
        print("\n🎬 Testing animation controls...")
        
        try:
            from PyQt5.QtWidgets import QApplication
            from time_series_animator import TimeSeriesAnimator
            
            app = QApplication.instance()
            if app is None:
                app = QApplication(sys.argv)
            
            # Test with 2-hour results
            print(f"📁 Launching animation for 2-hour simulation: {temp_dir1}")
            
            animator = TimeSeriesAnimator(results_2h, temp_dir1)
            animator.setWindowTitle("FloodEngine Test - 2 Hours, 10 Timesteps")
            animator.resize(900, 700)
            animator.show()
            animator.raise_()
            animator.activateWindow()
            
            print("✅ Animation controls launched!")
            print("🎮 You should see:")
            print("   - Play/Pause buttons")
            print("   - Timeline slider with 10 positions")
            print("   - Time display showing 0s to 7200s")
            print("   - Animation controls panel")
            
            # Keep reference to prevent garbage collection
            app._test_animator = animator
            
            return app.exec_()
            
        except Exception as e:
            print(f"❌ Animation test failed: {e}")
            import traceback
            traceback.print_exc()
            return False
        
        # Clean up
        os.remove(test_dem_path)
        
    except Exception as e:
        print(f"❌ Simulation test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def create_test_dem(output_path):
    """Create a simple test DEM."""
    try:
        from osgeo import gdal
        import numpy as np
        
        # Create simple valley DEM
        nx, ny = 100, 80
        x = np.linspace(0, 1000, nx)
        y = np.linspace(0, 800, ny)
        X, Y = np.meshgrid(x, y)
        
        # Valley running east-west
        valley_depth = 5 * np.exp(-((Y - 400)**2) / (2 * 100**2))
        base_elevation = 100 + 0.002 * X  # Gentle slope
        dem = base_elevation - valley_depth
        
        # Create GeoTIFF
        driver = gdal.GetDriverByName('GTiff')
        dataset = driver.Create(output_path, nx, ny, 1, gdal.GDT_Float32)
        
        # Set geotransform (10m pixels)
        geotransform = (0, 10, 0, 800, 0, -10)
        dataset.SetGeoTransform(geotransform)
        
        # Set projection
        srs_wkt = '''GEOGCS["WGS 84",DATUM["WGS_1984",SPHEROID["WGS 84",6378137,298.257223563]],PRIMEM["Greenwich",0],UNIT["degree",0.0174532925199433]]'''
        dataset.SetProjection(srs_wkt)
        
        # Write data
        band = dataset.GetRasterBand(1)
        band.WriteArray(dem)
        band.SetNoDataValue(-9999)
        
        # Clean up
        band = None
        dataset = None
        
        print(f"✅ Created test DEM: {output_path}")
        return True
        
    except ImportError:
        print("⚠️ GDAL not available - creating simple numpy array DEM")
        # Fallback without GDAL
        return False
    except Exception as e:
        print(f"❌ Failed to create test DEM: {e}")
        return False

def main():
    print("🌊 FloodEngine Animation Controls Test")
    print("=" * 40)
    
    # Check dependencies first
    print("🔍 Checking dependencies...")
    
    try:
        import numpy as np
        print("✅ NumPy available")
    except ImportError:
        print("❌ NumPy missing - cannot run test")
        return 1
    
    try:
        from PyQt5.QtWidgets import QApplication
        print("✅ PyQt5 available")
    except ImportError:
        print("❌ PyQt5 missing - cannot show animation")
        return 1
    
    try:
        from osgeo import gdal
        print("✅ GDAL available")
    except ImportError:
        print("⚠️ GDAL missing - limited functionality")
    
    # Run the test
    success = test_simple_simulation()
    
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())
