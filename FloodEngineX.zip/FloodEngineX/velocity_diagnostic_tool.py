#!/usr/bin/env python3
"""
Velocity Diagnostic Tool - Quick Problem Identification
------------------------------------------------------
This tool helps diagnose velocity issues in FloodEngine outputs.
Run this on your actual output folder to identify problems.

Usage: python velocity_diagnostic_tool.py /path/to/your/output/folder
"""

import os
import sys
import numpy as np
from osgeo import gdal
import logging

def diagnose_saint_venant_files(output_folder):
    """Diagnose Saint-Venant velocity files for issues."""
    print(f"\n🔍 DIAGNOSING SAINT-VENANT FILES IN: {output_folder}")
    print("=" * 60)
    
    # Look for velocity files
    velocity_files = {}
    for file_name in os.listdir(output_folder):
        file_path = os.path.join(output_folder, file_name)
        
        if not os.path.isfile(file_path) or not file_name.lower().endswith(('.tif', '.tiff')):
            continue
            
        if any(pattern in file_name.lower() for pattern in ['velocity_x', 'vx']):
            velocity_files['velocity_x'] = file_path
        elif any(pattern in file_name.lower() for pattern in ['velocity_y', 'vy']):
            velocity_files['velocity_y'] = file_path
        elif any(pattern in file_name.lower() for pattern in ['velocity_magnitude', 'vmag']):
            velocity_files['velocity_magnitude'] = file_path
    
    if not velocity_files:
        print("❌ No Saint-Venant velocity files found")
        return False
    
    print(f"📁 Found velocity files:")
    for key, path in velocity_files.items():
        print(f"   • {key}: {os.path.basename(path)}")
    
    # Load and analyze velocity files
    try:
        saint_venant_data = {}
        
        # Load velocity components
        if 'velocity_x' in velocity_files:
            vx_ds = gdal.Open(velocity_files['velocity_x'])
            vx_array = vx_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
            vx_nodata = vx_ds.GetRasterBand(1).GetNoDataValue()
            if vx_nodata is not None:
                vx_array[vx_array == vx_nodata] = 0.0
            saint_venant_data['velocity_x'] = vx_array
            vx_ds = None
        
        if 'velocity_y' in velocity_files:
            vy_ds = gdal.Open(velocity_files['velocity_y'])
            vy_array = vy_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
            vy_nodata = vy_ds.GetRasterBand(1).GetNoDataValue()
            if vy_nodata is not None:
                vy_array[vy_array == vy_nodata] = 0.0
            saint_venant_data['velocity_y'] = vy_array
            vy_ds = None
        
        # Calculate or load magnitude
        if 'velocity_magnitude' in velocity_files:
            vmag_ds = gdal.Open(velocity_files['velocity_magnitude'])
            vmag_array = vmag_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
            vmag_nodata = vmag_ds.GetRasterBand(1).GetNoDataValue()
            if vmag_nodata is not None:
                vmag_array[vmag_array == vmag_nodata] = 0.0
            saint_venant_data['velocity_magnitude'] = vmag_array
            vmag_ds = None
        elif 'velocity_x' in saint_venant_data and 'velocity_y' in saint_venant_data:
            saint_venant_data['velocity_magnitude'] = np.sqrt(
                saint_venant_data['velocity_x']**2 + saint_venant_data['velocity_y']**2
            )
        
        # Analyze velocity statistics
        print(f"\n📊 VELOCITY STATISTICS:")
        
        if 'velocity_magnitude' in saint_venant_data:
            vmag = saint_venant_data['velocity_magnitude']
            
            # Clean data
            vmag_clean = np.nan_to_num(vmag, nan=0.0, posinf=0.0, neginf=0.0)
            
            # Basic statistics
            max_vel = np.max(vmag_clean)
            mean_vel = np.mean(vmag_clean)
            median_vel = np.median(vmag_clean)
            
            print(f"   • Max velocity: {max_vel:.3f} m/s")
            print(f"   • Mean velocity: {mean_vel:.3f} m/s")
            print(f"   • Median velocity: {median_vel:.3f} m/s")
            
            # Velocity distribution
            cells_total = vmag_clean.size
            cells_with_flow = np.sum(vmag_clean > 0.01)
            cells_over_1 = np.sum(vmag_clean > 1.0)
            cells_over_3 = np.sum(vmag_clean > 3.0)
            cells_over_5 = np.sum(vmag_clean > 5.0)
            cells_over_10 = np.sum(vmag_clean > 10.0)
            cells_over_50 = np.sum(vmag_clean > 50.0)
            
            print(f"\n📈 VELOCITY DISTRIBUTION:")
            print(f"   • Total cells: {cells_total:,}")
            print(f"   • Cells with flow (>0.01 m/s): {cells_with_flow:,} ({cells_with_flow/cells_total*100:.1f}%)")
            print(f"   • Cells >1.0 m/s: {cells_over_1:,} ({cells_over_1/cells_total*100:.2f}%)")
            print(f"   • Cells >3.0 m/s: {cells_over_3:,} ({cells_over_3/cells_total*100:.2f}%)")
            print(f"   • Cells >5.0 m/s: {cells_over_5:,} ({cells_over_5/cells_total*100:.2f}%)")
            print(f"   • Cells >10.0 m/s: {cells_over_10:,} ({cells_over_10/cells_total*100:.2f}%)")
            print(f"   • Cells >50.0 m/s: {cells_over_50:,} ({cells_over_50/cells_total*100:.2f}%)")
            
            # Quality assessment
            print(f"\n🎯 QUALITY ASSESSMENT:")
            
            # Check for realistic velocities
            issues = []
            warnings = []
            
            if max_vel > 10.0:
                issues.append(f"Maximum velocity {max_vel:.1f} m/s is extremely unrealistic")
            elif max_vel > 5.0:
                warnings.append(f"Maximum velocity {max_vel:.1f} m/s is high but possible")
            
            if mean_vel > 2.0:
                issues.append(f"Mean velocity {mean_vel:.1f} m/s is too high")
            elif mean_vel > 1.0:
                warnings.append(f"Mean velocity {mean_vel:.1f} m/s is somewhat high")
            
            if cells_over_10 > 0:
                issues.append(f"{cells_over_10} cells have velocities >10 m/s (extremely unrealistic)")
            
            if cells_over_5 > 100:
                issues.append(f"{cells_over_5} cells have velocities >5 m/s (too many)")
            elif cells_over_5 > 0:
                warnings.append(f"{cells_over_5} cells have velocities >5 m/s")
            
            if cells_over_50 > 0:
                issues.append(f"{cells_over_50} cells have velocities >50 m/s (catastrophic)")
            
            # Report issues
            if issues:
                print("   🚨 CRITICAL ISSUES FOUND:")
                for issue in issues:
                    print(f"     ❌ {issue}")
                print("   🔧 RECOMMENDATION: These files should be REJECTED")
                print("   🔄 Fallback to hydraulic approximation recommended")
                return False
            elif warnings:
                print("   ⚠️  WARNINGS:")
                for warning in warnings:
                    print(f"     ⚠️  {warning}")
                print("   ✅ Files are acceptable but could be improved")
                return True
            else:
                print("   ✅ Velocities appear realistic and well-behaved")
                print("   🎉 These files should be ACCEPTED for use")
                return True
            
        else:
            print("   ❌ Could not calculate velocity magnitude")
            return False
            
    except Exception as e:
        print(f"   ❌ Error analyzing Saint-Venant files: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def diagnose_streamline_issues(output_folder):
    """Diagnose streamline-related issues."""
    print(f"\n🌊 DIAGNOSING STREAMLINE FILES")
    print("=" * 40)
    
    # Look for streamline files
    streamline_files = []
    for file_name in os.listdir(output_folder):
        if 'streamline' in file_name.lower() and file_name.lower().endswith('.shp'):
            streamline_files.append(os.path.join(output_folder, file_name))
    
    if not streamline_files:
        print("❌ No streamline files found")
        return False
    
    print(f"📁 Found streamline files:")
    for file_path in streamline_files:
        print(f"   • {os.path.basename(file_path)}")
    
    # Analyze streamlines (basic file check)
    try:
        from qgis.core import QgsVectorLayer
        
        for file_path in streamline_files:
            layer = QgsVectorLayer(file_path, "streamlines", "ogr")
            
            if layer.isValid():
                feature_count = layer.featureCount()
                print(f"   ✅ {os.path.basename(file_path)}: {feature_count} features")
                
                if feature_count == 0:
                    print(f"     ⚠️  No streamlines in file - check velocity field and seeding")
                elif feature_count < 10:
                    print(f"     ⚠️  Very few streamlines - may indicate seeding issues")
                else:
                    print(f"     ✅ Good number of streamlines")
            else:
                print(f"   ❌ {os.path.basename(file_path)}: Invalid layer")
        
        return True
        
    except ImportError:
        print("   ⚠️  QGIS not available - cannot analyze streamline content")
        return True
    except Exception as e:
        print(f"   ❌ Error analyzing streamlines: {str(e)}")
        return False

def diagnose_output_folder(output_folder):
    """Perform comprehensive diagnosis of output folder."""
    if not os.path.exists(output_folder):
        print(f"❌ Output folder does not exist: {output_folder}")
        return False
    
    print(f"🔬 FLOODENGINE VELOCITY DIAGNOSTIC TOOL")
    print(f"📁 Analyzing folder: {output_folder}")
    
    # List all files
    all_files = [f for f in os.listdir(output_folder) if os.path.isfile(os.path.join(output_folder, f))]
    print(f"\n📋 Files found: {len(all_files)}")
    
    # Categorize files
    velocity_files = [f for f in all_files if 'velocity' in f.lower() and f.lower().endswith(('.tif', '.tiff'))]
    streamline_files = [f for f in all_files if 'streamline' in f.lower()]
    depth_files = [f for f in all_files if 'depth' in f.lower() and f.lower().endswith(('.tif', '.tiff'))]
    
    print(f"   • Velocity files: {len(velocity_files)}")
    print(f"   • Streamline files: {len(streamline_files)}")
    print(f"   • Depth files: {len(depth_files)}")
    
    # Diagnose Saint-Venant velocities
    saint_venant_ok = diagnose_saint_venant_files(output_folder)
    
    # Diagnose streamlines
    streamlines_ok = diagnose_streamline_issues(output_folder)
    
    # Overall assessment
    print(f"\n🎯 OVERALL ASSESSMENT:")
    print("=" * 40)
    
    if saint_venant_ok and streamlines_ok:
        print("✅ DIAGNOSIS: Output appears healthy")
        print("✅ Velocities are within realistic ranges")
        print("✅ Streamlines were generated successfully")
        return True
    elif saint_venant_ok and not streamlines_ok:
        print("⚠️  DIAGNOSIS: Velocities OK, but streamline issues")
        print("🔧 RECOMMENDATION: Check streamline seeding and generation parameters")
        return False
    elif not saint_venant_ok and streamlines_ok:
        print("⚠️  DIAGNOSIS: Velocity issues, but streamlines generated")
        print("🔧 RECOMMENDATION: Velocity files should be rejected - use hydraulic fallback")
        return False
    else:
        print("❌ DIAGNOSIS: Multiple issues detected")
        print("🔧 RECOMMENDATION: Apply velocity fixes and regenerate")
        return False

def main():
    """Main function."""
    if len(sys.argv) != 2:
        print("Usage: python velocity_diagnostic_tool.py /path/to/output/folder")
        sys.exit(1)
    
    output_folder = sys.argv[1]
    
    try:
        success = diagnose_output_folder(output_folder)
        
        print(f"\n" + "=" * 80)
        if success:
            print("🎉 DIAGNOSTIC COMPLETE - No critical issues found")
        else:
            print("🔧 DIAGNOSTIC COMPLETE - Issues detected, see recommendations above")
        print("=" * 80)
        
    except Exception as e:
        print(f"\n❌ DIAGNOSTIC FAILED: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
