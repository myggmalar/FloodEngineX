"""
Flow Direction Based Flood Modeling
-----------------------------------
Improved flooding algorithm that ensures water flows downhill following natural channels.
Fixes the issue with water flowing backwards in waterways.
"""

import os
import numpy as np
from osgeo import gdal, ogr, osr
from collections import deque
import logging

# First check if we are in flow mode or water level mode
def find_channel_start_points(dem_array, stream_path=None, flow_q=None, geotransform=None):
    """
    Find the highest elevation points in channels where flow should start
    
    :param dem_array: Digital Elevation Model array
    :param stream_path: Path to stream vector file (optional)
    :param flow_q: Flow rate to help determine channel capacity
    :param geotransform: GDAL geotransform for coordinate conversion
    :returns: List of (row, col, elevation) tuples for start points
    """
    start_points = []
    
    # Check if we're in flow mode (Q) which requires special handling
    is_flow_mode = flow_q is not None and flow_q > 0
    
    # First priority: Find the global highest points in the DEM
    # These will serve as the primary headwaters for the flow
    valid_mask = ~np.isnan(dem_array)
    if np.sum(valid_mask) > 0:
        # Get top 0.1% highest elevation points as absolute starting points
        elev_threshold = np.percentile(dem_array[valid_mask], 99.9)
        highest_points = np.where((dem_array > elev_threshold) & valid_mask)
        for i in range(min(5, len(highest_points[0]))):  # Limit to 5 highest points
            row, col = highest_points[0][i], highest_points[1][i]
            start_points.append((row, col, dem_array[row, col]))
        
        print(f"Added {len(start_points)} global highest points as flow sources")
    
    # Second priority: Use stream data if available
    if stream_path and os.path.exists(stream_path):
        try:
            stream_ds = ogr.Open(stream_path)
            if stream_ds:
                layer = stream_ds.GetLayer()
                
                # Build a mask of all stream cells
                stream_mask = np.zeros_like(dem_array, dtype=bool)
                
                # First pass: Create stream mask
                for feature in layer:
                    geom = feature.GetGeometryRef()
                    if geom:
                        # Process each point in the stream
                        if geom.GetGeometryType() == ogr.wkbLineString:
                            for i in range(geom.GetPointCount()):
                                x, y, z = geom.GetPoint(i)
                                row, col = world_to_pixel(x, y, geotransform)
                                if (0 <= row < dem_array.shape[0] and 
                                    0 <= col < dem_array.shape[1]):
                                    stream_mask[row, col] = True
                
                # Second pass: Find local maxima along streams
                for i in range(1, dem_array.shape[0] - 1):
                    for j in range(1, dem_array.shape[1] - 1):
                        if stream_mask[i, j] and not np.isnan(dem_array[i, j]):
                            # Check if this is a local maximum along the stream
                            is_local_max = True
                            center_elev = dem_array[i, j]
                            
                            for di in [-1, 0, 1]:
                                for dj in [-1, 0, 1]:
                                    if di == 0 and dj == 0:
                                        continue
                                    ni, nj = i + di, j + dj
                                    if (0 <= ni < dem_array.shape[0] and 
                                        0 <= nj < dem_array.shape[1] and
                                        stream_mask[ni, nj] and
                                        not np.isnan(dem_array[ni, nj]) and
                                        dem_array[ni, nj] >= center_elev):
                                        is_local_max = False
                                        break
                            
                            if is_local_max:
                                start_points.append((i, j, dem_array[i, j]))
                
                print(f"Added {len(start_points)} stream-based flow source points")
                            
        except Exception as e:
            logging.warning(f"Could not process stream file: {e}")
    
    # Third priority: Fallback to topographic analysis if needed
    if len(start_points) < 5:
        topo_points = find_topographic_start_points(dem_array)
        start_points.extend(topo_points)
        print(f"Added {len(topo_points)} topographic flow source points")
    
    # Sort all points by elevation (highest first) and remove duplicates
    start_points.sort(key=lambda x: x[2], reverse=True)
    
    # In flow mode, we only want the single highest point
    if is_flow_mode and start_points:
        highest_point = start_points[0]
        start_points = [highest_point]
        print(f"Flow mode (Q={flow_q}): Using only the highest point at elevation {highest_point[2]:.2f}m")
    else:
        # Remove duplicates (points that are very close to each other)
        filtered_points = []
        used_cells = set()
        
        for row, col, elev in start_points:
            cell_key = (row // 5, col // 5)  # Group points within 5x5 cell regions
            if cell_key not in used_cells:
                filtered_points.append((row, col, elev))
                used_cells.add(cell_key)
        
        start_points = filtered_points[:15]  # Limit to 15 start points
    
    return start_points

def find_topographic_start_points(dem_array):
    """
    Find natural channel head locations using topographic analysis
    """
    # Calculate flow accumulation to find natural channels
    flow_dir = calculate_d8_flow_direction(dem_array)
    flow_acc = calculate_flow_accumulation(flow_dir)
    
    # Find high accumulation areas (natural channels)
    acc_threshold = np.percentile(flow_acc[flow_acc > 0], 90)  # Top 10% flow accumulation
    
    # Find start points: high elevation + high flow accumulation
    potential_starts = np.where((flow_acc > acc_threshold) & (~np.isnan(dem_array)))
    
    start_points = []
    for i in range(len(potential_starts[0])):
        row, col = potential_starts[0][i], potential_starts[1][i]
        elev = dem_array[row, col]
        
        # Check if this is a local maximum along the channel
        is_local_max = True
        for dr, dc in [(-1,-1), (-1,0), (-1,1), (0,-1), (0,1), (1,-1), (1,0), (1,1)]:
            nr, nc = row + dr, col + dc
            if (0 <= nr < dem_array.shape[0] and 0 <= nc < dem_array.shape[1] and
                not np.isnan(dem_array[nr, nc]) and dem_array[nr, nc] > elev):
                is_local_max = False
                break
        
        if is_local_max:
            start_points.append((row, col, elev))
    
    # Sort by elevation (highest first)
    start_points.sort(key=lambda x: x[2], reverse=True)
    
    # Return top 10 start points to avoid too many
    return start_points[:10]

def calculate_d8_flow_direction(dem_array):
    """
    Calculate D8 flow direction using steepest descent.
    Returns direction codes that represent where water flows TO (not FROM).
    
    Direction codes:
    1=E, 2=SE, 4=S, 8=SW, 16=W, 32=NW, 64=N, 128=NE
    A value of 0 means no flow (local minimum or flat area).
    """
    rows, cols = dem_array.shape
    flow_dir = np.zeros_like(dem_array, dtype=np.int8)
    
    # D8 directions: 1=E, 2=SE, 4=S, 8=SW, 16=W, 32=NW, 64=N, 128=NE
    directions = [(0, 1, 1), (1, 1, 2), (1, 0, 4), (1, -1, 8),
                 (0, -1, 16), (-1, -1, 32), (-1, 0, 64), (-1, 1, 128)]
    
    for i in range(1, rows-1):
        for j in range(1, cols-1):
            if np.isnan(dem_array[i, j]):
                continue
                
            center_elev = dem_array[i, j]
            max_slope = -1
            best_dir = 0
            
            for dr, dc, dir_code in directions:
                ni, nj = i + dr, j + dc
                if (0 <= ni < rows and 0 <= nj < cols and not np.isnan(dem_array[ni, nj])):
                    # Calculate slope (positive = downhill)
                    slope = (center_elev - dem_array[ni, nj]) / np.sqrt(dr*dr + dc*dc)
                    if slope > max_slope:
                        max_slope = slope
                        best_dir = dir_code
            
            flow_dir[i, j] = best_dir if max_slope > 0 else 0
    
    return flow_dir

def calculate_flow_accumulation(flow_dir):
    """
    Calculate flow accumulation from flow direction
    """
    rows, cols = flow_dir.shape
    accumulation = np.ones_like(flow_dir, dtype=np.float32)
    
    # Direction mappings
    dir_map = {1: (0, 1), 2: (1, 1), 4: (1, 0), 8: (1, -1),
               16: (0, -1), 32: (-1, -1), 64: (-1, 0), 128: (-1, 1)}
    
    # Process cells from highest to lowest elevation
    valid_cells = []
    for i in range(rows):
        for j in range(cols):
            if flow_dir[i, j] > 0:
                valid_cells.append((i, j))
    
    # Sort by elevation (highest first)
    dem_flat = flow_dir  # Use flow_dir as proxy for sorting
    valid_cells.sort(key=lambda x: -dem_flat[x[0], x[1]] if dem_flat[x[0], x[1]] > 0 else 0)
    
    for i, j in valid_cells:
        if flow_dir[i, j] in dir_map:
            dr, dc = dir_map[flow_dir[i, j]]
            ni, nj = i + dr, j + dc
            if 0 <= ni < rows and 0 <= nj < cols:
                accumulation[ni, nj] += accumulation[i, j]
    
    return accumulation

def simulate_hydraulic_flow(dem_array, start_points, water_level, flow_q=None, 
                           geotransform=None, progress_callback=None):
    """
    Simulate realistic hydraulic flow from start points following topography
    
    :param dem_array: Digital Elevation Model
    :param start_points: List of (row, col, elevation) start points
    :param water_level: Target water level
    :param flow_q: Flow rate in m³/s
    :param geotransform: GDAL geotransform for coordinate conversion
    :param progress_callback: Progress reporting function
    :returns: (flooded, water_depth) tuple of arrays
    """
    rows, cols = dem_array.shape
    flooded = np.zeros((rows, cols), dtype=bool)
    water_depth = np.zeros((rows, cols), dtype=np.float32)
    
    # Calculate flow direction once - this is critical for correct direction
    flow_dir = calculate_d8_flow_direction(dem_array)
    
    # Also calculate accumulated flow to prioritize main channels
    flow_acc = calculate_flow_accumulation(flow_dir)
    
    # Special handling for flow_q mode where water only flows from upstream to downstream
    is_flow_mode = flow_q is not None and flow_q > 0                # Direction mappings for flow propagation
    # D8 directions: 1=E, 2=SE, 4=S, 8=SW, 16=W, 32=NW, 64=N, 128=NE
    # These codes represent where water flows TO (not FROM)
    dir_map = {1: (0, 1), 2: (1, 1), 4: (1, 0), 8: (1, -1),
               16: (0, -1), 32: (-1, -1), 64: (-1, 0), 128: (-1, 1)}
    
    # Calculate the inverse direction map (to avoid uphill flow)
    inverse_dir_map = {
        1: 16,  # E -> W
        2: 32,  # SE -> NW
        4: 64,  # S -> N
        8: 128, # SW -> NE
        16: 1,  # W -> E
        32: 2,  # NW -> SE
        64: 4,  # N -> S
        128: 8, # NE -> SW
    }
    
    # Precalculate downstream neighbors for each cell based on flow direction
    downstream = {}
    for i in range(1, rows-1):
        for j in range(1, cols-1):
            if np.isnan(dem_array[i, j]) or flow_dir[i, j] == 0:
                continue
                
            if flow_dir[i, j] in dir_map:
                dr, dc = dir_map[flow_dir[i, j]]
                ni, nj = i + dr, j + dc
                if 0 <= ni < rows and 0 <= nj < cols:
                    downstream[(i, j)] = [(ni, nj)]
    
    # First pass: Fill depressions to prevent water getting trapped
    if progress_callback:
        progress_callback(40, "Analyzing flow patterns")
    
    total_points = len(start_points)    # In flow mode (Q), only use the highest point as the starting point
    # In water level mode, use all start points
    if is_flow_mode:
        # When using flow_q, only start from the highest point which represents the inflow
        # Find the point with highest flow accumulation among the top 10% highest elevation points
        top_elev_threshold = max(p[2] for p in start_points) * 0.9
        high_points = [p for p in start_points if p[2] >= top_elev_threshold]
        
        if high_points:
            # Choose the point with the highest flow accumulation among high elevation points
            best_point = None
            max_acc = -1
            
            for row, col, elev in high_points:
                if 0 <= row < rows and 0 <= col < cols:
                    acc = flow_acc[row, col]
                    if acc > max_acc:
                        max_acc = acc
                        best_point = (row, col, elev)
            
            if best_point:
                start_points = [best_point]
            else:
                start_points.sort(key=lambda x: x[2], reverse=True)
                start_points = [start_points[0]]
        else:
            start_points.sort(key=lambda x: x[2], reverse=True)
            start_points = [start_points[0]]  # Fall back to highest point
            
        print(f"Flow simulation (Q={flow_q} m³/s) starting from highest flow point:")
    else:
        # Sort start points by elevation (highest first)
        start_points.sort(key=lambda x: x[2], reverse=True)
        print(f"Water level simulation ({water_level}m) with {len(start_points)} start points:")
    
    # Print information about start points
    for i, (row, col, elev) in enumerate(start_points[:5]):
        print(f"  Point {i+1}: Row={row}, Col={col}, Elevation={elev:.2f}m")
    
    # Second pass: Actual flow simulation from highest points
    for point_idx, (start_row, start_col, start_elev) in enumerate(start_points):
        if progress_callback:
            progress = 40 + (point_idx / total_points) * 30
            progress_callback(int(progress), f"Simulating flow from point {point_idx+1}/{total_points}")
        
        # Skip if already flooded
        if flooded[start_row, start_col]:
            continue
              # Initialize flow from this start point
        current_level = water_level
          # Use priority queue (sorted by elevation) to ensure correct flow order
        # Format: (priority, water_level, row, col)
        from heapq import heappush, heappop
        
        priority_queue = []
        if is_flow_mode:
            # In flow mode, priority is determined by flow direction from this start point
            # Lower priority value means higher priority in heapq
            # Use a very low priority (-999) for the start point to ensure it's processed first
            # Also track flow accumulation to ensure main channels get priority
            heappush(priority_queue, (-999, current_level, start_row, start_col))  # Give highest priority to start point
            
            # Pre-calculate a path distance grid from the starting point to help guide flow
            # This helps ensure that the flow follows a connected path downstream
            distance_from_start = np.full_like(dem_array, np.inf)
            distance_from_start[start_row, start_col] = 0
        else:
            # In water level mode, priority is based on elevation to fill lowest areas first
            heappush(priority_queue, (start_elev, current_level, start_row, start_col))
            
        visited = set()
        
        while priority_queue:
            _, current_water_level, row, col = heappop(priority_queue)
            
            if (row, col) in visited:
                continue
                
            visited.add((row, col))
            
            # Get ground elevation at this cell
            ground_elev = dem_array[row, col]
            if np.isnan(ground_elev):
                continue
            
            # Calculate water depth
            depth = max(0, current_water_level - ground_elev)
            
            if depth > 0.01:  # Minimum depth threshold (1 cm)
                flooded[row, col] = True
                water_depth[row, col] = max(water_depth[row, col], depth)
                
                # Find neighboring cells to flood
                neighbors = []
                  # First, always follow the main flow direction
                if (row, col) in downstream:
                    for next_row, next_col in downstream[(row, col)]:
                        if (next_row, next_col) not in visited:
                            # Calculate flow energy for downstream cell
                            if is_flow_mode and 0 <= next_row < rows and 0 <= next_col < cols:
                                # Higher flow accumulation = more likely to be the main channel
                                flow_energy = max(1, flow_acc[next_row, next_col])
                                # Also consider elevation drop - more drop = better flow path
                                next_elev = dem_array[next_row, next_col]
                                if not np.isnan(next_elev):
                                    elev_drop = max(0, ground_elev - next_elev)
                                    flow_energy *= (1 + elev_drop)
                                neighbors.append((next_row, next_col, 'downstream', flow_energy))
                            else:
                                neighbors.append((next_row, next_col, 'downstream', 0))
                
                # Then check all adjacent cells for lateral spreading
                # But prevent uphill flow by checking the inverse flow direction
                for dr, dc in [(-1,0), (1,0), (0,-1), (0,1), (-1,-1), (-1,1), (1,-1), (1,1)]:
                    next_row, next_col = row + dr, col + dc
                    
                    if not (0 <= next_row < rows and 0 <= next_col < cols):
                        continue
                    
                    if (next_row, next_col) in visited:
                        continue
                    
                    next_elev = dem_array[next_row, next_col] 
                    if np.isnan(next_elev):
                        continue
                    
                    # Skip cells that would create uphill flow
                    dir_code = 0
                    for d, (dr_, dc_, code) in enumerate([(0,1,1), (1,1,2), (1,0,4), (1,-1,8),
                                                         (0,-1,16), (-1,-1,32), (-1,0,64), (-1,1,128)]):
                        if dr_ == dr and dc_ == dc:
                            dir_code = code
                            break
                    
                    # Skip if this would be against the main flow direction
                    if flow_dir[next_row, next_col] == inverse_dir_map.get(dir_code, 0):
                        continue                # Different behavior for flow_q vs water_level mode
                    if is_flow_mode:
                        # In flow_q mode, be much more restrictive with lateral spreading
                        # Consider flow accumulation and elevation change
                        
                        # Calculate "flow energy" based on flow accumulation and elevations
                        # Higher flow energy = more likely path for water to follow
                        flow_energy = flow_acc[row, col] * (ground_elev - next_elev)
                        
                        # Check if this cell has significant flow accumulation (is a stream channel)
                        is_channel = flow_acc[row, col] > np.percentile(flow_acc[flow_acc > 0], 75)
                        
                        if next_elev < ground_elev:
                            # Always allow flow to lower cells
                            if is_channel or flow_energy > 0:
                                # Prioritize cells with higher flow_energy 
                                neighbors.append((next_row, next_col, 'lateral_lower', flow_energy))
                        elif is_channel and depth > 0.5:
                            # Allow flow along main channel even with small elevation increases
                            # but only if we have significant water depth
                            if next_elev - ground_elev < 0.1:  # Max 10cm elevation gain
                                neighbors.append((next_row, next_col, 'lateral_higher', -1))
                        # No other uphill flow in Q mode
                    else:
                        # In water_level mode, allow more lateral spreading
                        # Water spreads to this cell if:
                        # 1. It's lower than or equal to our cell
                        # 2. Water level is above its ground elevation
                        if next_elev <= ground_elev:
                            neighbors.append((next_row, next_col, 'lateral_lower', 0))
                        else:
                            # Check if water level is high enough to flood uphill
                            # Must be a significant water depth to flow uphill
                            if depth > 0.5 and current_water_level > next_elev:
                                neighbors.append((next_row, next_col, 'lateral_higher', 0))
                  # Add neighbors to priority queue
                for neighbor_data in neighbors:
                    if len(neighbor_data) == 4:
                        next_row, next_col, flow_type, flow_energy = neighbor_data
                    else:
                        next_row, next_col, flow_type = neighbor_data
                        flow_energy = 0
                        
                    next_elev = dem_array[next_row, next_col]
                    
                    # Calculate energy loss based on flow type
                    distance = np.sqrt((next_row - row)**2 + (next_col - col)**2)
                    distance_meters = distance * abs(geotransform[1]) if geotransform else distance
                    
                    if is_flow_mode:
                        # In flow_q mode, strongly prioritize downstream flow
                        if flow_type == 'downstream':
                            # Almost no energy loss for main flow direction
                            energy_loss = 0.00005 * distance_meters
                        elif flow_type == 'lateral_lower':
                            # Energy loss inversely proportional to flow_energy
                            # Higher flow_energy = less energy loss
                            base_loss = 0.002 * distance_meters
                            if flow_energy > 0:
                                # Scale down energy loss for high flow_energy paths
                                energy_loss = base_loss / (1 + np.log1p(flow_energy))
                            else:
                                energy_loss = base_loss
                        else:  # lateral_higher - should rarely be used in flow_q mode
                            # Very high energy loss for uphill flow in Q mode
                            energy_loss = 0.05 * distance_meters
                            energy_loss += (next_elev - ground_elev) * 0.8  # Much stronger loss for elevation gain
                    else:
                        # Normal energy loss calculations for water level mode
                        if flow_type == 'downstream':
                            # Less energy loss for main flow direction
                            energy_loss = 0.0005 * distance_meters
                        elif flow_type == 'lateral_lower':
                            # Medium energy loss for lateral downhill flow
                            energy_loss = 0.002 * distance_meters
                        else:  # lateral_higher
                            # High energy loss for uphill flow
                            energy_loss = 0.01 * distance_meters
                            energy_loss += (next_elev - ground_elev) * 0.2  # Additional loss for elevation gain
                    
                    next_water_level = current_water_level - energy_loss
                    
                    # Only add to queue if water level would be above ground
                    if next_water_level > next_elev:
                        if is_flow_mode:
                            # In flow mode, prioritize based on:
                            # 1. Flow accumulation (higher = better)
                            # 2. Distance from start point (lower = better)
                            # 3. Elevation (lower = better for filling)
                            priority = next_elev
                            
                            # Adjust priority for flow energy - lower priority values processed first
                            if flow_energy > 0:
                                # Boost priority for high flow_energy cells (negative values are higher priority)
                                priority -= np.log1p(flow_energy)
                                
                            # Additional boost for downstream flow
                            if flow_type == 'downstream':
                                priority -= 10  # Strong boost for main flow direction
                                
                            heappush(priority_queue, (priority, next_water_level, next_row, next_col))
                        else:
                            # In water level mode, prioritize by elevation (lowest first)
                            heappush(priority_queue, (next_elev, next_water_level, next_row, next_col))
    
    if progress_callback:
        progress_callback(70, f"Flow simulation complete, {np.sum(flooded)} flooded cells")
    
    return flooded, water_depth

def world_to_pixel(x, y, geotransform):
    """
    Convert world coordinates to pixel coordinates
    """
    if geotransform is None:
        return 0, 0
        
    col = int((x - geotransform[0]) / geotransform[1])
    row = int((y - geotransform[3]) / geotransform[5])
    return row, col

def calculate_flood_area_with_flow_direction(iface, dem_path, water_level, bathymetry=None, 
                                           output_folder=None, flow_q=None, threshold=None,
                                           stream_path=None):
    """
    Enhanced flood calculation that follows actual flow patterns
    
    :param iface: QGIS interface
    :param dem_path: Path to DEM file
    :param water_level: Water level in meters
    :param bathymetry: Bathymetry data (optional)
    :param output_folder: Output folder (optional)
    :param flow_q: Flow rate in m³/s (optional)
    :param threshold: Threshold value for flooding (optional)
    :param stream_path: Path to stream vector file (optional)
    :return: Flood layer
    """
    from qgis.core import QgsVectorLayer, QgsProject, QgsRasterLayer
    
    # Set up paths and variables
    if output_folder is None:
        output_folder = r"C:\Users\david\OneDrive\Dokument\GIS\FloodEngine\VSCode\output"
    output_folder = os.path.abspath(output_folder)
    os.makedirs(output_folder, exist_ok=True)
    
    # Create output paths
    output_name = f"flood_{water_level}m"
    if flow_q is not None:
        output_name = f"flood_{water_level}m_q{flow_q}"
    shp_path = os.path.join(output_folder, output_name + ".shp")
    log_path = os.path.join(output_folder, output_name + "_log.txt")
    hillshade_path = os.path.join(output_folder, "hillshade.tif")
    
    # Progress callback wrapper
    def progress_wrapper(percent, message=""):
        if hasattr(iface, 'messageBar'):
            iface.messageBar().pushInfo("FloodEngine", f"{message} ({percent}%)")
        print(f"Progress: {percent}% - {message}")
    
    try:
        # Load DEM
        progress_wrapper(10, "Loading DEM")
        dem_ds = gdal.Open(dem_path)
        if dem_ds is None:
            raise Exception(f"Could not open DEM file: {dem_path}")
            
        geotransform = dem_ds.GetGeoTransform()
        projection = dem_ds.GetProjection()
        band = dem_ds.GetRasterBand(1)
        nodata = band.GetNoDataValue() or -9999
        
        dem_array = band.ReadAsArray().astype(np.float32)
        dem_array[dem_array == nodata] = np.nan
        
        # Create hillshade for visualization
        try:
            gdal.DEMProcessing(hillshade_path, dem_path, 'hillshade')
            hillshade_layer = QgsRasterLayer(hillshade_path, "Hillshade")
            if (hillshade_layer.isValid()):
                QgsProject.instance().addMapLayer(hillshade_layer)
        except Exception as e:
            print(f"Warning: Could not create hillshade: {str(e)}")
        
        # Find channel start points (highest elevations in channels)
        progress_wrapper(20, "Finding channel start points for flow simulation")
        start_points = find_channel_start_points(dem_array, stream_path, flow_q, geotransform)
        
        if not start_points:
            progress_wrapper(25, "No suitable start points found, using highest elevation points")
            # Fallback: use highest 5% of elevations as start points
            valid_mask = ~np.isnan(dem_array)
            valid_elevs = dem_array[valid_mask]
            threshold_elev = np.percentile(valid_elevs, 95)
            
            high_points = np.where((dem_array >= threshold_elev) & valid_mask)
            start_points = [(high_points[0][i], high_points[1][i], dem_array[high_points[0][i], high_points[1][i]])
                          for i in range(min(10, len(high_points[0])))]
        
        progress_wrapper(30, f"Found {len(start_points)} start points for flow simulation")
        for i, (row, col, elev) in enumerate(start_points[:5]):  # Show first 5
            print(f"  Start point {i+1}: Row {row}, Col {col}, Elevation {elev:.2f}m")
        
        # Simulate hydraulic flow
        progress_wrapper(40, "Simulating hydraulic flow patterns")
        flooded, water_depth = simulate_hydraulic_flow(
            dem_array, start_points, water_level, flow_q, 
            geotransform, progress_wrapper
        )
        
        progress_wrapper(75, f"Flow simulation complete. Flooded cells: {np.sum(flooded)}")
        
        # Convert to uint8 for GDAL
        flood_mask = flooded.astype(np.uint8)
        
        # Create temporary flood raster
        mem_driver = gdal.GetDriverByName('MEM')
        x_size = dem_array.shape[1] 
        y_size = dem_array.shape[0]
        flood_ds = mem_driver.Create('', x_size, y_size, 1, gdal.GDT_Byte)
        
        # Set geotransform and projection
        flood_ds.SetGeoTransform(geotransform)
        flood_ds.SetProjection(projection)
        
        # Write flood data
        flood_band = flood_ds.GetRasterBand(1)
        flood_band.WriteArray(flood_mask)
        flood_band.SetNoDataValue(0)  # Set 0 as NoData
        flood_band.FlushCache()
        
        # Create shapefile
        progress_wrapper(80, "Creating flood polygon")
        driver = ogr.GetDriverByName('ESRI Shapefile')
        ds = driver.CreateDataSource(shp_path)
        if ds is None:
            raise Exception(f"Could not create shapefile: {shp_path}")
        
        srs = ogr.osr.SpatialReference()
        srs.ImportFromEPSG(3006)  # SWEREF99 TM (Swedish CRS)
        layer = ds.CreateLayer('flood', srs, ogr.wkbPolygon)
        if layer is None:
            raise Exception("Could not create layer")
        
        # Add fields
        layer.CreateField(ogr.FieldDefn('water_lvl', ogr.OFTReal))
        layer.CreateField(ogr.FieldDefn('depth_avg', ogr.OFTReal))
        layer.CreateField(ogr.FieldDefn('depth_max', ogr.OFTReal))
        
        # Polygonize flood mask
        gdal.Polygonize(flood_band, flood_band, layer, 0, [])
        
        # Calculate statistics
        progress_wrapper(90, "Calculating flood statistics")
        num_flooded = np.sum(flood_mask)
        total_cells = np.sum(~np.isnan(dem_array))
        flood_stats = f"Översvämningsceller: {num_flooded} av {total_cells} ({(num_flooded/total_cells)*100:.1f}%)"
        
        # Write log
        with open(log_path, 'w') as f:
            f.write(f"DEM: {dem_path}\n")
            f.write(f"Vattennivå: {water_level}m\n")
            valid_mask = ~np.isnan(dem_array)
            if np.sum(valid_mask) > 0:
                min_height = np.nanmin(dem_array)
                max_height = np.nanmax(dem_array)
                f.write(f"DEM höjdintervall: {min_height:.2f}m till {max_height:.2f}m\n")
            f.write(flood_stats + "\n")
            f.write(f"Flow simulation completed with {len(start_points)} start points\n")
        
        # Calculate depth statistics
        valid_depths = water_depth[water_depth > 0]
        if len(valid_depths) > 0:
            depth_avg = float(np.mean(valid_depths))
            depth_max = float(np.max(valid_depths))
        else:
            depth_avg = 0
            depth_max = 0
        
        # Update attributes
        for feature in layer:
            feature.SetField('water_lvl', float(water_level))
            feature.SetField('depth_avg', depth_avg)
            feature.SetField('depth_max', depth_max)
            layer.SetFeature(feature)
        
        # Add flow_q field if provided
        if flow_q is not None:
            layer.CreateField(ogr.FieldDefn('flow_q', ogr.OFTReal))
            for feature in layer:
                feature.SetField('flow_q', flow_q)
                layer.SetFeature(feature)
        
        # Cleanup
        ds = None
        flood_ds = None
        if dem_ds is not None:
            dem_ds = None
        
        # Load layer in QGIS
        progress_wrapper(95, "Loading flood layer in QGIS")
        flood_layer = QgsVectorLayer(shp_path, f"Översvämning {water_level}m", "ogr")
        if not flood_layer.isValid():
            raise Exception(f"Could not load the created layer: {shp_path}")
        
        # Style the flood layer with semi-transparent blue
        from PyQt5.QtGui import QColor
        from qgis.core import QgsSymbol, QgsSingleSymbolRenderer, QgsFillSymbol
        
        symbol = QgsFillSymbol.createSimple({
            'color': '0,100,255,128',  # RGBA: Blue with 50% opacity
            'outline_color': '0,0,255,255',  # Blue outline
            'outline_width': '0.3'  # Thin outline
        })
        
        renderer = QgsSingleSymbolRenderer(symbol)
        flood_layer.setRenderer(renderer)
        flood_layer.triggerRepaint()
        
        # Add layer to QGIS
        QgsProject.instance().addMapLayer(flood_layer)
        
        # Zoom to the new layer
        iface.mapCanvas().setExtent(flood_layer.extent())
        iface.mapCanvas().refresh()
        
        progress_wrapper(100, "Flood analysis complete")
        return flood_layer
        
    except Exception as e:
        print(f"Detailed error: {str(e)}")
        import traceback
        traceback.print_exc()
        raise Exception(f"Error in flow-direction flood calculation: {str(e)}")
