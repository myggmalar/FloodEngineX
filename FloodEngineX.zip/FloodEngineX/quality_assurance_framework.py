#!/usr/bin/env python3
"""
FloodEngine v4.0 - Quality Assurance & Testing Framework
========================================================

Enterprise-grade quality assurance framework for FloodEngine providing:
- Automated testing suite with unit, integration, and performance tests
- Benchmark validation against established hydraulic models
- Continuous integration pipeline components
- Test dataset creation and validation
- Performance regression testing
- Code quality analysis

Author: FloodEngine Development Team
Date: June 7, 2025
Version: 4.0
"""

import os
import sys
import time
import json
import logging
import unittest
import subprocess
import numpy as np
import tempfile
import shutil
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
import sqlite3
import hashlib

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@dataclass
class TestResult:
    """Data class for test results"""
    test_name: str
    status: str  # 'PASS', 'FAIL', 'SKIP'
    duration: float
    details: str = ""
    metrics: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)

@dataclass
class BenchmarkResult:
    """Data class for benchmark results"""
    test_case: str
    floodengine_result: Dict[str, Any]
    reference_result: Dict[str, Any]
    comparison_metrics: Dict[str, float]
    status: str  # 'PASS', 'FAIL', 'WARNING'
    tolerance: float = 0.1

class QualityAssuranceFramework:
    """
    Comprehensive quality assurance framework for FloodEngine
    """
    
    def __init__(self, workspace_path: str):
        """
        Initialize QA framework
        
        Args:
            workspace_path: Path to FloodEngine workspace
        """
        self.workspace_path = Path(workspace_path)
        self.results_db = self.workspace_path / "qa_results.db"
        self.test_data_dir = self.workspace_path / "test_data"
        self.reports_dir = self.workspace_path / "qa_reports"
        
        # Create directories
        self.test_data_dir.mkdir(exist_ok=True)
        self.reports_dir.mkdir(exist_ok=True)
        
        # Initialize database
        self._init_database()
        
        # Test configuration
        self.test_config = {
            'unit_tests_enabled': True,
            'integration_tests_enabled': True,
            'performance_tests_enabled': True,
            'benchmark_tests_enabled': True,
            'max_test_duration': 300,  # 5 minutes
            'performance_tolerance': 0.2,  # 20%
            'accuracy_tolerance': 0.05,   # 5%
        }
        
        logger.info(f"QA Framework initialized at {self.workspace_path}")

    def _init_database(self):
        """Initialize SQLite database for test results"""
        conn = sqlite3.connect(str(self.results_db))
        cursor = conn.cursor()
        
        # Test results table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS test_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                test_name TEXT,
                test_type TEXT,
                status TEXT,
                duration REAL,
                details TEXT,
                metrics TEXT
            )
        ''')
        
        # Benchmark results table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS benchmark_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                test_case TEXT,
                floodengine_result TEXT,
                reference_result TEXT,
                comparison_metrics TEXT,
                status TEXT,
                tolerance REAL
            )
        ''')
        
        # Performance history table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS performance_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                test_name TEXT,
                grid_size TEXT,
                execution_time REAL,
                memory_usage REAL,
                accuracy_metric REAL
            )
        ''')
        
        conn.commit()
        conn.close()

    def run_comprehensive_test_suite(self) -> Dict[str, List[TestResult]]:
        """
        Run complete test suite including all test categories
        
        Returns:
            Dictionary with test results by category
        """
        logger.info("Starting comprehensive test suite...")
        
        results = {
            'unit_tests': [],
            'integration_tests': [],
            'performance_tests': [],
            'benchmark_tests': [],
            'regression_tests': []
        }
        
        try:
            # Unit tests
            if self.test_config['unit_tests_enabled']:
                logger.info("Running unit tests...")
                results['unit_tests'] = self._run_unit_tests()
            
            # Integration tests
            if self.test_config['integration_tests_enabled']:
                logger.info("Running integration tests...")
                results['integration_tests'] = self._run_integration_tests()
            
            # Performance tests
            if self.test_config['performance_tests_enabled']:
                logger.info("Running performance tests...")
                results['performance_tests'] = self._run_performance_tests()
            
            # Benchmark tests
            if self.test_config['benchmark_tests_enabled']:
                logger.info("Running benchmark tests...")
                results['benchmark_tests'] = self._run_benchmark_tests()
            
            # Regression tests
            logger.info("Running regression tests...")
            results['regression_tests'] = self._run_regression_tests()
            
            # Store results
            self._store_test_results(results)
            
            # Generate report
            self._generate_test_report(results)
            
        except Exception as e:
            logger.error(f"Test suite execution failed: {e}")
            raise
        
        return results

    def _run_unit_tests(self) -> List[TestResult]:
        """Run unit tests for core components"""
        unit_tests = []
        
        # Test 1: Saint-Venant solver unit tests
        test_result = self._test_saint_venant_solver()
        unit_tests.append(test_result)
        
        # Test 2: GPU acceleration unit tests
        test_result = self._test_gpu_acceleration()
        unit_tests.append(test_result)
        
        # Test 3: Precipitation processing unit tests
        test_result = self._test_precipitation_processing()
        unit_tests.append(test_result)
        
        # Test 4: Memory management unit tests
        test_result = self._test_memory_management()
        unit_tests.append(test_result)
        
        # Test 5: File I/O unit tests
        test_result = self._test_file_io()
        unit_tests.append(test_result)
        
        return unit_tests

    def _test_saint_venant_solver(self) -> TestResult:
        """Test Saint-Venant 2D solver components"""
        start_time = time.time()
        
        try:
            # Import solver
            sys.path.append(str(self.workspace_path))
            from saint_venant_2d_fixed import SaintVenant2D
            
            # Create test grid
            nx, ny = 50, 50
            dx, dy = 1.0, 1.0
            solver = SaintVenant2D(nx, ny, dx, dy)
            
            # Test initialization
            assert hasattr(solver, 'h'), "Height array not initialized"
            assert hasattr(solver, 'u'), "U velocity array not initialized"
            assert hasattr(solver, 'v'), "V velocity array not initialized"
            assert hasattr(solver, 'z'), "Elevation array not initialized"
            
            # Test time stepping
            dt = solver.compute_timestep()
            assert dt > 0, "Invalid timestep computed"
            assert dt < 1.0, "Timestep too large for stability"
            
            # Test boundary conditions
            solver.apply_boundary_conditions()
            
            # Test flux calculations
            solver.compute_fluxes()
            
            duration = time.time() - start_time
            
            return TestResult(
                test_name="Saint-Venant Solver Unit Test",
                status="PASS",
                duration=duration,
                details="All solver components functioning correctly",
                metrics={
                    'grid_size': f"{nx}x{ny}",
                    'timestep': dt,
                    'boundary_conditions': "OK",
                    'flux_calculations': "OK"
                }
            )
            
        except Exception as e:
            duration = time.time() - start_time
            return TestResult(
                test_name="Saint-Venant Solver Unit Test",
                status="FAIL",
                duration=duration,
                details=str(e)
            )

    def _test_gpu_acceleration(self) -> TestResult:
        """Test GPU acceleration functionality"""
        start_time = time.time()
        
        try:
            # Import GPU module
            from gpu_acceleration import GPUAccelerator
            
            # Test GPU detection
            accelerator = GPUAccelerator()
            backend = accelerator.detect_best_backend()
            
            # Test small calculation
            grid_size = (100, 100)
            test_data = np.random.rand(*grid_size).astype(np.float32)
            
            # Test GPU processing
            result = accelerator.process_on_gpu(test_data, 'test_kernel')
            
            assert result is not None, "GPU processing failed"
            assert result.shape == grid_size, "Output shape mismatch"
            
            duration = time.time() - start_time
            
            return TestResult(
                test_name="GPU Acceleration Unit Test",
                status="PASS",
                duration=duration,
                details=f"GPU backend: {backend}",
                metrics={
                    'backend': backend,
                    'grid_size': f"{grid_size[0]}x{grid_size[1]}",
                    'processing_time': duration
                }
            )
            
        except Exception as e:
            duration = time.time() - start_time
            return TestResult(
                test_name="GPU Acceleration Unit Test",
                status="FAIL",
                duration=duration,
                details=str(e)
            )

    def _test_precipitation_processing(self) -> TestResult:
        """Test precipitation input processing"""
        start_time = time.time()
        
        try:
            # Import precipitation module
            from precipitation_input import PrecipitationProcessor
            
            # Create test processor
            processor = PrecipitationProcessor()
            
            # Test design storm generation
            storm_data = processor.generate_design_storm(
                storm_type='SCS_Type_II',
                duration_hours=6,
                total_rainfall_mm=100,
                time_resolution_minutes=15
            )
            
            assert len(storm_data) > 0, "No storm data generated"
            assert sum(storm_data.values()) > 0, "Zero rainfall total"
            
            # Test spatial interpolation
            grid_shape = (50, 50)
            rainfall_field = processor.interpolate_to_grid(
                storm_data, grid_shape, method='bilinear'
            )
            
            assert rainfall_field.shape == grid_shape, "Grid shape mismatch"
            
            duration = time.time() - start_time
            
            return TestResult(
                test_name="Precipitation Processing Unit Test",
                status="PASS",
                duration=duration,
                details="Precipitation processing components working",
                metrics={
                    'storm_duration': 6,
                    'total_rainfall': 100,
                    'time_steps': len(storm_data),
                    'grid_shape': f"{grid_shape[0]}x{grid_shape[1]}"
                }
            )
            
        except Exception as e:
            duration = time.time() - start_time
            return TestResult(
                test_name="Precipitation Processing Unit Test",
                status="FAIL",
                duration=duration,
                details=str(e)
            )

    def _test_memory_management(self) -> TestResult:
        """Test memory management functionality"""
        start_time = time.time()
        
        try:
            # Import memory management
            from performance_optimization import MemoryManager
            
            # Create memory manager
            manager = MemoryManager()
            
            # Test memory detection
            available_memory = manager.get_available_memory()
            assert available_memory > 0, "Invalid memory detection"
            
            # Test memory allocation tracking
            large_array = np.zeros((1000, 1000), dtype=np.float64)
            memory_usage = manager.get_memory_usage()
            
            # Test memory cleanup
            del large_array
            manager.force_garbage_collection()
            
            duration = time.time() - start_time
            
            return TestResult(
                test_name="Memory Management Unit Test",
                status="PASS",
                duration=duration,
                details="Memory management functioning correctly",
                metrics={
                    'available_memory_gb': available_memory / (1024**3),
                    'memory_usage_mb': memory_usage / (1024**2),
                    'cleanup_successful': True
                }
            )
            
        except Exception as e:
            duration = time.time() - start_time
            return TestResult(
                test_name="Memory Management Unit Test",
                status="FAIL",
                duration=duration,
                details=str(e)
            )

    def _test_file_io(self) -> TestResult:
        """Test file I/O operations"""
        start_time = time.time()
        
        try:
            # Test GeoTIFF operations
            test_array = np.random.rand(100, 100).astype(np.float32)
            temp_file = tempfile.mktemp(suffix='.tif')
            
            # Import required modules
            from osgeo import gdal, osr
            
            # Create test GeoTIFF
            driver = gdal.GetDriverByName('GTiff')
            dataset = driver.Create(temp_file, 100, 100, 1, gdal.GDT_Float32)
            
            # Set spatial reference
            srs = osr.SpatialReference()
            srs.ImportFromEPSG(4326)  # WGS84
            dataset.SetProjection(srs.ExportToWkt())
            
            # Set geotransform
            geotransform = [0, 1, 0, 0, 0, -1]
            dataset.SetGeoTransform(geotransform)
            
            # Write data
            band = dataset.GetRasterBand(1)
            band.WriteArray(test_array)
            band.SetNoDataValue(-9999)
            
            # Close and reopen
            dataset = None
            
            # Read back
            dataset = gdal.Open(temp_file)
            read_array = dataset.ReadAsArray()
            
            assert np.allclose(test_array, read_array), "Data integrity check failed"
            
            # Cleanup
            dataset = None
            os.unlink(temp_file)
            
            duration = time.time() - start_time
            
            return TestResult(
                test_name="File I/O Unit Test",
                status="PASS",
                duration=duration,
                details="File I/O operations successful",
                metrics={
                    'file_format': 'GeoTIFF',
                    'array_shape': test_array.shape,
                    'data_integrity': True
                }
            )
            
        except Exception as e:
            duration = time.time() - start_time
            return TestResult(
                test_name="File I/O Unit Test",
                status="FAIL",
                duration=duration,
                details=str(e)
            )

    def _run_integration_tests(self) -> List[TestResult]:
        """Run integration tests for complete workflows"""
        integration_tests = []
        
        # Test 1: Complete flood simulation workflow
        test_result = self._test_complete_simulation_workflow()
        integration_tests.append(test_result)
        
        # Test 2: GPU-accelerated simulation
        test_result = self._test_gpu_simulation_integration()
        integration_tests.append(test_result)
        
        # Test 3: Precipitation-driven simulation
        test_result = self._test_precipitation_simulation()
        integration_tests.append(test_result)
        
        # Test 4: Advanced performance optimization
        test_result = self._test_performance_optimization_integration()
        integration_tests.append(test_result)
        
        return integration_tests

    def _test_complete_simulation_workflow(self) -> TestResult:
        """Test complete simulation workflow"""
        start_time = time.time()
        
        try:
            # Create test DEM
            dem_data = self._create_test_dem()
            temp_dem = tempfile.mktemp(suffix='.tif')
            self._save_test_raster(dem_data, temp_dem)
            
            # Import simulation components
            from advanced_integration import AdvancedFloodEngine
            
            # Create simulation engine
            engine = AdvancedFloodEngine()
            
            # Configure simulation
            config = {
                'dem_path': temp_dem,
                'initial_water_level': 60.0,
                'time_steps': 5,
                'output_dir': tempfile.mkdtemp(),
                'enable_gpu': False,  # Use CPU for testing
                'enable_precipitation': False
            }
            
            # Run simulation
            result = engine.run_simulation(config)
            
            # Validate results
            assert 'final_layer' in result, "Missing final layer in results"
            assert 'timestep_layers' in result, "Missing timestep layers"
            assert len(result['timestep_layers']) == config['time_steps'], "Incorrect number of timesteps"
            
            # Cleanup
            os.unlink(temp_dem)
            shutil.rmtree(config['output_dir'])
            
            duration = time.time() - start_time
            
            return TestResult(
                test_name="Complete Simulation Workflow",
                status="PASS",
                duration=duration,
                details="Full simulation workflow completed successfully",
                metrics={
                    'time_steps': config['time_steps'],
                    'simulation_duration': duration,
                    'output_layers': len(result['timestep_layers'])
                }
            )
            
        except Exception as e:
            duration = time.time() - start_time
            return TestResult(
                test_name="Complete Simulation Workflow",
                status="FAIL",
                duration=duration,
                details=str(e)
            )

    def _run_performance_tests(self) -> List[TestResult]:
        """Run performance tests for scalability analysis"""
        performance_tests = []
        
        # Test different grid sizes
        grid_sizes = [(100, 100), (200, 200), (500, 500)]
        
        for grid_size in grid_sizes:
            test_result = self._test_performance_scaling(grid_size)
            performance_tests.append(test_result)
        
        return performance_tests

    def _test_performance_scaling(self, grid_size: Tuple[int, int]) -> TestResult:
        """Test performance scaling for different grid sizes"""
        start_time = time.time()
        
        try:
            # Create test data
            dem_data = np.random.rand(*grid_size) * 100
            
            # Import performance optimization
            from performance_optimization import PerformanceProfiler
            
            # Create profiler
            profiler = PerformanceProfiler()
            
            # Start profiling
            profiler.start_section("performance_test")
            
            # Simulate computational work
            result = self._simulate_computation(dem_data)
            
            # End profiling
            profiler.end_section("performance_test")
            
            # Get metrics
            metrics = profiler.get_metrics()
            
            duration = time.time() - start_time
            
            return TestResult(
                test_name=f"Performance Scaling {grid_size[0]}x{grid_size[1]}",
                status="PASS",
                duration=duration,
                details="Performance scaling test completed",
                metrics={
                    'grid_size': f"{grid_size[0]}x{grid_size[1]}",
                    'total_cells': grid_size[0] * grid_size[1],
                    'processing_time': duration,
                    'cells_per_second': (grid_size[0] * grid_size[1]) / duration,
                    'memory_usage': metrics.get('memory_usage_mb', 0)
                }
            )
            
        except Exception as e:
            duration = time.time() - start_time
            return TestResult(
                test_name=f"Performance Scaling {grid_size[0]}x{grid_size[1]}",
                status="FAIL",
                duration=duration,
                details=str(e)
            )

    def _run_benchmark_tests(self) -> List[TestResult]:
        """Run benchmark tests against reference solutions"""
        benchmark_tests = []
        
        # Test against analytical solutions
        test_result = self._test_analytical_benchmark()
        benchmark_tests.append(test_result)
        
        # Test against dam break benchmark
        test_result = self._test_dam_break_benchmark()
        benchmark_tests.append(test_result)
        
        return benchmark_tests

    def _test_analytical_benchmark(self) -> TestResult:
        """Test against analytical solutions"""
        start_time = time.time()
        
        try:
            # Create simple test case with known analytical solution
            # (e.g., uniform flow over flat bottom)
            
            # Generate test case
            nx, ny = 100, 100
            dx, dy = 1.0, 1.0
            
            # Flat bottom with small slope
            z = np.ones((ny, nx)) * 0.0
            z[:, :] = np.arange(nx) * 0.001  # 0.1% slope
            
            # Initial water depth
            h0 = 1.0
            
            # Manning's roughness
            n = 0.03
            
            # Analytical solution for uniform flow
            # Q = (1/n) * A * R^(2/3) * S^(1/2)
            # For wide channel: R ≈ h, A = w*h
            slope = 0.001
            width = ny * dy
            area = h0 * width
            hydraulic_radius = h0
            
            analytical_velocity = (1/n) * hydraulic_radius**(2/3) * slope**(1/2)
            analytical_discharge = analytical_velocity * area
            
            # Run FloodEngine simulation
            from saint_venant_2d_fixed import SaintVenant2D
            solver = SaintVenant2D(nx, ny, dx, dy)
            
            # Set initial conditions
            solver.h[:] = h0
            solver.z[:] = z
            solver.u[:] = 0.0
            solver.v[:] = 0.0
            
            # Run steady state
            for _ in range(100):
                solver.update()
            
            # Compare results
            simulated_velocity = np.mean(solver.u)
            relative_error = abs(simulated_velocity - analytical_velocity) / analytical_velocity
            
            duration = time.time() - start_time
            
            status = "PASS" if relative_error < self.test_config['accuracy_tolerance'] else "FAIL"
            
            return TestResult(
                test_name="Analytical Benchmark Test",
                status=status,
                duration=duration,
                details=f"Relative error: {relative_error:.4f}",
                metrics={
                    'analytical_velocity': analytical_velocity,
                    'simulated_velocity': simulated_velocity,
                    'relative_error': relative_error,
                    'tolerance': self.test_config['accuracy_tolerance']
                }
            )
            
        except Exception as e:
            duration = time.time() - start_time
            return TestResult(
                test_name="Analytical Benchmark Test",
                status="FAIL",
                duration=duration,
                details=str(e)
            )

    def _run_regression_tests(self) -> List[TestResult]:
        """Run regression tests to ensure no performance degradation"""
        regression_tests = []
        
        # Load historical performance data
        historical_data = self._load_historical_performance()
        
        if historical_data:
            # Test current performance against historical baseline
            test_result = self._test_performance_regression(historical_data)
            regression_tests.append(test_result)
        
        return regression_tests

    def _create_test_dem(self) -> np.ndarray:
        """Create synthetic DEM for testing"""
        size = 100
        x = np.linspace(0, 10, size)
        y = np.linspace(0, 10, size)
        X, Y = np.meshgrid(x, y)
        
        # Create a valley with some complexity
        dem = 50 + 5 * np.sin(X) + 3 * np.cos(Y) + (X**2 + Y**2) * 0.1
        
        return dem.astype(np.float32)

    def _save_test_raster(self, data: np.ndarray, filename: str):
        """Save test data as GeoTIFF"""
        from osgeo import gdal, osr
        
        driver = gdal.GetDriverByName('GTiff')
        dataset = driver.Create(filename, data.shape[1], data.shape[0], 1, gdal.GDT_Float32)
        
        # Set spatial reference
        srs = osr.SpatialReference()
        srs.ImportFromEPSG(4326)
        dataset.SetProjection(srs.ExportToWkt())
        
        # Set geotransform
        geotransform = [0, 1, 0, 0, 0, -1]
        dataset.SetGeoTransform(geotransform)
        
        # Write data
        band = dataset.GetRasterBand(1)
        band.WriteArray(data)
        band.SetNoDataValue(-9999)
        
        dataset = None

    def _simulate_computation(self, data: np.ndarray) -> np.ndarray:
        """Simulate computational work for performance testing"""
        # Simulate Saint-Venant calculations
        result = np.zeros_like(data)
        
        for i in range(5):  # Multiple iterations
            # Simulate finite difference calculations
            result[1:-1, 1:-1] = (
                data[1:-1, 1:-1] + 
                0.1 * (data[2:, 1:-1] + data[:-2, 1:-1] + 
                       data[1:-1, 2:] + data[1:-1, :-2] - 4 * data[1:-1, 1:-1])
            )
            data = result.copy()
        
        return result

    def _store_test_results(self, results: Dict[str, List[TestResult]]):
        """Store test results in database"""
        conn = sqlite3.connect(str(self.results_db))
        cursor = conn.cursor()
        
        for test_type, test_list in results.items():
            for test_result in test_list:
                cursor.execute('''
                    INSERT INTO test_results 
                    (timestamp, test_name, test_type, status, duration, details, metrics)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (
                    test_result.timestamp.isoformat(),
                    test_result.test_name,
                    test_type,
                    test_result.status,
                    test_result.duration,
                    test_result.details,
                    json.dumps(test_result.metrics)
                ))
        
        conn.commit()
        conn.close()

    def _generate_test_report(self, results: Dict[str, List[TestResult]]):
        """Generate comprehensive test report"""
        report_file = self.reports_dir / f"qa_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
        
        html_content = self._create_html_report(results)
        
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        logger.info(f"Test report generated: {report_file}")

    def _create_html_report(self, results: Dict[str, List[TestResult]]) -> str:
        """Create HTML test report"""
        total_tests = sum(len(tests) for tests in results.values())
        passed_tests = sum(len([t for t in tests if t.status == 'PASS']) for tests in results.values())
        
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>FloodEngine QA Report</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 40px; }}
                .header {{ background: #2e7d32; color: white; padding: 20px; border-radius: 5px; }}
                .summary {{ background: #f5f5f5; padding: 15px; margin: 20px 0; border-radius: 5px; }}
                .test-section {{ margin: 20px 0; }}
                .test-result {{ padding: 10px; margin: 5px 0; border-radius: 3px; }}
                .pass {{ background: #e8f5e8; border-left: 4px solid #4caf50; }}
                .fail {{ background: #ffeaa7; border-left: 4px solid #f44336; }}
                .metrics {{ font-size: 0.9em; color: #666; margin-top: 5px; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>FloodEngine v4.0 - Quality Assurance Report</h1>
                <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            </div>
            
            <div class="summary">
                <h2>Test Summary</h2>
                <p><strong>Total Tests:</strong> {total_tests}</p>
                <p><strong>Passed:</strong> {passed_tests}</p>
                <p><strong>Failed:</strong> {total_tests - passed_tests}</p>
                <p><strong>Success Rate:</strong> {(passed_tests/total_tests*100):.1f}%</p>
            </div>
        """
        
        # Add test sections
        for test_type, test_list in results.items():
            html += f'<div class="test-section"><h2>{test_type.replace("_", " ").title()}</h2>'
            
            for test in test_list:
                css_class = test.status.lower()
                html += f'''
                <div class="test-result {css_class}">
                    <h3>{test.test_name}</h3>
                    <p><strong>Status:</strong> {test.status}</p>
                    <p><strong>Duration:</strong> {test.duration:.3f}s</p>
                    <p><strong>Details:</strong> {test.details}</p>
                    <div class="metrics">
                        <strong>Metrics:</strong> {json.dumps(test.metrics, indent=2)}
                    </div>
                </div>
                '''
            
            html += '</div>'
        
        html += '</body></html>'
        
        return html

    def _load_historical_performance(self) -> Optional[Dict]:
        """Load historical performance data"""
        try:
            conn = sqlite3.connect(str(self.results_db))
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT * FROM performance_history 
                ORDER BY timestamp DESC 
                LIMIT 10
            ''')
            
            rows = cursor.fetchall()
            conn.close()
            
            if rows:
                return {
                    'historical_data': rows,
                    'baseline_performance': rows[0] if rows else None
                }
            
        except Exception as e:
            logger.warning(f"Could not load historical performance data: {e}")
        
        return None

    def _test_performance_regression(self, historical_data: Dict) -> TestResult:
        """Test for performance regression"""
        start_time = time.time()
        
        try:
            # Run current performance test
            current_performance = self._measure_current_performance()
            
            # Compare with baseline
            baseline = historical_data.get('baseline_performance')
            if baseline:
                performance_ratio = current_performance / baseline[4]  # execution_time
                regression_detected = performance_ratio > (1 + self.test_config['performance_tolerance'])
                
                status = "FAIL" if regression_detected else "PASS"
                details = f"Performance ratio: {performance_ratio:.2f}"
                
            else:
                status = "SKIP"
                details = "No baseline data available"
            
            duration = time.time() - start_time
            
            return TestResult(
                test_name="Performance Regression Test",
                status=status,
                duration=duration,
                details=details,
                metrics={
                    'current_performance': current_performance,
                    'baseline_performance': baseline[4] if baseline else None,
                    'performance_ratio': performance_ratio if baseline else None
                }
            )
            
        except Exception as e:
            duration = time.time() - start_time
            return TestResult(
                test_name="Performance Regression Test",
                status="FAIL",
                duration=duration,
                details=str(e)
            )

    def _measure_current_performance(self) -> float:
        """Measure current performance for regression testing"""
        # Standard performance test
        test_data = np.random.rand(500, 500)
        start_time = time.time()
        
        # Simulate computational work
        result = self._simulate_computation(test_data)
        
        return time.time() - start_time

    def create_test_datasets(self):
        """Create comprehensive test datasets for validation"""
        logger.info("Creating test datasets...")
        
        # Create various DEM scenarios
        test_cases = {
            'flat_terrain': self._create_flat_terrain_dem(),
            'valley_terrain': self._create_valley_terrain_dem(),
            'urban_terrain': self._create_urban_terrain_dem(),
            'coastal_terrain': self._create_coastal_terrain_dem()
        }
        
        # Save test DEMs
        for name, dem_data in test_cases.items():
            dem_file = self.test_data_dir / f"{name}_dem.tif"
            self._save_test_raster(dem_data, str(dem_file))
            logger.info(f"Created test DEM: {dem_file}")
        
        # Create test metadata
        metadata = {
            'created': datetime.now().isoformat(),
            'test_cases': list(test_cases.keys()),
            'grid_size': test_cases['flat_terrain'].shape,
            'spatial_resolution': 1.0,
            'vertical_units': 'meters',
            'coordinate_system': 'WGS84'
        }
        
        metadata_file = self.test_data_dir / "test_metadata.json"
        with open(metadata_file, 'w') as f:
            json.dump(metadata, f, indent=2)

    def _create_flat_terrain_dem(self) -> np.ndarray:
        """Create flat terrain DEM for basic testing"""
        size = 200
        dem = np.ones((size, size)) * 50.0
        # Add small random variation
        dem += np.random.normal(0, 0.1, (size, size))
        return dem.astype(np.float32)

    def _create_valley_terrain_dem(self) -> np.ndarray:
        """Create valley terrain DEM"""
        size = 200
        x = np.linspace(-5, 5, size)
        y = np.linspace(-5, 5, size)
        X, Y = np.meshgrid(x, y)
        
        # Create valley shape
        dem = 100 + X**2 + Y**2 * 0.5
        return dem.astype(np.float32)

    def _create_urban_terrain_dem(self) -> np.ndarray:
        """Create urban terrain DEM with buildings"""
        size = 200
        dem = np.ones((size, size)) * 50.0
        
        # Add buildings (elevated areas)
        building_locations = [
            (50, 50, 20, 20, 10),  # x, y, width, height, elevation
            (100, 100, 30, 30, 15),
            (150, 80, 25, 25, 12)
        ]
        
        for x, y, w, h, elev in building_locations:
            dem[y:y+h, x:x+w] += elev
        
        return dem.astype(np.float32)

    def _create_coastal_terrain_dem(self) -> np.ndarray:
        """Create coastal terrain DEM"""
        size = 200
        x = np.linspace(0, 10, size)
        y = np.linspace(0, 10, size)
        X, Y = np.meshgrid(x, y)
        
        # Create coastal slope
        dem = X * 2 + np.sin(Y) * 5
        # Add some underwater areas
        dem[X < 2] = -5 + X[X < 2] * 2
        
        return dem.astype(np.float32)

def main():
    """Main function for running QA framework"""
    print("FloodEngine v4.0 - Quality Assurance Framework")
    print("=" * 60)
    
    # Initialize QA framework
    workspace_path = os.path.dirname(os.path.abspath(__file__))
    qa_framework = QualityAssuranceFramework(workspace_path)
    
    try:
        # Create test datasets
        qa_framework.create_test_datasets()
        
        # Run comprehensive test suite
        results = qa_framework.run_comprehensive_test_suite()
        
        # Print summary
        total_tests = sum(len(tests) for tests in results.values())
        passed_tests = sum(len([t for t in tests if t.status == 'PASS']) for tests in results.values())
        
        print(f"\nQA Summary:")
        print(f"Total Tests: {total_tests}")
        print(f"Passed: {passed_tests}")
        print(f"Failed: {total_tests - passed_tests}")
        print(f"Success Rate: {(passed_tests/total_tests*100):.1f}%")
        
        if passed_tests == total_tests:
            print("\n🎉 All tests passed! FloodEngine v4.0 is ready for production.")
        else:
            print(f"\n⚠️ {total_tests - passed_tests} tests failed. Review the detailed report.")
            
    except Exception as e:
        logger.error(f"QA framework execution failed: {e}")
        raise

if __name__ == "__main__":
    main()
