#!/usr/bin/env python3
"""
Test script to diagnose the DEM selection issue in FloodEngine UI.
This script simulates the problem and verifies the fix.
"""

from PyQt5.QtWidgets import QLineEdit, QRadioButton

class MockFloodEngineUI:
    """Mock class to simulate the FloodEngine UI behavior."""
    
    def __init__(self):
        # Simulate UI elements
        self.basic_radio = QRadioButton()
        self.basic_dem_path = QLineEdit()
        self.basic_output_folder = QLineEdit()
        
        # Set basic mode as selected
        self.basic_radio.setChecked(True)
        
        # Set some test paths
        self.basic_dem_path.setText("C:/test/dem.tif")
        self.basic_output_folder.setText("C:/test/output")
    
    def test_original_problematic_code(self):
        """Test the original problematic code that could cause empty DEM path."""
        print("=== Testing Original Problematic Code ===")
        
        if self.basic_radio.isChecked():
            # Basic mode - this should work
            dem_path = self.basic_dem_path.text().strip()
            output_folder = self.basic_output_folder.text().strip()
            print(f"Basic mode - DEM path: '{dem_path}'")
            print(f"Basic mode - Output folder: '{output_folder}'")
        else:
            # Advanced mode - this is problematic
            dem_path = getattr(self, 'adv_dem_path', QLineEdit()).text().strip()
            output_folder = getattr(self, 'adv_output_folder', QLineEdit()).text().strip()
            print(f"Advanced mode - DEM path: '{dem_path}'")
            print(f"Advanced mode - Output folder: '{output_folder}'")
        
        # Validation
        if not dem_path:
            print("❌ ERROR: Please select a DEM file. Current path is empty.")
            return False
        else:
            print("✅ DEM path validation passed")
            return True
    
    def test_problematic_scenario(self):
        """Test what happens when basic_radio is not checked."""
        print("\n=== Testing Problematic Scenario (Advanced Mode) ===")
        
        # Simulate advanced mode selection
        self.basic_radio.setChecked(False)
        
        return self.test_original_problematic_code()
    
    def test_fixed_code(self):
        """Test the improved code that should handle both modes correctly."""
        print("\n=== Testing Fixed Code ===")
        
        # Reset to basic mode
        self.basic_radio.setChecked(True)
        
        if self.basic_radio.isChecked():
            # Basic mode parameters - access UI elements directly
            dem_path = self.basic_dem_path.text().strip()
            output_folder = self.basic_output_folder.text().strip()
            print(f"Basic mode - DEM path: '{dem_path}'")
            print(f"Basic mode - Output folder: '{output_folder}'")
        else:
            # Advanced mode parameters - check if elements exist first
            if hasattr(self, 'adv_dem_path') and self.adv_dem_path:
                dem_path = self.adv_dem_path.text().strip()
            else:
                dem_path = ""
                print("⚠️  Advanced mode DEM UI element not implemented yet")
                
            if hasattr(self, 'adv_output_folder') and self.adv_output_folder:
                output_folder = self.adv_output_folder.text().strip()
            else:
                output_folder = ""
                print("⚠️  Advanced mode output UI element not implemented yet")
        
        # Validation
        if not dem_path:
            print("❌ ERROR: Please select a DEM file. Current path is empty.")
            return False
        else:
            print("✅ DEM path validation passed")
            return True

def main():
    """Run the diagnostic tests."""
    print("FloodEngine DEM Selection Issue Diagnosis")
    print("=" * 50)
    
    # Create mock UI
    ui = MockFloodEngineUI()
    
    # Test 1: Basic mode (should work)
    result1 = ui.test_original_problematic_code()
    
    # Test 2: Advanced mode (problematic)
    result2 = ui.test_problematic_scenario()
    
    # Test 3: Fixed implementation
    ui.basic_radio.setChecked(True)  # Reset to basic mode
    result3 = ui.test_fixed_code()
    
    print(f"\n=== Summary ===")
    print(f"Basic mode test: {'✅ PASS' if result1 else '❌ FAIL'}")
    print(f"Advanced mode test: {'✅ PASS' if result2 else '❌ FAIL (Expected - shows the bug)'}")
    print(f"Fixed code test: {'✅ PASS' if result3 else '❌ FAIL'}")
    
    if not result2:
        print("\n🔍 DIAGNOSIS: The issue occurs when the UI tries to access advanced mode")
        print("   elements that don't exist, causing getattr() to create empty QLineEdit")
        print("   objects, which return empty strings and trigger the validation error.")

if __name__ == "__main__":
    main()
