#!/usr/bin/env python3
"""
Cleanup script for extreme velocity files.
This script finds and caps any existing velocity files that contain extreme values.
"""

import numpy as np
import os
import glob
import logging

def cleanup_velocity_files(directory):
    """
    Find and clean up velocity files with extreme values.
    
    Parameters:
        directory (str): Directory to search for velocity files
    """
    
    # Set up logging
    logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
    logger = logging.getLogger("cleanup_velocity_files")
    
    logger.info(f"🧹 Cleaning up velocity files in: {directory}")
    
    # Find all numpy files that might contain velocities
    velocity_patterns = [
        "*velocity*.npy",
        "*saint_venant*.npy", 
        "*flow_velocity*.npy"
    ]
    
    files_processed = 0
    files_capped = 0
    
    for pattern in velocity_patterns:
        search_path = os.path.join(directory, "**", pattern)
        files = glob.glob(search_path, recursive=True)
        
        for file_path in files:
            try:
                logger.info(f"📂 Processing: {os.path.basename(file_path)}")
                
                # Load the file
                data = np.load(file_path)
                
                # Check if it's a velocity field
                if len(data.shape) == 2:  # 2D array
                    max_val = np.max(np.abs(data))
                    
                    if max_val > 10.0:  # Extreme velocity detected
                        logger.warning(f"🚨 EXTREME VELOCITY DETECTED: {max_val:.1f} m/s in {os.path.basename(file_path)}")
                        
                        # Create backup
                        backup_path = file_path + ".backup"
                        if not os.path.exists(backup_path):
                            np.save(backup_path, data)
                            logger.info(f"💾 Created backup: {os.path.basename(backup_path)}")
                        
                        # Cap the velocities
                        MAX_VELOCITY = 8.0
                        
                        if 'velocity_x' in file_path or 'velocity_y' in file_path:
                            # Component velocity - allow negative values
                            data_capped = np.clip(data, -MAX_VELOCITY, MAX_VELOCITY)
                        else:
                            # Magnitude velocity - only positive values
                            data_capped = np.clip(data, 0.0, MAX_VELOCITY)
                        
                        # Save the capped version
                        np.save(file_path, data_capped)
                        
                        new_max = np.max(np.abs(data_capped))
                        logger.info(f"✅ CAPPED: {max_val:.1f} m/s → {new_max:.1f} m/s")
                        
                        files_capped += 1
                    else:
                        logger.info(f"✅ OK: Max velocity {max_val:.1f} m/s")
                
                files_processed += 1
                
            except Exception as e:
                logger.error(f"❌ Error processing {file_path}: {str(e)}")
    
    logger.info(f"🎯 Summary:")
    logger.info(f"  • Files processed: {files_processed}")
    logger.info(f"  • Files capped: {files_capped}")
    logger.info(f"  • Files with reasonable velocities: {files_processed - files_capped}")
    
    return files_processed, files_capped

def cleanup_saint_venant_output_directory(directory):
    """
    Clean up Saint-Venant output directory specifically.
    
    Parameters:
        directory (str): Directory containing Saint-Venant outputs
    """
    
    logger = logging.getLogger("cleanup_saint_venant")
    logger.info(f"🔧 Cleaning Saint-Venant output directory: {directory}")
    
    if not os.path.exists(directory):
        logger.warning(f"⚠️  Directory does not exist: {directory}")
        return 0, 0
    
    # Look for specific Saint-Venant files
    saint_venant_files = [
        "velocity_x.npy",
        "velocity_y.npy", 
        "velocity_magnitude.npy",
        "water_depth.npy"
    ]
    
    files_processed = 0
    files_capped = 0
    
    for filename in saint_venant_files:
        file_path = os.path.join(directory, filename)
        
        if os.path.exists(file_path):
            try:
                logger.info(f"📂 Processing Saint-Venant file: {filename}")
                
                data = np.load(file_path)
                
                # Check for extreme values
                if 'velocity' in filename:
                    max_val = np.max(np.abs(data))
                    
                    if max_val > 10.0:  # Extreme velocity
                        logger.warning(f"🚨 EXTREME VELOCITY: {max_val:.1f} m/s in {filename}")
                        
                        # Create backup
                        backup_path = file_path + ".extreme_backup"
                        if not os.path.exists(backup_path):
                            np.save(backup_path, data)
                            logger.info(f"💾 Created backup: {filename}.extreme_backup")
                        
                        # Cap the velocities
                        MAX_VELOCITY = 8.0
                        
                        if 'magnitude' in filename:
                            data_capped = np.clip(data, 0.0, MAX_VELOCITY)
                        else:
                            data_capped = np.clip(data, -MAX_VELOCITY, MAX_VELOCITY)
                        
                        # Save capped version
                        np.save(file_path, data_capped)
                        
                        new_max = np.max(np.abs(data_capped))
                        logger.info(f"✅ CAPPED: {max_val:.1f} m/s → {new_max:.1f} m/s")
                        
                        files_capped += 1
                    else:
                        logger.info(f"✅ OK: Max velocity {max_val:.1f} m/s")
                
                files_processed += 1
                
            except Exception as e:
                logger.error(f"❌ Error processing {filename}: {str(e)}")
    
    return files_processed, files_capped

if __name__ == "__main__":
    print("=" * 60)
    print("EXTREME VELOCITY CLEANUP TOOL")
    print("=" * 60)
    
    # Get the current directory
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Check for common output directories
    output_dirs = [
        os.path.join(current_dir, "output"),
        os.path.join(current_dir, "saint_venant_output"),
        os.path.join(current_dir, "results"),
        current_dir
    ]
    
    total_processed = 0
    total_capped = 0
    
    for output_dir in output_dirs:
        if os.path.exists(output_dir):
            print(f"\n🔍 Checking directory: {output_dir}")
            
            # General cleanup
            processed, capped = cleanup_velocity_files(output_dir)
            total_processed += processed
            total_capped += capped
            
            # Saint-Venant specific cleanup
            sv_processed, sv_capped = cleanup_saint_venant_output_directory(output_dir)
            total_processed += sv_processed
            total_capped += sv_capped
    
    print("\n" + "=" * 60)
    print(f"🎯 FINAL SUMMARY:")
    print(f"  • Total files processed: {total_processed}")
    print(f"  • Total files capped: {total_capped}")
    
    if total_capped > 0:
        print(f"✅ Successfully capped {total_capped} files with extreme velocities")
        print(f"💾 Backup files created for safety")
    else:
        print("✅ No extreme velocities found - all files are clean")
    
    print("=" * 60)
