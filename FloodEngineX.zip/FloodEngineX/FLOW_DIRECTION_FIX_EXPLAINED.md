# Flow Direction Fix Explained

## The Problem

In the original FloodEngine implementation, when using the Q mode (flow rate), water sometimes flowed **backwards** in channels - from low to high elevation points. This produced unrealistic results that didn't match how water actually flows in nature.

### Original Behavior:
- Water filled like a "bathtub" from random low areas
- Flow often moved uphill against gravity
- Results didn't match realistic flow patterns

## The Fix

The new implementation ensures water starts from the **highest** points in channels and flows **downhill** following natural terrain, just like real water would.

### Fixed Behavior:
- Water starts ONLY from highest elevation points
- Flow follows natural downhill flow paths
- Results match realistic hydraulic behavior

## How to Use the Fix

The plugin now includes UI controls to select which algorithm to use:

### In Flow Q Mode:
- Check "Use fixed flow direction (water flows from high to low)" to enable the fix
- The fixed algorithm will be used by default
- Results will be displayed in RED to distinguish them from the original algorithm

### In Water Level Mode:
- Check "Use fixed flow direction (propagate from high points)" to enable the fix
- The fixed algorithm will prevent the "bathtub filling" behavior
- Water will propagate from high points instead of filling from arbitrary low points

## Technical Comparison

| Aspect | Original Implementation | Fixed Implementation |
|--------|-------------------------|----------------------|
| **Start Points** | Arbitrary points including low areas | Only highest elevation points in channels |
| **Flow Direction** | Sometimes flowed uphill | Always flows downhill from high to low |
| **Model Approach** | "Bathtub filling" style | True directional flow following terrain |
| **Output Color** | Blue | Red (for easy comparison) |
| **Output Name** | "flood_X.XXm" | "FIXED_flood_X.XXm" |

## Visual Guide

When comparing the results:

### Original (Blue Layer):
- Blue polygons show water filling from low areas
- Often shows water in disconnected areas
- May show unrealistic flow patterns against terrain

### Fixed (Red Layer):
- Red polygons show water flowing from high points downhill
- Connected flow following natural channels
- Realistic hydraulic behavior respecting terrain

## Using the Fix

The fix is now the default behavior when running FloodEngine with a Q value (flow rate). No special action is needed - the plugin will automatically use the improved flow direction algorithm.

To revert to the original behavior (not recommended), you would need to modify the code in `model_hydraulic.py` to set `FIXED_FLOW_AVAILABLE = False`.

## Verifying the Fix Works

1. Run a flow simulation with Q > 0
2. Look for:
   - "FIXED" in the output layer name
   - Red color (instead of blue)
   - Console message: "Using FIXED FLOW-BASED model"
   - Flow starting from highest points in channels
