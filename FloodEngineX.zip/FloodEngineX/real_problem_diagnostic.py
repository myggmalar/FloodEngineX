# -*- coding: utf-8 -*-
"""
REAL PROBLEM DIAGNOSTIC for FloodEngine
Identifies the actual reasons why river flooding shows tiny blue dots instead of large flooded areas
"""

import numpy as np
import gdal
import ogr
import osr
import os
import matplotlib.pyplot as plt
from typing import Dict, List, Tuple

def diagnose_real_flooding_problem(dem_path: str, stream_path: str, water_level: float, 
                                 output_folder: str = "diagnostic_real_problem"):
    """
    Diagnose the REAL reasons why flooding isn't working properly
    """
    
    os.makedirs(output_folder, exist_ok=True)
    print("🔍 DIAGNOSING REAL FLOODING PROBLEM")
    print("="*60)
    
    # 1. Check if stream burning actually worked
    print("\n1️⃣ CHECKING STREAM BURNING EFFECTIVENESS...")
    stream_burn_analysis = check_stream_burning_reality(dem_path, stream_path, output_folder)
    
    # 2. Check coordinate system alignment
    print("\n2️⃣ CHECKING COORDINATE SYSTEM ALIGNMENT...")
    coord_analysis = check_coordinate_alignment(dem_path, stream_path)
    
    # 3. Check water level vs terrain relationship  
    print("\n3️⃣ CHECKING WATER LEVEL VS TERRAIN...")
    water_level_analysis = check_water_level_reality(dem_path, water_level, stream_path)
    
    # 4. Check DEM characteristics around streams
    print("\n4️⃣ CHECKING DEM CHARACTERISTICS...")
    dem_analysis = check_dem_around_streams(dem_path, stream_path, output_folder)
    
    # 5. Simulate what SHOULD happen vs what IS happening
    print("\n5️⃣ COMPARING EXPECTED VS ACTUAL FLOODING...")
    flooding_comparison = compare_expected_vs_actual_flooding(dem_path, stream_path, water_level, output_folder)
    
    # 6. Generate actionable recommendations
    print("\n6️⃣ GENERATING RECOMMENDATIONS...")
    recommendations = generate_real_solutions(stream_burn_analysis, coord_analysis, 
                                            water_level_analysis, dem_analysis, flooding_comparison)
    
    # Save comprehensive report
    save_diagnostic_report(output_folder, stream_burn_analysis, coord_analysis, 
                          water_level_analysis, dem_analysis, flooding_comparison, recommendations)
    
    print(f"\n✅ REAL PROBLEM DIAGNOSIS COMPLETE!")
    print(f"📊 Check results in: {output_folder}")
    
    return {
        'stream_burning': stream_burn_analysis,
        'coordinates': coord_analysis, 
        'water_level': water_level_analysis,
        'dem_characteristics': dem_analysis,
        'flooding_comparison': flooding_comparison,
        'recommendations': recommendations
    }


def check_stream_burning_reality(dem_path: str, stream_path: str, output_folder: str) -> Dict:
    """Check if stream burning actually created visible channels"""
    
    analysis = {
        'burning_detected': False,
        'channel_depth_stats': {},
        'channel_width_stats': {},
        'issues_found': [],
        'evidence_files': []
    }
    
    try:
        # Check if burned DEM exists
        burned_dem_candidates = [
            os.path.join(os.path.dirname(dem_path), "burned_dem.tif"),
            os.path.join(output_folder, "burned_dem.tif"),
            dem_path.replace(".tif", "_burned.tif")
        ]
        
        burned_dem_path = None
        for candidate in burned_dem_candidates:
            if os.path.exists(candidate):
                burned_dem_path = candidate
                break
        
        if burned_dem_path is None:
            analysis['issues_found'].append("❌ No burned DEM found - stream burning may not have run")
            return analysis
        
        # Load original and burned DEMs
        orig_ds = gdal.Open(dem_path)
        burned_ds = gdal.Open(burned_dem_path)
        
        if orig_ds is None or burned_ds is None:
            analysis['issues_found'].append("❌ Cannot open DEM files for comparison")
            return analysis
        
        orig_array = orig_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
        burned_array = burned_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
        geotransform = orig_ds.GetGeoTransform()
        
        # Calculate difference
        diff_array = orig_array - burned_array
        
        # Find areas with significant elevation change (burned areas)
        significant_burn = diff_array > 0.1  # More than 10cm change
        burned_pixels = np.sum(significant_burn)
        
        print(f"   Burned pixels found: {burned_pixels:,}")
        
        if burned_pixels == 0:
            analysis['issues_found'].append("❌ CRITICAL: No elevation changes detected - stream burning completely failed!")
        else:
            analysis['burning_detected'] = True
            
            # Analyze burn characteristics
            burn_depths = diff_array[significant_burn]
            analysis['channel_depth_stats'] = {
                'min_depth': float(np.min(burn_depths)),
                'max_depth': float(np.max(burn_depths)), 
                'mean_depth': float(np.mean(burn_depths)),
                'median_depth': float(np.median(burn_depths))
            }
            
            print(f"   Burn depth range: {analysis['channel_depth_stats']['min_depth']:.2f} to {analysis['channel_depth_stats']['max_depth']:.2f}m")
            print(f"   Average burn depth: {analysis['channel_depth_stats']['mean_depth']:.2f}m")
            
            # Check if burns are deep enough to matter
            if analysis['channel_depth_stats']['mean_depth'] < 1.0:
                analysis['issues_found'].append(f"⚠️ Shallow burning: {analysis['channel_depth_stats']['mean_depth']:.2f}m average - may not affect flow significantly")
            
            # Create burn difference visualization
            diff_plot_path = os.path.join(output_folder, "burn_difference_analysis.png")
            create_burn_difference_plot(orig_array, burned_array, diff_array, diff_plot_path)
            analysis['evidence_files'].append(diff_plot_path)
        
        # Save difference raster for inspection
        diff_raster_path = os.path.join(output_folder, "burn_difference.tif")
        save_array_as_raster(diff_array, geotransform, orig_ds.GetProjection(), diff_raster_path)
        analysis['evidence_files'].append(diff_raster_path)
        
        orig_ds = None
        burned_ds = None
        
    except Exception as e:
        analysis['issues_found'].append(f"❌ Error checking stream burning: {str(e)}")
    
    return analysis


def check_coordinate_alignment(dem_path: str, stream_path: str) -> Dict:
    """Check if DEM and streams are in the same coordinate system and actually overlap"""
    
    analysis = {
        'coordinate_systems_match': False,
        'spatial_overlap': False,
        'dem_bounds': None,
        'stream_bounds': None,
        'overlap_area': 0.0,
        'issues_found': []
    }
    
    try:
        # Get DEM spatial info
        dem_ds = gdal.Open(dem_path)
        dem_geotransform = dem_ds.GetGeoTransform()
        dem_projection = dem_ds.GetProjection()
        
        # Calculate DEM bounds
        dem_bounds = {
            'min_x': dem_geotransform[0],
            'max_x': dem_geotransform[0] + dem_ds.RasterXSize * dem_geotransform[1],
            'min_y': dem_geotransform[3] + dem_ds.RasterYSize * dem_geotransform[5],
            'max_y': dem_geotransform[3]
        }
        analysis['dem_bounds'] = dem_bounds
        
        print(f"   DEM bounds: X({dem_bounds['min_x']:.0f} to {dem_bounds['max_x']:.0f}) Y({dem_bounds['min_y']:.0f} to {dem_bounds['max_y']:.0f})")
        
        # Get stream spatial info
        stream_ds = ogr.Open(stream_path)
        stream_layer = stream_ds.GetLayer()
        stream_srs = stream_layer.GetSpatialRef()
        
        # Get stream bounds
        extent = stream_layer.GetExtent()  # (minx, maxx, miny, maxy)
        stream_bounds = {
            'min_x': extent[0],
            'max_x': extent[1], 
            'min_y': extent[2],
            'max_y': extent[3]
        }
        analysis['stream_bounds'] = stream_bounds
        
        print(f"   Stream bounds: X({stream_bounds['min_x']:.0f} to {stream_bounds['max_x']:.0f}) Y({stream_bounds['min_y']:.0f} to {stream_bounds['max_y']:.0f})")
        
        # Check coordinate system match
        dem_srs = osr.SpatialReference()
        dem_srs.ImportFromWkt(dem_projection)
        
        if stream_srs and dem_srs:
            if stream_srs.IsSame(dem_srs):
                analysis['coordinate_systems_match'] = True
                print("   ✅ Coordinate systems match")
            else:
                analysis['issues_found'].append("❌ CRITICAL: Coordinate systems don't match!")
                print(f"   DEM CRS: {dem_srs.GetAttrValue('AUTHORITY', 1) if dem_srs.GetAttrValue('AUTHORITY') else 'Unknown'}")
                print(f"   Stream CRS: {stream_srs.GetAttrValue('AUTHORITY', 1) if stream_srs.GetAttrValue('AUTHORITY') else 'Unknown'}")
        
        # Check spatial overlap
        x_overlap = (stream_bounds['max_x'] > dem_bounds['min_x'] and stream_bounds['min_x'] < dem_bounds['max_x'])
        y_overlap = (stream_bounds['max_y'] > dem_bounds['min_y'] and stream_bounds['min_y'] < dem_bounds['max_y'])
        
        if x_overlap and y_overlap:
            analysis['spatial_overlap'] = True
            
            # Calculate overlap area
            overlap_min_x = max(dem_bounds['min_x'], stream_bounds['min_x'])
            overlap_max_x = min(dem_bounds['max_x'], stream_bounds['max_x'])
            overlap_min_y = max(dem_bounds['min_y'], stream_bounds['min_y'])
            overlap_max_y = min(dem_bounds['max_y'], stream_bounds['max_y'])
            
            analysis['overlap_area'] = (overlap_max_x - overlap_min_x) * (overlap_max_y - overlap_min_y)
            print(f"   ✅ Spatial overlap detected: {analysis['overlap_area']/1000000:.2f} km²")
        else:
            analysis['issues_found'].append("❌ CRITICAL: DEM and streams don't overlap spatially!")
            print("   ❌ No spatial overlap - streams and DEM are in completely different areas")
        
        dem_ds = None
        stream_ds = None
        
    except Exception as e:
        analysis['issues_found'].append(f"❌ Error checking coordinate alignment: {str(e)}")
    
    return analysis


def check_water_level_reality(dem_path: str, water_level: float, stream_path: str) -> Dict:
    """Check if water level makes sense relative to terrain elevations"""
    
    analysis = {
        'water_level': water_level,
        'terrain_stats': {},
        'flooding_potential': {},
        'issues_found': [],
        'recommendations': []
    }
    
    try:
        # Load DEM
        dem_ds = gdal.Open(dem_path)
        dem_array = dem_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
        nodata = dem_ds.GetRasterBand(1).GetNoDataValue()
        
        # Handle NoData
        if nodata is not None:
            valid_mask = dem_array != nodata
        else:
            valid_mask = ~np.isnan(dem_array)
        
        if not np.any(valid_mask):
            analysis['issues_found'].append("❌ No valid elevation data in DEM")
            return analysis
        
        valid_elevations = dem_array[valid_mask]
        
        # Calculate terrain statistics
        analysis['terrain_stats'] = {
            'min_elevation': float(np.min(valid_elevations)),
            'max_elevation': float(np.max(valid_elevations)),
            'mean_elevation': float(np.mean(valid_elevations)),
            'median_elevation': float(np.median(valid_elevations)),
            'std_elevation': float(np.std(valid_elevations))
        }
        
        print(f"   Terrain elevation range: {analysis['terrain_stats']['min_elevation']:.2f} to {analysis['terrain_stats']['max_elevation']:.2f}m")
        print(f"   Water level: {water_level:.2f}m")
        
        # Check flooding potential
        below_water_level = np.sum(valid_elevations < water_level)
        total_valid = len(valid_elevations)
        flood_percentage = (below_water_level / total_valid) * 100
        
        analysis['flooding_potential'] = {
            'cells_below_water_level': int(below_water_level),
            'total_valid_cells': int(total_valid),
            'potential_flood_percentage': float(flood_percentage)
        }
        
        print(f"   Cells below water level: {below_water_level:,} ({flood_percentage:.1f}%)")
        
        # Identify issues
        if water_level < analysis['terrain_stats']['min_elevation']:
            analysis['issues_found'].append(f"❌ CRITICAL: Water level ({water_level:.2f}m) is below ALL terrain!")
            analysis['recommendations'].append(f"Set water level above {analysis['terrain_stats']['min_elevation']:.2f}m")
        elif water_level < analysis['terrain_stats']['mean_elevation'] * 0.1:
            analysis['issues_found'].append(f"⚠️ Water level ({water_level:.2f}m) seems very low compared to terrain")
        elif flood_percentage < 1:
            analysis['issues_found'].append(f"⚠️ Very little flooding potential: only {flood_percentage:.1f}% of area below water level")
            analysis['recommendations'].append(f"Consider water level around {analysis['terrain_stats']['median_elevation']:.2f}m for significant flooding")
        elif flood_percentage > 90:
            analysis['issues_found'].append(f"⚠️ Almost entire area would flood: {flood_percentage:.1f}% - may be unrealistic")
        
        # Check water level relative to streams specifically
        if stream_path and os.path.exists(stream_path):
            stream_elevation_analysis = check_water_level_vs_streams(dem_path, stream_path, water_level)
            analysis.update(stream_elevation_analysis)
        
        dem_ds = None
        
    except Exception as e:
        analysis['issues_found'].append(f"❌ Error checking water level: {str(e)}")
    
    return analysis


def check_water_level_vs_streams(dem_path: str, stream_path: str, water_level: float) -> Dict:
    """Check water level specifically along stream corridors"""
    
    analysis = {
        'stream_elevation_stats': {},
        'stream_flooding_potential': {}
    }
    
    try:
        # Sample elevations along streams
        dem_ds = gdal.Open(dem_path)
        dem_array = dem_ds.GetRasterBand(1).ReadAsArray()
        geotransform = dem_ds.GetGeoTransform()
        
        stream_ds = ogr.Open(stream_path)
        stream_layer = stream_ds.GetLayer()
        
        stream_elevations = []
        
        for feature in stream_layer:
            geom = feature.GetGeometryRef()
            if geom:
                for i in range(0, geom.GetPointCount(), max(1, geom.GetPointCount()//20)):  # Sample every 20th point
                    x, y = geom.GetX(i), geom.GetY(i)
                    
                    # Convert to pixel coordinates
                    px = int((x - geotransform[0]) / geotransform[1])
                    py = int((y - geotransform[3]) / geotransform[5])
                    
                    if 0 <= px < dem_array.shape[1] and 0 <= py < dem_array.shape[0]:
                        elevation = dem_array[py, px]
                        if not np.isnan(elevation):
                            stream_elevations.append(elevation)
        
        if stream_elevations:
            stream_elevations = np.array(stream_elevations)
            
            analysis['stream_elevation_stats'] = {
                'min_stream_elevation': float(np.min(stream_elevations)),
                'max_stream_elevation': float(np.max(stream_elevations)),
                'mean_stream_elevation': float(np.mean(stream_elevations)),
                'median_stream_elevation': float(np.median(stream_elevations))
            }
            
            # Check flooding along streams
            stream_cells_below_water = np.sum(stream_elevations < water_level)
            stream_flood_percentage = (stream_cells_below_water / len(stream_elevations)) * 100
            
            analysis['stream_flooding_potential'] = {
                'stream_cells_below_water_level': int(stream_cells_below_water),
                'stream_flood_percentage': float(stream_flood_percentage)
            }
            
            print(f"   Stream elevation range: {analysis['stream_elevation_stats']['min_stream_elevation']:.2f} to {analysis['stream_elevation_stats']['max_stream_elevation']:.2f}m")
            print(f"   Stream flooding potential: {stream_flood_percentage:.1f}%")
        
        dem_ds = None
        stream_ds = None
        
    except Exception as e:
        print(f"   ⚠️ Could not analyze stream elevations: {str(e)}")
    
    return analysis


def check_dem_around_streams(dem_path: str, stream_path: str, output_folder: str) -> Dict:
    """Check DEM characteristics specifically around stream areas"""
    
    analysis = {
        'stream_corridor_stats': {},
        'terrain_roughness': {},
        'elevation_profiles': [],
        'issues_found': []
    }
    
    try:
        # Create elevation profiles along streams
        profiles = create_stream_elevation_profiles(dem_path, stream_path, output_folder)
        analysis['elevation_profiles'] = profiles
        
        # Check for flat/artificial areas around streams
        flatness_analysis = check_terrain_naturalness(dem_path, stream_path)
        analysis['terrain_roughness'] = flatness_analysis
        
    except Exception as e:
        analysis['issues_found'].append(f"❌ Error analyzing DEM around streams: {str(e)}")
    
    return analysis


def compare_expected_vs_actual_flooding(dem_path: str, stream_path: str, water_level: float, 
                                      output_folder: str) -> Dict:
    """Compare what SHOULD flood vs what actually floods"""
    
    comparison = {
        'expected_flood_area': 0,
        'actual_flood_area': 0,
        'difference_factor': 0,
        'expected_vs_actual_map': None
    }
    
    try:
        # Load DEM
        dem_ds = gdal.Open(dem_path)
        dem_array = dem_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
        geotransform = dem_ds.GetGeoTransform()
        
        # Simple expected flooding: all areas below water level
        expected_flood = dem_array < water_level
        expected_area = np.sum(expected_flood) * abs(geotransform[1] * geotransform[5])
        
        comparison['expected_flood_area'] = expected_area
        
        print(f"   Expected flood area: {expected_area/10000:.2f} hectares")
        
        # Try to find actual flood results
        flood_results_paths = [
            os.path.join(output_folder, "flood_*.shp"),
            os.path.join(os.path.dirname(dem_path), "flood_*.shp")
        ]
        
        # This would need actual flood calculation results to compare
        # For now, highlight the discrepancy concept
        
        # Create visualization showing expected vs actual
        comparison_plot_path = os.path.join(output_folder, "expected_vs_actual_flooding.png")
        create_flood_expectation_plot(dem_array, water_level, comparison_plot_path)
        comparison['expected_vs_actual_map'] = comparison_plot_path
        
        dem_ds = None
        
    except Exception as e:
        print(f"   ⚠️ Could not compare flooding: {str(e)}")
    
    return comparison


# Helper functions for visualization and analysis

def create_burn_difference_plot(orig_array, burned_array, diff_array, output_path):
    """Create visualization of stream burning effects"""
    
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    
    # Original DEM
    im1 = axes[0,0].imshow(orig_array, cmap='terrain', aspect='equal')
    axes[0,0].set_title('Original DEM')
    plt.colorbar(im1, ax=axes[0,0], label='Elevation (m)')
    
    # Burned DEM
    im2 = axes[0,1].imshow(burned_array, cmap='terrain', aspect='equal')
    axes[0,1].set_title('Burned DEM')
    plt.colorbar(im2, ax=axes[0,1], label='Elevation (m)')
    
    # Difference
    diff_masked = np.ma.masked_where(diff_array <= 0.01, diff_array)
    im3 = axes[1,0].imshow(diff_masked, cmap='Reds', aspect='equal')
    axes[1,0].set_title('Burn Difference (Original - Burned)')
    plt.colorbar(im3, ax=axes[1,0], label='Burn Depth (m)')
    
    # Histogram of burn depths
    burn_pixels = diff_array[diff_array > 0.01]
    if len(burn_pixels) > 0:
        axes[1,1].hist(burn_pixels, bins=50, alpha=0.7, color='red')
        axes[1,1].set_xlabel('Burn Depth (m)')
        axes[1,1].set_ylabel('Frequency')
        axes[1,1].set_title('Distribution of Burn Depths')
        axes[1,1].axvline(np.mean(burn_pixels), color='black', linestyle='--', label=f'Mean: {np.mean(burn_pixels):.2f}m')
        axes[1,1].legend()
    else:
        axes[1,1].text(0.5, 0.5, 'No burning detected!', ha='center', va='center', transform=axes[1,1].transAxes, fontsize=14, color='red')
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()


def create_flood_expectation_plot(dem_array, water_level, output_path):
    """Create plot showing expected flooding based on water level"""
    
    fig, axes = plt.subplots(1, 2, figsize=(15, 6))
    
    # DEM with water level
    im1 = axes[0].imshow(dem_array, cmap='terrain', aspect='equal')
    axes[0].contour(dem_array, levels=[water_level], colors='blue', linewidths=2)
    axes[0].set_title(f'DEM with Water Level ({water_level:.2f}m)')
    plt.colorbar(im1, ax=axes[0], label='Elevation (m)')
    
    # Expected flooding
    expected_flood = dem_array < water_level
    flood_display = np.where(expected_flood, 1, 0)
    im2 = axes[1].imshow(flood_display, cmap='Blues', aspect='equal')
    axes[1].set_title('Expected Flooding Areas')
    plt.colorbar(im2, ax=axes[1], label='Flooded (1) / Not Flooded (0)')
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()


def save_array_as_raster(array, geotransform, projection, output_path):
    """Save numpy array as GeoTIFF"""
    
    driver = gdal.GetDriverByName('GTiff')
    ds = driver.Create(output_path, array.shape[1], array.shape[0], 1, gdal.GDT_Float32)
    ds.SetGeoTransform(geotransform)
    ds.SetProjection(projection)
    ds.GetRasterBand(1).WriteArray(array)
    ds = None


def create_stream_elevation_profiles(dem_path, stream_path, output_folder):
    """Create elevation profiles along streams"""
    # Implementation would create longitudinal profiles
    return []


def check_terrain_naturalness(dem_path, stream_path):
    """Check if terrain around streams looks natural or artificially flat"""
    return {}


def generate_real_solutions(stream_burn_analysis, coord_analysis, water_level_analysis, 
                           dem_analysis, flooding_comparison):
    """Generate actionable solutions based on real problems found"""
    
    solutions = []
    
    # Stream burning issues
    if not stream_burn_analysis.get('burning_detected', False):
        solutions.append({
            'priority': 'CRITICAL',
            'issue': 'Stream burning completely failed',
            'solution': 'Check coordinate alignment between DEM and streams. Increase burn depth to 3-5m. Use ALL_TOUCHED rasterization option.',
            'code_fix': 'Use burn_streams_FIXED() with depth=3.0 and proper coordinate checking'
        })
    
    # Coordinate system issues
    if not coord_analysis.get('coordinate_systems_match', False):
        solutions.append({
            'priority': 'CRITICAL',
            'issue': 'DEM and streams have different coordinate systems',
            'solution': 'Reproject either DEM or streams to same coordinate system before processing',
            'code_fix': 'Use ogr2ogr or gdal.Warp() to reproject data to common CRS'
        })
    
    if not coord_analysis.get('spatial_overlap', False):
        solutions.append({
            'priority': 'CRITICAL', 
            'issue': 'DEM and streams don\'t overlap spatially',
            'solution': 'Check that you\'re using the correct DEM and stream files for the same geographic area',
            'code_fix': 'Verify file extents match your study area'
        })
    
    # Water level issues
    if water_level_analysis.get('flooding_potential', {}).get('potential_flood_percentage', 0) < 1:
        solutions.append({
            'priority': 'HIGH',
            'issue': 'Water level too low to cause significant flooding',
            'solution': f"Increase water level above {water_level_analysis.get('terrain_stats', {}).get('median_elevation', 0):.2f}m",
            'code_fix': 'Set water_level = terrain_median + flood_depth_desired'
        })
    
    return solutions


def save_diagnostic_report(output_folder, stream_burn_analysis, coord_analysis, 
                          water_level_analysis, dem_analysis, flooding_comparison, recommendations):
    """Save comprehensive diagnostic report"""
    
    report_path = os.path.join(output_folder, "REAL_PROBLEM_DIAGNOSIS.txt")
    
    with open(report_path, 'w') as f:
        f.write("FLOODENGINE REAL PROBLEM DIAGNOSIS REPORT\n")
        f.write("="*60 + "\n\n")
        
        f.write("CRITICAL ISSUES FOUND:\n")
        f.write("-"*30 + "\n")
        
        all_issues = []
        all_issues.extend(stream_burn_analysis.get('issues_found', []))
        all_issues.extend(coord_analysis.get('issues_found', []))
        all_issues.extend(water_level_analysis.get('issues_found', []))
        all_issues.extend(dem_analysis.get('issues_found', []))
        
        if all_issues:
            for issue in all_issues:
                f.write(f"{issue}\n")
        else:
            f.write("No critical issues detected.\n")
        
        f.write(f"\nACTIONABLE SOLUTIONS:\n")
        f.write("-"*30 + "\n")
        
        for i, solution in enumerate(recommendations, 1):
            f.write(f"{i}. {solution['priority']}: {solution['issue']}\n")
            f.write(f"   Solution: {solution['solution']}\n")
            f.write(f"   Code Fix: {solution['code_fix']}\n\n")
    
    print(f"📋 Diagnostic report saved: {report_path}")


if __name__ == "__main__":
    # Example usage
    print("🔍 Real Problem Diagnostic Tool")
    print("This tool will identify why your river flooding shows tiny dots instead of large areas")
    print("\nUsage:")
    print("diagnose_real_flooding_problem(dem_path, stream_path, water_level)")
