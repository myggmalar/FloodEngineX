#!/usr/bin/env python3
"""
Test script for Saint-Venant 2D implementation
"""

import os
import sys
import numpy as np

def test_saint_venant_basic():
    """Test basic Saint-Venant functionality without GDAL dependencies"""
    print("Testing Saint-Venant 2D implementation...")
    
    try:
        # Mock the GDAL dependency
        class MockGDAL:
            @staticmethod
            def Open(path):
                return None
            
            @staticmethod
            def GetDriverByName(name):
                return MockDriver()
                
            GDT_Float32 = 6
                
        class MockDriver:
            def Create(self, path, cols, rows, bands, dtype, options=None):
                return MockDataset()
                
        class MockDataset:
            def SetGeoTransform(self, transform):
                pass
            def SetProjection(self, proj):
                pass
            def GetRasterBand(self, band):
                return MockBand()
                
        class MockBand:
            def WriteArray(self, array):
                pass
            def SetNoDataValue(self, value):
                pass
            def ComputeStatistics(self, value):
                pass
        
        # Mock GDAL module
        sys.modules['osgeo.gdal'] = MockGDAL()
        
        # Now import and test Saint-Venant
        from saint_venant_2d import SaintVenant2D
        
        # Create test DEM
        test_dem = np.array([
            [10.0, 9.5, 9.0, 8.5, 8.0],
            [9.8, 9.3, 8.8, 8.3, 7.8],
            [9.6, 9.1, 8.6, 8.1, 7.6],
            [9.4, 8.9, 8.4, 7.9, 7.4],
            [9.2, 8.7, 8.2, 7.7, 7.2]
        ], dtype=np.float64)
        
        geotransform = (0.0, 1.0, 0.0, 0.0, 0.0, -1.0)
        
        print("✓ Creating Saint-Venant model...")
        model = SaintVenant2D(test_dem, geotransform, manning_n=0.035)
        
        print("✓ Setting initial conditions...")
        model.set_initial_condition(water_level=9.0, initial_velocity=(0.1, 0.1))
        
        print("✓ Testing time step calculation...")
        dt = model.calculate_timestep()
        print(f"  Calculated time step: {dt:.3f} seconds")
        
        print("✓ Testing simulation step...")
        actual_dt = model.step(dt)
        print(f"  Actual time step used: {actual_dt:.3f} seconds")
        
        print("✓ Testing velocity update...")
        model._update_velocities()
        
        print("✓ Testing flow direction calculation...")
        dx, dy = model._calculate_flow_directions()
        
        print("✓ Testing D8 flow direction...")
        direction = model._d8_flow_direction(2, 2)  # Center cell
        print(f"  D8 direction for center cell: {direction}")
        
        print("✓ Testing boundary conditions...")
        model._apply_boundaries()
        
        print("✓ Testing water surface calculation...")
        water_surface = model.get_water_surface()
        
        print("✓ Testing velocity field retrieval...")
        vel_x, vel_y, vel_mag = model.get_velocity_field()
        
        # Print some statistics
        print(f"\nModel Statistics:")
        print(f"  DEM shape: {model.shape}")
        print(f"  DEM elevation range: {np.min(test_dem):.1f} to {np.max(test_dem):.1f}m")
        print(f"  Water depth range: {np.min(model.h):.3f} to {np.max(model.h):.3f}m")
        print(f"  Velocity magnitude range: {np.min(vel_mag):.3f} to {np.max(vel_mag):.3f}m/s")
        print(f"  Cell size: dx={model.dx}, dy={model.dy}")
        print(f"  Manning's n: {np.mean(model.manning):.3f}")
        
        print("\n✅ All Saint-Venant tests passed!")
        return True
        
    except Exception as e:
        print(f"\n❌ Saint-Venant test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_numerical_stability():
    """Test numerical stability of the Saint-Venant model"""
    print("\nTesting numerical stability...")
    
    try:
        from saint_venant_2d import SaintVenant2D
        
        # Create a more challenging test case
        nx, ny = 20, 20
        x = np.linspace(0, 100, nx)
        y = np.linspace(0, 100, ny)
        X, Y = np.meshgrid(x, y)
        
        # Create a valley-like DEM
        test_dem = 10.0 - 0.01 * (X - 50)**2 - 0.005 * (Y - 50)**2
        geotransform = (0.0, 5.0, 0.0, 100.0, 0.0, -5.0)
        
        model = SaintVenant2D(test_dem, geotransform, manning_n=0.03)
        
        # Set water at the center
        water_level = 8.0
        model.set_initial_condition(water_level=water_level, initial_velocity=(0.0, 0.0))
        
        # Run for several time steps
        print("  Running stability test for 50 time steps...")
        max_depths = []
        max_velocities = []
        
        for step in range(50):
            dt = model.calculate_timestep()
            model.step(dt)
            
            max_depths.append(np.max(model.h))
            max_velocities.append(np.max(model.velocity_mag))
            
            # Check for NaN or infinite values
            if np.any(np.isnan(model.h)) or np.any(np.isinf(model.h)):
                raise Exception(f"NaN or infinite water depths at step {step}")
                
            if np.any(np.isnan(model.velocity_mag)) or np.any(np.isinf(model.velocity_mag)):
                raise Exception(f"NaN or infinite velocities at step {step}")
                
            # Check for excessive values
            if np.max(model.h) > 100:
                raise Exception(f"Excessive water depth: {np.max(model.h):.1f}m at step {step}")
                
            if np.max(model.velocity_mag) > 50:
                raise Exception(f"Excessive velocity: {np.max(model.velocity_mag):.1f}m/s at step {step}")
        
        print(f"  Final max depth: {max_depths[-1]:.3f}m")
        print(f"  Final max velocity: {max_velocities[-1]:.3f}m/s")
        print("✅ Numerical stability test passed!")
        
        return True
        
    except Exception as e:
        print(f"❌ Numerical stability test failed: {e}")
        return False

def main():
    """Run all tests"""
    print("=" * 60)
    print("SAINT-VENANT 2D IMPLEMENTATION TESTS")
    print("=" * 60)
    
    os.chdir(r"c:\Plugin\VSCode\FloodEngine_fixed_v8")
    
    tests = [
        ("Basic Functionality", test_saint_venant_basic),
        ("Numerical Stability", test_numerical_stability)
    ]
    
    passed = 0
    for test_name, test_func in tests:
        print(f"\n[TEST] {test_name}")
        print("-" * 40)
        
        if test_func():
            passed += 1
            print(f"[PASS] {test_name}")
        else:
            print(f"[FAIL] {test_name}")
    
    print("\n" + "=" * 60)
    print(f"SUMMARY: {passed}/{len(tests)} tests passed")
    print("=" * 60)
    
    if passed == len(tests):
        print("✅ Saint-Venant 2D implementation is working correctly!")
    else:
        print("❌ Some tests failed - check implementation")

if __name__ == "__main__":
    main()
