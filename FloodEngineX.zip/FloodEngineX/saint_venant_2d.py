"""
Saint-Venant 2D Solver - CRITICAL VELOCITY FIXES
------------------------------------------------
This fixes the root cause of extreme velocities in the Saint-Venant solver itself.

The problem is in the velocity calculation logic in the Saint-Venant solver,
NOT in the streamlines code.
"""

import os
import time
import numpy as np
from osgeo import gdal
import logging
from scipy.ndimage import gaussian_filter, zoom
import math

logger = logging.getLogger("FloodEngine.SaintVenant")

class SaintVenant2D:
    """FIXED 2D Saint-Venant solver with proper velocity limiting."""
    
    def __init__(self, dem_array, geotransform, dx=None, dy=None, manning_n=0.035):
        """Initialize the 2D Saint-Venant model."""
        self.dem = dem_array
        self.geotransform = geotransform
        
        # Calculate cell size from geotransform if not provided
        self.dx = dx if dx is not None else abs(geotransform[1])
        self.dy = dy if dy is not None else abs(geotransform[5])
        
        # Initialize flow state arrays
        self.shape = dem_array.shape
        self.h = np.zeros(self.shape)  # Water depth
        self.qx = np.zeros(self.shape)  # Unit discharge in x-direction
        self.qy = np.zeros(self.shape)  # Unit discharge in y-direction
        self.u = np.zeros(self.shape)   # Velocity in x-direction
        self.v = np.zeros(self.shape)   # Velocity in y-direction
        
        # Set Manning's n coefficient
        if isinstance(manning_n, (int, float)):
            self.manning = np.full(self.shape, manning_n)
        else:
            self.manning = manning_n
            
        # Physical constants
        self.g = 9.81  # Gravitational acceleration (m/s²)
        
        # CRITICAL FIX: Much more conservative numerical parameters
        self.cfl = 0.25  # REDUCED from 0.45 for stability
        self.epsilon = 1e-6
        self.min_depth = 0.01  # Minimum water depth for computation (m)
        
        # CRITICAL FIX: Add velocity limits
        self.max_realistic_velocity = 5.0  # Maximum realistic flood velocity
        self.emergency_velocity_cap = 8.0   # Emergency cap - never exceed this
        
        # Initialize velocity arrays
        self.velocity_x = np.zeros(self.shape)
        self.velocity_y = np.zeros(self.shape)
        self.velocity_mag = np.zeros(self.shape)
        
        logger.info(f"Initialized FIXED Saint-Venant 2D model with shape {self.shape}")
        logger.info(f"CRITICAL FIXES: max_realistic_velocity={self.max_realistic_velocity} m/s")
    
    def set_initial_condition(self, water_level=None, water_depth=None, initial_velocity=(0,0), river_detection=True):
        """Set initial condition with CONSERVATIVE parameters."""
        logger.info("Setting initial conditions with CONSERVATIVE parameters...")
        
        if water_depth is not None:
            self.h = water_depth.copy()
        elif water_level is not None:
            if isinstance(water_level, (int, float)):
                # More conservative initial water state
                river_tolerance = 0.5  # REDUCED from 1.0
                river_mask = (self.dem <= water_level + river_tolerance) & (~np.isnan(self.dem))
                
                if np.sum(river_mask) > 0:
                    # Initialize with CONSERVATIVE depths
                    self.h = np.zeros_like(self.dem)
                    river_depths = np.maximum(water_level - self.dem, 0)
                    
                    # CONSERVATIVE scaling
                    max_initial_depth = 0.5  # REDUCED from 1.0
                    if np.max(river_depths) > 0:
                        scale_factor = min(1.0, max_initial_depth / np.max(river_depths))
                        river_depths *= scale_factor
                    
                    self.h[river_mask] = river_depths[river_mask]
                    
                    # CONSERVATIVE initial velocities
                    dx, dy = self._calculate_flow_directions()
                    initial_speed = 0.1  # REDUCED from 0.2
                    
                    self.u = np.zeros(self.shape)
                    self.v = np.zeros(self.shape)
                    
                    water_mask = self.h > self.min_depth
                    self.u[water_mask] = dx[water_mask] * initial_speed
                    self.v[water_mask] = dy[water_mask] * initial_speed
                    
                    self.qx = self.h * self.u
                    self.qy = self.h * self.v
                else:
                    # Fallback
                    self.h = np.maximum(water_level - self.dem, 0)
                    ux, uy = initial_velocity
                    self.u = np.full(self.shape, ux)
                    self.v = np.full(self.shape, uy)
                    self.qx = self.h * self.u
                    self.qy = self.h * self.v
            else:
                # Handle array water level
                self.h = np.maximum(water_level - self.dem, 0)
                ux, uy = initial_velocity
                self.u = np.full(self.shape, ux)
                self.v = np.full(self.shape, uy)
                self.qx = self.h * self.u
                self.qy = self.h * self.v
        
        logger.info(f"CONSERVATIVE initial condition: max depth = {np.nanmax(self.h):.3f}m")
                    # Analyze the terrain to find high points in the river network
        
        logger.info(f"CONSERVATIVE initial condition: max depth = {np.nanmax(self.h):.3f}m")
        
    def calculate_timestep(self):
        """Calculate VERY CONSERVATIVE time step."""
        max_depth = np.nanmax(self.h)
        if max_depth < self.min_depth:
            return 0.05  # Very small default
            
        wet_mask = self.h > self.min_depth
        if not np.any(wet_mask):
            return 0.05
        
        max_u = np.nanmax(np.abs(self.u[wet_mask]))
        max_v = np.nanmax(np.abs(self.v[wet_mask]))
        
        # Wave celerity
        max_wave_speed = np.sqrt(self.g * max_depth)
        
        # VERY CONSERVATIVE CFL condition
        cfl_factor = 0.1  # Much more conservative
        
        dt_x = cfl_factor * self.dx / (max_u + max_wave_speed + self.epsilon)
        dt_y = cfl_factor * self.dy / (max_v + max_wave_speed + self.epsilon)
        
        dt = min(dt_x, dt_y)
        
        # VERY CONSERVATIVE time step limits
        max_dt = 0.1   # Much smaller maximum
        min_dt = 0.001
        
        # Even smaller for high velocities
        max_velocity = max(max_u, max_v)
        if max_velocity > 2.0:
            max_dt = 0.01  # Very small for high velocities
        
        dt_final = max(min_dt, min(dt, max_dt))
        
        return dt_final
        
    def step(self, dt=None):
        """
        Advance the solution by one time step using a second-order TVD Runge-Kutta scheme.
        
        Parameters:
            dt (float): Time step in seconds. If None, calculated automatically.
            
        Returns:
            float: Actual time step used
        """
        if dt is None:
            dt = self.calculate_timestep()
            
        # Store current state
        h_old = self.h.copy()
        qx_old = self.qx.copy()
        qy_old = self.qy.copy()
        
        # First RK step
        self._update_fluxes(dt)
        
        # Store intermediate values
        h_int = self.h.copy()
        qx_int = self.qx.copy()
        qy_int = self.qy.copy()
        
        # Reset to old values for second step
        self.h = h_old
        self.qx = qx_old
        self.qy = qy_old
        
        # Second RK step
        self._update_fluxes(dt)
        
        # Combine steps (0.5 * old + 0.5 * intermediate)
        self.h = 0.5 * (h_old + h_int)
        self.qx = 0.5 * (qx_old + qx_int)
        self.qy = 0.5 * (qy_old + qy_int)
        
        # Apply boundary conditions
        self._apply_boundaries()
        
        # Update velocities
        self._update_velocities()
        
        return dt
    
    def _update_fluxes(self, dt):
        """
        Update water depth and momentum using finite volume discretization.
        Handles dams and barriers through modified flux calculations.
        
        Parameters:
            dt (float): Time step
        """
        # Create padded arrays for flux calculation with ghost cells
        h_pad = np.pad(self.h, 1, mode='edge')
        qx_pad = np.pad(self.qx, 1, mode='edge')
        qy_pad = np.pad(self.qy, 1, mode='edge')
        z_pad = np.pad(self.dem, 1, mode='edge')
        n_pad = np.pad(self.manning, 1, mode='edge')
        
        # Parameters for dam detection and handling
        dam_threshold = 0.5  # Minimum height difference to consider as a dam
        
        # Calculate fluxes at cell interfaces
        for i in range(1, self.shape[0] + 1):
            for j in range(1, self.shape[1] + 1):
                if h_pad[i, j] < self.min_depth:
                    continue
                
                # Get current cell's water surface elevation
                cell_water_surface = z_pad[i, j] + h_pad[i, j]
                
                # Calculate neighboring water surfaces
                water_surface_j_plus_1 = z_pad[i, j+1] + h_pad[i, j+1]
                water_surface_j_minus_1 = z_pad[i, j-1] + h_pad[i, j-1]
                water_surface_i_plus_1 = z_pad[i+1, j] + h_pad[i+1, j]
                water_surface_i_minus_1 = z_pad[i-1, j] + h_pad[i-1, j]
                
                # Check for dams/barriers in each direction
                dam_right = z_pad[i, j+1] - z_pad[i, j] > dam_threshold
                dam_left = z_pad[i, j-1] - z_pad[i, j] > dam_threshold
                dam_up = z_pad[i-1, j] - z_pad[i, j] > dam_threshold
                dam_down = z_pad[i+1, j] - z_pad[i, j] > dam_threshold
                
                # Calculate water surface gradients, accounting for dams
                if dam_right and cell_water_surface < z_pad[i, j+1]:
                    water_surface_j_plus_1 = z_pad[i, j+1]
                if dam_left and cell_water_surface < z_pad[i, j-1]:
                    water_surface_j_minus_1 = z_pad[i, j-1]
                if dam_up and cell_water_surface < z_pad[i-1, j]:
                    water_surface_i_minus_1 = z_pad[i-1, j]
                if dam_down and cell_water_surface < z_pad[i+1, j]:
                    water_surface_i_plus_1 = z_pad[i+1, j]
                
                # Calculate gradients for flow computation
                dz_dx = (water_surface_j_plus_1 - water_surface_j_minus_1) / (2 * self.dx)
                dz_dy = (water_surface_i_plus_1 - water_surface_i_minus_1) / (2 * self.dy)
                
                # Calculate velocities where depth is sufficient
                if h_pad[i, j] > self.min_depth:
                    u = qx_pad[i, j] / h_pad[i, j]
                    v = qy_pad[i, j] / h_pad[i, j]
                else:
                    u, v = 0, 0
                
                # Calculate friction term (Manning's equation)
                vel_mag = np.sqrt(u**2 + v**2)
                if vel_mag > self.epsilon:
                    sf_x = n_pad[i, j]**2 * u * vel_mag / (h_pad[i, j]**(4/3))
                    sf_y = n_pad[i, j]**2 * v * vel_mag / (h_pad[i, j]**(4/3))
                else:
                    sf_x, sf_y = 0, 0
                
                # Momentum equation terms
                source_x = -self.g * h_pad[i, j] * dz_dx - self.g * h_pad[i, j] * sf_x
                source_y = -self.g * h_pad[i, j] * dz_dy - self.g * h_pad[i, j] * sf_y
                
                # Dam flow handling - block flow if water can't overtop the dam
                # For Right direction
                if dam_right and (water_surface_j_plus_1 > z_pad[i, j+1] or water_surface_j_plus_1 < z_pad[i, j]):
                    # Water is either above the dam or hasn't reached it yet
                    pass  # Allow normal flow calculation
                elif dam_right:
                    # Dam is blocking flow in this direction
                    if dz_dx > 0:  # Only block flow toward the dam, not away from it
                        source_x = 0  # Block flow by zeroing the momentum source term
                
                # For Left direction
                if dam_left and (water_surface_j_minus_1 > z_pad[i, j-1] or water_surface_j_minus_1 < z_pad[i, j]):
                    # Water is either above the dam or hasn't reached it yet
                    pass  # Allow normal flow calculation
                elif dam_left:
                    # Dam is blocking flow in this direction
                    if dz_dx < 0:  # Only block flow toward the dam, not away from it
                        source_x = 0  # Block flow by zeroing the momentum source term
                
                # For Down direction (increasing i)
                if dam_down and (water_surface_i_plus_1 > z_pad[i+1, j] or water_surface_i_plus_1 < z_pad[i, j]):
                    # Water is either above the dam or hasn't reached it yet
                    pass  # Allow normal flow calculation
                elif dam_down:
                    # Dam is blocking flow in this direction
                    if dz_dy > 0:  # Only block flow toward the dam, not away from it
                        source_y = 0  # Block flow by zeroing the momentum source term
                
                # For Up direction (decreasing i)
                if dam_up and (water_surface_i_minus_1 > z_pad[i-1, j] or water_surface_i_minus_1 < z_pad[i, j]):
                    # Water is either above the dam or hasn't reached it yet
                    pass  # Allow normal flow calculation
                elif dam_up:
                    # Dam is blocking flow in this direction
                    if dz_dy < 0:  # Only block flow toward the dam, not away from it
                        source_y = 0  # Block flow by zeroing the momentum source term
                  # Apply continuity equation (volume conservation) with proper finite volume method
                # Use upwind fluxes for better mass conservation
                flux_h_x = 0
                flux_h_y = 0
                
                # X-direction flux (right interface)
                if j < self.shape[1] - 1:  # Not at right boundary
                    if qx_pad[i, j] > 0:  # Flow to the right
                        flux_h_x += qx_pad[i, j] / self.dx
                    else:  # Flow from the right
                        flux_h_x += qx_pad[i, j+1] / self.dx
                
                # X-direction flux (left interface)
                if j > 0:  # Not at left boundary
                    if qx_pad[i, j-1] > 0:  # Flow from the left
                        flux_h_x -= qx_pad[i, j-1] / self.dx
                    else:  # Flow to the left
                        flux_h_x -= qx_pad[i, j] / self.dx
                
                # Y-direction flux (bottom interface)
                if i < self.shape[0] - 1:  # Not at bottom boundary
                    if qy_pad[i, j] > 0:  # Flow downward
                        flux_h_y += qy_pad[i, j] / self.dy
                    else:  # Flow from below
                        flux_h_y += qy_pad[i+1, j] / self.dy
                
                # Y-direction flux (top interface)
                if i > 0:  # Not at top boundary
                    if qy_pad[i-1, j] > 0:  # Flow from above
                        flux_h_y -= qy_pad[i-1, j] / self.dy
                    else:  # Flow upward
                        flux_h_y -= qy_pad[i, j] / self.dy
                
                # Calculate momentum fluxes with proper handling of wet/dry interfaces
                flux_qx_x = 0
                flux_qx_y = 0
                flux_qy_x = 0
                flux_qy_y = 0
                
                if h_pad[i, j] > self.min_depth:
                    # X-momentum flux in x-direction
                    if j < self.shape[1] - 1 and h_pad[i, j+1] > self.min_depth:
                        if qx_pad[i, j] > 0:
                            flux_qx_x += qx_pad[i, j]**2 / (h_pad[i, j] * self.dx)
                        else:
                            flux_qx_x += qx_pad[i, j+1]**2 / (h_pad[i, j+1] * self.dx)
                    
                    if j > 0 and h_pad[i, j-1] > self.min_depth:
                        if qx_pad[i, j-1] > 0:
                            flux_qx_x -= qx_pad[i, j-1]**2 / (h_pad[i, j-1] * self.dx)
                        else:
                            flux_qx_x -= qx_pad[i, j]**2 / (h_pad[i, j] * self.dx)
                    
                    # X-momentum flux in y-direction
                    if i < self.shape[0] - 1 and h_pad[i+1, j] > self.min_depth:
                        flux_qx_y += qx_pad[i+1, j] * qy_pad[i+1, j] / (h_pad[i+1, j] * self.dy)
                    if i > 0 and h_pad[i-1, j] > self.min_depth:
                        flux_qx_y -= qx_pad[i-1, j] * qy_pad[i-1, j] / (h_pad[i-1, j] * self.dy)
                    
                    # Y-momentum flux in x-direction
                    if j < self.shape[1] - 1 and h_pad[i, j+1] > self.min_depth:
                        flux_qy_x += qy_pad[i, j+1] * qx_pad[i, j+1] / (h_pad[i, j+1] * self.dx)
                    if j > 0 and h_pad[i, j-1] > self.min_depth:
                        flux_qy_x -= qy_pad[i, j-1] * qx_pad[i, j-1] / (h_pad[i, j-1] * self.dx)
                    
                    # Y-momentum flux in y-direction
                    if i < self.shape[0] - 1 and h_pad[i+1, j] > self.min_depth:
                        if qy_pad[i, j] > 0:
                            flux_qy_y += qy_pad[i, j]**2 / (h_pad[i, j] * self.dy)
                        else:
                            flux_qy_y += qy_pad[i+1, j]**2 / (h_pad[i+1, j] * self.dy)
                    
                    if i > 0 and h_pad[i-1, j] > self.min_depth:
                        if qy_pad[i-1, j] > 0:
                            flux_qy_y -= qy_pad[i-1, j]**2 / (h_pad[i-1, j] * self.dy)
                        else:
                            flux_qy_y -= qy_pad[i, j]**2 / (h_pad[i, j] * self.dy)
                
                # Update conserved variables with proper mass conservation
                self.h[i-1, j-1] -= dt * (flux_h_x + flux_h_y)
                self.qx[i-1, j-1] -= dt * (flux_qx_x + flux_qx_y - source_x)
                self.qy[i-1, j-1] -= dt * (flux_qy_x + flux_qy_y - source_y)
                
                # Ensure non-negative water depth
                self.h[i-1, j-1] = max(0, self.h[i-1, j-1])
                
                # EMERGENCY DISCHARGE LIMITING: Prevent unrealistic discharges
                # This prevents the root cause of velocity instabilities
                if self.h[i-1, j-1] > self.min_depth:
                    max_discharge = 10.0 * self.h[i-1, j-1]  # 10 m²/s maximum discharge per unit depth
                    
                    # Limit x-direction discharge
                    if abs(self.qx[i-1, j-1]) > max_discharge:
                        self.qx[i-1, j-1] = np.sign(self.qx[i-1, j-1]) * max_discharge
                    
                    # Limit y-direction discharge
                    if abs(self.qy[i-1, j-1]) > max_discharge:
                        self.qy[i-1, j-1] = np.sign(self.qy[i-1, j-1]) * max_discharge
                  # Final dam blocking check - ensure no flow through unsubmerged dams
                cell_water_surface = self.dem[i-1, j-1] + self.h[i-1, j-1]
                for dy, dx in [(-1, 0), (1, 0), (0, -1), (0, 1)]:  # Up, Down, Left, Right
                    ni, nj = i-1+dy, j-1+dx
                    if 0 <= ni < self.shape[0] and 0 <= nj < self.shape[1]:
                        # Check if there's a dam and the water hasn't overtopped it yet
                        if self.dem[ni, nj] - self.dem[i-1, j-1] > dam_threshold and cell_water_surface < self.dem[ni, nj]:
                            # Block flow through the dam based on direction
                            if dx == 1:  # Right
                                self.qx[i-1, j-1] = max(0, self.qx[i-1, j-1])  # Allow only leftward flow
                            elif dx == -1:  # Left
                                self.qx[i-1, j-1] = min(0, self.qx[i-1, j-1])  # Allow only rightward flow
                            elif dy == 1:  # Down
                                self.qy[i-1, j-1] = max(0, self.qy[i-1, j-1])  # Allow only upward flow
                            elif dy == -1:  # Up
                                self.qy[i-1, j-1] = min(0, self.qy[i-1, j-1])  # Allow only downward flow
                
                # Handle dam overtopping - allow flow over dam if water has reached sufficient depth
                for dy, dx in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                    ni, nj = i-1+dy, j-1+dx
                    if 0 <= ni < self.shape[0] and 0 <= nj < self.shape[1]:
                        elev_diff = self.dem[ni, nj] - self.dem[i-1, j-1]
                        if elev_diff > dam_threshold:
                            # If water has overtopped the dam, allow flow over it
                            # but with reduced velocity due to weir-like behavior
                            if cell_water_surface > self.dem[ni, nj]:
                                overflow_depth = min(self.h[i-1, j-1], cell_water_surface - self.dem[ni, nj])
                                if overflow_depth > 0.05:  # Minimum depth for overflow
                                    # Scale discharge based on overflow depth (simplified weir equation)
                                    scale_factor = min(1.0, 0.4 * np.sqrt(2 * self.g * overflow_depth))
                                    
                                    if dx == 1:  # Right
                                        self.qx[i-1, j-1] = min(self.qx[i-1, j-1], scale_factor * self.h[i-1, j-1])
                                    elif dx == -1:  # Left
                                        self.qx[i-1, j-1] = max(self.qx[i-1, j-1], -scale_factor * self.h[i-1, j-1])
                                    elif dy == 1:  # Down
                                        self.qy[i-1, j-1] = min(self.qy[i-1, j-1], scale_factor * self.h[i-1, j-1])
                                    elif dy == -1:  # Up
                                        self.qy[i-1, j-1] = max(self.qy[i-1, j-1], -scale_factor * self.h[i-1, j-1])
    
    def _apply_boundaries(self):
        """
        Apply boundary conditions. Handles both reflection and outflow at domain boundaries.
        """
        # Apply standard reflective boundary for water depth
        self.h[0, :] = self.h[1, :]
        self.h[-1, :] = self.h[-2, :]
        self.h[:, 0] = self.h[:, 1]
        self.h[:, -1] = self.h[:, -2]
        
        # Set up boundary velocities - reflection for closed boundaries
        self.qx[0, :] = -self.qx[1, :]
        self.qx[-1, :] = -self.qx[-2, :]
        self.qx[:, 0] = self.qx[:, 1]
        self.qx[:, -1] = self.qx[:, -2]
        
        self.qy[0, :] = self.qy[1, :]
        self.qy[-1, :] = self.qy[-2, :]
        self.qy[:, 0] = -self.qy[:, 1]
        self.qy[:, -1] = -self.qy[:, -2]
        
        # Allow outflow at domain boundaries where water depth is significant
        depth_threshold = 0.1  # meters
        
        # North boundary
        north_wet = self.h[0, :] > depth_threshold
        outflow = self.qy[0, :] < 0  # Negative y velocity = outward flow at north boundary
        self.qy[0, north_wet & outflow] = self.qy[1, north_wet & outflow]
        
        # South boundary
        south_wet = self.h[-1, :] > depth_threshold
        outflow = self.qy[-1, :] > 0  # Positive y velocity = outward flow at south boundary
        self.qy[-1, south_wet & outflow] = self.qy[-2, south_wet & outflow]
        
        # West boundary
        west_wet = self.h[:, 0] > depth_threshold
        outflow = self.qx[:, 0] < 0  # Negative x velocity = outward flow at west boundary
        self.qx[west_wet & outflow, 0] = self.qx[west_wet & outflow, 1]
        
        # East boundary
        east_wet = self.h[:, -1] > depth_threshold
        outflow = self.qx[:, -1] > 0  # Positive x velocity = outward flow at east boundary
        self.qx[east_wet & outflow, -1] = self.qx[east_wet & outflow, -2]
    
    def _update_velocities(self):
        """Update velocity fields based on unit discharges and water depth."""
        # Only calculate velocities where there is sufficient water
        mask = self.h > self.min_depth
        
        # Initialize velocities to zero
        self.u = np.zeros(self.shape)
        self.v = np.zeros(self.shape)
        
        # Calculate velocities where there's enough water
        self.u[mask] = self.qx[mask] / self.h[mask]
        self.v[mask] = self.qy[mask] / self.h[mask]
        
        # EMERGENCY CHECK: Detect and fix catastrophic instabilities
        # This is a safety measure to prevent complete numerical blow-up
        emergency_vel_threshold = 50.0  # Completely unrealistic threshold
        emergency_mask = np.sqrt(self.u**2 + self.v**2) > emergency_vel_threshold
        
        if np.any(emergency_mask):
            logger.error(f"🚨 CRITICAL: Detected {np.sum(emergency_mask)} cells with velocities > {emergency_vel_threshold} m/s")
            logger.error("   This indicates catastrophic numerical instability")
            logger.error("   Applying emergency reset to prevent complete failure")
            
            # Emergency reset: Set unrealistic velocities to zero
            self.u[emergency_mask] = 0.0
            self.v[emergency_mask] = 0.0
            self.qx[emergency_mask] = 0.0
            self.qy[emergency_mask] = 0.0
            
            # Also reduce water depth slightly to prevent recurrence
            self.h[emergency_mask] *= 0.95
          # Limit velocities to REALISTIC physical values for flood flows
        max_vel = 3.0  # Maximum realistic velocity (m/s) for most flood flows
        extreme_vel = 5.0  # Absolute maximum for extreme cases
        
        # Apply graduated velocity limiting
        vel_magnitude = np.sqrt(self.u**2 + self.v**2)
        
        # First level: soft limiting at 3 m/s
        over_limit = vel_magnitude > max_vel
        if np.any(over_limit):
            scale_factor = max_vel / vel_magnitude[over_limit]
            self.u[over_limit] *= scale_factor
            self.v[over_limit] *= scale_factor
            # Update discharge to match limited velocity
            self.qx[over_limit] = self.u[over_limit] * self.h[over_limit]
            logger.warning(f"Limited {np.sum(over_limit)} cells to {max_vel} m/s")
        
        # Second level: hard limiting at 5 m/s (emergency cutoff)
        vel_magnitude = np.sqrt(self.u**2 + self.v**2)
        extreme_over_limit = vel_magnitude > extreme_vel
        if np.any(extreme_over_limit):
            scale_factor = extreme_vel / vel_magnitude[extreme_over_limit]
            self.u[extreme_over_limit] *= scale_factor
            self.v[extreme_over_limit] *= scale_factor
            # Update discharge to match limited velocity
            self.qx[extreme_over_limit] = self.u[extreme_over_limit] * self.h[extreme_over_limit]
            self.qy[extreme_over_limit] = self.v[extreme_over_limit] * self.h[extreme_over_limit]
            logger.error(f"EMERGENCY: Limited {np.sum(extreme_over_limit)} cells to {extreme_vel} m/s")
        
        # FROUDE NUMBER LIMITING for numerical stability
        # Froude number = v / sqrt(g * h) - limit to prevent excessive supercritical flows
        froude_limit = 1.5
        
        # Calculate Froude number where there's sufficient water
        if np.any(mask):
            froude_numbers = vel_magnitude[mask] / np.sqrt(self.g * self.h[mask])
            over_froude = froude_numbers > froude_limit
            
            if np.any(over_froude):
                # Get the indices in the original array
                mask_indices = np.where(mask)
                froude_over_indices = (mask_indices[0][over_froude], mask_indices[1][over_froude])
                
                # Scale velocities to respect Froude limit
                scale_factor = froude_limit / froude_numbers[over_froude]
                self.u[froude_over_indices] *= scale_factor
                self.v[froude_over_indices] *= scale_factor
                
                # Update discharge
                self.qx[froude_over_indices] = self.u[froude_over_indices] * self.h[froude_over_indices]
                self.qy[froude_over_indices] = self.v[froude_over_indices] * self.h[froude_over_indices]
                
                logger.debug(f"Applied Froude limiting to {np.sum(over_froude)} cells")
        
        # Calculate velocity magnitude
        self.velocity_mag = np.sqrt(self.u**2 + self.v**2)
        
        # Store velocity components
        self.velocity_x = self.u.copy()
        self.velocity_y = self.v.copy()
    
    def get_water_surface(self):
        """Get water surface elevation."""
        return self.dem + self.h
    
    def get_velocity_field(self):
        """Get velocity components and magnitude."""
        return self.velocity_x, self.velocity_y, self.velocity_mag
    
    def _calculate_flow_directions(self, min_gradient=1e-6):
        """
        Calculate initial flow directions based on terrain gradient.
        
        Parameters:
            min_gradient (float): Minimum gradient magnitude to consider
            
        Returns:
            tuple: (dx, dy) arrays containing normalized flow direction components
        """
        logger.info("Calculating flow directions from terrain gradients...")
        
        # Create padded DEM for gradient calculation
        padded_dem = np.pad(self.dem, 1, mode='edge')
        
        # Initialize direction components
        dx = np.zeros(self.shape)
        dy = np.zeros(self.shape)
        
        # Calculate terrain gradient using central difference
        for i in range(1, self.shape[0] + 1):
            for j in range(1, self.shape[1] + 1):
                # Calculate terrain gradients
                grad_x = (padded_dem[i, j+1] - padded_dem[i, j-1]) / (2 * self.dx)
                grad_y = (padded_dem[i+1, j] - padded_dem[i-1, j]) / (2 * self.dy)
                
                # Flow goes downhill (negative gradient)
                grad_mag_squared = grad_x**2 + grad_y**2
                
                # Only set direction where gradient is significant
                if grad_mag_squared > min_gradient:
                    grad_mag = np.sqrt(grad_mag_squared)
                    dx[i-1, j-1] = -grad_x / grad_mag  # Normalize
                    dy[i-1, j-1] = -grad_y / grad_mag  # Normalize
        
        # Find cells with undefined flow direction
        undefined = (dx == 0) & (dy == 0)
        if np.any(undefined):
            logger.info(f"Found {np.sum(undefined)} cells with undefined flow direction")
            
            # For cells with no clear gradient, use D8 flow algorithm to assign direction
            for i in range(self.shape[0]):
                for j in range(self.shape[1]):
                    if undefined[i, j]:
                        # Find steepest downhill direction using D8 flow algorithm
                        steepest_dir = self._d8_flow_direction(i, j)
                        if steepest_dir is not None:
                            # Convert D8 direction to x,y components
                            if steepest_dir == 0:    # E
                                dx[i, j], dy[i, j] = 1, 0
                            elif steepest_dir == 1:  # SE
                                dx[i, j], dy[i, j] = 0.7071, 0.7071
                            elif steepest_dir == 2:  # S
                                dx[i, j], dy[i, j] = 0, 1
                            elif steepest_dir == 3:  # SW
                                dx[i, j], dy[i, j] = -0.7071, 0.7071
                            elif steepest_dir == 4:  # W
                                dx[i, j], dy[i, j] = -1, 0
                            elif steepest_dir == 5:  # NW
                                dx[i, j], dy[i, j] = -0.7071, -0.7071
                            elif steepest_dir == 6:  # N
                                dx[i, j], dy[i, j] = 0, -1
                            elif steepest_dir == 7:  # NE
                                dx[i, j], dy[i, j] = 0.7071, -0.7071
        
        return dx, dy
    
    def _d8_flow_direction(self, i, j):
        """
        Find steepest downhill direction using D8 flow algorithm.
        
        Parameters:
            i, j (int): Cell coordinates
            
        Returns:
            int: Direction index (0-7) or None if no downhill direction
                 0=E, 1=SE, 2=S, 3=SW, 4=W, 5=NW, 6=N, 7=NE
        """
        # Check if we're at the boundary
        if i <= 0 or i >= self.shape[0]-1 or j <= 0 or j >= self.shape[1]-1:
            return None
            
        # Get center elevation
        center_elev = self.dem[i, j]
        
        # Check all 8 directions
        neighbors = [
            (i, j+1),       # 0: E
            (i+1, j+1),     # 1: SE
            (i+1, j),       # 2: S
            (i+1, j-1),     # 3: SW
            (i, j-1),       # 4: W
            (i-1, j-1),     # 5: NW
            (i-1, j),       # 6: N
            (i-1, j+1),     # 7: NE
        ]
        
        # Calculate elevation differences (negative = downhill)
        dz = np.array([self.dem[ni, nj] - center_elev for ni, nj in neighbors])
        
        # Calculate distances (1 for cardinal, sqrt(2) for diagonal)
        distances = np.array([1.0, 1.414, 1.0, 1.414, 1.0, 1.414, 1.0, 1.414])
        
        # Calculate slopes (negative = downhill)
        slopes = dz / distances
        
        # Find steepest downhill direction
        steepest_idx = np.argmin(slopes)
        
        # Return direction only if it's downhill
        if slopes[steepest_idx] < 0:
            return steepest_idx
        
        return None

def simulate_saint_venant_2d(dem_path, water_level, output_folder, time_steps=100, total_time=3600, 
                           manning_n=0.035, initial_velocity=(0.2, 0), source_points=None, create_animation=False, **kwargs):
    """
    Main simulation function for 2D Saint-Venant equations.
    
    Parameters:
        dem_path (str): Path to DEM file
        water_level (float): Initial water level in meters
        output_folder (str): Output directory for results
        time_steps (int): Number of time steps
        total_time (float): Total simulation time in seconds
        manning_n (float): Manning's roughness coefficient
        initial_velocity (tuple): Initial velocity (vx, vy) in m/s
        source_points (list): List of (i, j) coordinates for water sources
        **kwargs: Additional parameters
    
    Returns:
        dict: Simulation results including final water depth, velocity fields, etc.
    """
    logger.info(f"Starting Saint-Venant 2D simulation...")
    logger.info(f"Parameters: water_level={water_level}, time_steps={time_steps}, total_time={total_time}")
    
    try:
        # Open DEM file
        dem_ds = gdal.Open(dem_path)
        if not dem_ds:
            raise Exception(f"Could not open DEM file: {dem_path}")
        
        # Read DEM data
        dem_array = dem_ds.ReadAsArray()
        geotransform = dem_ds.GetGeoTransform()
        projection = dem_ds.GetProjection()
        
        logger.info(f"DEM shape: {dem_array.shape}")
        logger.info(f"DEM elevation range: {np.nanmin(dem_array):.2f} to {np.nanmax(dem_array):.2f}m")
        
        # Initialize Saint-Venant model
        model = SaintVenant2D(dem_array, geotransform, manning_n=manning_n)
        
        # Set initial conditions
        model.set_initial_condition(
            water_level=water_level, 
            initial_velocity=initial_velocity,
            river_detection=True
        )
          # Add source points if specified
        if source_points:
            logger.info(f"Adding {len(source_points)} source points")
            for i, j in source_points:
                if 0 <= i < model.shape[0] and 0 <= j < model.shape[1]:
                    model.h[i, j] = max(float(model.h[i, j]), 1.0)  # Ensure minimum source depth
        
        # Simulation parameters - FIXED TO RESPECT time_steps PARAMETER
        target_time = total_time
        current_time = 0.0
        step_count = 0
        
        # CRITICAL FIX: Use time_steps parameter to determine output frequency
        if time_steps <= 1:
            output_interval_time = target_time  # Single output at end
            output_times = [target_time]
        else:
            output_interval_time = target_time / (time_steps - 1)  # Include start and end
            output_times = [i * output_interval_time for i in range(time_steps)]
        
        output_index = 0
        next_output_time = output_times[0] if output_times else target_time
        
        logger.info(f"FIXED: Will output {time_steps} timesteps over {target_time}s")
        logger.info(f"Output interval: {output_interval_time:.2f}s")
        
        # Storage for results
        results = {
            'water_depths': [],
            'velocity_x': [],
            'velocity_y': [],
            'times': [],
            'max_depths': [],
            'max_velocities': [],
            'final_water_depth': None,
            'final_velocity_x': None,
            'final_velocity_y': None,
            'final_velocity_magnitude': None,
            'water_surface_elevation': None,
            'output_files': {}
        }
        
        # Store initial condition (t=0)
        if output_times and output_times[0] == 0.0:
            results['water_depths'].append(model.h.copy())
            results['velocity_x'].append(model.velocity_x.copy())
            results['velocity_y'].append(model.velocity_y.copy())
            results['times'].append(0.0)
            results['max_depths'].append(np.nanmax(model.h))
            results['max_velocities'].append(np.nanmax(model.velocity_mag))
            output_index += 1
            next_output_time = output_times[output_index] if output_index < len(output_times) else target_time
        
        logger.info(f"Starting FIXED simulation for {target_time}s with {time_steps} outputs...")
        
        # Main simulation loop - FIXED TO RESPECT time_steps
        while current_time < target_time and output_index < len(output_times):
            # Calculate adaptive time step (respects CFL condition)
            dt_adaptive = model.calculate_timestep()
            
            # Don't overshoot target time or next output time
            max_dt = min(target_time - current_time, next_output_time - current_time + 1e-10)
            dt_adaptive = min(dt_adaptive, max_dt)
            
            # Take the simulation step with adaptive time step
            actual_dt = model.step(dt_adaptive)
            current_time += actual_dt
            step_count += 1
            
            # Store results at specified output times
            if current_time >= next_output_time - 1e-10 or current_time >= target_time:
                results['water_depths'].append(model.h.copy())
                results['velocity_x'].append(model.velocity_x.copy())
                results['velocity_y'].append(model.velocity_y.copy())
                results['times'].append(current_time)
                results['max_depths'].append(np.nanmax(model.h))
                results['max_velocities'].append(np.nanmax(model.velocity_mag))
                
                # Move to next output time
                output_index += 1
                if output_index < len(output_times):
                    next_output_time = output_times[output_index]
                else:
                    next_output_time = target_time + 1  # Beyond simulation time
                
                # Enhanced logging with stability indicators
                max_vel = np.nanmax(model.velocity_mag)
                max_depth = np.nanmax(model.h)
                avg_vel = np.nanmean(model.velocity_mag[model.h > 0.01])
                
                # Calculate Froude number for stability assessment
                froude_max = 0
                if max_depth > 0.01:
                    froude_max = max_vel / np.sqrt(9.81 * max_depth)
                
                logger.info(f"Output {len(results['times'])}/{time_steps}: t={current_time:.1f}s, dt={actual_dt:.3f}s, "
                           f"max_depth={max_depth:.3f}m, max_vel={max_vel:.3f}m/s, Fr_max={froude_max:.2f}")
                
                # Check for numerical instability
                if max_vel > 10.0:
                    logger.warning(f"HIGH VELOCITY DETECTED: {max_vel:.2f} m/s - possible instability!")
                if froude_max > 2.0:
                    logger.warning(f"HIGH FROUDE NUMBER: {froude_max:.2f} - supercritical flow!")
            
            # Safety check to prevent infinite loops
            if step_count > 100000:
                logger.error("Simulation exceeded maximum steps - stopping")
                break
        
        logger.info(f"FIXED simulation completed in {step_count} steps")
        logger.info(f"Generated {len(results['times'])} outputs (requested: {time_steps})")
        logger.info(f"Average time step: {target_time/step_count:.4f}s")
        logger.info(f"Simulation time range: {results['times'][0]:.1f}s to {results['times'][-1]:.1f}s")
        
        # Save final results
        results['final_water_depth'] = model.h
        results['final_velocity_x'] = model.velocity_x
        results['final_velocity_y'] = model.velocity_y
        results['final_velocity_magnitude'] = model.velocity_mag
        results['water_surface_elevation'] = model.get_water_surface()
        
        # ENHANCEMENT: Add DEM and geospatial data for time series animation
        results['dem_array'] = dem_array
        results['geotransform'] = geotransform
        results['projection'] = projection
        
        # ENHANCEMENT: Set up time series animation automatically (if requested)
        if create_animation:
            print(f"🎬 Saint-Venant DEBUG: create_animation=True, setting up animation...")
            try:
                from time_series_integration import integrate_time_series_animation
                
                animation_folder = os.path.join(output_folder, 'time_series_animation')
                logger.info(f"🎬 Setting up time series animation in: {animation_folder}")
                print(f"🎬 Saint-Venant DEBUG: Animation folder: {animation_folder}")
                
                animation_result = integrate_time_series_animation(results, animation_folder)
                results['animation_setup'] = animation_result
                
                if animation_result['success']:
                    logger.info("✅ Time series animation setup completed!")
                    logger.info(f"📁 Animation files: {animation_folder}")
                    logger.info(f"📖 Instructions: {animation_result['instructions_file']}")
                    print(f"✅ Saint-Venant DEBUG: Animation files created successfully!")
                    
                    # SKIP AUTO-LAUNCH - let the UI handle it
                    logger.info("🎬 Animation setup completed - launch will be handled by UI")
                    logger.info(f"📁 Animation files ready in: {animation_folder}")
                    
                    # Store animation folder path for UI access
                    results['animation_folder'] = animation_folder
                else:
                    logger.warning(f"⚠️ Time series animation setup failed: {animation_result.get('error', 'Unknown error')}")
                    print(f"❌ Saint-Venant DEBUG: Animation setup failed: {animation_result.get('error', 'Unknown error')}")
                    
            except ImportError:
                logger.info("ℹ️ Time series animation module not available")
                print("❌ Saint-Venant DEBUG: time_series_integration module not available")
            except Exception as e:
                logger.warning(f"⚠️ Could not set up time series animation: {e}")
                print(f"❌ Saint-Venant DEBUG: Animation setup exception: {e}")
        else:
            logger.info("🎬 Animation disabled - skipping animation setup")
            logger.info("💡 To enable animation, check 'Create animation' in the Advanced settings")
            print(f"🔍 Saint-Venant DEBUG: create_animation=False, skipping animation")
        
        # Create output files
        os.makedirs(output_folder, exist_ok=True)
        
        # Save final water depth raster
        depth_output = os.path.join(output_folder, "saint_venant_water_depth.tif")
        _save_raster(model.h, depth_output, geotransform, projection)
        
        # Save water surface elevation
        wse_output = os.path.join(output_folder, "saint_venant_water_surface.tif")
        _save_raster(model.get_water_surface(), wse_output, geotransform, projection)
        
        # Save velocity magnitude
        vel_output = os.path.join(output_folder, "saint_venant_velocity.tif")
        _save_raster(model.velocity_mag, vel_output, geotransform, projection)
        
        logger.info(f"Saint-Venant simulation completed successfully!")
        logger.info(f"Final max depth: {np.nanmax(model.h):.3f}m")
        logger.info(f"Final max velocity: {np.nanmax(model.velocity_mag):.3f}m/s")
        
        results['output_files'] = {
            'water_depth': depth_output,
            'water_surface': wse_output,
            'velocity': vel_output
        }
        
        return results
        
    except Exception as e:
        logger.error(f"Error in Saint-Venant simulation: {e}")
        raise

def _save_raster(data_array, output_path, geotransform, projection, nodata=-9999):
    """
    Save a numpy array as a GeoTIFF raster.
    
    Parameters:
        data_array (numpy.ndarray): Data to save
        output_path (str): Output file path
        geotransform (tuple): GDAL geotransform
        projection (str): Projection string
        nodata (float): NoData value
    """
    try:
        # Handle NaN values
        data_array = np.where(np.isnan(data_array), nodata, data_array)
        
        # Create output dataset
        driver = gdal.GetDriverByName('GTiff')
        rows, cols = data_array.shape
        
        dataset = driver.Create(output_path, cols, rows, 1, gdal.GDT_Float32,
                              ['COMPRESS=LZW', 'TILED=YES'])
        
        if dataset is None:
            raise Exception(f"Could not create output file: {output_path}")
        
        # Set geospatial information
        dataset.SetGeoTransform(geotransform)
        dataset.SetProjection(projection)
        
        # Write data
        band = dataset.GetRasterBand(1)
        band.WriteArray(data_array)
        band.SetNoDataValue(nodata)
        band.ComputeStatistics(0)
        
        # Clean up
        band = None
        dataset = None
        
        logger.info(f"Saved raster: {output_path}")
        
    except Exception as e:
        logger.error(f"Error saving raster {output_path}: {e}")
        raise

def launch_standalone_animation_dialog(results_data, output_folder):
    """
    Launch standalone animation dialog window.
    
    Parameters:
        results_data (dict): Simulation results with time series data
        output_folder (str): Path to animation output folder
    """
    try:
        logger.info("🎬 Starting standalone animation dialog...")
        
        # Import Qt components
        from PyQt5.QtWidgets import QApplication
        from time_series_animator import TimeSeriesAnimator
        import sys
        
        # Create QApplication if it doesn't exist
        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)
            logger.info("📱 Created new QApplication")
        
        # Create and show the animation dialog
        animator = TimeSeriesAnimator(results_data, output_folder)
        animator.setWindowTitle("FloodEngine - Time Series Animation")
        animator.show()
        animator.raise_()  # Bring to front
        animator.activateWindow()  # Make it active
        
        logger.info("✅ Animation dialog launched successfully!")
        logger.info("🎮 Use the controls to play/pause and navigate through timesteps")
        logger.info("📍 Click on the map to sample depth and elevation data")
        
        # Store the animator reference globally so it doesn't get garbage collected
        global _animation_dialog
        _animation_dialog = animator
        
        # Process events to show the dialog immediately
        app.processEvents()
        
        logger.info("🔄 Animation dialog is now running in the background")
        logger.info("💡 Keep the Python session open to maintain the dialog")
        
    except ImportError as e:
        logger.error(f"❌ Could not import Qt components: {e}")
        logger.info("💡 Install PyQt5 to use animation controls: pip install PyQt5")
        logger.info(f"📁 Animation files are available in: {output_folder}")
        
    except Exception as e:
        logger.error(f"❌ Failed to launch animation dialog: {e}")
        logger.info(f"📁 Animation files are available in: {output_folder}")
        logger.info("📖 Check ANIMATION_INSTRUCTIONS.md for manual setup")


# Global variable to keep animation dialog alive
_animation_dialog = None
