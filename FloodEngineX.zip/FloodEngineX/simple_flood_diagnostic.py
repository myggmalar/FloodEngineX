#!/usr/bin/env python3
"""
Simple diagnostic script to test flood mask generation
"""

import os
import sys
import numpy as np
from osgeo import gdal

def load_test_dem():
    """Load the actual DEM for testing"""
    dem_path = r"C:\Users\david\OneDrive\Dokument\GIS\FloodEngine\VSCode\Test_Data\DEM\DEM_20m_clipped.tif"
    
    if not os.path.exists(dem_path):
        print("DEM file not found: {}".format(dem_path))
        return None, None, None
    
    print("Loading DEM: {}".format(dem_path))
    ds = gdal.Open(dem_path)
    if ds is None:
        print("Could not open DEM file")
        return None, None, None
    
    dem_array = ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
    geotransform = ds.GetGeoTransform()
    
    # Handle NoData
    nodata = ds.GetRasterBand(1).GetNoDataValue()
    if nodata is not None:
        dem_array[dem_array == nodata] = np.nan
    
    # Create valid mask
    valid_mask = ~np.isnan(dem_array)
    
    print("DEM loaded: {}".format(dem_array.shape))
    print("Elevation range: {:.2f}m to {:.2f}m".format(np.nanmin(dem_array), np.nanmax(dem_array)))
    print("Valid cells: {} / {}".format(np.sum(valid_mask), dem_array.size))
    
    return dem_array, valid_mask, geotransform

def test_flood_mask_basic(dem_array, valid_mask, water_level):
    """Test basic flood mask generation"""
    print("\nTesting water level: {:.2f}m".format(water_level))
    
    # Find all floodable areas (simple bathtub model)
    floodable_mask = valid_mask & (dem_array < water_level)
    flooded_count = np.sum(floodable_mask)
    
    print("Floodable cells (bathtub model): {}".format(flooded_count))
    
    if flooded_count == 0:
        print("NO FLOODING POSSIBLE at this water level")
        return 0
    
    # Test percentile thresholds for starting points
    floodable_elevations = dem_array[floodable_mask]
    
    for percentile in [50, 60, 70, 80, 90]:
        threshold = np.percentile(floodable_elevations, percentile)
        start_points = floodable_mask & (dem_array >= threshold)
        start_count = np.sum(start_points)
        print("{}th percentile (>={:.2f}m): {} start points".format(
            percentile, threshold, start_count))
    
    return flooded_count

def main():
    print("SIMPLE FLOOD DIAGNOSTIC TOOL")
    print("=" * 50)
    
    # Load DEM
    dem_array, valid_mask, geotransform = load_test_dem()
    if dem_array is None:
        print("Cannot proceed without DEM data")
        return
    
    # Test with various water levels
    test_levels = [32.0, 40.0, 50.0, 60.0, 65.0, 70.0, 80.0]
    
    print("\nTesting multiple water levels:")
    results = []
    
    for level in test_levels:
        flood_count = test_flood_mask_basic(dem_array, valid_mask, level)
        results.append((level, flood_count))
    
    print("\nSUMMARY:")
    print("Water Level | Flooded Cells")
    print("-" * 30)
    for level, count in results:
        print("{:8.1f}m | {:10d}".format(level, count))
    
    # Check for problematic levels
    empty_levels = [level for level, count in results if count == 0]
    if empty_levels:
        print("\nPROBLEMATIC LEVELS (zero flooding):")
        for level in empty_levels:
            print("- {:.1f}m".format(level))
    else:
        print("\nAll levels show flooding - issue may be in flow algorithm")

if __name__ == "__main__":
    main()
