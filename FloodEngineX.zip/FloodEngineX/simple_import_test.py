#!/usr/bin/env python3
"""
Simple import test to verify our flood functions work
"""

import sys
import os
import numpy as np
from pathlib import Path

# Add the plugin directory to path
plugin_dir = Path(__file__).parent
sys.path.insert(0, str(plugin_dir))

print("Testing imports...")

try:
    from model_hydraulic import create_proper_flow_flood_mask
    print("✅ create_proper_flow_flood_mask imported successfully")
except ImportError as e:
    print(f"❌ create_proper_flow_flood_mask import failed: {e}")

try:
    from model_hydraulic import generate_variable_water_levels_IMPROVED
    print("✅ generate_variable_water_levels_IMPROVED imported successfully")
except ImportError as e:
    print(f"❌ generate_variable_water_levels_IMPROVED import failed: {e}")

print("\nTesting simple flood calculation...")

# Create minimal test DEM
dem = np.array([[40, 41, 42], [39, 38, 39], [40, 41, 42]], dtype=np.float32)
valid_mask = np.ones_like(dem, dtype=bool)
water_level = 40.5

try:
    flood_mask = create_proper_flow_flood_mask(dem, valid_mask, water_level)
    flooded_cells = np.sum(flood_mask)
    print(f"✅ Flood calculation successful: {flooded_cells} cells flooded")
except Exception as e:
    print(f"❌ Flood calculation failed: {e}")

print("\nTesting water level generation...")

try:
    water_levels = generate_variable_water_levels_IMPROVED(40.0, 5, flow_q=100, method="accumulation")
    print(f"✅ Water level generation successful: {water_levels}")
except Exception as e:
    print(f"❌ Water level generation failed: {e}")

print("\nBasic functionality test complete!")
