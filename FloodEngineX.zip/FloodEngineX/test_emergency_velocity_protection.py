"""
Test emergency velocity capping functionality
"""

import numpy as np
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

def test_emergency_velocity_capping():
    """
    Test that the emergency velocity capping works correctly.
    """
    logger.info("Testing emergency velocity capping...")
    
    # Simulate Saint-Venant results with extreme velocities
    saint_venant_results = {
        'velocity_x': np.array([[100.0, 2.0, -150.0], [1.0, 0.5, 200.0]]),
        'velocity_y': np.array([[50.0, 1.0, 75.0], [0.5, 1.5, -100.0]]),
        'velocity_magnitude': None
    }
    
    # Calculate magnitude
    saint_venant_results['velocity_magnitude'] = np.sqrt(
        saint_venant_results['velocity_x']**2 + saint_venant_results['velocity_y']**2
    )
    
    logger.info("Original velocities:")
    logger.info(f"Max velocity: {np.max(saint_venant_results['velocity_magnitude']):.1f} m/s")
    logger.info(f"Velocity field:\n{saint_venant_results['velocity_magnitude']}")
    
    # Apply emergency capping (simulating the code in enhanced_streamlines.py)
    
    # Emergency Layer 1: 10 m/s cap
    emergency_cap = 10.0
    emergency_mask = saint_venant_results['velocity_magnitude'] > emergency_cap
    if np.any(emergency_mask):
        logger.info(f"Emergency cap applied to {np.sum(emergency_mask)} cells")
        
        emergency_scale = np.where(
            saint_venant_results['velocity_magnitude'] > emergency_cap,
            emergency_cap / saint_venant_results['velocity_magnitude'],
            1.0
        )
        
        saint_venant_results['velocity_x'] *= emergency_scale
        saint_venant_results['velocity_y'] *= emergency_scale
        saint_venant_results['velocity_magnitude'] = np.minimum(
            saint_venant_results['velocity_magnitude'], 
            emergency_cap
        )
    
    # Realistic Layer 2: 5 m/s cap
    max_realistic_velocity = 5.0
    unrealistic_count = np.sum(saint_venant_results['velocity_magnitude'] > max_realistic_velocity)
    if unrealistic_count > 0:
        logger.info(f"Realistic cap applied to {unrealistic_count} cells")
        
        velocity_scale = np.where(
            saint_venant_results['velocity_magnitude'] > max_realistic_velocity,
            max_realistic_velocity / saint_venant_results['velocity_magnitude'],
            1.0
        )
        
        saint_venant_results['velocity_x'] *= velocity_scale
        saint_venant_results['velocity_y'] *= velocity_scale
        saint_venant_results['velocity_magnitude'] = np.minimum(
            saint_venant_results['velocity_magnitude'], 
            max_realistic_velocity
        )
    
    logger.info("After emergency capping:")
    logger.info(f"Max velocity: {np.max(saint_venant_results['velocity_magnitude']):.1f} m/s")
    logger.info(f"Velocity field:\n{saint_venant_results['velocity_magnitude']}")
    
    # Verify all velocities are now reasonable
    max_final = np.max(saint_venant_results['velocity_magnitude'])
    if max_final <= 5.0:
        logger.info("✅ Emergency capping successful - all velocities ≤ 5 m/s")
        return True
    else:
        logger.error(f"❌ Emergency capping failed - max velocity still {max_final:.1f} m/s")
        return False

def test_validation_logic():
    """
    Test the validation logic that determines when to use Saint-Venant results.
    """
    logger.info("\nTesting validation logic...")
    
    test_cases = [
        {"max_vel": 3.0, "mean_vel": 1.5, "should_use": True, "name": "Good velocities"},
        {"max_vel": 8.0, "mean_vel": 2.0, "should_use": False, "name": "High max velocity"},
        {"max_vel": 5.0, "mean_vel": 6.0, "should_use": False, "name": "High mean velocity"},
        {"max_vel": 100.0, "mean_vel": 20.0, "should_use": False, "name": "Extreme velocities"},
        {"max_vel": 4.5, "mean_vel": 2.5, "should_use": True, "name": "Borderline good"},
    ]
    
    for case in test_cases:
        max_vel = case["max_vel"]
        mean_vel = case["mean_vel"]
        should_use = case["should_use"]
        name = case["name"]
        
        # Apply validation logic (from enhanced_streamlines.py)
        if max_vel > 50.0:
            use_saint_venant = False
            reason = "EMERGENCY: Extremely unrealistic"
        elif max_vel > 10.0 or mean_vel > 5.0:
            use_saint_venant = False
            reason = "Unrealistic velocities"
        else:
            use_saint_venant = True
            reason = "Within reasonable limits"
        
        result = "✅" if use_saint_venant == should_use else "❌"
        logger.info(f"{result} {name}: max={max_vel:.1f}, mean={mean_vel:.1f} → {reason}")
    
    logger.info("Validation logic test complete")

def main():
    """
    Run all tests.
    """
    logger.info("Emergency Velocity Protection Test")
    logger.info("=" * 35)
    
    success1 = test_emergency_velocity_capping()
    test_validation_logic()
    
    logger.info("\n" + "=" * 35)
    if success1:
        logger.info("✅ Emergency velocity protection is working correctly")
        logger.info("The system will now prevent extreme velocities from being used")
    else:
        logger.error("❌ Emergency velocity protection needs attention")

if __name__ == "__main__":
    main()
