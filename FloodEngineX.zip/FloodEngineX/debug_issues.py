#!/usr/bin/env python3
"""
Debug script to diagnose persistent FloodEngine issues
"""

def debug_water_level_generation():
    """Test water level generation functions"""
    print("🔍 DEBUGGING WATER LEVEL GENERATION")
    print("=" * 50)
    
    try:
        # Import the function
        from model_hydraulic import generate_variable_water_levels_IMPROVED
        
        # Test parameters
        initial_level = 10.0
        time_steps = 5
        flow_q = 100.0
        
        # Generate water levels
        water_levels = generate_variable_water_levels_IMPROVED(
            initial_level=initial_level,
            time_steps=time_steps,
            flow_q=flow_q,
            method="accumulation"
        )
        
        print(f"✅ Generated {len(water_levels)} water levels:")
        for i, level in enumerate(water_levels):
            print(f"   Step {i}: {level:.3f}m")
        
        # Check variation
        variation = max(water_levels) - min(water_levels)
        print(f"💧 Water level variation: {variation:.3f}m")
        
        if variation < 0.01:
            print("❌ ERROR: Insufficient water level variation!")
            return False
        else:
            print("✅ Water level variation is adequate")
            return True
            
    except Exception as e:
        print(f"❌ ERROR importing/calling water level function: {e}")
        import traceback
        traceback.print_exc()
        return False

def debug_dem_styling():
    """Check DEM styling logic"""
    print("\n🎨 DEBUGGING DEM STYLING")
    print("=" * 50)
    
    try:
        # Import styling function if it exists
        try:
            from model_hydraulic import apply_dem_styling
            print("✅ Found apply_dem_styling function")
        except ImportError:
            print("⚠️ No apply_dem_styling function found")
        
        # Test color scheme calculation logic
        min_val = -20.0  # 20m below sea level
        max_val = 50.0   # 50m above sea level
        sea_level = 0.0
        
        # Calculate boundaries like the code does
        if min_val < sea_level < max_val:
            land_start = sea_level + 0.1
        elif min_val >= sea_level:
            land_start = min_val + 0.1    
        else:
            land_start = min_val + (max_val - min_val) * 0.8
        
        print(f"📊 Elevation range: {min_val:.1f}m to {max_val:.1f}m")
        print(f"🌊 Sea level: {sea_level:.1f}m")
        print(f"🏖️ Land start: {land_start:.1f}m")
        
        # Calculate color breakpoints
        color_points = [
            (min_val, "Deep water (navy blue)"),
            (min_val + (sea_level - min_val) * 0.5, "Deep blue"),
            (min_val + (sea_level - min_val) * 0.8, "Medium blue"),
            (sea_level, "Light blue (sea level)"),
            (land_start, "Sandy beige (shoreline)"),
            (land_start + (max_val - land_start) * 0.1, "Yellow"),
            (land_start + (max_val - land_start) * 0.25, "Light green"),
            (land_start + (max_val - land_start) * 0.5, "Green"),
            (land_start + (max_val - land_start) * 0.75, "Dark green"),
            (land_start + (max_val - land_start) * 0.9, "Brown"),
            (max_val, "White (peaks)")
        ]
        
        print(f"🎨 Color breakpoints:")
        for elevation, color in color_points:
            print(f"   {elevation:6.1f}m: {color}")
        
        return True
        
    except Exception as e:
        print(f"❌ ERROR in DEM styling debug: {e}")
        import traceback
        traceback.print_exc()
        return False

def debug_function_imports():
    """Check if our improved functions can be imported"""
    print("\n📦 DEBUGGING FUNCTION IMPORTS")
    print("=" * 50)
    
    functions_to_test = [
        "generate_variable_water_levels_IMPROVED",
        "simulate_over_time_FIXED",
        "apply_dem_styling",
        "calculate_streamlines_ENHANCED"
    ]
    
    results = {}
    
    for func_name in functions_to_test:
        try:
            exec(f"from model_hydraulic import {func_name}")
            print(f"✅ {func_name}: Successfully imported")
            results[func_name] = True
        except ImportError as e:
            print(f"❌ {func_name}: Import failed - {e}")
            results[func_name] = False
        except Exception as e:
            print(f"⚠️ {func_name}: Unknown error - {e}")
            results[func_name] = False
    
    return results

def main():
    """Run all diagnostics"""
    print("🔧 FLOODENGINE ISSUE DIAGNOSTICS")
    print("=" * 60)
    print("This script will test the fixed functions to identify why")
    print("the DEM styling and timestep variation issues persist.")
    print("=" * 60)
    
    # Test function imports
    import_results = debug_function_imports()
    
    # Test water level generation
    water_level_ok = debug_water_level_generation()
    
    # Test DEM styling logic
    dem_styling_ok = debug_dem_styling()
    
    # Summary
    print("\n📋 DIAGNOSTIC SUMMARY")
    print("=" * 50)
    
    print("Function imports:")
    for func, status in import_results.items():
        status_str = "✅ OK" if status else "❌ FAILED"
        print(f"  {func}: {status_str}")
    
    print(f"Water level generation: {'✅ OK' if water_level_ok else '❌ FAILED'}")
    print(f"DEM styling logic: {'✅ OK' if dem_styling_ok else '❌ FAILED'}")
    
    # Recommendations
    print("\n🎯 RECOMMENDATIONS")
    print("=" * 50)
    
    if not all(import_results.values()):
        print("❌ Some functions cannot be imported - check function definitions")
    
    if not water_level_ok:
        print("❌ Water level generation is broken - check accumulation logic")
    
    if not dem_styling_ok:
        print("❌ DEM styling has issues - check color ramp calculation")
    
    if all(import_results.values()) and water_level_ok and dem_styling_ok:
        print("✅ All core functions appear to be working")
        print("💡 Issue might be in:")
        print("   - UI not calling the FIXED functions correctly")
        print("   - QGIS layer caching/refresh issues")
        print("   - File path or permission problems")
        print("   - Function signature mismatches")

if __name__ == "__main__":
    main()
