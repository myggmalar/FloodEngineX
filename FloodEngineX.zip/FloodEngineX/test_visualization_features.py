#!/usr/bin/env python3
"""
Test script for FloodEngine v4.0 Advanced Visualization Features
================================================================

Tests the advanced visualization module functionality and validates integration capabilities.
"""

import os
import sys
import numpy as np
import traceback
from pathlib import Path

def test_visualization_imports():
    """Test if visualization module can be imported successfully."""
    print("🔬 Testing Advanced Visualization Features Import...")
    
    try:
        from advanced_visualization_features import (
            FloodEngineVisualizationManager,
            VisualizationConfig,
            FloodVisualization3D,
            FloodAnimationGenerator,
            InteractiveFloodAnalysis,
            VRFloodVisualization
        )
        print("✅ Successfully imported all visualization classes")
        return True
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False
    except Exception as e:
        print(f"❌ Unexpected error during import: {e}")
        traceback.print_exc()
        return False

def test_visualization_manager():
    """Test visualization manager initialization and capabilities."""
    print("\n🔬 Testing Visualization Manager...")
    
    try:
        from advanced_visualization_features import FloodEngineVisualizationManager
        
        # Test manager initialization
        output_dir = Path("test_output")
        output_dir.mkdir(exist_ok=True)
        
        viz_manager = FloodEngineVisualizationManager(str(output_dir))
        print(f"✅ Visualization manager initialized successfully")
        
        # Check capabilities
        print(f"📊 Available capabilities:")
        for capability, available in viz_manager.capabilities.items():
            status = "✅" if available else "⚠️"
            print(f"  {status} {capability}: {available}")
        
        return True, viz_manager
        
    except Exception as e:
        print(f"❌ Error testing visualization manager: {e}")
        traceback.print_exc()
        return False, None

def test_visualization_components(viz_manager):
    """Test individual visualization components."""
    print("\n🔬 Testing Visualization Components...")
    
    results = {}
    
    # Test 3D Visualization
    try:
        if viz_manager.capabilities['3d_visualization']:
            viz_3d = viz_manager.create_3d_visualization()
            print("✅ 3D visualization component created successfully")
            results['3d_visualization'] = True
        else:
            print("⚠️ 3D visualization not available (VTK dependency missing)")
            results['3d_visualization'] = False
    except Exception as e:
        print(f"❌ Error creating 3D visualization: {e}")
        results['3d_visualization'] = False
    
    # Test Animation Generator
    try:
        if viz_manager.capabilities['animation_generation']:
            anim_gen = viz_manager.create_animation_generator()
            print("✅ Animation generator created successfully")
            results['animation_generation'] = True
        else:
            print("⚠️ Animation generation not available (dependencies missing)")
            results['animation_generation'] = False
    except Exception as e:
        print(f"❌ Error creating animation generator: {e}")
        results['animation_generation'] = False
    
    # Test Interactive Analysis
    try:
        if viz_manager.capabilities['interactive_analysis']:
            interactive = viz_manager.create_interactive_analysis()
            print("✅ Interactive analysis component created successfully")
            results['interactive_analysis'] = True
        else:
            print("⚠️ Interactive analysis not available (Plotly/Dash missing)")
            results['interactive_analysis'] = False
    except Exception as e:
        print(f"❌ Error creating interactive analysis: {e}")
        results['interactive_analysis'] = False
    
    # Test VR Visualization
    try:
        if viz_manager.capabilities['vr_visualization']:
            vr_viz = viz_manager.create_vr_visualization()
            print("✅ VR visualization component created successfully")
            results['vr_visualization'] = True
        else:
            print("⚠️ VR visualization not available (OpenVR missing)")
            results['vr_visualization'] = False
    except Exception as e:
        print(f"❌ Error creating VR visualization: {e}")
        results['vr_visualization'] = False
    
    return results

def test_data_processing():
    """Test data processing capabilities with sample data."""
    print("\n🔬 Testing Data Processing with Sample Data...")
    
    try:
        # Create sample DEM data
        dem_data = np.random.rand(50, 50) * 100
        extent = (0, 1000, 0, 1000)
        
        # Create sample simulation results
        simulation_results = []
        for i in range(3):
            water_levels = np.maximum(0, (dem_data - 80) + np.random.rand(*dem_data.shape) * 10)
            velocities = np.random.rand(*dem_data.shape, 2) * 2
            
            simulation_results.append({
                'time': i * 60,  # seconds
                'water_levels': water_levels,
                'velocities': velocities
            })
        
        print(f"✅ Created sample data: DEM {dem_data.shape}, {len(simulation_results)} time steps")
        return True, dem_data, extent, simulation_results
        
    except Exception as e:
        print(f"❌ Error creating sample data: {e}")
        return False, None, None, None

def test_floodengine_integration():
    """Test integration with existing FloodEngine modules."""
    print("\n🔬 Testing FloodEngine Integration...")
    
    try:
        # Test integration with existing FloodEngine modules
        existing_modules = [
            'saint_venant_2d',
            'advanced_analysis_tools',
            'web_services_integration',
            'database_connectivity',
            'cloud_computing_interface',
            'restful_api_implementation'
        ]
        
        integration_status = {}
        for module in existing_modules:
            try:
                __import__(module)
                integration_status[module] = True
                print(f"✅ {module} available for integration")
            except ImportError:
                integration_status[module] = False
                print(f"⚠️ {module} not found")
        
        # Test specific integration functions
        try:
            from advanced_visualization_features import create_flood_visualization_from_qgis
            print("✅ QGIS integration function available")
        except ImportError:
            print("⚠️ QGIS integration function not available")
        
        return integration_status
        
    except Exception as e:
        print(f"❌ Error testing integration: {e}")
        return {}

def generate_test_report(results):
    """Generate comprehensive test report."""
    print("\n📋 FLOODENGINE V4.0 ADVANCED VISUALIZATION TEST REPORT")
    print("=" * 60)
    
    print(f"\n📊 IMPORT STATUS: {'✅ PASS' if results['import_success'] else '❌ FAIL'}")
    
    print(f"\n📊 MANAGER STATUS: {'✅ PASS' if results['manager_success'] else '❌ FAIL'}")
    
    print("\n📊 COMPONENT STATUS:")
    if 'component_results' in results:
        for component, status in results['component_results'].items():
            status_text = "✅ AVAILABLE" if status else "⚠️ NOT AVAILABLE"
            print(f"  - {component}: {status_text}")
    
    print(f"\n📊 DATA PROCESSING: {'✅ PASS' if results['data_success'] else '❌ FAIL'}")
    
    print("\n📊 INTEGRATION STATUS:")
    if 'integration_status' in results:
        for module, status in results['integration_status'].items():
            status_text = "✅ AVAILABLE" if status else "⚠️ NOT FOUND"
            print(f"  - {module}: {status_text}")
    
    # Summary
    total_tests = 4
    passed_tests = sum([
        results['import_success'],
        results['manager_success'],
        results['data_success'],
        bool(results.get('integration_status', {}))
    ])
    
    print(f"\n📈 OVERALL STATUS: {passed_tests}/{total_tests} tests passed")
    
    if passed_tests >= 3:
        print("🎉 Advanced Visualization Features are ready for production use!")
    elif passed_tests >= 2:
        print("⚠️ Advanced Visualization Features are partially functional")
    else:
        print("❌ Advanced Visualization Features need attention")
    
    print("\n💡 NEXT STEPS:")
    print("  1. Install optional dependencies for full functionality:")
    print("     - VTK for 3D visualization: pip install vtk")
    print("     - Plotly/Dash for interactive analysis: pip install plotly dash")
    print("     - OpenVR for VR capabilities: pip install openvr")
    print("  2. Test with real FloodEngine simulation data")
    print("  3. Proceed to Phase 7: Climate Change Impact Assessment")

def main():
    """Main test execution."""
    print("🚀 STARTING FLOODENGINE V4.0 ADVANCED VISUALIZATION FEATURES TEST")
    print("=" * 70)
    
    results = {}
    
    # Test 1: Import functionality
    results['import_success'] = test_visualization_imports()
    
    # Test 2: Manager initialization
    if results['import_success']:
        results['manager_success'], viz_manager = test_visualization_manager()
        
        if results['manager_success']:
            # Test 3: Component creation
            results['component_results'] = test_visualization_components(viz_manager)
        else:
            results['component_results'] = {}
    else:
        results['manager_success'] = False
        results['component_results'] = {}
    
    # Test 4: Data processing
    results['data_success'], dem_data, extent, simulation_results = test_data_processing()
    
    # Test 5: Integration
    results['integration_status'] = test_floodengine_integration()
    
    # Generate report
    generate_test_report(results)

if __name__ == "__main__":
    main()
