"""
FloodEngine Hydraulic Model Test Script
-------------------------------------
This script demonstrates the usage of the enhanced hydraulic models.
"""

import os
import sys
import logging
from qgis.core import QgsApplication, QgsVectorLayer, QgsRasterLayer, QgsProject
from qgis.gui import QgsMapCanvas

# Add plugin directory to path
plugin_dir = r"c:\Plugin\VSCode\FloodEngine_fixed_v8"
if plugin_dir not in sys.path:
    sys.path.append(plugin_dir)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] - %(name)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(plugin_dir, 'test_run.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("FloodEngine.Test")

class MockInterface:
    """Mock QGIS interface for testing"""
    
    def __init__(self):
        self.messageBar = lambda: self
        
    def pushInfo(self, title, message):
        logger.info(f"{title}: {message}")
        
    def pushWarning(self, title, message):
        logger.warning(f"{title}: {message}")
        
    def pushSuccess(self, title, message):
        logger.info(f"{title}: {message}")
        
    def pushCritical(self, title, message):
        logger.critical(f"{title}: {message}")


def run_test(dem_path, flood_layer_path, output_folder, water_level=None, flow_q=None):
    """Run test of all hydraulic models"""
    
    logger.info("Starting FloodEngine hydraulic model test")
    
    # Create mock interface
    iface = MockInterface()
    
    # Create output folder if it doesn't exist
    os.makedirs(output_folder, exist_ok=True)
    
    # Load the flood layer
    flood_layer = QgsVectorLayer(flood_layer_path, "Flood Layer", "ogr")
    if not flood_layer.isValid():
        logger.error(f"Could not load flood layer: {flood_layer_path}")
        return
        
    logger.info(f"Loaded flood layer with {flood_layer.featureCount()} features")
    
    # Load the DEM layer
    dem_layer = QgsRasterLayer(dem_path, "DEM")
    if not dem_layer.isValid():
        logger.error(f"Could not load DEM: {dem_path}")
        return
        
    logger.info(f"Loaded DEM: {dem_path}")
    
    # Extract water level from flood layer if not provided
    if water_level is None:
        water_levels = []
        for feature in flood_layer.getFeatures():
            if 'water_lvl' in feature.fields().names():
                water_levels.append(float(feature['water_lvl']))
                
        if water_levels:
            water_level = sum(water_levels) / len(water_levels)
            logger.info(f"Extracted water level: {water_level:.2f}m")
        else:
            water_level = 100.0  # Default value
            logger.warning(f"No water level in flood layer. Using default: {water_level}m")
    
    # Test 1: Run full Saint-Venant simulation
    try:
        from saint_venant_2d import simulate_saint_venant_2d
        
        logger.info("1. Running full 2D Saint-Venant simulation")
        
        sv_output_folder = os.path.join(output_folder, "saint_venant")
        os.makedirs(sv_output_folder, exist_ok=True)
        
        water_files, velocity_files = simulate_saint_venant_2d(
            dem_path=dem_path,
            initial_water_level=water_level,
            output_folder=sv_output_folder,
            time_steps=10,  # Reduced for testing
            inflow_rate=flow_q,
            manning_n=0.035
        )
        
        logger.info(f"Saint-Venant simulation completed with {len(water_files)} output files")
        logger.info(f"Final water surface: {water_files[-1]}")
        logger.info(f"Final velocity: {velocity_files[-1]}")
        
    except ImportError:
        logger.error("Saint-Venant module not available")
    except Exception as e:
        logger.error(f"Error in Saint-Venant simulation: {str(e)}")
    
    # Test 2: Fix flow directions
    try:
        from flow_direction import analyze_flow_patterns
        
        logger.info("2. Running flow direction correction")
        
        flow_output_folder = os.path.join(output_folder, "flow_direction")
        os.makedirs(flow_output_folder, exist_ok=True)
        
        # First create a simple water surface for testing if we don't have one
        if 'water_files' not in locals() or not water_files:
            # Create a simple water surface based on flood layer
            from osgeo import gdal
            
            # Create a raster of the DEM
            dem_ds = gdal.Open(dem_path)
            dem_array = dem_ds.GetRasterBand(1).ReadAsArray()
            geotransform = dem_ds.GetGeoTransform()
            projection = dem_ds.GetProjection()
            
            # Create a simple water surface by adding water depth
            water_surface_path = os.path.join(flow_output_folder, "simple_water_surface.tif")
            driver = gdal.GetDriverByName("GTiff")
            water_ds = driver.Create(
                water_surface_path, 
                dem_array.shape[1], 
                dem_array.shape[0], 
                1, 
                gdal.GDT_Float32
            )
            water_ds.SetGeoTransform(geotransform)
            water_ds.SetProjection(projection)
            water_band = water_ds.GetRasterBand(1)
            
            # Set water surface to DEM + water level where in flood area, DEM elsewhere
            import numpy as np
            water_array = dem_array.copy()
            water_array[~np.isnan(water_array)] = water_level
            
            water_band.WriteArray(water_array)
            water_band.FlushCache()
            water_ds = None
            
            logger.info(f"Created simple water surface for testing: {water_surface_path}")
        else:
            water_surface_path = water_files[-1]
            
        vx_path, vy_path, vmag_path = analyze_flow_patterns(
            dem_path=dem_path,
            water_surface_path=water_surface_path,
            output_folder=flow_output_folder
        )
        
        logger.info("Flow direction correction completed")
        logger.info(f"Velocity X: {vx_path}")
        logger.info(f"Velocity Y: {vy_path}")
        logger.info(f"Velocity magnitude: {vmag_path}")
        
    except ImportError:
        logger.error("Flow direction module not available")
    except Exception as e:
        logger.error(f"Error in flow direction correction: {str(e)}")
    
    # Test 3: Generate improved streamlines
    try:
        from enhanced_streamlines import create_enhanced_streamlines
        
        logger.info("3. Generating enhanced streamlines")
        
        streamline_output_folder = os.path.join(output_folder, "streamlines")
        os.makedirs(streamline_output_folder, exist_ok=True)
        
        streamline_layer = create_enhanced_streamlines(
            dem_path=dem_path,
            flood_layer=flood_layer,
            output_folder=streamline_output_folder,
            flow_q=flow_q,
            method="hydraulic"
        )
        
        if streamline_layer and streamline_layer.isValid():
            logger.info(f"Generated {streamline_layer.featureCount()} enhanced streamlines")
        else:
            logger.warning("No valid streamlines were created")
        
    except ImportError:
        logger.error("Enhanced streamlines module not available")
    except Exception as e:
        logger.error(f"Error in streamline generation: {str(e)}")
    
    logger.info("Test completed")


# Test parameters
# Replace these with actual paths from your system
DEFAULT_DEM_PATH = r"C:\path\to\your\dem.tif"
DEFAULT_FLOOD_PATH = r"C:\path\to\your\flood.shp"
DEFAULT_OUTPUT_FOLDER = r"C:\path\to\your\output"
DEFAULT_FLOW_Q = 50.0  # m³/s

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Test FloodEngine hydraulic models')
    parser.add_argument('--dem', default=DEFAULT_DEM_PATH, help='Path to DEM file')
    parser.add_argument('--flood', default=DEFAULT_FLOOD_PATH, help='Path to flood polygon shapefile')
    parser.add_argument('--output', default=DEFAULT_OUTPUT_FOLDER, help='Output folder')
    parser.add_argument('--water-level', type=float, help='Water level in meters')
    parser.add_argument('--flow-q', type=float, default=DEFAULT_FLOW_Q, help='Flow rate in m³/s')
    
    args = parser.parse_args()
    
    run_test(
        dem_path=args.dem,
        flood_layer_path=args.flood,
        output_folder=args.output,
        water_level=args.water_level,
        flow_q=args.flow_q
    )
