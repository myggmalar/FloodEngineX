"""
Test script to verify Saint-Venant velocity file loading
"""
import os
import numpy as np
from osgeo import gdal
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("VelocityFileTest")

def test_velocity_file_loading():
    """Test loading Saint-Venant velocity files"""
    
    output_folder = "C:/Plugin/VSCode/output"
    
    logger.info(f"Testing velocity file loading from: {output_folder}")
    
    # Look for velocity files
    velocity_x_files = [f for f in os.listdir(output_folder) if f.startswith('velocity_x_') and f.endswith('.tif')]
    velocity_y_files = [f for f in os.listdir(output_folder) if f.startswith('velocity_y_') and f.endswith('.tif')]
    
    logger.info(f"Found velocity X files: {len(velocity_x_files)} files")
    logger.info(f"Velocity X files: {velocity_x_files}")
    logger.info(f"Found velocity Y files: {len(velocity_y_files)} files")
    logger.info(f"Velocity Y files: {velocity_y_files}")
    
    if velocity_x_files and velocity_y_files:
        # Load the latest timestep
        latest_vx_file = sorted(velocity_x_files)[-1]
        latest_vy_file = sorted(velocity_y_files)[-1]
        
        vx_path = os.path.join(output_folder, latest_vx_file)
        vy_path = os.path.join(output_folder, latest_vy_file)
        
        logger.info(f"Loading latest velocity files:")
        logger.info(f"  - X component: {latest_vx_file}")
        logger.info(f"  - Y component: {latest_vy_file}")
        
        try:
            # Load velocity arrays
            vx_ds = gdal.Open(vx_path)
            vy_ds = gdal.Open(vy_path)
            
            vx_array = vx_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
            vy_array = vy_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
            
            # Handle NoData values
            vx_nodata = vx_ds.GetRasterBand(1).GetNoDataValue()
            vy_nodata = vy_ds.GetRasterBand(1).GetNoDataValue()
            
            if vx_nodata is not None:
                vx_array[vx_array == vx_nodata] = 0.0
            if vy_nodata is not None:
                vy_array[vy_array == vy_nodata] = 0.0
            
            # Debug velocity statistics
            valid_vx = vx_array[np.isfinite(vx_array)]
            valid_vy = vy_array[np.isfinite(vy_array)]
            
            if len(valid_vx) > 0 and len(valid_vy) > 0:
                vx_stats = f"min: {np.min(valid_vx):.3f}, max: {np.max(valid_vx):.3f}, mean: {np.mean(valid_vx):.3f}"
                vy_stats = f"min: {np.min(valid_vy):.3f}, max: {np.max(valid_vy):.3f}, mean: {np.mean(valid_vy):.3f}"
                logger.info(f"Saint-Venant Velocity X: {vx_stats}")
                logger.info(f"Saint-Venant Velocity Y: {vy_stats}")
                
                # Calculate velocity magnitude for debugging
                vel_mag_sv = np.sqrt(vx_array**2 + vy_array**2)
                valid_vel_mag = vel_mag_sv[np.isfinite(vel_mag_sv)]
                
                if len(valid_vel_mag) > 0:
                    vel_mag_stats = f"min: {np.min(valid_vel_mag):.3f}, max: {np.max(valid_vel_mag):.3f}, mean: {np.mean(valid_vel_mag):.3f}"
                    logger.info(f"Saint-Venant Velocity magnitude: {vel_mag_stats}")
                    logger.info(f"Cells with velocity > 0.001: {np.sum(vel_mag_sv > 0.001)}")
                    logger.info(f"Cells with velocity > 0.01: {np.sum(vel_mag_sv > 0.01)}")
                    logger.info(f"Cells with velocity > 0.1: {np.sum(vel_mag_sv > 0.1)}")
                    
                    logger.info("🎉 SUCCESS: Saint-Venant velocity files loaded successfully!")
                    logger.info(f"✅ Array shapes: VX={vx_array.shape}, VY={vy_array.shape}")
                    
                    return True
                else:
                    logger.warning("Saint-Venant velocity arrays contain no valid data")
            else:
                logger.warning("Saint-Venant velocity arrays are empty or invalid")
                
        except Exception as e:
            logger.error(f"Error loading velocity files: {str(e)}")
            
    else:
        logger.warning("No Saint-Venant velocity component files found")
        logger.info("Available files in output folder:")
        for f in os.listdir(output_folder):
            if f.endswith('.tif'):
                logger.info(f"  {f}")
    
    return False

if __name__ == "__main__":
    success = test_velocity_file_loading()
    if success:
        print("\n✅ Velocity file loading test PASSED!")
    else:
        print("\n❌ Velocity file loading test FAILED!")
