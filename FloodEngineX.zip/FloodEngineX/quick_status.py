import os
import sys

# Add current directory to path
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

print("FloodEngine v4.0 - Quick Status Check")
print("=" * 40)

# Test imports
try:
    import floodengine
    print("✅ floodengine.py imports successfully")
except Exception as e:
    print(f"❌ floodengine.py import failed: {e}")

try:
    import model_hydraulic
    print("✅ model_hydraulic.py imports successfully")
except Exception as e:
    print(f"❌ model_hydraulic.py import failed: {e}")

try:
    import saint_venant_2d_fixed
    print("✅ saint_venant_2d_fixed.py imports successfully")
except Exception as e:
    print(f"❌ saint_venant_2d_fixed.py import failed: {e}")

# Check production package
prod_file = os.path.join(current_dir, "FloodEngine_v4.0_Production.zip")
if os.path.exists(prod_file):
    size = os.path.getsize(prod_file) / 1024 / 1024
    print(f"✅ Production package exists ({size:.1f} MB)")
else:
    print("❌ Production package missing")

print("\nStatus: Plugin appears functional and ready for use")
