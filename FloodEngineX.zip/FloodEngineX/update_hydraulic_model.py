"""
Update script for model_hydraulic.py with Saint-Venant equations
---------------------------------------------------------------
This script modifies the model_hydraulic.py to use full Saint-Venant equations.
Run this script to update your model_hydraulic.py file.
"""

import os
import sys
import re
import shutil

def update_hydraulic_model():
    """Update model_hydraulic.py with improved hydrology"""
    
    # Get path to this script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    model_path = os.path.join(script_dir, "model_hydraulic.py")
    
    # Check if file exists
    if not os.path.exists(model_path):
        print(f"Error: Could not find {model_path}")
        return False
    
    # Create backup of original file
    backup_path = os.path.join(script_dir, "model_hydraulic.py.bak")
    shutil.copy2(model_path, backup_path)
    print(f"Created backup at {backup_path}")
    
    # Read the original file
    with open(model_path, 'r', encoding='utf-8') as f:
        original_code = f.read()
    
    # Extract the appropriate function to modify
    pattern_streamlines = re.compile(r'def calculate_streamlines_hydraulic\([^)]*\):.*?(?=\n\w+)', re.DOTALL)
    streamlines_match = pattern_streamlines.search(original_code)
    
    pattern_simulate = re.compile(r'def simulate_over_time\([^)]*\):.*?(?=\n\w+)', re.DOTALL)
    simulate_match = pattern_simulate.search(original_code)
    
    if not streamlines_match or not simulate_match:
        print("Error: Could not find target functions in model_hydraulic.py")
        return False
    
    # Modified function implementations
    simulate_func = """def simulate_over_time(iface, dem_path, water_level, flow_q, output_folder, time_steps=10, threshold=None, bathymetry=None):
    """
    simulate_func += '"""'
    simulate_func += """
    Simulerar översvämningsutbredning över tid med volymbevarande hydraulik.
    Om endast Q (flöde) anges, beräknas vattennivån dynamiskt utifrån Q och tröskelvärde.
    :param water_level: Initial vattennivå (kan vara None)
    :param flow_q: Flöde i m³/s (kan vara None)
    :param threshold: Tröskelvärde för översvämning (t.ex. minsta nivå för översvämning)
    """
    simulate_func += '"""'
    simulate_func += """
    import logging
    # Extra skydd: konvertera output_folder till str om det är int
    if isinstance(output_folder, int):
        logging.error(f"output_folder var int ({output_folder}), konverterar till str!")
        output_folder = str(output_folder)
    log_path = output_folder if isinstance(output_folder, str) else str(output_folder)
    try:
        log_file = os.path.join(log_path, "simulate_over_time_debug.log")
        logging.basicConfig(filename=log_file, level=logging.DEBUG)
        logging.debug(f"simulate_over_time called with: dem_path={dem_path} ({type(dem_path)}), output_folder={output_folder} ({type(output_folder)}), water_level={water_level}, flow_q={flow_q}, time_steps={time_steps}, threshold={threshold}")
        logging.info(f"Q (flöde) används i simuleringen: {flow_q}")
    except Exception as e:
        with open("simulate_over_time_fallback.log", "a") as f:
            f.write(f"Logging setup failed: {e}\\n")
    
    # Check for advanced simulation modules
    try:
        from saint_venant_2d import simulate_saint_venant_2d
        use_advanced_model = True
    except ImportError:
        use_advanced_model = False
    
    # Use the advanced Saint-Venant model if available
    if use_advanced_model:
        try:
            print(f"Using full 2D Saint-Venant equations for simulation")
            sv_output_folder = os.path.join(output_folder, "saint_venant")
            os.makedirs(sv_output_folder, exist_ok=True)
            
            water_files, velocity_files = simulate_saint_venant_2d(
                dem_path=dem_path,
                initial_water_level=water_level,
                output_folder=sv_output_folder,
                time_steps=time_steps,
                inflow_rate=flow_q,
                manning_n=0.035
            )
            
            # Original implementation continues for backward compatibility
            # But we use the results from Saint-Venant model
            
            # Load the final simulation results into QGIS
            final_water_layer = QgsRasterLayer(water_files[-1], "Final Water Level (Saint-Venant)")
            final_velocity_layer = QgsRasterLayer(velocity_files[-1], "Final Velocity (Saint-Venant)")
            
            if final_water_layer.isValid():
                QgsProject.instance().addMapLayer(final_water_layer)
            
            if final_velocity_layer.isValid():
                QgsProject.instance().addMapLayer(final_velocity_layer)
                
            # Continue with original implementation
        except Exception as e:
            print(f"Error in Saint-Venant simulation: {str(e)}. Falling back to standard model.")
    
    # Original implementation continues here
    """
    
    streamlines_func = """def calculate_streamlines_hydraulic(iface, dem_path, flood_layer, output_folder=None, flow_q=None, bathymetry=None):
    """
    streamlines_func += '"""'
    streamlines_func += """
    Beräkna realistiska streamlines baserat på hydraulisk modellering.
    Hanterar korrekt flödesriktning från uppströms till nedströms
    och tar hänsyn till vattendjup, terränglutning och flödeskvantitet.
    """
    streamlines_func += '"""'
    streamlines_func += """
    # Check for enhanced streamline module
    try:
        from enhanced_streamlines import create_enhanced_streamlines
        from flow_direction import enforce_downhill_flow, smooth_flow_field
        use_enhanced_streamlines = True
    except ImportError:
        use_enhanced_streamlines = False
    
    # Use the enhanced streamlines model if available
    if use_enhanced_streamlines:
        try:
            print("Using enhanced streamlines with improved hydraulic behavior")
            
            streamline_layer = create_enhanced_streamlines(
                dem_path=dem_path,
                flood_layer=flood_layer,
                output_folder=output_folder,
                flow_q=flow_q,
                method="hydraulic"
            )
            
            if streamline_layer and streamline_layer.isValid():
                print(f"Generated {streamline_layer.featureCount()} enhanced streamlines")
                return streamline_layer
            else:
                print("No valid enhanced streamlines were created, falling back to standard method")
        except Exception as e:
            print(f"Error in enhanced streamline generation: {str(e)}. Falling back to standard method.")
    
    # Original implementation continues here
    """
    
    # Replace original functions with modified versions
    # by prepending the new versions - full replacement can be error-prone
    modified_code = original_code
    
    if simulate_match:
        modified_code = modified_code.replace(
            simulate_match.group(0),
            simulate_func + "\n    # Original implementation\n" + simulate_match.group(0)[len("def simulate_over_time(iface, dem_path, water_level, flow_q, output_folder, time_steps=10, threshold=None, bathymetry=None):")]
        )
    
    if streamlines_match:
        modified_code = modified_code.replace(
            streamlines_match.group(0),
            streamlines_func + "\n    # Original implementation\n" + streamlines_match.group(0)[len("def calculate_streamlines_hydraulic(iface, dem_path, flood_layer, output_folder=None, flow_q=None, bathymetry=None):")]
        )
    
    # Add imports if not present
    if "from scipy.ndimage import gaussian_filter" not in modified_code:
        import_section = "import os\nimport time\nimport tempfile\nimport numpy as np\nimport csv\nimport math\nimport logging\nimport traceback\nfrom osgeo import gdal, ogr, osr\nfrom scipy.ndimage import gaussian_filter"
        modified_code = modified_code.replace(
            "import os\nimport time\nimport tempfile\nimport numpy as np\nimport csv\nimport math", 
            import_section
        )
    
    # Write the modified code
    try:
        with open(model_path, 'w', encoding='utf-8') as f:
            f.write(modified_code)
        print(f"Successfully updated {model_path}")
        return True
    except Exception as e:
        print(f"Error writing to {model_path}: {str(e)}")
        print("Restoring backup...")
        shutil.copy2(backup_path, model_path)
        return False

if __name__ == "__main__":
    update_hydraulic_model()
