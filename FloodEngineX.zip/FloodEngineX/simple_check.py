import sys
print("Python version:", sys.version)
print("Checking basic imports...")

try:
    import numpy
    print("✅ numpy available")
except:
    print("❌ numpy missing")

try:
    import matplotlib
    print("✅ matplotlib available") 
except:
    print("❌ matplotlib missing")

try:
    import vtk
    print("✅ VTK available")
except:
    print("❌ VTK missing")

try:
    import plotly
    print("✅ plotly available")
except:
    print("❌ plotly missing")

print("Testing advanced_visualization_features import...")
try:
    import advanced_visualization_features
    print("✅ Module imported successfully")
except Exception as e:
    print(f"❌ Import failed: {e}")
