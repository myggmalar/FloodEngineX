#!/usr/bin/env python
# Simple test script to verify that the FloodEngineDialog class can be imported
# This doesn't attempt to run the UI as that would require QGIS

try:
    print("Testing import of floodengine_ui module...")
    import floodengine_ui
    print("Successfully imported floodengine_ui module!")
    
    print("\nTesting import of FloodEngineDialog class...")
    from floodengine_ui import FloodEngineDialog
    print("Successfully imported FloodEngineDialog class!")
    
    print("\nChecking select_calculation_area method exists...")
    if hasattr(FloodEngineDialog, 'select_calculation_area'):
        print("select_calculation_area method exists in FloodEngineDialog class!")
    else:
        print("ERROR: select_calculation_area method not found in FloodEngineDialog!")
    
    print("\nChecking FloodEngine class...")
    import floodengine
    from floodengine import FloodEngine
    print("Successfully imported FloodEngine class!")
    
    print("\nChecking select_calculation_area method exists in FloodEngine...")
    if hasattr(FloodEngine, 'select_calculation_area'):
        print("select_calculation_area method exists in FloodEngine class!")
    else:
        print("ERROR: select_calculation_area method not found in FloodEngine!")
        
    print("\nAll checks passed successfully!")
    
except Exception as e:
    print(f"Error during testing: {e}")
