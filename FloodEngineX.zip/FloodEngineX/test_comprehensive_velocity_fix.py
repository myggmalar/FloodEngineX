#!/usr/bin/env python3
"""
Comprehensive test to verify the velocity capping fix in enhanced_streamlines.py.
This test simulates the exact scenario where extreme Saint-Venant velocities 
are loaded and processed.
"""

import numpy as np
import os
import sys
import logging

# Add the current directory to the path so we can import FloodEngineX modules
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_enhanced_streamlines_velocity_capping():
    """Test velocity capping in the context of enhanced_streamlines.py"""
    
    # Set up logging
    logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
    logger = logging.getLogger("test_enhanced_streamlines")
    
    logger.info("🧪 Testing enhanced_streamlines velocity capping...")
    
    try:
        # Import the enhanced streamlines module
        from enhanced_streamlines import EnhancedStreamlines
        
        # Create a test DEM and water depth
        test_shape = (50, 50)
        test_dem = np.random.uniform(0, 10, test_shape)
        test_geotransform = (0, 1, 0, 0, 0, -1)  # Simple geotransform
        test_water_depth = np.random.uniform(0.5, 2.0, test_shape)
        
        # Create the EnhancedStreamlines object
        streamlines = EnhancedStreamlines(test_dem, test_geotransform, water_depth=test_water_depth)
        
        # Create extreme Saint-Venant results
        extreme_saint_venant_results = {
            'velocity_x': np.random.uniform(-1000, 1000, test_shape),  # Extreme velocities
            'velocity_y': np.random.uniform(-1000, 1000, test_shape),  # Extreme velocities
            'velocity_magnitude': np.random.uniform(0, 1500, test_shape),  # Extreme magnitudes
        }
        
        original_max = np.max(extreme_saint_venant_results['velocity_magnitude'])
        logger.info(f"Original max velocity: {original_max:.1f} m/s")
        
        # Test the calculate_velocity_field method with extreme velocities
        logger.info("🧪 Testing calculate_velocity_field with extreme Saint-Venant results...")
        
        try:
            velocity_x, velocity_y, velocity_mag = streamlines.calculate_velocity_field(
                manning_n=0.035,
                method="saint_venant",
                saint_venant_results=extreme_saint_venant_results
            )
            
            # Check the results
            final_max = np.max(velocity_mag)
            final_max_x = np.max(np.abs(velocity_x))
            final_max_y = np.max(np.abs(velocity_y))
            
            logger.info(f"Final velocity statistics:")
            logger.info(f"  • Max velocity magnitude: {final_max:.3f} m/s")
            logger.info(f"  • Max |velocity_x|: {final_max_x:.3f} m/s")
            logger.info(f"  • Max |velocity_y|: {final_max_y:.3f} m/s")
            
            # Verify capping worked
            MAX_EXPECTED = 8.0
            if final_max <= MAX_EXPECTED and final_max_x <= MAX_EXPECTED and final_max_y <= MAX_EXPECTED:
                logger.info("✅ SUCCESS: Velocity capping worked correctly!")
                logger.info(f"✅ All velocities are ≤ {MAX_EXPECTED} m/s")
                return True
            else:
                logger.error("❌ FAILED: Velocity capping did not work!")
                logger.error(f"❌ Expected max velocity ≤ {MAX_EXPECTED} m/s")
                if final_max > MAX_EXPECTED:
                    logger.error(f"❌ Actual max velocity: {final_max:.1f} m/s")
                return False
                
        except Exception as e:
            logger.error(f"❌ Error during velocity calculation: {str(e)}")
            return False
            
    except ImportError as e:
        logger.error(f"❌ Could not import enhanced_streamlines: {str(e)}")
        logger.error("❌ This test requires the enhanced_streamlines.py module")
        return False
    
    except Exception as e:
        logger.error(f"❌ Unexpected error: {str(e)}")
        return False

def test_load_saint_venant_velocity_files():
    """Test the load_saint_venant_velocity_files function with extreme velocities"""
    
    logger = logging.getLogger("test_load_saint_venant")
    logger.info("🧪 Testing load_saint_venant_velocity_files with extreme velocities...")
    
    try:
        from enhanced_streamlines import load_saint_venant_velocity_files
        
        # Create test directory and files
        test_dir = "test_saint_venant_extreme"
        os.makedirs(test_dir, exist_ok=True)
        
        # Create test files with extreme velocities
        test_shape = (30, 30)
        extreme_vx = np.random.uniform(-2000, 2000, test_shape)
        extreme_vy = np.random.uniform(-2000, 2000, test_shape)
        extreme_vmag = np.sqrt(extreme_vx**2 + extreme_vy**2)
        
        # Save test files
        np.save(os.path.join(test_dir, "velocity_x.npy"), extreme_vx)
        np.save(os.path.join(test_dir, "velocity_y.npy"), extreme_vy)
        np.save(os.path.join(test_dir, "velocity_magnitude.npy"), extreme_vmag)
        
        original_max = np.max(extreme_vmag)
        logger.info(f"Created test files with max velocity: {original_max:.1f} m/s")
        
        # Test loading (this should trigger capping)
        try:
            result = load_saint_venant_velocity_files(test_dir)
            
            if result is None:
                logger.info("✅ SUCCESS: Extreme velocities were detected and rejected (fallback triggered)")
                return True
            else:
                # Check if velocities were capped
                final_max = np.max(result['velocity_magnitude'])
                if final_max <= 8.0:
                    logger.info(f"✅ SUCCESS: Velocities were capped to {final_max:.1f} m/s")
                    return True
                else:
                    logger.error(f"❌ FAILED: Velocities were not capped (max: {final_max:.1f} m/s)")
                    return False
                    
        except Exception as e:
            logger.error(f"❌ Error loading Saint-Venant files: {str(e)}")
            return False
            
        finally:
            # Clean up test files
            import shutil
            if os.path.exists(test_dir):
                shutil.rmtree(test_dir)
                logger.info("🧹 Cleaned up test files")
    
    except ImportError as e:
        logger.error(f"❌ Could not import load_saint_venant_velocity_files: {str(e)}")
        return False
    
    except Exception as e:
        logger.error(f"❌ Unexpected error: {str(e)}")
        return False

if __name__ == "__main__":
    print("=" * 70)
    print("COMPREHENSIVE VELOCITY CAPPING TEST")
    print("=" * 70)
    
    # Test 1: Enhanced streamlines velocity capping
    print("\n🧪 TEST 1: Enhanced streamlines velocity capping")
    print("-" * 50)
    test1_passed = test_enhanced_streamlines_velocity_capping()
    
    # Test 2: Saint-Venant file loading with extreme velocities
    print("\n🧪 TEST 2: Saint-Venant file loading with extreme velocities")
    print("-" * 50)
    test2_passed = test_load_saint_venant_velocity_files()
    
    # Summary
    print("\n" + "=" * 70)
    print("FINAL RESULTS")
    print("=" * 70)
    
    if test1_passed and test2_passed:
        print("🎉 ALL TESTS PASSED!")
        print("✅ The velocity capping fix is working correctly.")
        print("✅ Extreme velocities will be properly capped or rejected.")
    else:
        print("❌ SOME TESTS FAILED!")
        if not test1_passed:
            print("❌ Enhanced streamlines velocity capping needs fixing")
        if not test2_passed:
            print("❌ Saint-Venant file loading needs fixing")
    
    print("=" * 70)
