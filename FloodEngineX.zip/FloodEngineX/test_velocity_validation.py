#!/usr/bin/env python3
"""
Test script to verify the Saint-Venant velocity validation and fallback mechanism.
This script tests that unrealistic Saint-Venant velocities are properly detected and
the system falls back to hydraulic approximation.
"""

import numpy as np
import os
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_velocity_validation():
    """Test the velocity validation logic"""
    
    logger.info("🧪 Testing Saint-Venant velocity validation...")
    
    # Test cases with different velocity scenarios
    test_cases = [
        {
            'name': 'Realistic velocities',
            'max_vel': 2.5,
            'mean_vel': 1.2,
            'expected_valid': True
        },
        {
            'name': 'Borderline velocities',
            'max_vel': 9.5,
            'mean_vel': 4.8,
            'expected_valid': True
        },
        {
            'name': 'Unrealistic max velocity',
            'max_vel': 25.0,
            'mean_vel': 3.0,
            'expected_valid': False
        },
        {
            'name': 'Unrealistic mean velocity',
            'max_vel': 8.0,
            'mean_vel': 7.0,
            'expected_valid': False
        },
        {
            'name': 'Extremely unrealistic velocities',
            'max_vel': 465.0,
            'mean_vel': 46.0,
            'expected_valid': False
        }
    ]
    
    passed_tests = 0
    total_tests = len(test_cases)
    
    for test_case in test_cases:
        logger.info(f"\n🔍 Testing: {test_case['name']}")
        logger.info(f"   Max velocity: {test_case['max_vel']:.1f} m/s")
        logger.info(f"   Mean velocity: {test_case['mean_vel']:.1f} m/s")
        
        # Apply the validation logic
        is_valid = not (test_case['max_vel'] > 10.0 or test_case['mean_vel'] > 5.0)
        
        if is_valid == test_case['expected_valid']:
            logger.info(f"   ✅ PASS: Correctly identified as {'valid' if is_valid else 'invalid'}")
            passed_tests += 1
        else:
            logger.error(f"   ❌ FAIL: Expected {'valid' if test_case['expected_valid'] else 'invalid'}, got {'valid' if is_valid else 'invalid'}")
    
    logger.info(f"\n📊 Test Results: {passed_tests}/{total_tests} tests passed")
    
    return passed_tests == total_tests

def test_velocity_capping():
    """Test the velocity capping logic"""
    
    logger.info("\n🧪 Testing velocity capping mechanism...")
    
    # Create synthetic velocity data with some unrealistic values
    shape = (10, 10)
    velocity_x = np.random.randn(*shape) * 5  # Some velocities will be high
    velocity_y = np.random.randn(*shape) * 5
    
    # Add some extremely high velocities
    velocity_x[5, 5] = 150.0  # Unrealistic
    velocity_y[5, 5] = 200.0  # Unrealistic
    velocity_x[7, 3] = -100.0  # Unrealistic
    velocity_y[7, 3] = 50.0   # Unrealistic
    
    # Calculate initial magnitude
    velocity_magnitude = np.sqrt(velocity_x**2 + velocity_y**2)
    
    logger.info(f"Before capping:")
    logger.info(f"   Max velocity: {np.max(velocity_magnitude):.1f} m/s")
    logger.info(f"   Mean velocity: {np.mean(velocity_magnitude):.1f} m/s")
    logger.info(f"   Cells > 10 m/s: {np.sum(velocity_magnitude > 10.0)}")
    
    # Apply capping logic
    max_realistic_velocity = 5.0
    unrealistic_count = np.sum(velocity_magnitude > max_realistic_velocity)
    
    if unrealistic_count > 0:
        logger.info(f"   Found {unrealistic_count} cells with unrealistic velocities")
        
        # Cap velocity magnitude
        velocity_scale = np.where(
            velocity_magnitude > max_realistic_velocity,
            max_realistic_velocity / velocity_magnitude,
            1.0
        )
        
        # Apply scaling
        velocity_x *= velocity_scale
        velocity_y *= velocity_scale
        velocity_magnitude = np.minimum(velocity_magnitude, max_realistic_velocity)
    
    logger.info(f"After capping:")
    logger.info(f"   Max velocity: {np.max(velocity_magnitude):.1f} m/s")
    logger.info(f"   Mean velocity: {np.mean(velocity_magnitude):.1f} m/s")
    logger.info(f"   Cells > 5 m/s: {np.sum(velocity_magnitude > 5.0)}")
    
    # Check if capping worked
    if np.max(velocity_magnitude) <= max_realistic_velocity:
        logger.info("   ✅ PASS: Velocity capping worked correctly")
        return True
    else:
        logger.error("   ❌ FAIL: Velocity capping failed")
        return False

def main():
    """Run all tests"""
    logger.info("🚀 Starting Saint-Venant velocity validation tests...")
    
    test1_passed = test_velocity_validation()
    test2_passed = test_velocity_capping()
    
    logger.info("\n" + "="*60)
    logger.info("TEST SUMMARY")
    logger.info("="*60)
    logger.info(f"✅ Velocity validation logic: {'PASS' if test1_passed else 'FAIL'}")
    logger.info(f"✅ Velocity capping mechanism: {'PASS' if test2_passed else 'FAIL'}")
    
    if test1_passed and test2_passed:
        logger.info("\n🎉 All tests passed! The velocity validation system is working correctly.")
        logger.info("   • Unrealistic Saint-Venant velocities will be detected")
        logger.info("   • System will fall back to hydraulic approximation")
        logger.info("   • Velocity capping prevents extreme values")
    else:
        logger.error("\n❌ Some tests failed. The validation system needs review.")
    
    logger.info("="*60)

if __name__ == "__main__":
    main()
