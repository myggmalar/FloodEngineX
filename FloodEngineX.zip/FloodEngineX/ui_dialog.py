# -*- coding: utf-8 -*-
"""
/***************************************************************************
 FloodEngineDialog
                                 A QGIS plugin
 Avancerat översvämnings- och erosionsverktyg
                             -------------------
        begin                : 2025-04-17
        git sha              : $Format:%H$
        copyright            : (C) 2025 by FloodEngine Team
        email                : floodengine@example.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import os
import time
import tempfile
import logging
import traceback
import numpy as np
import csv
import math

from PyQt5.QtWidgets import (
    QDialog, QLabel, QVBoxLayout, QHBoxLayout, QLineEdit, 
    QPushButton, QCheckBox, QMessageBox, QTabWidget, 
    QWidget, QSlider, QComboBox, QGroupBox, QRadioButton, 
    QGridLayout, QButtonGroup, QProgressBar, QSplitter, 
    QFileDialog, QSpacerItem, QSizePolicy, QScrollArea, QDialog, QVBoxLayout, QPushButton, QLabel, QHBoxLayout, QSlider, QDialogButtonBox)
from PyQt5.QtGui import QFont, QColor, QPalette, QIcon
from PyQt5.QtCore import Qt, QSize, QVariant, QTimer

from qgis.core import (QgsProject, QgsVectorLayer, QgsField, QgsFeature, 
                        QgsGeometry, QgsPointXY, QgsRasterLayer, QgsCoordinateReferenceSystem,
                        QgsVectorFileWriter, QgsSymbol, QgsRendererCategory, 
                        QgsCategorizedSymbolRenderer, QgsRasterBandStats,
                        QgsWkbTypes, QgsFeatureRequest, QgsRasterDataProvider)

from .model_hydraulic import (calculate_flood_area, burn_streams, calculate_erosion, 
                             calculate_flow_vectors, calculate_streamlines_with_speed as calculate_streamlines, load_bathymetry)

from qgis.PyQt import QtWidgets

class FloodEngineDialog(QDialog):
    """Dialog för FloodEngine-pluginet"""
    
    def __init__(self, iface):
        """Konstruktör för FloodEngineDialog

        :param iface: QGIS-gränssnitt
        :type iface: QgsInterface
        """
        super().__init__()
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.plugin_dir = os.path.dirname(__file__)
        
        # Sätt titeln för dialogen
        self.setWindowTitle("FloodEngine")
        self.setStyleSheet("QWidget { font-size: 9pt; }")
        try:
            self.setWindowIcon(QIcon(os.path.join(self.plugin_dir, "icon.png")))
        except:
            pass
        self.setMinimumWidth(600)
        self.setMinimumHeight(500)
        self.setMaximumHeight(1000)
        self.setMinimumWidth(600)
        self.setMinimumHeight(700)
        
        # Initiera logg
        self.log_file = os.path.join(tempfile.gettempdir(), f"floodengine_log_{int(time.time())}.txt")
        self.logger = self.setup_logger()
        
        # Inställningar för mörkt läge
        self.dark_mode = False
        
        # Skapa gränssnittet
        self.create_ui()
        
        # Koppla signals/lots
        self.connect_signals()
        
        # Initialize output interval display
        try:
            self.update_output_interval()
        except:
            pass
        
    def setup_logger(self):
        """Skapa och konfigurera loggning"""
        logger = logging.getLogger('FloodEngine')
        logger.setLevel(logging.INFO)
        handler = logging.FileHandler(self.log_file)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        return logger
        
    def create_ui(self):
        """Skapa användargränssnittet för dialogen"""
        main_layout = QVBoxLayout()
        
        # Mode toggle
        mode_layout = QHBoxLayout()
        self.basic_radio = QRadioButton("Basic")
        self.advanced_radio = QRadioButton("Advanced")
        self.basic_radio.setChecked(True)
        mode_group = QButtonGroup()
        mode_group.addButton(self.basic_radio)
        mode_group.addButton(self.advanced_radio)
        
        mode_layout.addWidget(QLabel("<b>Modelläge:</b>"))
        mode_layout.addWidget(self.basic_radio)
        mode_layout.addWidget(self.advanced_radio)
        mode_layout.addStretch()
        
        # Lägg till dark mode toggle
        self.dark_mode_checkbox = QCheckBox("Mörkt läge")
        mode_layout.addWidget(self.dark_mode_checkbox)
        
        main_layout.addLayout(mode_layout)
        
        # Tab widget för Basic och Advanced
        self.tab_widget = QTabWidget()
        
        # Basic tab
        self.basic_tab = QWidget()
        basic_layout = QVBoxLayout()
        
        # DEM input
        dem_group = QGroupBox("Digital höjdmodell (DEM)")
        dem_layout = QVBoxLayout()
        
        self.dem_path = QLineEdit()
        self.dem_btn = QPushButton("Välj DEM")
        dem_layout.addWidget(QLabel("DEM-fil (.tif, .asc):"))
        dem_layout.addWidget(self.dem_path)
        dem_layout.addWidget(self.dem_btn)
        dem_group.setLayout(dem_layout)
        
        # Bathymetri input - FÖRBÄTTRAD VERSION
        bathy_group = QGroupBox("Bathymetri (valfritt)")
        bathy_layout = QVBoxLayout()
        
        self.bathy_path = QLineEdit()
        self.bathy_btn = QPushButton("Välj bathymetri")
        
        bathy_layout.addWidget(QLabel("Bathymetri (.csv):"))
        bathy_layout.addWidget(self.bathy_path)

        # Val av kolumner för XYZ - förenklad version
        xyz_layout = QGridLayout()
        xyz_layout.addWidget(QLabel("X-koordinat:"), 0, 0)
        self.bathy_x_col = QComboBox()
        xyz_layout.addWidget(self.bathy_x_col, 0, 1)
        
        xyz_layout.addWidget(QLabel("Y-koordinat:"), 1, 0)
        self.bathy_y_col = QComboBox()
        xyz_layout.addWidget(self.bathy_y_col, 1, 1)
        
        xyz_layout.addWidget(QLabel("Djupvärde (Z):"), 2, 0)
        self.bathy_z_col = QComboBox()
        xyz_layout.addWidget(self.bathy_z_col, 2, 1)
        
        bathy_layout.addLayout(xyz_layout)
        bathy_layout.addWidget(self.bathy_btn)
        bathy_group.setLayout(bathy_layout)
        
        # Vattennivå och Flöde (Q) på samma rad
        water_group = QGroupBox("Vattennivå och flöde")
        water_layout = QHBoxLayout()
        # Vattennivå
        self.water_level = QLineEdit()
        self.water_level.setText("10.00")
        self.water_level.setMaximumWidth(80)
        self.water_level.setPlaceholderText("m")
        water_layout.addWidget(QLabel("Vattennivå (m):"))
        water_layout.addWidget(self.water_level)
        # Flöde Q
        self.flow_q = QLineEdit()
        self.flow_q.setText("")
        self.flow_q.setMaximumWidth(80)
        self.flow_q.setPlaceholderText("m³/s")
        self.flow_q.setToolTip("Flöde Q i m³/s (valfritt, 2 decimaler)")
        water_layout.addWidget(QLabel("Flöde Q (m³/s):"))
        water_layout.addWidget(self.flow_q)
        # Lägg till slider för vattennivå
        water_level_slider_layout = QVBoxLayout()
        self.water_level_slider = QSlider(Qt.Horizontal)
        self.water_level_slider.setMinimum(0)
        self.water_level_slider.setMaximum(20)
        self.water_level_slider.setValue(10)
        water_level_slider_layout.addWidget(self.water_level_slider)
        water_layout.addLayout(water_level_slider_layout)
        water_group.setLayout(water_layout)
        
        water_group.setLayout(water_layout)
        
        # Lägg till alla grupper till basic tab
        basic_layout.addWidget(dem_group)
        basic_layout.addWidget(bathy_group)
        basic_layout.addWidget(water_group)
        basic_layout.addStretch()
        
        self.basic_tab.setLayout(basic_layout)
        
        # Advanced tab
        self.advanced_tab = QWidget()
        advanced_layout = QVBoxLayout()
        
        # Jordart
        soil_group = QGroupBox("Jordartskarta")
        soil_layout = QVBoxLayout()
        
        self.soil_path = QLineEdit()
        self.soil_btn = QPushButton("Välj jordartskarta")
        
        soil_layout.addWidget(QLabel("Jordartskarta (.shp):"))
        soil_layout.addWidget(self.soil_path)
        soil_layout.addWidget(self.soil_btn)
        soil_group.setLayout(soil_layout)
        
        # Inbränning
        inburn_group = QGroupBox("Inbränning av vattendrag")
        inburn_layout = QVBoxLayout()
        
        self.inburn_checkbox = QCheckBox("Aktivera inbränning")
        self.stream_path = QLineEdit()
        self.stream_btn = QPushButton("Välj vattendrag")
        
        inburn_depth_layout = QHBoxLayout()
        self.inburn_depth_label = QLabel("Inbränningsdjup (m): 5")
        self.inburn_depth_slider = QSlider(Qt.Horizontal)
        self.inburn_depth_slider.setMinimum(1)
        self.inburn_depth_slider.setMaximum(20)
        self.inburn_depth_slider.setValue(5)
        self.inburn_depth_input = QLineEdit("5")
        self.inburn_depth_input.setMaximumWidth(50)
        
        inburn_depth_layout.addWidget(self.inburn_depth_label)
        inburn_depth_layout.addWidget(self.inburn_depth_slider)
        inburn_depth_layout.addWidget(self.inburn_depth_input)
        
        inburn_layout.addWidget(self.inburn_checkbox)
        inburn_layout.addWidget(QLabel("Vattendrag (.shp):"))
        inburn_layout.addWidget(self.stream_path)
        inburn_layout.addWidget(self.stream_btn)
        inburn_layout.addLayout(inburn_depth_layout)
        inburn_group.setLayout(inburn_layout)
        
        # Output options
        output_group = QGroupBox("Utdatainställningar")
        output_layout = QVBoxLayout()
        
        self.erosion_checkbox = QCheckBox("Beräkna erosion")
        self.flow_checkbox = QCheckBox("Visa flödespilar")
        self.streamline_checkbox = QCheckBox("Visa streamlines")
        self.log_checkbox = QCheckBox("Skapa loggfil")
        
        output_layout.addWidget(self.erosion_checkbox)
        output_layout.addWidget(self.flow_checkbox)
        output_layout.addWidget(self.streamline_checkbox)
        output_layout.addWidget(self.log_checkbox)
        
        try:
            self.timelapse_checkbox = QCheckBox("Simulera över tid (volymbevarande)")
            self.animation_checkbox = QCheckBox("Visa animation efter simulering")
            anim_layout = QHBoxLayout()
            anim_layout.addWidget(self.timelapse_checkbox)
            anim_layout.addWidget(self.animation_checkbox)
            output_layout.addLayout(anim_layout)
            self.hillshade_checkbox = QCheckBox("Visa hillshade (lutningsskuggning)")
            output_layout.addWidget(self.hillshade_checkbox)
            
            # Time simulation settings
            time_group = QGroupBox("Tidssimuleringsinställningar")
            time_layout = QVBoxLayout()
            
            # Simulation duration
            duration_layout = QHBoxLayout()
            duration_layout.addWidget(QLabel("Simuleringstid (timmar):"))
            self.simulation_duration = QLineEdit("24")
            self.simulation_duration.setMaximumWidth(80)
            self.simulation_duration.setToolTip("Total simuleringstid i timmar (t.ex. 24 för en dags simulering)")
            duration_layout.addWidget(self.simulation_duration)
            duration_layout.addStretch()
            
            # Output frequency
            output_layout_freq = QHBoxLayout()
            output_layout_freq.addWidget(QLabel("Antal utgående tidssteg:"))
            self.output_timesteps = QLineEdit("10")
            self.output_timesteps.setMaximumWidth(80)
            self.output_timesteps.setToolTip("Antal tidssteg att spara (t.ex. 10 för att spara var 2.4:e timme över 24 timmar)")
            output_layout_freq.addWidget(self.output_timesteps)
            output_layout_freq.addStretch()
            
            # Output interval calculation display
            self.output_interval_label = QLabel("Utskriftsintervall: 2.4 timmar")
            self.output_interval_label.setStyleSheet("color: #666; font-style: italic;")
            
            time_layout.addLayout(duration_layout)
            time_layout.addLayout(output_layout_freq)
            time_layout.addWidget(self.output_interval_label)
            time_group.setLayout(time_layout)
            
            output_layout.addWidget(time_group)
            
            # Hydrograph input group
            hydrograph_group = QGroupBox("Hydrograph Input (Dynamic Flow)")
            hydrograph_layout = QVBoxLayout()
            
            # Enable hydrograph checkbox
            self.hydrograph_checkbox = QCheckBox("Use hydrograph data (time-varying flow)")
            self.hydrograph_checkbox.setToolTip("Enable to use time-varying flow data instead of constant flow")
            hydrograph_layout.addWidget(self.hydrograph_checkbox)
            
            # Hydrograph file selection
            hydrograph_file_layout = QHBoxLayout()
            hydrograph_file_layout.addWidget(QLabel("Hydrograph file:"))
            self.hydrograph_path = QLineEdit()
            self.hydrograph_path.setPlaceholderText("Select CSV file with time, flow columns...")
            self.hydrograph_path.setEnabled(False)
            hydrograph_file_layout.addWidget(self.hydrograph_path)
            self.hydrograph_btn = QPushButton("Browse...")
            self.hydrograph_btn.setEnabled(False)
            hydrograph_file_layout.addWidget(self.hydrograph_btn)
            hydrograph_layout.addLayout(hydrograph_file_layout)
            
            # Column selection for hydrograph
            hydrograph_cols_layout = QHBoxLayout()
            hydrograph_cols_layout.addWidget(QLabel("Time column:"))
            self.hydrograph_time_col = QComboBox()
            self.hydrograph_time_col.setEnabled(False)
            hydrograph_cols_layout.addWidget(self.hydrograph_time_col)
            hydrograph_cols_layout.addWidget(QLabel("Flow column:"))
            self.hydrograph_flow_col = QComboBox()
            self.hydrograph_flow_col.setEnabled(False)
            hydrograph_cols_layout.addWidget(self.hydrograph_flow_col)
            hydrograph_layout.addLayout(hydrograph_cols_layout)
            
            # Hydrograph preview
            self.hydrograph_preview = QLabel("No hydrograph loaded")
            self.hydrograph_preview.setStyleSheet("color: #666; font-style: italic; padding: 5px; border: 1px solid #ccc;")
            hydrograph_layout.addWidget(self.hydrograph_preview)
            
            hydrograph_group.setLayout(hydrograph_layout)
            output_layout.addWidget(hydrograph_group)
            
        except:
            pass
            
        output_group.setLayout(output_layout)
        
        # Lägg till alla grupper till advanced tab
        advanced_layout.addWidget(soil_group)
        advanced_layout.addWidget(inburn_group)
        advanced_layout.addWidget(output_group)
        advanced_layout.addStretch()
        
        self.advanced_tab.setLayout(advanced_layout)
        
        # Lägg till tabs till tabwidget
        self.tab_widget.addTab(self.basic_tab, "Basic")
        self.tab_widget.addTab(self.advanced_tab, "Advanced")
        
        # Add tab widget to main layout
        main_layout.addWidget(self.tab_widget)
        
        # Run button and progress bar
        bottom_layout = QVBoxLayout()
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        
        self.run_button = QPushButton("Kör modell")
        self.progress_bar = QProgressBar()
        self.progress_bar.setMinimum(0)
        self.progress_bar.setMaximum(100)
        self.progress_bar.setValue(0)
        bottom_layout.addWidget(self.progress_bar)
        self.run_button.setFont(QFont("Arial", 12, QFont.Bold))
        self.run_button.setMinimumHeight(40)
        
        bottom_layout.addWidget(self.progress_bar)
        bottom_layout.addWidget(self.run_button)
        
        main_layout.addLayout(bottom_layout)
        
        # Set layout
        self.main_widget = QWidget()
        self.main_widget.setLayout(main_layout)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(self.main_widget)
        scroll_layout = QVBoxLayout()
        title_label = QLabel("<b>FloodEngine</b>")
        title_label.setAlignment(Qt.AlignCenter)
        scroll_layout.addWidget(title_label)
        scroll_layout.addWidget(scroll)
        self.setLayout(scroll_layout)
        
        # Uppdatera titelfont
        font = QFont("Arial", 12, QFont.Bold)
        self.setFont(font)
        
        # Lägg till Q-baserad sektion
        self.q_group = QGroupBox("Q-baserad hydraulik", self)
        self.q_group.setGeometry(10, 300, 380, 100)
        self.q_label = QLabel("Flöde (Q) [m³/s]", self.q_group)
        self.q_label.setGeometry(10, 20, 120, 25)
        self.q_input = QLineEdit(self.q_group)
        self.q_input.setGeometry(140, 20, 80, 25)
        self.q_btn = QPushButton("Beräkna vattennivå", self.q_group)
        self.q_btn.setGeometry(230, 20, 130, 25)
        self.q_report_btn = QPushButton("Q-baserad rapport", self.q_group)
        self.q_report_btn.setGeometry(10, 60, 180, 25)
        # Lägg till Q-baserade knappar
        self.q_erosion_btn = QtWidgets.QPushButton("Q-baserad erosionsrisk", self.q_group)
        self.q_erosion_btn.setGeometry(QtCore.QRect(200, 60, 170, 25))
        self.q_meander_btn = QtWidgets.QPushButton("Q-baserad meander/får", self.q_group)
        self.q_meander_btn.setGeometry(QtCore.QRect(10, 90, 170, 25))
        self.q_retention_btn = QtWidgets.QPushButton("Q-baserad retention", self.q_group)
        self.q_retention_btn.setGeometry(QtCore.QRect(200, 90, 170, 25))
        
    def connect_signals(self):
        """Koppla signaler och slots för UI-interaktioner"""
        try:
            # File selection
            self.dem_btn.clicked.connect(lambda: self.select_file(self.dem_path, "Rasterfiler (*.tif *.asc)"))
            self.bathy_btn.clicked.connect(lambda: self.select_file(self.bathy_path, "CSV-filer (*.csv)"))
            self.soil_btn.clicked.connect(lambda: self.select_file(self.soil_path, "Shape-filer (*.shp)"))
            self.stream_btn.clicked.connect(lambda: self.select_file(self.stream_path, "Shape-filer (*.shp)"))
            
            # Mode toggle
            self.basic_radio.toggled.connect(self.toggle_mode)
            self.advanced_radio.toggled.connect(self.toggle_mode)
            
            # Connect hydrograph controls
            if hasattr(self, 'hydrograph_checkbox'):
                self.hydrograph_checkbox.toggled.connect(self.toggle_hydrograph_controls)
            if hasattr(self, 'hydrograph_btn'):
                self.hydrograph_btn.clicked.connect(lambda: self.select_hydrograph_file())
            
            # Connect timestep controls for real-time updates
            if hasattr(self, 'simulation_duration'):
                self.simulation_duration.textChanged.connect(self.update_output_interval)
            if hasattr(self, 'output_timesteps'):
                self.output_timesteps.textChanged.connect(self.update_output_interval)
            
            # Inbränningsdjup
            self.inburn_depth_slider.valueChanged.connect(self.update_inburn_depth)
            self.inburn_depth_input.textChanged.connect(self.update_inburn_slider)
            
            # Vattennivå slider
            self.water_level_slider.valueChanged.connect(self.update_water_level)
            self.water_level.textChanged.connect(self.update_water_slider)
            
            # Run button
            self.run_button.clicked.connect(self.run_model)
            
            # Dark mode toggle
            self.dark_mode_checkbox.toggled.connect(self.toggle_dark_mode)
            
            # Bathymetry file selection updated
            self.bathy_path.textChanged.connect(self.update_bathy_columns)
            
            # Timestep controls - update interval calculation when values change
            try:
                self.simulation_duration.textChanged.connect(self.update_output_interval)
                self.output_timesteps.textChanged.connect(self.update_output_interval)
            except:
                pass
            
            # Koppla knappar till slots (signaler)
            self.q_btn.clicked.connect(self.calculate_water_level_from_q)
            self.q_report_btn.clicked.connect(self.generate_q_report)
            self.q_erosion_btn.clicked.connect(self.parent().calculate_q_erosion_risk)
            self.q_meander_btn.clicked.connect(self.parent().q_meander_tool)
            self.q_retention_btn.clicked.connect(self.parent().q_retention_tool)
            
            # Hydrograph signals
            self.hydrograph_checkbox.toggled.connect(self.toggle_hydrograph_controls)
            self.hydrograph_btn.clicked.connect(lambda: self.select_file(self.hydrograph_path, "CSV-filer (*.csv)"))
            self.hydrograph_path.textChanged.connect(self.update_hydrograph_columns)
        except Exception as e:
            self.logger.error(f"Fel vid kopplingen av signaler: {str(e)}")
            # Om något fel uppstår vid signalhantering fortsätter programmet
            pass
    
    def update_bathy_columns(self):
        """Uppdatera kolumnvärden för bathymetri när en ny fil väljs"""
        try:
            path = self.bathy_path.text()
            if os.path.exists(path):
                # Försök läsa kolumnnamn från CSV-filen
                with open(path, 'r') as f:
                    try:
                        # Försök identifiera separator
                        sample = f.read(1024)
                        f.seek(0)
                        
                        try:
                            # Gissa separator (komma, semikolon, tab)
                            dialect = csv.Sniffer().sniff(sample, delimiters=',;\t')
                            reader = csv.reader(f, dialect)
                        except:
                            # Om vi inte kan gissa dialekt, använd standardkomma
                            reader = csv.reader(f)
                        
                        header = next(reader)  # Läs första raden som header
                        
                        # Rensa befintliga värden
                        self.bathy_x_col.clear()
                        self.bathy_y_col.clear()
                        self.bathy_z_col.clear()
                        
                        # Lägg till kolumnnamn
                        for col in header:
                            col = col.strip()  # Ta bort eventuella mellanslag
                            self.bathy_x_col.addItem(col)
                            self.bathy_y_col.addItem(col)
                            self.bathy_z_col.addItem(col)
                        
                        # Försök gissa kolumnnamn (X, Y, Z eller liknande)
                        for i, col in enumerate(header):
                            col_lower = col.lower().strip()
                            
                            # X-kolumnnamn
                            if col_lower in ['x', 'east', 'easting', 'lon', 'longitude', 'e', 'x-koordinat', 'xcoord']:
                                self.bathy_x_col.setCurrentIndex(i)
                            
                            # Y-kolumnnamn
                            if col_lower in ['y', 'north', 'northing', 'lat', 'latitude', 'n', 'y-koordinat', 'ycoord']:
                                self.bathy_y_col.setCurrentIndex(i)
                            
                            # Z-kolumnnamn
                            if col_lower in ['z', 'depth', 'djup', 'elevation', 'höjd', 'elev', 'level']:
                                self.bathy_z_col.setCurrentIndex(i)
                    
                    except Exception as e:
                        self.logger.error(f"Fel vid läsning av CSV-header: {str(e)}")
        except Exception as e:
            self.logger.error(f"Fel vid uppdatering av bathymetrikolumner: {str(e)}")
    
    def update_output_interval(self):
        """Update the output interval label when duration or timesteps change"""
        try:
            duration = float(self.simulation_duration.text())
            timesteps = int(self.output_timesteps.text())
            
            if duration > 0 and timesteps > 0:
                interval = duration / timesteps
                if hasattr(self, 'output_interval_label'):
                    if interval >= 1.0:
                        self.output_interval_label.setText(f"Utskriftsintervall: {interval:.1f} timmar")
                    else:
                        minutes = interval * 60
                        self.output_interval_label.setText(f"Utskriftsintervall: {minutes:.1f} minuter")
        except (ValueError, ZeroDivisionError):
            if hasattr(self, 'output_interval_label'):
                self.output_interval_label.setText("Utskriftsintervall: Kontrollera värden")
        except Exception as e:
            self.logger.error(f"Fel vid uppdatering av utskriftsintervall: {str(e)}")
    
    def toggle_hydrograph_controls(self, checked):
        """Enable/disable hydrograph controls based on checkbox state"""
        if hasattr(self, 'hydrograph_path'):
            self.hydrograph_path.setEnabled(checked)
        if hasattr(self, 'hydrograph_btn'):
            self.hydrograph_btn.setEnabled(checked)
        if hasattr(self, 'hydrograph_time_col'):
            self.hydrograph_time_col.setEnabled(checked)
        if hasattr(self, 'hydrograph_flow_col'):
            self.hydrograph_flow_col.setEnabled(checked)
    
    def select_hydrograph_file(self):
        """Select and load hydrograph file"""
        path, _ = QFileDialog.getOpenFileName(self, "Select Hydrograph File", "", "CSV files (*.csv);;All files (*)")
        if path:
            self.hydrograph_path.setText(path)
            self.load_hydrograph_preview(path)
    
    def load_hydrograph_preview(self, csv_path):
        """Load and preview hydrograph data"""
        try:
            # Clear existing column options
            self.hydrograph_time_col.clear()
            self.hydrograph_flow_col.clear()
            
            # Read CSV header
            with open(csv_path, 'r', newline='', encoding='utf-8') as csvfile:
                sample = csvfile.read(1024)
                csvfile.seek(0)
                sniffer = csv.Sniffer()
                delimiter = sniffer.sniff(sample).delimiter
                
                reader = csv.reader(csvfile, delimiter=delimiter)
                headers = next(reader)
                
                # Populate column dropdowns
                self.hydrograph_time_col.addItems(headers)
                self.hydrograph_flow_col.addItems(headers)
                
                # Auto-detect time and flow columns
                for i, header in enumerate(headers):
                    header_lower = header.lower()
                    if any(keyword in header_lower for keyword in ['time', 'hour', 'hr', 'h', 'tid', 'timme']):
                        self.hydrograph_time_col.setCurrentIndex(i)
                    elif any(keyword in header_lower for keyword in ['flow', 'q', 'discharge', 'flöde']):
                        self.hydrograph_flow_col.setCurrentIndex(i)
                
                # Read first few rows for preview
                csvfile.seek(0)
                reader = csv.reader(csvfile, delimiter=delimiter)
                next(reader)  # Skip header
                
                preview_data = []
                for i, row in enumerate(reader):
                    if i >= 5:  # Only show first 5 rows
                        break
                    preview_data.append(row)
                
                # Update preview
                if preview_data:
                    preview_text = f"Loaded {len(headers)} columns, {len(preview_data)}+ rows\n"
                    preview_text += f"Sample: {', '.join(preview_data[0][:3])}..."
                    self.hydrograph_preview.setText(preview_text)
                else:
                    self.hydrograph_preview.setText("Empty file")
                    
        except Exception as e:
            self.hydrograph_preview.setText(f"Error loading file: {str(e)}")
            self.logger.error(f"Error loading hydrograph file: {str(e)}")
    
    def get_hydrograph_data(self):
        """Extract hydrograph data from CSV file - FIXED VERSION"""
        if not hasattr(self, 'hydrograph_checkbox') or not self.hydrograph_checkbox.isChecked():
            return None
        
        if not hasattr(self, 'hydrograph_path') or not self.hydrograph_path.text():
            print("DEBUG: Hydrograph path is empty")
            return None
        
        try:
            csv_path = self.hydrograph_path.text()
            
            if not os.path.exists(csv_path):
                print(f"DEBUG: Hydrograph file does not exist: {csv_path}")
                return None
                
            time_col = self.hydrograph_time_col.currentText()
            flow_col = self.hydrograph_flow_col.currentText()
            
            if not time_col or not flow_col:
                print(f"DEBUG: Missing column selections - Time: {time_col}, Flow: {flow_col}")
                return None
            
            print(f"DEBUG: Reading hydrograph from {csv_path}, columns: {time_col}, {flow_col}")
            
            # Read CSV data with better error handling
            import csv
            
            with open(csv_path, 'r', newline='', encoding='utf-8') as csvfile:
                # Detect delimiter
                sample = csvfile.read(1024)
                csvfile.seek(0)
                sniffer = csv.Sniffer()
                try:
                    delimiter = sniffer.sniff(sample).delimiter
                except:
                    delimiter = ','  # Default fallback
                
                reader = csv.DictReader(csvfile, delimiter=delimiter)
                
                time_data = []
                flow_data = []
                errors = 0
                
                for row_num, row in enumerate(reader):
                    try:
                        if time_col not in row or flow_col not in row:
                            print(f"DEBUG: Row {row_num}: Missing columns in row")
                            continue
                            
                        time_val = float(row[time_col].strip())
                        flow_val = float(row[flow_col].strip())
                        
                        time_data.append(time_val)
                        flow_data.append(flow_val)
                        
                    except (ValueError, KeyError) as e:
                        errors += 1
                        if errors <= 5:  # Only print first 5 errors
                            print(f"DEBUG: Row {row_num}: Error parsing data - {e}")
                        continue
                
                if time_data and flow_data:
                    # Sort by time to ensure proper order
                    combined = list(zip(time_data, flow_data))
                    combined.sort(key=lambda x: x[0])
                    time_data, flow_data = zip(*combined)
                    
                    hydrograph_data = {
                        'time': list(time_data),
                        'flow': list(flow_data),
                        'time_units': 'hours',
                        'flow_units': 'm³/s'
                    }
                    
                    print(f"DEBUG: Successfully loaded {len(time_data)} hydrograph points")
                    print(f"DEBUG: Time range: {min(time_data):.1f} to {max(time_data):.1f} hours")
                    print(f"DEBUG: Flow range: {min(flow_data):.1f} to {max(flow_data):.1f} m³/s")
                    
                    if errors > 0:
                        print(f"DEBUG: Skipped {errors} rows due to parsing errors")
                        
                    return hydrograph_data
                else:
                    print("DEBUG: No valid data points found in hydrograph file")
                    return None
                        
        except Exception as e:
            print(f"ERROR: Error reading hydrograph data: {str(e)}")
            import traceback
            traceback.print_exc()
            return None
    
    def validate_inputs(self):
        """Validera alla indata innan modellen körs
        
        :returns: Om valideringen lyckades
        :rtype: bool
        """
        if not self.dem_path.text():
            QMessageBox.warning(self, "Saknar indata", "Du måste ange en DEM-fil!")
            return False
            
        try:
            water_level = float(self.water_level.text())
            if water_level <= 0 or water_level > 100:
                QMessageBox.warning(self, "Ogiltig vattennivå", "Vattennivån måste vara mellan 0 och 100 meter!")
                return False
        except ValueError:
            QMessageBox.warning(self, "Ogiltig vattennivå", "Vattennivån måste vara ett numeriskt värde!")
            return False
            
        # Kontrollera inbränning
        if self.inburn_checkbox.isChecked() and not self.stream_path.text():
            QMessageBox.warning(self, "Saknar indata", "Du har aktiverat inbränning men inte angett något vattendragslager!")
            return False
            
        # Kontrollera erosion
        if self.erosion_checkbox.isChecked() and not self.soil_path.text():
            QMessageBox.warning(self, "Saknar indata", "Du har aktiverat erosionsberäkning men inte angett något jordartslager!")
            return False
            
        return True
    
    def run_model(self):
        """Kör den hydrauliska modellen"""
        if not self.validate_inputs():
            return
            
        # Aktivera progressbar
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        
        # Läs indata
        try:
            dem_path = self.dem_path.text()
            water_level = float(self.water_level.text())
            flow_q_text = self.flow_q.text().strip()
            try:
                flow_q = float(flow_q_text) if flow_q_text else None
            except ValueError:
                flow_q = None
            print(f"DEBUG: Startar run_model med dem_path={dem_path}, water_level={water_level}, flow_q={flow_q}")
            self.logger.info(f"DEBUG: Startar run_model med dem_path={dem_path}, water_level={water_level}, flow_q={flow_q}")
            
            # Säkerställ korrekt sökväg för output
            output_folder = os.path.normpath(r"C:\Users\david\OneDrive\Dokument\GIS\FloodEngine\VSCode\output")
            os.makedirs(output_folder, exist_ok=True)
            
            if not isinstance(dem_path, (str, bytes, os.PathLike)):
                raise TypeError(f"dem_path måste vara en filväg (str), fick {type(dem_path)}")
            if not isinstance(output_folder, (str, bytes, os.PathLike)):
                raise TypeError(f"output_folder måste vara en filväg (str), fick {type(output_folder)}")
            
            # Kolla om bathymetri används - använd den nya TIN-funktionen
            bathymetry = None
            combined_dem = dem_path  # Standard: använd original DEM om ingen bathymetri
            if self.bathy_path.text():
                self.progress_bar.setValue(10)
                self.logger.info(f"Laddar bathymetri från {self.bathy_path.text()}")
                print(f"DEBUG: Laddar bathymetri från {self.bathy_path.text()}")
                try:
                    x_col = self.bathy_x_col.currentText()
                    y_col = self.bathy_y_col.currentText()
                    z_col = self.bathy_z_col.currentText()
                    bathymetry = load_bathymetry(self.bathy_path.text(), x_col, y_col, z_col, output_folder)
                    self.logger.info(f"Skapar TIN från bathymetri och kombinerar med DEM...")
                    print(f"DEBUG: Skapar TIN från bathymetri och kombinerar med DEM...")
                    from .model_hydraulic import load_bathymetry_as_tin
                    combined_dem = load_bathymetry_as_tin(
                        self.bathy_path.text(),
                        x_col, y_col, z_col,
                        output_folder,
                        dem_path
                    )
                    self.logger.info(f"Skapad kombinerad DEM med bathymetri: {combined_dem}")
                    print(f"DEBUG: Skapad kombinerad DEM med bathymetri: {combined_dem}")
                    dem_path = combined_dem
                except Exception as e:
                    print(f"FEL vid bathymetri/TIN-inläsning: {str(e)}")
                    QMessageBox.warning(self, "Fel vid laddning av bathymetri", str(e))
                    self.logger.error(f"Fel vid laddning av bathymetri: {str(e)}")
            
            # Kör inbränning om aktiverat
            burned_dem = dem_path
            if self.inburn_checkbox.isChecked() and self.stream_path.text():
                self.progress_bar.setValue(20)
                self.logger.info(f"Utför inbränning med {self.stream_path.text()}")
                depth = int(self.inburn_depth_input.text())
                burned_dem = burn_streams(dem_path, self.stream_path.text(), depth, output_folder)
            
            # Kolla om tidssimulering ska köras
            if hasattr(self, 'timelapse_checkbox') and self.timelapse_checkbox.isChecked():
                self.progress_bar.setValue(30)
                
                # Read timestep parameters from UI
                try:
                    simulation_duration_hours = float(self.simulation_duration.text())
                    output_timesteps = int(self.output_timesteps.text())
                except (ValueError, AttributeError):
                    # Fallback to defaults if UI controls don't exist or have invalid values
                    simulation_duration_hours = 24
                    output_timesteps = 10
                
                self.logger.info(f"Kör förbättrad tidssimulering: {simulation_duration_hours}h över {output_timesteps} tidssteg")
                
                # Calculate output interval for proper timestep handling
                output_interval_hours = simulation_duration_hours / output_timesteps
                
                # Use the new enhanced calculate_flood_area with proper timestep handling
                flood_layers = calculate_flood_area(
                    self.iface,
                    burned_dem,
                    water_levels=None,  # Let the function generate appropriate levels
                    output_folder=output_folder,
                    flow_q=flow_q,
                    manning_n=0.035,  # Default Manning's n
                    simulation_duration_hours=simulation_duration_hours,
                    output_timesteps=output_timesteps,
                    output_interval_hours=output_interval_hours  # Add missing parameter
                )
                
                # Show completion message
                output_interval = simulation_duration_hours / output_timesteps
                QMessageBox.information(self, "Tidssimulering slutförd", 
                                         f"Den förbättrade tidssimuleringen har körts framgångsrikt!\n\n"
                                         f"📊 Simuleringstid: {simulation_duration_hours} timmar\n"
                                         f"🔄 Antal tidssteg: {output_timesteps}\n"
                                         f"⏱️ Utskriftsintervall: {output_interval:.1f} timmar\n\n"
                                         f"Resultaten sparades i:\n{output_folder}\n\n"
                                         f"Alla tidssteg visas som lager med realistiska vattennivåer.")
                
                # Visa animation om boxen är ikryssad
                if hasattr(self, 'animation_checkbox') and self.animation_checkbox.isChecked():
                    self.show_animation_popup()
                
                # Återställ progress bar
                self.progress_bar.setVisible(False)
            
            # Beräkna översvämning med den nya förbättrade timestep-systemet
            self.progress_bar.setValue(30)
            
            # Read timestep parameters from UI - ALWAYS use the new system
            try:
                simulation_duration_hours = float(self.simulation_duration.text())
                output_timesteps = int(self.output_timesteps.text())
            except (ValueError, AttributeError):
                # Fallback to defaults if UI controls don't exist or have invalid values
                simulation_duration_hours = 24
                output_timesteps = 10
            
            # Get Manning's n from UI or use default
            try:
                manning_n = float(self.adv_manning_n.text()) if hasattr(self, 'adv_manning_n') and self.adv_manning_n.text() else 0.035
            except:
                manning_n = 0.035
            
            # Get hydrograph data if enabled
            hydrograph_data = self.get_hydrograph_data()
            if hydrograph_data:
                self.logger.info(f"Kör förbättrad översvämningssimulering med hydrograph: {simulation_duration_hours}h över {output_timesteps} tidssteg med Manning's n={manning_n}")
                self.logger.info(f"Hydrograph data: {len(hydrograph_data['time'])} tidspunkter, flöde varierar från {min(hydrograph_data['flow']):.1f} till {max(hydrograph_data['flow']):.1f} m³/s")
            else:
                self.logger.info(f"Kör förbättrad översvämningssimulering: {simulation_duration_hours}h över {output_timesteps} tidssteg med Manning's n={manning_n}")
            
            try:
                # Calculate output interval for proper timestep handling
                output_interval_hours = simulation_duration_hours / output_timesteps
                
                # Use the new enhanced calculate_flood_area with proper timestep handling
                flood_layers = calculate_flood_area(
                    self.iface,
                    burned_dem,
                    water_levels=None,  # Let the function generate REALISTIC levels based on DEM
                    output_folder=output_folder,
                    flow_q=flow_q,
                    manning_n=manning_n,
                    simulation_duration_hours=simulation_duration_hours,  # Keep as float
                    output_timesteps=output_timesteps,
                    output_interval_hours=output_interval_hours,  # Add missing parameter
                    hydrograph_data=hydrograph_data  # Pass hydrograph data
                )
                
                # Log successful call
                self.logger.info("Förbättrad calculate_flood_area anropades framgångsrikt")
                
            except Exception as e:
                self.logger.error(f"Fel vid anrop av förbättrad calculate_flood_area: {str(e)}")
                # Show error to user
                QMessageBox.critical(self, "Simuleringsfel", 
                                   f"Fel vid översvämningssimulering:\n{str(e)}\n\n"
                                   f"Kontrollera att DEM-filen är korrekt och att det finns låglänta områden att översvämma.")
                self.progress_bar.setVisible(False)
                return
            
            # Define output_name variable for consistent naming across functions
            output_name = f"flood_{simulation_duration_hours}h_{output_timesteps}steps"
            
            # Samla resultatlag för meddelande  
            result_layers = [f"- Översvämningslager: {len(flood_layers)} tidssteg skapade"]
            
            # Beräkna erosion om aktiverat (use first flood layer as reference)
            if self.erosion_checkbox.isChecked() and self.soil_path.text() and flood_layers:
                self.progress_bar.setValue(60)
                self.logger.info(f"Beräknar erosionsrisk med {self.soil_path.text()}")
                try:
                    erosion_layer = calculate_erosion(self.iface, burned_dem, flood_layers[0], self.soil_path.text(), output_folder)
                    result_layers.append(f"- Erosionslager: erosionsrisk.shp")
                except Exception as e:
                    self.logger.warning(f"Kunde inte beräkna erosion: {str(e)}")
                
            # Skapa flödespilar om aktiverat (use first flood layer as reference)
            if self.flow_checkbox.isChecked() and flood_layers:
                self.progress_bar.setValue(80)
                self.logger.info("Beräknar flödesvektorer")
                try:
                    flow_layer = calculate_flow_vectors(self.iface, burned_dem, flood_layers[0], output_folder)
                    result_layers.append(f"- Flödespilar: flödespilar.shp")
                except Exception as e:
                    self.logger.warning(f"Kunde inte skapa flödespilar: {str(e)}")
                
            # Streamlines skapas automatiskt av det nya systemet
            if self.streamline_checkbox.isChecked():
                result_layers.append(f"- Streamlines: Skapade automatiskt för alla tidssteg")
                
            # Spara logg om aktiverat
            if self.log_checkbox.isChecked():
                log_output = os.path.join(output_folder, output_name + "_log.txt")
                with open(self.log_file, 'r') as src, open(log_output, 'w') as dst:
                    dst.write(src.read())
                result_layers.append(f"- Loggfil: {output_name}_log.txt")
                    
            self.progress_bar.setValue(100)
            
            # Visa meddelande om slutfört
            QMessageBox.information(self, "Modellkörning slutförd", 
                                     f"Modellen har körts och genererat följande filer i:\n{output_folder}\n\n" + "\n".join(result_layers))
            
            # Zooma till resultat
            if flood_layers:
                self.canvas.setExtent(flood_layers[0].extent())
                self.canvas.refresh()
            
        except Exception as e:
            self.logger.error(f"Fel vid modellkörning: {str(e)}")
            self.logger.error(traceback.format_exc())
            QMessageBox.critical(self, "Fel vid modellkörning", f"Ett fel inträffade: {str(e)}")
        finally:
            self.progress_bar.setVisible(False)

        # Lägg till extra loggning kring bathymetri och TIN/DEM-kombination
        if self.bathy_path.text():
            self.logger.info(f"DEBUG: Kombinerad DEM/TIN används: {dem_path}")
            if os.path.exists(dem_path):
                try:
                    # Använd GDAL istället för rasterio
                    from osgeo import gdal
                    ds = gdal.Open(dem_path)
                    if ds:
                        band = ds.GetRasterBand(1)
                        arr = band.ReadAsArray()
                        self.logger.info(f"DEBUG: DEM shape: {arr.shape}, min: {np.nanmin(arr)}, max: {np.nanmax(arr)}")
                        ds = None
                except Exception as e:
                    self.logger.error(f"Fel vid läsning av DEM med GDAL: {str(e)}")

    def show_animation_popup(self):
        # Hitta alla tidsstegslager ("Översvämning X") i projektet
        timestep_layers = [l for l in QgsProject.instance().mapLayers().values() if l.name().startswith("Översvämning ")]
        timestep_layers = sorted(timestep_layers, key=lambda l: int(l.name().split()[-1]))
        if not timestep_layers:
            QMessageBox.warning(self, "Inga tidssteg", "Inga tidsstegslager hittades i projektet.")
            return
        self.anim_dialog = AnimationDialog(self.iface, timestep_layers, self)
        self.anim_dialog.show()  # Use show() instead of exec_() for modeless dialog

class AnimationDialog(QDialog):
    def __init__(self, iface, timestep_layers, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.timestep_layers = timestep_layers
        self.current_index = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.next_frame)
        self.setWindowTitle("Tidsstegsanimation")
        self.setMinimumWidth(400)
        layout = QVBoxLayout()
        self.label = QLabel("Tidssteg: 0")
        layout.addWidget(self.label)
        self.slider = QSlider()
        self.slider.setOrientation(Qt.Horizontal)
        self.slider.setMinimum(0)
        self.slider.setMaximum(len(timestep_layers)-1)
        self.slider.valueChanged.connect(self.set_frame)
        layout.addWidget(self.slider)
        btn_layout = QHBoxLayout()
        self.play_btn = QPushButton("Spela")
        self.pause_btn = QPushButton("Paus")
        self.stop_btn = QPushButton("Stoppa")
        self.play_btn.clicked.connect(self.play)
        self.pause_btn.clicked.connect(self.pause)
        self.stop_btn.clicked.connect(self.stop)
        btn_layout.addWidget(self.play_btn)
        btn_layout.addWidget(self.pause_btn)
        btn_layout.addWidget(self.stop_btn)
        layout.addLayout(btn_layout)
        self.setLayout(layout)
        self.update_layers()
    def play(self):
        self.timer.start(500)
    def pause(self):
        self.timer.stop()
    def stop(self):
        self.timer.stop()
        self.current_index = 0
        self.slider.setValue(0)
        self.update_layers()
    def next_frame(self):
        if self.current_index < len(self.timestep_layers)-1:
            self.current_index += 1
        else:
            self.current_index = 0
        self.slider.setValue(self.current_index)
        self.update_layers()
    def set_frame(self, idx):
        self.current_index = idx
        self.update_layers()
    def update_layers(self):
        # Use the layer tree to set visibility
        root = QgsProject.instance().layerTreeRoot()
        for i, layer in enumerate(self.timestep_layers):
            node = root.findLayer(layer.id())
            if node:
                node.setItemVisibilityChecked(i == self.current_index)
        self.label.setText(f"Tidssteg: {self.current_index}")
        self.iface.mapCanvas().refresh()

        self.timelapse_threshold_label = QLabel("Tröskelvärde [m] (minsta nivå för översvämning)")
        self.timelapse_threshold_input = QLineEdit()
        self.timelapse_layout.addWidget(self.timelapse_threshold_label)
        self.timelapse_layout.addWidget(self.timelapse_threshold_input)

        self.timelapse_flow_label = QLabel("Flöde Q [m³/s] (valfritt)")
        self.timelapse_flow_input = QLineEdit()
        self.timelapse_layout.addWidget(self.timelapse_flow_label)
        self.timelapse_layout.addWidget(self.timelapse_flow_input)

        def run_timelapse_simulation():
            dem_path = self.dem_input.text()
            output_folder = self.output_input.text()
            water_level_text = self.water_level.text().strip()
            flow_q_text = self.flow_q.text().strip()
            threshold_text = self.timelapse_threshold_input.text().strip() if hasattr(self, 'timelapse_threshold_input') else ''
            steps_text = self.timelapse_steps_input.text().strip() if hasattr(self, 'timelapse_steps_input') else ''
            try:
                water_level = float(water_level_text) if water_level_text else None
            except ValueError:
                water_level = None
            try:
                flow_q = float(flow_q_text) if flow_q_text else None
            except ValueError:
                flow_q = None
            try:
                threshold = float(threshold_text) if threshold_text else None
            except ValueError:
                threshold = None
            try:
                time_steps = int(steps_text) if steps_text else 10
            except ValueError:
                time_steps = 10
            # Kör simuleringen med rätt parametrar
            try:
                # Read timestep parameters from UI
                try:
                    simulation_duration_hours = float(self.simulation_duration.text())
                    output_timesteps = int(self.output_timesteps.text())
                except (ValueError, AttributeError):
                    # Fallback to defaults if UI controls don't exist or have invalid values
                    simulation_duration_hours = 24.0
                    output_timesteps = 10
                
                # Calculate output interval for proper timestep handling
                output_interval_hours = simulation_duration_hours / output_timesteps
                
                # Use calculate_flood_area which handles timestep simulations properly
                flood_layers = calculate_flood_area(
                    self.iface,
                    dem_path,
                    water_levels=None,  # Let the function generate appropriate levels
                    output_folder=output_folder,
                    flow_q=flow_q,
                    manning_n=0.035,  # Default Manning's n
                    simulation_duration_hours=simulation_duration_hours,
                    output_timesteps=output_timesteps,
                    output_interval_hours=output_interval_hours
                )
                
                # Show completion message
                QMessageBox.information(self, "Tidssimulering slutförd", 
                                         f"Den förbättrade tidssimuleringen har körts framgångsrikt!\n\n"
                                         f"📊 Simuleringstid: {simulation_duration_hours} timmar\n"
                                         f"🔄 Antal tidssteg: {output_timesteps}\n"
                                         f"⏱️ Utskriftsintervall: {output_interval_hours:.1f} timmar\n\n"
                                         f"Resultaten sparades i:\n{output_folder}\n\n"
                                         f"Alla tidssteg visas som lager med realistiska vattennivåer.")
                
            except Exception as e:
                QMessageBox.critical(self, "Simuleringsfel", f"Fel vid tidssimulering: {str(e)}")
        self.timelapse_button.clicked.connect(run_timelapse_simulation)

