#!/usr/bin/env python3
"""
Quick test to verify the FloodEngine UI loads without runtime errors
"""

import sys
import os

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from PyQt5.QtWidgets import QApplication
    
    # Import the UI module directly
    import importlib.util
    spec = importlib.util.spec_from_file_location("floodengine_ui", "floodengine_ui.py")
    ui_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(ui_module)
    FloodEngineDialog = ui_module.FloodEngineDialog
    
    def test_ui():
        """Test that the UI can be instantiated without errors"""
        app = QApplication(sys.argv)
        
        try:
            # Create the dialog
            dialog = FloodEngineDialog()
            
            # Test that key methods exist
            assert hasattr(dialog, 'toggle_simulation_type'), "Missing toggle_simulation_type method"
            assert hasattr(dialog, 'load_csv_preview'), "Missing load_csv_preview method"
            assert hasattr(dialog, 'toggle_2d_flow_controls'), "Missing toggle_2d_flow_controls method"
            
            # Test that key UI elements exist
            assert hasattr(dialog, 'adv_enable_2d'), "Missing unified 2D flow checkbox"
            assert hasattr(dialog, 'adv_complexity'), "Missing complexity combo box"
            assert hasattr(dialog, 'water_level_radio'), "Missing water level radio button"
            assert hasattr(dialog, 'flow_q_radio'), "Missing flow Q radio button"
            
            print("✓ UI created successfully")
            print("✓ All required methods exist")
            print("✓ All required UI elements exist")
            print("✓ Signal connections should work")
            
            # Test calling the new methods
            dialog.toggle_simulation_type()
            dialog.load_csv_preview()
            dialog.toggle_2d_flow_controls(True)
            dialog.toggle_2d_flow_controls(False)
            
            print("✓ All methods callable without errors")
            print("\n🎉 SUCCESS: UI consolidation complete and functional!")
            
            return True
            
        except Exception as e:
            print(f"❌ ERROR: {str(e)}")
            import traceback
            traceback.print_exc()
            return False
        finally:
            app.quit()
    
    if __name__ == '__main__':
        success = test_ui()
        sys.exit(0 if success else 1)
        
except ImportError as e:
    print(f"❌ Import error: {str(e)}")
    print("Make sure PyQt5 is installed and floodengine_ui.py is in the same directory")
    sys.exit(1)
