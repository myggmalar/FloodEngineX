from .floodengine_ui import FloodEngineDialog

class FloodEngine:
    def __init__(self, iface):
        self.iface = iface
        self.dlg = None

    def initGui(self):
        self.dlg = FloodEngineDialog(self.iface)
        self.dlg.show()

    def unload(self):
        if self.dlg:
            self.dlg.close()
