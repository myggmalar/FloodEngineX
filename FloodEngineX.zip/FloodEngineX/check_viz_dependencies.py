#!/usr/bin/env python3
"""
Dependency checker for FloodEngine v4.0 visualization features
"""

import sys
import subprocess
import importlib

print("=" * 60)
print("FloodEngine v4.0 - Visualization Dependencies Check")
print("=" * 60)

# Core dependencies (should be available)
core_deps = ['numpy', 'matplotlib']

# Optional dependencies for advanced features
optional_deps = {
    'vtk': 'VTK for 3D visualization',
    'plotly': 'Plotly for interactive plots',
    'dash': 'Dash for web-based interfaces', 
    'openvr': 'OpenVR for VR support',
    'moderngl': 'ModernGL for GPU acceleration'
}

print("\n🔍 Checking core dependencies:")
for dep in core_deps:
    try:
        importlib.import_module(dep)
        print(f"  ✅ {dep}: Available")
    except ImportError:
        print(f"  ❌ {dep}: Missing (REQUIRED)")

print("\n🔍 Checking optional dependencies:")
available_optional = []
missing_optional = []

for dep, description in optional_deps.items():
    try:
        importlib.import_module(dep)
        print(f"  ✅ {dep}: Available - {description}")
        available_optional.append(dep)
    except ImportError:
        print(f"  ⚠️ {dep}: Missing - {description}")
        missing_optional.append(dep)

print("\n" + "=" * 60)
print("SUMMARY:")
print(f"✅ Available optional features: {len(available_optional)}")
print(f"⚠️ Missing optional features: {len(missing_optional)}")

if missing_optional:
    print("\n🔧 To install missing dependencies:")
    print("pip install", " ".join(missing_optional))

print("\n🚀 Testing basic module syntax...")
try:
    import advanced_visualization_features
    print("✅ Advanced visualization module syntax is valid")
except SyntaxError as e:
    print(f"❌ Syntax error in visualization module: {e}")
except ImportError as e:
    print(f"⚠️ Import warning (expected due to missing deps): {e}")
except Exception as e:
    print(f"❌ Unexpected error: {e}")

print("\n✨ Dependency check complete!")
