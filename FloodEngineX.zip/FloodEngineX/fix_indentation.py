with open('saint_venant_2d.py', 'r') as in_file:
    content = in_file.read()
    # Fix indentation issues
    content = content.replace('      def set_initial_condition', '    def set_initial_condition')
    content = content.replace('      def calculate_timestep', '    def calculate_timestep')
    content = content.replace('                  # Calculate slopes', '                # Calculate slopes')
    content = content.replace('                  # Update conserved', '                # Update conserved')
    content = content.replace('      # Prepare for inflow', '    # Prepare for inflow')
    content = content.replace('      # Main simulation loop', '    # Main simulation loop')
    
    with open('saint_venant_2d_fixed.py', 'w') as out_file:
        out_file.write(content)
