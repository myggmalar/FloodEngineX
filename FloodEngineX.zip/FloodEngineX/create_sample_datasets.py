"""
FloodEngine v4.0 - Sample Datasets Creator
==========================================

This script creates standardized sample datasets for FloodEngine testing and tutorials.
Generates synthetic DEM data representing common flood modeling scenarios.

Author: FloodEngine Development Team
Date: June 7, 2025
"""

import numpy as np
import os
from osgeo import gdal, osr
import sys

class SampleDatasetCreator:
    """Creates standardized sample datasets for FloodEngine tutorials."""
    
    def __init__(self, output_dir="sample_datasets"):
        """Initialize the dataset creator.
        
        Args:
            output_dir (str): Directory to save sample datasets
        """
        self.output_dir = output_dir
        self.ensure_output_directory()
    
    def ensure_output_directory(self):
        """Create output directory if it doesn't exist."""
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
            print(f"Created output directory: {self.output_dir}")
    
    def create_river_valley_dem(self, width=200, height=200, cell_size=5.0):
        """Create a synthetic river valley DEM for basic flood modeling.
        
        Args:
            width (int): DEM width in cells
            height (int): DEM height in cells
            cell_size (float): Cell size in meters
            
        Returns:
            str: Path to created DEM file
        """
        print("Creating River Valley DEM...")
        
        # Create coordinate grids
        x = np.linspace(0, width * cell_size, width)
        y = np.linspace(0, height * cell_size, height)
        X, Y = np.meshgrid(x, y)
        
        # Create a valley profile - higher elevations on sides, lower in center
        center_x = width * cell_size / 2
        center_y = height * cell_size / 2
        
        # Base elevation increases with distance from center line (river)
        distance_from_river = np.abs(X - center_x)
        base_elevation = 100 + (distance_from_river / 50) ** 1.5
        
        # Add some topographic variation
        noise = 2 * np.sin(X / 100) * np.cos(Y / 150)
        elevation = base_elevation + noise
        
        # Create a clear river channel
        river_mask = distance_from_river < 25
        elevation[river_mask] = 95 - (25 - distance_from_river[river_mask]) * 0.1
        
        # Add some elevation variation along the river (slope)
        elevation -= Y * 0.001  # 0.1% slope downstream
        
        # Save as GeoTIFF
        filename = os.path.join(self.output_dir, "river_valley_dem.tif")
        self._save_geotiff(elevation, filename, 
                          transform=(0, cell_size, 0, height * cell_size, 0, -cell_size),
                          projection="SWEREF99")
        
        # Create metadata file
        self._create_metadata_file("river_valley_dem.txt", {
            "Dataset": "River Valley DEM",
            "Description": "Synthetic river valley with clear channel for basic flood modeling",
            "Dimensions": f"{width} x {height} cells",
            "Cell Size": f"{cell_size} meters",
            "Elevation Range": f"{elevation.min():.1f} - {elevation.max():.1f} meters",
            "Coordinate System": "SWEREF99 TM (EPSG:3006)",
            "Recommended Dam Height": "2-5 meters above river level",
            "Use Case": "Basic flood modeling tutorial"
        })
        
        print(f"River Valley DEM created: {filename}")
        return filename
    
    def create_dam_break_scenario(self, width=300, height=200, cell_size=2.0):
        """Create a dam break scenario DEM with reservoir and downstream area.
        
        Args:
            width (int): DEM width in cells
            height (int): DEM height in cells
            cell_size (float): Cell size in meters
            
        Returns:
            str: Path to created DEM file
        """
        print("Creating Dam Break Scenario DEM...")
        
        # Create coordinate grids
        x = np.linspace(0, width * cell_size, width)
        y = np.linspace(0, height * cell_size, height)
        X, Y = np.meshgrid(x, y)
        
        # Create a reservoir area (upstream) and downstream valley
        dam_location = height * 0.6  # Dam at 60% down from top
        
        # Upstream (reservoir) area - relatively flat with slight slope toward dam
        upstream_mask = Y > dam_location * cell_size
        downstream_mask = Y <= dam_location * cell_size
        
        elevation = np.zeros_like(X)
        
        # Upstream area (reservoir)
        elevation[upstream_mask] = 150 + (Y[upstream_mask] - dam_location * cell_size) * 0.002
        # Add basin shape
        center_x = width * cell_size / 2
        distance_from_center = np.abs(X - center_x)
        elevation[upstream_mask] += (distance_from_center[upstream_mask] / 100) ** 2
        
        # Downstream valley
        elevation[downstream_mask] = 140 - (dam_location * cell_size - Y[downstream_mask]) * 0.01
        # Add valley shape
        elevation[downstream_mask] += (distance_from_center[downstream_mask] / 80) ** 1.5
        
        # Create dam structure
        dam_mask = (Y > (dam_location - 2) * cell_size) & (Y < (dam_location + 2) * cell_size)
        dam_center_mask = dam_mask & (distance_from_center < 50)
        elevation[dam_center_mask] = 155  # Dam crest elevation
        
        # Add some realistic terrain variation
        noise = 1.5 * np.sin(X / 80) * np.cos(Y / 120)
        elevation += noise
        
        # Save as GeoTIFF
        filename = os.path.join(self.output_dir, "dam_break_scenario.tif")
        self._save_geotiff(elevation, filename,
                          transform=(0, cell_size, 0, height * cell_size, 0, -cell_size),
                          projection="SWEREF99")
        
        # Create metadata file
        self._create_metadata_file("dam_break_scenario.txt", {
            "Dataset": "Dam Break Scenario",
            "Description": "Synthetic dam and reservoir for dam break flood modeling",
            "Dimensions": f"{width} x {height} cells",
            "Cell Size": f"{cell_size} meters",
            "Elevation Range": f"{elevation.min():.1f} - {elevation.max():.1f} meters",
            "Dam Location": f"Row {int(dam_location)} (60% downstream)",
            "Reservoir Elevation": "~150m",
            "Downstream Elevation": "~130-140m",
            "Coordinate System": "SWEREF99 TM (EPSG:3006)",
            "Use Case": "Advanced dam break modeling tutorial"
        })
        
        print(f"Dam Break Scenario DEM created: {filename}")
        return filename
    
    def create_urban_flood_dem(self, width=250, height=250, cell_size=1.0):
        """Create an urban flood scenario with buildings and drainage.
        
        Args:
            width (int): DEM width in cells
            height (int): DEM height in cells
            cell_size (float): Cell size in meters
            
        Returns:
            str: Path to created DEM file
        """
        print("Creating Urban Flood Scenario DEM...")
        
        # Create coordinate grids
        x = np.linspace(0, width * cell_size, width)
        y = np.linspace(0, height * cell_size, height)
        X, Y = np.meshgrid(x, y)
        
        # Base urban terrain with gentle slope
        elevation = 50 + X * 0.002 + Y * 0.001
        
        # Add building blocks (elevated areas)
        # Commercial district
        building_mask1 = (X > 80) & (X < 120) & (Y > 80) & (Y < 120)
        elevation[building_mask1] += 3  # 3m building height equivalent
        
        # Residential areas
        building_mask2 = (X > 140) & (X < 180) & (Y > 140) & (Y < 180)
        elevation[building_mask2] += 2  # 2m residential elevation
        
        building_mask3 = (X > 60) & (X < 90) & (Y > 160) & (Y < 190)
        elevation[building_mask3] += 2
        
        # Create drainage channels/streets (lower elevation)
        street_mask1 = (X > 45) & (X < 55) | (X > 195) & (X < 205)
        elevation[street_mask1] -= 0.5
        
        street_mask2 = (Y > 45) & (Y < 55) | (Y > 195) & (Y < 205)
        elevation[street_mask2] -= 0.5
        
        # Main drainage channel
        main_drain_mask = (X > 20) & (X < 30) & (Y > 20) & (Y < 230)
        elevation[main_drain_mask] -= 1.5
        
        # Add surface roughness
        noise = 0.2 * np.random.random((height, width))
        elevation += noise
        
        # Save as GeoTIFF
        filename = os.path.join(self.output_dir, "urban_flood_scenario.tif")
        self._save_geotiff(elevation, filename,
                          transform=(0, cell_size, 0, height * cell_size, 0, -cell_size),
                          projection="SWEREF99")
        
        # Create metadata file
        self._create_metadata_file("urban_flood_scenario.txt", {
            "Dataset": "Urban Flood Scenario",
            "Description": "Synthetic urban area with buildings and drainage for urban flood modeling",
            "Dimensions": f"{width} x {height} cells",
            "Cell Size": f"{cell_size} meter",
            "Elevation Range": f"{elevation.min():.1f} - {elevation.max():.1f} meters",
            "Features": "Buildings, streets, drainage channels",
            "Coordinate System": "SWEREF99 TM (EPSG:3006)",
            "Recommended Water Source": "Precipitation input or upstream inflow",
            "Use Case": "Urban flood modeling and drainage analysis"
        })
        
        print(f"Urban Flood Scenario DEM created: {filename}")
        return filename
    
    def _save_geotiff(self, array, filename, transform, projection="SWEREF99"):
        """Save numpy array as GeoTIFF with proper georeferencing.
        
        Args:
            array (np.ndarray): Elevation data
            filename (str): Output filename
            transform (tuple): GDAL geotransform
            projection (str): Coordinate system
        """
        height, width = array.shape
        
        # Create GeoTIFF driver
        driver = gdal.GetDriverByName('GTiff')
        
        # Create dataset
        dataset = driver.Create(filename, width, height, 1, gdal.GDT_Float32,
                               options=['COMPRESS=LZW', 'TILED=YES'])
        
        # Set geotransform
        dataset.SetGeoTransform(transform)
        
        # Set projection
        srs = osr.SpatialReference()
        if projection == "SWEREF99":
            srs.ImportFromEPSG(3006)  # SWEREF99 TM
        else:
            srs.ImportFromEPSG(4326)  # WGS84
        dataset.SetProjection(srs.ExportToWkt())
        
        # Write data
        band = dataset.GetRasterBand(1)
        band.WriteArray(array)
        band.SetNoDataValue(-9999)
        
        # Close dataset
        dataset = None
        
    def _create_metadata_file(self, filename, metadata):
        """Create a metadata text file for the dataset.
        
        Args:
            filename (str): Metadata filename
            metadata (dict): Metadata key-value pairs
        """
        filepath = os.path.join(self.output_dir, filename)
        with open(filepath, 'w') as f:
            f.write("FloodEngine Sample Dataset Metadata\n")
            f.write("=" * 40 + "\n\n")
            for key, value in metadata.items():
                f.write(f"{key}: {value}\n")
            f.write(f"\nGenerated: {__import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    def create_all_samples(self):
        """Create all sample datasets."""
        print("Creating FloodEngine Sample Datasets...")
        print("=" * 50)
        
        datasets = []
        
        # Create sample datasets
        datasets.append(self.create_river_valley_dem())
        datasets.append(self.create_dam_break_scenario())
        datasets.append(self.create_urban_flood_dem())
        
        # Create comprehensive README
        self._create_sample_readme(datasets)
        
        print("\n" + "=" * 50)
        print("Sample dataset creation completed!")
        print(f"All datasets saved to: {os.path.abspath(self.output_dir)}")
        return datasets
    
    def _create_sample_readme(self, datasets):
        """Create comprehensive README for sample datasets."""
        readme_path = os.path.join(self.output_dir, "README.md")
        
        with open(readme_path, 'w') as f:
            f.write("""# FloodEngine Sample Datasets

## Overview
This directory contains sample datasets for FloodEngine v4.0 tutorials and testing.

## Available Datasets

### 1. River Valley DEM (`river_valley_dem.tif`)
- **Use Case**: Basic flood modeling tutorial
- **Features**: Simple river channel with surrounding valley
- **Recommended Dam Height**: 2-5 meters above river level
- **Tutorial**: Basic FloodEngine workflow

### 2. Dam Break Scenario (`dam_break_scenario.tif`)
- **Use Case**: Advanced dam break modeling
- **Features**: Reservoir, dam structure, downstream valley
- **Dam Location**: 60% downstream from top
- **Tutorial**: Dam failure analysis

### 3. Urban Flood Scenario (`urban_flood_scenario.tif`)
- **Use Case**: Urban flood modeling
- **Features**: Buildings, streets, drainage channels
- **Recommended Input**: Precipitation or upstream inflow
- **Tutorial**: Urban drainage analysis

## Usage Instructions

1. **Load DEM**: Import any .tif file into QGIS
2. **Run FloodEngine**: Use Plugins > FloodEngine menu
3. **Set Parameters**: Configure water level and simulation settings
4. **Analyze Results**: Review flood extent and depth maps

## Coordinate System
All datasets use SWEREF99 TM (EPSG:3006) coordinate system.

## Technical Specifications
- **Format**: GeoTIFF with LZW compression
- **Data Type**: 32-bit floating point
- **NoData Value**: -9999
- **Cell Sizes**: 1-5 meters depending on dataset

## Support
For tutorials and documentation, see `COMPREHENSIVE_USER_GUIDE.md` in the main plugin directory.

Generated: """ + __import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

def main():
    """Main function to create sample datasets."""
    print("FloodEngine Sample Dataset Creator")
    print("=" * 40)
    
    try:
        creator = SampleDatasetCreator()
        datasets = creator.create_all_samples()
        
        print(f"\nSuccessfully created {len(datasets)} sample datasets:")
        for dataset in datasets:
            print(f"  - {os.path.basename(dataset)}")
            
    except Exception as e:
        print(f"Error creating sample datasets: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()