#!/usr/bin/env python3
"""
FloodEngine Animation Controls Demo
===================================
This script demonstrates how to use the FloodEngine time series animation controls.

Usage Examples:
1. Demo with sample data:     python demo_animation_controls.py --sample
2. Load from folder:          python demo_animation_controls.py /path/to/animation/folder
3. QGIS mode (if available):  python demo_animation_controls.py --qgis /path/to/folder
4. Check dependencies:        python demo_animation_controls.py --check
"""

import os
import sys
import logging
from pathlib import Path

# Add FloodEngineX to path
script_dir = Path(__file__).parent
sys.path.insert(0, str(script_dir))

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("FloodEngine.Demo")

def check_system_requirements():
    """Check if system has required components."""
    logger.info("🔍 Checking system requirements...")
    
    requirements = {
        'numpy': False,
        'PyQt5': False,
        'GDAL': False,
        'QGIS': False
    }
    
    try:
        import numpy
        requirements['numpy'] = True
        logger.info("✅ NumPy: Available")
    except ImportError:
        logger.error("❌ NumPy: Missing (required)")
    
    try:
        from PyQt5.QtWidgets import QApplication
        requirements['PyQt5'] = True
        logger.info("✅ PyQt5: Available")
    except ImportError:
        logger.error("❌ PyQt5: Missing (required for GUI)")
    
    try:
        from osgeo import gdal
        requirements['GDAL'] = True
        logger.info("✅ GDAL: Available")
    except ImportError:
        logger.warning("⚠️ GDAL: Not available (limits raster functionality)")
    
    try:
        from qgis.utils import iface
        if iface is not None:
            requirements['QGIS'] = True
            logger.info("✅ QGIS: Available and active")
        else:
            logger.info("ℹ️ QGIS: Available but not active")
    except ImportError:
        logger.info("ℹ️ QGIS: Not available (standalone mode only)")
    
    return requirements

def demo_basic_usage():
    """Demonstrate basic animation controls usage."""
    logger.info("🎬 Basic Animation Controls Demo")
    
    print("""
FloodEngine Time Series Animation Controls
==========================================

The animation system provides:

1. 🎮 PLAYBACK CONTROLS
   • Play/Pause button
   • Stop button (returns to first timestep)
   • Step forward/backward buttons
   • Timeline slider for direct navigation

2. ⚙️ ANIMATION SETTINGS
   • Speed control (0.1 - 10 fps)
   • Loop animation option
   • Auto-hide non-current timesteps

3. 📍 INTERACTIVE POINT SAMPLING
   • Click on map to sample data at any location
   • View depth, elevation, and velocity at point
   • See complete time series for that location
   • Coordinate display in multiple systems

4. 📊 DATA VISUALIZATION
   • Water depth layers
   • Water surface elevation
   • Flow velocity (if available)
   • Real-time statistics

5. 🗺️ COORDINATE SYSTEMS
   • Automatic RH2000 (EPSG:3006) support
   • Map coordinate display
   • Coordinate transformation

HOW TO USE:
-----------
1. Run a FloodEngine simulation to generate time series data
2. Launch animation: python launch_animation.py [folder]
3. Use controls to navigate through timesteps
4. Click on map areas to inspect flood data
5. Export frames or data as needed

KEYBOARD SHORTCUTS:
------------------
• Spacebar: Play/Pause
• Left/Right arrows: Step through timesteps
• Home: Go to first timestep
• End: Go to last timestep
""")

def demo_with_sample_data():
    """Create and show sample animation."""
    logger.info("🧪 Creating sample animation demo...")
    
    try:
        # Check if we can create sample data
        requirements = check_system_requirements()
        if not requirements['numpy']:
            logger.error("❌ Cannot create sample data without NumPy")
            return False
        
        if not requirements['PyQt5']:
            logger.error("❌ Cannot show animation without PyQt5")
            return False
        
        # Import necessary modules
        import numpy as np
        from PyQt5.QtWidgets import QApplication
        
        # Create sample data
        logger.info("📊 Generating sample flood data...")
        
        # Simple expanding flood pattern
        nx, ny = 60, 40
        x = np.linspace(0, 600, nx)  # 600m domain
        y = np.linspace(0, 400, ny)  # 400m domain
        X, Y = np.meshgrid(x, y)
        
        # Simple bowl-shaped terrain
        dem = 10 + 0.01 * ((X - 300)**2 + (Y - 200)**2) / 1000
        
        # Time series (20 timesteps over 60 seconds)
        times = np.linspace(0, 60, 20)
        water_depths = []
        
        for t in times:
            # Expanding circular flood
            center_x, center_y = 300, 200
            radius = 50 + 100 * (t / 60)  # Expand from 50m to 150m radius
            
            distance = np.sqrt((X - center_x)**2 + (Y - center_y)**2)
            max_depth = 5.0 * (1 - t / 120)  # Decreasing depth over time
            
            depth = np.maximum(0, max_depth * np.exp(-distance / radius) - 0.1 * dem)
            depth = np.maximum(0, depth)
            
            water_depths.append(depth)
        
        # Package as results data
        results_data = {
            'times': times.tolist(),
            'water_depths': water_depths,
            'dem_array': dem,
            'geotransform': (0, 10, 0, 400, 0, -10),
            'projection': 'EPSG:4326'
        }
        
        # Create temporary folder and set up animation
        import tempfile
        temp_dir = tempfile.mkdtemp(prefix='floodengine_demo_')
        
        from time_series_integration import integrate_time_series_animation
        animation_result = integrate_time_series_animation(results_data, temp_dir)
        
        if animation_result['success']:
            logger.info(f"✅ Sample animation created in: {temp_dir}")
            
            # Launch the animation
            from time_series_animator import TimeSeriesAnimator
            
            app = QApplication.instance()
            if app is None:
                app = QApplication(sys.argv)
            
            animator = TimeSeriesAnimator(results_data, temp_dir)
            animator.setWindowTitle("FloodEngine Demo - Sample Animation")
            animator.show()
            
            logger.info("🎬 Demo animation launched!")
            logger.info("🎮 Try the playback controls")
            logger.info("📍 Click anywhere on the visualization")
            
            # Keep reference
            app._demo_animator = animator
            
            return app.exec_()
        else:
            logger.error(f"❌ Failed to create sample animation: {animation_result.get('error')}")
            return False
            
    except Exception as e:
        logger.error(f"❌ Demo failed: {e}")
        return False

def demo_folder_loading(folder_path):
    """Demonstrate loading animation from existing folder."""
    logger.info(f"📁 Loading animation from: {folder_path}")
    
    if not os.path.exists(folder_path):
        logger.error(f"❌ Folder does not exist: {folder_path}")
        return False
    
    try:
        # Try to launch animation
        from launch_animation import launch_animation_from_folder
        
        success = launch_animation_from_folder(folder_path)
        
        if success:
            logger.info("✅ Animation launched successfully!")
            return True
        else:
            logger.error("❌ Failed to launch animation")
            return False
            
    except Exception as e:
        logger.error(f"❌ Error loading animation: {e}")
        return False

def main():
    """Main demo function."""
    import argparse
    
    parser = argparse.ArgumentParser(description="FloodEngine Animation Controls Demo")
    parser.add_argument('folder', nargs='?', help='Animation folder path')
    parser.add_argument('--sample', '-s', action='store_true', help='Run demo with sample data')
    parser.add_argument('--check', '-c', action='store_true', help='Check system requirements')
    parser.add_argument('--qgis', action='store_true', help='Try QGIS integration')
    parser.add_argument('--usage', '-u', action='store_true', help='Show usage information')
    
    args = parser.parse_args()
    
    # Always show basic info
    print("🌊 FloodEngine Time Series Animation Controls Demo")
    print("=" * 50)
    
    if args.check:
        requirements = check_system_requirements()
        
        print("\nSYSTEM STATUS:")
        print(f"Animation Ready: {'✅ YES' if requirements['numpy'] and requirements['PyQt5'] else '❌ NO'}")
        print(f"Full Functionality: {'✅ YES' if all(requirements.values()) else '⚠️ PARTIAL'}")
        
        if not requirements['numpy']:
            print("\n💡 Install NumPy: pip install numpy")
        if not requirements['PyQt5']:
            print("💡 Install PyQt5: pip install PyQt5")
        if not requirements['GDAL']:
            print("💡 Install GDAL: pip install GDAL")
        
        return 0
    
    if args.usage:
        demo_basic_usage()
        return 0
    
    if args.sample:
        print("🧪 Starting sample animation demo...")
        result = demo_with_sample_data()
        return 0 if result else 1
    
    if args.folder:
        print(f"📁 Loading animation from folder: {args.folder}")
        result = demo_folder_loading(args.folder)
        return 0 if result else 1
    
    # No specific action - show help and options
    print("🚀 Available Demo Options:")
    print("  --sample     Create and show sample animation")
    print("  --check      Check system requirements")
    print("  --usage      Show detailed usage information")
    print("  folder_path  Load animation from existing folder")
    print("\nExamples:")
    print("  python demo_animation_controls.py --sample")
    print("  python demo_animation_controls.py --check")
    print("  python demo_animation_controls.py /path/to/animation/folder")
    
    # If PyQt5 is available, offer to run sample demo
    try:
        from PyQt5.QtWidgets import QApplication
        print("\n🎬 PyQt5 detected - you can run the sample demo!")
        
        response = input("Would you like to run the sample animation demo? (y/N): ")
        if response.lower().startswith('y'):
            return demo_with_sample_data()
    except ImportError:
        print("\n💡 Install PyQt5 to run interactive demos: pip install PyQt5")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
