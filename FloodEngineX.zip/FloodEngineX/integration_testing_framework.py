#!/usr/bin/env python3
"""
FloodEngine v4.0 - Integration Testing Framework
===============================================

Comprehensive integration testing framework for FloodEngine v4.0 that tests:
- Quality Assurance Framework integration with QGIS
- Advanced Analysis Tools integration with plugin
- GPU acceleration with actual QGIS workflows
- Precipitation input with real-world scenarios
- Performance optimization under live conditions
- Complete workflow validation

Author: FloodEngine Development Team
Date: June 7, 2025
Version: 4.0
"""

import os
import sys
import time
import json
import logging
import tempfile
import shutil
import traceback
import unittest
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple, Optional, Any, Union

# FloodEngine imports
try:
    from .quality_assurance_framework import QualityAssuranceFramework, QATestResult
    from .advanced_analysis_tools import (
        FloodRiskAssessment, EconomicImpactAnalysis, 
        UncertaintyQuantification, MultiScenarioAnalysis
    )
    from .gpu_acceleration import GPUAccelerationManager
    from .precipitation_input import PrecipitationProcessor, DesignStormGenerator
    from .performance_optimization import PerformanceOptimizer
    from .saint_venant_2d import SaintVenant2DSolver
    
    # Check if we have QGIS available
    QGIS_AVAILABLE = False
    try:
        from qgis.core import QgsApplication, QgsProject, QgsRasterLayer, QgsVectorLayer
        from qgis.PyQt.QtCore import QEventLoop, QTimer
        QGIS_AVAILABLE = True
    except ImportError:
        pass
        
except ImportError as e:
    print(f"Warning: Could not import FloodEngine modules: {e}")

class IntegrationTestResult:
    """Container for integration test results."""
    
    def __init__(self, test_name: str, success: bool = False, 
                 message: str = "", execution_time: float = 0.0,
                 details: Dict[str, Any] = None):
        self.test_name = test_name
        self.success = success
        self.message = message
        self.execution_time = execution_time
        self.details = details or {}
        self.timestamp = datetime.now()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary."""
        return {
            'test_name': self.test_name,
            'success': self.success,
            'message': self.message,
            'execution_time': self.execution_time,
            'details': self.details,
            'timestamp': self.timestamp.isoformat()
        }

class FloodEngineIntegrationTester:
    """Comprehensive integration testing framework for FloodEngine v4.0."""
    
    def __init__(self, output_dir: str = None):
        """Initialize the integration tester.
        
        Args:
            output_dir (str): Directory for test outputs
        """
        self.output_dir = Path(output_dir) if output_dir else Path.cwd() / "integration_test_results"
        self.output_dir.mkdir(exist_ok=True)
        
        # Setup logging
        self.logger = self._setup_logging()
        
        # Test results storage
        self.test_results: List[IntegrationTestResult] = []
        
        # Test data paths
        self.test_data_dir = self.output_dir / "test_data"
        self.test_data_dir.mkdir(exist_ok=True)
        
        # Initialize components for testing
        self.qa_framework = None
        self.gpu_manager = None
        self.precipitation_processor = None
        self.performance_optimizer = None
        
        # QGIS-specific components
        self.qgis_app = None
        self.qgis_project = None
        
        self.logger.info("FloodEngine Integration Tester initialized")
    
    def _setup_logging(self) -> logging.Logger:
        """Setup logging for integration tests."""
        logger = logging.getLogger('FloodEngineIntegrationTester')
        logger.setLevel(logging.INFO)
        
        # File handler
        log_file = self.output_dir / f"integration_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.INFO)
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        
        # Formatter
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)
        
        return logger
    
    def initialize_qgis_environment(self) -> bool:
        """Initialize QGIS environment for testing."""
        if not QGIS_AVAILABLE:
            self.logger.warning("QGIS not available - skipping QGIS-specific tests")
            return False
        
        try:
            # Initialize QGIS application
            self.qgis_app = QgsApplication([], False)
            self.qgis_app.initQgis()
            
            # Create new project
            self.qgis_project = QgsProject.instance()
            self.qgis_project.clear()
            
            self.logger.info("QGIS environment initialized successfully")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to initialize QGIS environment: {e}")
            return False
    
    def cleanup_qgis_environment(self):
        """Cleanup QGIS environment after testing."""
        if self.qgis_app:
            try:
                self.qgis_app.exitQgis()
                self.logger.info("QGIS environment cleaned up")
            except Exception as e:
                self.logger.warning(f"Error cleaning up QGIS: {e}")
    
    def create_test_datasets(self) -> Dict[str, str]:
        """Create test datasets for integration testing."""
        self.logger.info("Creating test datasets...")
        
        try:
            # Import QA framework to use its test dataset creation
            if 'quality_assurance_framework' in sys.modules:
                qa_module = sys.modules['quality_assurance_framework']
                qa_framework = qa_module.QualityAssuranceFramework(str(self.test_data_dir))
                
                # Create test datasets
                datasets = qa_framework.create_test_datasets()
                
                self.logger.info(f"Created {len(datasets)} test datasets")
                return datasets
            else:
                # Fallback: create basic test datasets
                return self._create_basic_test_datasets()
                
        except Exception as e:
            self.logger.error(f"Failed to create test datasets: {e}")
            return {}
    
    def _create_basic_test_datasets(self) -> Dict[str, str]:
        """Create basic test datasets as fallback."""
        import numpy as np
        
        datasets = {}
        
        try:
            # Create simple DEM
            dem_data = np.zeros((100, 100), dtype=np.float32)
            # Add some topography
            x, y = np.meshgrid(np.linspace(0, 99, 100), np.linspace(0, 99, 100))
            dem_data = 100 - 0.5 * np.sqrt((x - 50)**2 + (y - 50)**2)
            
            # Save as simple text file (basic format)
            dem_path = self.test_data_dir / "basic_test_dem.txt"
            np.savetxt(dem_path, dem_data, fmt='%.2f')
            datasets['basic_dem'] = str(dem_path)
            
            self.logger.info("Created basic test DEM")
            
        except Exception as e:
            self.logger.error(f"Failed to create basic test datasets: {e}")
        
        return datasets
    
    def test_qa_framework_integration(self) -> IntegrationTestResult:
        """Test Quality Assurance Framework integration."""
        test_name = "QA Framework Integration"
        start_time = time.time()
        
        try:
            self.logger.info(f"Starting {test_name}...")
            
            # Initialize QA framework
            if 'quality_assurance_framework' in sys.modules:
                qa_module = sys.modules['quality_assurance_framework']
                self.qa_framework = qa_module.QualityAssuranceFramework(str(self.output_dir))
                
                # Run basic QA tests
                test_results = []
                
                # Test 1: Unit tests
                unit_result = self.qa_framework.run_unit_tests()
                test_results.append(unit_result)
                
                # Test 2: Performance tests (small scale)
                perf_result = self.qa_framework.run_performance_tests(max_grid_size=50)
                test_results.append(perf_result)
                
                # Analyze results
                success_count = sum(1 for result in test_results if result.success)
                total_tests = len(test_results)
                
                execution_time = time.time() - start_time
                
                if success_count == total_tests:
                    return IntegrationTestResult(
                        test_name, True, 
                        f"All {total_tests} QA tests passed",
                        execution_time,
                        {'test_results': [r.to_dict() for r in test_results]}
                    )
                else:
                    return IntegrationTestResult(
                        test_name, False,
                        f"Only {success_count}/{total_tests} QA tests passed",
                        execution_time,
                        {'test_results': [r.to_dict() for r in test_results]}
                    )
            else:
                return IntegrationTestResult(
                    test_name, False,
                    "QA framework module not available",
                    time.time() - start_time
                )
                
        except Exception as e:
            execution_time = time.time() - start_time
            self.logger.error(f"QA framework integration test failed: {e}")
            return IntegrationTestResult(
                test_name, False, 
                f"Test failed with exception: {str(e)}",
                execution_time
            )
    
    def test_analysis_tools_integration(self) -> IntegrationTestResult:
        """Test Advanced Analysis Tools integration."""
        test_name = "Analysis Tools Integration"
        start_time = time.time()
        
        try:
            self.logger.info(f"Starting {test_name}...")
            
            # Create test simulation results
            test_datasets = self.create_test_datasets()
            if not test_datasets:
                return IntegrationTestResult(
                    test_name, False,
                    "No test datasets available",
                    time.time() - start_time
                )
            
            # Test flood risk assessment
            if 'advanced_analysis_tools' in sys.modules:
                analysis_module = sys.modules['advanced_analysis_tools']
                
                # Initialize analysis tools
                risk_assessor = analysis_module.FloodRiskAssessment()
                economic_analyzer = analysis_module.EconomicImpactAnalysis()
                uncertainty_analyzer = analysis_module.UncertaintyQuantification()
                
                # Create dummy flood simulation results
                import numpy as np
                flood_depths = np.random.uniform(0, 3, (50, 50))
                velocities = np.random.uniform(0, 2, (50, 50))
                
                # Test risk assessment
                risk_map = risk_assessor.calculate_flood_hazard(flood_depths, velocities)
                
                # Test economic analysis
                economic_impact = economic_analyzer.calculate_total_damage(
                    flood_depths, "urban", detailed_breakdown=True
                )
                
                # Test uncertainty analysis
                uncertainty_result = uncertainty_analyzer.run_monte_carlo_analysis(
                    lambda params: np.sum(flood_depths * params.get('roughness', 1.0)),
                    parameter_ranges={'roughness': (0.8, 1.2)},
                    num_simulations=10
                )
                
                execution_time = time.time() - start_time
                
                # Validate results
                tests_passed = (
                    risk_map is not None and 
                    economic_impact is not None and 
                    uncertainty_result is not None
                )
                
                if tests_passed:
                    return IntegrationTestResult(
                        test_name, True,
                        "All analysis tools working correctly",
                        execution_time,
                        {
                            'risk_levels': risk_map.shape if hasattr(risk_map, 'shape') else 'N/A',
                            'economic_impact': economic_impact,
                            'uncertainty_range': uncertainty_result
                        }
                    )
                else:
                    return IntegrationTestResult(
                        test_name, False,
                        "Some analysis tools failed",
                        execution_time
                    )
            else:
                return IntegrationTestResult(
                    test_name, False,
                    "Analysis tools module not available",
                    time.time() - start_time
                )
                
        except Exception as e:
            execution_time = time.time() - start_time
            self.logger.error(f"Analysis tools integration test failed: {e}")
            return IntegrationTestResult(
                test_name, False,
                f"Test failed with exception: {str(e)}",
                execution_time
            )
    
    def test_gpu_acceleration_integration(self) -> IntegrationTestResult:
        """Test GPU acceleration integration."""
        test_name = "GPU Acceleration Integration"
        start_time = time.time()
        
        try:
            self.logger.info(f"Starting {test_name}...")
            
            if 'gpu_acceleration' in sys.modules:
                gpu_module = sys.modules['gpu_acceleration']
                self.gpu_manager = gpu_module.GPUAccelerationManager()
                
                # Test GPU availability and initialization
                gpu_available = self.gpu_manager.is_gpu_available()
                
                if gpu_available:
                    # Test GPU computation with small dataset
                    import numpy as np
                    test_data = np.random.random((100, 100)).astype(np.float32)
                    
                    # Test GPU computation
                    result = self.gpu_manager.compute_shallow_water_step(
                        test_data, test_data, test_data, dt=0.1
                    )
                    
                    execution_time = time.time() - start_time
                    
                    if result is not None:
                        return IntegrationTestResult(
                            test_name, True,
                            f"GPU acceleration working (Platform: {self.gpu_manager.platform_name})",
                            execution_time,
                            {
                                'gpu_platform': self.gpu_manager.platform_name,
                                'gpu_device': getattr(self.gpu_manager, 'device_name', 'Unknown'),
                                'computation_successful': True
                            }
                        )
                    else:
                        return IntegrationTestResult(
                            test_name, False,
                            "GPU computation failed",
                            execution_time
                        )
                else:
                    execution_time = time.time() - start_time
                    return IntegrationTestResult(
                        test_name, False,
                        "No GPU available for acceleration",
                        execution_time,
                        {'gpu_available': False}
                    )
            else:
                return IntegrationTestResult(
                    test_name, False,
                    "GPU acceleration module not available",
                    time.time() - start_time
                )
                
        except Exception as e:
            execution_time = time.time() - start_time
            self.logger.error(f"GPU acceleration integration test failed: {e}")
            return IntegrationTestResult(
                test_name, False,
                f"Test failed with exception: {str(e)}",
                execution_time
            )
    
    def test_precipitation_integration(self) -> IntegrationTestResult:
        """Test precipitation input integration."""
        test_name = "Precipitation Integration"
        start_time = time.time()
        
        try:
            self.logger.info(f"Starting {test_name}...")
            
            if 'precipitation_input' in sys.modules:
                precip_module = sys.modules['precipitation_input']
                self.precipitation_processor = precip_module.PrecipitationProcessor()
                storm_generator = precip_module.DesignStormGenerator()
                
                # Test design storm generation
                storm_data = storm_generator.generate_design_storm(
                    storm_type="constant",
                    duration_hours=2,
                    return_period=10,
                    time_step_minutes=10
                )
                
                # Test precipitation processing
                if storm_data:
                    # Create dummy grid for testing
                    import numpy as np
                    grid_shape = (50, 50)
                    cell_size = 10.0  # 10 meter cells
                    
                    precip_grid = self.precipitation_processor.apply_precipitation_to_grid(
                        storm_data, grid_shape, cell_size
                    )
                    
                    execution_time = time.time() - start_time
                    
                    if precip_grid is not None:
                        return IntegrationTestResult(
                            test_name, True,
                            f"Precipitation processing successful (Storm: {storm_data.get('type', 'Unknown')})",
                            execution_time,
                            {
                                'storm_type': storm_data.get('type'),
                                'storm_duration': storm_data.get('duration_hours'),
                                'grid_shape': grid_shape,
                                'precipitation_applied': True
                            }
                        )
                    else:
                        return IntegrationTestResult(
                            test_name, False,
                            "Failed to apply precipitation to grid",
                            execution_time
                        )
                else:
                    return IntegrationTestResult(
                        test_name, False,
                        "Failed to generate design storm",
                        time.time() - start_time
                    )
            else:
                return IntegrationTestResult(
                    test_name, False,
                    "Precipitation input module not available",
                    time.time() - start_time
                )
                
        except Exception as e:
            execution_time = time.time() - start_time
            self.logger.error(f"Precipitation integration test failed: {e}")
            return IntegrationTestResult(
                test_name, False,
                f"Test failed with exception: {str(e)}",
                execution_time
            )
    
    def test_complete_workflow_integration(self) -> IntegrationTestResult:
        """Test complete FloodEngine workflow integration."""
        test_name = "Complete Workflow Integration"
        start_time = time.time()
        
        try:
            self.logger.info(f"Starting {test_name}...")
            
            # Create test datasets
            test_datasets = self.create_test_datasets()
            if not test_datasets:
                return IntegrationTestResult(
                    test_name, False,
                    "No test datasets available for workflow test",
                    time.time() - start_time
                )
            
            workflow_steps = []
            
            # Step 1: Initialize Saint-Venant solver
            if 'saint_venant_2d' in sys.modules:
                sv_module = sys.modules['saint_venant_2d']
                solver = sv_module.SaintVenant2DSolver()
                workflow_steps.append("Saint-Venant solver initialized")
            else:
                return IntegrationTestResult(
                    test_name, False,
                    "Saint-Venant solver not available",
                    time.time() - start_time
                )
            
            # Step 2: Run basic simulation
            try:
                import numpy as np
                
                # Create simple test scenario
                nx, ny = 50, 50
                dx, dy = 10.0, 10.0
                dt = 0.1
                
                # Initialize arrays
                h = np.ones((ny, nx), dtype=np.float32) * 0.1  # Small initial depth
                u = np.zeros((ny, nx), dtype=np.float32)
                v = np.zeros((ny, nx), dtype=np.float32)
                z = np.zeros((ny, nx), dtype=np.float32)  # Flat bottom
                
                # Add water source in center
                h[ny//2, nx//2] = 2.0
                
                # Run a few time steps
                for step in range(5):
                    h_new, u_new, v_new = solver.compute_time_step(h, u, v, z, dt, dx, dy)
                    h, u, v = h_new, u_new, v_new
                
                workflow_steps.append(f"Simulation completed {5} time steps")
                
            except Exception as e:
                return IntegrationTestResult(
                    test_name, False,
                    f"Simulation failed: {str(e)}",
                    time.time() - start_time
                )
            
            # Step 3: Test analysis integration (if available)
            if 'advanced_analysis_tools' in sys.modules:
                analysis_module = sys.modules['advanced_analysis_tools']
                risk_assessor = analysis_module.FloodRiskAssessment()
                
                # Calculate flood risk
                velocities = np.sqrt(u**2 + v**2)
                risk_map = risk_assessor.calculate_flood_hazard(h, velocities)
                workflow_steps.append("Risk assessment completed")
            
            execution_time = time.time() - start_time
            
            return IntegrationTestResult(
                test_name, True,
                f"Complete workflow successful ({len(workflow_steps)} steps)",
                execution_time,
                {
                    'workflow_steps': workflow_steps,
                    'simulation_grid_size': f"{nx}x{ny}",
                    'time_steps_completed': 5
                }
            )
            
        except Exception as e:
            execution_time = time.time() - start_time
            self.logger.error(f"Complete workflow integration test failed: {e}")
            return IntegrationTestResult(
                test_name, False,
                f"Workflow failed with exception: {str(e)}",
                execution_time
            )
    
    def run_all_integration_tests(self) -> Dict[str, Any]:
        """Run all integration tests and return comprehensive results."""
        self.logger.info("Starting comprehensive integration testing...")
        
        start_time = time.time()
        
        # Initialize QGIS environment if available
        qgis_initialized = self.initialize_qgis_environment()
        
        # Run all integration tests
        tests = [
            self.test_qa_framework_integration,
            self.test_analysis_tools_integration,
            self.test_gpu_acceleration_integration,
            self.test_precipitation_integration,
            self.test_complete_workflow_integration
        ]
        
        for test_func in tests:
            try:
                result = test_func()
                self.test_results.append(result)
                
                status = "PASS" if result.success else "FAIL"
                self.logger.info(f"{result.test_name}: {status} ({result.execution_time:.2f}s)")
                
            except Exception as e:
                self.logger.error(f"Test {test_func.__name__} crashed: {e}")
                self.test_results.append(IntegrationTestResult(
                    test_func.__name__, False, f"Test crashed: {str(e)}"
                ))
        
        # Cleanup QGIS environment
        if qgis_initialized:
            self.cleanup_qgis_environment()
        
        # Generate comprehensive report
        total_time = time.time() - start_time
        report = self.generate_integration_report(total_time)
        
        self.logger.info(f"Integration testing completed in {total_time:.2f} seconds")
        
        return report
    
    def generate_integration_report(self, total_execution_time: float) -> Dict[str, Any]:
        """Generate comprehensive integration test report."""
        
        # Calculate summary statistics
        total_tests = len(self.test_results)
        passed_tests = sum(1 for result in self.test_results if result.success)
        failed_tests = total_tests - passed_tests
        success_rate = (passed_tests / total_tests * 100) if total_tests > 0 else 0
        
        # Create report
        report = {
            'summary': {
                'total_tests': total_tests,
                'passed_tests': passed_tests,
                'failed_tests': failed_tests,
                'success_rate': success_rate,
                'total_execution_time': total_execution_time,
                'test_date': datetime.now().isoformat()
            },
            'test_results': [result.to_dict() for result in self.test_results],
            'system_info': {
                'qgis_available': QGIS_AVAILABLE,
                'python_version': sys.version,
                'platform': sys.platform
            }
        }
        
        # Save report to file
        report_file = self.output_dir / f"integration_test_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2)
        
        # Generate HTML report
        self.generate_html_report(report, report_file.with_suffix('.html'))
        
        return report
    
    def generate_html_report(self, report: Dict[str, Any], output_file: Path):
        """Generate HTML integration test report."""
        
        html_content = f"""
<!DOCTYPE html>
<html>
<head>
    <title>FloodEngine v4.0 - Integration Test Report</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; }}
        .header {{ background-color: #2c3e50; color: white; padding: 20px; border-radius: 5px; }}
        .summary {{ background-color: #ecf0f1; padding: 15px; margin: 20px 0; border-radius: 5px; }}
        .test-result {{ margin: 10px 0; padding: 15px; border-radius: 5px; }}
        .pass {{ background-color: #d5f4e6; border-left: 5px solid #27ae60; }}
        .fail {{ background-color: #fadbd8; border-left: 5px solid #e74c3c; }}
        .details {{ font-size: 0.9em; color: #7f8c8d; margin-top: 10px; }}
        table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
        th, td {{ border: 1px solid #ddd; padding: 12px; text-align: left; }}
        th {{ background-color: #f2f2f2; }}
        .metric {{ display: inline-block; margin: 10px 20px 0 0; }}
        .metric-value {{ font-size: 1.5em; font-weight: bold; color: #2c3e50; }}
        .metric-label {{ font-size: 0.9em; color: #7f8c8d; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>FloodEngine v4.0 - Integration Test Report</h1>
        <p>Comprehensive testing of Quality Assurance Framework and Advanced Analysis Tools</p>
        <p>Generated: {report['summary']['test_date']}</p>
    </div>
    
    <div class="summary">
        <h2>Test Summary</h2>
        <div class="metric">
            <div class="metric-value">{report['summary']['total_tests']}</div>
            <div class="metric-label">Total Tests</div>
        </div>
        <div class="metric">
            <div class="metric-value" style="color: #27ae60;">{report['summary']['passed_tests']}</div>
            <div class="metric-label">Passed</div>
        </div>
        <div class="metric">
            <div class="metric-value" style="color: #e74c3c;">{report['summary']['failed_tests']}</div>
            <div class="metric-label">Failed</div>
        </div>
        <div class="metric">
            <div class="metric-value">{report['summary']['success_rate']:.1f}%</div>
            <div class="metric-label">Success Rate</div>
        </div>
        <div class="metric">
            <div class="metric-value">{report['summary']['total_execution_time']:.2f}s</div>
            <div class="metric-label">Total Time</div>
        </div>
    </div>
    
    <h2>Test Results</h2>
"""
        
        # Add individual test results
        for result in report['test_results']:
            status_class = "pass" if result['success'] else "fail"
            status_text = "PASS" if result['success'] else "FAIL"
            
            html_content += f"""
    <div class="test-result {status_class}">
        <h3>{result['test_name']} - {status_text}</h3>
        <p><strong>Message:</strong> {result['message']}</p>
        <p><strong>Execution Time:</strong> {result['execution_time']:.2f} seconds</p>
        <div class="details">
            <strong>Details:</strong> {json.dumps(result['details'], indent=2) if result['details'] else 'No additional details'}
        </div>
    </div>
"""
        
        # Add system information
        html_content += f"""
    <h2>System Information</h2>
    <table>
        <tr><th>Property</th><th>Value</th></tr>
        <tr><td>QGIS Available</td><td>{report['system_info']['qgis_available']}</td></tr>
        <tr><td>Python Version</td><td>{report['system_info']['python_version']}</td></tr>
        <tr><td>Platform</td><td>{report['system_info']['platform']}</td></tr>
    </table>
    
</body>
</html>
"""
        
        # Save HTML report
        with open(output_file, 'w') as f:
            f.write(html_content)
        
        self.logger.info(f"HTML report saved to: {output_file}")

def main():
    """Main function for running integration tests."""
    print("FloodEngine v4.0 - Integration Testing Framework")
    print("=" * 50)
    
    # Create output directory
    output_dir = Path.cwd() / "integration_test_results"
    output_dir.mkdir(exist_ok=True)
    
    # Initialize and run integration tester
    tester = FloodEngineIntegrationTester(str(output_dir))
    
    try:
        # Run all integration tests
        report = tester.run_all_integration_tests()
        
        # Print summary
        print(f"\nIntegration Testing Summary:")
        print(f"Total Tests: {report['summary']['total_tests']}")
        print(f"Passed: {report['summary']['passed_tests']}")
        print(f"Failed: {report['summary']['failed_tests']}")
        print(f"Success Rate: {report['summary']['success_rate']:.1f}%")
        print(f"Total Time: {report['summary']['total_execution_time']:.2f} seconds")
        
        if report['summary']['failed_tests'] > 0:
            print("\nFailed Tests:")
            for result in report['test_results']:
                if not result['success']:
                    print(f"  - {result['test_name']}: {result['message']}")
        
        print(f"\nDetailed reports saved to: {output_dir}")
        
    except Exception as e:
        print(f"Integration testing failed: {e}")
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
