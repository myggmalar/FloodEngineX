import numpy as np
from saint_venant_2d import SaintVenant2D

# Create a minimal test DEM
dem = np.ones((3, 3)) * 10.0
dem[1, 1] = 9.0

# Create model
model = SaintVenant2D(dem, (0, 1, 0, 0, 0, -1))

# Set water level
model.set_initial_condition(water_level=10.5)

# Print result
print(f"Max water depth: {np.max(model.h)}")
