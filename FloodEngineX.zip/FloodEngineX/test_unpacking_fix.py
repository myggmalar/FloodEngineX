#!/usr/bin/env python3
"""
Test the unpacking fix for model_hydraulic.py
"""

def test_unpacking_fix():
    """Test that the simulate_saint_venant_2d function returns the correct number of values."""
    
    # Mock the simulation function return format
    mock_results = [
        ("depth_001.tif", 1, 0.5, 1.23),
        ("depth_002.tif", 2, 1.0, 1.45), 
        ("depth_003.tif", 3, 1.5, 1.67)
    ]
    
    print("🔧 Testing unpacking format...")
    
    try:
        # Test the unpacking that was causing the error
        for filename, timestep_num, simulation_time_hours, actual_water_level in mock_results:
            print(f"✅ Timestep {timestep_num}: {filename} at {simulation_time_hours:.1f}h with {actual_water_level:.2f}m")
        
        print("✅ Unpacking test passed!")
        return True
        
    except ValueError as e:
        print(f"❌ Unpacking failed: {e}")
        return False

def test_calculation():
    """Test the simulation time calculation."""
    
    # Test the time calculation logic
    timestep_minutes = 30
    
    for timestep in range(1, 5):
        simulation_time_hours = (timestep * timestep_minutes) / 60.0
        print(f"Timestep {timestep}: {simulation_time_hours:.1f} hours")
    
    print("✅ Time calculation test passed!")

if __name__ == '__main__':
    print("🧪 Testing FloodEngine unpacking fix...")
    test_unpacking_fix()
    test_calculation()
    print("🎉 All tests completed!")
