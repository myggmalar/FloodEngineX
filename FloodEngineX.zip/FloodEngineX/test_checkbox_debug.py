#!/usr/bin/env python3
"""Test if the animation checkbox state can be read correctly."""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from PyQt5.QtWidgets import QApplication, QDialog
from floodengine_ui import FloodEngineDialog

def test_animation_checkbox():
    """Test if we can read the animation checkbox state."""
    app = QApplication(sys.argv)
    
    # Create the dialog
    dialog = FloodEngineDialog(iface=None)
    
    # Switch to advanced mode
    dialog.advanced_radio.setChecked(True)
    
    # Check if the animation checkbox exists and is checked
    checkbox = getattr(dialog, 'adv_create_animation', None)
    print(f"🔍 Animation checkbox exists: {checkbox is not None}")
    
    if checkbox:
        print(f"🔍 Checkbox checked: {checkbox.isChecked()}")
        print(f"🔍 Checkbox text: {checkbox.text()}")
        print(f"🔍 Checkbox enabled: {checkbox.isEnabled()}")
    else:
        print("❌ Animation checkbox not found!")
    
    # Test the debug logic from run_simulation
    if dialog.basic_radio.isChecked():
        create_animation = False
        print("🔍 DEBUG: Basic mode selected - animation disabled")
    else:
        checkbox = getattr(dialog, 'adv_create_animation', None)
        create_animation = bool(checkbox and checkbox.isChecked())
        print(f"🔍 DEBUG: Advanced mode - checkbox exists: {checkbox is not None}")
        if checkbox:
            print(f"🔍 DEBUG: Checkbox checked: {checkbox.isChecked()}")
        else:
            print("🔍 DEBUG: Checkbox not found!")
    
    print(f"🎬 Animation enabled: {create_animation}")
    
    app.quit()
    return create_animation

if __name__ == "__main__":
    result = test_animation_checkbox()
    print(f"Final result: Animation enabled = {result}")
