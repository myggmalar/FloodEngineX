#!/usr/bin/env python3
"""
Debug the current flood polygon generation issues.
This script will test the boundary creation and polygon generation.
"""

import numpy as np
import os
import sys
sys.path.insert(0, r'c:\Plugin\VSCode\Alt3\FloodEngineX')

def test_flood_boundary_issues():
    """Test the flood boundary generation to identify issues."""
    print("FloodEngine v4.0 - Flood Boundary Debug Test")
    print("=" * 50)
    
    # Test 1: Check create_precise_flood_boundary function
    print("\n1. Testing create_precise_flood_boundary function:")
    
    try:
        from model_hydraulic import create_precise_flood_boundary
        
        # Create test data
        dem_data = np.array([
            [100, 100, 100, 100, 100],
            [100, 99, 98, 99, 100],
            [100, 98, 97, 98, 100],
            [100, 99, 98, 99, 100],
            [100, 100, 100, 100, 100]
        ], dtype=np.float32)
        
        water_level = 99.5
        wet_array = np.maximum(0, water_level - dem_data)
        threshold = 0.1
        
        print(f"   Test DEM shape: {dem_data.shape}")
        print(f"   Water level: {water_level}")
        print(f"   Wet array max: {np.max(wet_array)}")
        print(f"   Wet pixels: {np.sum(wet_array > threshold)}")
        
        # Test without contour correction
        boundary_old = wet_array > threshold
        print(f"   Old boundary pixels: {np.sum(boundary_old)}")
        
        # Test with contour correction
        boundary_new = create_precise_flood_boundary(wet_array, threshold, dem_data, water_level)
        print(f"   New boundary pixels: {np.sum(boundary_new)}")
        
        print("   ✅ create_precise_flood_boundary function works")
        
    except Exception as e:
        print(f"   ❌ create_precise_flood_boundary failed: {e}")
    
    # Test 2: Check if timestep generation is working
    print("\n2. Testing timestep generation:")
    
    try:
        # Simulate the water level generation logic
        simulation_duration_hours = 24
        output_timesteps = 10
        
        # Test values
        valid_elevations = np.array([95, 96, 97, 98, 99, 100, 101, 102, 103, 104])
        dem_min = np.min(valid_elevations)
        dem_max = np.max(valid_elevations)
        dem_5th = np.percentile(valid_elevations, 5)
        dem_50th = np.percentile(valid_elevations, 50)
        
        start_level = dem_5th + 0.1
        end_level = dem_50th + 2.0
        
        water_levels = list(np.linspace(start_level, end_level, output_timesteps))
        
        print(f"   Simulation duration: {simulation_duration_hours} hours")
        print(f"   Output timesteps: {output_timesteps}")
        print(f"   DEM range: {dem_min:.1f} - {dem_max:.1f}")
        print(f"   Generated water levels: {len(water_levels)}")
        print(f"   Water level range: {water_levels[0]:.1f} - {water_levels[-1]:.1f}")
        print(f"   First 5 levels: {', '.join([f'{wl:.1f}' for wl in water_levels[:5]])}")
        
        print("   ✅ Timestep generation works correctly")
        
    except Exception as e:
        print(f"   ❌ Timestep generation failed: {e}")
    
    # Test 3: Check if polygon boundaries are being created with blue squares
    print("\n3. Testing polygon boundary issues:")
    
    # Create a test scenario similar to the user's issue
    test_flood_mask = np.zeros((10, 10), dtype=bool)
    # Create a small flooded area in the center (not a blue square)
    test_flood_mask[3:7, 3:7] = True
    
    print(f"   Test flood mask shape: {test_flood_mask.shape}")
    print(f"   Flooded pixels: {np.sum(test_flood_mask)}")
    
    # Simulate the boundary processing that should prevent blue squares
    from scipy.ndimage import binary_erosion, binary_dilation, binary_fill_holes
    
    # Apply morphological operations like in create_precise_flood_boundary
    eroded = binary_erosion(test_flood_mask, iterations=1)
    dilated = binary_dilation(eroded, iterations=2)
    filled = binary_fill_holes(dilated)
    final_mask = binary_erosion(filled, iterations=1)
    
    print(f"   Original flooded pixels: {np.sum(test_flood_mask)}")
    print(f"   After processing: {np.sum(final_mask)}")
    
    # Check if it still creates the right shape
    if np.sum(final_mask) > 0 and np.sum(final_mask) < np.sum(test_flood_mask) * 2:
        print("   ✅ Morphological processing works correctly")
    else:
        print("   ⚠️ Morphological processing may be creating artifacts")
    
    print("\n4. Common issues and solutions:")
    print("   🔍 Issue: Blue squares instead of proper flood boundaries")
    print("       - Check if create_precise_flood_boundary is being called")
    print("       - Verify contour extraction is working")
    print("       - Ensure morphological operations don't over-dilate")
    
    print("   🔍 Issue: Black contour lines visible")
    print("       - Check if boundary erosion is removing edge artifacts")
    print("       - Verify contour-based clipping is active")
    
    print("   🔍 Issue: Only one timestep in project")
    print("       - Check if all timesteps are being processed in the loop")
    print("       - Verify polygon creation doesn't fail for some timesteps")
    print("       - Check QGIS layer addition process")
    
    return True

if __name__ == "__main__":
    test_flood_boundary_issues()
