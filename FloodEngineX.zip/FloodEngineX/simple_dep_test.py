import sys
import os

# Change to the correct directory
os.chdir(r"c:\Plugin\VSCode\FloodEngine_fixed_v8")

# Test basic imports
print("=== FloodEngine v4.0 Visualization Dependencies Test ===")

deps = [
    ("numpy", "Core numerical computing"),
    ("matplotlib", "2D plotting and basic animation"),
    ("vtk", "3D visualization engine"),
    ("plotly", "Interactive plotting"),
    ("dash", "Web-based interfaces"),
    ("imageio", "Animation export"),
    ("PIL", "Image processing (Pillow)"),
    ("moderngl", "GPU acceleration"),
    ("openvr", "VR/AR support")
]

available = []
missing = []

for dep, desc in deps:
    try:
        __import__(dep)
        print(f"✓ {dep}: Available - {desc}")
        available.append(dep)
    except ImportError:
        print(f"✗ {dep}: Missing - {desc}")
        missing.append(dep)

print(f"\nSummary: {len(available)}/{len(deps)} dependencies available")

# Test FloodEngine visualization module
print("\n=== Testing FloodEngine Visualization Module ===")
try:
    import advanced_visualization_features
    print("✓ advanced_visualization_features: Module imported successfully")
    
    from advanced_visualization_features import FloodEngineVisualizationManager
    viz_manager = FloodEngineVisualizationManager("test_output")
    print("✓ FloodEngineVisualizationManager: Initialized successfully")
    
    print("\nCapabilities:")
    for cap, avail in viz_manager.capabilities.items():
        status = "✓" if avail else "✗"
        print(f"  {status} {cap}")
        
except Exception as e:
    print(f"✗ Error: {e}")

print("\n=== Test Complete ===")
if missing:
    print(f"Install missing deps with: pip install {' '.join(missing)}")
else:
    print("All dependencies available!")
