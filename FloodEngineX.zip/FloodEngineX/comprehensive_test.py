#!/usr/bin/env python3
"""
Comprehensive FloodEngine Integration Test
==========================================

This script tests all the major components of the FloodEngine plugin:
1. Saint-Venant 2D hydraulic modeling
2. CSV safety fixes for TIN interpolation
3. UI model_type initialization
4. NoData handling for visualization
5. Streamlines parameter safety
6. Water level variation across timesteps

All critical errors identified in the original task should be resolved.
"""

import os
import sys
import traceback
from pathlib import Path

def test_imports():
    """Test that all modules can be imported without critical errors"""
    print("Testing module imports...")
    
    results = {}
    
    # Test core UI module
    try:
        sys.path.insert(0, str(Path.cwd()))
        
        # Mock QGIS dependencies for testing
        class MockQgis:
            pass
        
        sys.modules['qgis'] = MockQgis()
        sys.modules['qgis.core'] = MockQgis()
        sys.modules['PyQt5'] = MockQgis()
        sys.modules['PyQt5.QtWidgets'] = MockQgis()
        sys.modules['PyQt5.QtCore'] = MockQgis()
        sys.modules['PyQt5.QtGui'] = MockQgis()
        
        # Test UI import
        from floodengine_ui import FloodEngineDialog
        results['UI Module'] = True
        print("✓ UI module imported successfully")
        
    except Exception as e:
        results['UI Module'] = False
        print(f"✗ UI module import failed: {e}")
    
    # Test hydraulic model
    try:
        from model_hydraulic import (
            safe_csv_value_conversion,
            fix_nodata_handling,
            generate_variable_water_levels,
            safe_streamlines_parameters
        )
        results['Hydraulic Model'] = True
        print("✓ Hydraulic model with safety functions imported successfully")
        
    except Exception as e:
        results['Hydraulic Model'] = False
        print(f"✗ Hydraulic model import failed: {e}")
    
    # Test Saint-Venant module
    try:
        from saint_venant_2d import SaintVenant2D, simulate_saint_venant_2d
        results['Saint-Venant 2D'] = True
        print("✓ Saint-Venant 2D module imported successfully")
        
    except Exception as e:
        results['Saint-Venant 2D'] = False
        print(f"✗ Saint-Venant 2D import failed: {e}")
    
    return results

def test_csv_safety():
    """Test CSV safety functions"""
    print("\nTesting CSV safety functions...")
    
    try:
        from model_hydraulic import safe_csv_value_conversion
        
        # Test cases that caused the original errors
        test_cases = [
            ('depth', float, None),  # Should return None, not cause error
            ('elevation', float, None),
            ('x', float, None),
            ('y', float, None),
            ('z', float, None),
            ('123.45', float, 123.45),  # Should convert successfully
            ('67.89', int, 67),  # Should convert via float
            ('', float, None),  # Empty string
            ('invalid_text', float, None),  # Random text
        ]
        
        all_passed = True
        for value, target_type, expected in test_cases:
            try:
                result = safe_csv_value_conversion(value, target_type, "test")
                if expected is None:
                    if result is None:
                        print(f"✓ '{value}' -> None (correct)")
                    else:
                        print(f"✗ '{value}' -> {result} (expected None)")
                        all_passed = False
                else:
                    if abs(result - expected) < 1e-6:
                        print(f"✓ '{value}' -> {result} (correct)")
                    else:
                        print(f"✗ '{value}' -> {result} (expected {expected})")
                        all_passed = False
            except Exception as e:
                print(f"✗ '{value}' caused exception: {e}")
                all_passed = False
        
        return all_passed
        
    except Exception as e:
        print(f"✗ CSV safety test setup failed: {e}")
        return False

def test_water_level_variation():
    """Test water level variation functions"""
    print("\nTesting water level variation...")
    
    try:
        from model_hydraulic import generate_variable_water_levels, validate_water_levels
        
        # Test different methods
        methods = ['linear', 'exponential', 'accumulation']
        all_passed = True
        
        for method in methods:
            try:
                levels = generate_variable_water_levels(
                    initial_level=5.0,
                    time_steps=10,
                    flow_q=100.0,
                    method=method
                )
                
                if len(levels) == 10:
                    variation = max(levels) - min(levels)
                    if variation > 0.01:  # Should have some variation
                        print(f"✓ {method} method: {variation:.3f}m variation")
                    else:
                        print(f"✗ {method} method: insufficient variation")
                        all_passed = False
                else:
                    print(f"✗ {method} method: wrong number of timesteps")
                    all_passed = False
                    
                # Test validation
                is_valid = validate_water_levels(levels)
                if is_valid:
                    print(f"✓ {method} method: validation passed")
                else:
                    print(f"✗ {method} method: validation failed")
                    all_passed = False
                    
            except Exception as e:
                print(f"✗ {method} method failed: {e}")
                all_passed = False
        
        return all_passed
        
    except Exception as e:
        print(f"✗ Water level variation test failed: {e}")
        return False

def test_streamlines_safety():
    """Test streamlines parameter safety"""
    print("\nTesting streamlines parameter safety...")
    
    try:
        from model_hydraulic import safe_streamlines_parameters
        
        # Test problematic parameter types
        test_params = {
            'density': '2.5',  # String that should be float
            'max_length': 1000,  # Int that should be float
            'integration_direction': 'forward',  # Should stay string
            'unknown_param': 'test_value'  # Unknown parameter
        }
        
        safe_params = safe_streamlines_parameters(**test_params)
        
        checks = [
            (isinstance(safe_params.get('density'), float), "density converted to float"),
            (isinstance(safe_params.get('max_length'), float), "max_length converted to float"),
            (isinstance(safe_params.get('integration_direction'), str), "integration_direction stays string"),
            ('unknown_param' in safe_params, "unknown parameter preserved")
        ]
        
        all_passed = True
        for check, description in checks:
            if check:
                print(f"✓ {description}")
            else:
                print(f"✗ {description}")
                all_passed = False
        
        return all_passed
        
    except Exception as e:
        print(f"✗ Streamlines safety test failed: {e}")
        return False

def test_nodata_handling():
    """Test NoData handling functions"""
    print("\nTesting NoData handling...")
    
    try:
        import numpy as np
        from model_hydraulic import fix_nodata_handling, create_proper_geotiff
        
        # Create test data with problematic values
        test_data = np.array([
            [1.0, 2.0, np.nan],
            [np.inf, 5.0, 6.0],
            [-np.inf, 8.0, 9.0]
        ])
        
        # Test NoData fixing
        fixed_data = fix_nodata_handling(test_data, nodata_value=-9999)
        
        checks = [
            (not np.any(np.isnan(fixed_data)), "NaN values removed"),
            (not np.any(np.isinf(fixed_data)), "Infinite values removed"),
            (np.any(fixed_data == -9999), "NoData values inserted")
        ]
        
        all_passed = True
        for check, description in checks:
            if check:
                print(f"✓ {description}")
            else:
                print(f"✗ {description}")
                all_passed = False
        
        return all_passed
        
    except Exception as e:
        print(f"✗ NoData handling test failed: {e}")
        return False

def test_ui_model_type():
    """Test UI model_type initialization"""
    print("\nTesting UI model_type initialization...")
    
    try:
        # Check if the fix is in the file
        with open('floodengine_ui.py', 'r', encoding='utf-8') as f:
            content = f.read()
        
        if 'self.model_type = "2D Shallow Water"' in content:
            print("✓ model_type initialization found in UI")
            return True
        else:
            print("✗ model_type initialization not found in UI")
            return False
            
    except Exception as e:
        print(f"✗ UI model_type test failed: {e}")
        return False

def test_saint_venant_structure():
    """Test Saint-Venant 2D structure and key methods"""
    print("\nTesting Saint-Venant 2D structure...")
    
    try:
        # Check if the file exists and has key components
        with open('saint_venant_2d.py', 'r', encoding='utf-8') as f:
            content = f.read()
        
        required_components = [
            ('class SaintVenant2D:', 'Main class definition'),
            ('def __init__(', 'Constructor'),
            ('def set_initial_condition(', 'Initial condition setter'),
            ('def calculate_timestep(', 'Time step calculation'),
            ('def step(', 'Simulation step'),
            ('def _update_fluxes(', 'Flux update method'),
            ('def _apply_boundaries(', 'Boundary conditions'),
            ('def simulate_saint_venant_2d(', 'Main simulation function'),
            ('dam_threshold', 'Dam handling'),
            ('CFL', 'Stability condition'),
            ('Manning', 'Friction modeling')
        ]
        
        all_passed = True
        for component, description in required_components:
            if component in content:
                print(f"✓ {description} found")
            else:
                print(f"✗ {description} not found")
                all_passed = False
        
        return all_passed
        
    except Exception as e:
        print(f"✗ Saint-Venant structure test failed: {e}")
        return False

def main():
    """Run comprehensive FloodEngine integration test"""
    print("=" * 80)
    print("FLOODENGINE COMPREHENSIVE INTEGRATION TEST")
    print("=" * 80)
    print("Testing all critical fixes and implementations...")
    
    # Change to the correct directory
    os.chdir(r"c:\Plugin\VSCode\FloodEngine_fixed_v8")
    
    # Run all tests
    tests = [
        ("Module Imports", test_imports),
        ("CSV Safety Functions", test_csv_safety),
        ("Water Level Variation", test_water_level_variation),
        ("Streamlines Safety", test_streamlines_safety),
        ("NoData Handling", test_nodata_handling),
        ("UI Model Type", test_ui_model_type),
        ("Saint-Venant Structure", test_saint_venant_structure)
    ]
    
    results = {}
    for test_name, test_func in tests:
        print(f"\n[TEST] {test_name}")
        print("-" * 60)
        
        try:
            result = test_func()
            results[test_name] = result
            
            if result:
                print(f"[PASS] {test_name}")
            else:
                print(f"[FAIL] {test_name}")
                
        except Exception as e:
            print(f"[ERROR] {test_name}: {e}")
            results[test_name] = False
            traceback.print_exc()
    
    # Summary
    print("\n" + "=" * 80)
    print("INTEGRATION TEST SUMMARY")
    print("=" * 80)
    
    passed = sum(1 for result in results.values() if result)
    total = len(results)
    
    for test_name, result in results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status:8} {test_name}")
    
    print(f"\nOverall: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 ALL TESTS PASSED! 🎉")
        print("\nFloodEngine plugin is ready with:")
        print("- Fixed CSV parsing for TIN interpolation")
        print("- Resolved model_type variable references")
        print("- Variable water levels across timesteps")
        print("- Safe streamlines parameter handling")
        print("- Proper NoData handling for visualization")
        print("- Complete Saint-Venant 2D implementation")
        print("- All critical errors resolved")
    else:
        print(f"\n⚠️  {total - passed} tests failed - check implementation")
    
    print("\n" + "=" * 80)

if __name__ == "__main__":
    main()
