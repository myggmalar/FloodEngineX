# FloodEngine Timestep Simulation - QGIS Testing Checklist

## Pre-Testing Setup
- [ ] QGIS environment available with Swedish projection (SWEREF99 TM / EPSG:3006)
- [ ] Swedish DEM file available (.tif format)
- [ ] Swedish bathymetry file available (.csv format with X,Y,Z columns)
- [ ] FloodEngine plugin loaded in QGIS
- [ ] Plugin UI accessible from toolbar/menu

## Critical Issue Tests

### 1. Water Level Fix Test
- [ ] Open FloodEngine advanced mode
- [ ] Verify initial water level is set to reasonable value (around 60m)
- [ ] Check that flooding occurs with Swedish terrain
- [ ] Expected: Visible flood areas at 60m water level

### 2. Timestep Layer Creation Test
- [ ] Run timestep simulation with 5-10 timesteps
- [ ] Monitor QGIS layers panel during simulation
- [ ] Verify multiple layers appear during processing
- [ ] Expected: "Flood Step X (Y.Ym)" layers in layer tree

### 3. Streamlines Parameter Fix Test
- [ ] Complete timestep simulation
- [ ] Check for streamlines generation at the end
- [ ] No TypeError should occur
- [ ] Expected: Streamlines layer created without errors

### 4. Water Level Progression Test
- [ ] Examine water levels in console output
- [ ] Verify progression shows increasing levels
- [ ] Check variation is at least 20cm between steps
- [ ] Expected: Range like 60.0m → 60.5m → 61.0m → 61.5m...

### 5. Error Handling Test
- [ ] Try with problematic DEM (if available)
- [ ] Check if empty placeholder layers are created for failed steps
- [ ] Verify simulation continues despite individual step failures
- [ ] Expected: Graceful handling with informative error messages

## Success Criteria
✅ All tests pass = Plugin ready for production use
❌ Any test fails = Review and fix before deployment

## Contact
Report issues with detailed error messages and console output.
