import os
import numpy as np
import sys

# Open a log file to capture output
with open('test_results.log', 'w') as log_file:
    try:
        log_file.write("Starting test...\n")
        
        # Add the current directory to path
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

        # Import the SaintVenant2D class
        from saint_venant_2d import SaintVenant2D
        log_file.write("Successfully imported SaintVenant2D\n")
        
        # Create a simple test DEM
        dem_array = np.ones((10, 10)) * 10
        # Make a simple channel with descending elevation
        dem_array[0:10, 4:6] = np.linspace(9.5, 8.5, 10)[:, np.newaxis]
        
        # Create model
        model = SaintVenant2D(dem_array, (0, 1, 0, 0, 0, -1))
        log_file.write("Successfully created model\n")
        
        # Set initial water level
        model.set_initial_condition(water_level=9.6)
        log_file.write(f"Initial water level set, max depth: {model.h.max():.2f}m\n")
        
        # Find river source (highest elevation in wet cells)
        wet_mask = model.h > 0.01
        highest_elev = np.where(wet_mask, dem_array, -np.inf)
        highest_idx = np.unravel_index(np.argmax(highest_elev), dem_array.shape)
        py, px = highest_idx
        log_file.write(f"Highest point in river: ({px}, {py}) with elevation {dem_array[py, px]:.2f}m\n")
        
        # Run a simulation step
        dt = model.step()
        log_file.write(f"Ran simulation step, dt={dt:.2f}s, max velocity={model.velocity_mag.max():.2f}m/s\n")
        
        log_file.write("Test completed successfully!\n")
        
    except Exception as e:
        log_file.write(f"Error: {e}\n")
        import traceback
        traceback.print_exc(file=log_file)
