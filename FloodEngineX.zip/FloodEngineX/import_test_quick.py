print("Testing load_bathymetry import fix...")

try:
    import unittest.mock as mock
    
    with mock.patch.dict('sys.modules', {
        'osgeo': mock.MagicMock(),
        'osgeo.gdal': mock.MagicMock(),
        'osgeo.ogr': mock.MagicMock(),
        'osgeo.osr': mock.MagicMock(),
        'qgis': mock.MagicMock(),
        'qgis.core': mock.MagicMock(),
        'qgis.PyQt': mock.MagicMock(),
        'qgis.PyQt.QtCore': mock.MagicMock(),
    }):
        from model_hydraulic import load_bathymetry
        print("SUCCESS: load_bathymetry imported successfully!")
        
        # Check if it's callable
        if callable(load_bathymetry):
            print("SUCCESS: load_bathymetry is callable")
        else:
            print("ERROR: load_bathymetry is not callable")
        
except Exception as e:
    print(f"ERROR: {e}")
    import traceback
    traceback.print_exc()
