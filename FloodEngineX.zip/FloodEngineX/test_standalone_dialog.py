#!/usr/bin/env python3
"""
Test Standalone Animation Dialog
-------------------------------
Tests the animation dialog in standalone mode (without QGIS).
"""

import os
import sys
import logging
from pathlib import Path

# Add the FloodEngineX directory to the path
sys.path.insert(0, str(Path(__file__).parent))

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_standalone_dialog():
    """Test the standalone animation dialog."""
    logger.info("🧪 Testing standalone animation dialog...")
    
    try:
        # Import the dialog class
        from time_series_animator import TimeSeriesAnimator
        from PyQt5.QtWidgets import QApplication
        import sys
        
        # Create minimal test data
        results_data = {
            'times': [0, 10, 20, 30, 40, 50],  # 6 timesteps
            'total_time': 50.0,
            'grid_shape': (50, 50),
            'geotransform': (0, 1, 0, 50, 0, -1),
            'num_timesteps': 6
        }
        
        output_folder = "test_standalone_animation"
        os.makedirs(output_folder, exist_ok=True)
        
        # Create rasters subfolder
        rasters_folder = os.path.join(output_folder, "rasters")
        os.makedirs(rasters_folder, exist_ok=True)
        
        # Create some dummy raster files (just empty files for testing)
        for i in range(6):
            depth_file = os.path.join(rasters_folder, f"depth_t{i:04d}.tif")
            with open(depth_file, 'w') as f:
                f.write("dummy_raster")
        
        logger.info("✅ Test data created")
        
        # Create QApplication
        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)
        
        # Create and show the dialog
        logger.info("🎬 Creating animation dialog...")
        dialog = TimeSeriesAnimator(results_data, output_folder)
        dialog.setWindowTitle("FloodEngine - Test Animation")
        dialog.resize(800, 600)
        dialog.show()
        
        logger.info("✅ Dialog created and shown successfully!")
        logger.info("🎮 Dialog is now visible - you can interact with it")
        logger.info("❌ Close the dialog to complete the test")
        
        # Store dialog reference to prevent garbage collection
        global _test_dialog
        _test_dialog = dialog
        
        # Process events to ensure the dialog is visible
        app.processEvents()
        
        return True
        
    except ImportError as e:
        logger.error(f"❌ Could not import required components: {e}")
        logger.info("💡 Make sure PyQt5 is installed: pip install PyQt5")
        return False
        
    except Exception as e:
        logger.error(f"❌ Error creating dialog: {e}")
        return False

def test_with_event_loop():
    """Test the dialog with a full event loop."""
    logger.info("🧪 Testing animation dialog with event loop...")
    
    try:
        from launch_animation_standalone import launch_animation_with_event_loop
        
        # Create test data
        results_data = {
            'times': [0, 10, 20, 30, 40, 50],
            'total_time': 50.0,
            'grid_shape': (50, 50),
            'geotransform': (0, 1, 0, 50, 0, -1),
            'num_timesteps': 6
        }
        
        output_folder = "test_standalone_animation"
        
        logger.info("🎬 Launching animation with event loop...")
        exit_code = launch_animation_with_event_loop(results_data, output_folder)
        
        if exit_code == 0:
            logger.info("✅ Animation dialog completed successfully!")
            return True
        else:
            logger.warning(f"⚠️ Animation dialog exited with code: {exit_code}")
            return False
            
    except Exception as e:
        logger.error(f"❌ Error launching dialog with event loop: {e}")
        return False

def main():
    """Main test function."""
    print("=" * 60)
    print("STANDALONE ANIMATION DIALOG TEST")
    print("=" * 60)
    
    print("\n1. Testing basic dialog creation...")
    basic_success = test_standalone_dialog()
    
    if basic_success:
        print("\n✅ Basic dialog test passed!")
        print("\n2. Testing with full event loop...")
        print("   (This will open a dialog window - close it to continue)")
        
        choice = input("\nRun full event loop test? (y/n): ").lower().strip()
        if choice == 'y':
            event_loop_success = test_with_event_loop()
            if event_loop_success:
                print("\n✅ All tests passed!")
                return 0
            else:
                print("\n⚠️ Event loop test failed")
                return 1
        else:
            print("\n⏭️ Skipping event loop test")
            return 0
    else:
        print("\n❌ Basic dialog test failed")
        return 1

if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n\n⏹️ Test interrupted by user")
        sys.exit(1)
