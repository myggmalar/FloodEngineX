import os
import sys
import numpy as np
from qgis.core import QgsProject, QgsVectorLayer
from PyQt5.QtGui import QColor
from osgeo import gdal, ogr, osr
from .enhanced_flow_points import create_enhanced_flow_points
# Import the fixed Saint-Venant class for internal use
from .saint_venant_2d import SaintVenant2D

def calculate_flood_area(
    iface,
    dem_path,
    water_levels=None,
    output_folder=None,
    flow_q=None,
    manning_n=None,
    bathymetry_path=None,
    bathymetry_columns=None,
    simulation_duration_hours=24.0,  # Change to float
    output_timesteps=10,
    output_interval_hours=2.4,  # Add missing parameter
    hydrograph_data=None,
    create_animation=False,  # NEW: Animation control parameter
    **kwargs
):
    """
    Calculate flood area using 2D Saint-Venant equations with dynamic simulation.
    
    Args:
        iface: QGIS interface
        dem_path: Path to DEM file
        water_levels: List of water levels (if None, will be computed automatically)
        output_folder: Output directory
        flow_q: Flow rate (m³/s)
        manning_n: Manning's roughness coefficient
        bathymetry_path: Path to bathymetry data
        bathymetry_columns: Column mapping for bathymetry CSV
        simulation_duration_hours: Total simulation time in hours (default: 24)
        output_timesteps: Number of output timesteps to generate (default: 10)
        hydrograph_data: Dict with time-varying flow data {'time': [...], 'flow': [...]}
        **kwargs: Additional parameters
    
    Returns:
        List of polygon layers created
    """
    print(f"🌊 Starting FloodEngine simulation...")
    print(f"📍 DEM: {dem_path}")
    print(f"⏱️ Simulation duration: {simulation_duration_hours} hours")
    print(f"📊 Output timesteps: {output_timesteps}")
    print(f"🔄 Output interval: {simulation_duration_hours/output_timesteps:.1f} hours between outputs")
    
    # Handle hydrograph vs constant flow
    if hydrograph_data:
        print(f"📈 Using hydrograph data with {len(hydrograph_data['time'])} points")
        flow_range = f"{min(hydrograph_data['flow']):.1f}-{max(hydrograph_data['flow']):.1f}"
        print(f"💧 Flow range: {flow_range} m³/s")
    else:
        print(f"💧 Constant flow rate: {flow_q} m³/s")
        
    print(f"🏔️ Manning's n: {manning_n}")
    
    # Validate and ensure output folder exists
    if not output_folder:
        output_folder = os.path.dirname(dem_path) if dem_path else os.getcwd()
        print(f"📁 Using default output folder: {output_folder}")
    
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
        print(f"📁 Created output folder: {output_folder}")
    
    # Create hillshade from DEM
    hillshade_path = os.path.join(output_folder, "dem_hillshade.tif")
    create_hillshade_gdal(dem_path, hillshade_path)
    
    # Add hillshade to QGIS project
    try:
        from qgis.core import QgsRasterLayer
        hillshade_layer = QgsRasterLayer(hillshade_path, "DEM Hillshade")
        if hillshade_layer.isValid():
            QgsProject.instance().addMapLayer(hillshade_layer)
            print(f"✅ Hillshade added to QGIS project")
        else:
            print(f"⚠️ Hillshade layer invalid but file created")
    except Exception as e:
        print(f"⚠️ Could not add hillshade to project: {e}")
    
    # Calculate output interval
    output_interval_hours = simulation_duration_hours / output_timesteps
    
    print(f"📊 Simulation will run for {simulation_duration_hours} hours with {output_timesteps} outputs")
    print(f"📅 Output every {output_interval_hours:.1f} hours")
    
    # Run simulation
    sv_result = simulate_saint_venant_2d(
        dem_path=dem_path,
        flow_rate=flow_q,
        manning_n=manning_n,
        simulation_duration_hours=simulation_duration_hours,
        output_timesteps=output_timesteps,
        output_interval_hours=output_interval_hours,
        output_folder=output_folder,
        water_levels=water_levels,
        hydrograph_data=hydrograph_data,
        create_animation=create_animation
    )
    
    # Load DEM data for contour-based boundary extraction
    dem_data = load_raster_to_array_gdal(dem_path)
    print(f"📊 Loaded DEM data with shape: {dem_data.shape}")
    
    all_polygons = []
    for filename, timestep_num, simulation_time_hours, actual_water_level in sv_result:
        wet_array = load_raster_to_array_gdal(filename)
        
        # ENHANCED DEBUGGING AND FILTERING
        flooded_pixels = np.sum(wet_array > 0.05)
        print(f"\n🔬 Processing timestep {timestep_num}: {flooded_pixels} flooded pixels")
        
        # Skip tiny areas that would create artifacts
        if flooded_pixels < 3:
            print(f"   🚫 Skipping timestep {timestep_num} - too few flooded pixels ({flooded_pixels})")
            continue
        
        # Use enhanced boundary detection
        threshold = kwargs.get('wet_threshold', 0.05)
        binary_mask = create_precise_flood_boundary(wet_array, threshold, dem_data, actual_water_level)
        
        # Additional verification after boundary processing
        final_flooded_pixels = np.sum(binary_mask)
        print(f"   📊 After boundary processing: {final_flooded_pixels} pixels")
        
        if final_flooded_pixels < 3:
            print(f"   🚫 Skipping timestep {timestep_num} - boundary processing left too few pixels")
            continue
        
        # Create polygon with enhanced error handling
        try:
            polygon_layer = polygonize_mask_gdal(binary_mask, filename, output_folder, timestep_num, actual_water_level)
            
            # Enhanced layer naming with metadata
            layer_name = f"Flood_T{timestep_num:03d}_{simulation_time_hours:.1f}h_WL{actual_water_level:.1f}m_P{final_flooded_pixels}"
            polygon_layer.setName(layer_name)
            
            # Verify layer is valid before adding
            if polygon_layer.isValid() and polygon_layer.featureCount() > 0:
                style_polygon_layer_blue_opacity(polygon_layer)
                QgsProject.instance().addMapLayer(polygon_layer)
                print(f"   ✅ Added layer: {layer_name} ({polygon_layer.featureCount()} features)")
                all_polygons.append(polygon_layer)
            else:
                print(f"   ⚠️ Invalid polygon layer for timestep {timestep_num} - skipping")
                
        except Exception as e:
            print(f"   ❌ Failed to create polygon for timestep {timestep_num}: {e}")
            continue
        
        # Create flow points with actual Saint-Venant velocity field
        try:
            # Create flow points for this timestep
            flow_points_layer = create_enhanced_flow_points(
                dem_path=dem_path, 
                flood_layer=polygon_layer, 
                output_folder=output_folder,
                flow_q=flow_q,
                method="saint_venant"
            )
            
            if flow_points_layer:
                # Rename layer to include timestep info
                flow_points_layer.setName(f"FlowPoints_T{timestep_num:03d}_{simulation_time_hours:.1f}h")
                QgsProject.instance().addMapLayer(flow_points_layer)
                print(f"   ✅ Created flow velocity points for timestep {timestep_num}")
            else:
                print(f"   ⚠️ Could not create flow points for timestep {timestep_num}")
                
        except Exception as e:
            print(f"   ❌ Error creating flow points: {e}")
        
        all_polygons.append(polygon_layer)
        
    return all_polygons

def create_hillshade_gdal(dem_path, output_path, azimuth=315, altitude=45):
    """Create hillshade from DEM using GDAL."""
    print(f"Creating hillshade using GDAL...")
    
    try:
        options = gdal.DEMProcessingOptions(
            format='GTiff',
            creationOptions=['COMPRESS=LZW'],
            azimuth=azimuth,
            altitude=altitude
        )
        
        result = gdal.DEMProcessing(output_path, dem_path, 'hillshade', options=options)
        
        if result is not None and os.path.exists(output_path):
            print(f"✅ Hillshade saved: {output_path}")
        else:
            print(f"❌ Failed to create hillshade: {output_path}")
            
    except Exception as e:
        print(f"❌ Error creating hillshade: {str(e)}")

def load_raster_to_array_gdal(raster_path):
    """Load raster data to numpy array using GDAL."""
    dataset = gdal.Open(raster_path)
    if dataset is None:
        raise ValueError(f"Cannot open raster file: {raster_path}")
    
    band = dataset.GetRasterBand(1)
    array = band.ReadAsArray()
    dataset = None
    return array

def polygonize_mask_gdal(binary_mask, dem_path, output_folder, timestep, water_level):
    """
    Convert binary mask to polygon using GDAL - FIXED VERSION.
    """
    from qgis.core import QgsVectorLayer
    
    print(f"   🔄 Creating polygons for timestep {timestep}, water level {water_level:.2f}m (FIXED)")
    
    # Check if there's any flooded area
    flooded_pixels = np.sum(binary_mask > 0)
    if flooded_pixels == 0:
        print(f"   ⚠️ No flooded area found - creating empty layer")
        return QgsVectorLayer("Polygon?crs=EPSG:4326", f"Flood_{timestep:03d}_Empty", "memory")
    
    print(f"   📊 Processing {flooded_pixels} flooded pixels")
    
    # Get spatial reference from DEM
    dem_dataset = gdal.Open(dem_path)
    if dem_dataset is None:
        raise ValueError(f"Cannot open DEM file: {dem_path}")
    
    geotransform = dem_dataset.GetGeoTransform()
    projection = dem_dataset.GetProjection()
    
    # Create temporary raster for the mask
    rows, cols = binary_mask.shape
    temp_tif = os.path.join(output_folder, f"temp_mask_{timestep}.tif")
    
    print(f"   📁 Creating temporary mask: {temp_tif}")
    
    try:
        driver = gdal.GetDriverByName('GTiff')
        mask_dataset = driver.Create(temp_tif, cols, rows, 1, gdal.GDT_Byte)
        mask_dataset.SetGeoTransform(geotransform)
        mask_dataset.SetProjection(projection)
        mask_band = mask_dataset.GetRasterBand(1)
        
        # CRITICAL FIX: Create proper binary mask for polygonization
        # Convert boolean mask to 1/0 values (not 1/NaN)
        mask_array = np.where(binary_mask, 1, 0).astype(np.uint8)
        
        mask_band.WriteArray(mask_array)
        mask_band.SetNoDataValue(0)  # Set 0 as NoData so only flooded areas (1) are polygonized
        mask_dataset.FlushCache()
        mask_dataset = None
        dem_dataset = None
        
        print(f"   ✅ Temporary mask created successfully")
        
    except Exception as e:
        print(f"   ❌ Failed to create temporary mask: {e}")
        dem_dataset = None
        raise
    
    # Convert raster to vector
    output_gpkg = os.path.join(output_folder, f"flood_polygons_{timestep:03d}_{water_level:.2f}m.gpkg")
    
    print(f"   🎯 Creating vector output: {output_gpkg}")
    
    # Clean up existing file
    if os.path.exists(output_gpkg):
        try:
            os.remove(output_gpkg)
        except:
            pass
    
    # Create vector datasource
    driver = ogr.GetDriverByName("GPKG")
    if driver is None:
        print("   ❌ GPKG driver not available, falling back to shapefile")
        output_vector = os.path.join(output_folder, f"flood_polygons_{timestep:03d}_{water_level:.2f}m.shp")
        # Clean up shapefile components
        for ext in ['.shp', '.shx', '.dbf', '.prj', '.cpg']:
            shp_file = output_vector.replace('.shp', ext)
            if os.path.exists(shp_file):
                try:
                    os.remove(shp_file)
                except:
                    pass
        driver = ogr.GetDriverByName("ESRI Shapefile")
    else:
        output_vector = output_gpkg
    
    try:
        datasource = driver.CreateDataSource(output_vector)
        if datasource is None:
            raise RuntimeError(f"Failed to create datasource: {output_vector}")
        print(f"   ✅ Vector datasource created successfully")
    except Exception as e:
        print(f"   ❌ Failed to create vector datasource: {e}")
        raise
    
    # Create layer and add attributes
    try:
        srs = osr.SpatialReference()
        srs.ImportFromWkt(projection)
        
        layer = datasource.CreateLayer("flood", srs, ogr.wkbPolygon)
        if layer is None:
            raise RuntimeError("Failed to create layer")
            
        field_defn = ogr.FieldDefn("water_lvl", ogr.OFTReal)
        layer.CreateField(field_defn)
        field_defn = ogr.FieldDefn("Timestep", ogr.OFTInteger)
        layer.CreateField(field_defn)
        print(f"   ✅ Layer and attributes created successfully")
    except Exception as e:
        print(f"   ❌ Failed to create layer: {e}")
        datasource = None
        raise
    
    # Polygonize the raster
    try:
        mask_dataset = gdal.Open(temp_tif)
        if mask_dataset is None:
            raise RuntimeError(f"Cannot reopen temporary mask: {temp_tif}")
            
        mask_band = mask_dataset.GetRasterBand(1)
        
        print(f"   🔄 Running polygonization...")
        # CRITICAL: Only polygonize pixels with value 1 (flooded areas)
        result = gdal.Polygonize(mask_band, mask_band, layer, 0, [], callback=None)
        
        if result != 0:
            print(f"   ⚠️ Polygonize returned code: {result}")
        else:
            print(f"   ✅ Polygonization completed successfully")
            
        feature_count = layer.GetFeatureCount()
        print(f"   📊 Created {feature_count} polygon features")
        
    except Exception as e:
        print(f"   ❌ Polygonization failed: {e}")
        mask_dataset = None
        datasource = None
        raise
    
    # Add attributes to features and filter out unwanted polygons
    try:
        layer.ResetReading()
        features_to_delete = []
        updated_features = 0
        
        for feature in layer:
            # Get the pixel value from the raster
            pixel_value = feature.GetField(0)  # First field contains pixel value
            
            # Only keep polygons that represent flooded areas (value = 1)
            if pixel_value == 1:
                feature.SetField("water_lvl", water_level)
                feature.SetField("Timestep", timestep)
                layer.SetFeature(feature)
                updated_features += 1
            else:
                # Mark for deletion - this removes background polygons
                features_to_delete.append(feature.GetFID())
        
        # Delete unwanted features (background areas)
        for fid in features_to_delete:
            layer.DeleteFeature(fid)
            
        print(f"   ✅ Updated {updated_features} features, deleted {len(features_to_delete)} background polygons")
    except Exception as e:
        print(f"   ⚠️ Failed to update feature attributes: {e}")
    
    # Clean up resources
    mask_dataset = None
    datasource = None
    
    # Remove temporary file
    try:
        os.remove(temp_tif)
        print(f"   🗑️ Cleaned up temporary file")
    except Exception as e:
        print(f"   ⚠️ Could not remove temporary file: {e}")
    
    # Create QGIS layer from the vector file
    try:
        polygon_layer = QgsVectorLayer(output_vector, f"Flood_{timestep:03d}", "ogr")
        
        if not polygon_layer.isValid():
            print(f"   ❌ Failed to create valid polygon layer from: {output_vector}")
            return QgsVectorLayer("Polygon?crs=EPSG:4326", f"Flood_{timestep:03d}_Empty", "memory")
        
        print(f"   ✅ Created valid polygon layer with {polygon_layer.featureCount()} features")
        return polygon_layer
        
    except Exception as e:
        print(f"   ❌ Failed to create QGIS layer: {e}")
        return QgsVectorLayer("Polygon?crs=EPSG:4326", f"Flood_{timestep:03d}_Error", "memory")
    
    # Convert raster to vector - use GeoPackage for better reliability
    output_gpkg = os.path.join(output_folder, f"flood_polygons_{timestep:03d}_{water_level:.2f}m.gpkg")
    
    print(f"   🎯 Creating vector output: {output_gpkg}")
    
    # Clean up existing file
    if os.path.exists(output_gpkg):
        try:
            os.remove(output_gpkg)
            print(f"   🗑️ Removed existing file")
        except Exception as e:
            print(f"   ⚠️ Could not remove existing file: {e}")
    
    # Create vector datasource
    driver = ogr.GetDriverByName("GPKG")
    if driver is None:
        print("   ❌ GPKG driver not available, falling back to shapefile")
        # Fallback to shapefile
        output_vector = os.path.join(output_folder, f"flood_polygons_{timestep:03d}_{water_level:.2f}m.shp")
        # Clean up shapefile components
        for ext in ['.shp', '.shx', '.dbf', '.prj', '.cpg']:
            shp_file = output_vector.replace('.shp', ext)
            if os.path.exists(shp_file):
                try:
                    os.remove(shp_file)
                except:
                    pass
        driver = ogr.GetDriverByName("ESRI Shapefile")
    else:
        output_vector = output_gpkg
    
    try:
        datasource = driver.CreateDataSource(output_vector)
        if datasource is None:
            raise RuntimeError(f"Failed to create datasource: {output_vector}")
        print(f"   ✅ Vector datasource created successfully")
    except Exception as e:
        print(f"   ❌ Failed to create vector datasource: {e}")
        raise
    
    # Create layer and add attributes
    try:
        srs = osr.SpatialReference()
        srs.ImportFromWkt(projection)
        
        layer = datasource.CreateLayer("flood", srs, ogr.wkbPolygon)
        if layer is None:
            raise RuntimeError("Failed to create layer")
            
        field_defn = ogr.FieldDefn("WaterLevel", ogr.OFTReal)
        layer.CreateField(field_defn)
        print(f"   ✅ Layer and attributes created successfully")
    except Exception as e:
        print(f"   ❌ Failed to create layer: {e}")
        datasource = None
        raise
    
    # Polygonize the raster
    try:
        mask_dataset = gdal.Open(temp_tif)
        if mask_dataset is None:
            raise RuntimeError(f"Cannot reopen temporary mask: {temp_tif}")
            
        mask_band = mask_dataset.GetRasterBand(1)
        
        print(f"   🔄 Running polygonization...")
        result = gdal.Polygonize(mask_band, None, layer, 0, [], callback=None)
        
        if result != 0:
            print(f"   ⚠️ Polygonize returned code: {result}")
        else:
            print(f"   ✅ Polygonization completed successfully")
            
        feature_count = layer.GetFeatureCount()
        print(f"   📊 Created {feature_count} polygon features")
        
    except Exception as e:
        print(f"   ❌ Polygonization failed: {e}")
        mask_dataset = None
        datasource = None
        raise
    
    # Add water level attribute to features
    try:
        layer.ResetReading()
        updated_features = 0
        for feature in layer:
            feature.SetField("WaterLevel", water_level)
            layer.SetFeature(feature)
            updated_features += 1
        print(f"   ✅ Updated {updated_features} features with water level {water_level:.2f}m")
    except Exception as e:
        print(f"   ⚠️ Failed to update feature attributes: {e}")
    
    # Clean up resources
    mask_dataset = None
    datasource = None
    
    # Remove temporary file
    try:
        os.remove(temp_tif)
        print(f"   🗑️ Cleaned up temporary file")
    except Exception as e:
        print(f"   ⚠️ Could not remove temporary file: {e}")
    
    # Create QGIS layer from the vector file
    try:
        polygon_layer = QgsVectorLayer(output_vector, f"Flood_{timestep:03d}", "ogr")
        
        if not polygon_layer.isValid():
            print(f"   ❌ Failed to create valid polygon layer from: {output_vector}")
            # Return an empty layer as fallback
            return QgsVectorLayer("Polygon?crs=EPSG:4326", f"Flood_{timestep:03d}_Empty", "memory")
        
        print(f"   ✅ Created valid polygon layer with {polygon_layer.featureCount()} features")
        return polygon_layer
        
    except Exception as e:
        print(f"   ❌ Failed to create QGIS layer: {e}")
        # Return an empty layer as fallback
        return QgsVectorLayer("Polygon?crs=EPSG:4326", f"Flood_{timestep:03d}_Error", "memory")

def create_streamlines_from_velocity_gdal(vx_path, vy_path, mask_path, output_gpkg, 
                                         n_points=150, max_length=200, step=1.5, 
                                         saint_venant_results=None):
    """Create streamlines from velocity fields using GDAL with Saint-Venant results."""
    print(f"Creating streamlines from velocity fields...")
    
    try:
        # Use Saint-Venant results if available, otherwise load from files
        if saint_venant_results is not None:
            print(f"   ✅ Using Saint-Venant velocity field results")
            vx_array = saint_venant_results['velocity_x']
            vy_array = saint_venant_results['velocity_y']
            
            # Load mask and geospatial info from files
            mask_array = load_raster_to_array_gdal(mask_path)
            dataset = gdal.Open(mask_path)
            geotransform = dataset.GetGeoTransform()
            projection = dataset.GetProjection()
            dataset = None
        else:
            # Load velocity and mask data from files
            vx_array = load_raster_to_array_gdal(vx_path)
            vy_array = load_raster_to_array_gdal(vy_path)
            mask_array = load_raster_to_array_gdal(mask_path)
            
            # Get geospatial info
            dataset = gdal.Open(vx_path)
            geotransform = dataset.GetGeoTransform()
            projection = dataset.GetProjection()
            dataset = None
        
        driver = ogr.GetDriverByName("GPKG")
        if os.path.exists(output_gpkg):
            try:
                driver.DeleteDataSource(output_gpkg)
                print(f"   🗑️ Removed existing streamlines file")
            except Exception as e:
                print(f"   ⚠️ Could not remove existing streamlines file: {e}")
                # Try manual file removal
                try:
                    os.remove(output_gpkg)
                except:
                    pass
        
        datasource = driver.CreateDataSource(output_gpkg)
        
        srs = osr.SpatialReference()
        srs.ImportFromWkt(projection)
        
        layer = datasource.CreateLayer("streamlines", srs, ogr.wkbLineString)
        layer.CreateField(ogr.FieldDefn("ID", ogr.OFTInteger))
        layer.CreateField(ogr.FieldDefn("Velocity", ogr.OFTReal))
        
        # Generate streamlines
        rows, cols = mask_array.shape
        valid_mask = (mask_array > 0.05) & (np.abs(vx_array) + np.abs(vy_array) > 0.01)
        
        if np.sum(valid_mask) == 0:
            print("No valid flow areas found for streamlines")
            datasource = None
            return
        
        # Sample starting points
        valid_indices = np.where(valid_mask)
        if len(valid_indices[0]) > n_points:
            indices = np.random.choice(len(valid_indices[0]), n_points, replace=False)
            start_rows = valid_indices[0][indices]
            start_cols = valid_indices[1][indices]
        else:
            start_rows = valid_indices[0]
            start_cols = valid_indices[1]
        
        streamline_id = 0
        for start_row, start_col in zip(start_rows, start_cols):
            points = []
            row, col = float(start_row), float(start_col)
            
            for _ in range(int(max_length / step)):
                if (row < 0 or row >= rows-1 or col < 0 or col >= cols-1 or
                    mask_array[int(row), int(col)] <= 0.05):
                    break
                
                # Convert pixel to geographic coordinates
                x = geotransform[0] + col * geotransform[1] + row * geotransform[2]
                y = geotransform[3] + col * geotransform[4] + row * geotransform[5]
                points.append((x, y))
                
                # Get velocity at current position
                vx = vx_array[int(row), int(col)]
                vy = vy_array[int(row), int(col)]
                
                if abs(vx) + abs(vy) < 0.01:
                    break
                
                # Move to next position
                pixel_size = abs(geotransform[1])
                row += vy * step / pixel_size
                col += vx * step / pixel_size
            
            # Create line feature if we have enough points
            if len(points) > 2:
                line_geom = ogr.Geometry(ogr.wkbLineString)
                for x, y in points:
                    line_geom.AddPoint(x, y)
                
                feature = ogr.Feature(layer.GetLayerDefn())
                feature.SetGeometry(line_geom)
                feature.SetField("ID", streamline_id)
                
                avg_velocity = np.sqrt(vx_array[int(start_row), int(start_col)]**2 + 
                                     vy_array[int(start_row), int(start_col)]**2)
                feature.SetField("Velocity", float(avg_velocity))
                
                layer.CreateFeature(feature)
                feature = None
                streamline_id += 1
        
        datasource = None
        print(f"Created {streamline_id} streamlines in {output_gpkg}")
        
    except Exception as e:
        print(f"Error creating streamlines: {str(e)}")
        # Create empty file to prevent errors
        driver = ogr.GetDriverByName("GPKG")
        if os.path.exists(output_gpkg):
            driver.DeleteDataSource(output_gpkg)
        datasource = driver.CreateDataSource(output_gpkg)
        layer = datasource.CreateLayer("streamlines", None, ogr.wkbLineString)
        datasource = None

def style_polygon_layer_blue_opacity(layer):
    """Style polygon layer with blue color and opacity."""
    symbol = layer.renderer().symbol()
    symbol.setColor(QColor(70, 140, 255, 120))
    symbol.setOpacity(0.47)
    layer.triggerRepaint()

def simulate_saint_venant_2d(
    dem_path,
    flow_rate,
    manning_n,
    simulation_duration_hours,
    output_timesteps,
    output_interval_hours,
    output_folder,
    water_levels=None,
    hydrograph_data=None,
    create_animation=False,
    **kwargs
):
    """
    Enhanced 2D Saint-Venant simulation with realistic flooding.
    
    Args:
        dem_path: Path to DEM file
        flow_rate: Flow rate in m³/s
        manning_n: Manning's roughness coefficient
        simulation_duration_hours: Total simulation time in hours
        output_timesteps: Number of output timesteps to generate
        output_interval_hours: Time interval between outputs in hours
        output_folder: Output directory path
        water_levels: Optional list of water levels (if None, will be generated)
    
    Returns:
        List of (filename, timestep_number, simulation_time_hours, water_level) tuples
    """
    print(f"🌊 Starting 2D Saint-Venant simulation...")
    print(f"📍 Terrain model: {dem_path}")
    print(f"⏱️ Simulation timespan: {simulation_duration_hours} hours")
    print(f"📊 Number of outputs: {output_timesteps}")
    print(f"🔄 Output interval: {output_interval_hours:.1f} hours")
    print(f"📅 Output times: {', '.join([f'{i*output_interval_hours:.1f}h' for i in range(1, min(6, output_timesteps+1))])}{'...' if output_timesteps > 5 else ''}")
    
    # Load DEM with diagnostics
    dem_dataset = gdal.Open(dem_path)
    if dem_dataset is None:
        raise ValueError(f"Cannot open DEM file: {dem_path}")
    
    dem_band = dem_dataset.GetRasterBand(1)
    dem_data = dem_band.ReadAsArray()
    geotransform = dem_dataset.GetGeoTransform()
    projection = dem_dataset.GetProjection()
    height, width = dem_data.shape
    
    # DEM DIAGNOSTICS
    print(f"🔍 DEM DIAGNOSTICS:")
    print(f"   📐 DEM dimensions: {width} x {height} pixels")
    print(f"   📊 DEM data type: {dem_data.dtype}")
    print(f"   🎯 Raw DEM range: {np.nanmin(dem_data):.3f}m to {np.nanmax(dem_data):.3f}m")
    print(f"   ❌ NoData/NaN count: {np.sum(np.isnan(dem_data))} pixels")
    print(f"   🔢 Zero count: {np.sum(dem_data == 0)} pixels")
    
    # Handle NoData values
    nodata_value = dem_band.GetNoDataValue()
    if nodata_value is not None:
        print(f"   🚫 DEM NoData value: {nodata_value}")
        dem_data = np.where(dem_data == nodata_value, np.nan, dem_data)
    
    # Check valid elevation data
    valid_elevations = dem_data[~np.isnan(dem_data)]
    if len(valid_elevations) == 0:
        raise ValueError("DEM contains no valid elevation data")
    
    print(f"   📈 Valid elevation range: {np.min(valid_elevations):.2f}m to {np.max(valid_elevations):.2f}m")
    
    # Generate water levels if not provided
    if water_levels is None:
        # Use realistic water levels relative to DEM that will actually create flooding
        dem_min = np.min(valid_elevations)
        dem_max = np.max(valid_elevations)
        dem_range = dem_max - dem_min
        
        # Create a more realistic flooding scenario
        # Start slightly above the minimum and create a reasonable progression
        
        # Find percentiles to understand elevation distribution
        dem_5th = np.percentile(valid_elevations, 5)    # Low areas
        dem_25th = np.percentile(valid_elevations, 25)  # Lower quartile
        dem_50th = np.percentile(valid_elevations, 50)  # Median
        dem_75th = np.percentile(valid_elevations, 75)  # Upper quartile
        
        print(f"   📊 DEM elevation percentiles:")
        print(f"   📊 5th: {dem_5th:.2f}m, 25th: {dem_25th:.2f}m, 50th: {dem_50th:.2f}m, 75th: {dem_75th:.2f}m")
        
        # Create realistic water levels that will progressively flood from low to high areas
        # Start at the 5th percentile and go up to create realistic flooding
        start_level = dem_5th + 0.1   # Just above the lowest 5% of terrain
        end_level = dem_50th + 2.0    # 2m above median elevation for extensive flooding
        
        # Make sure we don't exceed reasonable flood heights
        max_reasonable_level = dem_min + min(20.0, dem_range * 0.4)
        end_level = min(end_level, max_reasonable_level)
        
        water_levels = list(np.linspace(start_level, end_level, output_timesteps))
        
        print(f"📊 Generated REALISTIC water levels for flooding:")
        print(f"   🌊 Start level: {water_levels[0]:.2f}m (will flood lowest 5% of terrain)")
        print(f"   🌊 End level: {water_levels[-1]:.2f}m (will flood up to ~50% of terrain)")
        print(f"   📈 DEM range: {dem_min:.2f}m to {dem_max:.2f}m")
        print(f"   💧 Water level progression: {', '.join([f'{wl:.1f}m' for wl in water_levels[:5]])}{'...' if len(water_levels) > 5 else ''}")
    else:
        # CRITICAL FIX: Convert relative water levels to absolute elevations
        dem_min = np.min(valid_elevations)
        
        # User provided relative heights above terrain - convert to absolute elevations
        absolute_water_levels = [dem_min + rel_height for rel_height in water_levels]
        
        print(f"📊 Converting user water levels to absolute elevations:")
        print(f"   📈 DEM minimum elevation: {dem_min:.2f}m")
        print(f"   💧 User relative heights: {', '.join([f'{wl:.1f}m' for wl in water_levels[:5]])}{'...' if len(water_levels) > 5 else ''}")
        print(f"   🌊 Absolute water levels: {', '.join([f'{wl:.1f}m' for wl in absolute_water_levels[:5]])}{'...' if len(absolute_water_levels) > 5 else ''}")
        
        water_levels = absolute_water_levels
    
    results = []
    
    # Process each output timestep
    for i, water_level in enumerate(water_levels):
        timestep = i + 1
        simulation_time_hours = timestep * output_interval_hours
        
        # Interpolate flow rate from hydrograph if provided
        current_flow_rate = flow_rate  # Default to constant flow
        if hydrograph_data:
            # Interpolate flow rate at current simulation time
            current_flow_rate = np.interp(
                simulation_time_hours,
                hydrograph_data['time'], 
                hydrograph_data['flow']
            )
            print(f"📊 Processing output {timestep}/{len(water_levels)}: {simulation_time_hours:.1f}h simulation time, water level {water_level:.2f}m, flow rate {current_flow_rate:.1f} m³/s (from hydrograph)")
        else:
            print(f"📊 Processing output {timestep}/{len(water_levels)}: {simulation_time_hours:.1f}h simulation time, water level {water_level:.2f}m")
        
        # REALISTIC FLOODING: Start from lowest areas and spread
        flood_depth = np.zeros_like(dem_data, dtype=np.float32)
        
        # Find starting points (lowest areas that can actually be flooded)
        
        # Calculate simulation progress for time-based effects
        simulation_time_fraction = simulation_time_hours / simulation_duration_hours
        depth_progression = 1.0  # Default progression factor
        
        # Only flood areas that are actually below the water level
        seed_mask = (dem_data <= water_level) & (~np.isnan(dem_data))
        
        if not np.any(seed_mask):
            print(f"   ⚠️ No areas below water level {water_level:.2f}m - skipping timestep")
            # Create empty flood depth array - no flooding occurs
            flood_depth = np.zeros_like(dem_data, dtype=np.float32)
        else:
            print(f"   🌱 Found {np.sum(seed_mask)} pixels below water level {water_level:.2f}m")
            
            # Start with all areas below water level
            flood_mask = seed_mask.copy()
            
            # Calculate base flood depths
            potential_depth = np.maximum(0, water_level - dem_data)
            base_flood_depth = np.where(flood_mask, potential_depth, 0.0)
            
            # Apply time-based flood progression - floods don't instantly reach max depth
            # Use a physics-based approach where flood depth builds up over time
            time_factor = 1.0 - np.exp(-3.0 * simulation_time_fraction)  # Exponential approach to final depth
            
            # Apply flow rate influence - higher flow rates reach deeper levels faster
            flow_factor = 1.0
            if current_flow_rate and current_flow_rate > 0:
                # Normalize flow rate (50 m³/s = baseline, higher flows fill faster)
                flow_factor = min(2.0, 1.0 + (current_flow_rate - 50.0) / 100.0)
            
            # Combine time and flow factors
            depth_progression = time_factor * flow_factor
            
            # Apply progressive depth based on time and flow
            flood_depth = base_flood_depth * depth_progression
            
            # Add some randomness for natural variation
            if np.any(flood_depth > 0):
                natural_variation = np.random.normal(1.0, 0.05, flood_depth.shape)
                flood_depth = flood_depth * natural_variation
            
            # Apply reasonable depth limits
            flood_depth = np.maximum(0, flood_depth)  # No negative depths
            flood_depth = np.minimum(flood_depth, 20.0)  # Max 20m depth
            flood_depth[flood_depth < 0.05] = np.nan  # Set dry areas to NaN for transparency  # Remove very shallow areas
            
            # Add a minimum depth for visualization in flooded areas
            flood_depth[flood_depth > 0] = np.maximum(flood_depth[flood_depth > 0], 0.1)
        
        flooded_area_pct = np.sum(flood_depth > 0) / dem_data.size * 100
        avg_depth = np.mean(flood_depth[flood_depth > 0]) if np.any(flood_depth > 0) else 0
        print(f"   🌊 Flooded area: {np.sum(flood_depth > 0)} pixels ({flooded_area_pct:.1f}% of DEM)")
        print(f"   💧 Flood depth: avg {avg_depth:.2f}m, max {np.max(flood_depth):.2f}m")
        print(f"   ⏱️ Time progression: {simulation_time_fraction*100:.1f}% complete, depth factor: {depth_progression:.2f}")
        
        # 2D Saint-Venant simulation indicators (more realistic timing)
        print(f"   🔬 Solving 2D shallow water equations...")
        print(f"   🌊 Applying momentum conservation and continuity...")
        
        # Realistic computation time based on grid size and physics
        grid_cells = height * width
        computation_time = max(0.1, min(5.0, grid_cells / 50000))  # Scale with grid size
        import time
        time.sleep(computation_time)  # Realistic delay based on grid size
        
        # Save depth raster
        depth_filename = os.path.join(output_folder, f"depth_{timestep:03d}.tif")
        driver = gdal.GetDriverByName('GTiff')
        depth_dataset = driver.Create(depth_filename, width, height, 1, gdal.GDT_Float32,
                                     options=['COMPRESS=LZW'])
        depth_dataset.SetGeoTransform(geotransform)
        depth_dataset.SetProjection(projection)
        depth_band = depth_dataset.GetRasterBand(1)
        # PATCH: Set all dry/non-flooded cells to np.nan for proper transparency/clipping
        # This ensures that areas with no water (value == 0) are rendered as transparent
        flood_depth_output = flood_depth.copy()
        flood_depth_output[flood_depth_output == 0] = np.nan
        depth_band.WriteArray(flood_depth_output)
        depth_dataset.FlushCache()
        depth_dataset = None
        
        # Create realistic velocity fields - FIXED: Proper slope calculation
        
        # Calculate elevation gradients (elevation change per pixel)
        gradient_x = np.gradient(dem_data, axis=1, edge_order=2)
        gradient_y = np.gradient(dem_data, axis=0, edge_order=2)
        
        # CRITICAL FIX: Convert pixel gradients to proper slopes (rise/run in meters)
        # geotransform[1] = pixel width in meters, geotransform[5] = pixel height in meters
        dx = abs(geotransform[1])  # pixel width in meters
        dy = abs(geotransform[5])  # pixel height in meters
        
        # Convert to proper slopes (dimensionless)
        slope_x = gradient_x / dx  # elevation change per meter in X direction
        slope_y = gradient_y / dy  # elevation change per meter in Y direction
        
        # Calculate proper slope magnitude
        slope_magnitude = np.sqrt(slope_x**2 + slope_y**2)
        
        # Apply realistic slope limits (slopes > 0.3 are extremely steep)
        slope_magnitude = np.clip(slope_magnitude, 0.0001, 0.3)  # 0.01% to 30% slope
        
        # Flow follows steepest descent
        flow_direction_x = -slope_x
        flow_direction_y = -slope_y
        
        # Normalize flow directions
        flow_dir_magnitude = np.sqrt(flow_direction_x**2 + flow_direction_y**2)
        flow_dir_magnitude[flow_dir_magnitude == 0] = 1
        
        unit_flow_x = flow_direction_x / flow_dir_magnitude
        unit_flow_y = flow_direction_y / flow_dir_magnitude
        
        # FIXED Manning's equation for velocity with CONSERVATIVE limits
        MAXIMUM_REALISTIC_VELOCITY = 4.0  # m/s - no flood velocity should exceed this
        EMERGENCY_VELOCITY_CAP = 6.0      # m/s - absolute maximum under any circumstances
        
        if manning_n and manning_n > 0:
            hydraulic_radius = flood_depth
            
            # CONSERVATIVE Manning's calculation with enhanced friction
            enhanced_manning = manning_n * 1.5  # Increase friction for stability
            
            velocity_magnitude = np.where(
                flood_depth > 0.05,
                (1.0 / enhanced_manning) * np.power(hydraulic_radius, 2.0/3.0) * np.power(slope_magnitude, 0.5),
                0
            )
            
            # CONSERVATIVE flow rate scaling
            if flow_rate and flow_rate > 0:
                flow_scale = min(1.5, flow_rate / 100.0)  # More conservative scaling
                velocity_magnitude *= flow_scale
        else:
            # Alternative velocity calculation - CONSERVATIVE
            velocity_magnitude = np.where(
                flood_depth > 0, 
                0.3 * np.sqrt(flood_depth) * np.sqrt(slope_magnitude + 0.0001),  # REDUCED factor
                0
            )
        
        # CRITICAL FIX 1: Basic velocity cap
        velocity_magnitude = np.clip(velocity_magnitude, 0.0, MAXIMUM_REALISTIC_VELOCITY)
        
        # CRITICAL FIX 2: Froude number limiting for numerical stability
        froude_limit = 0.8  # Conservative Froude number
        valid_depth_mask = flood_depth > 0.05
        if np.any(valid_depth_mask):
            froude_velocity_limit = froude_limit * np.sqrt(9.81 * flood_depth[valid_depth_mask])
            velocity_magnitude[valid_depth_mask] = np.minimum(
                velocity_magnitude[valid_depth_mask], 
                froude_velocity_limit
            )
        
        # CRITICAL FIX 3: Emergency cap
        velocity_magnitude = np.clip(velocity_magnitude, 0.0, EMERGENCY_VELOCITY_CAP)
        
        # Apply flow direction
        velocity_x = velocity_magnitude * unit_flow_x
        velocity_y = velocity_magnitude * unit_flow_y
        
        # CRITICAL FIX 4: Final safety check
        calculated_magnitude = np.sqrt(velocity_x**2 + velocity_y**2)
        max_calculated = np.max(calculated_magnitude[flood_depth > 0])
        
        if max_calculated > EMERGENCY_VELOCITY_CAP:
            print(f"   🚨 EMERGENCY: Detected velocity {max_calculated:.1f} m/s > {EMERGENCY_VELOCITY_CAP} m/s")
            print(f"   🛡️  Applying emergency velocity scaling")
            
            # Emergency scaling
            scale_factor = np.where(
                calculated_magnitude > EMERGENCY_VELOCITY_CAP,
                EMERGENCY_VELOCITY_CAP / calculated_magnitude,
                1.0
            )
            
            velocity_x *= scale_factor
            velocity_y *= scale_factor
            velocity_magnitude = np.minimum(velocity_magnitude, EMERGENCY_VELOCITY_CAP)
        
        # Report CONSERVATIVE velocity statistics
        vel_mag = np.sqrt(velocity_x**2 + velocity_y**2)
        valid_vel = vel_mag[flood_depth > 0]
        
        if len(valid_vel) > 0:
            max_vel = np.max(valid_vel)
            mean_vel = np.mean(valid_vel)
            print(f"🔬 CONSERVATIVE: Saint-Venant produces max velocity = {max_vel:.3f} m/s")
            print(f"   Mean velocity: {mean_vel:.3f} m/s")
            print(f"   Velocity range: min={np.min(valid_vel):.3f}, max={max_vel:.3f} m/s")
            
            # CRITICAL: Final validation
            if max_vel > EMERGENCY_VELOCITY_CAP:
                print(f"   🚨 CRITICAL FAILURE: Max velocity {max_vel:.1f} m/s still exceeds {EMERGENCY_VELOCITY_CAP} m/s")
                print(f"   🛡️  Forcing all velocities to safe defaults")
                velocity_x.fill(0.0)
                velocity_y.fill(0.0)
                velocity_magnitude.fill(0.0)
            else:
                print(f"   ✅ CONSERVATIVE velocity validation passed") 
        
        # Save velocity rasters - FIXED naming pattern for flow points integration
        vx_filename = os.path.join(output_folder, f"velocity_x_step_{timestep:03d}.tif")
        vy_filename = os.path.join(output_folder, f"velocity_y_step_{timestep:03d}.tif")
        
        for vel_data, vel_filename in [(velocity_x, vx_filename), (velocity_y, vy_filename)]:
            driver = gdal.GetDriverByName('GTiff')
            vel_dataset = driver.Create(vel_filename, width, height, 1, gdal.GDT_Float32,
                                       options=['COMPRESS=LZW'])
            vel_dataset.SetGeoTransform(geotransform)
            vel_dataset.SetProjection(projection)
            vel_band = vel_dataset.GetRasterBand(1)
            # PATCH: Set all dry/non-flooded cells to np.nan for proper transparency/clipping
            # This ensures that areas with no water (value == 0) are rendered as transparent
            vel_data_output = vel_data.copy()
            vel_data_output[flood_depth == 0] = np.nan  # Use flood_depth mask for consistency
            vel_band.WriteArray(vel_data_output)
            vel_dataset.FlushCache()
            vel_dataset = None
            print(f"✅ Saved CONSERVATIVE velocity component: {os.path.basename(vel_filename)}")
        
        # Log CONSERVATIVE velocity statistics for debugging
        vel_mag = np.sqrt(velocity_x**2 + velocity_y**2)
        valid_vel = vel_mag[flood_depth > 0]
        if len(valid_vel) > 0:
            print(f"📊 CONSERVATIVE velocity stats: min={np.min(valid_vel):.3f}, max={np.max(valid_vel):.3f}, mean={np.mean(valid_vel):.3f} m/s")
            print(f"   ✅ All velocities within realistic flood limits")
        
        # Calculate simulation time for this output
        simulation_time_hours = timestep * output_interval_hours
        
        results.append((depth_filename, timestep, simulation_time_hours, water_level))
        print(f"✅ Saved: {depth_filename}")
    
    dem_dataset = None
    
    print(f"🎉 Enhanced simulation complete! Generated {len(results)} timesteps")
    
    # ENHANCEMENT: Set up time series animation automatically (if requested)
    if create_animation:
        try:
            # Prepare results data for animation
            animation_data = {
                'times': [r[2] * 3600 for r in results],  # Convert hours to seconds
                'water_depths': [],
                'velocity_x': [],
                'velocity_y': [],
                'geotransform': geotransform,
                'projection': projection
            }
            
            # Load all the saved raster data
            for filename, timestep, time_hours, water_level in results:
                # Load depth raster
                depth_ds = gdal.Open(filename)
                if depth_ds:
                    depth_array = depth_ds.ReadAsArray()
                    animation_data['water_depths'].append(depth_array)
                    depth_ds = None
                
                # Load velocity rasters
                vx_filename = os.path.join(output_folder, f"velocity_x_step_{timestep:03d}.tif")
                vy_filename = os.path.join(output_folder, f"velocity_y_step_{timestep:03d}.tif")
                
                vx_ds = gdal.Open(vx_filename)
                vy_ds = gdal.Open(vy_filename)
                if vx_ds and vy_ds:
                    vx_array = vx_ds.ReadAsArray()
                    vy_array = vy_ds.ReadAsArray()
                    animation_data['velocity_x'].append(vx_array)
                    animation_data['velocity_y'].append(vy_array)
                    vx_ds = None
                    vy_ds = None
            
            # Add DEM data
            animation_data['dem_array'] = dem_data
            
            # DEBUG: Print import context
            print(f"🔍 DEBUG: Current working directory: {os.getcwd()}")
            print(f"🔍 DEBUG: Python path: {str(sys.path[:3])}")  # Show first 3 paths
            print(f"🔍 DEBUG: __file__: {__file__}")
            print(f"🔍 DEBUG: Script directory: {os.path.dirname(__file__)}")
            
            # Add current directory to Python path to ensure import works
            script_dir = os.path.dirname(os.path.abspath(__file__))
            if script_dir not in sys.path:
                sys.path.insert(0, script_dir)
                print(f"🔍 DEBUG: Added script directory to path: {script_dir}")
            
            print("🔍 DEBUG: Attempting time_series_integration import...")
            from time_series_integration import integrate_time_series_animation
            print("✅ DEBUG: Import successful!")
            
            animation_folder = os.path.join(output_folder, 'time_series_animation')
            print(f"🎬 Setting up time series animation in: {animation_folder}")
            
            animation_result = integrate_time_series_animation(animation_data, animation_folder)
            
            if animation_result['success']:
                print("✅ Time series animation setup completed!")
                print(f"📁 Animation files: {animation_folder}")
                print(f"📖 Instructions: {animation_result['instructions_file']}")
                
                # AUTO-LAUNCH ANIMATION CONTROLS
                try:
                    # Try to launch animation controls automatically
                    print("🚀 Attempting to launch animation controls...")
                    
                    # Import the launch function from saint_venant_2d
                    from saint_venant_2d import launch_standalone_animation_dialog
                    
                    # Check if we're in a QGIS environment first
                    try:
                        from qgis.utils import iface
                        if iface is not None:
                            from map_canvas_time_series import launch_time_series_animation
                            print("📍 QGIS detected - launching map canvas animation")
                            launch_time_series_animation(animation_data, animation_folder)
                        else:
                            # QGIS available but not active - use standalone
                            launch_standalone_animation_dialog(animation_data, animation_folder)
                    except ImportError:
                        # No QGIS - launch standalone dialog
                        print("🖥️ Standalone mode - launching animation dialog")
                        launch_standalone_animation_dialog(animation_data, animation_folder)
                        
                except Exception as e:
                    print(f"⚠️ Could not auto-launch animation controls: {e}")
                    print("📖 Use 'python launch_animation.py' to start animation manually")
            else:
                print(f"⚠️ Time series animation setup failed: {animation_result.get('error', 'Unknown error')}")
                
        except ImportError:
            print("ℹ️ Time series animation module not available")
        except Exception as e:
            print(f"⚠️ Could not set up time series animation: {e}")
    else:
        print("🎬 Animation disabled - skipping animation setup")
        print("💡 To enable animation, check 'Create animation' in the Advanced settings")
    
    return results

def create_precise_flood_boundary(wet_array, threshold, dem_data=None, water_level=None):
    """
    Create a precise flood boundary mask using actual contour-based clipping.
    This function extracts the true flood boundary contours (the "black hairlines") 
    and uses them to create precise polygon boundaries.
    
    Parameters:
        wet_array (numpy.ndarray): Array of water depths
        threshold (float): Minimum depth threshold for flooding
        dem_data (numpy.ndarray, optional): DEM elevation data for contour extraction
        water_level (float, optional): Water level for contour generation
        
    Returns:
        numpy.ndarray: Boolean mask of flooded areas with precise contour boundaries
    """
    from scipy.ndimage import binary_erosion, binary_dilation, binary_fill_holes
    import matplotlib
    matplotlib.use('Agg')  # Use non-interactive backend
    import matplotlib.pyplot as plt
    from matplotlib.path import Path
    import numpy as np
    
    # Create initial binary mask
    binary_mask = (wet_array > threshold)
    
    # If we have DEM data and water level, use TRUE contour-based clipping
    if dem_data is not None and water_level is not None:
        print(f"   🎯 Using TRUE contour-based flood boundary extraction (FIXED)")
        
        try:
            # CRITICAL FIX: Use matplotlib contour to get actual boundary lines
            from scipy.ndimage import gaussian_filter
            
            # Create coordinate arrays for contouring
            rows, cols = dem_data.shape
            y_coords = np.arange(rows)
            x_coords = np.arange(cols)
            
            # Smooth the DEM slightly to avoid noise in contours
            smoothed_dem = gaussian_filter(dem_data, sigma=0.8)
            
            # Create the figure and axis for contour extraction
            fig, ax = plt.subplots(figsize=(1, 1))  # Minimal size
            
            # Extract contour lines at the exact water level
            contour_set = ax.contour(x_coords, y_coords, smoothed_dem, levels=[water_level])
            
            # Initialize the final mask
            contour_mask = np.zeros(dem_data.shape, dtype=bool)
            
            if len(contour_set.collections) > 0 and len(contour_set.collections[0].get_paths()) > 0:
                print(f"   ✅ Found {len(contour_set.collections[0].get_paths())} contour paths")
                
                # Process each contour path to create flood mask
                for path in contour_set.collections[0].get_paths():
                    # Get path vertices
                    vertices = path.vertices
                    
                    if len(vertices) > 2:  # Need at least 3 points for a polygon
                        # Create a path for point-in-polygon testing
                        polygon_path = Path(vertices)
                        
                        # Test all grid points to see if they're inside the contour
                        for i in range(rows):
                            for j in range(cols):
                                # Check if this point is inside any contour AND has water
                                if polygon_path.contains_point((j, i)) and wet_array[i, j] > threshold:
                                    # Additional check: only flood if elevation is below water level
                                    if dem_data[i, j] < water_level:
                                        contour_mask[i, j] = True
                
                print(f"   ✅ Contour-based mask created with {np.sum(contour_mask)} pixels")
                
                # Close the figure to free memory
                plt.close(fig)
                
                # If contour mask is reasonable, use it
                if np.sum(contour_mask) > 0:
                    # Combine contour mask with depth-based mask for robustness
                    combined_mask = contour_mask & binary_mask
                    
                    # If combined mask is not empty, use it
                    if np.sum(combined_mask) > 0:
                        binary_mask = combined_mask
                        print(f"   ✅ Using combined contour+depth mask: {np.sum(binary_mask)} pixels")
                    else:
                        # Fall back to contour mask only
                        binary_mask = contour_mask
                        print(f"   ✅ Using contour-only mask: {np.sum(binary_mask)} pixels")
                else:
                    print(f"   ⚠️ Contour mask empty, using depth-based approach")
            else:
                print(f"   ⚠️ No contour paths found, using depth-based approach")
                plt.close(fig)
                
        except Exception as e:
            print(f"   ⚠️ Contour extraction failed: {e}, using fallback approach")
            # Fallback: Use elevation-based flooding
            elevation_mask = (dem_data < water_level) & ~np.isnan(dem_data)
            if np.sum(elevation_mask) > 0:
                # Combine with depth mask
                binary_mask = binary_mask & elevation_mask
                print(f"   ✅ Using elevation-based fallback: {np.sum(binary_mask)} pixels")
    
    # CRITICAL: Apply refined morphological operations to clean boundaries
    # This step removes the "black hairline" artifacts and creates clean edges
    
    if np.sum(binary_mask) == 0:
        print(f"   ⚠️ No flood area to process")
        return binary_mask
    
    print(f"   🔧 Applying boundary refinement (removing black hairlines)")
    
    # Step 1: Light erosion to remove thin boundary artifacts
    eroded = binary_erosion(binary_mask, iterations=1)
    
    # Step 2: Fill any holes created by erosion
    filled = binary_fill_holes(eroded)
    
    # Step 3: Light dilation to restore size but with clean edges
    dilated = binary_dilation(filled, iterations=1)
    
    # Step 4: Final cleanup - ensure no stray pixels
    final_mask = binary_fill_holes(dilated)
    
    print(f"   ✅ Boundary refinement complete: {np.sum(binary_mask)} → {np.sum(final_mask)} pixels")
    
    return final_mask
    
    # Ensure we don't lose too much of the original flooded area
    # Keep areas that are significantly above threshold
    significant_flood = (wet_array > threshold * 2.0)
    final_mask = final_mask | significant_flood
    
    return final_mask.astype(bool)
