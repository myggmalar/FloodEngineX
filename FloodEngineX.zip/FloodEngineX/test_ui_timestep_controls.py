#!/usr/bin/env python3
"""Test script to verify timestep controls are working properly in the UI"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

def test_timestep_controls():
    """Test that timestep controls exist and work correctly"""
    
    # Check if the UI file contains the expected timestep controls
    ui_file = os.path.join(os.path.dirname(__file__), 'ui_dialog.py')
    
    print("🔍 Checking UI file for timestep controls...")
    
    with open(ui_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check for new timestep controls
    checks = [
        ('simulation_duration', 'simulation_duration'),
        ('output_timesteps', 'output_timesteps'),
        ('output_interval_label', 'output_interval_label'),
        ('Simuleringstid (timmar)', 'Hours label'),
        ('Antal utgående tidssteg', 'Timesteps label'),
        ('update_output_interval', 'Update function'),
        ('Utskriftsintervall:', 'Interval display')
    ]
    
    found_controls = []
    missing_controls = []
    
    for search_term, description in checks:
        if search_term in content:
            found_controls.append(description)
            print(f"✅ Found: {description}")
        else:
            missing_controls.append(description)
            print(f"❌ Missing: {description}")
    
    print(f"\n📊 Results:")
    print(f"   Found: {len(found_controls)}/{len(checks)} controls")
    print(f"   Missing: {len(missing_controls)}")
    
    # Check for any old time controls that might be conflicting
    old_controls = [
        'time_seconds',
        'time_slider',
        'timestep_slider',
        'seconds_input'
    ]
    
    print(f"\n🔍 Checking for old/conflicting time controls...")
    old_found = []
    for old_control in old_controls:
        if old_control in content:
            old_found.append(old_control)
            print(f"⚠️  Found old control: {old_control}")
    
    if not old_found:
        print("✅ No old time controls found")
    
    # Test the calculation logic
    print(f"\n🧮 Testing calculation logic:")
    try:
        # Simulate calculation
        duration = 24  # hours
        timesteps = 10
        interval = duration / timesteps
        print(f"   Duration: {duration} hours")
        print(f"   Timesteps: {timesteps}")
        print(f"   Calculated interval: {interval} hours")
        
        if interval >= 1.0:
            print(f"   Display: {interval:.1f} timmar")
        else:
            minutes = interval * 60
            print(f"   Display: {minutes:.1f} minuter")
        
        print("✅ Calculation logic working correctly")
    except Exception as e:
        print(f"❌ Calculation error: {e}")
    
    return len(missing_controls) == 0

if __name__ == "__main__":
    print("=== FloodEngine UI Timestep Controls Test ===\n")
    
    success = test_timestep_controls()
    
    if success:
        print("\n🎉 All timestep controls are properly implemented!")
        print("   The UI should show:")
        print("   - Simulation duration in hours")
        print("   - Number of output timesteps")
        print("   - Calculated output interval")
        print("   - Real-time interval updates")
    else:
        print("\n⚠️  Some timestep controls may be missing or not working correctly")
        print("   Check the UI implementation")
    
    print("\nTest completed.")
