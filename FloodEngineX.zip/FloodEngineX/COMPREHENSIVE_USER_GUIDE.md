# FloodEngine v4.0 - Comprehensive User Guide
==================================================

**Date**: June 7, 2025  
**Version**: 4.0 Production Ready  
**Audience**: QGIS Users, Hydraulic Engineers, Emergency Planners  

## Table of Contents

1. [Quick Start Guide](#quick-start-guide)
2. [Installation Instructions](#installation-instructions)
3. [Basic Workflow Tutorial](#basic-workflow-tutorial)
4. [Advanced Features Guide](#advanced-features-guide)
5. [Troubleshooting](#troubleshooting)
6. [Sample Datasets](#sample-datasets)
7. [Technical Reference](#technical-reference)

---

## Quick Start Guide

### What is FloodEngine?
FloodEngine is a professional-grade QGIS plugin for 2D flood modeling using the Saint-Venant shallow water equations. It provides accurate hydraulic modeling capabilities for flood risk assessment, emergency planning, and hydraulic engineering projects.

### Key Capabilities
- ✅ **2D Shallow Water Modeling**: Complete Saint-Venant equation implementation
- ✅ **Timestep Animation**: Progressive flood visualization over time
- ✅ **Advanced Streamlines**: Flow direction analysis and visualization
- ✅ **Dam/Levee Modeling**: Overflow and breach calculations
- ✅ **Swedish Coordinate Systems**: Native SWEREF99 TM support
- ✅ **Real-time Progress**: Live monitoring during simulations

### Typical Use Cases
1. **Flood Risk Assessment**: Determine flood extents for different scenarios
2. **Emergency Planning**: Model evacuation routes and safe zones
3. **Infrastructure Design**: Analyze impacts of proposed developments
4. **Climate Change Studies**: Assess future flood risks under different conditions
5. **Dam Safety Analysis**: Model dam break scenarios and downstream impacts

---

## Installation Instructions

### Prerequisites
- QGIS 3.16 or later (recommended: QGIS 3.22+)
- Windows 10/11 with sufficient RAM (minimum 8GB, recommended 16GB+)
- DEM data in supported formats (GeoTIFF, ASCII)
- Python packages: GDAL, NumPy, SciPy (usually included with QGIS)

### Installation Steps

#### Method 1: Plugin Manager (Recommended)
1. Open QGIS
2. Go to **Plugins → Manage and Install Plugins**
3. Search for "FloodEngine"
4. Click **Install Plugin**
5. Restart QGIS

#### Method 2: Manual Installation
1. Download `FloodEngine_v4.0_Production.zip`
2. Open QGIS
3. Go to **Plugins → Manage and Install Plugins**
4. Click **Install from ZIP**
5. Select the downloaded ZIP file
6. Click **Install Plugin**
7. Restart QGIS

#### Verification
1. Check that FloodEngine appears in the **Plugins** menu
2. Look for the FloodEngine toolbar icon
3. Test opening the FloodEngine dialog

---

## Basic Workflow Tutorial

### Tutorial 1: Simple Flood Simulation

This tutorial demonstrates a basic flood simulation using sample data.

#### Step 1: Prepare Your Data
**Required:**
- DEM file (Digital Elevation Model) in GeoTIFF format
- Output folder for results

**Optional:**
- Bathymetry CSV file with columns: X, Y, Z (coordinates and depth)
- Stream network shapefile
- Soil properties shapefile

#### Step 2: Open FloodEngine
1. Click the FloodEngine toolbar icon or go to **Plugins → FloodEngine → Open Dialog**
2. The FloodEngine dialog opens with **Basic** and **Advanced** tabs

#### Step 3: Configure Basic Settings
**In the Basic tab:**
1. **DEM Path**: Browse and select your elevation raster file
2. **Water Level**: Enter initial water level (e.g., 5.0 meters above mean sea level)
3. **Output Folder**: Choose where to save results
4. **Simulation Type**: Choose "Water Level" for this tutorial

#### Step 4: Optional Enhancements
- **Bathymetry**: Upload CSV file if you have detailed water depth data
- **Stream Burning**: Enable if you want to ensure streams are properly represented
- **Erosion Analysis**: Enable for soil erosion risk assessment

#### Step 5: Run Simulation
1. Click **Run Model**
2. Monitor progress in the QGIS status bar
3. Results will be added to the QGIS map canvas automatically

#### Step 6: Interpret Results
**Output files include:**
- `flood_extent.shp`: Polygon showing flooded areas
- `water_depth.tif`: Raster showing water depth values
- `velocity_magnitude.tif`: Flow velocity information
- `simulation_summary.txt`: Technical details and statistics

---

### Tutorial 2: Timestep Animation

Create animated flood progression over time.

#### Step 1: Advanced Mode Setup
1. Switch to the **Advanced** tab in FloodEngine
2. Configure the same basic inputs as Tutorial 1
3. Enable **Timestep Simulation**

#### Step 2: Timestep Configuration
1. **Number of Timesteps**: Start with 10 for testing
2. **Time Interval**: 30 minutes (0.5 hours) per step
3. **Flow Method**: Choose "Accumulation" for progressive flooding

#### Step 3: Enhanced Features
- **Streamlines**: Enable for flow direction visualization
- **Advanced Engine**: Use Saint-Venant 2D for highest accuracy
- **Output Organization**: Each timestep creates separate layers

#### Step 4: Run and Visualize
1. Click **Run Model**
2. Multiple layers appear in QGIS (Flood Step 1, Flood Step 2, etc.)
3. Use QGIS Time Manager or layer visibility to create animations

---

## Advanced Features Guide

### Saint-Venant 2D Hydraulic Engine

The advanced hydraulic engine provides professional-grade flood modeling using the full 2D shallow water equations.

#### When to Use
- Large-scale flood modeling projects
- Dam break analysis
- Complex terrain with significant flow dynamics
- Research and academic applications

#### Configuration
1. Enable **Advanced Hydraulic Engine** in the Advanced tab
2. Set **CFL Number** (0.1-0.5, lower = more stable)
3. Configure **Manning's Roughness** values
4. Set **Boundary Conditions** as needed

#### Advanced Parameters
- **Time Step**: Automatic adaptive stepping (recommended)
- **Stability Control**: CFL condition enforcement
- **Velocity Limiting**: Prevents unrealistic flow speeds
- **Mass Conservation**: Tracks water volume throughout simulation

### Streamlines and Flow Analysis

#### Purpose
Streamlines show the path water would follow during flooding, essential for:
- Emergency evacuation planning
- Understanding flow patterns
- Identifying critical infrastructure at risk

#### Configuration
1. Enable **Generate Streamlines** in Advanced tab
2. Set **Streamline Density** (default: medium)
3. Choose **Speed Calculation Method**:
   - Manning's equation (recommended)
   - Simplified velocity
   - Constant speed

#### Interpreting Results
- **Line Direction**: Shows flow path
- **Line Color/Width**: Indicates flow speed
- **Line Density**: Shows concentration of flow

### Optimization Features

#### Calculation Area Selection
Reduce computation time by limiting the analysis area:
1. Click **Select Calculation Area**
2. Draw rectangle on map
3. Only selected area will be processed

#### Resolution Control
Balance accuracy vs. speed:
- **Full Resolution**: Best accuracy, slowest
- **Half Resolution (2x)**: Good balance
- **Quarter Resolution (4x)**: Fast preview

---

## Troubleshooting

### Common Issues and Solutions

#### Issue: "DEM file cannot be read"
**Symptoms**: Error message when loading DEM
**Solutions**:
1. Verify file format (must be GeoTIFF, ASCII, or IMG)
2. Check file path contains no special characters
3. Ensure coordinate system is properly defined
4. Try re-projecting DEM to SWEREF99 TM (EPSG:3006)

#### Issue: "No flooding detected"
**Symptoms**: Empty results, no flood polygons
**Solutions**:
1. Check water level is above minimum terrain elevation
2. Verify DEM units match water level units
3. Increase water level incrementally
4. Check for NoData values in DEM

#### Issue: "Simulation runs very slowly"
**Symptoms**: Progress bar moves slowly, high CPU usage
**Solutions**:
1. Use **Select Calculation Area** to limit processing area
2. Reduce resolution using **Resolution Factor**
3. Decrease number of timesteps
4. Close other applications to free memory

#### Issue: "CSV bathymetry import fails"
**Symptoms**: Error when loading bathymetry file
**Solutions**:
1. Verify CSV format: X, Y, Z columns with headers
2. Use comma separators (not semicolons)
3. Remove any text headers beyond column names
4. Ensure coordinates match DEM coordinate system

#### Issue: "Streamlines not generated"
**Symptoms**: No streamline layer appears
**Solutions**:
1. Verify flood extent exists first
2. Check flood layer is valid (not empty)
3. Ensure sufficient water depth for flow calculation
4. Try different streamline density settings

### Performance Tips

#### For Large Datasets
1. **Use Bounding Box**: Limit processing to area of interest
2. **Resolution Reduction**: Use 2x or 4x resolution factor for initial analysis
3. **Incremental Analysis**: Process smaller areas sequentially
4. **Memory Management**: Close unused QGIS layers and applications

#### For Multiple Scenarios
1. **Batch Processing**: Plan multiple runs with different parameters
2. **Result Organization**: Use consistent naming conventions
3. **Data Backup**: Save intermediate results
4. **Documentation**: Keep notes on parameter settings

---

## Sample Datasets

### Included Test Data

FloodEngine includes sample datasets for learning and testing:

#### Dataset 1: Swedish River Valley
- **Location**: Simplified Swedish terrain
- **DEM**: 10m resolution, SWEREF99 TM projection
- **Features**: River channel, floodplain, urban areas
- **Use Case**: Basic flood modeling tutorial

**Files:**
- `sample_dem_sweden.tif`: Elevation model
- `sample_bathymetry.csv`: River depth measurements
- `sample_streams.shp`: Stream network
- `tutorial_instructions.pdf`: Step-by-step guide

#### Dataset 2: Dam Break Scenario
- **Location**: Hypothetical dam and downstream area
- **DEM**: High resolution (2m) elevation model
- **Features**: Dam structure, residential areas, evacuation routes
- **Use Case**: Emergency planning and dam safety analysis

**Files:**
- `dam_break_dem.tif`: Detailed elevation
- `dam_structure.shp`: Dam and infrastructure
- `evacuation_points.shp`: Emergency assembly areas
- `dam_break_tutorial.pdf`: Advanced scenario guide

### Download Locations

**Official Repository:**
- URL: `https://github.com/floodengine/sample-data`
- Download ZIP: Direct download of all sample datasets
- License: Creative Commons Attribution 4.0

**QGIS Plugin Directory:**
- Access through FloodEngine → Sample Data → Download
- Automatic extraction to user data folder
- Integrated tutorial launchers

### Creating Your Own Test Data

#### DEM Requirements
- **Format**: GeoTIFF (.tif) preferred
- **Coordinate System**: Any projected system (SWEREF99 TM recommended for Sweden)
- **Resolution**: 1-25 meters (optimal: 5-10m)
- **Elevation Units**: Meters above sea level
- **NoData Handling**: Proper NoData values set

#### Bathymetry Format
```csv
X,Y,Z
12345.67,6789012.34,-2.5
12346.67,6789012.34,-3.1
12347.67,6789012.34,-3.8
```
- **X,Y**: Coordinates in same system as DEM
- **Z**: Water depth (negative values = below water surface)
- **Headers**: Must include column names
- **Encoding**: UTF-8 text format

---

## Technical Reference

### Coordinate Systems

#### Supported Projections
- **SWEREF99 TM** (EPSG:3006): Recommended for Sweden
- **WGS84 UTM** zones: Global standard
- **National Grid Systems**: Country-specific projections
- **Custom Projections**: Via QGIS project settings

#### Coordinate System Notes
- DEM and bathymetry must use same coordinate system
- Water levels interpreted in DEM elevation units
- Output files inherit DEM coordinate system
- Reprojection handled automatically when possible

### File Formats

#### Input Formats
- **DEM**: GeoTIFF (.tif), IMG (.img), ASCII (.asc)
- **Bathymetry**: CSV (.csv), Text (.txt)
- **Vectors**: Shapefile (.shp), GeoPackage (.gpkg)
- **Parameters**: JSON configuration files

#### Output Formats
- **Rasters**: GeoTIFF with proper NoData handling
- **Vectors**: Shapefile with complete attribute tables
- **Reports**: Plain text with detailed statistics
- **Metadata**: JSON files with processing parameters

### Performance Specifications

#### Typical Processing Times
- **Small area** (1 km²): 1-5 minutes
- **Medium area** (10 km²): 10-30 minutes
- **Large area** (100 km²): 1-3 hours
- **Very large** (1000 km²): 3-12 hours

#### Memory Requirements
- **Base requirement**: 4GB RAM
- **Recommended**: 16GB RAM
- **Large datasets**: 32GB+ RAM
- **Rule of thumb**: 1GB per 100 million DEM cells

#### Disk Space Requirements
- **Input data**: DEM size × 2
- **Working space**: DEM size × 5-10
- **Output data**: DEM size × 3-5
- **Total recommended**: DEM size × 15-20

### Quality Assurance

#### Validation Checks
FloodEngine performs automatic validation:
- **DEM Integrity**: NoData values, coordinate system, resolution
- **Water Level Feasibility**: Comparison with terrain elevation range
- **Memory Availability**: Check sufficient RAM before processing
- **Output Space**: Verify disk space for results

#### Result Validation
Recommended validation steps:
1. **Visual Inspection**: Check flood extent makes physical sense
2. **Volume Conservation**: Verify mass balance in reports
3. **Comparison Studies**: Compare with known flood events
4. **Sensitivity Analysis**: Test with varied parameters

---

## Support and Additional Resources

### Getting Help
- **User Manual**: This comprehensive guide
- **Video Tutorials**: Step-by-step visual guides
- **Community Forum**: User discussions and Q&A
- **Professional Support**: Commercial support options

### Reporting Issues
When reporting problems, include:
1. **FloodEngine Version**: Found in plugin information
2. **QGIS Version**: Help → About in QGIS
3. **Operating System**: Windows version and architecture
4. **Error Messages**: Complete text of any error messages
5. **Data Description**: Size and type of input data
6. **Steps to Reproduce**: Detailed workflow that causes the issue

### Updates and Changelog
- **Automatic Updates**: Through QGIS Plugin Manager
- **Release Notes**: Available with each update
- **Backward Compatibility**: Maintained for configuration files
- **Migration Tools**: Assist upgrading from older versions

---

**© 2025 FloodEngine Development Team**  
**Licensed under GNU General Public License v3.0**  
**Documentation Version: 4.0.1 - June 7, 2025**
