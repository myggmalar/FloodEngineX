#!/usr/bin/env python3
"""
Simple Test for 2D Hydraulic Logic
----------------------------------
Test the core logic of the enhanced 2D hydraulic modeling without requiring GDAL.
"""

import numpy as np
import logging
from scipy.ndimage import gaussian_filter

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def calculate_flow_accumulation(dem_array, valid_mask, dx=10.0, dy=10.0):
    """
    Calculate flow accumulation (upstream contributing area) for 2D hydraulic modeling.
    """
    logger.info("Calculating flow accumulation for 2D hydraulic modeling")
    
    shape = dem_array.shape
    
    # Initialize flow accumulation array
    flow_acc = np.ones(shape, dtype=np.float32)
    
    # Create a list of all valid cells with their elevations
    valid_indices = np.argwhere(valid_mask)
    
    if len(valid_indices) == 0:
        return flow_acc
    
    # Sort cells by elevation (highest to lowest) for proper flow routing
    cell_elevations = []
    for i, j in valid_indices:
        elevation = dem_array[i, j]
        cell_elevations.append((elevation, i, j))
    
    # Sort by elevation (highest first)
    cell_elevations.sort(key=lambda x: x[0], reverse=True)
    
    # Process cells from highest to lowest elevation
    for elevation, i, j in cell_elevations:
        current_acc = flow_acc[i, j]
        
        # Find the steepest downhill neighbor
        max_slope = 0.0
        flow_i, flow_j = i, j
        
        # Check 8 neighbors
        for di in [-1, 0, 1]:
            for dj in [-1, 0, 1]:
                if di == 0 and dj == 0:
                    continue
                
                ni, nj = i + di, j + dj
                
                # Check bounds
                if (0 <= ni < shape[0] and 0 <= nj < shape[1] and 
                    valid_mask[ni, nj]):
                    
                    # Calculate slope to neighbor
                    distance = np.sqrt((di * dx)**2 + (dj * dy)**2)
                    slope = (dem_array[i, j] - dem_array[ni, nj]) / distance
                    
                    # Find steepest downhill slope
                    if slope > max_slope:
                        max_slope = slope
                        flow_i, flow_j = ni, nj
        
        # Route flow to the steepest downhill neighbor
        if flow_i != i or flow_j != j:
            flow_acc[flow_i, flow_j] += current_acc
    
    # Apply smoothing to reduce numerical noise
    flow_acc = gaussian_filter(flow_acc, sigma=1.0)
    
    # Log statistics
    max_acc = np.max(flow_acc[valid_mask])
    mean_acc = np.mean(flow_acc[valid_mask])
    logger.info(f"Flow accumulation: max={max_acc:.1f}, mean={mean_acc:.1f}")
    
    return flow_acc

def calculate_upstream_discharge(flow_accumulation, depth):
    """
    Calculate upstream discharge based on flow accumulation and local conditions.
    """
    # Base discharge calculation
    base_discharge = 0.001 * flow_accumulation
    
    # Adjust based on depth
    if depth > 2.0:  # Deep channels
        depth_factor = 1.5
    elif depth > 1.0:  # Medium channels
        depth_factor = 1.2
    elif depth > 0.5:  # Shallow channels
        depth_factor = 1.0
    else:  # Very shallow areas
        depth_factor = 0.8
    
    # Calculate discharge per unit width
    discharge = base_discharge * depth_factor
    
    # Apply realistic limits
    discharge = min(discharge, 2.0)  # Cap at 2 m²/s per unit width
    discharge = max(discharge, 0.001)  # Minimum discharge
    
    return discharge

def test_2d_hydraulic_logic():
    """Test the core 2D hydraulic logic"""
    
    logger.info("Testing 2D Hydraulic Logic")
    
    # Create a synthetic river system
    rows, cols = 30, 60
    
    # Create a sloping terrain from left to right (upstream to downstream)
    base_elevation = 100.0
    slope = 0.002  # 0.2% slope
    
    dem_array = np.zeros((rows, cols))
    for j in range(cols):
        for i in range(rows):
            # Create a valley cross-section
            # Center of valley (main channel) at row 15
            distance_from_center = abs(i - 15)
            
            # Main channel is deepest, sides are higher
            valley_depth = max(0, 8 - distance_from_center * 0.4)
            
            # Overall downstream slope
            base_elev = base_elevation - j * slope
            
            dem_array[i, j] = base_elev - valley_depth
    
    # Create water depth array
    water_level = base_elevation - 3.0
    water_depth = np.maximum(water_level - dem_array, 0.0)
    water_depth[water_depth < 0.1] = 0.0
    
    # Create valid mask
    valid_mask = water_depth > 0.1
    
    # Calculate flow accumulation
    flow_accumulation = calculate_flow_accumulation(dem_array, valid_mask)
    
    # Test velocity calculation with 2D hydraulic effects
    logger.info("\nTesting velocity calculation with 2D hydraulic effects...")
    
    # Set up parameters
    dx, dy = 10.0, 10.0
    manning_n = 0.035
    
    # Create water surface
    water_surface = dem_array + water_depth
    water_surface_padded = np.pad(water_surface, pad_width=2, mode='edge')
    water_surface_padded = gaussian_filter(water_surface_padded, sigma=1.5)
    
    # Calculate bed slopes
    padded_dem = np.pad(dem_array, pad_width=2, mode='edge')
    
    # Results storage
    velocities = []
    depths = []
    flow_accs = []
    locations = []
    
    # Process a sample of cells
    valid_indices = np.argwhere(valid_mask)
    
    for i, j in valid_indices[::3]:  # Sample every 3rd cell
        depth = water_depth[i, j]
        
        # Calculate bed slope
        bed_dh_dx = (padded_dem[i+2, j+3] - padded_dem[i+2, j+1]) / (2 * dx)
        bed_dh_dy = (padded_dem[i+3, j+2] - padded_dem[i+1, j+2]) / (2 * dy)
        bed_slope_mag = np.sqrt(bed_dh_dx**2 + bed_dh_dy**2)
        
        # Calculate water surface slope
        ws_dh_dx = (water_surface_padded[i+2, j+3] - water_surface_padded[i+2, j+1]) / (2 * dx)
        ws_dh_dy = (water_surface_padded[i+3, j+2] - water_surface_padded[i+1, j+2]) / (2 * dy)
        ws_slope_mag = np.sqrt(ws_dh_dx**2 + ws_dh_dy**2)
        
        # Get flow accumulation
        flow_acc = flow_accumulation[i, j]
        
        # Calculate upstream discharge
        upstream_discharge = calculate_upstream_discharge(flow_acc, depth)
        
        # Enhanced velocity calculation
        if depth > 1.5:  # Main channel
            n_effective = manning_n * 0.6
            channel_factor = 1.5
        elif depth > 0.5:  # Secondary channel
            n_effective = manning_n * 0.8
            channel_factor = 1.2
        else:  # Floodplain
            n_effective = manning_n * 1.2
            channel_factor = 1.0
        
        # Manning's velocity from bed slope
        if bed_slope_mag > 1e-6:
            manning_vel = (1.0 / n_effective) * (depth ** (2/3)) * (bed_slope_mag ** 0.5)
            manning_vel = min(manning_vel, 4.0)
        else:
            manning_vel = 0.0
        
        # Pressure velocity from water surface slope and upstream flow
        if ws_slope_mag > 1e-6:
            pressure_vel = upstream_discharge / (depth * 1.0)
            pressure_vel = min(pressure_vel, 2.0)
        else:
            pressure_vel = 0.0
        
        # Combine velocities
        if bed_slope_mag > 1e-4:  # Steep areas
            vel_magnitude = manning_vel * channel_factor + 0.3 * pressure_vel
        else:  # Gentle areas
            vel_magnitude = 0.3 * manning_vel + pressure_vel * channel_factor
        
        # Apply minimum velocity based on flow accumulation
        min_vel = min(0.05 + 0.02 * np.log10(max(flow_acc, 1)), 0.5)
        vel_magnitude = max(vel_magnitude, min_vel)
        
        # Final cap
        vel_magnitude = min(vel_magnitude, 6.0)
        
        # Store results
        velocities.append(vel_magnitude)
        depths.append(depth)
        flow_accs.append(flow_acc)
        locations.append(abs(i - 15))  # Distance from center channel
    
    # Analyze results
    velocities = np.array(velocities)
    depths = np.array(depths)
    flow_accs = np.array(flow_accs)
    locations = np.array(locations)
    
    # Separate into channel types
    main_channel_mask = (depths > 1.5) & (locations <= 2)
    secondary_mask = (depths > 0.5) & (depths <= 1.5)
    floodplain_mask = depths <= 0.5
    
    logger.info("=== VELOCITY ANALYSIS ===")
    
    if np.any(main_channel_mask):
        main_vel = np.mean(velocities[main_channel_mask])
        logger.info(f"Main Channel: {np.sum(main_channel_mask)} cells, avg velocity: {main_vel:.3f} m/s")
    
    if np.any(secondary_mask):
        secondary_vel = np.mean(velocities[secondary_mask])
        logger.info(f"Secondary Channel: {np.sum(secondary_mask)} cells, avg velocity: {secondary_vel:.3f} m/s")
    
    if np.any(floodplain_mask):
        floodplain_vel = np.mean(velocities[floodplain_mask])
        logger.info(f"Floodplain: {np.sum(floodplain_mask)} cells, avg velocity: {floodplain_vel:.3f} m/s")
    
    # Test flow accumulation effects
    high_acc_mask = flow_accs > np.percentile(flow_accs, 75)
    low_acc_mask = flow_accs < np.percentile(flow_accs, 25)
    
    if np.any(high_acc_mask) and np.any(low_acc_mask):
        high_acc_vel = np.mean(velocities[high_acc_mask])
        low_acc_vel = np.mean(velocities[low_acc_mask])
        logger.info(f"High flow accumulation: avg velocity {high_acc_vel:.3f} m/s")
        logger.info(f"Low flow accumulation: avg velocity {low_acc_vel:.3f} m/s")
        
        if high_acc_vel > low_acc_vel:
            logger.info("✅ PASS: High flow accumulation areas have higher velocities")
        else:
            logger.info("❌ Areas with higher flow accumulation should have higher velocities")
    
    logger.info(f"\nOverall velocity range: {np.min(velocities):.3f} - {np.max(velocities):.3f} m/s")
    
    # Test depth-velocity relationship
    correlation = np.corrcoef(depths, velocities)[0, 1]
    logger.info(f"Depth-velocity correlation: {correlation:.3f}")
    
    if correlation > 0.3:
        logger.info("✅ PASS: Positive correlation between depth and velocity")
    else:
        logger.info("❌ Should have positive correlation between depth and velocity")
    
    logger.info("\n=== 2D HYDRAULIC LOGIC TEST COMPLETE ===")

if __name__ == "__main__":
    test_2d_hydraulic_logic()
