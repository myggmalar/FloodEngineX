#!/usr/bin/env python3
"""
Debug script to identify which method is producing extreme velocities.
This will help us understand if the issue is with Saint-Venant or hydraulic approximation.
"""

import numpy as np
import os
import logging

def debug_velocity_calculation_methods():
    """Debug the velocity calculation methods to identify the source of extreme velocities"""
    
    # Set up logging
    logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
    logger = logging.getLogger("debug_velocity_methods")
    
    logger.info("🔍 Debugging velocity calculation methods...")
    
    # Test 1: Test hydraulic approximation method logic
    logger.info("\n📊 TEST 1: Hydraulic approximation method")
    
    # Simulate typical hydraulic parameters
    depth = 2.0  # 2m depth
    manning_n = 0.035
    bed_slope = 0.001  # 0.1% slope
    flow_accumulation = 100.0  # Moderate flow accumulation
    
    # Calculate Manning velocity
    hydraulic_radius = depth
    manning_vel = (1.0 / manning_n) * (hydraulic_radius ** (2/3)) * (bed_slope ** 0.5)
    
    logger.info(f"  • Manning velocity: {manning_vel:.3f} m/s")
    
    # Calculate upstream discharge
    base_discharge = 0.001 * flow_accumulation
    depth_factor = 1.5  # Deep channel
    discharge = base_discharge * depth_factor
    discharge = min(discharge, 2.0)  # Cap at 2 m²/s
    
    # Pressure velocity
    pressure_vel = discharge / (depth * 1.0)
    pressure_vel = min(pressure_vel, 2.0)  # Cap pressure velocity
    
    logger.info(f"  • Pressure velocity: {pressure_vel:.3f} m/s")
    
    # Channel factor
    channel_factor = 1.5
    
    # Combined velocity
    if bed_slope > 1e-4:
        combined_vel = manning_vel * channel_factor + 0.3 * pressure_vel
    else:
        combined_vel = 0.3 * manning_vel + pressure_vel * channel_factor
    
    logger.info(f"  • Combined velocity: {combined_vel:.3f} m/s")
    
    # Flow concentration bonus
    flow_concentration_bonus = 0.3 + 0.1 * np.log10(max(flow_accumulation, 1))
    final_vel = combined_vel + flow_concentration_bonus
    
    logger.info(f"  • Flow concentration bonus: {flow_concentration_bonus:.3f}")
    logger.info(f"  • Final velocity (before cap): {final_vel:.3f} m/s")
    
    # Final cap
    final_capped_vel = min(final_vel, 6.0)
    logger.info(f"  • Final velocity (after cap): {final_capped_vel:.3f} m/s")
    
    # Test 2: Test with extreme parameters
    logger.info("\n📊 TEST 2: Extreme parameters test")
    
    # Test with unrealistic parameters that might cause issues
    extreme_depth = 10.0  # 10m depth
    extreme_slope = 0.01  # 1% slope (very steep)
    extreme_flow_acc = 10000.0  # Very high flow accumulation
    
    # Calculate with extreme parameters (using the new cap)
    extreme_manning_vel = (1.0 / manning_n) * (extreme_depth ** (2/3)) * (extreme_slope ** 0.5)
    extreme_manning_vel_capped = min(extreme_manning_vel, 3.0)  # Apply our new cap
    logger.info(f"  • Extreme Manning velocity (uncapped): {extreme_manning_vel:.3f} m/s")
    logger.info(f"  • Extreme Manning velocity (capped): {extreme_manning_vel_capped:.3f} m/s")
    
    # Check if capping prevents the issue
    if extreme_manning_vel > 10.0:
        if extreme_manning_vel_capped <= 3.0:
            logger.info(f"  ✅ FIXED: Capping prevents extreme Manning velocity")
        else:
            logger.error(f"  ❌ PROBLEM: Manning velocity {extreme_manning_vel:.1f} m/s is unrealistic!")
            logger.error(f"  🔧 Need to cap Manning velocity calculation")
    
    # Test flow concentration bonus with extreme accumulation (using new cap)
    extreme_bonus = 0.3 + 0.1 * np.log10(max(extreme_flow_acc, 1))
    extreme_bonus_capped = min(extreme_bonus, 0.8)  # Apply our new cap
    logger.info(f"  • Extreme flow concentration bonus (uncapped): {extreme_bonus:.3f}")
    logger.info(f"  • Extreme flow concentration bonus (capped): {extreme_bonus_capped:.3f}")
    
    if extreme_bonus > 1.0:
        if extreme_bonus_capped <= 0.8:
            logger.info(f"  ✅ FIXED: Capping prevents extreme flow concentration bonus")
        else:
            logger.error(f"  ❌ PROBLEM: Flow concentration bonus {extreme_bonus:.1f} is too high!")
            logger.error(f"  🔧 Need to cap flow concentration bonus")
    
    # Test 3: Identify potential issues in the adjustment methods
    logger.info("\n📊 TEST 3: Velocity adjustment methods")
    
    # Test curvature adjustment (using new reduced factor)
    curvature_factor = 1.05  # New reduced factor
    test_velocity = 3.0
    adjusted_vel = test_velocity * curvature_factor
    
    logger.info(f"  • Curvature adjustment: {test_velocity:.1f} m/s → {adjusted_vel:.1f} m/s")
    
    # Test bottleneck adjustment (using new reduced factor)
    bottleneck_factor = 1.1  # New reduced factor
    bottleneck_adjusted_vel = adjusted_vel * bottleneck_factor
    
    logger.info(f"  • Bottleneck adjustment: {adjusted_vel:.1f} m/s → {bottleneck_adjusted_vel:.1f} m/s")
    
    if bottleneck_adjusted_vel > 8.0:
        logger.error(f"  ❌ PROBLEM: After adjustments, velocity {bottleneck_adjusted_vel:.1f} m/s is too high!")
        logger.error(f"  🔧 Adjustment factors are too aggressive")
    else:
        logger.info(f"  ✅ GOOD: After adjustments, velocity {bottleneck_adjusted_vel:.1f} m/s is reasonable")
    
    # Summary
    logger.info("\n🎯 SUMMARY:")
    logger.info("Potential sources of extreme velocities:")
    
    issues_found = []
    
    if extreme_manning_vel > 10.0 and extreme_manning_vel_capped > 3.0:
        issues_found.append("Manning velocity calculation with steep slopes")
    
    if extreme_bonus > 1.0 and extreme_bonus_capped > 0.8:
        issues_found.append("Flow concentration bonus with high accumulation")
    
    if bottleneck_adjusted_vel > 8.0:
        issues_found.append("Velocity adjustment factors are too aggressive")
    
    if issues_found:
        logger.error("❌ Issues found:")
        for issue in issues_found:
            logger.error(f"  • {issue}")
    else:
        logger.info("✅ No obvious issues found in the calculation logic")
    
    return len(issues_found) == 0

if __name__ == "__main__":
    print("=" * 60)
    print("VELOCITY CALCULATION METHOD DEBUGGING")
    print("=" * 60)
    
    success = debug_velocity_calculation_methods()
    
    print("\n" + "=" * 60)
    if success:
        print("✅ No obvious calculation issues found")
        print("🔍 The extreme velocities might be coming from:")
        print("  • Incorrect input data (extreme slopes, depths)")
        print("  • Issues in the adjustment methods")
        print("  • Problems with the Saint-Venant results")
    else:
        print("❌ Found potential calculation issues")
        print("🔧 These need to be fixed to prevent extreme velocities")
    print("=" * 60)
