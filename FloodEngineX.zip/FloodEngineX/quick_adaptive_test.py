#!/usr/bin/env python3
"""
Quick test of adaptive threshold logic
"""
import numpy as np
from collections import deque

print("=== QUICK ADAPTIVE THRESHOLD TEST ===")

# Create simple test DEM
dem = np.array([
    [45, 44, 43, 42, 41],
    [44, 43, 42, 41, 40],
    [43, 42, 41, 40, 39],
    [42, 41, 40, 39, 38],
    [41, 40, 39, 38, 37]
], dtype=np.float32)

valid_mask = np.ones_like(dem, dtype=bool)
water_level = 41.5

print(f"DEM shape: {dem.shape}")
print(f"Elevation range: {dem.min():.1f} to {dem.max():.1f}")
print(f"Water level: {water_level}")

# Test adaptive threshold logic
floodable_mask = valid_mask & (dem < water_level)
floodable_elevations = dem[floodable_mask]

print(f"Floodable cells: {np.sum(floodable_mask)}")
print(f"Floodable elevation range: {floodable_elevations.min():.1f} to {floodable_elevations.max():.1f}")

# Try different percentiles
percentiles = [80, 70, 60, 50]
for pct in percentiles:
    threshold = np.percentile(floodable_elevations, pct)
    start_candidates = np.sum(floodable_mask & (dem >= threshold))
    print(f"{pct}th percentile threshold: {threshold:.2f}m -> {start_candidates} start points")

print("✅ Adaptive threshold logic working!")
print("✅ Test completed successfully!")
