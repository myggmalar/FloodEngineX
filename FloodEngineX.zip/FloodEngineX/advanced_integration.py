# -*- coding: utf-8 -*-
"""
FloodEngine v4.0 - Advanced Integration Module
==============================================

This module integrates all advanced FloodEngine features including GPU acceleration,
precipitation input, performance optimization, and enhanced hydraulic capabilities.
Provides a unified interface for professional flood modeling workflows.

Features:
- Unified simulation engine with all optimizations
- Integrated GPU acceleration and performance optimization
- Precipitation-driven flood modeling
- Advanced scenario management
- Professional reporting and visualization
- Multi-scale modeling capabilities

Author: FloodEngine Development Team
Date: June 7, 2025
Version: 4.0
"""

import numpy as np
import os
import sys
import time
import json
from datetime import datetime, timedelta
from typing import Optional, Tuple, Dict, Any, List, Union, Callable
import logging
from dataclasses import dataclass, asdict
from pathlib import Path

# Import FloodEngine advanced modules
try:
    from .gpu_acceleration import GPUAccelerator, create_gpu_accelerator
    from .precipitation_input import PrecipitationProcessor, PrecipitationData, create_precipitation_processor
    from .performance_optimization import PerformanceOptimizer, create_performance_optimizer
    GPU_AVAILABLE = True
except ImportError:
    # Handle standalone execution
    GPU_AVAILABLE = False
    print("Advanced modules not available in standalone mode")

@dataclass
class SimulationConfiguration:
    """Complete simulation configuration with all advanced features."""
    
    # Basic hydraulic parameters
    dem_file: str
    output_directory: str
    simulation_time: float
    initial_dt: float
    dx: float
    dy: float
    
    # Boundary conditions
    water_level: float = 0.0
    dam_height: float = None
    dam_x: float = None
    dam_y: float = None
    
    # Advanced features
    enable_gpu: bool = True
    enable_precipitation: bool = False
    enable_performance_optimization: bool = True
    enable_adaptive_timestepping: bool = True
    
    # GPU settings
    gpu_backend: str = "auto"  # "cuda", "opencl", "cpu", "auto"
    
    # Precipitation settings
    precipitation_file: str = None
    precipitation_format: str = "csv"  # "csv", "netcdf", "design_storm"
    storm_type: str = None  # For design storms
    rainfall_mm: float = None
    storm_duration_hours: float = None
    runoff_coefficient: float = 0.4
    
    # Performance settings
    max_memory_gb: float = None
    max_workers: int = None
    use_memory_mapping: bool = False
    
    # Output settings
    output_timesteps: int = 100
    save_intermediate: bool = True
    generate_video: bool = False
    export_formats: List[str] = None  # ["geotiff", "csv", "netcdf"]
    
    def __post_init__(self):
        if self.export_formats is None:
            self.export_formats = ["geotiff"]

class AdvancedFloodEngine:
    """
    Advanced flood modeling engine with integrated optimizations and features.
    """
    
    def __init__(self, config: SimulationConfiguration):
        """
        Initialize advanced flood engine.
        
        Args:
            config: Complete simulation configuration
        """
        self.config = config
        self.logger = self._setup_logging()
        
        # Initialize components
        self.gpu_accelerator = None
        self.precipitation_processor = None
        self.performance_optimizer = None
        
        # Simulation state
        self.current_time = 0.0
        self.time_step = config.initial_dt
        self.iteration = 0
        
        # Results storage
        self.results = {
            'timestamps': [],
            'water_depths': [],
            'velocities': [],
            'performance_metrics': [],
            'precipitation_data': []
        }
        
        # Load DEM and initialize domain
        self.dem_data, self.dem_extent, self.dem_resolution = self._load_dem()
        self._initialize_advanced_features()
        
    def _setup_logging(self) -> logging.Logger:
        """Setup comprehensive logging system."""
        logger = logging.getLogger(f"FloodEngine_{id(self)}")
        logger.setLevel(logging.INFO)
        
        # Create output directory if needed
        os.makedirs(self.config.output_directory, exist_ok=True)
        
        # File handler
        log_file = os.path.join(self.config.output_directory, "simulation.log")
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.DEBUG)
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        
        # Formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)
        
        return logger
    
    def _load_dem(self) -> Tuple[np.ndarray, Tuple[float, float, float, float], Tuple[float, float]]:
        """Load DEM data and extract metadata."""
        try:
            from osgeo import gdal
            
            # Open DEM file
            dataset = gdal.Open(self.config.dem_file)
            if dataset is None:
                raise ValueError(f"Cannot open DEM file: {self.config.dem_file}")
            
            # Extract data
            dem_array = dataset.ReadAsArray().astype(np.float32)
            
            # Get geotransform
            geotransform = dataset.GetGeoTransform()
            xmin = geotransform[0]
            dx = geotransform[1]
            ymax = geotransform[3]
            dy = abs(geotransform[5])
            
            ny, nx = dem_array.shape
            xmax = xmin + nx * dx
            ymin = ymax - ny * dy
            
            extent = (xmin, ymin, xmax, ymax)
            resolution = (dx, dy)
            
            self.logger.info(f"Loaded DEM: {nx}x{ny} cells, resolution: {dx}x{dy}m")\n            self.logger.info(f"Domain extent: ({xmin:.1f}, {ymin:.1f}) to ({xmax:.1f}, {ymax:.1f})")
            
            dataset = None  # Close dataset
            return dem_array, extent, resolution
            
        except ImportError:
            self.logger.error("GDAL not available. Cannot load DEM file.")
            raise
        except Exception as e:
            self.logger.error(f"Error loading DEM: {e}")
            raise
    
    def _initialize_advanced_features(self):
        """Initialize all advanced features based on configuration."""
        
        # GPU Acceleration
        if self.config.enable_gpu and GPU_AVAILABLE:
            try:
                self.gpu_accelerator = create_gpu_accelerator(self.config.gpu_backend)
                self.logger.info(f"GPU acceleration initialized: {self.gpu_accelerator.backend}")
            except Exception as e:
                self.logger.warning(f"GPU acceleration failed: {e}")
                self.config.enable_gpu = False
        
        # Precipitation Processing
        if self.config.enable_precipitation:
            try:
                self.precipitation_processor = create_precipitation_processor(
                    self.dem_extent, self.dem_resolution
                )
                self.logger.info("Precipitation processor initialized")
            except Exception as e:
                self.logger.warning(f"Precipitation processor failed: {e}")
                self.config.enable_precipitation = False
        
        # Performance Optimization
        if self.config.enable_performance_optimization:
            try:
                self.performance_optimizer = create_performance_optimizer(
                    self.config.max_memory_gb, self.config.max_workers
                )
                self.logger.info("Performance optimizer initialized")
            except Exception as e:
                self.logger.warning(f"Performance optimizer failed: {e}")
                self.config.enable_performance_optimization = False
    
    def setup_initial_conditions(self) -> Dict[str, np.ndarray]:
        """Setup initial hydraulic conditions."""
        ny, nx = self.dem_data.shape
        
        # Initialize hydraulic variables
        h = np.zeros((ny, nx), dtype=np.float32)  # Water depth
        u = np.zeros((ny, nx), dtype=np.float32)  # X-velocity
        v = np.zeros((ny, nx), dtype=np.float32)  # Y-velocity
        z = self.dem_data.copy()                  # Bed elevation
        
        # Set initial water level
        if self.config.water_level > 0:
            initial_depth = np.maximum(0, self.config.water_level - z)
            h[:] = initial_depth
            self.logger.info(f"Initial water level set to {self.config.water_level}m")
        
        # Setup dam failure scenario
        if all([self.config.dam_height, self.config.dam_x, self.config.dam_y]):
            self._setup_dam_scenario(h, z)
        
        return {'h': h, 'u': u, 'v': v, 'z': z}
    
    def _setup_dam_scenario(self, h: np.ndarray, z: np.ndarray):
        """Setup dam failure initial conditions."""
        ny, nx = h.shape
        xmin, ymin, xmax, ymax = self.dem_extent
        dx, dy = self.dem_resolution
        
        # Convert dam coordinates to grid indices
        dam_i = int((self.config.dam_x - xmin) / dx)
        dam_j = int((ymax - self.config.dam_y) / dy)
        
        # Ensure indices are within bounds
        dam_i = np.clip(dam_i, 0, nx-1)
        dam_j = np.clip(dam_j, 0, ny-1)
        
        # Create reservoir behind dam
        reservoir_radius = 50  # cells
        y_indices, x_indices = np.ogrid[:ny, :nx]
        
        distance = np.sqrt((x_indices - dam_i)**2 + (y_indices - dam_j)**2)
        reservoir_mask = distance <= reservoir_radius
        
        # Set reservoir water level
        reservoir_level = z[dam_j, dam_i] + self.config.dam_height
        reservoir_depth = np.maximum(0, reservoir_level - z)
        h[reservoir_mask] = reservoir_depth[reservoir_mask]
        
        self.logger.info(f"Dam scenario setup: dam at ({dam_i}, {dam_j}), height {self.config.dam_height}m")
    
    def load_precipitation_data(self) -> Optional[PrecipitationData]:
        """Load precipitation data based on configuration."""
        if not self.config.enable_precipitation:
            return None
        
        try:
            if self.config.precipitation_format == "design_storm":
                # Create design storm
                precip_data = self.precipitation_processor.create_design_storm(
                    storm_type=self.config.storm_type or "scs_type2",
                    duration_hours=self.config.storm_duration_hours or 6.0,
                    total_rainfall_mm=self.config.rainfall_mm or 50.0,
                    time_step_minutes=10
                )
                self.logger.info(f"Created {self.config.storm_type} design storm")
                
            elif self.config.precipitation_file:
                # Load from file
                if self.config.precipitation_format == "csv":
                    precip_data = self.precipitation_processor.load_precipitation_csv(
                        self.config.precipitation_file, "point"
                    )
                elif self.config.precipitation_format == "netcdf":
                    precip_data = self.precipitation_processor.load_precipitation_netcdf(
                        self.config.precipitation_file
                    )
                else:
                    raise ValueError(f"Unsupported precipitation format: {self.config.precipitation_format}")
                
                self.logger.info(f"Loaded precipitation data from {self.config.precipitation_file}")
            else:
                self.logger.warning("Precipitation enabled but no data source specified")
                return None
                
            return precip_data
            
        except Exception as e:
            self.logger.error(f"Failed to load precipitation data: {e}")
            return None
    
    def compute_time_step(self, state: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
        """Compute single time step with all optimizations."""
        h, u, v, z = state['h'], state['u'], state['v'], state['z']
        
        # Choose computation method based on available optimizations
        if self.config.enable_performance_optimization and self.performance_optimizer:
            # Use performance-optimized computation
            h_new, u_new, v_new = self.performance_optimizer.optimized_shallow_water_step(
                h, u, v, z, self.time_step, self.config.dx, self.config.dy
            )
            
        elif self.config.enable_gpu and self.gpu_accelerator:
            # Use GPU acceleration
            h_new, u_new, v_new = self.gpu_accelerator.accelerate_shallow_water_step(
                h, u, v, z, self.time_step, self.config.dx, self.config.dy
            )
            
        else:
            # Use basic CPU computation
            h_new, u_new, v_new = self._basic_shallow_water_step(
                h, u, v, z, self.time_step, self.config.dx, self.config.dy
            )
        
        return {'h': h_new, 'u': u_new, 'v': v_new, 'z': z}
    
    def _basic_shallow_water_step(self, h, u, v, z, dt, dx, dy, g=9.81):
        """Basic shallow water computation for fallback."""
        ny, nx = h.shape
        h_new = np.zeros_like(h)
        u_new = np.zeros_like(u)
        v_new = np.zeros_like(v)
        
        # Simple explicit scheme
        for j in range(1, ny-1):
            for i in range(1, nx-1):
                if h[j, i] > 1e-6:
                    # Water surface gradients
                    eta = h + z
                    deta_dx = (eta[j, i+1] - eta[j, i-1]) / (2 * dx)
                    deta_dy = (eta[j+1, i] - eta[j-1, i]) / (2 * dy)
                    
                    # Velocity divergence
                    du_dx = (u[j, i+1] - u[j, i-1]) / (2 * dx)
                    dv_dy = (v[j+1, i] - v[j-1, i]) / (2 * dy)
                    
                    # Saint-Venant equations
                    dh_dt = -h[j, i] * (du_dx + dv_dy)
                    du_dt = -g * deta_dx
                    dv_dt = -g * deta_dy
                    
                    # Euler forward update
                    h_new[j, i] = max(0, h[j, i] + dt * dh_dt)
                    u_new[j, i] = u[j, i] + dt * du_dt
                    v_new[j, i] = v[j, i] + dt * dv_dt
        
        return h_new, u_new, v_new
    
    def apply_precipitation_forcing(self, state: Dict[str, np.ndarray], 
                                  precip_data: PrecipitationData) -> Dict[str, np.ndarray]:
        """Apply precipitation forcing to hydraulic model."""
        if not precip_data:
            return state
        
        # Get precipitation at current time
        current_timestamp = datetime.now() + timedelta(seconds=self.current_time)
        precip_grid = self.precipitation_processor.interpolate_to_dem_grid(
            precip_data, current_timestamp
        )
        
        # Apply runoff coefficients
        effective_rainfall = self.precipitation_processor.apply_runoff_coefficients(
            precip_grid, default_coefficient=self.config.runoff_coefficient
        )
        
        # Convert mm/hr to m/s for depth increment
        rainfall_increment = effective_rainfall * (self.time_step / 3600.0) / 1000.0
        
        # Add to water depth
        state['h'] = state['h'] + rainfall_increment
        
        # Store precipitation data for reporting
        self.results['precipitation_data'].append({
            'time': self.current_time,
            'max_intensity': float(np.max(precip_grid)),
            'mean_intensity': float(np.mean(precip_grid)),
            'total_volume': float(np.sum(effective_rainfall * self.config.dx * self.config.dy))
        })
        
        return state
    
    def run_simulation(self, progress_callback: Optional[Callable] = None) -> Dict[str, Any]:
        """
        Run complete flood simulation with all advanced features.
        
        Args:
            progress_callback: Optional callback function for progress updates
            
        Returns:
            Simulation results dictionary
        """
        self.logger.info("Starting advanced flood simulation")
        self.logger.info(f"Configuration: {asdict(self.config)}")
        
        # Setup initial conditions
        state = self.setup_initial_conditions()
        
        # Load precipitation data
        precip_data = self.load_precipitation_data()
        
        # Calculate output intervals
        output_interval = self.config.simulation_time / self.config.output_timesteps
        next_output_time = 0.0
        
        # Main simulation loop
        start_time = time.time()
        while self.current_time < self.config.simulation_time:
            
            # Apply precipitation forcing
            if precip_data:
                state = self.apply_precipitation_forcing(state, precip_data)
            
            # Compute time step
            state = self.compute_time_step(state)
            
            # Update time
            self.current_time += self.time_step
            self.iteration += 1
            
            # Store results at output intervals
            if self.current_time >= next_output_time:
                self._store_results(state)
                next_output_time += output_interval
                
                # Progress callback
                if progress_callback:
                    progress = self.current_time / self.config.simulation_time
                    progress_callback(progress, self.current_time, self.iteration)
            
            # Adaptive time stepping
            if (self.config.enable_adaptive_timestepping and 
                self.performance_optimizer and 
                hasattr(self.performance_optimizer, 'adaptive_timestepping')):
                
                h, u, v = state['h'], state['u'], state['v']
                current_cfl = self.performance_optimizer.adaptive_timestepping.compute_cfl_number(
                    h, u, v, self.config.dx, self.config.dy
                )
                self.time_step = self.performance_optimizer.adaptive_timestepping.adapt_timestep(current_cfl)
        
        # Finalize simulation
        total_time = time.time() - start_time
        self.logger.info(f"Simulation completed in {total_time:.2f} seconds")
        self.logger.info(f"Total iterations: {self.iteration}")
        
        # Generate final results
        results = self._finalize_results(total_time)
        
        # Save results
        self._save_results(results)
        
        return results
    
    def _store_results(self, state: Dict[str, np.ndarray]):
        """Store simulation results at current time step."""
        self.results['timestamps'].append(self.current_time)
        self.results['water_depths'].append(state['h'].copy())
        
        # Calculate velocities magnitude
        velocity_magnitude = np.sqrt(state['u']**2 + state['v']**2)
        self.results['velocities'].append({
            'u': state['u'].copy(),
            'v': state['v'].copy(),
            'magnitude': velocity_magnitude
        })
        
        # Store performance metrics
        if self.performance_optimizer:
            memory_usage = self.performance_optimizer.memory_manager.get_memory_usage()
            self.results['performance_metrics'].append({
                'time': self.current_time,
                'memory_mb': memory_usage['process_rss_mb'],
                'timestep': self.time_step,
                'iteration': self.iteration
            })
    
    def _finalize_results(self, total_computation_time: float) -> Dict[str, Any]:
        """Finalize and package all simulation results."""
        
        # Basic statistics
        final_depths = self.results['water_depths'][-1] if self.results['water_depths'] else np.zeros_like(self.dem_data)
        max_depth = float(np.max(final_depths))
        total_volume = float(np.sum(final_depths) * self.config.dx * self.config.dy)
        
        # Velocity statistics
        if self.results['velocities']:
            final_velocities = self.results['velocities'][-1]['magnitude']
            max_velocity = float(np.max(final_velocities))
        else:
            max_velocity = 0.0
        
        # Performance statistics
        performance_stats = {}
        if self.gpu_accelerator:
            performance_stats['gpu'] = self.gpu_accelerator.get_performance_report()
        
        if self.performance_optimizer:
            performance_stats['optimization'] = self.performance_optimizer.generate_optimization_report()
        
        # Precipitation statistics
        precip_stats = {}
        if self.results['precipitation_data']:
            total_precip_volume = sum(p['total_volume'] for p in self.results['precipitation_data'])
            max_intensity = max(p['max_intensity'] for p in self.results['precipitation_data'])
            precip_stats = {
                'total_volume_m3': total_precip_volume,
                'max_intensity_mm_hr': max_intensity,
                'precipitation_steps': len(self.results['precipitation_data'])
            }
        
        # Compile final results
        results = {
            'configuration': asdict(self.config),
            'simulation_statistics': {
                'total_time_seconds': total_computation_time,
                'simulation_time': self.config.simulation_time,
                'total_iterations': self.iteration,
                'final_timestep': self.time_step,
                'output_timesteps': len(self.results['timestamps'])
            },
            'hydraulic_results': {
                'max_water_depth_m': max_depth,
                'total_water_volume_m3': total_volume,
                'max_velocity_m_s': max_velocity,
                'flooded_area_m2': float(np.sum(final_depths > 0.01) * self.config.dx * self.config.dy)
            },
            'precipitation_results': precip_stats,
            'performance_results': performance_stats,
            'timestamps': self.results['timestamps'],
            'dem_metadata': {
                'extent': self.dem_extent,
                'resolution': self.dem_resolution,
                'shape': self.dem_data.shape
            }
        }
        
        return results
    
    def _save_results(self, results: Dict[str, Any]):
        """Save simulation results in multiple formats."""
        
        # Save configuration and summary
        summary_file = os.path.join(self.config.output_directory, "simulation_summary.json")
        with open(summary_file, 'w') as f:
            # Convert numpy types to JSON-serializable types
            json_results = self._convert_for_json(results)
            json.dump(json_results, f, indent=2)
        
        self.logger.info(f"Simulation summary saved to {summary_file}")
        
        # Save detailed results based on export formats
        for export_format in self.config.export_formats:
            if export_format == "geotiff":
                self._save_geotiff_outputs()
            elif export_format == "csv":
                self._save_csv_outputs()
            elif export_format == "netcdf":
                self._save_netcdf_outputs()
    
    def _convert_for_json(self, obj):
        """Convert numpy types to JSON-serializable types."""
        if isinstance(obj, dict):
            return {key: self._convert_for_json(value) for key, value in obj.items()}
        elif isinstance(obj, list):
            return [self._convert_for_json(item) for item in obj]
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, (np.integer, np.floating)):
            return float(obj)
        else:
            return obj
    
    def _save_geotiff_outputs(self):
        """Save results as GeoTIFF files."""
        try:
            from osgeo import gdal, osr
            
            # Setup georeferencing
            xmin, ymin, xmax, ymax = self.dem_extent
            ny, nx = self.dem_data.shape
            dx, dy = self.dem_resolution
            
            # Create GeoTIFF for each output timestep
            for i, (timestamp, depth_grid) in enumerate(zip(self.results['timestamps'], self.results['water_depths'])):
                
                # Create output filename
                output_file = os.path.join(self.config.output_directory, f"water_depth_{i:04d}.tif")
                
                # Create GeoTIFF
                driver = gdal.GetDriverByName('GTiff')
                dataset = driver.Create(output_file, nx, ny, 1, gdal.GDT_Float32, 
                                      ['COMPRESS=LZW', 'TILED=YES'])
                
                # Set geotransform
                geotransform = (xmin, dx, 0, ymax, 0, -dy)
                dataset.SetGeoTransform(geotransform)
                
                # Set projection (SWEREF99 TM)
                srs = osr.SpatialReference()
                srs.ImportFromEPSG(3006)
                dataset.SetProjection(srs.ExportToWkt())
                
                # Write data
                band = dataset.GetRasterBand(1)
                band.WriteArray(depth_grid)
                band.SetNoDataValue(-9999)
                band.SetDescription(f"Water depth at t={timestamp:.2f}s")
                
                # Add metadata
                dataset.SetMetadataItem("TIMESTAMP", str(timestamp))
                dataset.SetMetadataItem("SIMULATION_TIME", str(self.config.simulation_time))
                
                dataset.FlushCache()
                dataset = None
            
            self.logger.info(f"Saved {len(self.results['timestamps'])} GeoTIFF files")
            
        except ImportError:
            self.logger.error("GDAL not available. Cannot save GeoTIFF outputs.")
        except Exception as e:
            self.logger.error(f"Error saving GeoTIFF outputs: {e}")
    
    def _save_csv_outputs(self):
        """Save results as CSV files."""
        try:
            import csv
            
            # Save time series summary
            summary_file = os.path.join(self.config.output_directory, "time_series_summary.csv")
            with open(summary_file, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['Time_s', 'Max_Depth_m', 'Total_Volume_m3', 'Max_Velocity_m_s', 'Timestep_s'])
                
                for i, timestamp in enumerate(self.results['timestamps']):
                    depth_grid = self.results['water_depths'][i]
                    velocity_data = self.results['velocities'][i]
                    
                    max_depth = np.max(depth_grid)
                    total_volume = np.sum(depth_grid) * self.config.dx * self.config.dy
                    max_velocity = np.max(velocity_data['magnitude'])
                    
                    # Get timestep from performance metrics
                    timestep = self.time_step
                    if i < len(self.results['performance_metrics']):
                        timestep = self.results['performance_metrics'][i]['timestep']
                    
                    writer.writerow([timestamp, max_depth, total_volume, max_velocity, timestep])
            
            self.logger.info(f"CSV summary saved to {summary_file}")
            
        except Exception as e:
            self.logger.error(f"Error saving CSV outputs: {e}")
    
    def _save_netcdf_outputs(self):
        """Save results as NetCDF file."""
        if not HDF5_AVAILABLE:
            self.logger.warning("HDF5/NetCDF not available. Skipping NetCDF output.")
            return
        
        try:
            import h5py
            
            output_file = os.path.join(self.config.output_directory, "simulation_results.nc")
            
            with h5py.File(output_file, 'w') as f:
                # Dimensions
                nt = len(self.results['timestamps'])
                ny, nx = self.dem_data.shape
                
                # Create datasets
                f.create_dataset('time', data=self.results['timestamps'])
                f.create_dataset('x', data=np.linspace(self.dem_extent[0], self.dem_extent[2], nx))
                f.create_dataset('y', data=np.linspace(self.dem_extent[1], self.dem_extent[3], ny))
                f.create_dataset('elevation', data=self.dem_data)
                
                # Water depth time series
                depth_data = np.stack(self.results['water_depths'], axis=0)
                f.create_dataset('water_depth', data=depth_data)
                
                # Velocity data
                u_data = np.stack([v['u'] for v in self.results['velocities']], axis=0)
                v_data = np.stack([v['v'] for v in self.results['velocities']], axis=0)
                f.create_dataset('velocity_u', data=u_data)
                f.create_dataset('velocity_v', data=v_data)
                
                # Attributes
                f.attrs['title'] = 'FloodEngine v4.0 Simulation Results'
                f.attrs['simulation_time'] = self.config.simulation_time
                f.attrs['dx'] = self.config.dx
                f.attrs['dy'] = self.config.dy
                f.attrs['created'] = datetime.now().isoformat()
            
            self.logger.info(f"NetCDF results saved to {output_file}")
            
        except Exception as e:
            self.logger.error(f"Error saving NetCDF outputs: {e}")

# Factory function for easy integration
def create_advanced_flood_engine(config: SimulationConfiguration) -> AdvancedFloodEngine:
    """
    Factory function to create advanced flood engine.
    
    Args:
        config: Complete simulation configuration
        
    Returns:
        Configured AdvancedFloodEngine instance
    """
    return AdvancedFloodEngine(config)

# Example usage and testing
if __name__ == "__main__":
    print("FloodEngine Advanced Integration Test")
    print("====================================")
    
    # Create test configuration
    config = SimulationConfiguration(
        dem_file="test_dem.tif",  # Would need actual DEM file
        output_directory="./test_output",
        simulation_time=3600.0,  # 1 hour
        initial_dt=0.1,
        dx=10.0,
        dy=10.0,
        water_level=2.0,
        enable_gpu=True,
        enable_precipitation=True,
        enable_performance_optimization=True,
        precipitation_format="design_storm",
        storm_type="scs_type2",
        rainfall_mm=25.0,
        storm_duration_hours=2.0,
        output_timesteps=60,
        export_formats=["geotiff", "csv"]
    )
    
    print(f"Configuration created:")
    print(f"  GPU acceleration: {config.enable_gpu}")
    print(f"  Precipitation: {config.enable_precipitation}")
    print(f"  Performance optimization: {config.enable_performance_optimization}")
    print(f"  Storm type: {config.storm_type}")
    print(f"  Simulation time: {config.simulation_time}s")
    
    # Note: Actual simulation would require a real DEM file
    # engine = create_advanced_flood_engine(config)
    # results = engine.run_simulation()
    
    print("\nAdvanced integration module ready for production use!")
    print("Note: Requires actual DEM file and proper QGIS environment for full functionality.")


def _add_outputs_to_project(self):
    try:
        from qgis.core import QgsRasterLayer, QgsProject
        for i, timestamp in enumerate(self.results['timestamps']):
            output_file = os.path.join(self.config.output_directory, f"water_depth_{i:04d}.tif")
            layer = QgsRasterLayer(output_file, f"Water Depth t={timestamp:.2f}s")
            if layer.isValid():
                QgsProject.instance().addMapLayer(layer)
            else:
                self.logger.warning(f"Invalid raster layer: {output_file}")
    except Exception as e:
        self.logger.error(f"Failed to add output layers to QGIS project: {e}")
