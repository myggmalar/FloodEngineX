"""
FloodEngine v4.0 - Batch Processing UI
=====================================

User interface components for batch processing configuration and monitoring.
Integrates with the batch processing framework for multi-scenario analysis.

Author: FloodEngine Development Team
Date: June 7, 2025
"""

try:
    from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QGridLayout,
                                QLabel, QLineEdit, QPushButton, QTableWidget,
                                QTableWidgetItem, QProgressBar, QTextEdit,
                                QGroupBox, QSpinBox, QDoubleSpinBox, QComboBox,
                                QFileDialog, QMessageBox, QTabWidget, QWidget,
                                QCheckBox, QListWidget, QListWidgetItem,
                                QSplitter, QFrame)
    from PyQt5.QtCore import Qt, QThread, pyqtSignal, QTimer
    from PyQt5.QtGui import QFont, QColor
except ImportError:
    # Fallback for development environment
    print("PyQt5 not available - UI components disabled")
    QDialog = object
    QThread = object

import os
import json
from datetime import datetime
from typing import List, Dict, Any, Optional

# Import batch processing framework
try:
    from .batch_processing_framework import (BatchConfiguration, BatchJob, 
                                           BatchProcessor, BatchProgressCallback,
                                           create_water_level_sweep_config,
                                           create_multi_scenario_config)
except ImportError:
    from batch_processing_framework import (BatchConfiguration, BatchJob,
                                          BatchProcessor, BatchProgressCallback,
                                          create_water_level_sweep_config,
                                          create_multi_scenario_config)

class BatchProcessingDialog(QDialog):
    """Main dialog for batch processing configuration and execution."""
    
    def __init__(self, hydraulic_model, parent=None):
        """Initialize batch processing dialog.
        
        Args:
            hydraulic_model: FloodEngine hydraulic model instance
            parent: Parent widget
        """
        super().__init__(parent)
        self.hydraulic_model = hydraulic_model
        self.batch_processor = None
        self.current_config = None
        
        self.setWindowTitle("FloodEngine - Batch Processing")
        self.setMinimumSize(800, 600)
        
        self.setup_ui()
        self.connect_signals()
    
    def setup_ui(self):
        """Set up the user interface."""
        layout = QVBoxLayout(self)
        
        # Create tab widget
        self.tab_widget = QTabWidget()
        layout.addWidget(self.tab_widget)
        
        # Configuration tab
        self.config_tab = self.create_configuration_tab()
        self.tab_widget.addTab(self.config_tab, "Configuration")
        
        # Execution tab
        self.execution_tab = self.create_execution_tab()
        self.tab_widget.addTab(self.execution_tab, "Execution")
        
        # Results tab
        self.results_tab = self.create_results_tab()
        self.tab_widget.addTab(self.results_tab, "Results")
        
        # Control buttons
        button_layout = QHBoxLayout()
        
        self.load_config_btn = QPushButton("Load Configuration")
        self.save_config_btn = QPushButton("Save Configuration")
        self.start_batch_btn = QPushButton("Start Batch Processing")
        self.close_btn = QPushButton("Close")
        
        button_layout.addWidget(self.load_config_btn)
        button_layout.addWidget(self.save_config_btn)
        button_layout.addStretch()
        button_layout.addWidget(self.start_batch_btn)
        button_layout.addWidget(self.close_btn)
        
        layout.addLayout(button_layout)
    
    def create_configuration_tab(self):
        """Create the configuration tab."""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # Configuration type selection
        config_group = QGroupBox("Configuration Type")
        config_layout = QGridLayout(config_group)
        
        self.config_type_combo = QComboBox()
        self.config_type_combo.addItems([
            "Water Level Sweep",
            "Multi-DEM Analysis", 
            "Full Scenario Matrix",
            "Custom Configuration"
        ])
        config_layout.addWidget(QLabel("Type:"), 0, 0)
        config_layout.addWidget(self.config_type_combo, 0, 1)
        
        self.config_name_edit = QLineEdit()
        self.config_name_edit.setText(f"BatchJob_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
        config_layout.addWidget(QLabel("Name:"), 1, 0)
        config_layout.addWidget(self.config_name_edit, 1, 1)
        
        self.config_desc_edit = QLineEdit()
        config_layout.addWidget(QLabel("Description:"), 2, 0)
        config_layout.addWidget(self.config_desc_edit, 2, 1)
        
        layout.addWidget(config_group)
        
        # DEM file selection
        dem_group = QGroupBox("DEM Files")
        dem_layout = QVBoxLayout(dem_group)
        
        dem_button_layout = QHBoxLayout()
        self.add_dem_btn = QPushButton("Add DEM File")
        self.remove_dem_btn = QPushButton("Remove Selected")
        self.clear_dem_btn = QPushButton("Clear All")
        dem_button_layout.addWidget(self.add_dem_btn)
        dem_button_layout.addWidget(self.remove_dem_btn)
        dem_button_layout.addWidget(self.clear_dem_btn)
        dem_button_layout.addStretch()
        
        self.dem_list = QListWidget()
        self.dem_list.setMaximumHeight(120)
        
        dem_layout.addLayout(dem_button_layout)
        dem_layout.addWidget(self.dem_list)
        
        layout.addWidget(dem_group)
        
        # Parameter configuration
        param_group = QGroupBox("Parameters")
        param_layout = QGridLayout(param_group)
        
        # Base parameters
        # Manning's n input
        self.manning_label = QLabel("Manning’s n:")
        self.manning_input = QDoubleSpinBox()
        self.manning_input.setRange(0.01, 0.2)
        self.manning_input.setSingleStep(0.005)
        self.manning_input.setValue(0.035)
        param_layout.addWidget(self.manning_label, 3, 0)
        param_layout.addWidget(self.manning_input, 3, 1)

        param_layout.addWidget(QLabel("Model Type:"), 0, 0)
        self.model_type_combo = QComboBox()
        self.model_type_combo.addItems(["saint_venant_2d", "basic_flow", "dam_break"])
        param_layout.addWidget(self.model_type_combo, 0, 1)
        
        param_layout.addWidget(QLabel("Time Step (s):"), 1, 0)
        self.time_step_spin = QDoubleSpinBox()
        self.time_step_spin.setRange(0.01, 10.0)
        self.time_step_spin.setValue(0.1)
        self.time_step_spin.setSingleStep(0.01)
        param_layout.addWidget(self.time_step_spin, 1, 1)
        
        param_layout.addWidget(QLabel("Total Time (s):"), 2, 0)
        self.total_time_spin = QSpinBox()
        self.total_time_spin.setRange(60, 86400)
        self.total_time_spin.setValue(3600)
        param_layout.addWidget(self.total_time_spin, 2, 1)
        
        param_layout.addWidget(QLabel("Manning's n:"), 3, 0)
        self.manning_spin = QDoubleSpinBox()
        self.manning_spin.setRange(0.01, 0.15)
        self.manning_spin.setValue(0.035)
        self.manning_spin.setSingleStep(0.005)
        param_layout.addWidget(self.manning_spin, 3, 1)
        
        # Parameter sweep configuration
        sweep_layout = QHBoxLayout()
        self.enable_sweep_cb = QCheckBox("Enable Parameter Sweep")
        sweep_layout.addWidget(self.enable_sweep_cb)
        
        self.sweep_param_combo = QComboBox()
        self.sweep_param_combo.addItems(["dam_height", "manning_n", "time_step"])
        sweep_layout.addWidget(QLabel("Parameter:"))
        sweep_layout.addWidget(self.sweep_param_combo)
        
        param_layout.addLayout(sweep_layout, 4, 0, 1, 2)
        
        # Sweep values
        param_layout.addWidget(QLabel("Sweep Values:"), 5, 0)
        self.sweep_values_edit = QLineEdit()
        self.sweep_values_edit.setPlaceholderText("e.g., 1.0, 2.0, 3.0, 4.0, 5.0")
        param_layout.addWidget(self.sweep_values_edit, 5, 1)
        
        layout.addWidget(param_group)
        
        # Job preview
        preview_group = QGroupBox("Job Preview")
        preview_layout = QVBoxLayout(preview_group)
        
        self.update_preview_btn = QPushButton("Update Preview")
        self.job_count_label = QLabel("Jobs: 0")
        
        preview_button_layout = QHBoxLayout()
        preview_button_layout.addWidget(self.update_preview_btn)
        preview_button_layout.addStretch()
        preview_button_layout.addWidget(self.job_count_label)
        
        self.job_preview_table = QTableWidget()
        self.job_preview_table.setColumnCount(4)
        self.job_preview_table.setHorizontalHeaderLabels(["Job ID", "DEM", "Parameter", "Value"])
        self.job_preview_table.setMaximumHeight(150)
        
        preview_layout.addLayout(preview_button_layout)
        preview_layout.addWidget(self.job_preview_table)
        
        layout.addWidget(preview_group)
        
        return tab
    
    def create_execution_tab(self):
        """Create the execution tab."""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # Execution settings
        settings_group = QGroupBox("Execution Settings")
        settings_layout = QGridLayout(settings_group)
        
        settings_layout.addWidget(QLabel("Output Directory:"), 0, 0)
        self.output_dir_edit = QLineEdit()
        self.output_dir_edit.setText(os.path.expanduser("~/FloodEngine_Batch_Output"))
        self.browse_output_btn = QPushButton("Browse")
        
        output_layout = QHBoxLayout()
        output_layout.addWidget(self.output_dir_edit)
        output_layout.addWidget(self.browse_output_btn)
        settings_layout.addLayout(output_layout, 0, 1)
        
        self.continue_on_error_cb = QCheckBox("Continue on Error")
        self.continue_on_error_cb.setChecked(True)
        settings_layout.addWidget(self.continue_on_error_cb, 1, 0, 1, 2)
        
        layout.addWidget(settings_group)
        
        # Progress monitoring
        progress_group = QGroupBox("Progress")
        progress_layout = QVBoxLayout(progress_group)
        
        self.overall_progress = QProgressBar()
        self.current_job_progress = QProgressBar()
        
        progress_layout.addWidget(QLabel("Overall Progress:"))
        progress_layout.addWidget(self.overall_progress)
        progress_layout.addWidget(QLabel("Current Job:"))
        progress_layout.addWidget(self.current_job_progress)
        
        self.status_label = QLabel("Ready")
        progress_layout.addWidget(self.status_label)
        
        layout.addWidget(progress_group)
        
        # Execution log
        log_group = QGroupBox("Execution Log")
        log_layout = QVBoxLayout(log_group)
        
        self.log_text = QTextEdit()
        self.log_text.setMaximumHeight(200)
        self.log_text.setFont(QFont("Courier", 9))
        
        log_layout.addWidget(self.log_text)
        
        layout.addWidget(log_group)
        
        # Control buttons
        control_layout = QHBoxLayout()
        self.pause_btn = QPushButton("Pause")
        self.stop_btn = QPushButton("Stop")
        self.clear_log_btn = QPushButton("Clear Log")
        
        control_layout.addWidget(self.pause_btn)
        control_layout.addWidget(self.stop_btn)
        control_layout.addStretch()
        control_layout.addWidget(self.clear_log_btn)
        
        layout.addLayout(control_layout)
        
        return tab
    
    def create_results_tab(self):
        """Create the results tab."""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        # Results summary
        summary_group = QGroupBox("Batch Summary")
        summary_layout = QGridLayout(summary_group)
        
        self.total_jobs_label = QLabel("0")
        self.completed_jobs_label = QLabel("0")
        self.failed_jobs_label = QLabel("0")
        self.success_rate_label = QLabel("0%")
        self.total_time_label = QLabel("0 seconds")
        
        summary_layout.addWidget(QLabel("Total Jobs:"), 0, 0)
        summary_layout.addWidget(self.total_jobs_label, 0, 1)
        summary_layout.addWidget(QLabel("Completed:"), 1, 0)
        summary_layout.addWidget(self.completed_jobs_label, 1, 1)
        summary_layout.addWidget(QLabel("Failed:"), 2, 0)
        summary_layout.addWidget(self.failed_jobs_label, 2, 1)
        summary_layout.addWidget(QLabel("Success Rate:"), 0, 2)
        summary_layout.addWidget(self.success_rate_label, 0, 3)
        summary_layout.addWidget(QLabel("Total Time:"), 1, 2)
        summary_layout.addWidget(self.total_time_label, 1, 3)
        
        layout.addWidget(summary_group)
        
        # Results table
        results_group = QGroupBox("Job Results")
        results_layout = QVBoxLayout(results_group)
        
        self.results_table = QTableWidget()
        self.results_table.setColumnCount(6)
        self.results_table.setHorizontalHeaderLabels([
            "Job ID", "Status", "Execution Time", "Output Files", "Error", "Actions"
        ])
        
        results_layout.addWidget(self.results_table)
        
        # Results actions
        results_actions_layout = QHBoxLayout()
        self.open_output_btn = QPushButton("Open Output Folder")
        self.export_results_btn = QPushButton("Export Results")
        self.generate_report_btn = QPushButton("Generate Report")
        
        results_actions_layout.addWidget(self.open_output_btn)
        results_actions_layout.addWidget(self.export_results_btn)
        results_actions_layout.addWidget(self.generate_report_btn)
        results_actions_layout.addStretch()
        
        results_layout.addLayout(results_actions_layout)
        
        layout.addWidget(results_group)
        
        return tab
    
    def connect_signals(self):
        """Connect UI signals to handlers."""
        # Configuration tab
        self.config_type_combo.currentTextChanged.connect(self.on_config_type_changed)
        self.add_dem_btn.clicked.connect(self.add_dem_file)
        self.remove_dem_btn.clicked.connect(self.remove_dem_file)
        self.clear_dem_btn.clicked.connect(self.clear_dem_files)
        self.update_preview_btn.clicked.connect(self.update_job_preview)
        self.enable_sweep_cb.toggled.connect(self.on_sweep_enabled)
        
        # Execution tab
        self.browse_output_btn.clicked.connect(self.browse_output_directory)
        self.clear_log_btn.clicked.connect(self.clear_log)
        
        # Results tab
        self.open_output_btn.clicked.connect(self.open_output_folder)
        self.export_results_btn.clicked.connect(self.export_results)
        self.generate_report_btn.clicked.connect(self.generate_report)
        
        # Main buttons
        self.load_config_btn.clicked.connect(self.load_configuration)
        self.save_config_btn.clicked.connect(self.save_configuration)
        self.start_batch_btn.clicked.connect(self.start_batch_processing)
        self.close_btn.clicked.connect(self.close)
    
    def on_config_type_changed(self):
        """Handle configuration type change."""
        config_type = self.config_type_combo.currentText()
        
        # Update UI based on configuration type
        if config_type == "Water Level Sweep":
            self.sweep_param_combo.setCurrentText("dam_height")
            self.enable_sweep_cb.setChecked(True)
            self.sweep_values_edit.setText("1.0, 2.0, 3.0, 4.0, 5.0")
        elif config_type == "Multi-DEM Analysis":
            self.enable_sweep_cb.setChecked(False)
        else:
            self.enable_sweep_cb.setChecked(False)
    
    def on_sweep_enabled(self, enabled):
        """Handle sweep checkbox toggle."""
        self.sweep_param_combo.setEnabled(enabled)
        self.sweep_values_edit.setEnabled(enabled)
    
    def add_dem_file(self):
        """Add DEM file to the list."""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select DEM File", "", "GeoTIFF files (*.tif *.tiff)")
        
        if file_path:
            self.dem_list.addItem(file_path)
            self.update_job_preview()
    
    def remove_dem_file(self):
        """Remove selected DEM file."""
        current_row = self.dem_list.currentRow()
        if current_row >= 0:
            self.dem_list.takeItem(current_row)
            self.update_job_preview()
    
    def clear_dem_files(self):
        """Clear all DEM files."""
        self.dem_list.clear()
        self.update_job_preview()
    
    def browse_output_directory(self):
        """Browse for output directory."""
        directory = QFileDialog.getExistingDirectory(
            self, "Select Output Directory")
        
        if directory:
            self.output_dir_edit.setText(directory)
    
    def clear_log(self):
        """Clear execution log."""
        self.log_text.clear()
    
    def update_job_preview(self):
        """Update job preview table."""
        try:
            config = self.create_configuration_from_ui()
            
            if config and config.jobs:
                self.job_preview_table.setRowCount(min(len(config.jobs), 10))  # Show max 10 jobs
                
                for i, job in enumerate(config.jobs[:10]):
                    self.job_preview_table.setItem(i, 0, QTableWidgetItem(job.job_id))
                    self.job_preview_table.setItem(i, 1, QTableWidgetItem(os.path.basename(job.dem_path)))
                    
                    # Show varied parameter
                    if self.enable_sweep_cb.isChecked():
                        param_name = self.sweep_param_combo.currentText()
                        param_value = str(job.parameters.get(param_name, "N/A"))
                        self.job_preview_table.setItem(i, 2, QTableWidgetItem(param_name))
                        self.job_preview_table.setItem(i, 3, QTableWidgetItem(param_value))
                    else:
                        self.job_preview_table.setItem(i, 2, QTableWidgetItem("N/A"))
                        self.job_preview_table.setItem(i, 3, QTableWidgetItem("N/A"))
                
                self.job_count_label.setText(f"Jobs: {len(config.jobs)}")
                
                if len(config.jobs) > 10:
                    self.job_count_label.setText(f"Jobs: {len(config.jobs)} (showing first 10)")
            else:
                self.job_preview_table.setRowCount(0)
                self.job_count_label.setText("Jobs: 0")
                
        except Exception as e:
            self.log_text.append(f"Error updating preview: {str(e)}")
    
    def create_configuration_from_ui(self):
        """Create batch configuration from UI inputs."""
        try:
            # Get basic configuration
            config_name = self.config_name_edit.text()
            config_desc = self.config_desc_edit.text()
            config_type = self.config_type_combo.currentText()
            
            if not config_name:
                return None
            
            # Get DEM files
            dem_paths = []
            for i in range(self.dem_list.count()):
                dem_paths.append(self.dem_list.item(i).text())
            
            if not dem_paths:
                return None
            
            # Get base parameters
            base_parameters = {
                'model_type': self.model_type_combo.currentText(),
                'time_step': self.time_step_spin.value(),
                'total_time': self.total_time_spin.value(),
                'manning_n': self.manning_spin.value(),
                'output_interval': 300
            }
            
            # Create configuration based on type
            config = BatchConfiguration(config_name, config_desc, manning_n=self.manning_input.value())
            
            if config_type == "Water Level Sweep" and self.enable_sweep_cb.isChecked():
                # Parse sweep values
                values_text = self.sweep_values_edit.text()
                try:
                    values = [float(v.strip()) for v in values_text.split(',') if v.strip()]
                    if values and dem_paths:
                        config.add_parameter_sweep(dem_paths[0], 'dam_height', values, base_parameters)
                except ValueError:
                    return None
                    
            elif config_type == "Multi-DEM Analysis":
                config.add_multi_dem_analysis(dem_paths, base_parameters)
                
            elif config_type == "Full Scenario Matrix":
                # Create multiple parameter sets
                scenario_parameters = [base_parameters]  # Simplified for now
                config.add_scenario_matrix(dem_paths, scenario_parameters)
                
            else:  # Custom Configuration
                if self.enable_sweep_cb.isChecked():
                    param_name = self.sweep_param_combo.currentText()
                    values_text = self.sweep_values_edit.text()
                    try:
                        values = [float(v.strip()) for v in values_text.split(',') if v.strip()]
                        if values and dem_paths:
                            config.add_parameter_sweep(dem_paths[0], param_name, values, base_parameters)
                    except ValueError:
                        return None
                else:
                    config.add_multi_dem_analysis(dem_paths, base_parameters)
            
            return config
            
        except Exception as e:
            print(f"Error creating configuration: {e}")
            return None
    
    def load_configuration(self):
        """Load configuration from file."""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Load Batch Configuration", "", "JSON files (*.json)")
        
        if file_path:
            try:
                self.current_config = BatchConfiguration.load_configuration(file_path)
                self.load_configuration_to_ui(self.current_config)
                self.log_text.append(f"Configuration loaded: {file_path}")
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to load configuration:\n{str(e)}")
    
    def save_configuration(self):
        """Save current configuration to file."""
        config = self.create_configuration_from_ui()
        if not config:
            QMessageBox.warning(self, "Error", "Please configure at least one job before saving.")
            return
        
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Save Batch Configuration", f"{config.name}.json", "JSON files (*.json)")
        
        if file_path:
            try:
                config.save_configuration(file_path)
                self.current_config = config
                self.log_text.append(f"Configuration saved: {file_path}")
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to save configuration:\n{str(e)}")
    
    def load_configuration_to_ui(self, config):
        """Load configuration data to UI elements."""
        self.config_name_edit.setText(config.name)
        self.config_desc_edit.setText(config.description)
        
        # Load DEM files from jobs
        self.dem_list.clear()
        dem_paths = list(set(job.dem_path for job in config.jobs))
        for dem_path in dem_paths:
            self.dem_list.addItem(dem_path)
        
        # Load parameters from first job
        if config.jobs:
            params = config.jobs[0].parameters
            self.model_type_combo.setCurrentText(params.get('model_type', 'saint_venant_2d'))
            self.time_step_spin.setValue(params.get('time_step', 0.1))
            self.total_time_spin.setValue(params.get('total_time', 3600))
            self.manning_spin.setValue(params.get('manning_n', 0.035))
        
        self.update_job_preview()
    
    def start_batch_processing(self):
        """Start batch processing execution."""
        config = self.create_configuration_from_ui()
        if not config or not config.jobs:
            QMessageBox.warning(self, "Error", "Please configure at least one job before starting.")
            return
        
        output_dir = self.output_dir_edit.text()
        if not output_dir:
            QMessageBox.warning(self, "Error", "Please specify an output directory.")
            return
        
        # Create batch processor
        self.batch_processor = BatchProcessor(self.hydraulic_model, output_dir)
        self.batch_processor.continue_on_error = self.continue_on_error_cb.isChecked()
        
        # Set up progress callback
        progress_callback = QtBatchProgressCallback(self)
        self.batch_processor.set_progress_callback(progress_callback)
        
        # Start processing in separate thread
        self.batch_thread = BatchProcessingThread(self.batch_processor, config)
        self.batch_thread.finished.connect(self.on_batch_finished)
        self.batch_thread.start()
        
        # Update UI
        self.start_batch_btn.setEnabled(False)
        self.tab_widget.setCurrentIndex(1)  # Switch to execution tab
        self.status_label.setText("Starting batch processing...")
        
        self.log_text.append(f"Starting batch processing: {config.name}")
        self.log_text.append(f"Total jobs: {len(config.jobs)}")
    
    def on_batch_finished(self, completed_jobs, failed_jobs):
        """Handle batch processing completion."""
        self.start_batch_btn.setEnabled(True)
        self.overall_progress.setValue(100)
        self.current_job_progress.setValue(100)
        
        # Update results tab
        self.update_results_display(completed_jobs, failed_jobs)
        self.tab_widget.setCurrentIndex(2)  # Switch to results tab
        
        self.log_text.append(f"Batch processing completed!")
        self.log_text.append(f"Successful jobs: {completed_jobs}")
        self.log_text.append(f"Failed jobs: {failed_jobs}")
    
    def update_results_display(self, completed_jobs, failed_jobs):
        """Update results display."""
        total_jobs = completed_jobs + failed_jobs
        
        self.total_jobs_label.setText(str(total_jobs))
        self.completed_jobs_label.setText(str(completed_jobs))
        self.failed_jobs_label.setText(str(failed_jobs))
        
        if total_jobs > 0:
            success_rate = (completed_jobs / total_jobs) * 100
            self.success_rate_label.setText(f"{success_rate:.1f}%")
        
        # Update results table
        if self.current_config:
            self.results_table.setRowCount(len(self.current_config.jobs))
            
            for i, job in enumerate(self.current_config.jobs):
                self.results_table.setItem(i, 0, QTableWidgetItem(job.job_id))
                self.results_table.setItem(i, 1, QTableWidgetItem(job.status))
                self.results_table.setItem(i, 2, QTableWidgetItem(f"{job.execution_time:.1f}s" if job.execution_time else "N/A"))
                self.results_table.setItem(i, 3, QTableWidgetItem(str(len(job.output_files))))
                self.results_table.setItem(i, 4, QTableWidgetItem(job.error_message or ""))
    
    def open_output_folder(self):
        """Open output folder in file explorer."""
        output_dir = self.output_dir_edit.text()
        if os.path.exists(output_dir):
            os.startfile(output_dir)  # Windows
    
    def export_results(self):
        """Export results to file."""
        if not self.current_config:
            QMessageBox.warning(self, "Error", "No results to export.")
            return
        
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Export Results", f"{self.current_config.name}_results.json", "JSON files (*.json)")
        
        if file_path:
            try:
                self.current_config.save_configuration(file_path)
                self.log_text.append(f"Results exported: {file_path}")
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to export results:\n{str(e)}")
    
    def generate_report(self):
        """Generate batch processing report."""
        if not self.current_config or not self.current_config.output_directory:
            QMessageBox.warning(self, "Error", "No batch results available for report generation.")
            return
        
        try:
            completed = sum(1 for job in self.current_config.jobs if job.status == "completed")
            failed = sum(1 for job in self.current_config.jobs if job.status == "failed")
            
            # This would typically call the batch processor's report generation
            self.log_text.append("Report generation completed.")
            
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to generate report:\n{str(e)}")

class QtBatchProgressCallback(BatchProgressCallback):
    """Qt-based progress callback for UI updates."""
    
    def __init__(self, dialog):
        """Initialize with dialog reference.
        
        Args:
            dialog (BatchProcessingDialog): Parent dialog
        """
        self.dialog = dialog
    
    def on_batch_started(self, total_jobs):
        """Called when batch processing starts."""
        self.dialog.overall_progress.setMaximum(total_jobs)
        self.dialog.overall_progress.setValue(0)
        self.dialog.status_label.setText(f"Processing {total_jobs} jobs...")
    
    def on_job_started(self, job, current_job, total_jobs):
        """Called when a job starts."""
        self.dialog.overall_progress.setValue(current_job - 1)
        self.dialog.current_job_progress.setValue(0)
        self.dialog.status_label.setText(f"Job {current_job}/{total_jobs}: {job.job_id}")
        self.dialog.log_text.append(f"Started: {job.job_id}")
    
    def on_job_completed(self, job, current_job, total_jobs):
        """Called when a job completes."""
        self.dialog.overall_progress.setValue(current_job)
        self.dialog.current_job_progress.setValue(100)
        self.dialog.log_text.append(f"Completed: {job.job_id} ({job.execution_time:.1f}s)")
    
    def on_job_failed(self, job, current_job, total_jobs, error):
        """Called when a job fails."""
        self.dialog.overall_progress.setValue(current_job)
        self.dialog.current_job_progress.setValue(100)
        self.dialog.log_text.append(f"FAILED: {job.job_id} - {error}")

class BatchProcessingThread(QThread):
    """Thread for batch processing execution."""
    
    finished = pyqtSignal(int, int)  # completed_jobs, failed_jobs
    
    def __init__(self, batch_processor, config):
        """Initialize thread.
        
        Args:
            batch_processor (BatchProcessor): Batch processor instance
            config (BatchConfiguration): Configuration to process
        """
        super().__init__()
        self.batch_processor = batch_processor
        self.config = config
    
    def run(self):
        """Run batch processing."""
        try:
            completed, failed = self.batch_processor.process_configuration(self.config)
            self.finished.emit(completed, failed)
        except Exception as e:
            print(f"Batch processing error: {e}")
            self.finished.emit(0, len(self.config.jobs))