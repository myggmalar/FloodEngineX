"""
Minimal test to check for syntax errors in saint_venant_2d.py
"""

import os
import sys

# Try to compile the file without executing it
# This will catch syntax and indentation errors
try:
    with open("saint_venant_2d.py", "r") as f:
        source = f.read()
    
    # Compile the source code without executing it
    compile(source, "saint_venant_2d.py", "exec")
    print("SUCCESS: No syntax or indentation errors found in the file!")
    print("The indentation error has been fixed successfully.")
except IndentationError as e:
    print(f"IndentationError at line {e.lineno}, column {e.offset}: {e.msg}")
except SyntaxError as e:
    print(f"SyntaxError at line {e.lineno}, column {e.offset}: {e.msg}")
except Exception as e:
    print(f"Unexpected error: {str(e)}")
