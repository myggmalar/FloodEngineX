# FloodEngine v4.0 - User Guide
==============================

## Overview

FloodEngine is a comprehensive flood modeling plugin for QGIS that performs 2D shallow water simulations using the Saint-Venant equations. It's designed for hydraulic engineers, emergency planners, and researchers who need accurate flood modeling capabilities within QGIS.

## Features

### Core Capabilities
- **2D Shallow Water Modeling**: Full Saint-Venant equation implementation
- **Adaptive Time Stepping**: Automatic stability control for accurate results
- **Streamline Generation**: Advanced flow visualization and analysis
- **Timestep Animation**: Progressive flood visualization over time
- **Dam/Levee Modeling**: Overflow and breach calculations
- **Multiple Output Formats**: GeoTIFF, raster layers, and vector outputs

### Advanced Features
- **Hydraulic Routing**: Channel and overland flow calculations
- **Boundary Conditions**: Flexible inlet/outlet configurations
- **Manning's Roughness**: Spatially variable friction coefficients
- **Real-time Monitoring**: Progress tracking and result visualization

## Installation

### Requirements
- QGIS 3.x (3.16 or later recommended)
- Python 3.7+
- Minimum 4GB RAM (8GB+ recommended for large simulations)
- Available disk space for output files

### Installation Steps

1. **Download Plugin**
   - Extract `FloodEngine_v4.0_Production.zip`

2. **Install in QGIS**
   - Copy folder to QGIS plugins directory:
     - Windows: `%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\`
     - Linux: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`
     - macOS: `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`

3. **Enable Plugin**
   - Restart QGIS
   - Go to `Plugins > Manage and Install Plugins`
   - Find "FloodEngine" and check to enable
   - Plugin menu appears under `Plugins > FloodEngine`

## Quick Start Guide

### Basic Flood Simulation

1. **Prepare Input Data**
   ```
   Required:
   - DEM raster file (GeoTIFF format recommended)
   - Initial water level (meters above sea level)
   
   Optional:
   - Bathymetry data (CSV with X,Y,Z columns)
   - Manning's roughness raster
   - Boundary condition shapefiles
   ```

2. **Launch FloodEngine**
   - Click `Plugins > FloodEngine > FloodEngine`
   - Select "2D Shallow Water" model type

3. **Configure Basic Parameters**
   ```
   DEM Path: [Browse to your elevation file]
   Water Level: 10.0  (meters above sea level)
   Output Directory: [Choose output folder]
   Simulation Time: 3600  (seconds)
   Time Steps: 100
   Manning's n: 0.035  (typical value for natural channels)
   ```

4. **Run Simulation**
   - Click "Run Analysis"
   - Monitor progress in QGIS message bar
   - Results appear as new layers in Layer Panel

### Advanced Configuration

#### Timestep Animation
```
Enable Timestep Layers: ✓
Number of Timesteps: 10-20 (for animation)
Output Interval: 300 seconds (5 minutes)
```

#### Streamline Generation
```
Enable Streamlines: ✓
Streamline Density: Medium
Starting Points: Automatic (or upload point shapefile)
```

#### Performance Settings
```
CFL Number: 0.5 (stability control)
Max Iterations: 1000
Convergence Tolerance: 0.001
```

## Input Data Preparation

### DEM Requirements
- **Format**: GeoTIFF, ESRI Grid, or other GDAL-supported formats
- **Resolution**: 1-30 meters (finer for urban areas)
- **Coordinate System**: Any projected coordinate system
- **NoData Values**: Properly defined for water bodies
- **Units**: Elevation in meters

### Bathymetry Data (Optional)
- **Format**: CSV file with columns: X, Y, Z
- **Coordinate System**: Match DEM coordinate system
- **Coverage**: Should overlap with flood areas
- **Quality**: Remove outliers and ensure consistency

### Example Data Structure
```
DEM File: elevation.tif
├── Spatial Resolution: 5m x 5m
├── Coordinate System: EPSG:3006 (SWEREF99 TM)
├── Elevation Range: 0-200 meters
└── NoData Value: -9999

Bathymetry File: bathymetry.csv
├── Columns: X, Y, Depth
├── Format: 12345.67, 6789012.34, -2.5
├── Coordinate System: EPSG:3006
└── Points: 1000-10000 measurements
```

## Understanding Results

### Output Layers

1. **Depth Raster** (`flood_depth.tif`)
   - Water depth in meters
   - Zero values indicate dry areas
   - NoData for areas outside simulation domain

2. **Velocity Raster** (`flood_velocity.tif`)
   - Flow velocity in m/s
   - Combined horizontal velocity magnitude
   - Useful for hazard assessment

3. **Streamlines** (`streamlines.shp`)
   - Vector layer showing flow paths
   - Attributes include velocity and direction
   - Useful for understanding flow patterns

4. **Timestep Layers** (`flood_step_1.tif`, `flood_step_2.tif`, etc.)
   - Progressive flood development
   - Can be animated in QGIS
   - Shows temporal flood evolution

### Interpreting Results

#### Flood Depth Classification
```
0.0 - 0.1m:  Minimal flooding
0.1 - 0.5m:  Low hazard
0.5 - 1.0m:  Moderate hazard  
1.0 - 2.0m:  High hazard
> 2.0m:      Extreme hazard
```

#### Velocity Classification
```
0.0 - 0.5 m/s:  Low velocity
0.5 - 1.0 m/s:  Moderate velocity
1.0 - 2.0 m/s:  High velocity
> 2.0 m/s:     Very high velocity
```

## Troubleshooting

### Common Issues

1. **Plugin Not Loading**
   - Check QGIS version compatibility
   - Verify plugin folder location
   - Restart QGIS after installation

2. **Simulation Fails to Start**
   - Verify DEM file is valid and accessible
   - Check coordinate system consistency
   - Ensure output directory is writable

3. **No Flood Results**
   - Check if water level is above terrain elevation
   - Verify DEM has proper elevation values
   - Increase simulation time or reduce time steps

4. **Slow Performance**
   - Reduce DEM resolution for testing
   - Decrease number of time steps
   - Use smaller simulation domain
   - Close other applications to free memory

### Error Messages

#### "DEM file not found"
- Check file path and permissions
- Use full path without special characters
- Ensure file format is supported by GDAL

#### "Coordinate system mismatch"
- Reproject DEM to consistent coordinate system
- Use projected coordinates (not geographic)
- Check that all input data uses same CRS

#### "Insufficient memory"
- Reduce DEM size or resolution
- Close other applications
- Use 64-bit QGIS version
- Consider processing smaller domains

## Best Practices

### Data Preparation
1. Use high-quality, recent DEM data
2. Clean bathymetry data to remove outliers
3. Ensure consistent coordinate systems
4. Test with small domains before full simulations

### Simulation Setup
1. Start with coarse parameters for testing
2. Use appropriate time steps for stability
3. Set realistic Manning's roughness values
4. Define proper boundary conditions

### Result Analysis
1. Validate results against known data
2. Check for numerical artifacts
3. Compare with other modeling approaches
4. Document assumptions and limitations

## Advanced Topics

### Custom Manning's Roughness
Create raster with roughness values:
- Urban areas: 0.015-0.050
- Natural channels: 0.025-0.075
- Vegetated areas: 0.035-0.15
- Rocky areas: 0.030-0.050

### Boundary Conditions
Define specific inlet/outlet conditions:
- Constant head boundaries
- Flow rate specifications
- Stage-discharge relationships
- Tidal boundaries

### Model Calibration
1. Compare with measured flood data
2. Adjust Manning's roughness
3. Refine DEM if necessary
4. Validate against multiple events

## Support and Resources

### Documentation
- Plugin help: Press F1 in FloodEngine dialog
- QGIS documentation: https://qgis.org/en/docs/
- Hydraulic modeling theory: Academic literature

### Community
- Report issues with detailed error messages
- Share example datasets and use cases
- Contribute improvements and enhancements

### Professional Support
For complex projects requiring:
- Custom model development
- Large-scale simulations
- Specialized boundary conditions
- Integration with other systems

---

**FloodEngine v4.0 User Guide**  
*Last Updated: June 7, 2025*  
*Version: Production Release*
