#!/usr/bin/env python3
"""
Test the full animation workflow from UI to ensure everything works
"""

import sys
import os
from pathlib import Path

# Add current directory to path
script_dir = Path(__file__).parent
sys.path.insert(0, str(script_dir))

def create_test_animation_data():
    """Create test animation data to verify the launch process."""
    
    test_folder = "test_animation_results"
    animation_folder = os.path.join(test_folder, "time_series_animation")
    
    # Create directories
    os.makedirs(animation_folder, exist_ok=True)
    
    # Create a dummy raster file
    dummy_raster = os.path.join(animation_folder, "depth_t000.tif")
    with open(dummy_raster, "w") as f:
        f.write("dummy raster file")
    
    print(f"✅ Created test data in: {animation_folder}")
    return test_folder

def test_full_animation_workflow():
    """Test the complete animation workflow."""
    
    print("🧪 Testing full animation workflow...")
    
    try:
        # Create test data
        test_folder = create_test_animation_data()
        
        # Import required modules
        from launch_animation import launch_animation_from_folder
        from PyQt5.QtWidgets import QApplication, QWidget
        
        # Create QApplication if needed
        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)
            print("📱 Created QApplication")
        
        # Create a dummy parent widget
        parent_widget = QWidget()
        parent_widget.setWindowTitle("Test Parent Widget")
        print("✅ Created parent widget")
        
        print("🧪 Testing animation launch with real parent...")
        result = launch_animation_from_folder(test_folder, standalone=True, parent=parent_widget)
        
        if result:
            print("✅ Animation dialog created successfully!")
            print("ℹ️ Dialog should be visible...")
            
            # Keep the app running for a moment to see the dialog
            import time
            time.sleep(2)
            
        else:
            print("❌ Animation dialog creation failed")
            
        # Cleanup
        import shutil
        shutil.rmtree(test_folder, ignore_errors=True)
        print("🧹 Cleaned up test data")
        
        return result
        
    except Exception as e:
        print(f"❌ Error in workflow test: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_full_animation_workflow()
    if success:
        print("✅ Full workflow test completed successfully")
    else:
        print("❌ Full workflow test failed")
