# Copy and paste this entire block into the QGIS Python console:

# QGIS Animation Launch Test
import sys, os, importlib

# Add FloodEngineX path
plugin_path = r"C:\Plugin\VSCode\Alt3\FloodEngineX"
if plugin_path not in sys.path:
    sys.path.insert(0, plugin_path)

# Force reload launch_animation module
if 'launch_animation' in sys.modules:
    import launch_animation
    importlib.reload(launch_animation)
    print("✅ Reloaded launch_animation module")

from launch_animation import launch_animation_from_folder

# Check function signature
import inspect
sig = inspect.signature(launch_animation_from_folder)
print(f"✅ Function signature: {sig}")

# Animation folder from recent run
animation_folder = r"C:\Plugin\VSCode\output\time_series_animation"

# Get QGIS parent window
try:
    from qgis.utils import iface
    parent_window = iface.mainWindow() if iface else None
    print(f"✅ QGIS parent window: {type(parent_window).__name__ if parent_window else 'None'}")
except:
    parent_window = None

# Launch animation dialog
print("🚀 Launching animation dialog...")
try:
    result = launch_animation_from_folder(animation_folder, standalone=True, parent=parent_window)
    if result:
        print("🎉 SUCCESS! Animation dialog launched and should be visible!")
        print(f"🔍 Dialog type: {type(result)}")
    else:
        print("❌ Launch returned False")
except Exception as e:
    print(f"❌ Error: {e}")
    # Try without parent argument as fallback
    try:
        print("🔄 Trying without parent argument...")
        result = launch_animation_from_folder(animation_folder, standalone=True)
        if result:
            print("🎉 SUCCESS! Animation dialog launched (no parent)!")
        else:
            print("❌ Still failed")
    except Exception as e2:
        print(f"❌ Still failed: {e2}")
