"""
Simple print test to verify the script runs
"""
print("Starting syntax check...")

# Try to import the key modules
try:
    import floodengine_ui
    print("✅ floodengine_ui.py imported successfully")
except Exception as e:
    print(f"❌ Error importing floodengine_ui.py: {e}")

try:
    import floodengine
    print("✅ floodengine.py imported successfully")
except Exception as e:
    print(f"❌ Error importing floodengine.py: {e}")

try:
    import model_hydraulic
    print("✅ model_hydraulic.py imported successfully")
except Exception as e:
    print(f"❌ Error importing model_hydraulic.py: {e}")

try:
    import flow_direction_flood_fixed
    print("✅ flow_direction_flood_fixed.py imported successfully")
except Exception as e:
    print(f"❌ Error importing flow_direction_flood_fixed.py: {e}")

print("Syntax check complete!")
