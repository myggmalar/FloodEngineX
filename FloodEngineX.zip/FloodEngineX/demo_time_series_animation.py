#!/usr/bin/env python3
"""
FloodEngine Time Series Animation Demo
=====================================
Complete demonstration of the time series animation system with interactive features.
"""

import os
import sys
import numpy as np
import logging
from pathlib import Path

# Add FloodEngineX to path
sys.path.insert(0, str(Path(__file__).parent))

from saint_venant_2d import simulate_saint_venant_2d
from time_series_integration import integrate_time_series_animation

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def create_demo_dem():
    """Create a demonstration DEM for flood simulation."""
    logger.info("🏔️ Creating demonstration DEM...")
    
    # Create a 100x100 grid (100m x 100m)
    size = 100
    dem_array = np.zeros((size, size))
    
    # Create a valley with a river channel
    for i in range(size):
        for j in range(size):
            # General elevation increases with distance from center
            center_i, center_j = size // 2, size // 2
            dist_from_center = np.sqrt((i - center_i)**2 + (j - center_j)**2)
            
            # Base elevation
            dem_array[i, j] = 100 + 0.01 * dist_from_center
            
            # River channel (diagonal from top-left to bottom-right)
            channel_distance = abs(i - j)
            if channel_distance < 5:  # 5-cell wide channel
                dem_array[i, j] -= 3.0  # 3m deep channel
            elif channel_distance < 10:  # Floodplain
                dem_array[i, j] -= 1.0  # 1m lower floodplain
    
    # Add some hills
    hill1_i, hill1_j = 20, 20
    hill2_i, hill2_j = 80, 80
    
    for i in range(size):
        for j in range(size):
            # Hill 1
            dist1 = np.sqrt((i - hill1_i)**2 + (j - hill1_j)**2)
            if dist1 < 15:
                dem_array[i, j] += 5.0 * np.exp(-dist1 / 5.0)
            
            # Hill 2
            dist2 = np.sqrt((i - hill2_i)**2 + (j - hill2_j)**2)
            if dist2 < 15:
                dem_array[i, j] += 4.0 * np.exp(-dist2 / 5.0)
    
    return dem_array

def save_demo_dem(dem_array, output_path):
    """Save the DEM as a GeoTIFF file."""
    try:
        from osgeo import gdal
        
        # Create geotransform (1m pixel size)
        geotransform = (0, 1, 0, dem_array.shape[0], 0, -1)
        
        # Create dataset
        driver = gdal.GetDriverByName('GTiff')
        dataset = driver.Create(
            output_path, 
            dem_array.shape[1], 
            dem_array.shape[0], 
            1, 
            gdal.GDT_Float32
        )
        
        # Set geotransform and projection
        dataset.SetGeoTransform(geotransform)
        dataset.SetProjection('EPSG:3006')  # RH2000 / SWEREF99 TM
        
        # Write data
        band = dataset.GetRasterBand(1)
        band.WriteArray(dem_array)
        band.SetNoDataValue(-9999)
        band.ComputeStatistics(0)
        
        # Clean up
        dataset = None
        logger.info(f"📁 DEM saved to: {output_path}")
        
    except ImportError:
        logger.warning("⚠️ GDAL not available - cannot save DEM file")
        # Save as numpy array instead
        np.save(output_path.replace('.tif', '.npy'), dem_array)
        logger.info(f"📁 DEM saved as numpy array: {output_path.replace('.tif', '.npy')}")

def run_demo_simulation():
    """Run a complete demonstration of the time series animation system."""
    logger.info("🚀 Starting FloodEngine Time Series Animation Demo")
    
    # Create output directory
    output_dir = Path("demo_flood_animation")
    output_dir.mkdir(exist_ok=True)
    
    # Create DEM
    dem_array = create_demo_dem()
    dem_path = output_dir / "demo_dem.tif"
    save_demo_dem(dem_array, str(dem_path))
    
    # Run flood simulation with time series animation
    logger.info("🌊 Running flood simulation with time series animation...")
    
    try:
        # Check if we have GDAL for proper simulation
        if str(dem_path).endswith('.npy'):
            logger.info("📊 Running simulation with numpy array (GDAL not available)")
            # Create synthetic results for demonstration
            results = create_synthetic_results(dem_array)
        else:
            # Run full Saint-Venant simulation
            logger.info("🔧 Running full Saint-Venant simulation...")
            results = simulate_saint_venant_2d(
                dem_path=str(dem_path),
                water_level=102.0,  # 2m above lowest point
                output_folder=str(output_dir),
                total_time=300,     # 5 minutes
                time_step=5.0,      # 5 second timesteps
                manning_n=0.035,
                save_interval=10.0  # Save every 10 seconds
            )
    
    except Exception as e:
        logger.warning(f"⚠️ Full simulation failed: {e}")
        logger.info("📊 Creating synthetic results for demonstration...")
        results = create_synthetic_results(dem_array)
    
    # Display results
    display_results(results, output_dir)
    
    # Show usage instructions
    show_usage_instructions()
    
    logger.info("🎉 Demo completed successfully!")

def create_synthetic_results(dem_array):
    """Create synthetic flood results for demonstration."""
    logger.info("🎭 Creating synthetic flood animation data...")
    
    # Time series setup
    total_time = 300  # 5 minutes
    time_step = 10    # 10 seconds
    times = np.arange(0, total_time + time_step, time_step)
    
    water_depths = []
    velocity_x = []
    velocity_y = []
    
    # Simulate flood progression
    for t in times:
        # Create flood wave
        progress = min(1.0, float(t / 180.0))  # Full extent at 3 minutes
        wave_height = 1.0 + 0.5 * np.sin(t * 0.02)  # Varying height
        
        # Initialize arrays
        depth = np.zeros_like(dem_array)
        vel_x = np.zeros_like(dem_array)
        vel_y = np.zeros_like(dem_array)
        
        # Flood along diagonal (river channel)
        for i in range(dem_array.shape[0]):
            for j in range(dem_array.shape[1]):
                # Distance from diagonal
                diag_dist = abs(i - j)
                
                # Flood spreads from channel
                if diag_dist < progress * 20:  # Spreads up to 20 cells
                    channel_depth = wave_height * np.exp(-diag_dist * 0.1)
                    depth[i, j] = max(0, channel_depth)
                    
                    # Add velocity
                    if depth[i, j] > 0.01:
                        vel_x[i, j] = 1.0 * np.sqrt(depth[i, j])
                        vel_y[i, j] = 0.5 * np.sqrt(depth[i, j])
        
        water_depths.append(depth)
        velocity_x.append(vel_x)
        velocity_y.append(vel_y)
    
    # Create results dictionary
    results = {
        'success': True,
        'times': times,
        'water_depths': water_depths,
        'velocity_x': velocity_x,
        'velocity_y': velocity_y,
        'dem_array': dem_array,
        'geotransform': (0, 1, 0, dem_array.shape[0], 0, -1),
        'projection': 'EPSG:3006'
    }
    
    logger.info(f"✅ Created synthetic results: {len(times)} timesteps")
    return results

def display_results(results, output_dir):
    """Display the simulation results."""
    logger.info("📊 Displaying simulation results...")
    
    if not results['success']:
        logger.error("❌ Simulation failed!")
        return
    
    num_timesteps = len(results['times'])
    total_time = results['times'][-1]
    max_depth = max(np.max(depth) for depth in results['water_depths'])
    
    print("\n" + "="*60)
    print("FLOOD SIMULATION RESULTS")
    print("="*60)
    print(f"📊 Timesteps: {num_timesteps}")
    print(f"⏱️ Total Time: {total_time:.1f} seconds")
    print(f"🌊 Maximum Depth: {max_depth:.2f} meters")
    print(f"📁 Output Directory: {output_dir}")
    
    # Check if animation was set up
    if 'animation_setup' in results:
        animation_info = results['animation_setup']
        if animation_info['success']:
            print(f"🎬 Animation Setup: SUCCESS")
            print(f"📁 Animation Folder: {animation_info['output_folder']}")
            print(f"📖 Instructions: {animation_info['instructions_file']}")
        else:
            print(f"⚠️ Animation Setup: FAILED ({animation_info.get('error', 'Unknown error')})")
    
    print("="*60)

def show_usage_instructions():
    """Show detailed usage instructions."""
    print("\\n" + "="*60)
    print("HOW TO USE THE TIME SERIES ANIMATION")
    print("="*60)
    
    print("\\n1. 🎥 IN QGIS:")
    print("   • Open QGIS and load the FloodEngine plugin")
    print("   • Run your flood simulation")
    print("   • Look for the 'Time Series Animation' dialog")
    print("   • Use the play/pause/step controls")
    print("   • Click on the map to sample data at any point")
    
    print("\\n2. 📁 MANUAL SETUP:")
    print("   • Navigate to the 'demo_flood_animation' folder")
    print("   • Open the 'time_series_animation' subfolder")
    print("   • Load all raster files in the 'rasters' folder into QGIS")
    print("   • Group them by type (depth, surface, velocity)")
    print("   • Use layer visibility to create animation")
    
    print("\\n3. 🎯 INTERACTIVE FEATURES:")
    print("   • Click anywhere on the map to see:")
    print("     - Water depth at that location")
    print("     - Surface elevation (RH2000 coordinates)")
    print("     - Flow velocity (if available)")
    print("     - Complete time series chart")
    
    print("\\n4. 📊 DATA FORMATS:")
    print("   • Depths: meters above ground level")
    print("   • Surface elevations: meters above RH2000 datum")
    print("   • Velocities: meters per second")
    print("   • Coordinates: RH2000 / SWEREF99 TM (EPSG:3006)")
    
    print("\\n5. 🔧 AUTOMATION:")
    print("   • Animation setup is automatic when using Saint-Venant solver")
    print("   • All raster files are generated automatically")
    print("   • QGIS integration is set up automatically (if available)")
    print("   • Usage instructions are generated in output folder")
    
    print("\\n" + "="*60)
    print("🎬 Ready to create interactive flood animations!")
    print("="*60)

if __name__ == "__main__":
    try:
        run_demo_simulation()
    except KeyboardInterrupt:
        logger.info("Demo interrupted by user")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Demo failed: {e}")
        sys.exit(1)
