#!/usr/bin/env python3
"""
Diagnostic script to check how velocity is being calculated
"""

import sys
import os
import numpy as np
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def diagnose_velocity_calculation():
    """Diagnose which velocity calculation path is being used"""
    print("🔍 VELOCITY CALCULATION DIAGNOSTIC")
    print("=" * 50)
    
    print("\n📋 Current velocity calculation has TWO paths:")
    print("\n1️⃣ SAINT-VENANT 2D (Direct from model - NO guessing!):")
    print("   ✅ Uses actual velocity_x and velocity_y from 2D solver")
    print("   ✅ velocity_mag = sqrt(velocity_x² + velocity_y²)")
    print("   ✅ No Manning's equation, no approximations")
    print("   ❓ Condition: saint_venant_results is not None AND method == 'saint_venant'")
    
    print("\n2️⃣ HYDRAULIC APPROXIMATION (Manning's + flow accumulation):")
    print("   ⚠️  Uses Manning's equation with bed slope")
    print("   ⚠️  Adds hydraulic pressure from upstream")
    print("   ⚠️  Applies channel factors and flow bonuses")
    print("   ⚠️  This is the 'guessing game' with unrealistic 6 m/s values")
    print("   ❓ Condition: saint_venant_results is None OR method != 'saint_venant'")
    
    print("\n🔍 TO DIAGNOSE YOUR CASE:")
    print("We need to check:")
    print("1. Is saint_venant_results being passed to the function?")
    print("2. What is the 'method' parameter value?")
    print("3. What velocities are in the Saint-Venant results?")
    print("4. Are the 6 m/s values coming from the 2D model or the approximation?")
    
    return True

def check_saint_venant_integration():
    """Check how Saint-Venant results should be integrated"""
    print("\n🔗 SAINT-VENANT INTEGRATION CHECK")
    print("=" * 40)
    
    print("\n📂 Saint-Venant 2D solver should export:")
    print("   • velocity_x.tif - X-component of velocity (can be negative)")
    print("   • velocity_y.tif - Y-component of velocity (can be negative)")
    print("   • These are passed as saint_venant_results dict")
    
    print("\n📞 Flow points should be called like:")
    print("   flow_points.calculate_velocity_field(")
    print("       method='saint_venant',")
    print("       saint_venant_results={")
    print("           'velocity_x': velocity_x_array,")
    print("           'velocity_y': velocity_y_array")
    print("       }")
    print("   )")
    
    print("\n❗ IF YOU'RE SEEING 6 m/s VALUES:")
    print("   Option A: Saint-Venant results not passed → using Manning's approximation")
    print("   Option B: Saint-Venant 2D model itself produces unrealistic velocities")
    print("   Option C: Method parameter is not set to 'saint_venant'")
    
    return True

def suggest_debugging_steps():
    """Suggest debugging steps"""
    print("\n🔧 DEBUGGING STEPS")
    print("=" * 20)
    
    print("\n1️⃣ Check the main calling code:")
    print("   • Look for 'calculate_velocity_field' calls")
    print("   • Check if method='saint_venant'")
    print("   • Check if saint_venant_results is passed")
    
    print("\n2️⃣ Add logging to see which path is taken:")
    print("   • Look for log message: 'Using Saint-Venant velocity field results'")
    print("   • If you see 'Using 2D hydraulic modeling', it's using approximation!")
    
    print("\n3️⃣ Check Saint-Venant solver output:")
    print("   • Are velocity_x.tif and velocity_y.tif files created?")
    print("   • What are the max/min values in these files?")
    print("   • Are they realistic (typically -3 to +3 m/s)?")
    
    print("\n4️⃣ Check if bathymetry affects Saint-Venant solver:")
    print("   • Missing bathymetry affects the 2D model setup")
    print("   • May cause unrealistic bed slopes in the solver")
    print("   • This could explain both slow channels AND high velocities")
    
    return True

if __name__ == "__main__":
    try:
        diagnose_velocity_calculation()
        check_saint_venant_integration()
        suggest_debugging_steps()
        
        print("\n🎯 CONCLUSION:")
        print("The velocity should be DIRECTLY from your 2D model, not approximated!")
        print("If you're seeing unrealistic values, the issue is likely:")
        print("  A) Saint-Venant results not being used (wrong method/missing data)")
        print("  B) 2D model itself producing bad velocities due to missing bathymetry")
        print("\nNext step: Check the logs to see which calculation path is actually used!")
        
    except Exception as e:
        print(f"\n❌ Diagnostic failed: {e}")
        sys.exit(1)
