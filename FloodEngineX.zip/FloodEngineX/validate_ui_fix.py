"""
Validation script for FloodEngine fixed flow direction UI changes
"""
from qgis.PyQt.QtWidgets import QApplication
import os
import sys

# To be run inside QGIS Python Console
def validate_fixed_flow_ui():
    """
    Validates that the fixed flow direction UI changes were implemented correctly
    """
    try:
        from floodengine_ui import FloodEngineDialog
        print("✅ Successfully imported FloodEngineDialog")
        
        # Test creating a dialog
        dialog = FloodEngineDialog()
        
        # Verify UI components exist
        if not hasattr(dialog, 'use_fixed_flow'):
            print("❌ ERROR: use_fixed_flow checkbox not found in FloodEngineDialog")
            return False
            
        if not hasattr(dialog, 'use_fixed_flow_wl'):
            print("❌ ERROR: use_fixed_flow_wl checkbox not found in FloodEngineDialog")
            return False
            
        if not hasattr(dialog, 'status_label'):
            print("❌ ERROR: status_label not found in FloodEngineDialog")
            return False
            
        # Test functionality
        print(f"Flow Q fixed flow enabled by default: {dialog.use_fixed_flow.isChecked()}")
        print(f"Water level fixed flow enabled by default: {dialog.use_fixed_flow_wl.isChecked()}")
        
        # Test status message
        dialog.show_status_message("Testing status message functionality")
        print("✅ Status message displayed")
        
        print("✅ All UI components for fixed flow direction are properly implemented!")
        return True
        
    except Exception as e:
        print(f"❌ ERROR during validation: {str(e)}")
        import traceback
        traceback.print_exc()
        return False
        
if __name__ == "__main__":
    print("Running validation for FloodEngine fixed flow direction UI...")
    validate_fixed_flow_ui()
