#!/usr/bin/env python3
"""
Test script to verify the channel start point fix for FloodEngine
This demonstrates that water now starts from the highest elevation points in channels
"""
import numpy as np
import sys
import os

# Add the plugin directory to the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def create_test_dem():
    """Create a test DEM with a clear channel from high to low elevation"""
    # Create a 100x100 DEM
    dem = np.full((100, 100), 100.0, dtype=np.float32)  # Base elevation 100m
    
    # Create a channel running from top (high) to bottom (low)
    channel_col = 50  # Center column
    channel_width = 5
    
    for row in range(100):
        # Channel elevation decreases from top (110m) to bottom (90m)
        channel_elevation = 110.0 - (row / 100.0) * 20.0  # 110m to 90m
        
        # Apply channel elevation to the channel area
        for col in range(channel_col - channel_width, channel_col + channel_width + 1):
            if 0 <= col < 100:
                dem[row, col] = channel_elevation
    
    # Add some random terrain variation outside the channel
    for i in range(100):
        for j in range(100):
            if abs(j - channel_col) > channel_width:
                dem[i, j] += np.random.uniform(-5, 5)
    
    return dem

def test_find_channel_start_points():
    """Test the find_channel_start_points function"""
    print("=== Testing Channel Start Point Detection ===")
    
    # Import the function we're testing
    try:
        from flow_direction_flood import find_channel_start_points
    except ImportError:
        print("ERROR: Could not import find_channel_start_points")
        return False
    
    # Create test DEM
    dem = create_test_dem()
    print(f"Created test DEM: {dem.shape}, elevation range {np.min(dem):.1f}m to {np.max(dem):.1f}m")
    
    # Test in flow mode (Q mode) - should find single highest point
    print("\n--- Testing Flow Mode (Q > 0) ---")
    flow_q = 50.0  # 50 m³/s
    start_points = find_channel_start_points(dem, flow_q=flow_q)
    
    if start_points:
        print(f"Found {len(start_points)} start points in flow mode:")
        for i, (row, col, elev) in enumerate(start_points):
            print(f"  Point {i+1}: Row={row}, Col={col}, Elevation={elev:.2f}m")
        
        # Verify that we found the highest point
        highest_elev = np.max(dem[~np.isnan(dem)])
        start_elev = start_points[0][2]
        
        print(f"Highest elevation in DEM: {highest_elev:.2f}m")
        print(f"Start point elevation: {start_elev:.2f}m")
        
        if abs(start_elev - highest_elev) < 0.1:
            print("✓ SUCCESS: Flow mode correctly identified highest elevation point")
            return True
        else:
            print("✗ FAIL: Flow mode did not find the highest point")
            return False
    else:
        print("✗ FAIL: No start points found in flow mode")
        return False

def test_water_level_mode():
    """Test water level mode (should find multiple points)"""
    print("\n--- Testing Water Level Mode (No Q) ---")
    
    try:
        from flow_direction_flood import find_channel_start_points
    except ImportError:
        print("ERROR: Could not import find_channel_start_points")
        return False
    
    dem = create_test_dem()
    
    # Test in water level mode (no flow_q) - should find multiple high points
    start_points = find_channel_start_points(dem, flow_q=None)
    
    if start_points:
        print(f"Found {len(start_points)} start points in water level mode:")
        for i, (row, col, elev) in enumerate(start_points[:5]):  # Show first 5
            print(f"  Point {i+1}: Row={row}, Col={col}, Elevation={elev:.2f}m")
        
        # Verify that points are sorted by elevation (highest first)
        elevations = [elev for _, _, elev in start_points]
        is_sorted = all(elevations[i] >= elevations[i+1] for i in range(len(elevations)-1))
        
        if is_sorted and len(start_points) > 1:
            print("✓ SUCCESS: Water level mode found multiple points sorted by elevation")
            return True
        else:
            print("✗ FAIL: Water level mode points not properly sorted or too few points")
            return False
    else:
        print("✗ FAIL: No start points found in water level mode")
        return False

def main():
    """Run all tests"""
    print("FloodEngine Channel Start Point Fix - Test Suite")
    print("=" * 60)
    
    # Test 1: Flow mode (Q > 0)
    test1_result = test_find_channel_start_points()
    
    # Test 2: Water level mode (Q = None)  
    test2_result = test_water_level_mode()
    
    print("\n" + "=" * 60)
    print("TEST RESULTS:")
    print(f"Flow Mode Test: {'PASS' if test1_result else 'FAIL'}")
    print(f"Water Level Mode Test: {'PASS' if test2_result else 'FAIL'}")
    
    if test1_result and test2_result:
        print("\n✓ ALL TESTS PASSED - Channel start point fix is working correctly!")
        print("Water will now start from the highest elevation points in channels.")
        return True
    else:
        print("\n✗ SOME TESTS FAILED - Channel start point fix needs debugging.")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
