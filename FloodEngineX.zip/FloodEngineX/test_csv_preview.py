#!/usr/bin/env python3
"""
Test CSV preview functionality in FloodEngine UI
"""

import sys
import os
import csv
from PyQt5.QtWidgets import QApplication

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def create_sample_csv():
    """Create a sample CSV file for testing"""
    sample_file = os.path.join(os.path.dirname(__file__), 'sample_bathymetry.csv')
    
    with open(sample_file, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['X', 'Y', 'Elevation', 'Source'])  # Headers
        
        # Sample data points
        for i in range(10):
            x = 100000 + i * 10
            y = 200000 + i * 15
            elevation = 50 + i * 0.5
            source = f'Point_{i+1}'
            writer.writerow([x, y, elevation, source])
    
    return sample_file

def test_csv_preview():
    """Test the CSV preview functionality"""
    try:
        # Create sample CSV
        sample_file = create_sample_csv()
        print(f"Created sample CSV: {sample_file}")
        
        # Import and test the UI
        from floodengine_ui import FloodEngineUI
        
        app = QApplication(sys.argv)
        ui = FloodEngineUI()
        
        # Set the bathymetry file path
        if hasattr(ui, 'basic_bath_path'):
            print("Setting bathymetry file path...")
            ui.basic_bath_path.setText(sample_file)
            
            # Check if preview table has data
            if hasattr(ui, 'basic_bath_preview'):
                row_count = ui.basic_bath_preview.rowCount()
                col_count = ui.basic_bath_preview.columnCount()
                print(f"Preview table dimensions: {row_count} rows x {col_count} columns")
                
                if row_count > 0 and col_count > 0:
                    print("✓ CSV preview loaded successfully!")
                    
                    # Check column headers
                    headers = []
                    for col in range(col_count):
                        header = ui.basic_bath_preview.horizontalHeaderItem(col)
                        if header:
                            headers.append(header.text())
                    print(f"Column headers: {headers}")
                    
                    # Check first row of data
                    first_row = []
                    for col in range(col_count):
                        item = ui.basic_bath_preview.item(0, col)
                        if item:
                            first_row.append(item.text())
                    print(f"First data row: {first_row}")
                    
                else:
                    print("✗ CSV preview table is empty")
            
            # Check column selectors
            selectors = ['basic_x_column', 'basic_y_column', 'basic_z_column']
            for selector_name in selectors:
                if hasattr(ui, selector_name):
                    selector = getattr(ui, selector_name)
                    items = [selector.itemText(i) for i in range(selector.count())]
                    current = selector.currentText()
                    print(f"{selector_name}: {items} (selected: {current})")
        
        # Clean up
        if os.path.exists(sample_file):
            os.remove(sample_file)
            print(f"Cleaned up sample file: {sample_file}")
            
        print("CSV preview test completed successfully!")
        return True
        
    except Exception as e:
        print(f"Error in CSV preview test: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_csv_preview()
    if success:
        print("\n🎉 CSV preview functionality is working!")
    else:
        print("\n⚠️ CSV preview test failed")
