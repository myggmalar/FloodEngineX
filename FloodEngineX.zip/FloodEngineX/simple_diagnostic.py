#!/usr/bin/env python3
"""
Simple diagnostic script to check FloodEngine functions without GDAL dependencies
"""

def test_function_availability():
    """Test availability of key functions"""
    print("🔧 Testing FloodEngine Function Availability")
    print("=" * 50)
    
    # Test model_hydraulic imports
    try:
        from model_hydraulic import (
            simulate_over_time,
            simulate_over_time_FIXED,
            generate_variable_water_levels_IMPROVED,
            calculate_streamlines_ENHANCED
        )
        print("✅ All main functions available")
        
        # Check function signatures
        import inspect
        
        print("\n📋 Function Signatures:")
        sig_simulate = inspect.signature(simulate_over_time)
        print(f"simulate_over_time: {sig_simulate}")
        
        sig_fixed = inspect.signature(simulate_over_time_FIXED)
        print(f"simulate_over_time_FIXED: {sig_fixed}")
        
        sig_water_levels = inspect.signature(generate_variable_water_levels_IMPROVED)
        print(f"generate_variable_water_levels_IMPROVED: {sig_water_levels}")
        
        sig_streamlines = inspect.signature(calculate_streamlines_ENHANCED)
        print(f"calculate_streamlines_ENHANCED: {sig_streamlines}")
        
        return True
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False

def test_ui_integration():
    """Test which UI file is being used"""
    print("\n🖥️ Testing UI Integration")
    print("=" * 30)
    
    import os
    
    # Check which UI files exist
    ui_files = [
        "floodengine_ui.py",
        "floodengine_ui.py.normalized"
    ]
    
    for ui_file in ui_files:
        if os.path.exists(ui_file):
            print(f"✅ {ui_file} exists")
            
            # Check for FIXED function usage
            with open(ui_file, 'r', encoding='utf-8') as f:
                content = f.read()
                if "simulate_over_time_FIXED" in content:
                    print(f"  → Uses FIXED version")
                else:
                    print(f"  → Uses original version")
        else:
            print(f"❌ {ui_file} not found")

def test_water_level_generation():
    """Test water level generation without actual simulation"""
    print("\n🌊 Testing Water Level Generation")
    print("=" * 40)
    
    try:
        from model_hydraulic import generate_variable_water_levels_IMPROVED
        
        # Test water level generation
        water_levels = generate_variable_water_levels_IMPROVED(
            initial_level=60.0,
            time_steps=10,
            flow_q=100.0,
            method="accumulation"
        )
        
        print(f"✅ Generated {len(water_levels)} water levels")
        print(f"📊 Range: {min(water_levels):.2f}m to {max(water_levels):.2f}m")
        print(f"📈 Levels: {[f'{wl:.1f}' for wl in water_levels[:5]]}... (first 5)")
        
        return True
        
    except Exception as e:
        print(f"❌ Water level generation failed: {e}")
        return False

def test_hydraulic_calculations():
    """Test hydraulic calculation functions"""
    print("\n🔧 Testing Hydraulic Calculations")
    print("=" * 40)
    
    try:
        from model_hydraulic_q import calculate_water_level_from_flow
        
        # Test hydraulic calculations
        water_level = calculate_water_level_from_flow(
            flow_q=100.0,
            dem_path="test_path.tif",  # Won't actually be used in calculation
            channel_shape="rectangular",
            manning_n=0.035
        )
        
        print(f"✅ Calculated water level: {water_level:.2f}m for Q=100 m³/s")
        return True
        
    except Exception as e:
        print(f"❌ Hydraulic calculation failed: {e}")
        return False

def run_all_tests():
    """Run all diagnostic tests"""
    print("🚀 FloodEngine Simple Diagnostic")
    print("=" * 60)
    
    results = []
    
    results.append(("Function Availability", test_function_availability()))
    results.append(("Water Level Generation", test_water_level_generation()))
    results.append(("Hydraulic Calculations", test_hydraulic_calculations()))
    
    test_ui_integration()
    
    print("\n📊 Test Results Summary")
    print("=" * 30)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{test_name}: {status}")
    
    total_passed = sum(results)
    print(f"\nOverall: {total_passed}/{len(results)} tests passed")
    
    if total_passed == len(results):
        print("🎉 All core functions are working!")
    else:
        print("⚠️ Some issues found - check output above")

if __name__ == "__main__":
    run_all_tests()
