"""
Global Animation Dialog Manager
==============================
Manages persistent references to animation dialogs to prevent garbage collection.
"""

# Global storage for animation dialogs
_active_animation_dialogs = []

def store_animation_dialog(dialog):
    """Store an animation dialog reference to prevent garbage collection."""
    global _active_animation_dialogs
    _active_animation_dialogs.append(dialog)
    print(f"✅ Stored animation dialog #{len(_active_animation_dialogs)}")
    return dialog

def get_active_dialogs():
    """Get list of active animation dialogs."""
    global _active_animation_dialogs
    return _active_animation_dialogs

def cleanup_dialogs():
    """Clean up closed dialogs."""
    global _active_animation_dialogs
    active = []
    for dialog in _active_animation_dialogs:
        try:
            if dialog.isVisible():
                active.append(dialog)
        except:
            pass  # Dialog was already deleted
    _active_animation_dialogs = active
    print(f"📊 Cleaned up dialogs, {len(active)} still active")
