#!/usr/bin/env python3
"""
Simple Animation Test (No GDAL Required)
=======================================
Test animation controls without requiring GDAL.
"""

import sys
import os
import numpy as np
from pathlib import Path

# Add FloodEngineX to path
script_dir = Path(__file__).parent
sys.path.insert(0, str(script_dir))

def create_simple_test_data():
    """Create simple test data without GDAL."""
    print("📊 Creating simple test data...")
    
    # Simple 30x30 grid
    nx, ny = 30, 30
    
    # Create 10 timesteps over different time periods
    times_2h = np.linspace(0, 7200, 10)  # 2 hours
    times_10h = np.linspace(0, 36000, 10)  # 10 hours
    
    water_depths_2h = []
    water_depths_10h = []
    
    # Create simple expanding flood
    for i, (t2, t10) in enumerate(zip(times_2h, times_10h)):
        # 2-hour simulation - faster expansion
        radius_2h = 5 + i * 2  # Expands quickly
        depth_2h = np.zeros((ny, nx))
        
        for y in range(ny):
            for x in range(nx):
                distance = np.sqrt((x - 15)**2 + (y - 15)**2)
                if distance <= radius_2h:
                    depth_2h[y, x] = max(0, 2.0 - distance * 0.1)
        
        water_depths_2h.append(depth_2h)
        
        # 10-hour simulation - slower expansion
        radius_10h = 5 + i * 1.5  # Expands more slowly
        depth_10h = np.zeros((ny, nx))
        
        for y in range(ny):
            for x in range(nx):
                distance = np.sqrt((x - 15)**2 + (y - 15)**2)
                if distance <= radius_10h:
                    depth_10h[y, x] = max(0, 1.5 - distance * 0.08)
        
        water_depths_10h.append(depth_10h)
    
    # Create simple DEM
    dem = np.ones((ny, nx)) * 100.0
    
    # Package results
    results_2h = {
        'times': times_2h.tolist(),
        'water_depths': water_depths_2h,
        'dem_array': dem,
        'geotransform': (0, 10, 0, 300, 0, -10),
        'projection': 'EPSG:4326'
    }
    
    results_10h = {
        'times': times_10h.tolist(),
        'water_depths': water_depths_10h,
        'dem_array': dem,
        'geotransform': (0, 10, 0, 300, 0, -10),
        'projection': 'EPSG:4326'
    }
    
    print("✅ Test data created")
    print(f"2h times: {[f'{t:.0f}s' for t in times_2h]}")
    print(f"10h times: {[f'{t:.0f}s' for t in times_10h]}")
    
    return results_2h, results_10h

def test_animation_directly():
    """Test animation controls directly."""
    print("\n🎬 Testing animation controls...")
    
    try:
        from PyQt5.QtWidgets import QApplication
        from time_series_animator import TimeSeriesAnimator
        import tempfile
        
        # Create test data
        results_2h, results_10h = create_simple_test_data()
        
        # Compare max depths to verify they're different
        max_depths_2h = [np.max(d) for d in results_2h['water_depths']]
        max_depths_10h = [np.max(d) for d in results_10h['water_depths']]
        
        print(f"\n📈 Max depths comparison:")
        print(f"2h simulation: {[f'{d:.2f}m' for d in max_depths_2h]}")
        print(f"10h simulation: {[f'{d:.2f}m' for d in max_depths_10h]}")
        
        if abs(max_depths_2h[-1] - max_depths_10h[-1]) > 0.1:
            print("✅ GOOD: Different results for different time periods")
        else:
            print("⚠️ WARNING: Results are very similar")
        
        # Create QApplication
        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)
        
        # Create temporary folder
        temp_dir = tempfile.mkdtemp(prefix='animation_test_')
        print(f"📁 Using temp directory: {temp_dir}")
        
        # Create animator with 2-hour results
        animator = TimeSeriesAnimator(results_2h, temp_dir)
        animator.setWindowTitle("FloodEngine Test - Animation Controls")
        animator.resize(900, 700)
        animator.show()
        animator.raise_()
        animator.activateWindow()
        
        print("🎮 Animation controls launched!")
        print("Expected to see:")
        print("  ✅ Play/Pause buttons")
        print("  ✅ Timeline slider")
        print("  ✅ 10 timesteps (0-9)")
        print("  ✅ Time range: 0s to 7200s")
        print("  ✅ Speed controls")
        print("  ✅ Animation settings")
        
        # Try to set up time series files for proper testing
        try:
            from time_series_integration import integrate_time_series_animation
            
            print("\n🗂️ Setting up time series files...")
            animation_result = integrate_time_series_animation(results_2h, temp_dir)
            
            if animation_result['success']:
                print(f"✅ Time series files created: {animation_result['num_timesteps']} timesteps")
            else:
                print(f"⚠️ Time series setup failed: {animation_result.get('error')}")
        except Exception as e:
            print(f"⚠️ Time series setup error: {e}")
        
        # Keep reference to prevent garbage collection
        app._test_animator = animator
        
        print("\n🖱️ Test the controls:")
        print("1. Click Play button - animation should start")
        print("2. Drag timeline slider - should jump to different timesteps")
        print("3. Try speed control - should change animation speed")
        print("4. Click anywhere on the visualization (if available)")
        
        return app.exec_()
        
    except ImportError as e:
        print(f"❌ Import failed: {e}")
        return False
    except Exception as e:
        print(f"❌ Animation test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    print("🌊 Simple Animation Test (No GDAL)")
    print("=" * 40)
    
    # Check basic requirements
    try:
        import numpy as np
        print("✅ NumPy available")
    except ImportError:
        print("❌ NumPy required")
        return 1
    
    try:
        from PyQt5.QtWidgets import QApplication
        print("✅ PyQt5 available")
    except ImportError:
        print("❌ PyQt5 required")
        return 1
    
    # Run the test
    success = test_animation_directly()
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())
