"""
FloodEngine Q-based Hydraulic Methods
------------------------------------
This module implements the hydraulic calculations based on flow rate (Q).
"""

import os
import numpy as np
from osgeo import gdal

def calculate_water_level_from_flow(flow_q, dem_path, channel_shape="rectangular", manning_n=0.035):
    """Calculate water level from flow rate using Manning's equation
    
    Parameters:
        flow_q (float): Flow rate in m³/s
        dem_path (str): Path to DEM raster file
        channel_shape (str): Channel cross-section shape
        manning_n (float): Manning's roughness coefficient
        
    Returns:
        float: Estimated water level (m)
    """
    # Open DEM for slope calculation
    dem_ds = gdal.Open(dem_path)
    dem_array = dem_ds.GetRasterBand(1).ReadAsArray()
    
    # Create temporary slope raster
    temp_folder = os.path.dirname(dem_path)
    slope_path = os.path.join(temp_folder, "temp_slope.tif")
    
    # Calculate slope using GDAL
    gdal.DEMProcessing(slope_path, dem_path, 'slope')
    
    # Open slope raster
    slope_ds = gdal.Open(slope_path)
    slope_array = slope_ds.GetRasterBand(1).ReadAsArray()
    
    # Calculate mean slope (convert from percent to decimal)
    mean_slope = np.nanmean(slope_array) / 100
    
    # Estimate channel width based on flow rate
    estimated_width = 3.5 * pow(flow_q, 0.5)
    
    # Initial guess for water depth
    depth = 0.1
    
    # Iteratively find depth that satisfies Manning's equation
    for _ in range(20):
        # Calculate cross-sectional area
        area = estimated_width * depth
        
        # Calculate wetted perimeter
        wetted_perimeter = estimated_width + 2 * depth
        
        # Calculate hydraulic radius
        hydraulic_radius = area / wetted_perimeter
        
        # Calculate flow using Manning's equation
        calculated_q = (area * pow(hydraulic_radius, 2/3) * pow(mean_slope, 1/2)) / manning_n
        
        # Check convergence
        if abs(calculated_q - flow_q) < 0.01:
            break
            
        # Adjust depth based on ratio
        ratio = flow_q / calculated_q if calculated_q > 0 else 2.0
        depth *= pow(ratio, 0.4)
    
    # Add safety margin to depth
    water_level_above_bed = depth * 1.2
    
    # CRITICAL FIX: Start from CHANNEL/RIVER elevations, not median terrain
    min_elevation = np.nanmin(dem_array)
    median_elevation = np.nanmedian(dem_array)
    percentile_5 = np.nanpercentile(dem_array, 5)   # Lowest 5% (valleys/rivers)
    percentile_10 = np.nanpercentile(dem_array, 10)  # Channel areas
    percentile_15 = np.nanpercentile(dem_array, 15)  # Wider channel system
    
    print(f"📊 DEM statistics: min={min_elevation:.2f}m, 5%={percentile_5:.2f}m, 10%={percentile_10:.2f}m, 15%={percentile_15:.2f}m, median={median_elevation:.2f}m")
    
    # Use CHANNEL elevations as baseline (not median terrain)
    # River channels are typically in the lowest 10-15% of the terrain
    channel_elevation = percentile_10  # Use 10th percentile as typical channel level
    
    # REALISTIC FLOOD DEPTHS: Swedish rivers typically flood 1-3m above normal levels
    minimum_flood_depth = 1.0  # Minimum meaningful flood depth
    calculated_flood_depth = max(water_level_above_bed, minimum_flood_depth)
    
    # Cap flood depth at reasonable levels for Swedish conditions
    max_realistic_depth = 3.0  # Maximum 3m flood depth above channel
    if calculated_flood_depth > max_realistic_depth:
        calculated_flood_depth = max_realistic_depth
        print(f"⚠️ Flood depth capped at {max_realistic_depth}m for realistic conditions")
    
    # Calculate water level from CHANNEL baseline (not median terrain)
    water_level = channel_elevation + calculated_flood_depth
    
    # Safety check: ensure we don't flood unrealistically high terrain
    # Water level should not exceed the 25th percentile of terrain elevation
    percentile_25 = np.nanpercentile(dem_array, 25)
    if water_level > percentile_25:
        water_level = percentile_25
        calculated_flood_depth = water_level - channel_elevation
        print(f"⚠️ Water level adjusted to {water_level:.2f}m to avoid flooding high terrain")
    
    # Additional reality check: if water level is too close to median elevation, reduce it
    if water_level > median_elevation - 2.0:  # Should be at least 2m below median terrain
        water_level = median_elevation - 2.0
        calculated_flood_depth = water_level - channel_elevation
        print(f"⚠️ Water level reduced to {water_level:.2f}m to maintain realistic flood extent")
        
    print(f"🌊 CHANNEL-BASED WATER LEVEL: {water_level:.2f}m")
    print(f"   Channel elevation: {channel_elevation:.2f}m")
    print(f"   Flood depth above channel: {calculated_flood_depth:.2f}m") 
    print(f"   DEM range: {min_elevation:.2f}m to {np.nanmax(dem_array):.2f}m")
    print(f"   This will flood areas between {channel_elevation:.2f}m and {water_level:.2f}m elevation")
    
    # Clean up temporary files safely with Windows-specific handling
    try:
        # Force close any GDAL references first
        slope_ds = None
        dem_ds = None
        
        # Force garbage collection to release file handles
        import gc
        gc.collect()
        
        # Windows-specific: Add longer delay for file handle release
        import time
        time.sleep(0.2)
        
        # Multiple attempts to delete the file (Windows file locking issue)
        max_attempts = 3
        for attempt in range(max_attempts):
            try:
                if os.path.exists(slope_path):
                    os.remove(slope_path)
                    print(f"✅ Successfully deleted temporary file: {slope_path}")
                    break
            except PermissionError:
                if attempt < max_attempts - 1:
                    print(f"⏳ Attempt {attempt + 1}: File still in use, waiting...")
                    time.sleep(0.5)  # Wait longer between attempts
                else:
                    print(f"⚠️ Warning: Could not delete temporary file {slope_path} after {max_attempts} attempts")
                    print(f"   File may be cleaned up later by the system")
            except Exception as e:
                print(f"⚠️ Warning: Unexpected error cleaning up temp file: {e}")
                break
                
    except Exception as e:
        print(f"⚠️ Warning: Error in cleanup process: {e}")
    
    return water_level

def calculate_velocity_from_flow(flow_q, cross_section_area, manning_n=0.035, hydraulic_radius=None):
    """Calculate water velocity from flow rate
    
    Parameters:
        flow_q (float): Flow rate in m³/s
        cross_section_area (float): Cross-sectional area in m²
        manning_n (float): Manning's roughness coefficient
        hydraulic_radius (float): Hydraulic radius (optional)
        
    Returns:
        float: Estimated water velocity (m/s)
    """
    # If hydraulic radius not provided, estimate it
    if hydraulic_radius is None:
        hydraulic_radius = np.sqrt(cross_section_area) / 4
    
    # Calculate velocity as flow rate divided by area
    velocity = flow_q / cross_section_area
    
    return velocity

def calculate_erosion_risk_with_flow(soil_type, slope, depth, flow_q=None, channel_width=None):
    """Calculate erosion risk based on soil, slope, water depth, and flow
    
    Parameters:
        soil_type (str): Soil type name
        slope (float): Slope in degrees
        depth (float): Water depth in meters
        flow_q (float): Flow rate in m³/s (optional)
        channel_width (float): Channel width in meters (optional)
        
    Returns:
        float: Erosion risk factor (0-1)
    """
    # Soil erodibility factors
    soil_factors = {
        "SAND": 0.8,
        "MO": 0.9,
        "SILT": 1.0,
        "LERA": 0.6,  # Clay
        "MORÄN": 0.5,  # Till
        "TORV": 0.4,  # Peat
        "BERG": 0.1   # Rock
    }
    
    # Get soil factor from dictionary or default
    soil_factor = soil_factors.get(soil_type.upper(), 0.5)
    
    # Slope factor (increases with steeper slopes)
    slope_factor = min(1.0, slope / 20.0)
    
    # Depth factor (increases with water depth up to a limit)
    depth_factor = min(1.0, depth / 2.0)
    
    # Flow factor (if flow rate is provided)
    flow_factor = 1.0
    if flow_q is not None and channel_width is not None:
        # Calculate specific flow (flow per unit width)
        specific_flow = flow_q / channel_width
        # Flow factor increases with specific flow up to a limit
        flow_factor = min(1.0, specific_flow / 5.0)
    
    # Calculate total risk (product of all factors)
    risk = soil_factor * slope_factor * depth_factor * flow_factor
    
    # Ensure risk is in range 0-1
    return min(1.0, risk)

def classify_by_return_period(flow_q, region="Sweden"):
    """Classify flow by return period
    
    Parameters:
        flow_q (float): Flow rate in m³/s
        region (str): Geographic region
        
    Returns:
        tuple: (return_period, description)
    """
    # Return period descriptions
    return_periods = {
        "Sweden": {
            10: "10-year flow (common high flow)",
            50: "50-year flow (uncommon high flow)",
            100: "100-year flow (high design flow)",
            200: "200-year flow (high design flow + climate factor)"
        }
    }
    
    # Approximate catchment size (would be calculated from actual data)
    catchment_size = 100  # km²
    
    # Calculate specific flow (flow per unit area)
    specific_q = flow_q / catchment_size
    
    # Classify based on specific flow
    if specific_q < 0.2:
        return_year = 2
    elif specific_q < 0.4:
        return_year = 10
    elif specific_q < 0.6:
        return_year = 50
    elif specific_q < 0.8:
        return_year = 100
    else:
        return_year = 200
    
    # Find closest standard return period
    standard_periods = list(return_periods[region].keys())
    closest_period = min(standard_periods, key=lambda x: abs(x-return_year))
    
    return closest_period, return_periods[region][closest_period]

def generate_flow_report(flow_q, water_level, flood_area, affected_buildings=None):
    """Generate a hydrological report based on flow model
    
    Parameters:
        flow_q (float): Flow rate in m³/s
        water_level (float): Water level in meters
        flood_area (float): Flooded area in m²
        affected_buildings (int): Number of affected buildings (optional)
        
    Returns:
        str: HTML-formatted report
    """
    # Classify flow by return period
    return_period, flood_class = classify_by_return_period(flow_q)
    
    # Estimate flood volume (area * average depth)
    flood_volume = flood_area * 0.5  # Assuming average depth of 0.5m
    
    # Generate HTML report
    html = f"""
    <h1>Hydrological Risk Report</h1>
    <h2>Flow Analysis</h2>
    <ul>
      <li>Flow (Q): {flow_q} m³/s</li>
      <li>Classification: {flood_class}</li>
      <li>Return period: {return_period} years</li>
      <li>Water level: {water_level:.2f} m</li>
    </ul>
    <h2>Flood Analysis</h2>
    <ul>
      <li>Flooded area: {flood_area/10000:.2f} ha</li>
      <li>Estimated volume: {flood_volume:.2f} m³</li>
      <li>Affected buildings: {len(affected_buildings) if affected_buildings else 'Not calculated'}</li>
    </ul>
    """
    
    return html

def q_meander_analysis(flow_q, dem_path, params=None):
    """Stub for Q-based meandering analysis
    
    Parameters:
        flow_q (float): Flow rate in m³/s
        dem_path (str): Path to DEM raster file
        params (dict): Additional parameters
        
    Returns:
        dict: Analysis results
    """
    # This is a stub function - in a real implementation, this would:
    # 1. Calculate channel dimensions based on flow_q
    # 2. Analyze channel slope and sinuosity from the DEM
    # 3. Estimate sediment transport rates using a model like Meyer-Peter Müller
    # 4. Predict lateral migration rates based on bank material and flow conditions
    # 5. Generate potential future channel paths
    
    # For now, return a simple message
    return {
        "status": "not_implemented",
        "message": "Q-based meandering analysis will be available in version 4.0"
    }

def q_retention_effect(flow_q, dem_path, retention_params=None):
    """Stub for Q-based retention effect analysis
    
    Parameters:
        flow_q (float): Flow rate in m³/s
        dem_path (str): Path to DEM raster file
        retention_params (dict): Retention area parameters
        
    Returns:
        dict: Analysis results
    """
    # This is a stub function - in a real implementation, this would:
    # 1. Calculate flood volume for given flow_q
    # 2. Analyze potential retention areas from the DEM 
    # 3. Calculate volume-reduction effects for different retention scenarios
    # 4. Predict downstream peak flow reduction
    
    # For now, return a simple message
    return {
        "status": "not_implemented",
        "message": "Q-based retention effect analysis will be available in version 4.0"
    }
