#!/usr/bin/env python3
"""
Test script to verify the flow scenarios functionality in FloodEngine UI.
"""

import os
import sys

# Add the plugin directory to the path
plugin_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, plugin_dir)

def test_flow_scenarios():
    """Test the flow scenarios functionality."""
    print("Testing FloodEngine Flow Scenarios...")
    
    try:
        # Import the UI class
        from floodengine_ui import FloodEngineDialog
        
        # Create test UI dialog
        dialog = FloodEngineDialog()
        
        print("✓ UI created successfully")
        
        # Test that flow scenarios elements exist
        test_results = []
        
        # Check if scenarios group exists
        if hasattr(dialog, 'enable_scenarios'):
            test_results.append("✓ Enable scenarios checkbox exists")
            
            # Test enable/disable functionality
            dialog.enable_scenarios.setChecked(True)
            dialog.toggle_scenarios(True)
            test_results.append("✓ Scenarios can be enabled")
            
            if dialog.scenario_combo.isEnabled():
                test_results.append("✓ Scenario combo box enabled when scenarios active")
            else:
                test_results.append("✗ Scenario combo box not enabled")
                
        else:
            test_results.append("✗ Enable scenarios checkbox missing")
        
        # Check if scenario combo exists and has items
        if hasattr(dialog, 'scenario_combo'):
            test_results.append("✓ Scenario combo box exists")
            
            if dialog.scenario_combo.count() > 0:
                test_results.append(f"✓ Found {dialog.scenario_combo.count()} predefined scenarios")
                
                # Test scenario selection
                first_scenario = dialog.scenario_combo.itemText(0)
                dialog.scenario_combo.setCurrentText(first_scenario)
                dialog.update_scenario_values()
                test_results.append(f"✓ Can select scenario: {first_scenario}")
                
            else:
                test_results.append("✗ No scenarios found in combo box")
        else:
            test_results.append("✗ Scenario combo box missing")
        
        # Check if flood scenarios data exists
        if hasattr(dialog, 'flood_scenarios') and dialog.flood_scenarios:
            test_results.append(f"✓ Found {len(dialog.flood_scenarios)} scenario definitions")
            
            # Test a few specific scenarios
            expected_scenarios = ["10-year flood", "100-year flood", "Dam failure"]
            for scenario in expected_scenarios:
                if scenario in dialog.flood_scenarios:
                    scenario_data = dialog.flood_scenarios[scenario]
                    if 'water_level' in scenario_data and 'flow_q' in scenario_data:
                        test_results.append(f"✓ Scenario '{scenario}' has required data")
                    else:
                        test_results.append(f"✗ Scenario '{scenario}' missing required data")
                else:
                    test_results.append(f"✗ Scenario '{scenario}' not found")
        else:
            test_results.append("✗ No flood scenarios data found")
        
        # Check if custom scenario creation exists
        if hasattr(dialog, 'create_custom_scenario_btn'):
            test_results.append("✓ Custom scenario creation button exists")
        else:
            test_results.append("✗ Custom scenario creation button missing")
        
        # Check if scenario description exists
        if hasattr(dialog, 'scenario_description'):
            test_results.append("✓ Scenario description label exists")
        else:
            test_results.append("✗ Scenario description label missing")
        
        # Print all test results
        print("\nFlow Scenarios Test Results:")
        print("=" * 50)
        for result in test_results:
            print(result)
        
        # Count passed/failed tests
        passed = len([r for r in test_results if r.startswith("✓")])
        failed = len([r for r in test_results if r.startswith("✗")])
        
        print(f"\nSummary: {passed} passed, {failed} failed")
        
        if failed == 0:
            print("🎉 All flow scenarios tests passed!")
            return True
        else:
            print("❌ Some flow scenarios tests failed")
            return False
            
    except Exception as e:
        print(f"✗ Error testing flow scenarios: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_scenario_integration():
    """Test scenario integration with model execution."""
    print("\nTesting scenario integration...")
    
    try:
        from floodengine_ui import FloodEngineDialog
        
        dialog = FloodEngineDialog()
        
        # Enable scenarios
        if hasattr(dialog, 'enable_scenarios'):
            dialog.enable_scenarios.setChecked(True)
            dialog.toggle_scenarios(True)
            
            # Select a scenario
            if dialog.scenario_combo.count() > 0:
                scenario_name = dialog.scenario_combo.itemText(0)
                dialog.scenario_combo.setCurrentText(scenario_name)
                dialog.update_scenario_values()
                
                # Test parameter gathering (simulate what run_model does)
                if scenario_name in dialog.flood_scenarios:
                    scenario = dialog.flood_scenarios[scenario_name]
                    
                    # Check water level mode
                    if hasattr(dialog, 'water_level_radio'):
                        dialog.water_level_radio.setChecked(True)
                        dialog.update_scenario_values()
                        
                        if hasattr(dialog, 'basic_water_level'):
                            current_wl = dialog.basic_water_level.value()
                            expected_wl = scenario["water_level"]
                            
                            if abs(current_wl - expected_wl) < 0.01:
                                print(f"✓ Water level correctly set to {current_wl}m from scenario")
                            else:
                                print(f"✗ Water level mismatch: got {current_wl}, expected {expected_wl}")
                    
                    # Check flow Q mode
                    if hasattr(dialog, 'flow_q_radio'):
                        dialog.flow_q_radio.setChecked(True)
                        dialog.update_scenario_values()
                        
                        if hasattr(dialog, 'basic_flow_q'):
                            current_q = dialog.basic_flow_q.value()
                            expected_q = scenario["flow_q"]
                            
                            if abs(current_q - expected_q) < 0.01:
                                print(f"✓ Flow Q correctly set to {current_q}m³/s from scenario")
                            else:
                                print(f"✗ Flow Q mismatch: got {current_q}, expected {expected_q}")
                
                print("✓ Scenario integration test completed")
                return True
        
        print("✗ Could not test scenario integration - missing components")
        return False
        
    except Exception as e:
        print(f"✗ Error testing scenario integration: {e}")
        return False

def main():
    print("FloodEngine Flow Scenarios Test")
    print("=" * 40)
    
    success1 = test_flow_scenarios()
    success2 = test_scenario_integration()
    
    print("\n" + "=" * 40)
    
    if success1 and success2:
        print("🎉 ALL TESTS PASSED: Flow scenarios functionality is working!")
        return True
    else:
        print("❌ SOME TESTS FAILED: Check the results above.")
        return False

if __name__ == "__main__":
    success = main()
    exit(0 if success else 1)
