#!/usr/bin/env python3
"""
Test script to verify that the velocity capping fix works correctly.
This script creates extreme velocity values and tests that they are properly capped.
"""

import numpy as np
import os
import sys
import logging

# Add the current directory to the path so we can import FloodEngineX modules
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_velocity_capping():
    """Test that velocity capping works correctly"""
    
    # Set up logging
    logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
    logger = logging.getLogger("test_velocity_capping")
    
    logger.info("🧪 Testing velocity capping fix...")
    
    # Create test Saint-Venant results with extreme velocities
    test_shape = (100, 100)
    
    # Create extreme velocity values (hundreds of m/s)
    saint_venant_results = {
        'velocity_x': np.random.uniform(-500, 500, test_shape),  # -500 to 500 m/s
        'velocity_y': np.random.uniform(-500, 500, test_shape),  # -500 to 500 m/s
    }
    
    # Calculate magnitude
    saint_venant_results['velocity_magnitude'] = np.sqrt(
        saint_venant_results['velocity_x']**2 + 
        saint_venant_results['velocity_y']**2
    )
    
    original_max = np.max(saint_venant_results['velocity_magnitude'])
    logger.info(f"Original max velocity: {original_max:.1f} m/s")
    
    # Apply the same capping logic as in enhanced_streamlines.py
    EMERGENCY_CAP = 6.0
    ABSOLUTE_MAX_VELOCITY = 8.0
    
    # Test 1: Emergency capping
    logger.info("🛡️  Testing emergency capping...")
    
    if original_max > EMERGENCY_CAP:
        logger.warning(f"🚨 EMERGENCY CAPPING: Detected velocities up to {original_max:.1f} m/s")
        
        # Apply brutal capping to all velocity components
        saint_venant_results['velocity_x'] = np.clip(
            saint_venant_results['velocity_x'], -EMERGENCY_CAP, EMERGENCY_CAP
        )
        saint_venant_results['velocity_y'] = np.clip(
            saint_venant_results['velocity_y'], -EMERGENCY_CAP, EMERGENCY_CAP
        )
        saint_venant_results['velocity_magnitude'] = np.clip(
            saint_venant_results['velocity_magnitude'], 0.0, EMERGENCY_CAP
        )
        
        # Double-check the fix worked
        final_max = np.max(saint_venant_results['velocity_magnitude'])
        logger.warning(f"After emergency capping: Max velocity = {final_max:.1f} m/s")
        
        if final_max > EMERGENCY_CAP:
            logger.error("🚨 CRITICAL: Emergency capping FAILED!")
            return False
        else:
            logger.info("✅ Emergency capping successful")
    
    # Test 2: Critical capping
    logger.info("🔒 Testing critical capping...")
    
    # Cap velocity magnitude aggressively
    saint_venant_results['velocity_magnitude'] = np.clip(
        saint_venant_results['velocity_magnitude'], 
        0.0, 
        ABSOLUTE_MAX_VELOCITY
    )
    
    # Cap velocity components aggressively  
    saint_venant_results['velocity_x'] = np.clip(
        saint_venant_results['velocity_x'], 
        -ABSOLUTE_MAX_VELOCITY, 
        ABSOLUTE_MAX_VELOCITY
    )
    
    saint_venant_results['velocity_y'] = np.clip(
        saint_venant_results['velocity_y'], 
        -ABSOLUTE_MAX_VELOCITY, 
        ABSOLUTE_MAX_VELOCITY
    )
    
    # Recalculate magnitude to ensure consistency
    saint_venant_results['velocity_magnitude'] = np.sqrt(
        saint_venant_results['velocity_x']**2 + saint_venant_results['velocity_y']**2
    )
    
    # Final aggressive cap on magnitude
    saint_venant_results['velocity_magnitude'] = np.minimum(
        saint_venant_results['velocity_magnitude'], 
        ABSOLUTE_MAX_VELOCITY
    )
    
    # Check results
    final_max = np.max(saint_venant_results['velocity_magnitude'])
    final_max_x = np.max(np.abs(saint_venant_results['velocity_x']))
    final_max_y = np.max(np.abs(saint_venant_results['velocity_y']))
    
    logger.info(f"Final velocity statistics:")
    logger.info(f"  • Max velocity magnitude: {final_max:.3f} m/s")
    logger.info(f"  • Max |velocity_x|: {final_max_x:.3f} m/s")
    logger.info(f"  • Max |velocity_y|: {final_max_y:.3f} m/s")
    
    # Test 3: Verify all velocities are within limits
    success = True
    
    if final_max > ABSOLUTE_MAX_VELOCITY:
        logger.error(f"❌ FAILED: Final max velocity {final_max:.1f} m/s > {ABSOLUTE_MAX_VELOCITY} m/s")
        success = False
    
    if final_max_x > ABSOLUTE_MAX_VELOCITY:
        logger.error(f"❌ FAILED: Final max |velocity_x| {final_max_x:.1f} m/s > {ABSOLUTE_MAX_VELOCITY} m/s")
        success = False
    
    if final_max_y > ABSOLUTE_MAX_VELOCITY:
        logger.error(f"❌ FAILED: Final max |velocity_y| {final_max_y:.1f} m/s > {ABSOLUTE_MAX_VELOCITY} m/s")
        success = False
    
    if success:
        logger.info("✅ SUCCESS: All velocity capping tests passed!")
        logger.info(f"✅ All velocities are now ≤ {ABSOLUTE_MAX_VELOCITY} m/s")
    else:
        logger.error("❌ FAILED: Velocity capping tests failed!")
    
    return success

def test_velocity_assignment():
    """Test that velocity assignment preserves capping"""
    
    logger = logging.getLogger("test_velocity_assignment")
    logger.info("🧪 Testing velocity assignment logic...")
    
    # Create capped Saint-Venant results
    test_shape = (50, 50)
    FINAL_ABSOLUTE_CAP = 8.0
    
    # Simulate the assignment process
    saint_venant_results = {
        'velocity_x': np.random.uniform(-6, 6, test_shape),  # Already capped
        'velocity_y': np.random.uniform(-6, 6, test_shape),  # Already capped
        'velocity_magnitude': np.random.uniform(0, 6, test_shape),  # Already capped
    }
    
    # Simulate the assignment (as in enhanced_streamlines.py)
    velocity_x = saint_venant_results['velocity_x'].copy()
    velocity_y = saint_venant_results['velocity_y'].copy()
    velocity_mag = saint_venant_results['velocity_magnitude'].copy()
    
    # Apply final emergency capping to instance variables
    velocity_x = np.clip(velocity_x, -FINAL_ABSOLUTE_CAP, FINAL_ABSOLUTE_CAP)
    velocity_y = np.clip(velocity_y, -FINAL_ABSOLUTE_CAP, FINAL_ABSOLUTE_CAP)
    velocity_mag = np.clip(velocity_mag, 0.0, FINAL_ABSOLUTE_CAP)
    
    # Verify the velocity magnitude is consistent and capped
    recalc_mag = np.sqrt(velocity_x**2 + velocity_y**2)
    recalc_mag = np.minimum(recalc_mag, FINAL_ABSOLUTE_CAP)
    
    # Use the minimum of the two (capped original or recalculated)
    velocity_mag = np.minimum(velocity_mag, recalc_mag)
    
    # Check final results
    final_max = np.max(velocity_mag)
    final_max_x = np.max(np.abs(velocity_x))
    final_max_y = np.max(np.abs(velocity_y))
    
    logger.info(f"Assignment test results:")
    logger.info(f"  • Max velocity magnitude: {final_max:.3f} m/s")
    logger.info(f"  • Max |velocity_x|: {final_max_x:.3f} m/s")
    logger.info(f"  • Max |velocity_y|: {final_max_y:.3f} m/s")
    
    # Verify all are within limits
    success = (final_max <= FINAL_ABSOLUTE_CAP and 
              final_max_x <= FINAL_ABSOLUTE_CAP and 
              final_max_y <= FINAL_ABSOLUTE_CAP)
    
    if success:
        logger.info("✅ SUCCESS: Velocity assignment preserves capping!")
    else:
        logger.error("❌ FAILED: Velocity assignment broke capping!")
    
    return success

if __name__ == "__main__":
    print("=" * 60)
    print("VELOCITY CAPPING FIX TEST")
    print("=" * 60)
    
    test1_passed = test_velocity_capping()
    test2_passed = test_velocity_assignment()
    
    print("\n" + "=" * 60)
    if test1_passed and test2_passed:
        print("🎉 ALL TESTS PASSED!")
        print("✅ The velocity capping fix should work correctly.")
    else:
        print("❌ SOME TESTS FAILED!")
        print("🔧 The velocity capping fix needs more work.")
    print("=" * 60)
