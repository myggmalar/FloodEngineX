# -*- coding: utf-8 -*-
"""
Complete Fixed Advanced Hydraulic Engine for FloodEngine
- Fixes hanging at 25% issue
- Resolves small dots problem
- Improved stability and performance
- Better initial conditions handling
"""
import numpy as np
import math
import time
from dataclasses import dataclass
from typing import Tuple, List, Optional, Dict
from enum import Enum

# Handle optional advanced dependencies
try:
    import numba as nb
    from numba import jit, prange
    HAS_NUMBA = True
    print("✅ Numba acceleration available")
except ImportError:
    HAS_NUMBA = False
    print("⚠️ Numba not available - using standard NumPy (slower but functional)")
    def jit(*args, **kwargs):
        def decorator(func):
            return func
        return decorator
    def prange(start, stop=None, step=1):
        if stop is None:
            return range(start)
        return range(start, stop, step)

try:
    import scipy.sparse as sp
    from scipy.sparse.linalg import spsolve
    from scipy.ndimage import gaussian_filter, sobel
    HAS_SCIPY = True
    print("✅ SciPy advanced features available")
except ImportError:
    HAS_SCIPY = False
    print("⚠️ SciPy not available - using NumPy alternatives")
    def gaussian_filter(input, sigma, **kwargs):
        return input


# =============================================================================
# FIXED NUMBA-ACCELERATED FUNCTIONS
# =============================================================================

@jit(nopython=True, parallel=True)
def calculate_slopes_numba(dem: np.ndarray, dx: float, dy: float) -> Tuple[np.ndarray, np.ndarray]:
    """Numba-accelerated slope calculation - 20-50x faster"""
    ny, nx = dem.shape
    slope_x = np.zeros_like(dem)
    slope_y = np.zeros_like(dem)
    
    # Central differences for interior points
    for i in prange(1, ny-1):
        for j in prange(1, nx-1):
            slope_x[i, j] = (dem[i, j+1] - dem[i, j-1]) / (2.0 * dx)
            slope_y[i, j] = (dem[i+1, j] - dem[i-1, j]) / (2.0 * dy)
            
    # Forward/backward differences for boundaries
    for i in prange(ny):
        slope_x[i, 0] = (dem[i, 1] - dem[i, 0]) / dx
        slope_x[i, nx-1] = (dem[i, nx-1] - dem[i, nx-2]) / dx
        
    for j in prange(nx):
        slope_y[0, j] = (dem[1, j] - dem[0, j]) / dy
        slope_y[ny-1, j] = (dem[ny-1, j] - dem[ny-2, j]) / dy
        
    return slope_x, slope_y


@jit(nopython=True, parallel=False)
def kinematic_wave_update_numba(h: np.ndarray, dem: np.ndarray, manning: np.ndarray, 
                               slope_x: np.ndarray, slope_y: np.ndarray,
                               dt: float, dx: float, dy: float, 
                               min_depth: float, gravity: float) -> np.ndarray:
    """FIXED: Stable kinematic wave implementation"""
    ny, nx = h.shape
    h_new = h.copy()
    
    # Limit time step for stability
    dt_safe = min(dt, 5.0)
    
    for i in range(1, ny-1):
        for j in range(1, nx-1):
            if h[i, j] > min_depth:
                # Calculate local slope magnitude
                slope_mag = math.sqrt(slope_x[i, j]**2 + slope_y[i, j]**2)
                
                if slope_mag > 1e-6:
                    # Manning's equation for velocity
                    n = manning[i, j]
                    velocity = (1.0 / n) * (h[i, j]**(2.0/3.0)) * (slope_mag**0.5)
                    
                    # Limit velocity for stability
                    if velocity > 3.0:
                        velocity = 3.0
                    
                    # Flow direction based on steepest descent
                    flow_direction_x = -slope_x[i, j] / slope_mag
                    flow_direction_y = -slope_y[i, j] / slope_mag
                    
                    # Calculate outflow with conservative limits
                    discharge = velocity * h[i, j]
                    max_transfer = h[i, j] * 0.2  # Conservative 20% max transfer
                    
                    # Distribute flow to downstream cells
                    if flow_direction_x > 0.1 and j < nx-2:  # Flow to right
                        flow_rate = discharge * flow_direction_x * dt_safe / dx
                        transfer = min(flow_rate, max_transfer)
                        h_new[i, j] -= transfer
                        h_new[i, j+1] += transfer
                    elif flow_direction_x < -0.1 and j > 1:  # Flow to left
                        flow_rate = discharge * abs(flow_direction_x) * dt_safe / dx
                        transfer = min(flow_rate, max_transfer)
                        h_new[i, j] -= transfer
                        h_new[i, j-1] += transfer
                    
                    if flow_direction_y > 0.1 and i < ny-2:  # Flow down
                        flow_rate = discharge * flow_direction_y * dt_safe / dy
                        transfer = min(flow_rate, max_transfer)
                        h_new[i, j] -= transfer
                        h_new[i+1, j] += transfer
                    elif flow_direction_y < -0.1 and i > 1:  # Flow up
                        flow_rate = discharge * abs(flow_direction_y) * dt_safe / dy
                        transfer = min(flow_rate, max_transfer)
                        h_new[i, j] -= transfer
                        h_new[i-1, j] += transfer
    
    return h_new


@jit(nopython=True, parallel=True)
def calculate_friction_slopes_numba(h: np.ndarray, u: np.ndarray, v: np.ndarray, 
                                   manning: np.ndarray, gravity: float) -> Tuple[np.ndarray, np.ndarray]:
    """Numba-accelerated friction slope calculation using Manning's equation"""
    ny, nx = h.shape
    sf_x = np.zeros_like(h)
    sf_y = np.zeros_like(h)
    
    for i in prange(ny):
        for j in prange(nx):
            if h[i, j] > 1e-6:
                n = manning[i, j]
                velocity_mag = math.sqrt(u[i, j]**2 + v[i, j]**2)
                
                if velocity_mag > 1e-6:
                    friction_factor = (n * velocity_mag) / (h[i, j]**(4.0/3.0))
                    sf_x[i, j] = friction_factor * u[i, j] / gravity
                    sf_y[i, j] = friction_factor * v[i, j] / gravity
                    
    return sf_x, sf_y


# =============================================================================
# ENUMS AND DATA CLASSES
# =============================================================================

class ModelComplexity(Enum):
    """Model complexity levels"""
    SIMPLE = "simple"
    KINEMATIC = "kinematic"
    DIFFUSIVE = "diffusive"  
    DYNAMIC = "dynamic"

@dataclass
class HydraulicParameters:
    """Hydraulic modeling parameters with performance controls"""
    manning_n: float = 0.035
    cfl_number: float = 0.25
    theta: float = 0.6
    min_depth: float = 0.01          # Increased from 0.001 for visibility
    max_velocity: float = 5.0        # Conservative velocity limit
    convergence_tolerance: float = 1e-4
    max_iterations: int = 25
    gravity: float = 9.81
    # Performance controls
    min_timestep: float = 1.0        # Minimum 1 second
    max_timestep: float = 60.0       # Maximum 60 seconds
    progress_check_interval: int = 50
    max_simulation_steps: int = 3600  # 1 hour max


# =============================================================================
# MAIN ADVANCED HYDRAULIC ENGINE CLASS
# =============================================================================

class AdvancedHydraulicEngine:
    """
    Complete Fixed Advanced hydraulic modeling engine
    """
    
    def __init__(self, dem: np.ndarray, dx: float, dy: float, params: HydraulicParameters = None):
        self.dem = dem.astype(np.float64)
        self.dx = dx
        self.dy = dy
        self.params = params or HydraulicParameters()
        
        # Store grid bounds for coordinate conversion
        self.x_min = 0.0
        self.y_min = 0.0
        
        # Grid dimensions
        self.ny, self.nx = dem.shape
        
        # Performance check
        total_cells = self.nx * self.ny
        if total_cells > 100000:
            print(f"⚠️ Very large grid ({total_cells} cells). Performance may be slow.")
        elif total_cells > 50000:
            print(f"⚠️ Large grid ({total_cells} cells). Consider reducing for better performance.")
        
        # Initialize state variables
        self.h = np.zeros_like(dem)
        self.u = np.zeros_like(dem)
        self.v = np.zeros_like(dem)
        self.eta = dem.copy()  # Start with terrain elevation
        
        # Manning's roughness grid
        self.manning_grid = np.full_like(dem, self.params.manning_n)
        
        # Boundary conditions
        self.boundary_conditions = []
        
        # Precompute slopes for efficiency
        self.slope_x, self.slope_y = self._precompute_slopes()
        
        # Performance monitoring
        self._step_count = 0
        self._simulation_start_time = None
        
        print(f"✅ Advanced hydraulic engine initialized: {self.nx}x{self.ny} grid")
        print(f"✅ Total cells: {total_cells:,}")
        print(f"✅ DEM elevation range: {dem.min():.2f} to {dem.max():.2f} m")
        
    def set_grid_bounds(self, x_min: float, y_min: float):
        """Set grid coordinate bounds for proper coordinate conversion"""
        self.x_min = x_min
        self.y_min = y_min
        
    def _precompute_slopes(self) -> Tuple[np.ndarray, np.ndarray]:
        """Precompute slopes once for efficiency"""
        if HAS_NUMBA:
            return calculate_slopes_numba(self.dem, self.dx, self.dy)
        else:
            return self._calculate_slopes_numpy()
            
    def _calculate_slopes_numpy(self) -> Tuple[np.ndarray, np.ndarray]:
        """Numpy fallback for slope calculation"""
        ny, nx = self.dem.shape
        slope_x = np.zeros_like(self.dem)
        slope_y = np.zeros_like(self.dem)
        
        # Central differences for interior
        slope_x[1:-1, 1:-1] = (self.dem[1:-1, 2:] - self.dem[1:-1, :-2]) / (2.0 * self.dx)
        slope_y[1:-1, 1:-1] = (self.dem[2:, 1:-1] - self.dem[:-2, 1:-1]) / (2.0 * self.dy)
        
        # Boundaries
        slope_x[:, 0] = (self.dem[:, 1] - self.dem[:, 0]) / self.dx
        slope_x[:, -1] = (self.dem[:, -1] - self.dem[:, -2]) / self.dx
        slope_y[0, :] = (self.dem[1, :] - self.dem[0, :]) / self.dy
        slope_y[-1, :] = (self.dem[-1, :] - self.dem[-2, :]) / self.dy
        
        return slope_x, slope_y
        
    def set_manning_roughness(self, manning_grid: np.ndarray):
        """Set spatially variable Manning's roughness"""
        if manning_grid.shape != self.dem.shape:
            raise ValueError("Manning grid must match DEM dimensions")
        self.manning_grid = manning_grid.copy()
        
    def set_initial_conditions(self, initial_depth: np.ndarray = None, 
                             initial_velocity_x: np.ndarray = None,
                             initial_velocity_y: np.ndarray = None):
        """Set initial conditions with validation"""
        if initial_depth is not None:
            if initial_depth.shape != self.dem.shape:
                raise ValueError("Initial depth must match DEM dimensions")
            self.h = initial_depth.copy()
            # Ensure non-negative depths
            self.h = np.maximum(self.h, 0.0)
            
        if initial_velocity_x is not None:
            if initial_velocity_x.shape != self.dem.shape:
                raise ValueError("Initial velocity X must match DEM dimensions")
            self.u = initial_velocity_x.copy()
            
        if initial_velocity_y is not None:
            if initial_velocity_y.shape != self.dem.shape:
                raise ValueError("Initial velocity Y must match DEM dimensions")
            self.v = initial_velocity_y.copy()
            
        # Update water surface elevation
        self.eta = self.dem + self.h
        
        # Log initial conditions
        total_volume = np.sum(self.h) * self.dx * self.dy
        wet_cells = np.sum(self.h > self.params.min_depth)
        print(f"✅ Initial conditions set: Volume={total_volume:.1f}m³, Wet cells={wet_cells}")
        
    def add_flood_source(self, x_coords: List[float], y_coords: List[float], 
                        initial_depth: float = 2.0, radius: float = 50.0):
        """Add flood source at specified coordinates"""
        if len(x_coords) != len(y_coords):
            raise ValueError("x_coords and y_coords must have same length")
            
        # Convert world coordinates to grid indices
        for x_coord, y_coord in zip(x_coords, y_coords):
            j = int((x_coord - self.x_min) / self.dx)
            i = int((y_coord - self.y_min) / self.dy)
            
            # Check bounds
            if 0 <= i < self.ny and 0 <= j < self.nx:
                # Add water in circular area
                radius_cells = int(radius / min(self.dx, self.dy))
                
                for di in range(-radius_cells, radius_cells + 1):
                    for dj in range(-radius_cells, radius_cells + 1):
                        ii, jj = i + di, j + dj
                        if 0 <= ii < self.ny and 0 <= jj < self.nx:
                            distance = np.sqrt((di * self.dy)**2 + (dj * self.dx)**2)
                            if distance <= radius:
                                # Gaussian-like distribution
                                depth_factor = np.exp(-(distance/radius)**2)
                                self.h[ii, jj] = max(self.h[ii, jj], 
                                                   initial_depth * depth_factor)
        
        # Update water surface elevation
        self.eta = self.dem + self.h
        
        total_volume = np.sum(self.h) * self.dx * self.dy
        wet_cells = np.sum(self.h > self.params.min_depth)
        print(f"✅ Flood source added: Volume={total_volume:.1f}m³, Wet cells={wet_cells}")
        
    def solve_shallow_water_equations(self, dt: float, method: str = "kinematic") -> Dict:
        """
        Solve 2D shallow water equations using specified method
        """
        # Start timing if first step
        if self._step_count == 0:
            self._simulation_start_time = time.time()
            
        self._step_count += 1
        
        # Performance monitoring
        if (self._step_count % self.params.progress_check_interval == 0 and 
            self._simulation_start_time is not None):
            elapsed = time.time() - self._simulation_start_time
            print(f"Progress: Step {self._step_count}, elapsed: {elapsed:.1f}s")
        
        # Choose solution method
        if method == "kinematic":
            return self._solve_kinematic_wave(dt)
        elif method == "explicit":
            return self._solve_explicit(dt)
        elif method == "semi_implicit":
            return self._solve_semi_implicit(dt)
        else:
            print(f"⚠️ Unknown method '{method}', using kinematic")
            return self._solve_kinematic_wave(dt)
    
    def _solve_kinematic_wave(self, dt: float) -> Dict:
        """Solve using kinematic wave approximation"""
        # Store old state
        h_old = self.h.copy()
        
        # Apply kinematic wave update
        if HAS_NUMBA:
            self.h = kinematic_wave_update_numba(
                self.h, self.dem, self.manning_grid, 
                self.slope_x, self.slope_y,
                dt, self.dx, self.dy, 
                self.params.min_depth, self.params.gravity
            )
        else:
            self._kinematic_numpy_fallback(dt)
        
        # Apply boundary conditions
        self._apply_boundary_conditions()
        
        # Ensure non-negative depths
        self.h = np.maximum(self.h, 0.0)
        
        # Update water surface elevation
        self.eta = self.dem + self.h
        
        # Calculate diagnostics
        slope_mag = np.sqrt(self.slope_x**2 + self.slope_y**2)
        mask = (self.h > self.params.min_depth) & (slope_mag > 1e-6)
        
        velocity_est = np.zeros_like(self.h)
        if np.any(mask):
            velocity_est[mask] = ((1.0 / self.params.manning_n) * 
                                 (self.h[mask]**(2.0/3.0)) * 
                                 (slope_mag[mask]**0.5))
        
        mass = np.sum(self.h) * self.dx * self.dy
        max_velocity = np.max(velocity_est) if np.any(mask) else 0.0
        
        return {
            'mass': mass,
            'max_velocity': max_velocity,
            'dt_used': dt,
            'method': 'kinematic',
            'wet_cells': np.sum(self.h > self.params.min_depth),
            'max_depth': np.max(self.h)
        }
    
    def _kinematic_numpy_fallback(self, dt: float):
        """Numpy fallback for kinematic wave"""
        h_new = self.h.copy()
        slope_mag = np.sqrt(self.slope_x**2 + self.slope_y**2)
        
        # Only process cells with water
        mask = self.h > self.params.min_depth
        if np.any(mask):
            # Manning velocity estimation
            velocity = np.where(mask, 
                              (1.0 / self.params.manning_n) * 
                              (self.h**(2.0/3.0)) * (slope_mag**0.5), 0.0)
            
            # Limit velocity
            velocity = np.minimum(velocity, 3.0)
            
            # Simple downhill flow
            flow_x = -self.slope_x * velocity * self.h * dt / self.dx
            flow_y = -self.slope_y * velocity * self.h * dt / self.dy
            
            # Limit flow to 20% of available water
            flow_x = np.clip(flow_x, -0.2 * self.h, 0.2 * self.h)
            flow_y = np.clip(flow_y, -0.2 * self.h, 0.2 * self.h)
            
            # Apply flows with boundary protection
            h_new[1:-1, 1:-1] += (
                flow_x[1:-1, :-2] - flow_x[1:-1, 1:-1] +
                flow_y[:-2, 1:-1] - flow_y[1:-1, 1:-1]
            )
        
        self.h = np.maximum(h_new, 0.0)
    
    def _solve_explicit(self, dt: float) -> Dict:
        """Explicit finite difference solution"""
        # Calculate friction slopes
        sf_x, sf_y = self._calculate_friction_slopes()
        
        # Calculate time derivatives
        dh_dt, du_dt, dv_dt = self._calculate_derivatives_explicit(sf_x, sf_y)
        
        # Limit time step for stability
        dt_safe = min(dt, 2.0)
        
        # Update state variables
        self.h += dt_safe * dh_dt
        self.u += dt_safe * du_dt  
        self.v += dt_safe * dv_dt
        
        # Apply boundary conditions and constraints
        self._apply_boundary_conditions()
        self.h = np.maximum(self.h, 0.0)
        self.eta = self.dem + self.h
        
        # Calculate diagnostics
        mass = np.sum(self.h) * self.dx * self.dy
        max_velocity = np.sqrt(np.max(self.u**2 + self.v**2))
        
        return {
            'mass': mass,
            'max_velocity': max_velocity,
            'dt_used': dt_safe,
            'method': 'explicit',
            'wet_cells': np.sum(self.h > self.params.min_depth),
            'max_depth': np.max(self.h)
        }
    
    def _solve_semi_implicit(self, dt: float) -> Dict:
        """Semi-implicit solution (placeholder - simplified version)"""
        # For now, use kinematic wave as fallback
        return self._solve_kinematic_wave(dt)
    
    def _calculate_friction_slopes(self) -> Tuple[np.ndarray, np.ndarray]:
        """Calculate friction slopes"""
        if HAS_NUMBA:
            return calculate_friction_slopes_numba(
                self.h, self.u, self.v, self.manning_grid, self.params.gravity
            )
        else:
            return self._calculate_friction_slopes_numpy()
    
    def _calculate_friction_slopes_numpy(self) -> Tuple[np.ndarray, np.ndarray]:
        """Numpy fallback for friction slope calculation"""
        sf_x = np.zeros_like(self.h)
        sf_y = np.zeros_like(self.h)
        
        mask = self.h > 1e-6
        velocity_mag = np.sqrt(self.u**2 + self.v**2)
        
        with np.errstate(divide='ignore', invalid='ignore'):
            friction_factor = np.where(mask, 
                                     (self.manning_grid * velocity_mag) / (self.h**(4.0/3.0)), 
                                     0.0)
            sf_x = np.where(mask, friction_factor * self.u / self.params.gravity, 0.0)
            sf_y = np.where(mask, friction_factor * self.v / self.params.gravity, 0.0)
        
        return sf_x, sf_y
    
    def _calculate_derivatives_explicit(self, sf_x: np.ndarray, sf_y: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Calculate time derivatives for explicit method"""
        dh_dt = np.zeros_like(self.h)
        du_dt = np.zeros_like(self.u)
        dv_dt = np.zeros_like(self.v)
        
        # Simplified calculations for interior points
        i_slice = slice(1, -1)
        j_slice = slice(1, -1)
        
        # Continuity equation: ∂h/∂t + ∂(hu)/∂x + ∂(hv)/∂y = 0
        dhu_dx = (self.h[i_slice, 2:] * self.u[i_slice, 2:] - 
                 self.h[i_slice, :-2] * self.u[i_slice, :-2]) / (2.0 * self.dx)
        dhv_dy = (self.h[2:, j_slice] * self.v[2:, j_slice] - 
                 self.h[:-2, j_slice] * self.v[:-2, j_slice]) / (2.0 * self.dy)
        
        dh_dt[i_slice, j_slice] = -(dhu_dx + dhv_dy)
        
        # Momentum equations (simplified)
        # X-momentum
        deta_dx = (self.eta[i_slice, 2:] - self.eta[i_slice, :-2]) / (2.0 * self.dx)
        du_dt[i_slice, j_slice] = (-self.params.gravity * deta_dx - 
                                  self.params.gravity * sf_x[i_slice, j_slice])
        
        # Y-momentum
        deta_dy = (self.eta[2:, j_slice] - self.eta[:-2, j_slice]) / (2.0 * self.dy)
        dv_dt[i_slice, j_slice] = (-self.params.gravity * deta_dy - 
                                  self.params.gravity * sf_y[i_slice, j_slice])
        
        return dh_dt, du_dt, dv_dt
    
    def _apply_boundary_conditions(self):
        """Apply boundary conditions (simplified - zero flux at boundaries)"""
        # Zero flux at boundaries
        self.h[0, :] = self.h[1, :]
        self.h[-1, :] = self.h[-2, :]
        self.h[:, 0] = self.h[:, 1]
        self.h[:, -1] = self.h[:, -2]
        
        # Zero velocity at boundaries
        self.u[0, :] = 0.0
        self.u[-1, :] = 0.0
        self.u[:, 0] = 0.0
        self.u[:, -1] = 0.0
        
        self.v[0, :] = 0.0
        self.v[-1, :] = 0.0
        self.v[:, 0] = 0.0
        self.v[:, -1] = 0.0
    
    def get_simulation_state(self) -> Dict:
        """Get current simulation state for output"""
        return {
            'depth': self.h.copy(),
            'velocity_x': self.u.copy(),
            'velocity_y': self.v.copy(),
            'elevation': self.eta.copy(),
            'dem': self.dem.copy(),
            'step_count': self._step_count,
            'total_volume': np.sum(self.h) * self.dx * self.dy,
            'max_depth': np.max(self.h),
            'wet_cells': np.sum(self.h > self.params.min_depth)
        }
    
    def reset_simulation(self):
        """Reset simulation to initial state"""
        self.h = np.zeros_like(self.dem)
        self.u = np.zeros_like(self.dem)
        self.v = np.zeros_like(self.dem)
        self.eta = self.dem.copy()
        self._step_count = 0
        self._simulation_start_time = None
        print("✅ Simulation reset to initial state")


# =============================================================================
# UTILITY FUNCTIONS FOR IMPROVED FLOOD MODELING
# =============================================================================

def create_realistic_flood_scenario(engine: AdvancedHydraulicEngine, 
                                  scenario_type: str = "dam_break",
                                  **kwargs) -> None:
    """Create realistic flood scenarios"""
    
    if scenario_type == "dam_break":
        # Dam break scenario
        x_center = kwargs.get('x_center', engine.x_min + (engine.nx * engine.dx) / 2)
        y_center = kwargs.get('y_center', engine.y_min + (engine.ny * engine.dy) / 2)
        initial_depth = kwargs.get('initial_depth', 5.0)
        radius = kwargs.get('radius', 100.0)
        
        engine.add_flood_source([x_center], [y_center], initial_depth, radius)
        
    elif scenario_type == "river_flood":
        # River flood scenario
        river_width = kwargs.get('river_width', 50.0)
        initial_depth = kwargs.get('initial_depth', 3.0)
        
        # Find lowest elevation cells for river placement
        flat_dem = engine.dem.flatten()
        low_indices = np.argsort(flat_dem)[:int(len(flat_dem) * 0.1)]  # Lowest 10%
        
        for idx in low_indices[::10]:  # Every 10th point to avoid clustering
            i, j = np.unravel_index(idx, engine.dem.shape)
            x_coord = engine.x_min + j * engine.dx
            y_coord = engine.y_min + i * engine.dy
            engine.add_flood_source([x_coord], [y_coord], initial_depth, river_width/2)
            
    elif scenario_type == "coastal_flood":
        # Coastal flood scenario
        initial_depth = kwargs.get('initial_depth', 2.0)
        
        # Add water along one edge (assuming it's coastline)
        edge = kwargs.get('edge', 'bottom')  # bottom, top, left, right
        
        if edge == 'bottom':
            for j in range(0, engine.nx, 5):
                x_coord = engine.x_min + j * engine.dx
                y_coord = engine.y_min
                engine.add_flood_source([x_coord], [y_coord], initial_depth, 30.0)
        # Add other edge cases as needed
        
    print(f"✅ Created {scenario_type} flood scenario")


def run_improved_flood_simulation(engine: AdvancedHydraulicEngine, 
                                total_time: float = 3600.0,
                                time_step: float = 30.0,
                                output_interval: float = 300.0,
                                method: str = "kinematic") -> List[Dict]:
    """
    Run improved flood simulation with proper time stepping and monitoring
    """
    print(f"🌊 Starting flood simulation:")
    print(f"   Total time: {total_time}s ({total_time/3600:.1f} hours)")
    print(f"   Time step: {time_step}s")
    print(f"   Method: {method}")
    
    # Calculate simulation parameters
    total_steps = int(total_time / time_step)
    output_step_interval = max(1, int(output_interval / time_step))
    
    print(f"   Total steps: {total_steps}")
    print(f"   Output every {output_step_interval} steps")
    
    results = []
    start_time = time.time()
    
    # Store initial state
    initial_state = engine.get_simulation_state()
    initial_state['time'] = 0.0
    results.append(initial_state)
    
    print(f"   Initial volume: {initial_state['total_volume']:.1f} m³")
    print(f"   Initial wet cells: {initial_state['wet_cells']}")
    
    # Main simulation loop
    for step in range(1, total_steps + 1):
        current_time = step * time_step
        
        # Adaptive time stepping for stability
        if step > 1:
            last_result = results[-1] if len(results) > 0 else None
            if last_result and 'max_velocity' in last_result:
                max_vel = last_result['max_velocity']
                if max_vel > 0:
                    # CFL condition
                    cfl_dt = 0.25 * min(engine.dx, engine.dy) / max_vel
                    adaptive_dt = min(time_step, cfl_dt, 60.0)
                else:
                    adaptive_dt = time_step
            else:
                adaptive_dt = time_step
        else:
            adaptive_dt = time_step
        
        # Run simulation step
        step_result = engine.solve_shallow_water_equations(adaptive_dt, method)
        
        # Progress reporting
        if step % 50 == 0 or step <= 10:
            elapsed = time.time() - start_time
            progress = 100.0 * step / total_steps
            eta_remaining = elapsed * (total_steps - step) / step if step > 0 else 0
            
            print(f"   Step {step:4d}/{total_steps} ({progress:5.1f}%) - "
                  f"Vol: {step_result['mass']:8.1f}m³, "
                  f"MaxDepth: {step_result.get('max_depth', 0):.3f}m, "
                  f"WetCells: {step_result.get('wet_cells', 0):5d}, "
                  f"MaxVel: {step_result['max_velocity']:5.2f}m/s, "
                  f"ETA: {eta_remaining/60:.1f}min")
        
        # Store output at specified intervals
        if step % output_step_interval == 0:
            state = engine.get_simulation_state()
            state['time'] = current_time
            state['step_result'] = step_result
            results.append(state)
            
            print(f"   💾 Saved output at t={current_time}s")
        
        # Early termination checks
        if step_result['mass'] < 1.0:  # Less than 1 m³
            print(f"   ✅ Simulation completed early at step {step} (water drained)")
            break
            
        if step_result.get('wet_cells', 0) < 5:
            print(f"   ✅ Simulation completed early at step {step} (few wet cells)")
            break
    
    # Final timing
    elapsed = time.time() - start_time
    print(f"🏁 Simulation completed in {elapsed:.1f}s ({elapsed/60:.1f} minutes)")
    print(f"   Processed {len(results)} output frames")
    
    # Final state summary
    if results:
        final_state = results[-1]
        print(f"   Final volume: {final_state['total_volume']:.1f} m³")
        print(f"   Final wet cells: {final_state['wet_cells']}")
        print(f"   Maximum depth reached: {max(r['max_depth'] for r in results):.2f} m")
    
    return results


def validate_dem_data(dem: np.ndarray, dx: float, dy: float) -> Dict:
    """
    Validate DEM data for flood modeling
    """
    validation_report = {
        'valid': True,
        'warnings': [],
        'errors': [],
        'statistics': {}
    }
    
    # Basic statistics
    stats = {
        'shape': dem.shape,
        'total_cells': dem.size,
        'min_elevation': float(np.min(dem)),
        'max_elevation': float(np.max(dem)),
        'mean_elevation': float(np.mean(dem)),
        'elevation_range': float(np.max(dem) - np.min(dem)),
        'resolution_x': dx,
        'resolution_y': dy
    }
    validation_report['statistics'] = stats
    
    # Check for reasonable elevation values
    if stats['elevation_range'] > 5000:  # More than 5km elevation difference
        validation_report['warnings'].append(
            f"Very large elevation range ({stats['elevation_range']:.1f}m). "
            "Check if using correct elevation column."
        )
    
    if stats['min_elevation'] > 10000:  # Elevations above 10km
        validation_report['errors'].append(
            f"Minimum elevation ({stats['min_elevation']:.1f}m) is suspiciously high. "
            "This may be coordinate data instead of elevation."
        )
        validation_report['valid'] = False
    
    # Check for NaN values
    nan_count = np.sum(np.isnan(dem))
    if nan_count > 0:
        validation_report['warnings'].append(
            f"Found {nan_count} NaN values in DEM ({100*nan_count/dem.size:.1f}%)"
        )
    
    # Check resolution
    if dx != dy:
        validation_report['warnings'].append(
            f"Non-square grid cells (dx={dx}, dy={dy}). May affect accuracy."
        )
    
    if dx > 100 or dy > 100:
        validation_report['warnings'].append(
            f"Large grid resolution ({dx}x{dy}m). Consider higher resolution for accuracy."
        )
    
    # Check grid size
    if stats['total_cells'] > 1000000:  # 1M cells
        validation_report['warnings'].append(
            f"Very large grid ({stats['total_cells']:,} cells). "
            "Performance will be slow. Consider reducing size."
        )
    elif stats['total_cells'] > 100000:  # 100k cells
        validation_report['warnings'].append(
            f"Large grid ({stats['total_cells']:,} cells). "
            "Performance may be slow."
        )
    
    # Check for flat areas (potential issues)
    flat_percentage = 100.0 * np.sum(np.abs(np.gradient(dem)[0]) < 0.001) / dem.size
    if flat_percentage > 50:
        validation_report['warnings'].append(
            f"Large percentage of flat areas ({flat_percentage:.1f}%). "
            "May affect flow routing."
        )
    
    return validation_report


def print_validation_report(report: Dict):
    """Print DEM validation report"""
    print("📊 DEM Validation Report")
    print("=" * 50)
    
    stats = report['statistics']
    print(f"Grid size: {stats['shape'][1]} x {stats['shape'][0]} cells ({stats['total_cells']:,} total)")
    print(f"Resolution: {stats['resolution_x']:.1f} x {stats['resolution_y']:.1f} meters")
    print(f"Elevation: {stats['min_elevation']:.2f} to {stats['max_elevation']:.2f} m")
    print(f"Range: {stats['elevation_range']:.2f} m")
    print(f"Mean: {stats['mean_elevation']:.2f} m")
    
    if report['errors']:
        print("\n❌ ERRORS:")
        for error in report['errors']:
            print(f"   • {error}")
    
    if report['warnings']:
        print("\n⚠️ WARNINGS:")
        for warning in report['warnings']:
            print(f"   • {warning}")
    
    if report['valid'] and not report['warnings']:
        print("\n✅ DEM validation passed - no issues detected")
    elif report['valid']:
        print("\n⚠️ DEM validation passed with warnings")
    else:
        print("\n❌ DEM validation failed - please fix errors before proceeding")


# =============================================================================
# EXAMPLE USAGE AND TESTING
# =============================================================================

def create_test_dem(nx: int = 100, ny: int = 100, dx: float = 10.0, dy: float = 10.0) -> np.ndarray:
    """Create a test DEM for debugging"""
    x = np.linspace(0, (nx-1)*dx, nx)
    y = np.linspace(0, (ny-1)*dy, ny)
    X, Y = np.meshgrid(x, y)
    
    # Create a simple valley with some random variation
    dem = (
        100.0 +  # Base elevation
        0.02 * X +  # Gentle slope in X direction
        0.01 * Y +  # Gentle slope in Y direction
        10.0 * np.sin(X / 200.0) * np.sin(Y / 150.0) +  # Large-scale variation
        2.0 * np.random.random((ny, nx))  # Small random variation
    )
    
    return dem


def run_test_simulation():
    """Run a test simulation for validation"""
    print("🧪 Running test simulation...")
    
    # Create test DEM
    dem = create_test_dem(50, 50, 10.0, 10.0)
    
    # Validate DEM
    validation = validate_dem_data(dem, 10.0, 10.0)
    print_validation_report(validation)
    
    if not validation['valid']:
        print("❌ Test DEM validation failed")
        return
    
    # Create engine
    params = HydraulicParameters()
    params.min_depth = 0.05  # 5cm minimum for visibility
    params.max_timestep = 30.0
    
    engine = AdvancedHydraulicEngine(dem, 10.0, 10.0, params)
    engine.set_grid_bounds(0.0, 0.0)
    
    # Create flood scenario
    create_realistic_flood_scenario(
        engine, 
        scenario_type="dam_break",
        x_center=250.0,  # Center of domain
        y_center=250.0,
        initial_depth=3.0,
        radius=75.0
    )
    
    # Run simulation
    results = run_improved_flood_simulation(
        engine,
        total_time=1800.0,  # 30 minutes
        time_step=15.0,     # 15 second steps
        output_interval=300.0,  # Output every 5 minutes
        method="kinematic"
    )
    
    print(f"✅ Test simulation completed with {len(results)} outputs")
    return results


if __name__ == "__main__":
    # Run test when script is executed directly
    test_results = run_test_simulation()