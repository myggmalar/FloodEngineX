"""
Enhanced Flow Direction Utilities for FloodEngine
-----------------------------------------------
Ensures that water flows correctly downhill and prevents backward flow.
This version fixes issues with backward flow in watercourses and respects the calculation area.
"""

import numpy as np
from osgeo import gdal
import logging
from scipy.ndimage import gaussian_filter
import os

logger = logging.getLogger("FloodEngine.FlowDirection")

def enforce_boundary_flow(velocity_x, velocity_y, water_depth, bounding_box=None, geotransform=None):
    """
    Enforce correct flow at the boundaries of the calculation area to prevent
    backflow into the calculation area.
    
    Parameters:
        velocity_x (numpy.ndarray): X component of velocity
        velocity_y (numpy.ndarray): Y component of velocity
        water_depth (numpy.ndarray): Water depth
        bounding_box (tuple): (xmin, ymin, xmax, ymax) in world coordinates
        geotransform (tuple): GDAL geotransform
        
    Returns:
        tuple: Corrected velocity arrays (velocity_x, velocity_y)
    """
    corrected_vx = velocity_x.copy()
    corrected_vy = velocity_y.copy()
    
    # If no bounding box or geotransform, return unchanged
    if bounding_box is None or geotransform is None:
        return corrected_vx, corrected_vy
    
    # Convert world coordinates to pixel coordinates
    try:
        xmin, ymin, xmax, ymax = bounding_box
        
        # Convert world coordinates to pixel coordinates
        i_min = int((ymin - geotransform[3]) / geotransform[5])
        i_max = int((ymax - geotransform[3]) / geotransform[5])
        j_min = int((xmin - geotransform[0]) / geotransform[1])
        j_max = int((xmax - geotransform[0]) / geotransform[1])
        
        # Ensure within array bounds
        rows, cols = velocity_x.shape
        i_min = max(0, min(i_min, rows-1))
        i_max = max(0, min(i_max, rows-1))
        j_min = max(0, min(j_min, cols-1))
        j_max = max(0, min(j_max, cols-1))
        
        # Adjust flow at boundaries
        
        # Left boundary (prevent flow from right to left at boundary)
        boundary_col = j_min
        boundary_mask = (water_depth[:, boundary_col] > 0.01)
        if np.any(boundary_mask):
            # Ensure flow is outward (negative x velocity)
            corrected_vx[boundary_mask, boundary_col] = np.minimum(corrected_vx[boundary_mask, boundary_col], 0)
        
        # Right boundary (prevent flow from left to right at boundary)
        boundary_col = j_max
        boundary_mask = (water_depth[:, boundary_col] > 0.01)
        if np.any(boundary_mask):
            # Ensure flow is outward (positive x velocity)
            corrected_vx[boundary_mask, boundary_col] = np.maximum(corrected_vx[boundary_mask, boundary_col], 0)
        
        # Top boundary (prevent flow from bottom to top at boundary)
        boundary_row = i_min
        boundary_mask = (water_depth[boundary_row, :] > 0.01)
        if np.any(boundary_mask):
            # Ensure flow is outward (negative y velocity)
            corrected_vy[boundary_row, boundary_mask] = np.minimum(corrected_vy[boundary_row, boundary_mask], 0)
        
        # Bottom boundary (prevent flow from top to bottom at boundary)
        boundary_row = i_max
        boundary_mask = (water_depth[boundary_row, :] > 0.01)
        if np.any(boundary_mask):
            # Ensure flow is outward (positive y velocity)
            corrected_vy[boundary_row, boundary_mask] = np.maximum(corrected_vy[boundary_row, boundary_mask], 0)
            
        logger.info(f"Enforced boundary flow constraints for {np.sum(boundary_mask)} boundary cells")
    
    except Exception as e:
        logger.error(f"Error enforcing boundary flow: {str(e)}")
    
    return corrected_vx, corrected_vy

def analyze_channel_direction(water_depth, dem_array, water_surface):
    """
    Analyze the overall channel direction to detect main flow paths.
    
    Parameters:
        water_depth (numpy.ndarray): Water depth array
        dem_array (numpy.ndarray): DEM array
        water_surface (numpy.ndarray): Water surface elevation array
        
    Returns:
        tuple: Main channel direction (dx, dy)
    """
    # Find the deepest point as the starting point for analysis
    channel_mask = water_depth > 0.5  # Consider deeper parts as channel
    
    if not np.any(channel_mask):
        return 0, 0  # No clear channel
    
    # Get lowest elevation in the wet area
    lowest_elev = np.inf
    lowest_i, lowest_j = 0, 0
    
    rows, cols = dem_array.shape
    
    for i in range(rows):
        for j in range(cols):
            if channel_mask[i, j] and dem_array[i, j] < lowest_elev:
                lowest_elev = dem_array[i, j]
                lowest_i, lowest_j = i, j
    
    # Find highest upstream elevation in the wet area
    highest_elev = -np.inf
    highest_i, highest_j = 0, 0
    
    for i in range(rows):
        for j in range(cols):
            if channel_mask[i, j] and water_surface[i, j] > highest_elev:
                highest_elev = water_surface[i, j]
                highest_i, highest_j = i, j
    
    # Calculate overall direction from highest to lowest
    dx = lowest_j - highest_j
    dy = lowest_i - highest_i
    
    # Normalize
    mag = np.sqrt(dx**2 + dy**2)
    if mag > 0:
        dx /= mag
        dy /= mag
    
    return dx, dy

def ensure_correct_flow_directions(dem_array, water_depth, velocity_x, velocity_y, water_surface=None, bounding_box=None, geotransform=None):
    """
    Ensure that water flows correctly downhill by checking and adjusting velocity vectors.
    This is a critical fix for cases where mathematical approximations might cause incorrect flow.
    
    Parameters:
        dem_array (numpy.ndarray): Digital Elevation Model array
        water_depth (numpy.ndarray): Water depth array
        velocity_x (numpy.ndarray): X component of velocity
        velocity_y (numpy.ndarray): Y component of velocity
        water_surface (numpy.ndarray, optional): Water surface elevation array
        bounding_box (tuple, optional): (xmin, ymin, xmax, ymax) in world coordinates 
        geotransform (tuple, optional): GDAL geotransform
        
    Returns:
        tuple: Corrected velocity arrays (velocity_x, velocity_y)
    """
    rows, cols = dem_array.shape
    min_depth = 0.05  # Only consider cells with at least 5cm of water
    
    # Create water surface elevation array if not provided
    if water_surface is None:
        water_surface = dem_array + water_depth
    
    # Smooth the water surface slightly to reduce noise
    valid_mask = water_depth > min_depth
    smoothed_surface = np.copy(water_surface)
    if np.sum(valid_mask) > 0:  # Only smooth if we have water
        smoothed_surface[valid_mask] = gaussian_filter(
            water_surface[valid_mask], sigma=1.0)
    
    # Pad the surface for gradient calculation
    padded = np.pad(smoothed_surface, 1, mode='edge')
    
    # Analyze the channel direction for checking dominant flow
    channel_dx, channel_dy = analyze_channel_direction(water_depth, dem_array, water_surface)
    
    # Calculate surface gradient (water flows from high to low)
    for i in range(1, rows-1):
        for j in range(1, cols-1):
            if water_depth[i, j] <= min_depth:
                continue
                
            # Calculate gradient of water surface using central difference
            dx = (padded[i+1, j+2] - padded[i+1, j]) / 2.0
            dy = (padded[i+2, j+1] - padded[i, j+1]) / 2.0
            
            # Special case handling for dam structures
            # Check surrounding cells for significant elevation changes that may indicate a dam
            neighbor_elevations = [
                padded[i, j+1],    # left
                padded[i+2, j+1],  # right
                padded[i+1, j],    # up
                padded[i+1, j+2]   # down
            ]
            center_elev = padded[i+1, j+1]
            elevation_diff = [abs(ne - center_elev) for ne in neighbor_elevations]
            max_diff = max(elevation_diff)
            
            # If we detect a significant elevation change (potential dam structure)
            is_dam_structure = max_diff > 1.0  # More than 1 meter drop indicates potential dam
            
            # For dam structures, force water to flow from higher to lower elevation
            if is_dam_structure:
                # Find the direction with the greatest downward slope
                directions = [(0, -1), (0, 1), (-1, 0), (1, 0)]  # Left, right, up, down
                slopes = []
                
                for di, (dy_dir, dx_dir) in enumerate(directions):
                    ni, nj = i + dy_dir + 1, j + dx_dir + 1  # +1 because padded
                    slope = center_elev - padded[ni, nj]
                    slopes.append(slope)
                
                # Find the steepest downslope direction
                max_slope_idx = np.argmax(slopes)
                if slopes[max_slope_idx] > 0:  # If there's a downslope
                    dy_flow, dx_flow = directions[max_slope_idx]
                    # Force flow in this direction
                    v_mag = np.sqrt(velocity_x[i, j]**2 + velocity_y[i, j]**2)
                    v_mag = max(v_mag, 0.5)  # Ensure minimum flow velocity
                    velocity_x[i, j] = v_mag * dx_flow
                    velocity_y[i, j] = v_mag * dy_flow
            
            # Standard handling for non-dam situations
            # Check if velocity direction is consistent with surface gradient
            # If water is flowing uphill, reverse the direction
            elif (dx * velocity_x[i, j] > 0) or (dy * velocity_y[i, j] > 0):
                # Velocity direction is wrong (water flowing uphill)
                # Correct the flow direction to follow the gradient
                grad_mag = np.sqrt(dx*dx + dy*dy)
                if grad_mag > 1e-6:
                    # Set velocity to flow downhill following the surface gradient
                    v_mag = np.sqrt(velocity_x[i, j]**2 + velocity_y[i, j]**2)
                    v_mag = max(v_mag, 0.2)  # Ensure minimum flow velocity
                    
                    # Check against dominant channel direction to avoid backflow
                    flow_dx = -dx / grad_mag
                    flow_dy = -dy / grad_mag
                    
                    # If dominant channel direction exists and flow direction opposes it strongly,
                    # modify the flow to follow the dominant channel direction
                    if channel_dx != 0 or channel_dy != 0:
                        # Calculate dot product to check if flow opposes channel direction
                        dot_product = flow_dx * channel_dx + flow_dy * channel_dy
                        if dot_product < -0.7:  # Strongly opposing directions
                            # Use channel direction instead
                            flow_dx = channel_dx
                            flow_dy = channel_dy
                    
                    velocity_x[i, j] = v_mag * flow_dx
                    velocity_y[i, j] = v_mag * flow_dy
    
    # Enforce boundary flow constraints if bounding box is provided
    if bounding_box is not None and geotransform is not None:
        velocity_x, velocity_y = enforce_boundary_flow(
            velocity_x, velocity_y, water_depth, bounding_box, geotransform)
    
    logger.info("Applied flow direction corrections to ensure downhill flow")
    return velocity_x, velocity_y

def analyze_flow_patterns(dem_path, water_surface_path, output_folder=None, bounding_box=None):
    """
    Analyze flow patterns from DEM and water surface to correct flow direction.
    
    Parameters:
        dem_path (str): Path to DEM file
        water_surface_path (str): Path to water surface elevation file
        output_folder (str): Output folder for results
        bounding_box (tuple): (xmin, ymin, xmax, ymax) in world coordinates
        
    Returns:
        tuple: Paths to corrected velocity rasters
    """
    if output_folder is None:
        output_folder = os.path.dirname(dem_path)
    
    # Read DEM
    dem_ds = gdal.Open(dem_path)
    dem_array = dem_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
    geotransform = dem_ds.GetGeoTransform()
    projection = dem_ds.GetProjection()
    nodata = dem_ds.GetRasterBand(1).GetNoDataValue()
    dem_array[dem_array == nodata] = np.nan
    
    # Read water surface
    water_ds = gdal.Open(water_surface_path)
    water_surface = water_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
    water_nodata = water_ds.GetRasterBand(1).GetNoDataValue()
    water_surface[water_surface == water_nodata] = np.nan
    
    # Calculate water depth
    water_depth = np.maximum(water_surface - dem_array, 0)
    
    # Calculate gradient of water surface
    dx = abs(geotransform[1])
    dy = abs(geotransform[5])
    
    # Use central differences with padding
    pad_surface = np.pad(water_surface, pad_width=1, mode='edge')
    grad_x = np.zeros_like(water_surface)
    grad_y = np.zeros_like(water_surface)
    
    # Valid areas for calculation
    valid_mask = water_depth > 0.01
    
    rows, cols = water_surface.shape
    for i in range(rows):
        for j in range(cols):
            if valid_mask[i, j]:
                grad_x[i, j] = (pad_surface[i+1, j+2] - pad_surface[i+1, j]) / (2 * dx)
                grad_y[i, j] = (pad_surface[i+2, j+1] - pad_surface[i, j+1]) / (2 * dy)
    
    # Calculate velocity based on gradient and Manning's equation
    manning_n = 0.035  # Default Manning's roughness
    hydraulic_radius = water_depth.copy()  # Simplified for 2D
    
    slope_mag = np.sqrt(grad_x**2 + grad_y**2)
    velocity_mag = np.zeros_like(water_depth)
    
    # Manning's equation: v = (1/n) * R^(2/3) * S^(1/2)
    valid_mask = (slope_mag > 0) & (hydraulic_radius > 0.01)
    if np.any(valid_mask):
        velocity_mag[valid_mask] = (1.0 / manning_n) * \
                                  (hydraulic_radius[valid_mask] ** (2/3)) * \
                                  (slope_mag[valid_mask] ** 0.5)
    
    # Calculate velocity components
    velocity_x = np.zeros_like(water_depth)
    velocity_y = np.zeros_like(water_depth)
    
    # Velocity is in the direction of negative gradient
    valid_mask = slope_mag > 0
    if np.any(valid_mask):
        velocity_x[valid_mask] = -velocity_mag[valid_mask] * (grad_x[valid_mask] / slope_mag[valid_mask])
        velocity_y[valid_mask] = -velocity_mag[valid_mask] * (grad_y[valid_mask] / slope_mag[valid_mask])
    
    # Apply enhanced terrain-based correction
    corrected_vx, corrected_vy = ensure_correct_flow_directions(
        dem_array, 
        water_depth, 
        velocity_x, 
        velocity_y, 
        water_surface=water_surface,
        bounding_box=bounding_box, 
        geotransform=geotransform
    )
    
    # Save outputs
    vx_path = os.path.join(output_folder, "velocity_x_corrected.tif")
    vy_path = os.path.join(output_folder, "velocity_y_corrected.tif")
    vmag_path = os.path.join(output_folder, "velocity_mag_corrected.tif")
    
    # Calculate final magnitude
    final_magnitude = np.sqrt(corrected_vx**2 + corrected_vy**2)
    
    # Save velocity x-component
    driver = gdal.GetDriverByName("GTiff")
    out_ds = driver.Create(vx_path, cols, rows, 1, gdal.GDT_Float32)
    out_ds.SetGeoTransform(geotransform)
    out_ds.SetProjection(projection)
    out_band = out_ds.GetRasterBand(1)
    out_band.SetNoDataValue(-9999)
    out_band.WriteArray(np.where(np.isnan(corrected_vx), -9999, corrected_vx))
    out_ds.FlushCache()
    
    # Save velocity y-component
    out_ds = driver.Create(vy_path, cols, rows, 1, gdal.GDT_Float32)
    out_ds.SetGeoTransform(geotransform)
    out_ds.SetProjection(projection)
    out_band = out_ds.GetRasterBand(1)
    out_band.SetNoDataValue(-9999)
    out_band.WriteArray(np.where(np.isnan(corrected_vy), -9999, corrected_vy))
    out_ds.FlushCache()
    
    # Save velocity magnitude
    out_ds = driver.Create(vmag_path, cols, rows, 1, gdal.GDT_Float32)
    out_ds.SetGeoTransform(geotransform)
    out_ds.SetProjection(projection)
    out_band = out_ds.GetRasterBand(1)
    out_band.SetNoDataValue(-9999)
    out_band.WriteArray(np.where(np.isnan(final_magnitude), -9999, final_magnitude))
    out_ds.FlushCache()
    
    return vx_path, vy_path, vmag_path
