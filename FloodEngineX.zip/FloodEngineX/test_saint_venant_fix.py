#!/usr/bin/env python3
"""
Test script to verify the FIXED Saint-Venant 2D solver works properly.
This should produce realistic velocities (< 8 m/s) instead of the previous 157 m/s.
"""

import numpy as np
import sys
import os

# Add the FloodEngineX directory to the Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from saint_venant_2d import SaintVenant2D
    print("✅ Successfully imported FIXED SaintVenant2D class")
except ImportError as e:
    print(f"❌ Failed to import SaintVenant2D: {e}")
    sys.exit(1)

def test_velocity_limits():
    """Test that the fixed solver produces realistic velocities."""
    print("\n🔬 Testing FIXED Saint-Venant velocity limits...")
    
    # Create a simple test DEM (10x10 grid)
    dem = np.array([
        [100, 99, 98, 97, 96, 95, 94, 93, 92, 91],
        [99, 98, 97, 96, 95, 94, 93, 92, 91, 90],
        [98, 97, 96, 95, 94, 93, 92, 91, 90, 89],
        [97, 96, 95, 94, 93, 92, 91, 90, 89, 88],
        [96, 95, 94, 93, 92, 91, 90, 89, 88, 87],
        [95, 94, 93, 92, 91, 90, 89, 88, 87, 86],
        [94, 93, 92, 91, 90, 89, 88, 87, 86, 85],
        [93, 92, 91, 90, 89, 88, 87, 86, 85, 84],
        [92, 91, 90, 89, 88, 87, 86, 85, 84, 83],
        [91, 90, 89, 88, 87, 86, 85, 84, 83, 82]
    ], dtype=np.float32)
    
    # Create a geotransform (1m pixel size)
    geotransform = (0.0, 1.0, 0.0, 0.0, 0.0, -1.0)
    
    print(f"📊 Test DEM shape: {dem.shape}")
    print(f"📊 DEM elevation range: {np.min(dem):.1f} to {np.max(dem):.1f}m")
    
    # Initialize the FIXED Saint-Venant model
    model = SaintVenant2D(dem, geotransform, manning_n=0.035)
    
    # Set initial conditions with water level at 95m (floods most of the area)
    water_level = 95.0
    model.set_initial_condition(water_level=water_level, initial_velocity=(0.1, 0.1))
    
    # Check initial velocities
    initial_max_vel = np.max(model.velocity_mag)
    print(f"🌊 Initial max velocity: {initial_max_vel:.3f} m/s")
    
    # Run several time steps
    print("\n⏱️ Running simulation steps...")
    for step in range(5):
        dt = model.step()
        max_vel = np.max(model.velocity_mag)
        mean_vel = np.mean(model.velocity_mag[model.h > 0.01])
        max_depth = np.max(model.h)
        
        print(f"   Step {step+1}: dt={dt:.4f}s, max_vel={max_vel:.3f}m/s, mean_vel={mean_vel:.3f}m/s, max_depth={max_depth:.3f}m")
        
        # Critical test: velocity should never exceed the limits
        if max_vel > model.emergency_velocity_cap:
            print(f"❌ CRITICAL FAILURE: Velocity {max_vel:.1f} m/s exceeds emergency cap {model.emergency_velocity_cap} m/s")
            return False
        
        if max_vel > model.max_realistic_velocity:
            print(f"⚠️  WARNING: Velocity {max_vel:.1f} m/s exceeds realistic limit {model.max_realistic_velocity} m/s")
        
        # Test for NaN or infinite values
        if np.any(np.isnan(model.velocity_mag)) or np.any(np.isinf(model.velocity_mag)):
            print(f"❌ CRITICAL FAILURE: NaN or infinite velocities detected!")
            return False
    
    final_max_vel = np.max(model.velocity_mag)
    print(f"\n🎯 Final max velocity: {final_max_vel:.3f} m/s")
    
    # SUCCESS CRITERIA
    if final_max_vel <= model.emergency_velocity_cap:
        print(f"✅ SUCCESS: All velocities within emergency cap ({model.emergency_velocity_cap} m/s)")
        
        if final_max_vel <= model.max_realistic_velocity:
            print(f"✅ EXCELLENT: All velocities within realistic limit ({model.max_realistic_velocity} m/s)")
            return True
        else:
            print(f"✅ ACCEPTABLE: Velocities within emergency limits but above realistic threshold")
            return True
    else:
        print(f"❌ FAILURE: Velocities exceed emergency cap")
        return False

def main():
    """Main test function."""
    print("🔧 Testing FIXED Saint-Venant 2D Solver")
    print("=" * 50)
    
    # Test velocity limits
    success = test_velocity_limits()
    
    print("\n" + "=" * 50)
    if success:
        print("🎉 ALL TESTS PASSED!")
        print("🛡️  The FIXED Saint-Venant solver produces realistic velocities")
        print("🔬 You should now see velocities like 'max velocity = 3.456 m/s' instead of '157.288 m/s'")
    else:
        print("❌ TESTS FAILED!")
        print("🚨 The solver still has velocity issues")
    
    return success

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
