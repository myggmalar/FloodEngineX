# -*- coding: utf-8 -*-
"""
Utility functions for raster processing in FloodEngine
"""
import os
import numpy as np
from osgeo import gdal

def clip_dem_by_extent(dem_path, bbox=None, resolution_factor=1, output_folder=None):
    """
    Clip DEM by specified bounding box and/or resample by specified resolution factor
    
    Args:
        dem_path (str): Path to DEM file
        bbox (tuple): Bounding box as (xmin, ymin, xmax, ymax)
        resolution_factor (int): Factor to reduce resolution by (1=original, 2=half, etc)
        output_folder (str): Folder to save clipped DEM
    
    Returns:
        str: Path to clipped/resampled DEM or original if no changes needed
    """
    if bbox is None and resolution_factor == 1:
        # No clipping or resampling needed
        return dem_path
    
    # Setup output path
    if output_folder is None:
        output_folder = os.path.dirname(dem_path)
    
    # Create a descriptive filename
    base_name = os.path.splitext(os.path.basename(dem_path))[0]
    if bbox:
        suffix = f"_clip_{int(bbox[0])}_{int(bbox[1])}_{int(bbox[2])}_{int(bbox[3])}"
    else:
        suffix = ""
        
    if resolution_factor > 1:
        suffix += f"_res_{resolution_factor}"
    
    output_path = os.path.join(output_folder, f"{base_name}{suffix}.tif")
    
    # Check if output already exists and is newer than input
    if os.path.exists(output_path):
        if os.path.getmtime(output_path) > os.path.getmtime(dem_path):
            print(f"Using existing clipped/resampled DEM: {output_path}")
            return output_path
    
    # Open original DEM
    src_ds = gdal.Open(dem_path)
    if src_ds is None:
        print(f"Error: Could not open DEM file: {dem_path}")
        return dem_path
    
    # Setup processing options
    translateOptions = []
    
    # Set projection window if bounding box is specified
    if bbox:
        translateOptions.extend([
            "-projwin", str(bbox[0]), str(bbox[3]), str(bbox[2]), str(bbox[1])
        ])
    
    # Set resolution if factor is specified
    if resolution_factor > 1:
        # Get original resolution
        gt = src_ds.GetGeoTransform()
        orig_res_x = gt[1]
        orig_res_y = abs(gt[5])
        
        # Calculate new resolution
        new_res_x = orig_res_x * resolution_factor
        new_res_y = orig_res_y * resolution_factor
        
        translateOptions.extend(["-tr", str(new_res_x), str(new_res_y)])
    
    # Add resampling algorithm
    translateOptions.extend(["-r", "bilinear"])
    
    try:
        # Execute the gdal_translate command
        print(f"Clipping DEM with bbox={bbox}, resolution_factor={resolution_factor}")
        gdal.Translate(output_path, src_ds, options=" ".join(translateOptions))
        print(f"DEM clipped successfully: {output_path}")
        return output_path
    except Exception as e:
        print(f"Error clipping DEM: {str(e)}")
        return dem_path
    finally:
        src_ds = None  # Close dataset

def load_bathymetry(bath_path):
    """Load bathymetry data from file"""
    try:
        bath_ds = gdal.Open(bath_path)
        if bath_ds is None:
            print(f"Warning: Could not open bathymetry: {bath_path}")
            return None
        
        bath_array = bath_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
        nodata = bath_ds.GetRasterBand(1).GetNoDataValue()
        if nodata is not None:
            bath_array[bath_array == nodata] = np.nan
        
        return bath_array
    except Exception as e:
        print(f"Error loading bathymetry: {str(e)}")
        return None
