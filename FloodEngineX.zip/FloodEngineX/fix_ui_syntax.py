#!/usr/bin/env python3
"""
Create a clean UI file without the problematic backup method.
"""

import os

def fix_ui_file():
    """Remove everything after line 1339 to clean up the malformed backup method."""
    ui_file_path = r"c:\Plugin\VSCode\Alt3\FloodEngineX\floodengine_ui.py"
    
    # Read the current file
    with open(ui_file_path, 'r', encoding='utf-8', errors='ignore') as f:
        lines = f.readlines()
    
    # Find the line with the last valid content (before the backup method)
    target_line = '            self.show_message(f"Animation error: {e}")\n'
    
    # Keep everything up to and including this line
    keep_lines = []
    found_target = False
    
    for line in lines:
        keep_lines.append(line)
        if target_line in line and not found_target:
            found_target = True
            break
    
    if found_target:
        print(f"Found target line, keeping {len(keep_lines)} lines")
        
        # Write the cleaned content back
        with open(ui_file_path + '.backup2', 'w', encoding='utf-8') as f:
            f.writelines(lines)  # Full backup
        
        with open(ui_file_path, 'w', encoding='utf-8') as f:
            f.writelines(keep_lines)
        
        print("✅ Cleaned UI file successfully")
        return True
    else:
        print("❌ Could not find target line")
        return False

if __name__ == "__main__":
    print("FloodEngine UI Cleanup Script")
    print("=" * 40)
    
    if fix_ui_file():
        print("✅ UI file cleaned successfully!")
        print("📝 Removed problematic backup method")
    else:
        print("❌ Failed to clean UI file")
