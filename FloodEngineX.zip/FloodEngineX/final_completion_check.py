#!/usr/bin/env python3
"""
Final Completion Check for FloodEngine
Verify all fixes are complete and ready for QGIS
"""

import os
import py_compile
import tempfile

def check_syntax():
    """Check Python syntax compilation"""
    print("🔍 Checking Python Syntax...")
    try:
        with tempfile.NamedTemporaryFile(suffix='.pyc', delete=True) as tmp:
            py_compile.compile('floodengine_ui.py', tmp.name, doraise=True)
        print("✅ Python syntax is valid")
        return True
    except py_compile.PyCompileError as e:
        print(f"❌ Syntax error: {e}")
        return False

def check_indentation():
    """Check for common indentation issues"""
    print("\n🔍 Checking Indentation...")
    with open('floodengine_ui.py', 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    issues_found = 0
    for i, line in enumerate(lines, 1):
        # Check for mixed tabs and spaces
        if '\t' in line and '    ' in line:
            print(f"⚠️  Line {i}: Mixed tabs and spaces detected")
            issues_found += 1
        
        # Check for inconsistent indentation patterns
        if line.strip() and line.startswith('  ') and not line.startswith('    '):
            stripped = line.lstrip()
            if not stripped.startswith('#') and not stripped.startswith('"""'):
                print(f"⚠️  Line {i}: Possible indentation issue: {repr(line[:20])}")
                issues_found += 1
    
    if issues_found == 0:
        print("✅ No indentation issues found")
    else:
        print(f"⚠️  Found {issues_found} potential indentation issues")
    
    return issues_found == 0

def check_connect_signals():
    """Check that connect_signals method exists and has content"""
    print("\n🔍 Checking connect_signals method...")
    
    with open('floodengine_ui.py', 'r', encoding='utf-8') as f:
        content = f.read()
    
    if "def connect_signals(self):" not in content:
        print("❌ connect_signals method not found")
        return False
    
    # Extract the connect_signals method
    start_idx = content.find("def connect_signals(self):")
    if start_idx == -1:
        print("❌ connect_signals method not found")
        return False
    
    # Find the end of the method (next method or class)
    method_content = content[start_idx:]
    end_patterns = ["\n    def ", "\nclass ", "\n\ndef "]
    end_idx = len(method_content)
    for pattern in end_patterns:
        found_idx = method_content.find(pattern, 1)
        if found_idx != -1 and found_idx < end_idx:
            end_idx = found_idx
    
    method_body = method_content[:end_idx]
    
    # Count signal connections
    signal_count = method_body.count('.clicked.connect(')
    signal_count += method_body.count('.toggled.connect(')
    signal_count += method_body.count('.stateChanged.connect(')
    signal_count += method_body.count('.valueChanged.connect(')
    
    print(f"✅ connect_signals method found with {signal_count} signal connections")
    
    if signal_count < 20:  # Expect at least 20 signal connections
        print(f"⚠️  Low number of signal connections. Expected at least 20, found {signal_count}")
        return False
    
    return True

def check_ui_elements():
    """Check for presence of key UI elements that were missing"""
    print("\n🔍 Checking for required UI elements...")
    
    with open('floodengine_ui.py', 'r', encoding='utf-8') as f:
        content = f.read()
    
    required_elements = [
        "self.adv_buildings_btn",
        "self.adv_soil_btn", 
        "self.adv_hydrograph",
        "self.adv_hydrograph_btn",
        "self.adv_buildings_path",
        "self.adv_enable_groundwater",
        "self.adv_hydraulic_conductivity",
        "self.adv_draw_threshold"
    ]
    
    missing_elements = []
    for element in required_elements:
        if element not in content:
            missing_elements.append(element)
    
    if missing_elements:
        print(f"❌ Missing UI elements: {missing_elements}")
        return False
    else:
        print(f"✅ All {len(required_elements)} required UI elements found")
        return True

def main():
    """Run all validation checks"""
    print("🚀 FloodEngine Final Completion Check")
    print("=" * 50)
    
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    if not os.path.exists('floodengine_ui.py'):
        print("❌ floodengine_ui.py not found in current directory")
        return False
    
    checks = [
        ("Syntax Check", check_syntax),
        ("Indentation Check", check_indentation), 
        ("connect_signals Check", check_connect_signals),
        ("UI Elements Check", check_ui_elements)
    ]
    
    all_passed = True
    for check_name, check_func in checks:
        try:
            result = check_func()
            all_passed = all_passed and result
        except Exception as e:
            print(f"❌ {check_name} failed with error: {e}")
            all_passed = False
    
    print("\n" + "=" * 50)
    if all_passed:
        print("🎉 ALL CHECKS PASSED! FloodEngine is ready for QGIS testing!")
        print("✅ The indentation error has been fixed")
        print("✅ connect_signals method is complete")
        print("✅ All required UI elements are present")
        print("✅ Python syntax is valid")
        print("\n🚀 Next step: Test plugin loading in QGIS")
    else:
        print("❌ Some checks failed. Please review the issues above.")
    
    return all_passed

if __name__ == "__main__":
    main()
