#!/usr/bin/env python3
"""
Quick test to verify model_hydraulic.py syntax fix
"""

def test_syntax_fix():
    """Test that model_hydraulic.py can be imported without syntax errors."""
    try:
        import ast
        
        # Test syntax parsing
        with open('model_hydraulic.py', 'r') as f:
            code = f.read()
        
        # This will raise SyntaxError if there are issues
        ast.parse(code)
        print("✅ Syntax check passed")
        
        # Test that the main functions exist
        expected_functions = [
            'calculate_flood_area',
            'create_merged_terrain_model', 
            'simulate_saint_venant_2d',
            'load_raster_to_array_gdal',
            'polygonize_mask_gdal',
            'create_streamlines_from_velocity_gdal'
        ]
        
        for func_name in expected_functions:
            if f"def {func_name}(" in code:
                print(f"✅ Function {func_name} found")
            else:
                print(f"❌ Function {func_name} missing")
        
        # Check that rasterio is not imported
        if 'import rasterio' not in code and 'from rasterio' not in code:
            print("✅ No rasterio imports found (good)")
        else:
            print("❌ Still has rasterio imports")
            
        # Check GDAL usage
        if 'gdal.Open(' in code and 'gdal.Create(' in code:
            print("✅ GDAL usage found")
        else:
            print("❌ GDAL usage not found")
            
        return True
        
    except SyntaxError as e:
        print(f"❌ Syntax error: {e}")
        return False
    except Exception as e:
        print(f"❌ Other error: {e}")
        return False

if __name__ == '__main__':
    print("🔧 Testing model_hydraulic.py syntax fix...")
    test_syntax_fix()
    print("✅ Test complete!")
