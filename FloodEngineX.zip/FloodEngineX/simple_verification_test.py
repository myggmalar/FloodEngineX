#!/usr/bin/env python3
"""
Simple Verification Test: Check if adaptive threshold fixes are working
"""

import sys
import os
import numpy as np
from pathlib import Path

# Add the plugin directory to path
plugin_dir = Path(__file__).parent
sys.path.insert(0, str(plugin_dir))

print("=== FLOODENGINE ADAPTIVE THRESHOLD VERIFICATION ===")
print(f"Plugin directory: {plugin_dir}")
print(f"Python version: {sys.version}")
print(f"NumPy version: {np.__version__}")

try:
    # Test importing our main module
    print("\n1. Testing imports...")
    from model_hydraulic import create_proper_flow_flood_mask
    print("✅ Successfully imported create_proper_flow_flood_mask")
    
    # Create test DEM data
    print("\n2. Creating test DEM data...")
    rows, cols = 100, 100
    dem_array = np.random.uniform(0, 10, (rows, cols)).astype(np.float32)
    # Add some lower areas that should flood
    dem_array[40:60, 40:60] = np.random.uniform(0, 2, (20, 20))
    print(f"✅ Created test DEM: {rows}x{cols}, elevation range: {dem_array.min():.2f} to {dem_array.max():.2f}")
    
    # Test multiple water levels
    print("\n3. Testing flood mask generation at different water levels...")
    water_levels = [1.0, 2.0, 3.0, 4.0, 5.0]
    
    for water_level in water_levels:
        print(f"\nTesting water level: {water_level}")
        
        try:
            flood_mask = create_proper_flow_flood_mask(
                dem_array=dem_array,
                water_level=water_level,
                nodata_value=-9999
            )
            
            flooded_cells = np.sum(flood_mask > 0)
            total_cells = dem_array.size
            flood_percentage = (flooded_cells / total_cells) * 100
            
            print(f"  ✅ Generated flood mask: {flooded_cells} flooded cells ({flood_percentage:.1f}%)")
            
            if flooded_cells == 0:
                print(f"  ⚠️  WARNING: No flooding detected at water level {water_level}")
            else:
                print(f"  ✅ SUCCESS: Flooding detected at water level {water_level}")
                
        except Exception as e:
            print(f"  ❌ ERROR at water level {water_level}: {str(e)}")
    
    print("\n=== TEST COMPLETED ===")
    print("If you see ✅ SUCCESS messages for multiple water levels, the adaptive threshold fixes are working!")
    
except ImportError as e:
    print(f"❌ Import error: {e}")
    print("Check that model_hydraulic.py is in the correct location and has no syntax errors")
except Exception as e:
    print(f"❌ Unexpected error: {e}")
    import traceback
    traceback.print_exc()
