"""
Simplified test script to verify water flow simulation without GDAL dependency
"""

import numpy as np
import logging
import matplotlib.pyplot as plt

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Create a simplified version of the SaintVenant2D class without GDAL
class SimpleSaintVenant2D:
    """
    Simplified version for testing without GDAL dependency
    """
    
    def __init__(self, dem_array, dx=1.0, dy=1.0, manning_n=0.035):
        """Initialize the simplified model"""
        self.dem = dem_array
        self.dx = dx
        self.dy = dy
        self.shape = dem_array.shape
        self.h = np.zeros(self.shape)  # Water depth
        self.qx = np.zeros(self.shape)  # Unit discharge in x-direction
        self.qy = np.zeros(self.shape)  # Unit discharge in y-direction
        self.u = np.zeros(self.shape)   # Velocity in x-direction
        self.v = np.zeros(self.shape)   # Velocity in y-direction
        
        # Manning's n coefficient
        if isinstance(manning_n, (int, float)):
            self.manning_n = np.full(self.shape, manning_n)
        else:
            self.manning_n = manning_n
        
        # Time step
        self.dt = 0.1
        
    def set_initial_condition(self, initial_depth=0.1, source_points=None):
        """
        Set initial water depth and identify source points for flow initiation.
        Enhanced version with proper terrain analysis.
        """
        print("\n=== Enhanced Initial Condition Setup ===")
        
        # Reset arrays
        self.h.fill(0.0)
        self.qx.fill(0.0)
        self.qy.fill(0.0)
        self.u.fill(0.0)
        self.v.fill(0.0)
        
        # Analyze terrain to find river network and source points
        print("Analyzing terrain for river network...")
        
        # Find local elevation minima (potential river channels)
        river_mask = self._identify_river_network()
        
        # Automatically identify source points if not provided
        if source_points is None:
            source_points = self._find_source_points(river_mask)
            print(f"Auto-identified {len(source_points)} source points")
        
        # Set initial water depth at source points and along river network
        for point in source_points:
            i, j = point
            if 0 <= i < self.shape[0] and 0 <= j < self.shape[1]:
                # Set higher initial depth at source points
                self.h[i, j] = initial_depth * 2.0
                print(f"Source point at ({i}, {j}): elevation={self.dem[i,j]:.2f}, depth={self.h[i,j]:.3f}")
        
        # Set gradual initial depth along river network
        for i in range(self.shape[0]):
            for j in range(self.shape[1]):
                if river_mask[i, j]:
                    if self.h[i, j] == 0.0:  # Not a source point
                        self.h[i, j] = initial_depth
        
        # Calculate initial velocities based on terrain gradient
        self._calculate_initial_velocities()
        
        print(f"Initial water volume: {np.sum(self.h):.3f} m³")
        print(f"Max water depth: {np.max(self.h):.3f} m")
        print(f"River network cells: {np.sum(river_mask)}")
        
    def _identify_river_network(self):
        """Identify potential river channels based on terrain analysis"""
        rows, cols = self.shape
        river_mask = np.zeros(self.shape, dtype=bool)
        
        # Simple approach: find cells that are lower than most of their neighbors
        for i in range(1, rows-1):
            for j in range(1, cols-1):
                current_elev = self.dem[i, j]
                neighbors = [
                    self.dem[i-1, j], self.dem[i+1, j],
                    self.dem[i, j-1], self.dem[i, j+1]
                ]
                # If current cell is lower than most neighbors, it's likely a river channel
                lower_count = sum(1 for n_elev in neighbors if current_elev < n_elev)
                if lower_count >= 2:
                    river_mask[i, j] = True
        
        return river_mask
    
    def _find_source_points(self, river_mask):
        """Find source points (high elevation points in river network)"""
        source_points = []
        
        # Find cells in river network that are local elevation maxima
        for i in range(1, self.shape[0]-1):
            for j in range(1, self.shape[1]-1):
                if river_mask[i, j]:
                    current_elev = self.dem[i, j]
                    
                    # Check if this is a local maximum within river network
                    is_source = True
                    for di in [-1, 0, 1]:
                        for dj in [-1, 0, 1]:
                            if di == 0 and dj == 0:
                                continue
                            ni, nj = i + di, j + dj
                            if (0 <= ni < self.shape[0] and 0 <= nj < self.shape[1] and 
                                river_mask[ni, nj] and self.dem[ni, nj] > current_elev):
                                is_source = False
                                break
                        if not is_source:
                            break
                    
                    if is_source:
                        source_points.append((i, j))
        
        # If no sources found, use highest points in river network
        if not source_points:
            river_elevations = self.dem[river_mask]
            if len(river_elevations) > 0:
                max_elev = np.max(river_elevations)
                for i in range(self.shape[0]):
                    for j in range(self.shape[1]):
                        if river_mask[i, j] and abs(self.dem[i, j] - max_elev) < 0.1:
                            source_points.append((i, j))
        
        return source_points
    
    def _calculate_initial_velocities(self):
        """Calculate initial velocities based on terrain gradient"""
        print("Calculating initial velocities from terrain gradient...")
        
        # Calculate terrain gradients
        grad_x = np.zeros(self.shape)
        grad_y = np.zeros(self.shape)
        
        # Central difference for interior points
        grad_x[1:-1, 1:-1] = (self.dem[1:-1, 2:] - self.dem[1:-1, :-2]) / (2 * self.dx)
        grad_y[1:-1, 1:-1] = (self.dem[2:, 1:-1] - self.dem[:-2, 1:-1]) / (2 * self.dy)
        
        # Set initial velocities proportional to negative gradient (downhill)
        velocity_scale = 0.5  # Scaling factor for initial velocity
        
        for i in range(self.shape[0]):
            for j in range(self.shape[1]):
                if self.h[i, j] > 0:
                    # Velocity in direction of steepest descent
                    self.u[i, j] = -velocity_scale * grad_x[i, j]
                    self.v[i, j] = -velocity_scale * grad_y[i, j]
                    
                    # Limit maximum initial velocity
                    speed = np.sqrt(self.u[i, j]**2 + self.v[i, j]**2)
                    if speed > 1.0:
                        self.u[i, j] *= 1.0 / speed
                        self.v[i, j] *= 1.0 / speed
                    
                    # Update unit discharges
                    self.qx[i, j] = self.h[i, j] * self.u[i, j]
                    self.qy[i, j] = self.h[i, j] * self.v[i, j]
        
        print(f"Max initial velocity: {np.max(np.sqrt(self.u**2 + self.v**2)):.3f} m/s")
    
    def get_water_surface(self):
        """Get water surface elevation (terrain + depth)"""
        return self.dem + self.h

def main():
    """Run the simplified flow test"""
    print("=== Simplified Flow Simulation Test ===")
    
    # Create a test DEM with a river channel and dam
    print("\nCreating test DEM...")
    dem_size = 30
    dem = np.ones((dem_size, dem_size)) * 100.0  # Base elevation
    
    # Create a channel with varying elevation (higher at top)
    channel_width = 3
    channel_center = dem_size // 2
    
    print("Adding river channel...")
    for i in range(dem_size):
        # Calculate elevation (decreasing from top to bottom)
        channel_elevation = 98.0 - (i / dem_size) * 4.0
        for j in range(channel_center - channel_width, channel_center + channel_width + 1):
            dem[i, j] = channel_elevation
    
    # Add a dam
    dam_row = dem_size * 3 // 4  # Dam at 3/4 down the channel
    dam_height = 2.0
    print(f"Adding dam at row {dam_row} with height {dam_height}m...")
    
    for j in range(channel_center - channel_width - 1, channel_center + channel_width + 2):
        dem[dam_row, j] = dem[dam_row, j] + dam_height
    
    # Print DEM statistics
    print(f"\nDEM Statistics:")
    print(f"Size: {dem.shape}")
    print(f"Elevation range: {np.min(dem):.2f} - {np.max(dem):.2f} m")
    print(f"Channel center: column {channel_center}")
    print(f"Dam location: row {dam_row}")
    
    # Initialize the model
    print("\nInitializing Saint-Venant 2D model...")
    geotransform = (0, 1, 0, 0, 0, -1)  # Simple 1x1 meter cells
    model = SimpleSaintVenant2D(dem, dx=1.0, dy=1.0)
    
    # Set initial conditions
    print("\nSetting initial conditions...")
    model.set_initial_condition(initial_depth=0.2)
    
    # Analyze initial state
    print(f"\nInitial State Analysis:")
    print(f"Total water volume: {np.sum(model.h):.3f} m³")
    print(f"Water depth range: {np.min(model.h):.3f} - {np.max(model.h):.3f} m")
    print(f"Cells with water: {np.sum(model.h > 0)}")
    
    # Check water surface levels
    water_surface = model.get_water_surface()
    print(f"Water surface range: {np.min(water_surface[model.h > 0]):.3f} - {np.max(water_surface[model.h > 0]):.3f} m")
    
    # Test source point identification
    print(f"\nSource Points Analysis:")
    river_mask = model._identify_river_network()
    source_points = model._find_source_points(river_mask)
    
    for i, (row, col) in enumerate(source_points):
        elev = dem[row, col]
        depth = model.h[row, col]
        surface = water_surface[row, col]
        print(f"Source {i+1}: ({row}, {col}) - Elevation: {elev:.2f}m, Depth: {depth:.3f}m, Surface: {surface:.2f}m")
    
    # Verify flow is starting from highest points
    if source_points:
        source_elevations = [dem[point[0], point[1]] for point in source_points]
        channel_elevations = dem[river_mask]
        
        print(f"\nFlow Direction Verification:")
        print(f"Source elevations: {source_elevations}")
        print(f"Min channel elevation: {np.min(channel_elevations):.2f}m")
        print(f"Max channel elevation: {np.max(channel_elevations):.2f}m")
        
        # Check that sources are at high elevations
        high_elevation_sources = sum(1 for elev in source_elevations if elev >= np.percentile(channel_elevations, 75))
        print(f"Sources in top 25% of channel elevations: {high_elevation_sources}/{len(source_points)}")
        
        if high_elevation_sources > 0:
            print("✓ PASS: Flow is initiating from high elevation points")
        else:
            print("✗ FAIL: Flow is not starting from highest points")
    else:
        print("✗ FAIL: No source points identified")
    
    print("\n=== Test Complete ===")

if __name__ == "__main__":
    main()
