#!/usr/bin/env python3
"""
Test script to verify contour-based flood boundary clipping
"""

import os
import sys
import numpy as np
import matplotlib.pyplot as plt
from osgeo import gdal
from scipy.ndimage import gaussian_filter, binary_erosion

# Add the FloodEngineX directory to the path
sys.path.insert(0, r'c:\Plugin\VSCode\Alt3\FloodEngineX')

from model_hydraulic import create_precise_flood_boundary, load_raster_to_array_gdal

def test_contour_based_clipping():
    """Test the new contour-based flood boundary clipping"""
    
    print("🧪 Testing contour-based flood boundary clipping...")
    
    # Create a synthetic DEM with valleys and hills
    rows, cols = 100, 100
    x, y = np.meshgrid(np.linspace(0, 10, cols), np.linspace(0, 10, rows))
    
    # Create a landscape with valleys (where water will accumulate)
    dem_data = 50 + 20 * np.sin(x/2) + 15 * np.cos(y/2) + 10 * np.sin(x * y / 5)
    
    # Add some noise to make it more realistic
    dem_data += np.random.normal(0, 2, dem_data.shape)
    
    # Create a water level that will flood the lower areas
    water_level = np.percentile(dem_data, 30)  # Flood the lowest 30% of terrain
    
    # Create water depth array (areas below water level have positive depth)
    water_depth = np.maximum(0, water_level - dem_data)
    
    # Add some variation to water depth to simulate realistic flooding
    water_depth = np.where(water_depth > 0, water_depth * (1 + 0.1 * np.random.rand(*water_depth.shape)), 0)
    
    print(f"📊 Created synthetic DEM: {dem_data.shape}")
    print(f"🌊 Water level: {water_level:.2f}m")
    print(f"💧 Max water depth: {np.max(water_depth):.2f}m")
    print(f"🏞️ Flooded area: {np.sum(water_depth > 0)} pixels")
    
    # Test the old method (morphological only)
    print("\n🔄 Testing old morphological method...")
    threshold = 0.05
    old_mask = (water_depth > threshold)
    
    # Apply basic morphological operations
    from scipy.ndimage import binary_erosion, binary_dilation, binary_fill_holes
    eroded = binary_erosion(old_mask, iterations=1)
    dilated = binary_dilation(eroded, iterations=2)
    filled = binary_fill_holes(dilated)
    old_final = binary_erosion(filled, iterations=1)
    
    print(f"✅ Old method: {np.sum(old_final)} flooded pixels")
    
    # Test the new method (contour-based)
    print("\n🎯 Testing new contour-based method...")
    new_mask = create_precise_flood_boundary(water_depth, threshold, dem_data, water_level)
    
    print(f"✅ New method: {np.sum(new_mask)} flooded pixels")
    
    # Create visualization
    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    
    # Row 1: DEM, Water depth, Water level contour
    im1 = axes[0, 0].imshow(dem_data, cmap='terrain', aspect='equal')
    axes[0, 0].set_title('DEM Elevation')
    axes[0, 0].contour(dem_data, levels=[water_level], colors='blue', linewidths=2)
    plt.colorbar(im1, ax=axes[0, 0], label='Elevation (m)')
    
    im2 = axes[0, 1].imshow(water_depth, cmap='Blues', aspect='equal')
    axes[0, 1].set_title('Water Depth')
    plt.colorbar(im2, ax=axes[0, 1], label='Depth (m)')
    
    # Show the black hairline contour clearly
    axes[0, 2].imshow(dem_data, cmap='terrain', aspect='equal', alpha=0.7)
    axes[0, 2].contour(dem_data, levels=[water_level], colors='black', linewidths=3)
    axes[0, 2].set_title('Black Hairline Contour')
    
    # Row 2: Old method, New method, Difference
    im3 = axes[1, 0].imshow(old_final, cmap='Blues', aspect='equal')
    axes[1, 0].set_title('Old Method (Morphological)')
    plt.colorbar(im3, ax=axes[1, 0])
    
    im4 = axes[1, 1].imshow(new_mask, cmap='Blues', aspect='equal')
    axes[1, 1].set_title('New Method (Contour-based)')
    plt.colorbar(im4, ax=axes[1, 1])
    
    # Show difference
    difference = new_mask.astype(int) - old_final.astype(int)
    im5 = axes[1, 2].imshow(difference, cmap='RdBu', aspect='equal', vmin=-1, vmax=1)
    axes[1, 2].set_title('Difference (New - Old)')
    plt.colorbar(im5, ax=axes[1, 2], label='Difference')
    
    plt.tight_layout()
    
    # Save the test result
    output_path = r'c:\Plugin\VSCode\Alt3\FloodEngineX\contour_clipping_test.png'
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    print(f"🖼️ Test visualization saved: {output_path}")
    
    plt.show()
    
    # Calculate metrics
    old_area = np.sum(old_final)
    new_area = np.sum(new_mask)
    overlap = np.sum(old_final & new_mask)
    
    print(f"\n📊 Comparison Results:")
    print(f"   Old method area: {old_area} pixels")
    print(f"   New method area: {new_area} pixels")
    print(f"   Overlap: {overlap} pixels")
    print(f"   Overlap percentage: {100 * overlap / max(old_area, new_area):.1f}%")
    
    if new_area > 0:
        print(f"✅ New contour-based method is working!")
        if abs(new_area - old_area) / old_area < 0.1:
            print(f"✅ Area change is reasonable (<10%)")
        else:
            print(f"⚠️ Significant area change: {100 * (new_area - old_area) / old_area:.1f}%")
    else:
        print(f"❌ New method failed - no flooded area detected")
    
    return new_mask, old_final

def test_real_dem_data():
    """Test with real DEM data if available"""
    print("\n🌍 Testing with real DEM data...")
    
    # Look for a real DEM file
    test_dem_paths = [
        r'c:\Plugin\VSCode\Alt3\FloodEngineX\test_dem.tif',
        r'c:\Plugin\VSCode\Alt3\FloodEngineX\sample_dem.tif'
    ]
    
    dem_path = None
    for path in test_dem_paths:
        if os.path.exists(path):
            dem_path = path
            break
    
    if dem_path:
        print(f"📍 Found real DEM: {dem_path}")
        try:
            dem_data = load_raster_to_array_gdal(dem_path)
            print(f"📊 Real DEM shape: {dem_data.shape}")
            print(f"🏔️ Elevation range: {np.min(dem_data):.2f} - {np.max(dem_data):.2f}m")
            
            # Test with real data
            water_level = np.percentile(dem_data, 25)  # Flood lowest 25%
            water_depth = np.maximum(0, water_level - dem_data)
            
            print(f"🌊 Testing real DEM with water level: {water_level:.2f}m")
            
            # Test new method
            new_mask = create_precise_flood_boundary(water_depth, 0.05, dem_data, water_level)
            
            print(f"✅ Real DEM test: {np.sum(new_mask)} flooded pixels")
            return True
            
        except Exception as e:
            print(f"❌ Error testing real DEM: {e}")
            return False
    else:
        print(f"ℹ️ No real DEM found for testing")
        return False

if __name__ == "__main__":
    print("🧪 CONTOUR-BASED FLOOD BOUNDARY CLIPPING TEST")
    print("=" * 60)
    
    try:
        # Test with synthetic data
        new_mask, old_mask = test_contour_based_clipping()
        
        # Test with real data if available
        test_real_dem_data()
        
        print("\n✅ All tests completed successfully!")
        
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
