#!/usr/bin/env python3
"""Simple test to debug validation script"""

print("Starting validation test...")

import os
import sys

print(f"Python version: {sys.version}")
print(f"Current directory: {os.getcwd()}")
print(f"Files in directory: {len(os.listdir('.'))}")

# Test the main validation
try:
    print("Testing production validation import...")
    import production_validation
    print("Import successful, running main...")
    production_validation.main()
except Exception as e:
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()
