#!/usr/bin/env python3
"""
Direct test of animation launch from UI without running simulation.
This simulates what happens when the UI tries to launch animation.
"""

import sys
import os
import tempfile
import time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_ui_animation_launch():
    """Test the UI animation launch mechanism directly."""
    print("🎬 Testing UI animation launch mechanism...")
    
    # Create temporary test structure
    temp_dir = tempfile.mkdtemp()
    output_folder = os.path.join(temp_dir, "test_output")
    animation_folder = os.path.join(output_folder, 'time_series_animation')
    os.makedirs(animation_folder, exist_ok=True)
    
    # Create dummy animation files to simulate what Saint-Venant creates
    test_file = os.path.join(animation_folder, "test_animation.txt")
    with open(test_file, 'w') as f:
        f.write("Test animation data - simulating Saint-Venant output")
    
    print(f"📁 Created test animation folder: {animation_folder}")
    
    # Test the exact same logic as in floodengine_ui.launch_animation_controls
    try:
        print("🔍 Testing animation folder detection...")
        
        # Import the launch function (same as UI does)
        from launch_animation import launch_animation_from_folder
        print("✅ Successfully imported launch_animation_from_folder")
        
        # Check for animation folder (same logic as UI)
        detected_folder = None
        if os.path.exists(os.path.join(output_folder, 'time_series_animation')):
            detected_folder = os.path.join(output_folder, 'time_series_animation')
            print(f"✅ Animation folder detected: {detected_folder}")
        elif os.path.exists(os.path.join(output_folder, 'rasters')):
            detected_folder = output_folder
            print(f"✅ Raster folder detected: {detected_folder}")
        else:
            print("❌ No animation data found in output folder")
            return False
        
        # Try to launch animation (forced standalone mode)
        print("🎬 Testing animation launch in standalone mode...")
        result = launch_animation_from_folder(detected_folder, standalone=True)
        
        if result:
            print("✅ Animation launch SUCCEEDED!")
            print("🎮 Animation dialog should be visible now")
            
            # Keep it alive for a few seconds to see if it works
            time.sleep(3)
            return True
        else:
            print("❌ Animation launch FAILED")
            return False
            
    except Exception as e:
        print(f"❌ Animation launch error: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    finally:
        # Clean up
        try:
            import shutil
            shutil.rmtree(temp_dir)
            print(f"🧹 Cleaned up: {temp_dir}")
        except:
            pass

if __name__ == "__main__":
    success = test_ui_animation_launch()
    print(f"\n{'✅ UI ANIMATION TEST PASSED' if success else '❌ UI ANIMATION TEST FAILED'}")
    
    if not success:
        print("\n🔍 Troubleshooting suggestions:")
        print("1. Check if PyQt5 is properly installed")
        print("2. Check if GDAL is available") 
        print("3. Check if time_series_animator.py exists")
        print("4. Try running this test again")
