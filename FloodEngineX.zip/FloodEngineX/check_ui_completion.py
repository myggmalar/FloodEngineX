#!/usr/bin/env python3
"""
Simple syntax check for the FloodEngine UI
"""

import sys
import os

def main():
    """Main test function"""
    ui_file = "floodengine_ui.py"
    
    if not os.path.exists(ui_file):
        print(f"❌ File {ui_file} not found")
        return False
    
    print("🔍 Checking FloodEngine UI...")
    
    # Check for syntax errors
    try:
        with open(ui_file, 'r', encoding='utf-8') as f:
            code = f.read()
        
        # Compile to check for syntax errors
        compile(code, ui_file, 'exec')
        print("✓ No syntax errors found")
        
        # Check for required methods
        if 'def toggle_simulation_type(self):' in code:
            print("✓ toggle_simulation_type method found")
        else:
            print("❌ toggle_simulation_type method missing")
            return False
            
        if 'def load_csv_preview(self):' in code:
            print("✓ load_csv_preview method found")
        else:
            print("❌ load_csv_preview method missing")
            return False
            
        if 'def toggle_2d_flow_controls(self, enabled):' in code:
            print("✓ toggle_2d_flow_controls method found")
        else:
            print("❌ toggle_2d_flow_controls method missing")
            return False
        
        # Check for unified 2D flow section
        if '2D Flow Modeling (Unified)' in code:
            print("✓ Unified 2D Flow Modeling section found")
        else:
            print("❌ Unified 2D Flow Modeling section missing")
            return False
        
        # Check signal connections
        if 'self.water_level_radio.toggled.connect(self.toggle_simulation_type)' in code:
            print("✓ Simulation type signal connections found")
        else:
            print("❌ Simulation type signal connections missing")
            return False
            
        if 'self.adv_enable_2d.toggled.connect(self.toggle_2d_flow_controls)' in code:
            print("✓ 2D flow controls signal connections found")
        else:
            print("❌ 2D flow controls signal connections missing")
            return False
        
        print("\n🎉 SUCCESS: All required components found!")
        print("✓ UI consolidation complete")
        print("✓ Redundant sections removed")
        print("✓ Missing methods implemented")
        print("✓ Signal connections fixed")
        
        return True
        
    except SyntaxError as e:
        print(f"❌ Syntax error: {e}")
        return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)
