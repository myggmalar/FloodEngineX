#!/usr/bin/env python3
"""
FINAL VERIFICATION TEST
======================
Test that the single-instance animation window pattern is properly implemented.
"""

import os
import sys

def test_single_instance_pattern():
    """Test the single-instance animation window pattern in the UI."""
    print("🧪 TESTING SINGLE-INSTANCE ANIMATION WINDOW PATTERN")
    print("=" * 60)
    
    # Test the UI initialization
    print("\n1. Testing UI initialization...")
    try:
        from floodengine_ui import FloodEngineDialog
        
        # Mock iface for testing
        class MockIface:
            def mainWindow(self):
                return None
        
        mock_iface = MockIface()
        dialog = FloodEngineDialog(mock_iface)
        
        # Check if animation_window is properly initialized
        if hasattr(dialog, 'animation_window'):
            print(f"✅ animation_window attribute exists: {dialog.animation_window}")
        else:
            print("❌ animation_window attribute missing!")
            return False
            
        if dialog.animation_window is None:
            print("✅ animation_window properly initialized to None")
        else:
            print(f"⚠️ animation_window not None: {dialog.animation_window}")
            
    except Exception as e:
        print(f"❌ UI initialization error: {e}")
        return False
    
    # Test the launch_animation_controls method
    print("\n2. Testing launch_animation_controls method...")
    try:
        import inspect
        
        # Get the method
        method = getattr(dialog, 'launch_animation_controls', None)
        if not method:
            print("❌ launch_animation_controls method not found!")
            return False
        
        print("✅ launch_animation_controls method exists")
        
        # Check the method signature
        sig = inspect.signature(method)
        print(f"✅ Method signature: {sig}")
        
        # Read the method source to verify single-instance logic
        source = inspect.getsource(method)
        
        # Check for single-instance checks
        if "if self.animation_window is not None and self.animation_window.isVisible():" in source:
            print("✅ Single-instance check present")
        else:
            print("❌ Single-instance check missing!")
            return False
            
        if "self.animation_window.raise_()" in source:
            print("✅ Window raising logic present")
        else:
            print("❌ Window raising logic missing!")
            return False
            
        if "self.animation_window = result" in source:
            print("✅ Window reference storage present")
        else:
            print("❌ Window reference storage missing!")
            return False
            
    except Exception as e:
        print(f"❌ Method verification error: {e}")
        return False
    
    # Test the closeEvent method
    print("\n3. Testing closeEvent cleanup...")
    try:
        close_method = getattr(dialog, 'closeEvent', None)
        if not close_method:
            print("❌ closeEvent method not found!")
            return False
        
        print("✅ closeEvent method exists")
        
        # Check the cleanup logic
        source = inspect.getsource(close_method)
        
        if "if self.animation_window is not None:" in source:
            print("✅ Animation window cleanup check present")
        else:
            print("❌ Animation window cleanup check missing!")
            return False
            
        if "self.animation_window.close()" in source:
            print("✅ Animation window close logic present")
        else:
            print("❌ Animation window close logic missing!")
            return False
            
        if "self.animation_window = None" in source:
            print("✅ Animation window reference cleanup present")
        else:
            print("❌ Animation window reference cleanup missing!")
            return False
            
    except Exception as e:
        print(f"❌ closeEvent verification error: {e}")
        return False
    
    # Test the safe launcher function
    print("\n4. Testing safe launcher...")
    try:
        from qgis_module_reload_helper import launch_animation_safe
        
        sig = inspect.signature(launch_animation_safe)
        print(f"✅ Safe launcher signature: {sig}")
        
        # The launcher should return the dialog object
        source = inspect.getsource(launch_animation_safe)
        if "return result" in source:
            print("✅ Safe launcher returns result")
        else:
            print("❌ Safe launcher doesn't return result!")
            return False
            
    except Exception as e:
        print(f"❌ Safe launcher verification error: {e}")
        return False
    
    # Test the main launcher function
    print("\n5. Testing main launcher function...")
    try:
        from launch_animation import launch_animation_from_folder
        
        sig = inspect.signature(launch_animation_from_folder)
        print(f"✅ Main launcher signature: {sig}")
        
        # Check that it returns the animator object
        source = inspect.getsource(launch_animation_from_folder)
        if "return animator" in source:
            print("✅ Main launcher returns animator object")
        else:
            print("❌ Main launcher doesn't return animator!")
            return False
            
    except Exception as e:
        print(f"❌ Main launcher verification error: {e}")
        return False
    
    print("\n" + "=" * 60)
    print("🎉 ALL TESTS PASSED! Single-instance pattern is properly implemented!")
    print("\nFeatures verified:")
    print("✅ UI properly initializes animation_window = None")
    print("✅ Single-instance check prevents multiple windows")
    print("✅ Existing window is raised/activated if already open")
    print("✅ New window reference is stored for proper management")
    print("✅ Window cleanup on dialog close")
    print("✅ Safe launcher returns dialog object")
    print("✅ Main launcher returns animator object")
    
    return True

if __name__ == "__main__":
    success = test_single_instance_pattern()
    if success:
        print("\n🎯 READY FOR PRODUCTION!")
        print("The animation dialog should now:")
        print("• Only show one instance at a time")
        print("• Properly raise/activate if already open")
        print("• Persist and remain visible after simulation")
        print("• Clean up properly when main dialog closes")
    else:
        print("\n❌ TESTS FAILED - Review implementation")
    
    sys.exit(0 if success else 1)
