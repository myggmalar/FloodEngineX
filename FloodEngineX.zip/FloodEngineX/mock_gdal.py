"""
Mock GDAL module for testing without GDAL dependency
"""

class MockGDAL:
    """Mock GDAL class for testing"""
    
    @staticmethod
    def Open(filename, access=0):
        """Mock Open method"""
        return None
    
    @staticmethod
    def GetDriverByName(driver_name):
        """Mock GetDriverByName method"""
        return None

# Create mock objects
gdal = MockGDAL()
