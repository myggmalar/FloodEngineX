"""
Map Canvas Time Series Integration
----------------------------------
Direct integration with QGIS map canvas for seamless time series animation
and interactive depth/elevation viewing.
"""

import os
import numpy as np
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QSlider, QLabel,
    QDockWidget, QGroupBox, QGridLayout, QDoubleSpinBox, QCheckBox,
    QTextEdit, QComboBox, QSpinBox, QProgressBar
)
from PyQt5.QtCore import QTimer, Qt, pyqtSignal, QObject
from PyQt5.QtGui import QFont, QColor
from qgis.core import (
    QgsProject, QgsRasterLayer, QgsCoordinateReferenceSystem,
    QgsCoordinateTransform, QgsPointXY, QgsMessageLog, Qgis,
    QgsRasterDataProvider, QgsMapLayerStyle
)
from qgis.gui import QgsMapToolEmitPoint, QgsMapCanvas
from qgis.utils import iface
import logging

logger = logging.getLogger("FloodEngine.MapCanvasAnimator")

class MapCanvasTimeSeriesController(QObject):
    """Controller for time series animation directly in the map canvas."""
    
    # Signals
    timestep_changed = pyqtSignal(int, float)  # timestep, time
    animation_state_changed = pyqtSignal(bool)  # is_playing
    point_sampled = pyqtSignal(dict)  # point data
    
    def __init__(self, results_data, output_folder, parent=None):
        super().__init__(parent)
        
        self.results_data = results_data
        self.output_folder = output_folder
        self.current_timestep = 0
        self.is_playing = False
        self.animation_speed = 500  # ms per frame
        
        # Animation timer
        self.timer = QTimer()
        self.timer.timeout.connect(self.advance_timestep)
        
        # Map canvas and tools
        self.map_canvas = iface.mapCanvas()
        self.click_tool = QgsMapToolEmitPoint(self.map_canvas)
        self.click_tool.canvasClicked.connect(self.on_map_clicked)
        
        # Time series data
        self.timestamps = results_data.get('times', [])
        self.water_depths = results_data.get('water_depths', [])
        self.velocity_data = {
            'velocity_x': results_data.get('velocity_x', []),
            'velocity_y': results_data.get('velocity_y', []),
            'velocity_mag': []
        }
        
        # Calculate velocity magnitudes if components are available
        if (len(self.velocity_data['velocity_x']) > 0 and 
            len(self.velocity_data['velocity_y']) > 0):
            for vx, vy in zip(self.velocity_data['velocity_x'], self.velocity_data['velocity_y']):
                vel_mag = np.sqrt(vx**2 + vy**2)
                self.velocity_data['velocity_mag'].append(vel_mag)
        
        # DEM and geospatial info
        self.dem_array = results_data.get('dem_array')
        self.geotransform = results_data.get('geotransform')
        
        # Coordinate systems
        self.setup_coordinate_systems()
        
        # Layer management
        self.time_series_layers = {}
        self.layer_styles = {}
        
        logger.info(f"Map Canvas Time Series Controller initialized with {len(self.timestamps)} timesteps")
    
    def setup_coordinate_systems(self):
        """Set up coordinate system transformations."""
        # RH2000 (SWEREF99 TM) - EPSG:3006
        self.rh2000_crs = QgsCoordinateReferenceSystem("EPSG:3006")
        
        # Map canvas CRS
        self.map_crs = self.map_canvas.mapSettings().destinationCrs()
        
        # Coordinate transformation
        if self.map_crs != self.rh2000_crs:
            self.coord_transform = QgsCoordinateTransform(
                self.map_crs, self.rh2000_crs, QgsProject.instance()
            )
            self.reverse_transform = QgsCoordinateTransform(
                self.rh2000_crs, self.map_crs, QgsProject.instance()
            )
        else:
            self.coord_transform = None
            self.reverse_transform = None
    
    def create_time_series_layers(self):
        """Create time series layers for animation."""
        if not os.path.exists(self.output_folder):
            os.makedirs(self.output_folder)
        
        # Create raster files for each timestep
        self.create_timestep_rasters()
        
        # Load as QGIS layers
        project = QgsProject.instance()
        
        for i, timestamp in enumerate(self.timestamps):
            # Depth layer
            depth_file = os.path.join(self.output_folder, f"flood_depth_t{i:04d}.tif")
            if os.path.exists(depth_file):
                layer_name = f"Flood Depth T{i+1:03d} ({timestamp:.1f}s)"
                depth_layer = QgsRasterLayer(depth_file, layer_name)
                
                if depth_layer.isValid():
                    # Style the layer
                    self.style_depth_layer(depth_layer)
                    
                    # Add to project
                    project.addMapLayer(depth_layer, False)
                    
                    # Store layer reference
                    self.time_series_layers[f'depth_{i}'] = depth_layer
                    
                    # Hide all except first timestep
                    if i > 0:
                        depth_layer.setCustomProperty('showInOverview', False)
            
            # Velocity layer (if available)
            if len(self.velocity_data['velocity_mag']) > i:
                velocity_file = os.path.join(self.output_folder, f"flood_velocity_t{i:04d}.tif")
                if os.path.exists(velocity_file):
                    layer_name = f"Flood Velocity T{i+1:03d} ({timestamp:.1f}s)"
                    velocity_layer = QgsRasterLayer(velocity_file, layer_name)
                    
                    if velocity_layer.isValid():
                        self.style_velocity_layer(velocity_layer)
                        project.addMapLayer(velocity_layer, False)
                        self.time_series_layers[f'velocity_{i}'] = velocity_layer
                        
                        if i > 0:
                            velocity_layer.setCustomProperty('showInOverview', False)
        
        # Update layer visibility
        self.update_layer_visibility()
        
        logger.info(f"Created {len(self.time_series_layers)} time series layers")
    
    def create_timestep_rasters(self):
        """Create raster files for each timestep."""
        from osgeo import gdal
        
        logger.info("Creating timestep raster files...")
        
        for i, (depth_array, timestamp) in enumerate(zip(self.water_depths, self.timestamps)):
            # Create depth raster
            depth_file = os.path.join(self.output_folder, f"flood_depth_t{i:04d}.tif")
            self._save_array_as_raster(depth_array, depth_file)
            
            # Create velocity raster if available
            if i < len(self.velocity_data['velocity_mag']):
                velocity_array = self.velocity_data['velocity_mag'][i]
                velocity_file = os.path.join(self.output_folder, f"flood_velocity_t{i:04d}.tif")
                self._save_array_as_raster(velocity_array, velocity_file)
        
        logger.info(f"Created raster files for {len(self.water_depths)} timesteps")
    
    def _save_array_as_raster(self, data_array, output_path, nodata=-9999):
        """Save numpy array as GeoTIFF raster."""
        from osgeo import gdal
        
        try:
            # Handle NaN values
            data_array = np.where(np.isnan(data_array), nodata, data_array)
            
            # Create output dataset
            driver = gdal.GetDriverByName('GTiff')
            rows, cols = data_array.shape
            
            dataset = driver.Create(output_path, cols, rows, 1, gdal.GDT_Float32,
                                  ['COMPRESS=LZW', 'TILED=YES'])
            
            if dataset is None:
                raise Exception(f"Could not create output file: {output_path}")
            
            # Set geospatial information
            if self.geotransform:
                dataset.SetGeoTransform(self.geotransform)
            
            # Set projection (assume same as map canvas)
            dataset.SetProjection(self.map_crs.toWkt())
            
            # Write data
            band = dataset.GetRasterBand(1)
            band.WriteArray(data_array)
            band.SetNoDataValue(nodata)
            band.ComputeStatistics(0)
            
            # Clean up
            band = None
            dataset = None
            
        except Exception as e:
            logger.error(f"Error saving raster {output_path}: {e}")
            raise
    
    def style_depth_layer(self, layer):
        """Apply blue gradient styling to depth layer."""
        try:
            # Get layer's data provider
            provider = layer.dataProvider()
            
            # Calculate statistics for styling
            band_stats = provider.bandStatistics(1)
            min_val = max(0.01, band_stats.minimumValue)  # Minimum visible depth
            max_val = band_stats.maximumValue
            
            # Apply pseudocolor renderer
            from qgis.core import (
                QgsSingleBandPseudoColorRenderer, QgsColorRampShader,
                QgsGradientColorRamp, QgsRasterShader
            )
            
            # Create color ramp (white to blue)
            color_ramp = QgsGradientColorRamp(
                QColor(255, 255, 255, 0),    # Transparent white (no water)
                QColor(0, 100, 200, 180)     # Semi-transparent blue (deep water)
            )
            
            # Create shader
            shader = QgsRasterShader()
            color_shader = QgsColorRampShader()
            color_shader.setColorRampType(QgsColorRampShader.Interpolated)
            color_shader.setSourceColorRamp(color_ramp)
            
            # Define value ranges
            items = []
            items.append(QgsColorRampShader.ColorRampItem(0, QColor(255, 255, 255, 0), '0'))
            items.append(QgsColorRampShader.ColorRampItem(min_val, QColor(173, 216, 230, 100), f'{min_val:.2f}'))
            items.append(QgsColorRampShader.ColorRampItem(max_val/2, QColor(0, 150, 255, 150), f'{max_val/2:.2f}'))
            items.append(QgsColorRampShader.ColorRampItem(max_val, QColor(0, 100, 200, 200), f'{max_val:.2f}'))
            
            color_shader.setColorRampItemList(items)
            shader.setRasterShaderFunction(color_shader)
            
            # Apply renderer
            renderer = QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, shader)
            layer.setRenderer(renderer)
            
            # Set layer opacity
            layer.setOpacity(0.7)
            
        except Exception as e:
            logger.error(f"Error styling depth layer: {e}")
    
    def style_velocity_layer(self, layer):
        """Apply red gradient styling to velocity layer."""
        try:
            # Similar to depth styling but with red color scheme
            provider = layer.dataProvider()
            band_stats = provider.bandStatistics(1)
            min_val = max(0.01, band_stats.minimumValue)
            max_val = band_stats.maximumValue
            
            from qgis.core import (
                QgsSingleBandPseudoColorRenderer, QgsColorRampShader,
                QgsGradientColorRamp, QgsRasterShader
            )
            
            # Create color ramp (transparent to red)
            color_ramp = QgsGradientColorRamp(
                QColor(255, 255, 255, 0),    # Transparent (low velocity)
                QColor(255, 0, 0, 180)       # Red (high velocity)
            )
            
            # Create and apply shader
            shader = QgsRasterShader()
            color_shader = QgsColorRampShader()
            color_shader.setColorRampType(QgsColorRampShader.Interpolated)
            color_shader.setSourceColorRamp(color_ramp)
            
            items = []
            items.append(QgsColorRampShader.ColorRampItem(0, QColor(255, 255, 255, 0), '0'))
            items.append(QgsColorRampShader.ColorRampItem(min_val, QColor(255, 255, 0, 100), f'{min_val:.2f}'))
            items.append(QgsColorRampShader.ColorRampItem(max_val/2, QColor(255, 150, 0, 150), f'{max_val/2:.2f}'))
            items.append(QgsColorRampShader.ColorRampItem(max_val, QColor(255, 0, 0, 200), f'{max_val:.2f}'))
            
            color_shader.setColorRampItemList(items)
            shader.setRasterShaderFunction(color_shader)
            
            renderer = QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, shader)
            layer.setRenderer(renderer)
            layer.setOpacity(0.6)
            
        except Exception as e:
            logger.error(f"Error styling velocity layer: {e}")
    
    def show_timestep(self, timestep_index):
        """Show specific timestep by index."""
        if 0 <= timestep_index < len(self.timestamps):
            self.current_timestep = timestep_index
            self.update_layer_visibility()
            
            # Emit signal
            timestamp = self.timestamps[timestep_index]
            self.timestep_changed.emit(timestep_index, timestamp)
            
            logger.debug(f"Showing timestep {timestep_index}: {timestamp:.1f}s")
    
    def toggle_animation(self):
        """Toggle animation play/pause."""
        if self.is_playing:
            self.timer.stop()
            self.is_playing = False
        else:
            self.timer.start(self.animation_speed)
            self.is_playing = True
        
        self.animation_state_changed.emit(self.is_playing)
    
    def set_animation_speed(self, fps):
        """Set animation speed in frames per second."""
        self.animation_speed = int(1000 / fps)  # Convert to milliseconds
        if self.is_playing:
            self.timer.setInterval(self.animation_speed)
    
    def set_point_sampling(self, enabled):
        """Enable or disable point sampling."""
        if enabled:
            self.map_canvas.setMapTool(self.click_tool)
            logger.info("📍 Point sampling enabled - click on map to sample data")
        else:
            self.map_canvas.unsetMapTool(self.click_tool)
            logger.info("📍 Point sampling disabled")
    
    def advance_timestep(self):
        """Advance to next timestep (for animation)."""
        if self.current_timestep < len(self.timestamps) - 1:
            self.show_timestep(self.current_timestep + 1)
        else:
            # End of animation - stop or loop
            self.timer.stop()
            self.is_playing = False
            self.animation_state_changed.emit(False)
            
            # Loop if enabled
            # (This would need to be controlled by UI)
            # self.show_timestep(0)
    
    def update_layer_visibility(self):
        """Update layer visibility for current timestep."""
        for layer_key, layer in self.time_series_layers.items():
            if layer_key.endswith(f'_{self.current_timestep}'):
                # Show current timestep
                layer.setCustomProperty('showInOverview', True)
                if hasattr(layer, 'triggerRepaint'):
                    layer.triggerRepaint()
            else:
                # Hide other timesteps
                layer.setCustomProperty('showInOverview', False)
        
        # Refresh map canvas
        self.map_canvas.refresh()
    
    def on_map_clicked(self, point, button):
        """Handle map click for point sampling."""
        try:
            # Convert map coordinates to array indices
            map_x, map_y = point.x(), point.y()
            
            # Convert to array coordinates using geotransform
            if self.geotransform:
                # geotransform = [x_origin, pixel_width, 0, y_origin, 0, pixel_height]
                x_origin, pixel_width, _, y_origin, _, pixel_height = self.geotransform
                
                col = int((map_x - x_origin) / pixel_width)
                row = int((map_y - y_origin) / pixel_height)
                
                # Check bounds
                if (0 <= row < len(self.water_depths[0]) and 
                    0 <= col < len(self.water_depths[0][0])):
                    
                    # Get data at this point for current timestep
                    depth = self.water_depths[self.current_timestep][row, col]
                    
                    # Calculate surface elevation
                    dem_elevation = 0
                    if self.dem_array is not None:
                        dem_elevation = self.dem_array[row, col]
                    
                    surface_elevation = dem_elevation + depth
                    
                    # Get velocity if available
                    velocity = 0
                    if (self.current_timestep < len(self.velocity_data['velocity_mag']) and
                        len(self.velocity_data['velocity_mag']) > 0):
                        velocity = self.velocity_data['velocity_mag'][self.current_timestep][row, col]
                    
                    # Convert to RH2000 if coordinate transform available
                    rh2000_x, rh2000_y = map_x, map_y
                    if self.coord_transform:
                        try:
                            from qgis.core import QgsPointXY
                            rh2000_point = self.coord_transform.transform(QgsPointXY(map_x, map_y))
                            rh2000_x, rh2000_y = rh2000_point.x(), rh2000_point.y()
                        except:
                            pass
                    
                    # Create point data
                    point_data = {
                        'x': map_x,
                        'y': map_y,
                        'rh2000_x': rh2000_x,
                        'rh2000_y': rh2000_y,
                        'depth': depth,
                        'surface_elevation': surface_elevation,
                        'dem_elevation': dem_elevation,
                        'velocity': velocity,
                        'timestep': self.current_timestep,
                        'time': self.timestamps[self.current_timestep]
                    }
                    
                    # Emit signal
                    self.point_sampled.emit(point_data)
                    
                    logger.info(f"Sampled point: depth={depth:.3f}m, surface={surface_elevation:.2f}m, vel={velocity:.3f}m/s")
                    
        except Exception as e:
            logger.error(f"Error sampling point: {e}")
    
    def sample_data_at_point(self, point):
        """Sample all available data at a point."""
        point_data = {
            'depth': None,
            'velocity': None,
            'dem_elevation': None,
            'surface_elevation': None,
            'time_series_depth': [],
            'time_series_velocity': []
        }
        
        try:
            # Convert map point to array indices if geotransform is available
            if self.geotransform:
                # Inverse geotransform to get pixel coordinates
                gt = self.geotransform
                px = int((point.x() - gt[0]) / gt[1])
                py = int((point.y() - gt[3]) / gt[5])
                
                # Check bounds
                if (self.dem_array is not None and 
                    0 <= py < self.dem_array.shape[0] and 
                    0 <= px < self.dem_array.shape[1]):
                    
                    # Sample DEM elevation
                    point_data['dem_elevation'] = float(self.dem_array[py, px])
                    
                    # Sample current timestep data
                    if self.current_timestep < len(self.water_depths):
                        depth = self.water_depths[self.current_timestep][py, px]
                        point_data['depth'] = float(depth) if not np.isnan(depth) else None
                        
                        if point_data['depth'] is not None and point_data['dem_elevation'] is not None:
                            point_data['surface_elevation'] = point_data['dem_elevation'] + point_data['depth']
                    
                    if self.current_timestep < len(self.velocity_data['velocity_mag']):
                        velocity = self.velocity_data['velocity_mag'][self.current_timestep][py, px]
                        point_data['velocity'] = float(velocity) if not np.isnan(velocity) else None
                    
                    # Generate time series
                    for i, timestamp in enumerate(self.timestamps):
                        if i < len(self.water_depths):
                            depth = self.water_depths[i][py, px]
                            point_data['time_series_depth'].append(
                                (timestamp, float(depth) if not np.isnan(depth) else None)
                            )
                        
                        if i < len(self.velocity_data['velocity_mag']):
                            velocity = self.velocity_data['velocity_mag'][i][py, px]
                            point_data['time_series_velocity'].append(
                                (timestamp, float(velocity) if not np.isnan(velocity) else None)
                            )
        
        except Exception as e:
            logger.error(f"Error sampling data: {e}")
        
        return point_data


class TimeSeriesControlPanel(QWidget):
    """Control panel widget for time series animation."""
    
    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self.controller = controller
        self.setup_ui()
        self.connect_signals()
    
    def setup_ui(self):
        """Set up the control panel UI."""
        layout = QVBoxLayout()
        
        # Title
        title = QLabel("🌊 FloodEngine Time Series")
        title.setAlignment(Qt.AlignCenter)
        font = QFont()
        font.setPointSize(12)
        font.setBold(True)
        title.setFont(font)
        layout.addWidget(title)
        
        # Current timestep info
        info_layout = QHBoxLayout()
        self.timestep_label = QLabel("Timestep: 1/1")
        self.time_label = QLabel("Time: 0.0 s")
        info_layout.addWidget(self.timestep_label)
        info_layout.addStretch()
        info_layout.addWidget(self.time_label)
        layout.addLayout(info_layout)
        
        # Timeline slider
        self.timeline_slider = QSlider(Qt.Horizontal)
        self.timeline_slider.setMinimum(0)
        self.timeline_slider.setMaximum(max(0, len(self.controller.timestamps) - 1))
        self.timeline_slider.valueChanged.connect(self.on_slider_changed)
        layout.addWidget(self.timeline_slider)
        
        # Playback controls
        controls_layout = QHBoxLayout()
        
        self.play_button = QPushButton("▶️ Play")
        self.play_button.clicked.connect(self.toggle_play)
        
        self.stop_button = QPushButton("⏹️ Stop")
        self.stop_button.clicked.connect(self.controller.stop_animation)
        
        controls_layout.addWidget(self.play_button)
        controls_layout.addWidget(self.stop_button)
        layout.addLayout(controls_layout)
        
        # Animation settings
        settings_group = QGroupBox("Settings")
        settings_layout = QGridLayout(settings_group)
        
        settings_layout.addWidget(QLabel("Speed (fps):"), 0, 0)
        self.speed_spinbox = QDoubleSpinBox()
        self.speed_spinbox.setRange(0.1, 10.0)
        self.speed_spinbox.setValue(2.0)
        self.speed_spinbox.valueChanged.connect(self.controller.set_animation_speed)
        settings_layout.addWidget(self.speed_spinbox, 0, 1)
        
        self.sampling_button = QPushButton("📍 Enable Point Sampling")
        self.sampling_button.setCheckable(True)
        self.sampling_button.toggled.connect(self.toggle_sampling)
        settings_layout.addWidget(self.sampling_button, 1, 0, 1, 2)
        
        layout.addWidget(settings_group)
        
        # Point information display
        info_group = QGroupBox("Point Information")
        info_layout = QVBoxLayout(info_group)
        
        self.point_info_text = QTextEdit()
        self.point_info_text.setMaximumHeight(150)
        self.point_info_text.setPlainText("Enable point sampling and click on map to view data...")
        info_layout.addWidget(self.point_info_text)
        
        layout.addWidget(info_group)
        
        self.setLayout(layout)
    
    def connect_signals(self):
        """Connect controller signals to UI updates."""
        self.controller.timestep_changed.connect(self.update_timestep_display)
        self.controller.animation_state_changed.connect(self.update_play_button)
        self.controller.point_sampled.connect(self.update_point_info)
    
    def toggle_play(self):
        """Toggle animation play/pause."""
        if self.controller.is_playing:
            self.controller.stop_animation()
        else:
            self.controller.start_animation()
    
    def toggle_sampling(self, enabled):
        """Toggle point sampling mode."""
        if enabled:
            self.controller.enable_point_sampling()
            self.sampling_button.setText("📍 Disable Point Sampling")
        else:
            self.controller.disable_point_sampling()
            self.sampling_button.setText("📍 Enable Point Sampling")
    
    def on_slider_changed(self, value):
        """Handle timeline slider changes."""
        self.controller.set_timestep(value)
    
    def update_timestep_display(self, timestep, time):
        """Update timestep display."""
        total_timesteps = len(self.controller.timestamps)
        self.timestep_label.setText(f"Timestep: {timestep + 1}/{total_timesteps}")
        self.time_label.setText(f"Time: {time:.1f} s")
        
        # Update slider without triggering signal
        self.timeline_slider.blockSignals(True)
        self.timeline_slider.setValue(timestep)
        self.timeline_slider.blockSignals(False)
    
    def update_play_button(self, is_playing):
        """Update play button text based on animation state."""
        if is_playing:
            self.play_button.setText("⏸️ Pause")
        else:
            self.play_button.setText("▶️ Play")
    
    def update_point_info(self, point_data):
        """Update point information display."""
        lines = []
        lines.append(f"📍 Point Information")
        lines.append(f"Map Coordinates: {point_data['map_x']:.2f}, {point_data['map_y']:.2f}")
        lines.append(f"RH2000 Coordinates: {point_data['rh2000_x']:.2f}, {point_data['rh2000_y']:.2f}")
        lines.append("")
        lines.append(f"Current Timestep: {point_data['timestep'] + 1} (t = {point_data['time']:.1f} s)")
        
        if point_data['dem_elevation'] is not None:
            lines.append(f"DEM Elevation: {point_data['dem_elevation']:.3f} m (RH2000)")
        
        if point_data['depth'] is not None:
            lines.append(f"Water Depth: {point_data['depth']:.3f} m")
        else:
            lines.append("Water Depth: No water")
        
        if point_data['surface_elevation'] is not None:
            lines.append(f"Water Surface: {point_data['surface_elevation']:.3f} m (RH2000)")
        
        if point_data['velocity'] is not None:
            lines.append(f"Flow Velocity: {point_data['velocity']:.3f} m/s")
        
        # Add time series summary
        if point_data['time_series_depth']:
            lines.append("")
            lines.append("📊 Time Series Summary:")
            max_depth = max([d[1] for d in point_data['time_series_depth'] if d[1] is not None] or [0])
            lines.append(f"Max Depth: {max_depth:.3f} m")
            
            if point_data['time_series_velocity']:
                max_velocity = max([v[1] for v in point_data['time_series_velocity'] if v[1] is not None] or [0])
                lines.append(f"Max Velocity: {max_velocity:.3f} m/s")
        
        self.point_info_text.setPlainText("\n".join(lines))


def create_time_series_dock_widget(controller):
    """Create a dock widget for time series controls."""
    # Create control panel
    control_panel = TimeSeriesControlPanel(controller)
    
    # Create dock widget
    dock = QDockWidget("FloodEngine Time Series", iface.mainWindow())
    dock.setWidget(control_panel)
    dock.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
    
    # Add to QGIS interface
    iface.addDockWidget(Qt.RightDockWidgetArea, dock)
    
    return dock, control_panel


def setup_time_series_animation(results_data, output_folder):
    """
    Set up time series animation for Saint-Venant results.
    
    Parameters:
        results_data (dict): Saint-Venant simulation results
        output_folder (str): Output folder for time series files
        
    Returns:
        tuple: (controller, dock_widget, control_panel)
    """
    # Create controller
    controller = MapCanvasTimeSeriesController(results_data, output_folder)
    
    # Create time series layers
    controller.create_time_series_layers()
    
    # Create dock widget with controls
    dock, control_panel = create_time_series_dock_widget(controller)
    
    logger.info("Time series animation setup complete")
    
    return controller, dock, control_panel


def launch_time_series_animation(results_data, output_folder):
    """
    Launch time series animation in QGIS environment.
    
    Parameters:
        results_data (dict): Simulation results with time series data
        output_folder (str): Path to animation output folder
    """
    try:
        logger.info("🎬 Launching time series animation in QGIS...")
        
        from qgis.utils import iface
        from PyQt5.QtCore import Qt
        
        # Create the time series controller
        controller = MapCanvasTimeSeriesController(results_data, output_folder)
        
        # Create the dock widget
        dock_widget = TimeSeriesDockWidget(controller)
        dock_widget.setWindowTitle("FloodEngine Time Series Animation")
        
        # Add dock widget to QGIS interface
        iface.addDockWidget(Qt.RightDockWidgetArea, dock_widget)
        dock_widget.show()
        
        # Create time series layers
        controller.create_time_series_layers()
        
        # Show first timestep
        controller.show_timestep(0)
        
        logger.info("✅ Time series animation launched in QGIS!")
        logger.info("📍 Look for the 'FloodEngine Time Series Animation' dock panel")
        logger.info("🎮 Use the controls to animate through timesteps")
        
        return controller, dock_widget
        
    except Exception as e:
        logger.error(f"❌ Failed to launch QGIS animation: {e}")
        raise


class TimeSeriesDockWidget(QDockWidget):
    """Dock widget for time series animation controls."""
    
    def __init__(self, controller, parent=None):
        super().__init__(parent)
        
        self.controller = controller
        self.setup_ui()
        self.connect_signals()
    
    def setup_ui(self):
        """Set up the dock widget UI."""
        from PyQt5.QtWidgets import (
            QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QSlider, 
            QLabel, QSpinBox, QCheckBox, QGroupBox, QGridLayout
        )
        from PyQt5.QtCore import Qt
        
        # Main widget
        main_widget = QWidget()
        self.setWidget(main_widget)
        
        # Main layout
        layout = QVBoxLayout(main_widget)
        
        # Title
        title_label = QLabel("🌊 FloodEngine Time Series")
        title_label.setStyleSheet("font-weight: bold; font-size: 14px; color: #2c3e50;")
        layout.addWidget(title_label)
        
        # Timestep info
        info_layout = QHBoxLayout()
        self.timestep_label = QLabel("Timestep: 0")
        self.time_label = QLabel("Time: 0.0s")
        info_layout.addWidget(self.timestep_label)
        info_layout.addStretch()
        info_layout.addWidget(self.time_label)
        layout.addLayout(info_layout)
        
        # Timeline slider
        self.timeline_slider = QSlider(Qt.Horizontal)
        self.timeline_slider.setMinimum(0)
        self.timeline_slider.setMaximum(len(self.controller.timestamps) - 1)
        self.timeline_slider.setValue(0)
        layout.addWidget(self.timeline_slider)
        
        # Control buttons
        controls_layout = QHBoxLayout()
        
        self.play_button = QPushButton("▶️")
        self.play_button.setToolTip("Play/Pause Animation")
        
        self.step_back_button = QPushButton("⏮️")
        self.step_back_button.setToolTip("Step Backward")
        
        self.step_forward_button = QPushButton("⏭️")
        self.step_forward_button.setToolTip("Step Forward")
        
        controls_layout.addWidget(self.step_back_button)
        controls_layout.addWidget(self.play_button)
        controls_layout.addWidget(self.step_forward_button)
        layout.addLayout(controls_layout)
        
        # Settings group
        settings_group = QGroupBox("Settings")
        settings_layout = QGridLayout(settings_group)
        
        # Speed control
        settings_layout.addWidget(QLabel("Speed (fps):"), 0, 0)
        self.speed_spinbox = QSpinBox()
        self.speed_spinbox.setRange(1, 10)
        self.speed_spinbox.setValue(2)
        settings_layout.addWidget(self.speed_spinbox, 0, 1)
        
        # Loop checkbox
        self.loop_checkbox = QCheckBox("Loop")
        self.loop_checkbox.setChecked(True)
        settings_layout.addWidget(self.loop_checkbox, 1, 0, 1, 2)
        
        # Point sampling checkbox
        self.sampling_checkbox = QCheckBox("Point Sampling")
        self.sampling_checkbox.setToolTip("Enable clicking on map to sample data")
        settings_layout.addWidget(self.sampling_checkbox, 2, 0, 1, 2)
        
        layout.addWidget(settings_group)
        
        # Point info display
        self.point_info_label = QLabel("Click on map to sample data")
        self.point_info_label.setStyleSheet("background-color: #ecf0f1; padding: 8px; border-radius: 4px;")
        self.point_info_label.setWordWrap(True)
        layout.addWidget(self.point_info_label)
        
        layout.addStretch()
    
    def connect_signals(self):
        """Connect UI signals to controller methods."""
        self.timeline_slider.valueChanged.connect(self.on_timestep_changed)
        self.play_button.clicked.connect(self.toggle_animation)
        self.step_back_button.clicked.connect(self.step_backward)
        self.step_forward_button.clicked.connect(self.step_forward)
        self.speed_spinbox.valueChanged.connect(self.update_speed)
        self.sampling_checkbox.toggled.connect(self.toggle_point_sampling)
        
        # Connect controller signals
        self.controller.timestep_changed.connect(self.update_display)
        self.controller.animation_state_changed.connect(self.update_play_button)
        self.controller.point_sampled.connect(self.update_point_info)
    
    def on_timestep_changed(self, timestep):
        """Handle timeline slider change."""
        self.controller.show_timestep(timestep)
    
    def toggle_animation(self):
        """Toggle animation play/pause."""
        self.controller.toggle_animation()
    
    def step_backward(self):
        """Step to previous timestep."""
        current = self.timeline_slider.value()
        if current > 0:
            self.timeline_slider.setValue(current - 1)
    
    def step_forward(self):
        """Step to next timestep."""
        current = self.timeline_slider.value()
        if current < self.timeline_slider.maximum():
            self.timeline_slider.setValue(current + 1)
    
    def update_speed(self, fps):
        """Update animation speed."""
        self.controller.set_animation_speed(fps)
    
    def toggle_point_sampling(self, enabled):
        """Toggle point sampling mode."""
        self.controller.set_point_sampling(enabled)
    
    def update_display(self, timestep, time_value):
        """Update display for current timestep."""
        self.timestep_label.setText(f"Timestep: {timestep + 1}")
        self.time_label.setText(f"Time: {time_value:.1f}s")
        self.timeline_slider.setValue(timestep)
    
    def update_play_button(self, is_playing):
        """Update play button text."""
        self.play_button.setText("⏸️" if is_playing else "▶️")
    
    def update_point_info(self, point_data):
        """Update point information display."""
        info_text = f"""
<b>Point Information:</b><br>
Coordinates: {point_data.get('x', 0):.2f}, {point_data.get('y', 0):.2f}<br>
RH2000: {point_data.get('rh2000_x', 0):.2f}, {point_data.get('rh2000_y', 0):.2f}<br>
Depth: {point_data.get('depth', 0):.3f} m<br>
Surface Elev: {point_data.get('surface_elevation', 0):.2f} m<br>
DEM Elev: {point_data.get('dem_elevation', 0):.2f} m<br>
Velocity: {point_data.get('velocity', 0):.3f} m/s
        """.strip()
        
        self.point_info_label.setText(info_text)
