#!/usr/bin/env python3
"""
Test script to verify multiple timestep generation and proper polygon clipping.
This will help identify the specific issues with blue squares and missing timesteps.
"""

import numpy as np
import os
import sys
sys.path.insert(0, r'c:\Plugin\VSCode\Alt3\FloodEngineX')

def test_complete_simulation():
    """Test the complete simulation process to identify issues."""
    print("FloodEngine v4.0 - Complete Simulation Test")
    print("=" * 55)
    
    # Test the main simulation function logic
    print("\n🧪 Testing simulation parameters:")
    
    # Simulate real parameters
    simulation_duration_hours = 24
    output_timesteps = 5  # Smaller number for testing
    output_interval_hours = simulation_duration_hours / output_timesteps
    
    # Create test DEM
    test_dem = np.array([
        [105, 104, 103, 102, 101],
        [104, 103, 102, 101, 100],
        [103, 102, 101, 100, 99],
        [102, 101, 100, 99, 98],
        [101, 100, 99, 98, 97]
    ], dtype=np.float32)
    
    # Generate water levels like the real function
    valid_elevations = test_dem[~np.isnan(test_dem)]
    dem_min = np.min(valid_elevations)
    dem_5th = np.percentile(valid_elevations, 5)
    dem_50th = np.percentile(valid_elevations, 50)
    
    start_level = dem_5th + 0.1
    end_level = dem_50th + 2.0
    
    water_levels = list(np.linspace(start_level, end_level, output_timesteps))
    
    print(f"   📊 Simulation duration: {simulation_duration_hours} hours")
    print(f"   📊 Output timesteps: {output_timesteps}")
    print(f"   📊 Output interval: {output_interval_hours:.1f} hours")
    print(f"   📊 DEM range: {dem_min:.1f} - {np.max(valid_elevations):.1f}")
    print(f"   📊 Water levels: {', '.join([f'{wl:.1f}' for wl in water_levels])}")
    
    # Test each timestep
    print(f"\n🔬 Testing timestep processing:")
    
    results = []
    for i, water_level in enumerate(water_levels):
        timestep = i + 1
        simulation_time_hours = timestep * output_interval_hours
        
        print(f"\n   Timestep {timestep}/{len(water_levels)}:")
        print(f"   ⏱️ Simulation time: {simulation_time_hours:.1f}h")
        print(f"   🌊 Water level: {water_level:.2f}m")
        
        # Calculate flooding like the real function
        flood_depth = np.zeros_like(test_dem, dtype=np.float32)
        seed_mask = (test_dem <= water_level) & (~np.isnan(test_dem))
        
        if np.any(seed_mask):
            potential_depth = np.maximum(0, water_level - test_dem)
            flood_depth = np.where(seed_mask, potential_depth, 0.0)
            
            # Apply time progression
            simulation_time_fraction = simulation_time_hours / simulation_duration_hours
            time_factor = 1.0 - np.exp(-3.0 * simulation_time_fraction)
            flood_depth = flood_depth * time_factor
            
            # Apply thresholds
            flood_depth = np.maximum(0, flood_depth)
            flood_depth[flood_depth < 0.05] = 0.0
            flood_depth[flood_depth > 0] = np.maximum(flood_depth[flood_depth > 0], 0.1)
        
        flooded_pixels = np.sum(flood_depth > 0)
        max_depth = np.max(flood_depth)
        
        print(f"   📊 Flooded pixels: {flooded_pixels}")
        print(f"   📊 Max depth: {max_depth:.2f}m")
        
        # Test boundary creation
        try:
            threshold = 0.05
            
            # Test the fixed boundary function
            binary_mask = (flood_depth > threshold)
            
            print(f"   🎯 Basic binary mask: {np.sum(binary_mask)} pixels")
            
            # Simulate contour-based refinement
            # Since we can't import the real function, simulate the logic
            if water_level and len(test_dem) > 0:
                # Elevation-based mask (areas below water level)
                elevation_mask = (test_dem < water_level) & ~np.isnan(test_dem)
                combined_mask = binary_mask & elevation_mask
                
                if np.sum(combined_mask) > 0:
                    refined_mask = combined_mask
                    print(f"   ✅ Refined mask: {np.sum(refined_mask)} pixels")
                else:
                    refined_mask = binary_mask
                    print(f"   ⚠️ Using basic mask: {np.sum(refined_mask)} pixels")
            else:
                refined_mask = binary_mask
                print(f"   ⚠️ No refinement: {np.sum(refined_mask)} pixels")
            
            # Test if this would create a valid polygon
            if np.sum(refined_mask) > 0:
                print(f"   ✅ Valid polygon can be created")
                
                # Simulate the file naming
                depth_filename = f"depth_{timestep:03d}.tif"
                layer_name = f"Flood_T{timestep:03d}_{simulation_time_hours:.1f}h_{water_level:.2f}m"
                
                results.append({
                    'timestep': timestep,
                    'filename': depth_filename,
                    'layer_name': layer_name,
                    'water_level': water_level,
                    'simulation_time': simulation_time_hours,
                    'flooded_pixels': flooded_pixels,
                    'max_depth': max_depth
                })
                
                print(f"   📁 Would create: {depth_filename}")
                print(f"   🏷️ Layer name: {layer_name}")
            else:
                print(f"   ⚠️ No flooding - would skip this timestep")
        
        except Exception as e:
            print(f"   ❌ Boundary processing failed: {e}")
    
    print(f"\n📋 SIMULATION SUMMARY:")
    print(f"   🔢 Total timesteps processed: {len(results)}")
    print(f"   📊 Valid timesteps with flooding: {len([r for r in results if r['flooded_pixels'] > 0])}")
    
    if len(results) > 0:
        print(f"   🌊 Water level range: {results[0]['water_level']:.1f} - {results[-1]['water_level']:.1f}m")
        print(f"   ⏱️ Time range: {results[0]['simulation_time']:.1f} - {results[-1]['simulation_time']:.1f}h")
        
        print(f"\n   📁 Files that would be created:")
        for r in results:
            print(f"     - {r['filename']} ({r['flooded_pixels']} pixels)")
        
        print(f"\n   🏷️ QGIS layers that would be added:")
        for r in results:
            print(f"     - {r['layer_name']}")
    
    print(f"\n🔍 ISSUE ANALYSIS:")
    
    if len(results) < output_timesteps:
        print(f"   ❌ ISSUE: Only {len(results)} timesteps generated instead of {output_timesteps}")
        print(f"       → Some timesteps have no flooding (water level too low)")
        print(f"       → Check water level generation logic")
    else:
        print(f"   ✅ Correct number of timesteps generated: {len(results)}")
    
    if all(r['flooded_pixels'] > 10 for r in results):
        print(f"   ✅ All timesteps have reasonable flooding")
    else:
        print(f"   ⚠️ Some timesteps have very little flooding")
        print(f"       → May appear as small or 'blue square' artifacts")
    
    print(f"\n💡 SOLUTIONS:")
    print(f"   1. For blue squares: Ensure create_precise_flood_boundary removes edge artifacts")
    print(f"   2. For missing timesteps: Check water level progression and DEM compatibility")
    print(f"   3. For only one layer: Verify all layers are added to QGIS project correctly")
    print(f"   4. For black contours: Ensure morphological operations clean boundaries")
    
    return results

if __name__ == "__main__":
    test_complete_simulation()
