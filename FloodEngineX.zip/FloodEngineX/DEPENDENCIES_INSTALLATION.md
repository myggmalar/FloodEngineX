# FloodEngine Dependencies Installation Guide

## Required Python Packages

The FloodEngine 2D model requires several spatial analysis packages. Install them using:

```bash
# Option 1: Install individual packages
pip install rasterio
pip install scipy
pip install pandas
pip install geopandas
pip install shapely
pip install fiona
pip install numpy

# Option 2: Install from requirements file
pip install -r requirements.txt
```

## For QGIS Plugin Development

If you're working within QGIS, you may need to install packages in the QGIS Python environment:

```bash
# Windows QGIS Python environment
python -m pip install rasterio scipy pandas geopandas shapely fiona

# Or use OSGeo4W Shell (QGIS)
pip install rasterio scipy pandas geopandas shapely fiona
```

## Error Resolution

If you get "No module named 'rasterio'" error:

1. **Check Python environment**: Make sure you're using the same Python environment as QGIS
2. **Install dependencies**: Run the pip install commands above
3. **Restart QGIS**: After installing packages, restart QGIS to load the new modules

## Testing Installation

You can test if the dependencies are properly installed by running:

```python
try:
    import rasterio
    import scipy
    import pandas
    import geopandas
    import shapely
    import fiona
    import numpy
    print("✅ All dependencies installed successfully!")
except ImportError as e:
    print(f"❌ Missing dependency: {e}")
```
