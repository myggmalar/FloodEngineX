#!/usr/bin/env python3
"""
Visible Animation Test
====================
Ensures the animation window is clearly visible and stays on top.
"""

import sys
import os
import numpy as np
from pathlib import Path

# Add FloodEngineX to path
script_dir = Path(__file__).parent
sys.path.insert(0, str(script_dir))

def test_visible_animation():
    """Create a highly visible animation test."""
    print("🎬 Creating VISIBLE animation test...")
    
    try:
        from PyQt5.QtWidgets import QApplication, QMessageBox
        from PyQt5.QtCore import Qt
        from time_series_animator import TimeSeriesAnimator
        import tempfile
        
        # Create QApplication
        app = QApplication.instance()
        if app is None:
            app = QApplication(sys.argv)
        
        # Show initial message
        msg = QMessageBox()
        msg.setWindowTitle("FloodEngine Animation Test")
        msg.setText("🌊 FloodEngine Animation Controls Test\n\nClick OK to launch animation controls.")
        msg.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)
        msg.setDefaultButton(QMessageBox.Ok)
        
        if msg.exec_() != QMessageBox.Ok:
            print("Test cancelled by user")
            return False
        
        # Create simple test data
        times = [0, 600, 1200, 1800, 2400, 3000, 3600, 4200, 4800, 5400]  # 10 timesteps over 90 minutes
        water_depths = []
        
        # Simple expanding square flood
        for i, t in enumerate(times):
            depth = np.zeros((20, 20))
            size = 3 + i  # Expanding square
            
            center = 10
            for y in range(max(0, center-size), min(20, center+size+1)):
                for x in range(max(0, center-size), min(20, center+size+1)):
                    depth[y, x] = 1.5 - 0.1 * max(abs(x-center), abs(y-center))
            
            water_depths.append(depth)
        
        # Create DEM
        dem = np.ones((20, 20)) * 100.0
        
        # Package results
        results_data = {
            'times': times,
            'water_depths': water_depths,
            'dem_array': dem,
            'geotransform': (0, 50, 0, 1000, 0, -50),  # 50m pixels
            'projection': 'EPSG:4326'
        }
        
        # Create temp directory
        temp_dir = tempfile.mkdtemp(prefix='flood_animation_')
        
        # Create animator
        animator = TimeSeriesAnimator(results_data, temp_dir)
        
        # Make it VERY visible
        animator.setWindowTitle("🌊 FloodEngine Animation Controls - TEST")
        animator.setGeometry(100, 100, 1000, 800)  # Large size, specific position
        animator.setWindowFlags(Qt.Window | Qt.WindowStaysOnTopHint)  # Stay on top
        animator.show()
        animator.raise_()
        animator.activateWindow()
        
        print("✅ Animation controls should now be VISIBLE!")
        print("🖼️ Window properties:")
        print(f"   - Size: 1000x800 pixels")
        print(f"   - Position: 100,100 from top-left")
        print(f"   - Stays on top: Yes")
        print(f"   - Title: 🌊 FloodEngine Animation Controls - TEST")
        
        print("\n🎮 Animation features to test:")
        print("   1. ▶️ Play button - starts animation")
        print("   2. ⏸️ Pause button - pauses animation")
        print("   3. ⏹️ Stop button - stops and resets")
        print("   4. 📊 Timeline slider - 10 positions (0-9)")
        print("   5. 🔢 Speed control - adjustable FPS")
        print("   6. 🔄 Loop checkbox - repeat animation")
        
        # Show completion message after 5 seconds
        from PyQt5.QtCore import QTimer
        def show_completion():
            completion_msg = QMessageBox()
            completion_msg.setWindowTitle("Animation Test Status")
            completion_msg.setText("✅ Animation controls should be visible!\n\n" +
                                 "Can you see the animation window with controls?\n\n" +
                                 "Features:\n" +
                                 "• Play/Pause/Stop buttons\n" +
                                 "• Timeline slider\n" +
                                 "• Speed controls\n" +
                                 "• Settings panel")
            completion_msg.setStandardButtons(QMessageBox.Ok)
            completion_msg.exec_()
            app.quit()
        
        timer = QTimer()
        timer.singleShot(5000, show_completion)  # Show message after 5 seconds
        
        return app.exec_()
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    print("🌊 FloodEngine Visible Animation Test")
    print("=" * 40)
    
    # Basic checks
    try:
        from PyQt5.QtWidgets import QApplication
        print("✅ PyQt5 available")
    except ImportError:
        print("❌ PyQt5 required - install with: pip install PyQt5")
        return 1
    
    try:
        import numpy as np
        print("✅ NumPy available")
    except ImportError:
        print("❌ NumPy required")
        return 1
    
    print("\n🚀 Starting visible animation test...")
    success = test_visible_animation()
    
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())
