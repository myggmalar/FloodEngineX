# Optimization Features for FloodEngine

## Overview

FloodEngine now includes optimization features to improve performance when working with large DEMs or when you only need to focus on a specific area of interest. These optimizations can significantly reduce processing time and memory usage.

## Features

### 1. Bounding Box Selection

The bounding box feature allows you to limit hydraulic calculations to a specific area of interest:

- Select a rectangular area on the map
- Use the current map extent
- Use the full DEM extent

This reduces the amount of data processed, significantly speeding up calculations when you only need to focus on a specific area.

### 2. Resolution Control

The resolution control feature allows you to reduce the resolution of the DEM for faster processing:

- Original resolution - Highest accuracy but slowest
- Half resolution (4x faster) - Good compromise between speed and accuracy
- Quarter resolution (16x faster) - Fast with acceptable accuracy for large areas
- Eighth resolution (64x faster) - Very fast with reduced accuracy
- Sixteenth resolution (256x faster) - Extremely fast for preliminary analysis

Lower resolutions process fewer cells, dramatically speeding up calculations at the cost of some detail.

## How to Use

1. Open the FloodEngine plugin
2. Go to the "Advanced Mode" tab
3. Find the "Hydraulic Model Optimization" section at the top
4. Click "Select Calculation Area and Resolution..."
5. In the dialog that appears:
   - Draw a bounding box on the map, use current extent, or use full DEM
   - Select your desired resolution
   - Click OK to apply these settings
6. Run your model as usual - it will use the optimized settings

After selecting your optimization settings, the UI will display your current settings.

## Performance Impact

Performance improvements depend on the specific optimizations you choose:

- Reducing the area by half reduces processing time by ~4x
- Reducing resolution by half reduces processing time by ~4x
- Combining both optimizations provides multiplicative improvements

## Notes and Recommendations

- Start with a lower resolution for initial tests, then increase for final results
- Use the bounding box to focus on your area of interest
- For very large DEMs, combining both optimizations is recommended
- Lower resolutions may smooth out small terrain features
