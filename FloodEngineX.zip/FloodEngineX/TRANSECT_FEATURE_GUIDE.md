# FloodEngine Transect Feature Guide

## Overview
The FloodEngine plugin now supports **user-defined transects** to solve the channel detection problem. Instead of relying on automatic channel detection, you can draw lines exactly where you want flooding to begin.

## Why Use Transects?

### Problems with Automatic Detection:
- May not find the correct river channels
- Could start flooding from wrong elevations
- Terrain complexity can confuse the algorithm
- Results in unrealistic flood patterns

### Benefits of Transects:
- **Complete Control**: You define exactly where flooding starts
- **Accurate Results**: Flooding follows your knowledge of the terrain
- **Realistic Patterns**: Water starts from actual river/channel locations
- **Flexible**: Works with any terrain or water source type

## How to Create and Use Transects

### Step 1: Create Transect Lines in QGIS

1. **Create New Shapefile**:
   - Layer → Create Layer → New Shapefile Layer
   - Geometry type: Line
   - Name: "flood_transects" (or any name you prefer)
   - CRS: Same as your DEM (typically SWEREF99 TM for Sweden)

2. **Draw Transect Lines**:
   - Enable editing for your transect layer
   - Use the "Add Line Feature" tool
   - Draw lines **across** rivers, channels, or water sources
   - Draw multiple lines along the river system
   - Lines should be perpendicular to flow direction
   - Each line represents potential flood starting points

3. **Transect Line Guidelines**:
   - Draw lines where you know water flows (rivers, streams, channels)
   - Multiple short lines work better than few long lines
   - Cover the main drainage network
   - Don't worry about line orientation - the plugin samples points along each line

### Step 2: Use Transects in FloodEngine

1. **Load Your DEM** as usual in the Basic tab

2. **Select Transect File**:
   - In the "Transects (optional)" field
   - Click "Browse..." 
   - Select your transect line shapefile

3. **Set Water Parameters**:
   - Choose water level OR flow rate
   - Set other parameters as normal

4. **Run Simulation**:
   - The plugin will extract starting points from your transect lines
   - Flooding will begin from these user-defined locations
   - Water will follow natural drainage patterns from these points

## Example Workflow

### For a Swedish River System:

```
1. Load Swedish DEM (RH2000 elevation system)
2. Identify river channel locations visually
3. Create transect lines across the main river and tributaries
4. In FloodEngine:
   - DEM: your_dem.tif
   - Transects: river_transects.shp
   - Flow Q: 200 m³/s (or water level: 12.5m RH2000)
5. Run simulation
6. Result: Realistic flooding starting from actual river locations
```

## Expected Results

### With Transects:
- ✅ Flooding starts from your defined river/channel locations
- ✅ Water levels are realistic relative to channel elevations
- ✅ Flood pattern follows natural drainage
- ✅ No flooding of high terrain areas
- ✅ Blue streamlines show proper flow direction

### Without Transects (automatic):
- ⚠️ May miss actual channels
- ⚠️ Could start from wrong elevations
- ⚠️ Unpredictable flood patterns

## Technical Details

### What the Plugin Does:

1. **Reads Transect Lines**: Opens your shapefile and extracts line geometries
2. **Samples Points**: Takes ~10 points along each line
3. **Converts Coordinates**: Maps geographic coordinates to DEM pixel locations
4. **Validates Points**: Ensures points are within DEM bounds and below water level
5. **Starts Flooding**: Uses these points as initial flood locations
6. **Propagates Water**: Follows natural drainage patterns from starting points

### Transect Requirements:

- **File Format**: ESRI Shapefile (.shp)
- **Geometry**: LineString (lines)
- **Coordinate System**: Should match your DEM
- **Content**: Lines drawn across water features (rivers, channels, etc.)

## Troubleshooting

### No Flooding Occurs:
- Check that transect lines cross actual low-elevation areas
- Verify water level is above channel elevations
- Ensure transect file coordinate system matches DEM

### Unexpected Flood Pattern:
- Add more transect lines to better define the channel system
- Check that lines are drawn across (not along) water features
- Verify DEM quality and coordinate alignment

### "No valid transect points found":
- Transect lines may be outside DEM bounds
- Water level may be too low
- Check coordinate system match between transect and DEM

## Best Practices

1. **Line Placement**: Draw across rivers perpendicular to flow
2. **Coverage**: Include main channels and major tributaries  
3. **Density**: More lines = better control, but 5-10 lines usually sufficient
4. **Validation**: Always check results and adjust transects if needed
5. **Documentation**: Save transect files with descriptive names

## Summary

The transect feature gives you complete control over flood starting locations, solving the channel detection problem and ensuring realistic flood simulations that match your local knowledge of the terrain and drainage patterns.
