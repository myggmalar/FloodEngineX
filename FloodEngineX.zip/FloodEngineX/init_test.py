"""
Simple initialization test for SaintVenant2D class
"""

print("Starting initialization test...")

try:
    print("Importing os and sys...")
    import os
    import sys
    print("Successfully imported os and sys")
    
    print("\nImporting numpy...")
    import numpy as np
    print("Successfully imported numpy")
    
    print("\nAttempting to import SaintVenant2D...")
    from saint_venant_2d import SaintVenant2D
    print("Successfully imported SaintVenant2D")
    
    print("\nCreating test DEM...")
    dem = np.ones((5, 5)) * 10.0
    dem[2, 2] = 9.0  # Simple depression
    print("Created test DEM")
    
    print("\nCreating SaintVenant2D instance...")
    model = SaintVenant2D(dem, (0, 1, 0, 0, 0, -1))
    print("Successfully created model instance")
    
    print("\nSetting initial water level...")
    try:
        model.set_initial_condition(water_level=10.5)
        print("Successfully set initial conditions")
        
        if hasattr(model, 'h'):
            print(f"Water depth array shape: {model.h.shape}")
            print(f"Maximum water depth: {np.max(model.h):.3f}m")
            if np.max(model.h) > 0:
                print("Water initialization successful!")
            else:
                print("WARNING: No water was initialized (max depth = 0)")
        else:
            print("ERROR: Model missing water depth array 'h'")
    
    except Exception as e:
        print(f"Error in set_initial_condition: {str(e)}")
        raise
    
    print("\nTest completed successfully!")

except ImportError as e:
    print(f"Import error: {str(e)}")
    print("Module search paths:")
    for path in sys.path:
        print(f"  {path}")
except Exception as e:
    print(f"Unexpected error: {str(e)}")
    import traceback
    traceback.print_exc()
