#!/usr/bin/env python3
"""
Fix the indentation and try/except structure in floodengine_ui.py
This script specifically targets the run_advanced_model function 
to fix the IndentationError after the try statement.
"""

import os
import re

def fix_advanced_model_indentation():
    file_path = r"c:\Plugin\VSCode\Alt3\FloodEngine\floodengine_ui.py"
    
    print("🔧 Fixing advanced model indentation and try/except structure...")
    
    # Read the current file
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Find the run_advanced_model function
    # Look for the specific problem area starting around line 2163
    lines = content.split('\n')
    
    # Find the start of the problematic try block
    try_block_start = -1
    for i, line in enumerate(lines):
        if 'def run_advanced_model(self):' in line:
            print(f"📍 Found run_advanced_model function at line {i+1}")
            # Look for the main try block within this function
            for j in range(i, min(i+50, len(lines))):
                if 'Main advanced model execution' in lines[j] and j+1 < len(lines) and 'try:' in lines[j+1]:
                    try_block_start = j+1
                    print(f"📍 Found main try block at line {try_block_start+1}")
                    break
            break
    
    if try_block_start == -1:
        print("❌ Could not find the problematic try block")
        return False
    
    # Find where this function ends (next function definition or end of class)
    function_end = len(lines)
    for i in range(try_block_start + 1, len(lines)):
        if re.match(r'^    def ', lines[i]) or re.match(r'^class ', lines[i]):
            function_end = i
            break
    
    print(f"📍 Function ends at line {function_end}")
    
    # Fix the indentation within the try block
    fixed_lines = lines[:try_block_start+1]  # Keep everything up to and including the try:
    
    # Process the content that should be inside the try block
    in_try_block = True
    except_added = False
    
    for i in range(try_block_start + 1, function_end):
        line = lines[i]
        
        # Skip lines that are already properly indented or are part of inner try blocks
        if line.strip() == '':
            fixed_lines.append(line)
            continue
            
        # If we hit another function, we're done with this try block
        if re.match(r'^    def ', line):
            # Make sure we have an except clause before ending
            if in_try_block and not except_added:
                fixed_lines.append('')
                fixed_lines.append('        except Exception as e:')
                fixed_lines.append('            self.iface.messageBar().pushCritical(')
                fixed_lines.append('                "FloodEngine Error",')
                fixed_lines.append('                f"Advanced model execution failed: {str(e)}"')
                fixed_lines.append('            )')
                fixed_lines.append('            import traceback')
                fixed_lines.append('            print(traceback.format_exc())')
                fixed_lines.append('            return')
                except_added = True
            fixed_lines.append(line)
            break
            
        # Check if this is already an except clause
        if line.strip().startswith('except Exception as e:') and in_try_block:
            # Fix the indentation of the except clause
            fixed_lines.append('        except Exception as e:')
            except_added = True
            in_try_block = False
            continue
            
        # If we're in the try block, make sure content is properly indented
        if in_try_block:
            # Check current indentation level
            indent_level = len(line) - len(line.lstrip())
            
            # Code inside the try block should be indented at least 8 spaces (2 levels)
            if line.strip() and indent_level < 8:
                # Add proper indentation
                line_content = line.lstrip()
                if line_content.startswith('#'):
                    fixed_lines.append('            ' + line_content)
                else:
                    fixed_lines.append('            ' + line_content)
            else:
                fixed_lines.append(line)
        else:
            # We're in the except block or after, keep proper indentation
            fixed_lines.append(line)
    
    # If we didn't add an except clause yet, add it now
    if in_try_block and not except_added:
        fixed_lines.append('')
        fixed_lines.append('        except Exception as e:')
        fixed_lines.append('            self.iface.messageBar().pushCritical(')
        fixed_lines.append('                "FloodEngine Error",')
        fixed_lines.append('                f"Advanced model execution failed: {str(e)}"')
        fixed_lines.append('            )')
        fixed_lines.append('            import traceback')
        fixed_lines.append('            print(traceback.format_exc())')
        fixed_lines.append('            return')
    
    # Add the rest of the file
    fixed_lines.extend(lines[function_end:])
    
    # Write the fixed content back
    fixed_content = '\n'.join(fixed_lines)
    
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(fixed_content)
    
    print("✅ Fixed indentation and try/except structure")
    return True

if __name__ == "__main__":
    try:
        success = fix_advanced_model_indentation()
        if success:
            print("🎉 Indentation fix completed successfully!")
        else:
            print("❌ Failed to fix indentation")
    except Exception as e:
        print(f"❌ Error during fix: {e}")
        import traceback
        traceback.print_exc()
